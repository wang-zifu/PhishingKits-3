<?php

$to ="abt.bangledesh@gmail.com,shipinglive@gmail.com";

?>