<?php

$email = "davidnagel2019@gmail.com"; // PUT UR FUCKING E-MAIL BRO

?>