vti_encoding:SR|utf8-nl
vti_timelastmodified:TW|21 Sep 2018 18:07:54 -0000
vti_author:SR|DESKTOP-E6HSF8S\\ahmad
vti_modifiedby:SR|DESKTOP-E6HSF8S\\ahmad
vti_nexttolasttimemodified:TW|21 Sep 2018 18:07:54 -0000
vti_timecreated:TR|21 Sep 2018 18:09:47 -0000
vti_cacheddtm:TX|21 Sep 2018 18:09:47 -0000
vti_filesize:IR|97848
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|boa/index.html
