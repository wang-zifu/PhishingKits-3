<?php
$recipient = "joehunter696@gmail.com, joehunter696@yandex.com"; //
?>