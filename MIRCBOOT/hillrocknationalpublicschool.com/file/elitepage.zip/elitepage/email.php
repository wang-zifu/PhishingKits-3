<?php
$recipient = "resultborce@yandex.com"; //
?>