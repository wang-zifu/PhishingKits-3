<?php
$recipient = "myworkpermit01@yandex.com, myworkpermit01@gmail.com"; //
?>