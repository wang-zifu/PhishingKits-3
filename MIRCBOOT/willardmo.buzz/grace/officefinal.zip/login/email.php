<?php



$sent1 ="shadyelkady@yandex.com";  //Enter you email here mr mayor




?>