
======================= Coded By x-Phisher ======================
____  ___        __________.__    .__       .__                  
\   \/  /        \______   \  |__ |__| _____|  |__   ___________ 
 \     /   ______ |     ___/  |  \|  |/  ___/  |  \_/ __ \_  __ \
 /     \  /_____/ |    |   |   Y  \  |\___ \|   Y  \  ___/|  | \/
/___/\  \         |____|   |___|  /__/____  >___|  /\___  >__|   
      \_/                       \/        \/     \/     \/       
=================================================================

Disclaimer :-
Use at your own risk we are not responsible for any illegal activity.

About :-
Name : Office365
Version : 10.0.0
Creation Date : 13/11/2019

Contact :-
Email : xphisher.pro@gmail.com
Websites : xphisher.pro , xphisher.com , xphisher.ru

===========================xxxxxxxxxxxxx=========================