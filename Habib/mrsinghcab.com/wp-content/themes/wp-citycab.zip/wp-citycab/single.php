<?php
/**
 * The Template for displaying all single posts.
 * @author Fox
 * @package cshero
 */
get_header();
?>
<?php global $smof_data,$breadcrumb; $layout = cshero_generetor_layout(); ?>
	<section id="primary" class="content-area<?php if($breadcrumb == '0'){ echo ' no_breadcrumb'; }; ?><?php echo esc_attr($layout->class); ?>">
        <div class="container">
            <div class="row">
            	<?php if($layout->left1_col):?>
            		<div class="left-wrap <?php echo esc_attr($layout->left1_col); ?>">
            		     <div id="secondary" class="widget-area" role="complementary">
							<div id="primary-sidebar" class="primary-sidebar widget-area" role="complementary">
								<?php dynamic_sidebar($layout->left1_sidebar); ?>
							</div>
						 </div>
            		</div>
            	<?php endif; ?>
                <div class="content-wrap <?php echo esc_attr($layout->blog); ?>">
                    <main id="main" class="site-main" role="main">
                        <?php while ( have_posts() ) : the_post(); ?>
                            <?php get_template_part( 'framework/templates/single/single',get_post_format()); ?>
                            <?php
                            	if($smof_data['show_navigation_post'] == '1'){
                            		cshero_post_nav();
                            	}
                            ?>
                            <div class="row post-details-footer">
                                <?php
                                	$tags = wp_get_post_tags(get_the_ID());
                                	if($smof_data['show_tags_post'] == '1' && count($tags) > 0):
                                ?>
                                <div class="cs_tags col-xs-12 col-sm-8 col-md-8 col-lg-8 clearfix">
    								<div class="tagcloud">
    								<?php
    								// Tags from post
    								foreach ($tags as $tag){
    									echo '<a class="tag-link-'.$tag->term_id.'" href="'.get_tag_link($tag->term_id).'">'.$tag->name.'</a>';
    								}
    								?>
    								</div>
    							</div>
    							<?php endif; ?>
                                <?php if($smof_data['show_social_post']):?>
                                <div class="cs-blog-share col-xs-12 col-sm-4 col-md-4 col-lg-4">
                                    <?php
                                        $attachment_image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full', false);
                                        $img = esc_attr($attachment_image[0]);
                                        $title = get_the_title();
                                        echo cs_socials_share(get_the_permalink(),$img, $title,get_comments_link($post->ID));
                                    ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php
                            // If comments are open or we have at least one comment, load up the comment template
                            if (cshero_show_comments('post') == '1') :
                                comments_template();
                            endif;
                            ?>
                        <?php endwhile; // end of the loop. ?>
                    </main><!-- #main -->
                </div>
                <?php if($layout->right1_col):?>
            		<div class="right-wrap <?php echo esc_attr($layout->right1_col); ?>">
            		     <div id="secondary" class="widget-area" role="complementary">
							<div id="primary-sidebar" class="primary-sidebar widget-area" role="complementary">
								<?php dynamic_sidebar($layout->right1_sidebar); ?>
							</div>
						 </div>
            		</div>
            	<?php endif; ?>
            </div>
        </div>
	</section><!-- #primary -->
<?php get_footer(); ?>