<?php

$output = $text = $google_fonts = $font_container = $el_class = $css = $google_fonts_data = $font_container_data = '';
extract( $this->getAttributes( $atts ) );
$atts['style'] = isset($atts['style'])?$atts['style']:'style-none';
extract( $this->getStyles( $el_class, $css, $google_fonts_data, $font_container_data, $atts ) );
extract(shortcode_atts(array(
    'after_heading_background_image_style' =>'',
), $atts));
$settings = get_option( 'wpb_js_google_fonts_subsets' );
$subsets  = '';
if ( is_array( $settings ) && ! empty( $settings ) ) {
	$subsets = '&subset=' . implode( ',', $settings );
}
$background_after_style="";
switch($after_heading_background_image_style){
    case "none":
         $background_after_style = "none";
    break;
    case "style1":
         $background_after_style = "taxi1";
    break;
    case "style2":
         $background_after_style = "taxi2";
    break;
    default:
        $background_after_style = "none";
}  
$output .= '<div class="cs-heading-wrap clearfix">';
$output .= '<div class="'.$atts['style'].' '.$font_container_data['values']['text_align'].' custom-heading-wrap '.$background_after_style.'" >';
	$output .= '<div class="' . $css_class . '" >';
	$output .= '<' . $font_container_data['values']['tag'] . ' style="' . implode( ';', $styles ) . '">';
	if($atts['style']=='title-icon'){
		$atts['title_icon']=isset($atts['title_icon'])?$atts['title_icon']:'';
		$output.="<i class='".$atts['title_icon']."'></i> ";
	}
	$output .= '<span>'.$text.'</span>';
	$output .= '</' . $font_container_data['values']['tag'] . '>';
	$output .= '</div>';
	if($atts['style']=='title-bottom-line'){
		$output.='<div class="title-bottom-line-wrap">';
		$style_inline="";
		if(isset($atts['title_bottom_line_width'])){
			$style_inline.="width:".$atts['title_bottom_line_width'].";";
		}
		if(isset($atts['title_bottom_line_height'])){
			$style_inline.="height:".$atts['title_bottom_line_height'].";";
		}
		if(isset($atts['title_bottom_line_color'])){
			$style_inline.="background:".$atts['title_bottom_line_color'].";";
		}
		if(isset($atts['title_bottom_line_margin_bottom'])){
			$style_inline.="margin-bottom:".$atts['title_bottom_line_margin_bottom'].";";
		}
		$output.='<div class="title-bottom-line-inner" style="'.$style_inline.'"></div>';
		$output.="</div>";
	}
	if($atts['style']=='title-bottom-dotted'){
		$output.='<div class="title-bottom-dotted-wrap">';
		$style_inline="";
	
		if(isset($atts['title_bottom_line_width'])){
			$style_inline.="width:".$atts['title_bottom_line_width'].";";
		}
		if(isset($atts['title_bottom_line_height'])){
			$style_inline.="border-bottom:".$atts['title_bottom_line_height']." dotted;";
		}else{
			$style_inline.="border-bottom:6px dotted;";
		}
		if(isset($atts['title_bottom_line_color'])){
			$style_inline.="border-color:".$atts['title_bottom_line_color'].";";
		}
		if(isset($atts['title_bottom_line_margin_bottom'])){
			$style_inline.="margin-bottom:".$atts['title_bottom_line_margin_bottom'].";";
		}
		
		$output.='<div class="title-bottom-dotted-inner" style="'.$style_inline.'"></div>';
		$output.="</div>";
	}
$output .= '</div>';
$output .= '</div>';

echo ''.$output;