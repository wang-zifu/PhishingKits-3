<?php
$output = $color = $size = $icon = $target = $href = $el_class = $title = $position = '';
extract( shortcode_atts( array(
	'color' => 'wpb_button',
	'size' => '',
	'icon' => 'none',
	'target' => '_self',
	'type' => 'btn btn-default',
	'button_block' => "false",
	'href' => '',
	'el_class' => '',
	'title' => __( 'Text on the button', "js_composer" ),
	'position' => '',
    'button_color' => '',
    'button_color_hover' =>'',
    'button_background_color' =>'',
    'button_background_color_hover'=>'',
    'button_border_color'=>'',
    'button_border_color_hover'=>'',
    'button_margin' => '',
    'button_padding' =>'',
    'button_font_size' => '',
    'button_font_weight' =>'',
    'button_position' => '',
    'enable_button_postion' =>'0'
    
), $atts ) );
$a_class = $color = $icon ;
$button_block = ($button_block == true)?"btn-block":"";
if ( $el_class != '' ) {
	$tmp_class = explode( " ", strtolower( $el_class ) );
	$tmp_class = str_replace( ".", "", $tmp_class );
	if ( in_array( "prettyphoto", $tmp_class ) ) {
		wp_enqueue_script( 'prettyphoto' );
		wp_enqueue_style( 'prettyphoto' );
		$a_class .= ' prettyphoto';
		$el_class = str_ireplace( "prettyphoto", "", $el_class );
	}
	if ( in_array( "pull-right", $tmp_class ) && $href != '' ) {
		$a_class .= ' pull-right';
		$el_class = str_ireplace( "pull-right", "", $el_class );
	}
	if ( in_array( "pull-left", $tmp_class ) && $href != '' ) {
		$a_class .= ' pull-left';
		$el_class = str_ireplace( "pull-left", "", $el_class );
	}
}

if ( $target == 'same' || $target == '_self' ) {
	$target = '';
}
$target = ( $target != '' ) ? ' target="' . $target . '"' : '';

$color = ( $color != '' ) ? ' wpb_' . $color : '';
$icon = ( $icon != '' && $icon != 'none' ) ? ' ' . $icon : '';
$i_icon = ( $icon != '' ) ? ' <i class="icon"> </i>' : '';
$position = ( $position != '' ) ? ' ' . $position . '-button-position' : '';
$el_class = $this->getExtraClass( $el_class );

$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, ' ' . $color . ' '. $type.' '.$button_block.' '. $size . $icon . $el_class . $position, $this->settings['base'], $atts );
$unique_id = uniqid().'_'.time();
$button_id = 'cshero-button'.$unique_id;
$button_style ='<style type="text/css" scoped>
    #'.$button_id.' .wpb_button_anone span.wpb_none.btn{
        color:'.$button_color.'!important;
        background:'.$button_background_color.'!important;
        border-color:'.$button_border_color.'!important;
        margin:'.$button_margin.' !important;
        padding:'.$button_padding.'!important;
        font-size:'.$button_font_size.'!important;
        font-weight:'.$button_font_weight.'!important;
    }
    #'.$button_id.' .wpb_button_anone span.wpb_none.btn:hover,
    #'.$button_id.' .wpb_button_anone span.wpb_none.btn:focus,
    #'.$button_id.' .wpb_button_anone span.wpb_none.btn:active{
        color:'.$button_color_hover.'!important;
        background:'.$button_background_color_hover.'!important;
        border-color:'.$button_border_color_hover.'!important;
    }';
if($enable_button_postion)
$button_style .= '
    #'.$button_id.' .wpb_button_anone{
        display: block;
        text-align: '.$button_position.';
    }
';
$button_style .='</style>';
if ( $href != '' ) {
	$output .= '<span class="' . $css_class . '">' . $title . $i_icon . '</span>';
	$output = '<div id="'.$button_id.'" class="cs-button">'.$button_style.'<a class="wpb_button_a' . $a_class . '" title="' . $title . '" href="' . $href . '"' . $target . '>'. $output . '</a></div>';
} else {
	$output .= '<button class="' . $css_class . '">' . $title . $i_icon . '</button>';

}

echo $output . $this->endBlockComment( 'button' ) . "\n";