<?php
global $smof_data;
require_once 'templates/multiple-blog.php';
require_once 'dynamic/dynamic.php';
if(class_exists('CsCoreControl'))
    require_once 'metabox/page_template.php';
if(function_exists('vc_add_param'))
	require_once 'vc_extra/vc_extra_params.php';
get_template_part('framework/widgets');
?>