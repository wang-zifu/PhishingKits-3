<?php 
add_action('init', 'cshero_vc_extra_param2');
/* add extra param for vc shortcodes */
function cshero_vc_extra_param2()
{
	/*
	 * Custom heading
	 */
	vc_add_param("cs_custom_heading", array (
		"type" => "dropdown",
		"heading" => __ ( 'After heading background', 'wp-citycab' ),
		"param_name" => "after_heading_background_image_style",
		"value" => array(
		'None'  =>  'none',
		'Style1' => 'style1',
		'Style2' => 'style2',
		),
		"description" => 'Set background after heading.'
	));
	/*
	 * Drop cap
	 */
	vc_add_param("cs-dropcap", array (
		"type" => "textfield",
		"heading" => __ ( 'Font weight content', 'wp-citycab' ),
		"param_name" => "font_weight",
		"value" => '',
		"description" => 'Font weight content(ex:100,200,300,400,500,600,700)'
	));
	vc_add_param("cs-dropcap", array (
		"type" => "textfield",
		"heading" => __ ( 'Sequence number item', 'wp-citycab' ),
		"param_name" => "sequence_number",
		"value" => '',
		"description" => 'Set sequence number item.'
	));
	vc_add_param("cs-dropcap", array (
		"type" => "colorpicker",
		"heading" => __ ( 'Sequence number color item', 'wp-citycab' ),
		"param_name" => "sequence_number_color",
		"value" => '',
		"description" => 'Set sequence number item.'
	));
	vc_add_param("cs-dropcap", array (
		"type" => "colorpicker",
		"heading" => __ ( 'Sequence number background item', 'wp-citycab' ),
		"param_name" => "sequence_number_background",
		"value" => '',
		"description" => 'Set sequence number item.'
	));
	vc_add_param("cs-dropcap", array (
		"type" => "textfield",
		"heading" => __ ( 'font-family', 'wp-citycab' ),
		"param_name" => "font_family",
		"value" => '',
		"description" => 'Set font family (ex: "Montserrat Alternates",arial).'
	));
   /*
	 * Fancybox
	 */

	vc_add_param("cshero-fancy-box", array (
		"type" => "checkbox",
		"heading" => __ ( 'Show icon arrow left (Layout 2).', 'wp-citycab' ),
		"param_name" => "show_icon_arrow_left",
		"value" => array (
				__ ( "Yes, please", 'wp-citycab' ) => true
		),
		"group" => "Icon",
		"description" => __ ( 'Show or hide icon icon arrow left.', 'wp-citycab' )
	));
	 vc_add_param("cshero-fancy-box", array (
		"type" => "checkbox",
		"heading" => __ ( 'Show icon arrow right (Layout 2).', 'wp-citycab' ),
		"param_name" => "show_icon_arrow_right",
		"value" => array (
				__ ( "Yes, please", 'wp-citycab' ) => true
		),
		"group" => "Icon",
		"description" => __ ( 'Show or hide icon icon arrow right.', 'wp-citycab' )
	));
	/*
	 * VC_COLUMN_TEXT
	 */

	vc_add_param("vc_column_text", array (
		"type" => "colorpicker",
		"heading" => __ ( 'Text color', 'wp-citycab' ),
		"param_name" => "text_color",
		"description" => __ ( 'Show or hide icon icon arrow left.', 'wp-citycab' )
	));
	 /*
	 * VC_BUTTON
	 */
	vc_add_param("vc_button", array (
	"type" => "colorpicker",
	"heading" => __ ( 'Button color', 'wp-citycab' ),
	"param_name" => "button_color",
	"group" => "Style"
));
	vc_add_param("vc_button", array (
		"type" => "colorpicker",
		"heading" => __ ( 'Button color hover', 'wp-citycab' ),
		"param_name" => "button_color_hover",
		"group" => "Style"
	));
	vc_add_param("vc_button", array (
		"type" => "colorpicker",
		"heading" => __ ( 'Background color', 'wp-citycab' ),
		"param_name" => "button_background_color",
		"group" => "Style"
	));
	vc_add_param("vc_button", array (
		"type" => "colorpicker",
		"heading" => __ ( 'Background color hover', 'wp-citycab' ),
		"param_name" => "button_background_color_hover",
		"group" => "Style"
	));
	vc_add_param("vc_button", array (
		"type" => "colorpicker",
		"heading" => __ ( 'Button border color', 'wp-citycab' ),
		"param_name" => "button_border_color",
		"group" => "Style"
	));
	vc_add_param("vc_button", array (
		"type" => "colorpicker",
		"heading" => __ ( 'Button border color hover', 'wp-citycab' ),
		"param_name" => "button_border_color_hover",
		"group" => "Style"
	));
	vc_add_param("vc_button", array (
		"type" => "textfield",
		"heading" => __ ( 'Button margin', 'wp-citycab' ),
		"param_name" => "button_margin",
		"group" => "Style"
	));
	vc_add_param("vc_button", array (
		"type" => "textfield",
		"heading" => __ ( 'Button padding', 'wp-citycab' ),
		"param_name" => "button_padding",
		"group" => "Style"
	));
	vc_add_param("vc_button", array (
		"type" => "textfield",
		"heading" => __ ( 'Button font size', 'wp-citycab' ),
		"param_name" => "button_font_size",
		"group" => "Style"
	));
	vc_add_param("vc_button", array (
		"type" => "textfield",
		"heading" => __ ( 'Button font weight', 'wp-citycab' ),
		"param_name" => "button_font_weight",
		"group" => "Style"
	));
	vc_add_param("vc_button", array (
		"type" => "checkbox",
		"heading" => __ ( 'Enable button position.', 'wp-citycab' ),
		"param_name" => "enable_button_postion",
		"value" => array (
			__ ( "Yes, please", 'wp-citycab' ) => true
		),
		"group" => "Style",
	));
	vc_add_param("vc_button", array(
		"type" => "dropdown",
		"heading" => __ ( 'Button position', 'wp-citycab' ),
		"param_name" => "button_position",
		"value" => array(
			'Left' => 'left',
			'Right' => 'right',
			'Center' => 'center'
		),
		"description" => 'Button position (ex:left,right,center)',
		"group" =>"Style"
	));
	/*
	* DROPCAP
	*/
	vc_remove_param( "vc_icon", "color" );
	vc_add_param("vc_icon", array(
		"type" => "textfield",
		"heading" => __ ( 'Icon margin', 'wp-citycab' ),
		"param_name" => "icon_margin",
		"description" => "Icon margin (ex:5px 5px 5xp 5px)"
	));
}
