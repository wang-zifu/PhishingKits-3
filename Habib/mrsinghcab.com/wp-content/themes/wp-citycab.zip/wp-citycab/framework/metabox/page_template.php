<?php

class CsheroTemplateMetaboxes
{

    public function __construct()
    {
        add_action('add_meta_boxes', array(
            $this,
            'add_meta_boxes'
        ));
        add_action('admin_enqueue_scripts', array(
            $this,
            'admin_script_loader'
        ));
    }

    function admin_script_loader()
    {
        global $pagenow;
        if (is_admin() && ($pagenow == 'post-new.php' || $pagenow == 'post.php')) {}
    }

    public function add_meta_boxes()
    {
        //$this->add_meta_box('template_classic_options', __('Template Blog Classic', 'wp-citycab'), 'page', 'side' , 'low');
    }

    public function add_meta_box($id, $label, $post_type, $context = 'advanced', $priority = 'default')
    {
        add_meta_box('cs_' . $id, $label, array(
            $this,
            $id
        ), $post_type, $context, $priority);
    }

    /* post */
    function template_classic_options()
    {
        ?>
        <div id="cs-blog-metabox" class='cs_metabox'>
        	<div style="max-height: 200px; overflow: auto;">
        	<?php
        	
        	?>
        	</div>
        </div>
        <?php
    }
}
new CsheroTemplateMetaboxes();