<?php
    global $portfolio_filters;
    $cshero_portfolio_filters_id = "cshero_portfolio_filters_{$portfolio_filters['filter']}";
    wp_enqueue_script('sorting_portfolio_item',get_template_directory_uri().'/cms_templates/portfolio/js/sorting.js');
?>
<div class="cshero_portfolio_filters <?php echo $filter_align.' '.str_replace('.','-',$layout).' '.esc_attr($el_class); ?>" <?php echo $filter_style; ?>>
    <ul class="list-unstyled btn-group" data-filter-group="category">
        <li class="active"><a class="<?php echo $filter_btn.' '.$filter_btn_size;?>" href="#" data-filter=""><?php echo __('All', 'wp-citycab'); ?></a></li>
        <?php
        global $portfolio_options;
        if (empty($portfolio_options['term_cats'])) {
            $terms = get_terms('portfolio_category', 'orderby=count&hide_empty=0');
        } else {
            $terms = $portfolio_options['term_cats'];
        }
        if ($terms && !is_wp_error($terms)) {
            foreach ($terms as $term) {
                if($term):
                ?>
                <li class="filter-items">
                    <a class="<?php echo $filter_btn.' '.$filter_btn_size;?>" href="#" data-filter=".cat-<?php echo esc_attr($term->slug); ?>">
                        <?php echo __($term->name, 'wp-citycab'); ?>
                    </a>
                </li>
                <?php
                endif;
            }
        }
        ?>
    </ul>
</div>
<div class="cshero_portfolio_order">
    <ul class="list-order btn-group">
        <li class="active"><button class="button btn btn-default" data-filter="*">Default</button></li>
        <li class="order-items"><button class="button btn btn-default" data-sort-by="title">Title</button></li>
        <li class="order-items"><button class="button btn btn-default" data-sort-by="date">Date</button></li>
        <li class="order-items"><button id="random" class="button btn btn-default" data-sort-by="random">Random</button></li>
    </ul>
</div>