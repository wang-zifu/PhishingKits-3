jQuery( function($) {
 var $container = $('.cshero-portfolio-wrapper').isotope({
  getSortData: {
    title: '.text-title',
    date: function(itemElem) {
        var date = $(itemElem).find('.post-date').attr('data-time').split("/");
        var new_date = date[1]+"/"+date[0]+"/"+date[2];
        return  new Date(new_date).getTime();
      }
    }
});
// sort items on button click
$('.cshero_portfolio_order').on( 'click', 'button', function() {
  var sortByValue = $(this).attr('data-sort-by');
  $container.isotope({ sortBy: sortByValue });
});
// sort random item
    $('#random').click( function() {
        $container.isotope('updateSortData').isotope({
            sortBy: 'random'
        });
    });
});
