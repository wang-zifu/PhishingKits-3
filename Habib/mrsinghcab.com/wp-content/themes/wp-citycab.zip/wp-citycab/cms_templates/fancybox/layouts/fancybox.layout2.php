<?php
extract(shortcode_atts(array(
    'show_icon_arrow_left' => '',
    'show_icon_arrow_right' => ''        
    ), $atts));
$arrow_item_right = "";
$arrow_item_left  = "";
if($show_icon_arrow_right)
    $arrow_item_right = 'arrow-item-right';
if($show_icon_arrow_left)
    $arrow_item_left = 'arrow-item-left';
?>
<div id="<?php echo esc_attr($fancybox_id); ?>" class="cshero-fancybox-wrap clearfix <?php echo esc_attr($fancy_wrap.' '.$custom_class.' '.$content_align.' '.$animate_class.' '.$arrow_item_right.' '.$arrow_item_left); ?>" <?php echo $box_style;?>>

 <?php if (!empty($image_url)) { ?>
    <img src="<?php echo esc_attr($image_url); ?>" alt="<?php echo $title; ?>" />
 <?php } ?>
    <div class="overlay-area">
        <?php if ( !empty( $content ) ):?>
            <div class="cshero-fancybox-content">
                <?php if ( $content ) : ?>
                    <h4 class="content">
                        <?php echo $content; ?>
                    </h4>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
