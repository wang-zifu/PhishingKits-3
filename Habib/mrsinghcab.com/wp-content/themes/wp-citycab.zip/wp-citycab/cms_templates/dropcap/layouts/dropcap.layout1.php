<?php
    extract(shortcode_atts(array(
        'sequence_number'=>'',
        'sequence_number_color'=>'',
        'sequence_number_background'=>'',
        'font_weight' =>'',
        'font_family' =>''
    ), $params));
	if ($icon != '') {
		$output .= '<div id="cs-dropcap-'.$date.'" class="'.str_replace(".","-",$layout).'"><p style="font-weight:'.$font_weight.';font-family:'.$font_family.' !important" class="text-content cs-icon"><i class="' . esc_attr ( $icon ) . '" ' . $styles . '></i>' . $content . '</p></div>';
	}
    elseif($sequence_number !='') {
		$output .= '<div id="cs-dropcap-'.$date.'" class="'.str_replace(".","-",$layout).'"><span class="circle" style="color:'.$sequence_number_color.';background:'.$sequence_number_background.'">'.$sequence_number.'</span><p style="font-weight:'.$font_weight.';font-family:'.$font_family.'!important" class="text-content">' . $content . '</p></div>';
	}else{
	   $output .= '<div id="cs-dropcap-'.$date.'" class="'.str_replace(".","-",$layout).'"><p style="font-weight:'.$font_weight.';font-family:'.$font_family.'!important" class="text-content cs-dropcap-firstText">' . $content . '</p></div>';
	}
?>