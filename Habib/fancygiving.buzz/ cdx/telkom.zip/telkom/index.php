<?php
header("location:hdtegjdjs.php")
?>