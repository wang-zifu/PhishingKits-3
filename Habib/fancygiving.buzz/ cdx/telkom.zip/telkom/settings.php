<?php
/**
 * Created by PhpStorm.
 * User: Habib
 * Date: 1/26/2020
 * Time: 1:10 PM
 * 
 */
$g_email = "mp283887@gmail.com";
//$g_email = "mp283887@gmail.com";