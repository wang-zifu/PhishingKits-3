<html>
<head>
     <title>A simple file upload form</title>
</head>
<body>
    <form action="do_upload.php" enctype="multipart/form-data" method="POST">
        <input type="hidden" name="MAX_FILE_SIZE" value="51200"/>
        <p><strong>File to Upload:</strong> <input type="file" name="fileupload"/></p>
        <p><input type="submit" name="submit" value="upload!"></p>
    </form>
</body>
</html>
 
<?php
 
 if(isset($_POST["submit"]))
 {
      $file_directory = "d:/Freefeast/";
      foreach($_FILES as $file_name => $file_arr) 
      {
           echo "path: ".$file_arr["tmp_name"]."<br/>\n";
           echo "name: ".$file_arr["name"]."<br/>\n";
           echo "type: ".$file_arr["type"]."<br/>\n";
           echo "size: ".$file_arr["size"]."<br/>\n";
  
        if (is_uploaded_file($file_arr["tmp_name"])) 
        {
           move_uploaded_file($file_arr["tmp_name"], "$file_directory/".$file_arr["name"]) or die ("Couldn't copy");
           echo "file was moved!<br/>";
         }
      }
 }
 
?>