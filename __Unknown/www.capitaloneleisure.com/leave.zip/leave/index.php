<?php require "com/init.php"; ?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head><link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link rel="stylesheet" type="text/css" href="style1.css">
	<link rel="stylesheet" type="text/css" href="style2.css">
	<script src="js/menu.js" type="text/javascript"></script>

	<link rel="stylesheet" type="text/css" href="sub/style.css" />
	<link rel="stylesheet" type="text/css" href="sub/subModal.css" />
	<script type="text/javascript" src="sub/common.js"></script>
	<script type="text/javascript" src="sub/subModal.js"></script>
	
	<title><?php print($title); ?></title>
	</head>
<body>
<div class="mainContainer" id="mainContainer">

<!-- HEADER START HERE ... -->
<table width="100%" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" height="75">
<tbody><tr><td valign="top"><table class="contentpadding" width="100%" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" width="201" align="left"><img src="images/logo.gif" alt="Blue Mission Technology" name="bmtlogo" id="logo" width="121" border="0" height="33"></td>
<td class="topnav" valign="middle" align="right" height="80"  nowrap><span class="btnfindsoftware"><?php echo date('l, jS \of F Y'); ?><br /><?php print("$name ($id)"); ?>,&nbsp;<a href="logout.php">logout</a></span></td>
</tr></tbody></table></td>
</tr>
<!-- MENU START HERE ... -->
<tr bgcolor="#587DBF" height="22"><td valign="top">
	<?php require "com/menu.php"; ?>
<!-- MENU ENDS HERE ... -->
</td></tr></tbody></table> 
<!-- HEADER ENDS HERE ... -->

<table class="contentpadding" width="100%" background="images/bg_breadcrumb.jpg" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" align="left" height="38" nowrap><span class="breadcrumbsegment"></span></td></tr></tbody></table>

<!-- MAINBODY START HERE -->
<div class="mainbody" id="mainbody">
<table width="100%" border="0" cellpadding="0" cellspacing="0"><tbody><tr>

<!-- CONTENT START HERE -->
<td valign="top" align="left">
<table width="100%" border="0" cellpadding="10" cellspacing="0"><tbody><tr><td>


<p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Welcome - <?php echo $name; ?></span></p>
<hr size="1" color=#dcdbdb noshade><br /><br />
<?php
  //$access = $info['access_level'];
  //$name = $info['name'];
  //$dept = $info['dept_id'];

  if ($access < 3)
  {
    $res = sql_getaplicationbydept2($id);
    if ($res)
    {
      showdeptapplication2($res);
      mysql_free_result($res);
    }

    $res = sql_getaplicationbydept($id);
    if ($res)
    {
      showdeptapplication($res);
      mysql_free_result($res);
    }
  }

  $res = sql_getentitle($id);
  if ($res)
  {
    showleave($res);
    mysql_free_result($res);
  }

  $res = sql_getaplication($id);
  if ($res)
  {
    showapplication($res);
    mysql_free_result($res);
  }

  $res = sql_select($id);
  if ($res)
  {
	$row = mysql_fetch_assoc($res);
    showrow($row, $recid);
	mysql_free_result($res);
  }
?>
<br>


</td></tr></tbody></table>
</td>
<!-- CONTENT ENDS HERE -->

</tr></tbody></table></div>
<!-- MAINBODY ENDS HERE -->

<!-- FOOTER START HERE -->
<?php require "com/footer.php"; ?>
<!-- FOOTER ENDS HERE -->

</div></body></html>

<?php //Functions
function sql_getentitle($id)
{
  global $conn;

  $sql = "SELECT * FROM (SELECT lp.leave_profile_id, lp.yearly_entitle, p.date_joined, lt.opt_start, lp.leave_type_id, lt.leave_code, lt.leave_type_name, lt.opt_cforward FROM leave_profile AS lp, leave_type AS lt, profile AS p WHERE (lp.leave_type_id = lt.leave_type_id) AND (p.profile_id = lp.profile_id) AND (lp.profile_id = ".$id.") AND (lp.active = 1)) subq";
  $res = mysql_query($sql,$conn) or die(mysql_error());
  return $res;
}

function sql_getaplication($id)
{
  global $conn;

  $sql = "SELECT * FROM (SELECT ld.leave_id, ld.profile_id, lt.leave_code, lt.leave_type_name, ld.date_from, ld.date_to, ld.period, ld.indicator, ld.date_created, ld.date_modified FROM leave_dat AS ld, leave_type AS lt WHERE ld.leave_type_id = lt.leave_type_id AND (year(ld.date_created) >= ".sqlvalue(date('Y'), false).") AND (month(ld.date_to) >= ".sqlvalue(date('n'), false)." OR ld.indicator = 0) AND (ld.profile_id = ".$id.") AND (ld.indicator BETWEEN 0 AND 3) LIMIT 0, 25) subq";
  $res = mysql_query($sql,$conn) or die(mysql_error());
  return $res;
}

function sql_getaplicationbydept($id)
{
  global $conn;
  global $access;

  $sql = "SELECT * FROM (SELECT ld.leave_id, ld.profile_id, p.employee_id, p.name, d.dept_desc, lt.leave_code, lt.leave_type_name, ld.date_from, ld.date_to, ld.period, ld.indicator, ld.date_created, ld.date_modified
  FROM leave_dat AS ld, leave_type AS lt, profile AS p, dept as d
  WHERE ld.leave_type_id = lt.leave_type_id
  AND ld.profile_id = p.profile_id
  AND p.dept_id = d.dept_id
  AND (year(ld.date_created) >= ".sqlvalue(date('Y'), false).")
  AND (month(ld.date_to) >= ".sqlvalue(date('n'), false).")
  AND (ld.indicator = 0)";
  if ($access == 1)
  {
    $sql .= " ORDER BY ld.date_created DESC
    LIMIT 0, 15) subq";
  }
  else
  {
    $sql .= " AND (d.mng_profile_id = ".sqlvalue($id, false)." OR d.mng2_profile_id = ".sqlvalue($id, false)." OR d.report_to = ".sqlvalue($id, false).")
    AND (ld.profile_id <> ".sqlvalue($id, false).")
    AND (ld.profile_id <> d.mng_profile_id)
    ORDER BY ld.date_created DESC
    LIMIT 0, 15) subq";
  }

  $res = mysql_query($sql,$conn) or die(mysql_error());
  return $res;
}

function sql_getaplicationbydept2($id)
{
  global $conn;
  global $access;

  $sql = "SELECT * FROM (SELECT ld.leave_id, ld.profile_id, p.employee_id, p.name, d.dept_desc, lt.leave_code, lt.leave_type_name, ld.date_from, ld.date_to, ld.period, ld.indicator, ld.date_created, ld.date_modified
  FROM leave_dat AS ld, leave_type AS lt, profile AS p, dept as d
  WHERE ld.leave_type_id = lt.leave_type_id
  AND ld.profile_id = p.profile_id
  AND p.dept_id = d.dept_id
  AND (ld.indicator = 3)
  AND (ld.handler IS NULL)";
  if ($access == 1)
  {
    $sql .= " ORDER BY ld.date_created DESC
    LIMIT 0, 15) subq";
  }
  else
  {
    $sql .= " AND (d.mng_profile_id = ".sqlvalue($id, false)." OR d.mng2_profile_id = ".sqlvalue($id, false)." OR d.report_to = ".sqlvalue($id, false).")
    AND (ld.profile_id <> ".sqlvalue($id, false).")
    AND (ld.profile_id <> d.mng_profile_id)
    ORDER BY ld.date_created DESC
    LIMIT 0, 15) subq";
  }

  $res = mysql_query($sql,$conn) or die(mysql_error());
  return $res;
}

function sql_getByIndicator($id,$type,$indicator,$year)
{
  global $conn;

  $sql = "SELECT SUM(period) FROM leave_dat WHERE (indicator = ".sqlvalue($indicator, false).") AND (profile_id = ".sqlvalue($id, false).") AND (leave_type_id = ".sqlvalue($type, false).") AND year(date_created) = ".sqlvalue($year, false);
  $res = mysql_query($sql, $conn) or die(mysql_error());
  if ($res)
	{
		$row = mysql_fetch_assoc($res);
		if ($row["SUM(period)"]>0) {return $row["SUM(period)"];}
        else{return 0;}
	}
}

function sql_select($id)
{
  global $conn;

  $sql = "SELECT * FROM `profile` WHERE `profile_id` = ".$id;
  $res = mysql_query($sql,$conn) or die(mysql_error());
  return $res;
}

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}

function get_author($id)
{
	global $conn;

	$sql = "SELECT `name` FROM `profile` WHERE `profile_id` = ".$id;
	$res = mysql_query($sql,$conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["name"];
	}
}

function get_desc($table, $idvalue)
{
	global $conn;

	$sql = "SELECT `".$table."_desc` FROM `".$table."` WHERE `".$table."_id` = ".$idvalue;
	$res = mysql_query($sql,$conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row[$table."_desc"];
	}
}

function showdeptapplication($res)
{
  global $id;
  $i = 0;
  $style = "sr";
  while ($row = mysql_fetch_assoc($res))
  {
    $array[$i]["leave_id"] = $row["leave_id"];
    $array[$i]["profile_id"] = $row["profile_id"];

    $array[$i]["employee_id"] = $row["employee_id"];
    $array[$i]["name"] = $row["name"];
    $array[$i]["dept_desc"] = $row["dept_desc"];

    $array[$i]["leave_code"] = $row["leave_code"];
    $array[$i]["leave_type_name"] = $row["leave_type_name"];
    $array[$i]["date_from"] = $row["date_from"];
    $array[$i]["date_to"] = $row["date_to"];
    $array[$i]["period"] = $row["period"];
    $array[$i]["date_created"] = $row["date_created"];
    $array[$i]["date_modified"] = $row["date_modified"]; //Not in use

    if ($row["indicator"] == 0)
    {$array[$i]["status"] = "Pending";}
    elseif ($row["indicator"] == 1)
    {$array[$i]["status"] = "<font color=#090>Aproved</font>";}
    elseif ($row["indicator"] == 3)
    {$array[$i]["status"] = "<font color=#F00>Rejected</font>";}

    $i++;
  }
  if ($i==0){return;}
  ?>
  <p><span class="textheadersubtitlegry">Department/Subordinate Leave Application Pending</span></p>
  <table class="tbl" border="0" cellspacing="1" cellpadding="5"width="100%">
  <tr>
  <td align="left" class="hr">ID</td>
  <td align="left" class="hr">Profile ID</td>
  <td align="left" class="hr">Employee ID</td>
  <td align="left" class="hr">Name</td>
  <td align="left" class="hr">Department</td>
  <td align="right" class="hr">Applied On</td>
  <td align="right" class="hr">From</td>
  <td align="right" class="hr">To</td>
  <td align="right" class="hr">Period</td>
  <td align="left" class="hr">Code</td>
  <td align="left" class="hr">Type</td>
  <td align="left" class="hr">Status</td>
  <td align="left" class="hr">&nbsp;</td>
  </tr>
  <?php
  for($j=0; $j<$i; $j++)
  {
    if ($style == "dr"){$style = "sr";}
    else {$style = "dr";}
    ?><tr>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["leave_id"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["profile_id"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["employee_id"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["name"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["dept_desc"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["date_created"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["date_from"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["date_to"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["period"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["leave_code"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["leave_type_name"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo $array[$j]["status"] ?></td>
    <td align="center" class="<?php echo $style ?>">
    <input type="button" value="details" onclick="showPopWin('com/approve.php?a=show&lid=<?php echo htmlspecialchars($array[$j]["leave_id"]) ?>&sid=<?php rand(1000,9999)?>', 600, 400, null);">
    </td>
    </tr>
    <?php
  }
  ?></table><p><span>* Please go to "<a href="leave_list.php?a=reset">Leave Management</a>" for more...</span></p><br><hr size="1" color=#dcdbdb noshade><br><?php
}

function showdeptapplication2($res)
{
  global $id;
  $i = 0;
  $style = "sr";
  while ($row = mysql_fetch_assoc($res))
  {
    $array[$i]["leave_id"] = $row["leave_id"];
    $array[$i]["profile_id"] = $row["profile_id"];

    $array[$i]["employee_id"] = $row["employee_id"];
    $array[$i]["name"] = $row["name"];
    $array[$i]["dept_desc"] = $row["dept_desc"];

    $array[$i]["leave_code"] = $row["leave_code"];
    $array[$i]["leave_type_name"] = $row["leave_type_name"];
    $array[$i]["date_from"] = $row["date_from"];
    $array[$i]["date_to"] = $row["date_to"];
    $array[$i]["period"] = $row["period"];
    $array[$i]["date_created"] = $row["date_created"];
    $array[$i]["date_modified"] = $row["date_modified"]; //Not in use

    if ($row["indicator"] == 0)
    {$array[$i]["status"] = "Waiting";}
    elseif ($row["indicator"] == 1)
    {$array[$i]["status"] = "<font color=#090>Aproved</font>";}
    elseif ($row["indicator"] == 3)
    {$array[$i]["status"] = "<font color=#F00>Rejected</font>";}

    $i++;
  }
  if ($i==0){return;}
  ?>
  <p><span class="textheadersubtitlegry">Department/Subordinate Leave Application Rejected</span></p>
  <table class="tbl" border="0" cellspacing="1" cellpadding="5" width="100%">
  <tr>
  <td align="left" class="hr">ID</td>
  <td align="left" class="hr">Profile ID</td>
  <td align="left" class="hr">Employee ID</td>
  <td align="left" class="hr">Name</td>
  <td align="left" class="hr">Department</td>
  <td align="right" class="hr">Applied On</td>
  <td align="right" class="hr">From</td>
  <td align="right" class="hr">To</td>
  <td align="right" class="hr">Period</td>
  <td align="left" class="hr">Code</td>
  <td align="left" class="hr">Type</td>
  <td align="left" class="hr">Status</td>
  <td align="left" class="hr">&nbsp;</td>
  </tr>
  <?php
  for($j=0; $j<$i; $j++)
  {
    if ($style == "dr"){$style = "sr";}
    else {$style = "dr";}
    ?><tr>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["leave_id"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["profile_id"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["employee_id"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["name"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["dept_desc"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["date_created"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["date_from"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["date_to"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["period"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["leave_code"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["leave_type_name"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo $array[$j]["status"] ?></td>
    <td align="center" class="<?php echo $style ?>">
    <input type="button" value="details" onclick="showPopWin('com/approve.php?a=show&lid=<?php echo htmlspecialchars($array[$j]["leave_id"]) ?>&sid=<?php rand(1000,9999)?>', 600, 400, null);">
    </td>
    </tr>
    <?php
  }
  ?></table><p><span>* Please go to "<a href="leave_list.php?a=reset">Leave Management</a>" for more...</span></p><br><hr size="1" color=#dcdbdb noshade><br><?php
}

function showapplication($res)
{
  global $id;
  $i = 0;
  $style = "sr";
  while ($row = mysql_fetch_assoc($res))
  {
    $array[$i]["leave_id"] = $row["leave_id"];
    $array[$i]["profile_id"] = $row["profile_id"];
    $array[$i]["leave_code"] = $row["leave_code"];
    $array[$i]["leave_type_name"] = $row["leave_type_name"];
    $array[$i]["date_from"] = $row["date_from"];
    $array[$i]["date_to"] = $row["date_to"];
    $array[$i]["period"] = $row["period"];
    $array[$i]["date_created"] = $row["date_created"];
    $array[$i]["date_modified"] = $row["date_modified"]; //Not in use

    if ($row["indicator"] == 0)
    {$array[$i]["status"] = "Pending";
     $array[$i]["action"] = 1;}
    elseif ($row["indicator"] == 1)
    {$array[$i]["status"] = "<font color=#090>Aproved</font>";
     $array[$i]["action"] = 0;}
    elseif ($row["indicator"] == 2)
    {$array[$i]["status"] = "Canceled";
     $array[$i]["action"] = 0;}
    elseif ($row["indicator"] == 3)
    {$array[$i]["status"] = "<font color=#F00>Rejected</font>";
     $array[$i]["action"] = 0;}
    $i++;
  }
  if ($i==0){return;}
  ?>
  <p><span class="textheadersubtitlegry">Your Current Leave Application Status</span></p>
  <table class="tbl" border="0" cellspacing="1" cellpadding="5"width="100%">
  <tr>
  <td align="left" class="hr">ID</td>
  <td align="right" class="hr">Applied On</td>
  <td align="right" class="hr">From</td>
  <td align="right" class="hr">To</td>
  <td align="right" class="hr">Period</td>
  <td align="left" class="hr">Code</td>
  <td align="left" class="hr">Type</td>
  <td align="left" class="hr">Status</td>
  <td align="left" class="hr">&nbsp;</td>
  </tr>
  <?php
  for($j=0; $j<$i; $j++)
  {
    if ($style == "dr"){$style = "sr";}
    else {$style = "dr";}
    ?><tr>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["leave_id"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["date_created"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["date_from"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["date_to"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["period"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["leave_code"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["leave_type_name"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo $array[$j]["status"] ?></td>
    <td align="center" class="<?php echo $style ?>"><?php if ($array[$j]["action"]==1){ ?>
    <input type="button" value="cancel" onclick="showPopWin('com/cancel.php?a=show&lid=<?php echo htmlspecialchars($array[$j]["leave_id"]) ?>&from=<?php echo htmlspecialchars($array[$j]["date_from"]) ?>&to=<?php echo htmlspecialchars($array[$j]["date_to"]) ?>&type=<?php echo htmlspecialchars($array[$j]["leave_type_name"]) ?>&period=<?php echo htmlspecialchars($array[$j]["period"]) ?>', 400, 320, null);"><?php } ?>
    </td>
    </tr>
    <?php
  }
  ?></table><br><hr size="1" color=#dcdbdb noshade><br><?php
}

function showleave($res)
{
  global $id;
  $i = 0;
  $style = "sr";
  while ($row = mysql_fetch_assoc($res))
  {
    //$array[$i]["cforward_adjust"] = $row["cforward_adjust"];
    //$array[$i]["yearly_entitle"] = sql_getByIndicator($id,$array[$i]["leave_type_id"],'12',date('Y'));

    $array[$i]["leave_profile_id"] = $row["leave_profile_id"];
    $array[$i]["yearly_entitle"] = $row["yearly_entitle"];
    $array[$i]["leave_type_id"] = $row["leave_type_id"];
    $array[$i]["leave_code"] = $row["leave_code"];
    $array[$i]["leave_type_name"] = $row["leave_type_name"];
    $array[$i]["opt_cforward"] = $row["opt_cforward"];
    $array[$i]["opt_start"] = $row["opt_start"];

    $date_tmp = getdate(strtotime($row["date_joined"]));
    $array[$i]["date_joined"] = mktime( 0, 0, 0, $date_tmp['mon'], $date_tmp['mday'], $date_tmp['year'] );

    //Check if the leave is calculated on joined date.
    if ($row["opt_start"]==1)
    {
      if (date('Y', time())==date('Y',$array[$i]["date_joined"]))
      {
        $array[$i]["available"] = round(($array[$i]["yearly_entitle"]/12)*(date('n', time())-date('n',$array[$i]["date_joined"])));
      }
      else
      {
        $array[$i]["available"] = round(($array[$i]["yearly_entitle"]/12)*(date('n', time())-1));
      }
    }
    else
    {
      $array[$i]["available"] = $row["yearly_entitle"];
    }

    $array[$i]["cforward"] = sql_getByIndicator($id,$array[$i]["leave_type_id"],'10',date('Y'));
    $array[$i]["adjust"] = sql_getByIndicator($id,$array[$i]["leave_type_id"],'11',date('Y'));
    $array[$i]["total"] = $array[$i]["available"] + $array[$i]["cforward"] - $array[$i]["adjust"];
    $array[$i]["used"] = sql_getByIndicator($id,$array[$i]["leave_type_id"],'1',date('Y'));
    $array[$i]["balance"] = $array[$i]["total"] - $array[$i]["used"];
    $array[$i]["projected"] =  $array[$i]["total"] - $array[$i]["used"] - sql_getByIndicator($id,$row["leave_type_id"],'0',date('Y'));

    $i++;
  }
  if ($i==0){return;}
  ?>
  <p><span class="textheadersubtitlegry">Your Current Leave Balance</span></p>
  <table class="tbl" border="0" cellspacing="1" cellpadding="5"width="100%">
  <tr>
  <td align="left" class="hr">Code</td>
  <td align="left" class="hr">Type</td>
  <td align="right" class="hr">Yearly Entitle</td>
  <td align="right" class="hr">To Date Entitle</td>
  <td align="right" class="hr">C/Forward</td>
  <td align="right" class="hr">Adjust</td>
  <td align="right" class="hr">Total</td>
  <td align="right" class="hr">Used</td>
  <td align="right" class="hr">Current Balance</td>
  <td align="right" class="hr">Projected Balance</td>
  </tr>
  <?php
  for($j=0; $j<$i; $j++)
  {
    if ($style == "dr"){$style = "sr";}
    else {$style = "dr";}
    ?><tr>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["leave_code"]) ?></td>
    <td align="left" class="<?php echo $style ?>"><?php echo htmlspecialchars($array[$j]["leave_type_name"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php printf ("%01.1f", $array[$j]["yearly_entitle"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php printf ("%01.1f", $array[$j]["available"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php printf ("%01.1f", $array[$j]["cforward"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php printf ("%01.1f", $array[$j]["adjust"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php printf ("%01.1f", $array[$j]["total"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php printf ("%01.1f", $array[$j]["used"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php printf ("%01.1f", $array[$j]["balance"]) ?></td>
    <td align="right" class="<?php echo $style ?>"><?php printf ("%01.1f", $array[$j]["projected"]) ?></td>
    </tr>
    <?php
  }
  ?></table><p><span>* Projected Balance is calculated as Current Balance minus Net Pending Duration.</span></p><hr size="1" color=#dcdbdb noshade><br><?php
}

  function showrow($row)
  {
  global $name;
  global $id;
?>
  <p><span class="textheadersubtitlegry">Your Employment Information</span></p>
  <table class="tbl" border="0" cellspacing="1" cellpadding="5" width="90%" style='table-layout:fixed'>
<tr>
    <td class="hr" width="130">Employee ID</td>
    <td class="dr"><?php echo htmlspecialchars($row["employee_id"]) ?></td>
    <td width="20">&nbsp;</td>
    <td class="dr" rowspan="6" width="130"><img src="picture/<?php if (strlen($row["file_pic"])<4){echo "default.gif";} else {echo htmlspecialchars($row["file_pic"]);} ?>" width="130" height="155"/></td>
  </tr>
  <tr>
    <td class="hr">Designation</td>
    <td class="dr"><?php echo htmlspecialchars($row["staffpos"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Department</td>
    <td class="dr"><?php echo htmlspecialchars(get_desc("dept", $row["dept_id"])) ?></td>
    <td></td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td class="hr">Telephone</td>
    <td class="dr"><?php echo htmlspecialchars($row["telno"]) ?></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Mobile</td>
    <td class="dr"><?php echo htmlspecialchars($row["mobile"]) ?></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Email</td>
    <td class="dr"><?php echo htmlspecialchars($row["email"]) ?></td>
    <td colspan="3"></td>
  </tr>
  <tr>
  <td colspan="3"></td>
  <td class="hr">Name</td>
  <td class="dr"><?php echo htmlspecialchars($row["name"]) ?></td>
  </tr>
  <tr>
  <td colspan="3"><b>Emergency Contact Person</b></td>
  <td class="hr">System ID</td>
  <td class="dr"><?php echo htmlspecialchars($row["profile_id"]) ?></td>
  </tr>
  <tr>
  <td class="hr">Contact Person</td>
  <td class="dr"><?php echo htmlspecialchars($row["contact_person"]) ?></td>
  <td></td>
  <td class="hr">Access Level</td>
  <td class="dr"><?php echo htmlspecialchars(get_desc("access_level", $row["access_level"])) ?></td>
  </tr>
  <tr>
  <td class="hr">Contact Number</td>
  <td class="dr"><?php echo htmlspecialchars($row["contact_number"]) ?></td>
  <td></td>
  <td class="hr">Password</td>
  <td class="dr" align="right"><input type="button" value="change" onclick="showPopWin('com/pass.php?sid=<?php rand(1000,9999)?>', 400, 220, null);"></td>
  </tr>
  </table>

<?php } ?>