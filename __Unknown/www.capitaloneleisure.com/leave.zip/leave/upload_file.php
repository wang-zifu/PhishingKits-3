<?php require "com/init.php";

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}

function sql_update($pid,$file)
{
  global $conn;
  global $id;
  $sql = "update `profile` set `file_doc`=".sqlvalue($file, true)
  .", `date_modified`=" .sqlvalue(date("Y-m-d H:i:s"), true)
  .", `modified_by`=" .sqlvalue($id, false) ." where `profile_id`=".$pid;
  mysql_query($sql, $conn) or die(mysql_error());
}

function get_filetype()
{
  $extend = ".rar";
  switch ($_FILES["file"]["type"]) {
      case "application/zip":
      $extend = ".zip";
          break;
  }
  return $extend;
}

$pid = @$_POST["pid"];
$str = "";

if (isset($_POST["a"])) $a = @$_POST["a"];
if(strlen($_FILES["file"]["name"])==0)
{
  foreach (glob("upload/".$pid."doc*.*") as $filename) {
    unlink($filename);
    $str .= "File Removed: " . $filename . "<br />";
  }
  if(strlen($str)<1){$str .= "No File Removed.<br />";}
  sql_update($pid,"");
}
else
{
  if ((($_FILES["file"]["type"] == "application/octet-stream")
  || ($_FILES["file"]["type"] == "application/zip") || ($_FILES["file"]["type"] == "application/x-zip-compressed"))
  && ($_FILES["file"]["size"] < 2000000))
  {
    if ($_FILES["file"]["error"] > 0)
    {
      $str = "Return Code: " . $_FILES["file"]["error"] . "<br />";
    }
    else
    {
      $str = "Upload: " . $_FILES["file"]["name"] . "<br />";
      $str .= "Type: " . $_FILES["file"]["type"] . "<br />";
      $str .= "Size: " . round(($_FILES["file"]["size"] / 1024),2) . " Kb<br />";

      $extend = get_filetype();
      $file = $pid."doc".rand(1000,9999).$extend;

      //foreach (glob("upload/".$pid."doc*.*") as $filename) {
          //unlink($filename);
      //}

      move_uploaded_file($_FILES["file"]["tmp_name"],"upload/".$file);
      sql_update($pid,$file);
      $str .= "Successfully Uploaded.";
    }
  }
  else
  {
    $str =  "Error : Invalid file or file size.<br /><br />";
    $str .= "Please make sure the file you upload is zip<br /> and the size is not more then 2Mb.<br /><br />";
    $str .= "Type: " . $_FILES["file"]["type"] . "<br />";
    $str .= "Size: " . round(($_FILES["file"]["size"] / 1024),2) . " Kb<br />";
  }
}
echo $str;
?>