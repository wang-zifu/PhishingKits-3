<?php require "com/init1.php"; ?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link rel="stylesheet" type="text/css" href="style4.css">

    <style>
    body, html, input {
	font-family:Verdana, Arial, Helvetica, sans-serif;
	font-size:11px;
	color: #333333;
    }

    .info {
	font-style:italic;
	font-size: 0.9em;
	color: #666666;
    }
    .textheadertitle
    {
    FONT-WEIGHT: 500;
    FONT-SIZE: 16pt;
    TEXT-TRANSFORM: none;
    COLOR: #333333;
    FONT-STYLE: normal;
    FONT-WEIGHT: bold;
    FONT-FAMILY: Helvetica, Arial, Verdana, serif;
    FONT-VARIANT: normal
    }
    .textheadersubtitlegry
    {
        FONT-WEIGHT: normal;
        FONT-SIZE: 11pt;
        COLOR: #999999;
        FONT-STYLE: oblique;
        FONT-FAMILY: Arial, Helvetica, 'Times New Roman', Times, serif
    }
    .textsubtitlegry
    {
        FONT-WEIGHT: normal;
        FONT-SIZE: 8pt;
        COLOR: #333;
        FONT-FAMILY: Arial, Helvetica, 'Times New Roman', Times, serif
    }
    A
    {
        COLOR: #2c498b;
        TEXT-DECORATION: none
    }
    A:hover
    {
        COLOR: #2c498b;
        TEXT-DECORATION: underline
    }
    .input2{
        FONT-FAMILY: Arial, Helvetica, 'Times New Roman', Times, serif;
    	border: 1px solid #ccc;
    	font-size: 11px;
    	width: 200px;
    }

    .input2:hover,.input2:focus{
        border: 1px solid #666;
    }
    </style>
	<link rel="stylesheet" type="text/css" href="../sub/subModal.css" />
	<script type="text/javascript" src="../sub/common.js"></script>
	<script type="text/javascript" src="../sub/subModal.js"></script>
	<title><?php print($title); ?></title>
	</head>
<?php
  if (isset($_GET["order2"])) $order = @$_GET["order2"];
  if (isset($_GET["type2"])) $ordtype = @$_GET["type2"];

  if (isset($_POST["filter2"])) {$filter = @$_POST["filter2"];} else {$filter = $_GET["filter2"];}
  if (isset($_POST["filter_field2"])) {$filterfield = @$_POST["filter_field2"];} else {$filterfield = $_GET["filter_field2"];}
  $wholeonly = false;
  if (isset($_POST["wholeonly2"])) $wholeonly = @$_POST["wholeonly2"];

  if (!isset($order) && isset($_SESSION["order2"])) $order = $_SESSION["order2"];
  if (!isset($ordtype) && isset($_SESSION["type2"])) $ordtype = $_SESSION["type2"];
  if (!isset($filter) && isset($_SESSION["filter2"])) $filter = $_SESSION["filter2"];
  if (!isset($filterfield) && isset($_SESSION["filter_field2"])) $filterfield = $_SESSION["filter_field2"];
?>

<body>
<div class="mainContainer" id="mainContainer">

<!-- MAINBODY START HERE -->
<div class="mainbody" id="mainbody">
<table width="100%" border="0" cellpadding="0" cellspacing="0"><tbody><tr>

<!-- CONTENT START HERE -->
<td valign="top" align="left">
<table width="100%" border="0" cellpadding="10" cellspacing="0"><tbody><tr><td>

<span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Leave Setting</span><br />
<?php
  $conn = connect();
  $showrecs = 25;
  $pagerange = 10;

  $a = @$_GET["a2"];
  $recid = @$_GET["recid2"];
  $page = @$_GET["page2"];
  if (!isset($page)) $page = 1;

  $sql = @$_POST["sql2"];

  switch ($sql) {
    case "insert":
      sql_insert();
      break;
    case "update":
      sql_update();
      break;
    case "delete":
      sql_delete();
      break;
  }

  switch ($a) {
    case "add":
      addrec();
      break;
    case "edit":
      editrec($recid);
      break;
    case "del":
      deleterec($recid);
      break;
    default:
      select();
      break;
  }

  if (isset($filter)) $_SESSION["filter2"] = $filter;
  if (isset($filterfield)) $_SESSION["filter_field2"] = $filterfield;
  if (isset($wholeonly)) $_SESSION["wholeonly2"] = $wholeonly;

  mysql_close($conn);
?>
</body>
</html>

<?php function select()
  {
  global $a;
  global $showrecs;
  global $page;

  $res = sql_selectmain();
  $count = sql_getrecordcountmain();
  if ($count % $showrecs != 0) {
    $pagecount = intval($count / $showrecs) + 1;
  }
  else {
    $pagecount = intval($count / $showrecs);
  }
  $startrec = $showrecs * ($page - 1);
  if ($startrec < $count) {mysql_data_seek($res, $startrec);}
  $reccount = min($showrecs * $page, $count);
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr><td>Records shown <?php echo $startrec + 1 ?> - <?php echo $reccount ?> of <?php echo $count ?></td></tr>
</table>
<hr size="1" color=#dcdbdb noshade>
<?php showpagenav($page, $pagecount); ?>
<br>
<table class="tbl" border="0" cellspacing="1" cellpadding="5"width="100%">
<tr>
<td class="hr"><?php echo "Rec" ?></td>
<td class="hr"><?php echo "System ID" ?></td>
<td class="hr"><?php echo "Leave Type" ?></td>
<td class="hr"><?php echo "Yearly Entitlement" ?></td>
<td class="hr"><?php echo "Active" ?></td>
<td class="hr">&nbsp;</td>
<td class="hr">&nbsp;</td>
</tr>
<?php
  for ($i = $startrec; $i < $reccount; $i++)
  {
    $row = mysql_fetch_assoc($res);
    $style = "dr";
    if ($i % 2 != 0) {
      $style = "sr";
    }
?>
<tr>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["leave_profile_id"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["profile_id"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["leave_type_name"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["yearly_entitle"]) ?></td>
<td class="<?php echo $style ?>"><?php if($row["active"]==1){echo htmlspecialchars("Yes");}else{echo htmlspecialchars("No");} ?></td>
<td class="<?php echo $style ?>"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a2=edit&recid2=<?php echo $i ?>">Edit</a></td>
<td class="<?php echo $style ?>"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a2=del&recid2=<?php echo $i ?>">Delete</a></td>
</tr>
<?php
  }
  mysql_free_result($res);
?>
</table>
<br>
<?php showpagenav($page, $pagecount); ?>
<?php } ?>

<?php function showrow($row, $recid)
  {
?>
<table class="tbl" border="0" cellspacing="1" cellpadding="5"width="50%">
<tr>
<td class="hr"><?php echo htmlspecialchars("Rec")."&nbsp;" ?></td>
<td class="dr"><?php echo htmlspecialchars($row["leave_profile_id"]) ?></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("System ID")."&nbsp;" ?></td>
<td class="dr"><?php echo htmlspecialchars($row["profile_id"]) ?></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Yearly Entitle")."&nbsp;" ?></td>
<td class="dr"><?php echo htmlspecialchars($row["yearly_entitle"]) ?></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Leave Type")."&nbsp;" ?></td>
<td class="dr"><?php echo get_leave_type($row["leave_type_id"]) ?></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Active")."&nbsp;" ?></td>
<td class="dr"><?php if ($row["active"]==1){echo "Yes";}else{echo "No";} ?></td>
</tr>
<tr><td colspan=2>&nbsp;</td></tr>
<tr>
<td class="hr">Date Created</td>
<td class="sr"><?php echo htmlspecialchars($row["date_created"]) ?></td>
</tr>
<tr>
<td class="hr">Created By</td>
<td class="sr"><?php echo get_author($row["created_by"]) ?></td>
</tr>
<tr>
<td class="hr">Date Modified</td>
<td class="sr"><?php echo htmlspecialchars($row["date_modified"]) ?></td>
</tr>
<tr>
<td class="hr">Modified By</td>
<td class="sr"><?php echo get_author($row["modified_by"]) ?></td>
</tr>
</table>
<?php } ?>

<?php function showroweditor($row, $iseditmode)
  {
  global $conn;
?>
<table class="tbl" border="0" cellspacing="1" cellpadding="5"width="50%">
<tr>
<td class="hr"><?php echo htmlspecialchars("ID")."&nbsp;" ?></td>
<td class="dr"><?php echo htmlspecialchars($row["leave_profile_id"]) ?></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Profile ID")."&nbsp;" ?></td>
<td class="dr"><?php echo htmlspecialchars($row["profile_id"]) ?></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Yearly Entitle")."&nbsp;" ?></td>
<td class="dr"><input class="input2" type="text" name="yearly_entitle" value="<?php echo str_replace('"', '&quot;', trim($row["yearly_entitle"])) ?>"></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Leave Type")."&nbsp;" ?></td>
<td class="dr"><?php set_leave_type("leave_type_id", $row["leave_type_id"]); ?> </td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Active")."&nbsp;" ?></td>
<td class="dr">
<select name="active" class="input2">
<option value="1" <?php if (1 == $row["active"]) { echo "selected"; } ?>>Yes</option>
<option value="0" <?php if (0 == $row["active"]) { echo "selected"; } ?>>No</option>
</select>
</td>
</tr>
<tr><td colspan=2>&nbsp;</td></tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Date Created")."&nbsp;" ?></td>
<td class="sr"><?php echo htmlspecialchars($row["date_created"]) ?></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Date Modified")."&nbsp;" ?></td>
<td class="sr"><?php echo htmlspecialchars($row["date_modified"]) ?></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Created By")."&nbsp;" ?></td>
<td class="sr"><?php echo htmlspecialchars(get_author($row["created_by"])) ?></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Modified By")."&nbsp;" ?></td>
<td class="sr"><?php echo htmlspecialchars(get_author($row["modified_by"])) ?></td>
</tr>
</table>
<input type="hidden" name="leave_profile_id" value="<?php echo str_replace('"', '&quot;', trim($row["leave_profile_id"])) ?>">
<input type="hidden" name="profile_id" value="<?php echo str_replace('"', '&quot;', trim($row["profile_id"])) ?>">
<input type="hidden" name="date_created" value="<?php echo str_replace('"', '&quot;', trim($row["date_created"])) ?>">
<input type="hidden" name="date_modified" value="<?php echo str_replace('"', '&quot;', trim($row["date_modified"])) ?>">
<input type="hidden" name="created_by" value="<?php echo str_replace('"', '&quot;', trim($row["created_by"])) ?>">
<input type="hidden" name="modified_by" value="<?php echo str_replace('"', '&quot;', trim($row["modified_by"])) ?>">
<?php } ?>

<?php function showpagenav($page, $pagecount)
{
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a2=add">Add Record</a>&nbsp;</td>
<?php if ($page > 1) { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page2=<?php echo $page - 1 ?>">&lt;&lt;&nbsp;Prev</a>&nbsp;</td>
<?php } ?>
<?php
  global $pagerange;

  if ($pagecount > 1) {

  if ($pagecount % $pagerange != 0) {
    $rangecount = intval($pagecount / $pagerange) + 1;
  }
  else {
    $rangecount = intval($pagecount / $pagerange);
  }
  for ($i = 1; $i < $rangecount + 1; $i++) {
    $startpage = (($i - 1) * $pagerange) + 1;
    $count = min($i * $pagerange, $pagecount);

    if ((($page >= $startpage) && ($page <= ($i * $pagerange)))) {
      for ($j = $startpage; $j < $count + 1; $j++) {
        if ($j == $page) {
?>
<td><b><?php echo $j ?></b></td>
<?php } else { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $j ?>"><?php echo $j ?></a></td>
<?php } } } else { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $startpage ?>"><?php echo $startpage ."..." .$count ?></a></td>
<?php } } } ?>
<?php if ($page < $pagecount) { ?>
<td>&nbsp;<a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $page + 1 ?>">Next&nbsp;&gt;&gt;</a>&nbsp;</td>
<?php } ?>
</tr>
</table>
<?php } ?>

<?php function showrecnav($a, $recid, $count)
{
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>">Index Page</a></td>
<?php if ($recid > 0) { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a2=<?php echo $a ?>&recid2=<?php echo $recid - 1 ?>">Prior Record</a></td>
<?php } if ($recid < $count - 1) { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a2=<?php echo $a ?>&recid2=<?php echo $recid + 1 ?>">Next Record</a></td>
<?php } ?>
</tr>
</table>
<hr size="1" color=#dcdbdb noshade>
<?php } ?>

<?php function addrec()
{
  global $id;
  global $filter;
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>">Index Page</a></td>
</tr>
</table>
<hr size="1" color=#dcdbdb noshade>  
<form enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p><input type="hidden" name="sql2" value="insert"></p>
<?php
$row = array(
  "leave_profile_id" => "",
  "profile_id" => $filter,
  "yearly_entitle" => "0",
  "leave_type_id" => "",
  "active" => "1",
  "date_created" => date("Y-m-d H:i:s"),
  "date_modified" => date("Y-m-d H:i:s"),
  "created_by" => $id,
  "modified_by" => $id);
showroweditor($row, false);
?>
<p><input type="submit" name="action" value="Post"></p>
</form>
<?php } ?>
<?php function editrec($recid)
{
  $res = sql_select();
  $count = sql_getrecordcount();
  mysql_data_seek($res, $recid);
  $row = mysql_fetch_assoc($res);
  showrecnav("edit", $recid, $count);
?>
<br>
<form enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" name="sql2" value="update">
<input type="hidden" name="xleave_profile_id" value="<?php echo $row["leave_profile_id"] ?>">
<?php showroweditor($row, true); ?>
<p><input type="submit" name="action" value="Post"></p>
</form>
<?php
  mysql_free_result($res);
} ?>

<?php function deleterec($recid)
{
  $res = sql_select();
  $count = sql_getrecordcount();
  mysql_data_seek($res, $recid);
  $row = mysql_fetch_assoc($res);
  showrecnav("del", $recid, $count);
?>
<br>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" name="sql2" value="delete">
<input type="hidden" name="xleave_profile_id" value="<?php echo $row["leave_profile_id"] ?>">
<?php showrow($row, $recid) ?>
<p><input type="submit" name="action" value="Confirm"></p>
</form>
<?php
  mysql_free_result($res);
}

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}

function sql_selectmain()
{
  global $conn;
  global $filter;
  global $filterfield;
  global $wholeonly;

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT * FROM (SELECT lp.leave_profile_id, lp.profile_id, lp.yearly_entitle, lt.leave_type_name, lp.active FROM leave_profile AS lp, leave_type AS lt where lt.leave_type_id =  lp.leave_type_id) subq";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where (`leave_profile_id` like '" .$filterstr ."') or (`profile_id` like '" .$filterstr ."') or (`yearly_entitle` like '" .$filterstr ."') or (`leave_type_name` like '" .$filterstr ."') or (`active` like '" .$filterstr ."')";
  }
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}

function sql_getrecordcountmain()
{
  global $conn;
  global $filter;
  global $filterfield;
  global $wholeonly;

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT COUNT(*) FROM (SELECT lp.leave_profile_id, lp.profile_id, lp.yearly_entitle, lt.leave_type_name, lp.active FROM leave_profile AS lp, leave_type AS lt where lt.leave_type_id =  lp.leave_type_id) subq";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where (`leave_profile_id` like '" .$filterstr ."') or (`profile_id` like '" .$filterstr ."') or (`yearly_entitle` like '" .$filterstr ."') or (`leave_type_name` like '" .$filterstr ."') or (`active` like '" .$filterstr ."')";
  }
  $res = mysql_query($sql, $conn) or die(mysql_error());
  $row = mysql_fetch_assoc($res);
  reset($row);
  return current($row);
}

function sql_select()
{
  global $conn;
  global $filter;
  global $filterfield;
  global $wholeonly;

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT `leave_profile_id`, `profile_id`, `yearly_entitle`, `leave_type_id`, `active`, `date_created`, `date_modified`, `created_by`, `modified_by` FROM `leave_profile`";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where (`leave_profile_id` like '" .$filterstr ."') or (`profile_id` like '" .$filterstr ."') or (`yearly_entitle` like '" .$filterstr ."') or (`leave_type_id` like '" .$filterstr ."') or (`active` like '" .$filterstr ."')";
  }
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}

function sql_getrecordcount()
{
  global $conn;
  global $filter;
  global $filterfield;
  global $wholeonly;

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT COUNT(*) FROM `leave_profile`";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where (`leave_profile_id` like '" .$filterstr ."') or (`profile_id` like '" .$filterstr ."') or (`yearly_entitle` like '" .$filterstr ."') or (`leave_type_id` like '" .$filterstr ."') or (`active` like '" .$filterstr ."')";
  }
  $res = mysql_query($sql, $conn) or die(mysql_error());
  $row = mysql_fetch_assoc($res);
  reset($row);
  return current($row);
}

function sql_insert()
{
  global $conn;
  global $_POST;

  $sql = "insert into `leave_profile` (`leave_profile_id`, `profile_id`, `yearly_entitle`, `leave_type_id`, `active`, `date_created`, `date_modified`, `created_by`, `modified_by`) values (" .sqlvalue(@$_POST["leave_profile_id"], false).", " .sqlvalue(@$_POST["profile_id"], false).", " .sqlvalue(@$_POST["yearly_entitle"], false).", " .sqlvalue(@$_POST["leave_type_id"], false).", " .sqlvalue(@$_POST["active"], false).", " .sqlvalue(@$_POST["date_created"], true).", " .sqlvalue(@$_POST["date_modified"], true).", " .sqlvalue(@$_POST["created_by"], false).", " .sqlvalue(@$_POST["modified_by"], false).")";
  mysql_query($sql, $conn) or die(mysql_error());
}

function sql_update()
{
  global $conn;
  global $_POST;
  global $id;

  $sql = "update `leave_profile` set `leave_profile_id`=" .sqlvalue(@$_POST["leave_profile_id"], false).", `profile_id`=" .sqlvalue(@$_POST["profile_id"], false).", `yearly_entitle`=" .sqlvalue(@$_POST["yearly_entitle"], false).", `leave_type_id`=" .sqlvalue(@$_POST["leave_type_id"], false).", `active`=" .sqlvalue(@$_POST["active"], false).", `date_created`=" .sqlvalue(@$_POST["date_created"], true).", `date_modified`=" .sqlvalue(date("Y-m-d H:i:s"), true).", `created_by`=" .sqlvalue(@$_POST["created_by"], false).", `modified_by`=" .sqlvalue($id, false) ." where " .primarykeycondition();
  mysql_query($sql, $conn) or die(mysql_error());
}

function sql_delete()
{
  global $conn;

  $sql = "delete from `leave_profile` where " .primarykeycondition();
  mysql_query($sql, $conn) or die(mysql_error());
}
function primarykeycondition()
{
  global $_POST;
  $pk = "";
  $pk .= "(`leave_profile_id`";
  if (@$_POST["xleave_profile_id"] == "") {
    $pk .= " IS NULL";
  }else{
  $pk .= " = " .sqlvalue(@$_POST["xleave_profile_id"], false);
  };
  $pk .= ")";
  return $pk;
}
 ?>

 <?php
//************************************************************************************************************************************************
//  MY MODULE
//************************************************************************************************************************************************
function get_author($id)
{
	global $conn;

	$sql = "SELECT `name` FROM `profile` WHERE `profile_id` = ".$id;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["name"];
	}
}

function get_leave_type($leave_type_id)
{
	global $conn;

	$sql = "SELECT `leave_type_name` FROM `leave_type` WHERE `leave_type_id` = ".$leave_type_id;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["leave_type_name"];
	}
}

function set_leave_type($name, $idvalue)
{
	global $conn;

	$sql = "SELECT * FROM `leave_type`";
	$res = mysql_query($sql, $conn) or die(mysql_error());?>
	<select name="<?php echo $name ?>" class="input2">
	<option value=""></option>
	<?php while($row = mysql_fetch_array($res))
	{?>
	<option value="<?php echo $row["leave_type_id"] ?>" <?php if ($idvalue == $row["leave_type_id"]) { echo "selected"; } ?>><?php echo $row["leave_type_id"]." - ".$row["leave_type_name"]?></option>
	<?php } ?>
	</select><?php
	 mysql_free_result($res);
}
?>
