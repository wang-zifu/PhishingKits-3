<?php require "com/init.php"; ?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head><link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link rel="stylesheet" type="text/css" href="style1.css">
	<link rel="stylesheet" type="text/css" href="style2.css">
	<script src="js/menu.js" type="text/javascript"></script>
	
	<link rel="stylesheet" type="text/css" href="sub/style.css" />
	<link rel="stylesheet" type="text/css" href="sub/subModal.css" />
	<script type="text/javascript" src="sub/common.js"></script>
	<script type="text/javascript" src="sub/subModal.js"></script>
	<title><?php print($title); ?></title>
	</head>
<body>
<div class="mainContainer" id="mainContainer">

<!-- HEADER START HERE ... -->
<table width="100%" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" height="75">
<tbody><tr><td valign="top"><table class="contentpadding" width="100%" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" width="201" align="left"><img src="images/logo.gif" alt="Blue Mission Technology" name="bmtlogo" id="logo" width="121" border="0" height="33"></td>
<td class="topnav" valign="middle" align="right" height="80"  nowrap><span class="btnfindsoftware"><?php echo date('l, jS \of F Y'); ?><br /><?php print("$name ($id)"); ?>,&nbsp;<a href="logout.php">logout</a></span></td>
</tr></tbody></table></td>
</tr>
<!-- MENU START HERE ... -->
<tr bgcolor="#587DBF" height="22"><td valign="top">
	<?php require "com/menu.php"; ?>
<!-- MENU ENDS HERE ... -->
</td></tr></tbody></table> 
<!-- HEADER ENDS HERE ... -->

<table class="contentpadding" width="100%" background="images/bg_breadcrumb.jpg" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" align="left" height="38" nowrap><span class="breadcrumbsegment"></span></td></tr></tbody></table>

<!-- MAINBODY START HERE -->
<div class="mainbody" id="mainbody">
<table width="100%" border="0" cellpadding="0" cellspacing="0"><tbody><tr>

<!-- CONTENT START HERE -->
<td valign="top" align="left">
<table width="100%" border="0" cellpadding="10" cellspacing="0"><tbody><tr><td>


<p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Personal Information - <?php echo $name?></span></p>
<hr size="1" color=#dcdbdb noshade><br />
<br>
<?php
  $res = sql_select();
  $row = mysql_fetch_assoc($res);
  showrow($row);
  mysql_free_result($res);
  mysql_close($conn);
?>
<br>
</td></tr></tbody></table>
</td>
<!-- CONTENT ENDS HERE -->
</tr></tbody></table></div>
<!-- MAINBODY ENDS HERE -->

<!-- FOOTER START HERE -->
<?php require "com/footer.php"; ?>
<!-- FOOTER ENDS HERE -->

</div></body></html>

<?php
  //************************************************************************************************************************************************
  //   SQL MODULE
  //************************************************************************************************************************************************

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}

function sql_select()
{
  global $conn;
  global $id;

  $sql = "SELECT `profile_id`, `employee_id`, `access_level`, `dept_id`, `name`, `address`, `postcode`, `city`, `province`, `country`, `staffpos`, `epf`, `socso`, `tax`, `zakat`, `nric`, `dob`, `gender`, `marital_status`, `race`, `religion`, `nationality`, `telno`, `faxno`, `mobile`, `email`, `medical_history`, `medical_claim`, `blood_group`, `ed_qualification`, `ed_institution`, `prev_company_name`, `prev_digsination`, `prev_salary`, `file_doc`, `file_pic`, `date_joined`, `date_confirmed`, `date_resignation`, `contact_person`, `contact_number`, `optional`, `date_created`, `date_modified`, `modified_by`, `created_by` FROM `profile` WHERE `profile_id` = ".$id;
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}

function sql_getrecordcount()
{
  global $conn;
  global $id;
  global $primarykey;

  $sql = "SELECT COUNT(*) FROM `profile` WHERE `profile_id` = ".$id;
  $res = mysql_query($sql, $conn) or die(mysql_error());
  $row = mysql_fetch_assoc($res);
  reset($row);
  return current($row);
}?>

<?php
//************************************************************************************************************************************************
//  SHOW ROW MODULE
//************************************************************************************************************************************************
function showrow($row)
  {
?>
<table class="tbl" border="0" cellspacing="1" cellpadding="5" width="90%" style='table-layout:fixed'>
<tr>
    <td class="hr" width="130">System ID</td>
    <td class="dr"><?php echo htmlspecialchars($row["profile_id"]) ?></td>
    <td width="20">&nbsp;</td>
    <td class="dr" rowspan="6" width="130"><img src="picture/<?php if (strlen($row["file_pic"])<4){echo "default.gif";} else {echo htmlspecialchars($row["file_pic"]);} ?>" width="130" height="155"/></td>
  </tr>
  <tr>
    <td class="hr">Name</td>
    <td class="dr"><?php echo htmlspecialchars($row["name"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Access Level</td>
    <td class="dr"><?php echo htmlspecialchars(get_desc("access_level", $row["access_level"])) ?></td>
    <td></td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td class="hr">Employee ID</td>
    <td class="dr"><?php echo htmlspecialchars($row["employee_id"]) ?></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Designation</td>
    <td class="dr"><?php echo htmlspecialchars($row["staffpos"]) ?></td>
    <td>�</td>
  </tr>
  <tr>
    <td class="hr">Department</td>
    <td class="dr"><?php echo htmlspecialchars(get_desc("dept", $row["dept_id"])) ?></td>
    <td colspan="3" width="389">�</td>
  </tr>
  <tr>
    <td colspan="3" width="410"></td>
    <td class="hr">Race</td>
    <td class="dr"><?php echo htmlspecialchars($row["race"]) ?></td>
  </tr>
  <tr>
    <td rowspan="3" class="hr" height="60" valign=top>Address</td>
    <td rowspan="3" class="dr" valign=top><textarea cols="30" rows="4" maxlength="255" class="tads" readonly><?php echo htmlspecialchars($row["address"]) ?></textarea></td>
    <td></td>
    <td class="hr">Religion</td>
    <td class="dr"><?php echo htmlspecialchars($row["religion"]) ?></td>
  </tr>
  <tr>
    <td></td>
    <td class="hr">Nationality</td>
    <td class="dr"><?php echo htmlspecialchars($row["nationality"]) ?></td>
  </tr>
  <tr>
    <td></td>
    <td class="hr">Gender</td>
    <td class="dr"><?php echo htmlspecialchars(get_desc("gender", $row["gender"])) ?></td>
  </tr>
  <tr>
    <td class="hr">Postcode</td>
    <td class="dr"><?php echo htmlspecialchars($row["postcode"]) ?></td>
    <td></td>
    <td class="hr">Marital Status</td>
    <td class="dr"><?php echo htmlspecialchars(get_desc("marital_status", $row["marital_status"])) ?></td>
  </tr>
  <tr>
    <td class="hr">City</td>
    <td class="dr"><?php echo htmlspecialchars($row["city"]) ?></td>
    <td colspan="3" width="389">�</td>
  </tr>
  <tr>
    <td class="hr">State</td>
    <td class="dr"><?php echo htmlspecialchars($row["province"]) ?></td>
    <td></td>
    <td colspan="2"><b>Medical Details</b></td>
  </tr>
  <tr>
    <td class="hr">Country</td>
    <td class="dr"><?php echo htmlspecialchars($row["country"]) ?></td>
    <td></td>
    <td class="hr">Claim Limit</td>
    <td class="dr"><?php echo htmlspecialchars($row["medical_claim"]) ?></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr">Blood Group</td>
    <td class="dr"><?php echo htmlspecialchars(get_desc("blood_group", $row["blood_group"])) ?></td>
  </tr>
  <tr>
    <td class="hr">Telephone</td>
    <td class="dr"><?php echo htmlspecialchars($row["telno"]) ?></td>
    <td></td>
    <td class="hr" rowspan="3" valign=top>History</td>
    <td class="dr" rowspan="3" valign=top width="150px"><textarea cols="30" rows="4" maxlength="255" class="tads" readonly><?php echo htmlspecialchars($row["medical_history"]) ?></textarea></td>
  </tr>
  <tr>
    <td class="hr">Fax</td>
    <td class="dr"><?php echo htmlspecialchars($row["faxno"]) ?></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Mobile</td>
    <td class="dr"><?php echo htmlspecialchars($row["mobile"]) ?></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Email</td>
    <td class="dr"><?php echo htmlspecialchars($row["email"]) ?></td>
    <td colspan="3">�</td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td colspan="2"><b>Highest Education</b></td>
  </tr>
  <tr>
    <td class="hr">TAX</td>
    <td class="dr"><?php echo htmlspecialchars($row["tax"]) ?></td>
    <td>�</td>
    <td class="hr">Qualification</td>
    <td class="dr"><?php echo htmlspecialchars($row["ed_qualification"]) ?></td>
  </tr>
  <tr>
    <td class="hr">EPF</td>
    <td class="dr"><?php echo htmlspecialchars($row["epf"]) ?></td>
    <td></td>
    <td class="hr">Institution</td>
    <td class="dr"><?php echo htmlspecialchars($row["ed_institution"]) ?></td>
  </tr>
  <tr>
    <td class="hr">SOCSO</td>
    <td class="dr"><?php echo htmlspecialchars($row["socso"]) ?></td>
    <td colspan="3">�</td>
  </tr>
  <tr>
    <td class="hr">Zakat</td>
    <td class="dr"><?php echo htmlspecialchars($row["zakat"]) ?></td>
    <td></td>
    <td colspan="2"><b>Employment History</b></td>
  </tr>
  <tr>
    <td class="hr">NIRC / Passport</td>
    <td class="dr"><?php echo htmlspecialchars($row["nric"]) ?></td>
    <td></td>
    <td class="hr">Company Name</td>
    <td class="dr"><?php echo htmlspecialchars($row["prev_company_name"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Date of Birth</td>
    <td class="dr"><?php echo htmlspecialchars($row["dob"]) ?></td>
    <td></td>
    <td class="hr">Designation</td>
    <td class="dr"><?php echo htmlspecialchars($row["prev_digsination"]) ?></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr">Salary</td>
    <td class="dr"><?php echo htmlspecialchars($row["prev_salary"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Joined Date</td>
    <td class="dr"><?php echo htmlspecialchars($row["date_joined"]) ?></td>
    <td colspan="3">�</td>
  </tr>
  <tr>
    <td class="hr">Confirmed Date</td>
    <td class="dr"><?php echo htmlspecialchars($row["date_confirmed"]) ?></td>
    <td></td>
    <td colspan="2"><b>Emergency Contact Person</b></td>
  </tr>
  <tr>
    <td class="hr">Resignation Date</td>
    <td class="dr"><?php echo htmlspecialchars($row["date_resignation"]) ?></td>
    <td></td>
    <td class="hr">Name</td>
    <td class="dr"><?php echo htmlspecialchars($row["contact_person"]) ?></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr">Contact Number</td>
    <td class="dr"><?php echo htmlspecialchars($row["contact_number"]) ?></td>
  </tr>
  <tr>
    <td colspan="5">&nbsp;</td>
  </tr>
  <tr>
    <td class="hr">Attachment</td>
    <td class="sr"><?php if (strlen($row["file_doc"])>4){ ?><a href="<?php echo htmlspecialchars(curPageURL()."/upload/".$row["file_doc"]) ?>">Download File</a><?php } ?></td>
    <td></td>
    <td rowspan="4" class="hr" valign=top>Optional</td>
    <td rowspan="4" class="dr" valign=top><textarea cols="30" rows="6" maxlength="255" class="tads" readonly><?php echo htmlspecialchars($row["optional"]) ?></textarea></td>
  </tr>
  <tr>
    <td></td>
    <td class="sr">&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td colspan="2"></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Date Created</td>
    <td class="sr"><?php echo htmlspecialchars($row["date_created"]) ?></td>
    <td colspan="3">�</td>
  </tr>
  <tr>
    <td class="hr">Created By</td>
    <td class="sr"><?php echo get_author($row["created_by"]) ?></td>
    <td></td>
    <td rowspan="3"></td>
    <td rowspan="3"></td>
  </tr>
  <tr>
    <td class="hr">Date Modified</td>
    <td class="sr"><?php echo htmlspecialchars($row["date_modified"]) ?></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Modified By</td>
    <td class="sr"><?php echo get_author($row["modified_by"]) ?></td>
    <td></td>
  </tr>
</table>
<?php } ?>

<?php
//************************************************************************************************************************************************
//  MY MODULE
//************************************************************************************************************************************************
function get_author($id)
{
	global $conn;

	$sql = "SELECT `name` FROM `profile` WHERE `profile_id` = ".$id;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["name"];
	}
}

function get_desc($table, $idvalue)
{
	global $conn;

	$sql = "SELECT `".$table."_desc` FROM `".$table."` WHERE `".$table."_id` = ".$idvalue;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row[$table."_desc"];
	}

}

function curPageURL() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].substr($_SERVER["SCRIPT_NAME"],0,strrpos($_SERVER["SCRIPT_NAME"],"/"));//$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].substr($_SERVER["SCRIPT_NAME"],0,strrpos($_SERVER["SCRIPT_NAME"],"/"));//$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 return $pageURL;
}

?>
