<?php
require "com/init.php";

if (isset($_POST["a"])) $a = @$_POST["a"];
//if (isset($_GET["a"])) $a = @$_GET["a"];

switch ($a) {
   case "dept":
    sql_dept();
    break;
   case "pfile":
    sql_profile();
    break;
}

function sql_dept()
{
  global $conn;
  $sql = "SELECT * FROM dept WHERE dept_id <> 1 ORDER BY dept_id ASC";
  $res = mysql_query($sql, $conn) or die(mysql_error());
  while($row = mysql_fetch_array($res))
  {
    $returnstr .=  ";".$row["dept_id"]."~".$row["dept_desc"];
  }
  echo $returnstr;
  return;
}

function sql_profile()
{
  global $conn;
  $sql = "SELECT * FROM profile WHERE profile_id <> 999 ORDER BY profile_id ASC";
  $res = mysql_query($sql, $conn) or die(mysql_error());
  $returnstr = "";
  while($row = mysql_fetch_array($res))
  {
    $returnstr .=  ";".$row["profile_id"]."~".$row["name"];
  }
  echo $returnstr;
  return;
}
?>


