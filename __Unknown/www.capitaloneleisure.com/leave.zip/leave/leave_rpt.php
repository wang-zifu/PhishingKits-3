<?php require "com/init1.php"; ?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head><link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link rel="stylesheet" type="text/css" href="style1.css">
	<link rel="stylesheet" type="text/css" href="style5.css">
	<script src="js/menu.js" type="text/javascript"></script>
    <?php
    if (isset($_POST["filter"]))
    {echo "<script> var filter = ".$_POST["filter"].";</script>"; }
    else
    {
      if (isset($_SESSION["filter"]))
      {echo "<script> var filter = ".@$_SESSION["filter"].";</script>"; }
       else
      {echo "<script> var filter = -1;</script>"; }
    }
    ?>
	<link rel="stylesheet" type="text/css" href="sub/style.css" />
	<link rel="stylesheet" type="text/css" href="sub/subModal.css" />
	<script type="text/javascript" src="sub/common.js"></script>
	<script type="text/javascript" src="sub/subModal.js"></script>
	<title><?php print($title); ?></title>
	</head>
<?php
  if (isset($_GET["a"])) $a = @$_GET["a"];
  if (isset($_GET["order"])) $order = @$_GET["order"];
  if (isset($_GET["type"])) $ordtype = @$_GET["type"];
  if (isset($_GET["year"])) $year = @$_GET["year"];
  if (isset($_GET["month"])) $month = @$_GET["month"];
  if (isset($_GET["day"])) $day = @$_GET["day"];

  if (isset($_POST["filter"])) $filter = @$_POST["filter"];
  if (isset($_POST["filter2"])) $filter2 = @$_POST["filter2"];
  if (isset($_POST["filter_field"])) $filterfield = @$_POST["filter_field"];

  if (!isset($a) && isset($_SESSION["a"])) $a = $_SESSION["a"];
  if (!isset($order) && isset($_SESSION["order"])) $order = $_SESSION["order"];
  if (!isset($year) && isset($_SESSION["year"])) $year = $_SESSION["year"];
  if (!isset($month) && isset($_SESSION["month"])) $month = $_SESSION["month"];
  if (!isset($day) && isset($_SESSION["day"])) $day = $_SESSION["day"];
  if (!isset($ordtype) && isset($_SESSION["type"])) $ordtype = $_SESSION["type"];
  if (!isset($filter) && isset($_SESSION["filter"])) $filter = $_SESSION["filter"];
  if (!isset($filter2) && isset($_SESSION["filter2"])) $filter2 = $_SESSION["filter2"];
  if (!isset($filterfield) && isset($_SESSION["filter_field"])) $filterfield = $_SESSION["filter_field"];
?>

<body>
<div class="mainContainer" id="mainContainer">

<!-- HEADER START HERE ... -->
<table width="100%" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" height="75">
<tbody><tr><td valign="top"><table class="contentpadding" width="100%" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" width="201" align="left"><img src="images/logo.gif" alt="Blue Mission Technology" name="bmtlogo" id="logo" width="121" border="0" height="33"></td>
<td class="topnav" valign="middle" align="right" height="80"  nowrap><span class="btnfindsoftware"><?php echo date('l, jS \of F Y'); ?><br /><?php print("$name ($id)"); ?>,&nbsp;<a href="logout.php">logout</a></span></td>
</tr></tbody></table></td>
</tr>
<!-- MENU START HERE ... -->
<tr bgcolor="#587DBF" height="22"><td valign="top">
	<?php require "com/menu.php"; ?>
<!-- MENU ENDS HERE ... -->
</td></tr></tbody></table> 
<!-- HEADER ENDS HERE ... -->

<table class="contentpadding" width="100%" background="images/bg_breadcrumb.jpg" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" align="left" height="38" nowrap><span class="breadcrumbsegment"></span></td></tr></tbody></table>

<!-- MAINBODY START HERE -->
<div class="mainbody" id="mainbody">
<table width="100%" border="0" cellpadding="0" cellspacing="0"><tbody><tr>

<!-- CONTENT START HERE -->
<td valign="top" align="left">
<table width="100%" border="0" cellpadding="10" cellspacing="0"><tbody><tr><td>


<p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Leave Applications Reports</span></p><br />

<?php
  $conn = connect();
  $showrecs = 25;
  $pagerange = 10;
  $page = @$_GET["page"];
  if (!isset($page)) $page = 1;

  if ($a == "reset") {
    $filter = "";
    $filter2 = "";
    $filterfield = "";
    $order = "";
    $ordtype = "";
  }

   switch ($a) {
     case "emp":
      select($a);
      break;
     case "day":
      select($a);
      break;
    case "month":
      select($a);
      break;
    default:
      select("year");
      break;
  }

  if (isset($a)) $_SESSION["a"] = $a;
  if (isset($order)) $_SESSION["order"] = $order;
  if (isset($year)) $_SESSION["year"] = $year;
  if (isset($month)) $_SESSION["month"] = $month;
  if (isset($day)) $_SESSION["day"] = $day;
  if (isset($ordtype)) $_SESSION["type"] = $ordtype;
  if (isset($filter)) $_SESSION["filter"] = $filter;
  if (isset($filter2)) $_SESSION["filter2"] = $filter2;
  if (isset($filterfield)) $_SESSION["filter_field"] = $filterfield;
  if (isset($wholeonly)) $_SESSION["wholeonly"] = $wholeonly;

  mysql_close($conn);
?>
</td></tr></tbody></table>
</td>
<!-- CONTENT ENDS HERE -->
</tr></tbody></table></div>
<!-- MAINBODY ENDS HERE -->

<!-- FOOTER START HERE -->
<?php require "com/footer.php"; ?>
<!-- FOOTER ENDS HERE -->

</div></body></html>

<?php function select($choice)
  {
  global $a;
  global $showrecs;
  global $page;
  global $filter;
  global $filter2;
  global $filterfield;
  global $wholeonly;
  global $order;
  global $ordtype;
  global $year;
  global $month;
  global $day;

  $a = $choice;

  $checkstr = "";
  if ($wholeonly) $checkstr = " checked";
  if ($ordtype == "asc") { $ordtypestr = "desc"; } else { $ordtypestr = "asc"; }
  $res = sql_select($a);
  $count = sql_getrecordcount($a);
  if ($count % $showrecs != 0) {
    $pagecount = intval($count / $showrecs) + 1;
  }
  else {
    $pagecount = intval($count / $showrecs);
  }
  $startrec = $showrecs * ($page - 1);
  if ($startrec < $count) {mysql_data_seek($res, $startrec);}
  $reccount = min($showrecs * $page, $count);
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr><td>Records shown <?php echo $startrec + 1 ?> - <?php echo $reccount ?> of <?php echo $count ?></td></tr>
</table>
<hr size="1" color=#dcdbdb noshade>
<form name="rpt" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><b>Find</b>&nbsp;</td>
<td width="200px"><select class="input2" name="filter"></select></td>
<td><select class="input2" name="filter_field" onchange="setInterface()">
<option value="">All Records</option>
<option value="<?php echo "p.dept_id" ?>"<?php if ($filterfield == "p.dept_id") { echo "selected"; } ?>><?php echo htmlspecialchars("Department") ?></option>
<option value="<?php echo "p.profile_id" ?>"<?php if ($filterfield == "p.profile_id") { echo "selected"; } ?>><?php echo htmlspecialchars("Employee") ?></option>
</select></td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td><input type="submit" name="action" value="Search"></td>
<td><?php set_leave_option($filter2);?></td>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=reset">Reset</a>&nbsp;/&nbsp;
<a href="ext/leapprpt.php?a=<?php echo $a; ?>&year=<?php echo $year; ?>&month=<?php echo $month; ?>&day=<?php echo $day; ?>&filter2=<?php echo $filter2; ?>&order=<?php echo $order; ?>&type=<?php echo $ordtype; ?>&filter=<?php echo $filter; ?>&filter_field=<?php echo $filterfield; ?>">Export Result</a>
</td></tr>
</table>
</form>
<script type="text/javascript" src="js/rpt.js"></script>
<hr size="1" color=#dcdbdb noshade>
<font class="nav">&nbsp;<b>Current View:</b>&nbsp;
<?php
switch ($a) {
case "emp":
    ?><a class="nav" href="<?php echo $_SERVER['PHP_SELF']; ?>?a=year&order=&type=">Year (<?php echo $year ?>)</a> > <a class="nav" href="<?php echo $_SERVER['PHP_SELF']; ?>?a=month&order=&type="> Month (<?php echo $month ?>)</a> > <a class="nav" href="<?php echo $_SERVER['PHP_SELF']; ?>?a=day&order=&type="> Day (<?php echo $day ?>)</a> > Details<?php
    break;
case "day":
    ?><a class="nav" href="<?php echo $_SERVER['PHP_SELF']; ?>?a=year&order=&type=">Year (<?php echo $year ?>)</a> > <a class="nav" href="<?php echo $_SERVER['PHP_SELF']; ?>?a=month&order=&type="> Month (<?php echo $month ?>)</a> > Day <?php
    break;
case "month":
    ?><a class="nav" href="<?php echo $_SERVER['PHP_SELF']; ?>?a=year&order=&type=">Year (<?php echo $year ?>)</a> > Month<?php
    break;
default:
    ?>Year<?php
    break;
}?>
</font>
<br><br>
<?php showpagenav($page, $pagecount); ?><br>
<table class="tbl" border="0" cellspacing="1" cellpadding="5"width="100%">
<tr>
<?php
switch ($a) {
case "emp":
    ?><td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "profile_id" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("System ID") ?></a></td>
    <td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "name" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Name") ?></a></td><?php
    break;
case "day":
    ?><td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "day_select" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Day") ?></a></td><?php
    break;
case "month":
    ?><td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "month_select" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Month") ?></a></td><?php
    break;
default:
    ?><td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "year_select" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Year") ?></a></td><?php
    break;
}?>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "waiting" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Pending") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "waiting_period" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Period(s)") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "approve" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Approve") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "approve_period" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Period(s)") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "reject" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Reject") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "reject_period" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Period(s)") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "cancel" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Cancel") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "cancel_period" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Period(s)") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "total_aplication" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Total Application") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "total_period" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Total Period(s)") ?></a></td>
</tr>
<?php
  for ($i = $startrec; $i < $reccount; $i++)
  {
    $row = mysql_fetch_assoc($res);
    $style = "dr";
    if ($i % 2 != 0) {
      $style = "sr";
    }
?>
<tr>
<?php
switch ($a) {
case "emp":
    ?><td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["profile_id"]) ?></td>
    <td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["name"]) ?></td><?php
    break;
case "day":
    ?><td class="<?php echo $style ?>"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=emp&day=<?php echo $row["day_select"] ?>&order=&type="><?php echo htmlspecialchars($row["day_select"]) ?></a></td><?php
    break;
case "month":
    ?><td class="<?php echo $style ?>"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=day&month=<?php echo $row["month_select"] ?>&order=&type="><?php echo htmlspecialchars($row["month_select"]) ?></a></td><?php
    break;
default:
    ?><td class="<?php echo $style ?>"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=month&year=<?php echo $row["year_select"] ?>&order=&type="><?php echo htmlspecialchars($row["year_select"]) ?></a></td><?php
    break;
}?>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["waiting"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["waiting_period"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["approve"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["approve_period"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["reject"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["reject_period"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["cancel"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["cancel_period"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["total_aplication"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["total_period"]) ?></td>
</tr>
<?php
  }
  mysql_free_result($res);
?>
</table>
<br>
<?php showpagenav($page, $pagecount); ?>
<?php }


function showpagenav($page, $pagecount)
{
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<?php if ($page > 1) { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $page - 1 ?>">&lt;&lt;&nbsp;Prev</a>&nbsp;</td>
<?php } ?>
<?php
  global $pagerange;

  if ($pagecount > 1) {

  if ($pagecount % $pagerange != 0) {
    $rangecount = intval($pagecount / $pagerange) + 1;
  }
  else {
    $rangecount = intval($pagecount / $pagerange);
  }
  for ($i = 1; $i < $rangecount + 1; $i++) {
    $startpage = (($i - 1) * $pagerange) + 1;
    $count = min($i * $pagerange, $pagecount);

    if ((($page >= $startpage) && ($page <= ($i * $pagerange)))) {
      for ($j = $startpage; $j < $count + 1; $j++) {
        if ($j == $page) {
?>
<td><b><?php echo $j ?></b></td>
<?php } else { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $j ?>"><?php echo $j ?></a></td>
<?php } } } else { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $startpage ?>"><?php echo $startpage ."..." .$count ?></a></td>
<?php } } } ?>
<?php if ($page < $pagecount) { ?>
<td>&nbsp;<a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $page + 1 ?>">Next&nbsp;&gt;&gt;</a>&nbsp;</td>
<?php } ?>
</tr>
</table>
<?php }

function sqlstr($val)
{
  return str_replace("'", htmlspecialchars("'"), $val);
}

function sql_select($a)
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filter2;
  global $filterfield;
  global $year;
  global $month;
  global $day;

  switch ($a) {
     case "emp":
      $front = "p.profile_id, p.name, ";
      $mid = " AND YEAR(l.date_from) = ".sqlstr($year)."
             AND MONTH(l.date_from) = ".sqlstr($month)."
             AND DAY(l.date_from) = ".sqlstr($day);
      $back = " GROUP BY p.profile_id) subq";
      break;
     case "day":
      $front = "DAY(l.date_from) AS day_select, ";
      $mid = " AND YEAR(l.date_from) = ".sqlstr($year)."
             AND MONTH(l.date_from) = ".sqlstr($month);
      $back = " GROUP BY DAY(l.date_from)) subq";
      break;
    case "month":
      $front = "MONTH(l.date_from) AS month_select, ";
      $mid = " AND YEAR(l.date_from) = ".sqlstr($year);
      $back = " GROUP BY MONTH(l.date_from)) subq";
      break;
    default:
      $front = "YEAR(l.date_from) AS year_select, ";
      $mid = "";
      $back = " GROUP BY YEAR(l.date_from)) subq";
      break;
  }

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT * FROM (SELECT ";
  $sql .= $front;
  $sql .= "Sum(if(l.indicator = 0 ,1,0)) AS waiting, Sum(if(l.indicator = 0 ,l.period,0)) AS waiting_period,
  Sum(if(l.indicator = 1 ,1,0)) AS approve, Sum(if(l.indicator = 1 ,l.period,0)) AS approve_period,
  Sum(if(l.indicator = 3 ,1,0)) AS reject, Sum(if(l.indicator = 3 ,l.period,0)) AS reject_period,
  Sum(if(l.indicator = 2 ,1,0)) AS cancel, Sum(if(l.indicator = 2 ,l.period,0)) AS cancel_period,
  Sum(1) AS total_aplication, Sum(l.period) AS total_period
  FROM leave_dat AS l ,  profile AS p
  WHERE p.profile_id =  l.profile_id
  AND l.indicator < 4";
  $sql .= $mid;
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " AND ".$filterfield." = ".$filter;
  }
  if (isset($filter2) && $filter2!='') {
    $sql .= " AND l.leave_type_id = ".$filter2;
  }
  $sql .= $back;

  if (isset($order) && $order!='') $sql .= " order by `" .sqlstr($order) ."`";
  if (isset($ordtype) && $ordtype!='') $sql .= " " .sqlstr($ordtype);
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}

function sql_getrecordcount($a)
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filter2;
  global $filterfield;
  global $year;
  global $month;
  global $day;

  switch ($a) {
     case "emp":
      $front = "p.profile_id, p.name, ";
      $mid = " AND YEAR(l.date_from) = ".sqlstr($year)."
             AND MONTH(l.date_from) = ".sqlstr($month)."
             AND DAY(l.date_from) = ".sqlstr($day);
      $back = " GROUP BY p.profile_id) subq";
      break;
     case "day":
      $front = "DAY(l.date_from) AS day_select, ";
      $mid = " AND YEAR(l.date_from) = ".sqlstr($year)."
             AND MONTH(l.date_from) = ".sqlstr($month);
      $back = " GROUP BY DAY(l.date_from)) subq";
      break;
    case "month":
      $front = "MONTH(l.date_from) AS month_select, ";
      $mid = " AND YEAR(l.date_from) = ".sqlstr($year);
      $back = " GROUP BY MONTH(l.date_from)) subq";
      break;
    default:
      $front = "YEAR(l.date_from) AS year_select, ";
      $mid = "";
      $back = " GROUP BY YEAR(l.date_from)) subq";
      break;
  }

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT COUNT(*) FROM (SELECT ";
  $sql .= $front;
  $sql .= "Sum(if(l.indicator = 0 ,1,0)) AS waiting, Sum(if(l.indicator = 0 ,l.period,0)) AS waiting_period,
  Sum(if(l.indicator = 1 ,1,0)) AS approve, Sum(if(l.indicator = 1 ,l.period,0)) AS approve_period,
  Sum(if(l.indicator = 3 ,1,0)) AS reject, Sum(if(l.indicator = 3 ,l.period,0)) AS reject_period,
  Sum(if(l.indicator = 2 ,1,0)) AS cancel, Sum(if(l.indicator = 2 ,l.period,0)) AS cancel_period,
  Sum(1) AS total_aplication, Sum(l.period) AS total_period
  FROM leave_dat AS l ,  profile AS p
  WHERE p.profile_id =  l.profile_id
  AND l.indicator < 4";
  $sql .= $mid;
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " AND ".$filterfield." = ".$filter;
  }
  if (isset($filter2) && $filter2!='') {
    $sql .= " AND l.leave_type_id = ".$filter2;
  }
  $sql .= $back;

  $res = mysql_query($sql, $conn) or die(mysql_error());
  $row = mysql_fetch_assoc($res);
  reset($row);
  return current($row);
}

function set_leave_option($idvalue)
{
	global $conn;

	$sql = "SELECT * FROM `leave_type`";
	$res = mysql_query($sql, $conn) or die(mysql_error());?>
	<select name="filter2" class="input2">
    <option value="">All Leave</option>
	<?php while($row = mysql_fetch_array($res))
	{?>
	<option value="<?php echo $row["leave_type_id"] ?>" <?php if ($idvalue == $row["leave_type_id"]) { echo "selected"; } ?>><?php echo $row["leave_type_name"] ?></option>
	<?php } ?>
	</select><?php
	 mysql_free_result($res);
}
?>


