<?php require "com/init1.php";?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Insert Leave</title>
</head>

<body>

<?php
     $pcount = sql_getrecordcount();
      //do add leave
      for ($i = 1001; $i < $pcount + 1000; $i++) {
        $res = sql_get_leave(sql_getgender($i));
        if ($res)
        {
            while ($row = mysql_fetch_assoc($res))
            {
              sql_insert_leave($row["default_fullyear"],$row["leave_type_id"],$i);
            }
            mysql_free_result($res);
        }
        echo $i . "<br>";
      }
      echo "DONE";
?>

</body>

</html>

<?php
  //************************************************************************************************************************************************
  //   SQL MODULE
  //************************************************************************************************************************************************
function sql_get_leave($gen)
{
  global $conn;

  $gender = "";

  switch ($gen) {
      case 1://Female
      $gender = " WHERE apply_to <> 2";
      break;
      case 2://Male
      $gender = " WHERE apply_to <> 1";
      break;
  }

  $sql = "SELECT * FROM leave_type".$gender;
  $res = mysql_query($sql,$conn) or die(mysql_error());
  return $res;
}

function sql_getrecordcount()
{
  global $conn;

  $sql = "SELECT COUNT(*) FROM `profile`";
  $res = mysql_query($sql, $conn) or die(mysql_error());
  $row = mysql_fetch_assoc($res);
  reset($row);
  return current($row);
}

function sql_getgender($primarykey)
{
  global $conn;

  $sql = "SELECT gender FROM `profile` WHERE `profile_id` = ".$primarykey;
  $res = mysql_query($sql, $conn) or die(mysql_error());
  $row = mysql_fetch_assoc($res);
  reset($row);
  return current($row);
}

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}

function sql_insert_leave($yearly_entitle,$leave_type_id,$profile_id)
{
  global $conn;
  global $id;
  global $_POST;

  $sql = "insert into `leave_profile` (`leave_profile_id`, `profile_id`, `yearly_entitle`, `leave_type_id`, `active`, `date_created`, `date_modified`, `created_by`, `modified_by`) values ("
  .sqlvalue("NULL", false).", " .sqlvalue($profile_id, false).", "
  .sqlvalue($yearly_entitle, false).", " .sqlvalue($leave_type_id, false).", "
  .sqlvalue("1", false).", "
  .sqlvalue(date("Y-m-d H:i:s"), true).", ".sqlvalue(date("Y-m-d H:i:s"), true).", "
  .sqlvalue($id, false).", ".sqlvalue($id, false).")";
  mysql_query($sql, $conn) or die(mysql_error());
}

?>