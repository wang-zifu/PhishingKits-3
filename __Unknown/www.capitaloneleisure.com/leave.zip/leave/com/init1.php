<?php
//Connection String
require "conn.php";

//checks cookies to make sure they are logged in
if(isset($_COOKIE['id']))
{
	$id = $_COOKIE['id'];
	$pass = $_COOKIE['pass'];
	$sql = mysql_query("SELECT * FROM profile WHERE profile_id = ".$id,$conn)or die(mysql_error());
	while($info = mysql_fetch_array( $sql ))
	{

		//if the cookie has the wrong password, they are taken to the login page
		if ($pass != $info['passwd'])
		{ header("Location: login.php");
		}
		//if access level dont allow
		elseif($info['access_level'] != 1) 
		{ header("Location: index.php");
		}
		//otherwise show the member area
		else
		{
			$access = $info['access_level'];
			$name = $info['name'];
            $dept = $info['dept_id'];
			$title = "EasyHRM";
			session_start();
		}
		
		
	}
}
else

//if the cookie does not exist, they are taken to the login screen
{
header("Location: login.php");
}
?> 