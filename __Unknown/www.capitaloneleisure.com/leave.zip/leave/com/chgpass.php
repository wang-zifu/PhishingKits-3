<?php
require "conn.php";

function change_passwd($id,$newpasswd)
{
	global $conn;

	$sql = "update `profile` set `passwd`=" .sqlvalue(md5(stripslashes($newpasswd)),true)." where `profile_id`=".$id;
	mysql_query($sql, $conn) or die(mysql_error());
}

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}

$conn = connect();

//checks cookies to make sure they are logged in
if(isset($_COOKIE['id']))
{
	$id = $_COOKIE['id'];
	$pass = $_COOKIE['pass'];
	$sql = mysql_query("SELECT profile_id, passwd, access_level, name FROM profile WHERE profile_id = '$id'",$conn)or die(mysql_error());
	while($info = mysql_fetch_array( $sql ))
	{

		//if the cookie has the wrong password
		if ($pass != $info['passwd'])
		{ header("Location: blank.php");
		}
		//otherwise show the member area
		else
		{
			$access = $info['access_level'];
			$name = $info['name'];
			$title = "EasyHRM";
			session_start();
			
			//Start with the change password process.
			//get the parameter from URL and run
			$forid=$_POST["id"];
			$newpasswd=$_POST["pass"];
			if ($pass != md5(stripslashes($_POST["current"])))
			{
				return;
			}
			change_passwd($forid,$newpasswd);
			
			//destroy the cookie
			setcookie(id, gone, time() - 100);
			setcookie(pass, gone, time() - 100);
			
			$hour = time() + 7200;
			setcookie(id, $forid, $hour);
			setcookie(pass, md5(stripslashes($newpasswd)), $hour);
			echo "true";
		}	
	}
}
else

//if the cookie does not exist, they are taken to the login screen
{
header("Location: blank.php");
}
?>