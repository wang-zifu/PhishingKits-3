<?php

function sql_holidayCount($a,$b)
{
  global $conn;

  $sql = "SELECT COUNT(*) FROM `holiday` WHERE `holiday_date` BETWEEN '".$a."' AND '".$b."'";
  $res = mysql_query($sql, $conn) or die(mysql_error());
  $row = mysql_fetch_assoc($res);
  reset($row);
  return current($row);
}

function sql_dayAdjustment($info, $opt_halfday)
{
  global $conn;

  $sql = "SELECT * FROM `day`";
  $res = mysql_query($sql, $conn) or die(mysql_error());
  while($row = mysql_fetch_assoc($res)){
    switch ($row["day_id"])
    {
      case 0:
          $info["0"]["work"] = $row["day_working"];
          break;
      case 1:
          $info["1"]["work"] = $row["day_working"];
          break;
      case 2:
          $info["2"]["work"] = $row["day_working"];
          break;
      case 3:
          $info["3"]["work"] = $row["day_working"];
          break;
      case 4:
          $info["4"]["work"] = $row["day_working"];
          break;
      case 5:
          $info["5"]["work"] = $row["day_working"];
          break;
      case 6:
          $info["6"]["work"] = $row["day_working"];
          break;
    }
  }
  $info["off"] = $info["total"] - (
  ($info["0"]["count"] * $info["0"]["work"]) +
  ($info["1"]["count"] * $info["1"]["work"]) +
  ($info["2"]["count"] * $info["2"]["work"]) +
  ($info["3"]["count"] * $info["3"]["work"]) +
  ($info["4"]["count"] * $info["4"]["work"]) +
  ($info["5"]["count"] * $info["5"]["work"]) +
  ($info["6"]["count"] * $info["6"]["work"]));

  //Check if halfday is applicable
  if ($opt_halfday == 1)
  {
    //Check if the first apply day is full working day
  if($info[$info["start"]["wday"]]["work"]==1){if ($info["start"]["am"] == 0){$info["adjust"] =  $info["adjust"] + 0.5;}}

  //Check if the last apply day is full working day
  if($info[$info["end"]["wday"]]["work"]==1){if ($info["end"]["am"] == 1){$info["adjust"] =  $info["adjust"] + 0.5;}}
  }

  $info["period"] = $info["total"] - $info["off"] - $info["holiday"] - $info["adjust"];

  return $info;
}

function getPeriod( $a, $b, $a_am, $b_am, $opt_halfday)
{
  // First we need to break these dates into their constituent parts:
  $gd_a = getdate( $a );
  $gd_b = getdate( $b );

  // The specific time doesn't matter but it must be the same each day
  $start = mktime( 0, 0, 0, $gd_a['mon'], $gd_a['mday'], $gd_a['year'] );
  $end = mktime( 0, 0, 0, $gd_b['mon'], $gd_b['mday'], $gd_b['year'] );

  if($start > $end)return; //avoid infinite loop;
  $res = array(
  "0" => array("count" => 0, "work" => 0), //Sunday
  "1" => array("count" => 0, "work" => 0), //Monday
  "2" => array("count" => 0, "work" => 0), //Tuesday
  "3" => array("count" => 0, "work" => 0), //Wednesday
  "4" => array("count" => 0, "work" => 0), //Thursday
  "5" => array("count" => 0, "work" => 0), //Friday
  "6" => array("count" => 0, "work" => 0), //Saturday
  "start" => array("am" => $a_am, "wday" => date("w",$start)),
  "end" => array("am" => $b_am, "wday" => date("w",$end)),
  "holiday" => sql_holidayCount(date("Y-m-d",$start),date("Y-m-d",$end)),
  "total" => 0,
  "off" => 0,
  "adjust" => 0,
  "period" => 0);

  while ($start <= $end)
  {
    switch (date("w",$start))
    {
      case 0:
          $res["0"]["count"]++;
          break;
      case 1:
          $res["1"]["count"]++;
          break;
      case 2:
          $res["2"]["count"]++;
          break;
      case 3:
          $res["3"]["count"]++;
          break;
      case 4:
          $res["4"]["count"]++;
          break;
      case 5:
          $res["5"]["count"]++;
          break;
      case 6:
          $res["6"]["count"]++;
          break;
    }
    //echo  "<p>".date("Y-m-d; w - l",$start)."<p>";
    $res["total"]++;
    $start = strtotime('next day',$start);
  }
  $res = sql_dayAdjustment($res, $opt_halfday);
  return $res;
}