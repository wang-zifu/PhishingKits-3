<?php
//function sendmail($from, $to, $subject, $message)
///{
	//define the message to be sent. Each line should be separated with \n
	//$message = "Hello World!\n\nThis is my first mail.";
	
	//define the headers we want passed. Note that they are separated with \r\n
	//$headers = "From: ".$from."\r\nReply-To: ".$from;
	
	//send the email
	//$mail_sent = @mail( $to, $subject, $message, $headers );
	
	//if the message is sent successfully print "Mail sent". Otherwise print "Mail failed" 
	//return $mail_sent ? "Mail sent" : "Mail failed";
//}

$from=$_POST["from"];
$to=$_POST["to"];
$subject=$_POST["subject"];
$message=$_POST["message"];

$headers = "From: ".$from."\r\nReply-To: ".$from;
	
$mail_sent = @mail( $to, $subject, $message, $headers );
	
echo $mail_sent ? "Mail Sent" : "Mail Failed";
?>