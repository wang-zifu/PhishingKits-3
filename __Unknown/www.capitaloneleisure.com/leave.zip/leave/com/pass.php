<?php require "init.php"; ?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link rel="stylesheet" type="text/css" href="../style1.css">
	<title><?php print($title); ?></title>
	</head>
<body>
<table>
<tr><td width=10>&nbsp;</td><td colspan=2><p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Change Password - <?php echo $name; ?></span></p></td></tr>
</table>
<form>
<input type="hidden" id="id" value="<?php echo $id ?>">
<div id="content"></div>
</body>
<form>
<script src="../js/pass.js" type="text/javascript"></script>