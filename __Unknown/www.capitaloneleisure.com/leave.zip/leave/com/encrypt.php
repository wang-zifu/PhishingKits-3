<?php
if (isset($_POST["record_id"]))
{
    require "init1.php";
    global $conn;
    $id = $_COOKIE['id'];
	$pass = $_COOKIE['pass'];
	$sql = mysql_query("SELECT * FROM profile WHERE profile_id = ".$id,$conn)or die(mysql_error());
	while($info = mysql_fetch_array( $sql ))
	{
      if ($pass == $info['passwd'])
      {
        $record_id = @$_POST["record_id"];
        $encrypted = encrypt($record_id.";".date("Y-m-d"));
        echo curPageURL()."/job.php?key=".$encrypted;
        return;
      }
    }
}

function curPageURL() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 $temp = substr($_SERVER["SCRIPT_NAME"],0,strrpos($_SERVER["SCRIPT_NAME"],"/"));
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].substr($temp,0,strrpos($temp,"/"));
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].substr($temp,0,strrpos($temp,"/"));
 }
 return $pageURL;
}

function encrypt($string) {
  $key = date("Y-m-d");
  $result = '';
  for($i=0; $i<strlen($string); $i++) {
    $char = substr($string, $i, 1);
    $keychar = substr($key, ($i % strlen($key))-1, 1);
    $char = chr(ord($char)+ord($keychar));
    $result.=$char;
  }

  $result =  base64_encode($result);
  while(substr($result,-1,1)=="="){$result =  substr($result,0,-1);}
  return $result;
}

function decrypt($string) {
  $key = date("Y-m-d");
  $result = '';
  $string = base64_decode($string);

  for($i=0; $i<strlen($string); $i++) {
    $char = substr($string, $i, 1);
    $keychar = substr($key, ($i % strlen($key))-1, 1);
    $char = chr(ord($char)-ord($keychar));
    $result.=$char;
  }

  return $result;
}

// Test output
//$key = @$_GET["key"];
//$decrypted = decrypt($key);
//echo $decrypted."<br><br>";

//$encrypted = encrypt("5;".date("Y-m-d"));
//$decrypted = decrypt($encrypted);
//echo $encrypted."<br>";
//echo $decrypted;
?>