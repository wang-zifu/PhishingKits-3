<?php require "init1.php"; ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<link rel="stylesheet" type="text/css" href="../style1.css">
<title><?php print($title); ?></title>
</head>
<body>
<table>
<tr><td width=10>&nbsp;</td><td colspan=2><p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Change Password - <?php echo $_GET["name"] ?></span></p></td></tr>
</table>
<form>
<input type="hidden" id="id" value="<?php echo $_GET["id"] ?>">
<div id="content"></div>
</form>
</body>
</html>


<div id="choice" style="display:none">
<table>
<tr>
<td width=10>&nbsp;</td>
<td></td>
<td><input type='button' id='button1' value='Change' onclick='manual();'></td><td>&nbsp;Manually change the password.</td>
</tr>
<tr>
<td width=10>&nbsp;</td>
<td></td>
<td><input type='button' id='button2' value='Reset' onclick='showreset();'></td><td>&nbsp;Reset the password for the employee.</td>
</tr>
</table>
</div>

<div id="input" style="display:none">
<table>
<tr>
<td width=10>&nbsp;</td><td><label>New Password</label></td>
<td><input class='input2' type='password' name='passwd' id='passwd' onkeyup='comparepasswd();'/></td>
</tr>
<tr>
<td width=10>&nbsp;</td><td><label>Retype Password</label></td>
<td><input class='input2' type='password' name='passwd_chk' id='passwd_chk' onkeyup='comparepasswd();'/></td>
</tr>
<tr>
<td colspan=2></td><td><input type='button' id='button' value='apply changes' onclick='changepasswd();'>&nbsp;<input type='button' id='cancel1' value='cancel' onclick='window.top.hidePopWin()'></td>
</tr><tr>
<td width=10>&nbsp;</td><td colspan=2><p><span id='txtHint'></span></p></td></tr>
</table>
</div>

<div id="rinput" style="display:none">
<table>
<tr><td></td><td colspan=2>Create a temporary password for the user and send it to the email address below.</td></tr>
<tr><td colspan=3>&nbsp;</td></tr>
<tr>
<td width=10>&nbsp;</td><td><label>Email</label></td>
<td><input class='input2' type='input' name='email' id='email' value="<?php echo $_GET["email"] ?>"/></td>
</tr>
<tr>
<td colspan=2></td><td><input type='button' id='resetbut' value='reset' onclick='resetpass();'>&nbsp;<input type='button' id='cancel2' value='cancel' onclick='window.top.hidePopWin()'></td>
</tr>
</table>
</div>
<script src="../js/supass.js" type="text/javascript"></script>