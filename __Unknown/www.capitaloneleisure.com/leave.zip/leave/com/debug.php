<?php
$id = $_COOKIE['id'];
$result = mysql_query("SELECT * FROM profile WHERE profile_id = '$id'") or die(mysql_error());

while ($row = mysql_fetch_array($result))
{
    echo "<pre>";
	print_r($row);
	echo "</pre>";
}
mysql_free_result($result);
?>
