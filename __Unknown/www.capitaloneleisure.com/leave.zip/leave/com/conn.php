<?php
// Set Timezone.
date_default_timezone_set('Singapore');

$conn = connect();
$email="hrm@bluemission.com.my";

// Connects to your Database blank
function connect()
{
  $conn = mysql_connect("localhost", "bmt_hrmdbuser", "HRM@user123");
  mysql_select_db("bmt_hrm_db");
  return $conn;
}
?>
