<?php
require "init1.php";

function curPageURL() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 $temp = substr($_SERVER["SCRIPT_NAME"],0,strrpos($_SERVER["SCRIPT_NAME"],"/"));
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].substr($temp,0,strrpos($temp,"/"));
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].substr($temp,0,strrpos($temp,"/"));
 }
 return $pageURL;
}

function encrypt($string) {
  $key = date("Y-m-d");
  $result = '';
  for($i=0; $i<strlen($string); $i++) {
    $char = substr($string, $i, 1);
    $keychar = substr($key, ($i % strlen($key))-1, 1);
    $char = chr(ord($char)+ord($keychar));
    $result.=$char;
  }

  $result =  base64_encode($result);
  while(substr($result,-1,1)=="="){$result =  substr($result,0,-1);}
  return $result;
}

function sendmessage($from, $to, $subject, $message)
{
	//define the message to be sent. Each line should be separated with \n
	//$message = "Hello World!\n\nThis is my first mail.";
	
	//define the headers we want passed. Note that they are separated with \r\n
	$headers = "From: ".$from."\r\nReply-To: ".$from;
	
	//send the email
	$mail_sent = @mail( $to, $subject, $message, $headers );
	
	//if the message is sent successfully print "Mail sent". Otherwise print "Mail failed" 
	return $mail_sent;
}

$returnstring="Failed - Please Get Advice From Vendor.";

//checks cookies to make sure they are logged in
if(isset($_COOKIE['id']))
{
    global $email;
	$id = $_COOKIE['id'];
	$pass = $_COOKIE['pass'];
	$sql = mysql_query("SELECT profile_id, passwd, access_level, name FROM profile WHERE profile_id = '$id'",$conn)or die(mysql_error());
	while($info = mysql_fetch_array( $sql ))
	{

		//if the cookie has the wrong password
		if ($pass != $info['passwd'])
		{ 
			$returnstring =  "Failed - Permission Denied.";
		}
		//otherwise show the member area
		else
		{
			$access = $info['access_level'];
			$name = $info['name'];
			$title = "EasyHRM";
			session_start();

			if ($access != 1)
			{
				$returnstring =  "Failed - Permission Denied.";
			}
			else
			{
				if (isset($_POST["record_id"]) && isset($_POST["email"]))//check if it is a reset.
				{
				    $record_id = @$_POST["record_id"];
                    $encrypted = encrypt($record_id.";".date("Y-m-d"));
					$from=$email;
					$to=$_POST["email"];
					$subject="Candidate's Details Form";
					$message="Please visit the address below and fill-up your details: \n\n".curPageURL()."/job.php?key=".$encrypted;
					if (sendmessage($from, $to, $subject, $message))
					{
						$returnstring = "Successful - Invitation Sent.";
					}
					else
					{
						$returnstring = "Email Send Failed - Please Check The Email Address.";
					}
				}
			}
		}	
	}
}
else //if the cookie does not exist.
{
$returnstring =  "Failed - Permission Denied.";
}
echo $returnstring;
?>