<?php require "init.php"; ?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link rel="stylesheet" type="text/css" href="../style1.css">
    <link rel="stylesheet" type="text/css" href="../style4.css">
	<title><?php print($title); ?></title>
	</head>
<body>
<table>
<tr><td width=10>&nbsp;</td><td colspan=2><p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Leave Application Cancelation (<?php echo $name; ?>)</span></p></td></tr>
</table>
<input type="hidden" id="id" value="<?php echo $id ?>">
<div id="content">
<?php

$a = $_GET["a"];

switch ($a) {
    case "confirm":
      update();
      break;
    default:
      show();
      break;
  }

?>
</div>
</body>

<?php
function show()
{ $lid = $_GET["lid"];
  $from = $_GET["from"];
  $to = $_GET["to"];
  $type = $_GET["type"];
  $period = $_GET["period"];
  ?>
  <table>
  <tr><td width=10>&nbsp;</td><td>
  <table class="tbl" border="0" cellspacing="1" cellpadding="5"width="40%">
  <tr>
  <td class="hr">ID</td>
  <td class="dr" colspan=2><?php echo $lid; ?></td></tr>
  <tr>
  <td class="hr">Leave From</td>
  <td class="dr" colspan=2><?php echo $from; ?></td></tr>
  <tr>
  <td class="hr">Leave To</td>
  <td class="dr" colspan=2><?php echo $to; ?></td></tr>
  <tr>
  <td class="hr">Leave Type</td >
  <td class="dr" colspan=2><?php echo $type; ?></td></tr>
  <tr>
  <td class="hr">Period(s)</td>
  <td class="dr" colspan=2><?php echo $period; ?></td></tr>
  <tr>
  <td colspan=3><span style="font-size:13px;color:#F00;">Cancel this Leave Application?</span></td></tr>
  <tr>
  <td colspan=3><input type="button" value="confirm" onclick="window.location.href='<?php echo $_SERVER['PHP_SELF']; ?>?a=confirm&lid=<?php echo $lid; ?>'"> </td></tr>
  </table></td></tr></table><?php
}

function update()
{
  $lid = $_GET["lid"];
  sql_update($lid);
  ?>
  <table>
  <tr><td width=10>&nbsp;</td><td>
  <table class="tbl" border="0" cellspacing="1" cellpadding="5"width="40%">
  <tr>
  <td colspan=3><span style="font-size:13px;color:#F00;">Leave application successfuly canceled.</span></td></tr>
  <tr>
  <td colspan=3><input type="button" value="close" onclick="window.top.hidePopWin();history.go();"> </td></tr>
  </table></td></tr></table><?php
}

function sql_update($lid)
{
  global $conn;
  global $id;

  $sql = "update `leave_dat` set `indicator` = 2, `date_modified` = " .sqlvalue(date("Y-m-d H:i:s"), true).", `modified_by` = " .sqlvalue($id, false) ." where leave_id = ".sqlvalue($lid, false);
  mysql_query($sql, $conn) or die(mysql_error());
}

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}
?>

