<?php
	if ($access)
	{ ?>
		<ul id="sddm">
		<li><a href="index.php">Home</a></li><?php
		if ($access == 1)// load admin menu
		{ ?>
			<li><a href="#"
				onmouseover="mopen('m1')"
				onmouseout="mclosetime()">Setting</a>
				<div id="m1" 
					onmouseover="mcancelclosetime()" 
					onmouseout="mclosetime()">
                <a href="leave_pim.php?a=reset">Employee Leave</a>
				<a href="dept.php?a=reset">Department</a>
				<a href="leave_type.php">Leave Type</a>
				<a href="holiday.php?a=reset">Holidays</a>
                <a href="day.php">Working Day</a>
                <a href="clinic.php">Panel Clinic</a>
				</div>
			</li>
			<li><a href="#"
				onmouseover="mopen('m2')"
				onmouseout="mclosetime()">PIM</a>
				<div id="m2"
					onmouseover="mcancelclosetime()"
					onmouseout="mclosetime()">
                <a href="pim.php?a=add">Add New Employee</a>
				<a href="pim.php?a=reset">Employee List</a>
                <a href="potential.php?a=reset">Potential Candidates</a>
                <?php if ($id<>999){ ?><a href="profile.php">My Personal Information</a><?php } ?>
				</div>
			</li>
			<li><a href="#"
				onmouseover="mopen('m3')"
				onmouseout="mclosetime()">Leave</a>
				<div id="m3"
					onmouseover="mcancelclosetime()"
					onmouseout="mclosetime()">
                <a href="leave_list.php?a=reset">Leave Management</a>
                <a href="leave_rpt.php?a=reset">Leave Application Report</a>
                <a href="summary.php?a=reset">Leave Balance Summary</a>
				<?php if ($id<>999){ ?><a href="history.php?a=reset">My Leave History</a><a href="apply.php">Apply New Leave</a><?php } ?>
				</div>
            </li>
            <li><a href="#"
				onmouseover="mopen('m4')"
				onmouseout="mclosetime()">Claim</a>
				<div id="m4"
					onmouseover="mcancelclosetime()"
					onmouseout="mclosetime()">
                <a href="medical_slip.php?a=reset">Medical Claim Management</a>
                </div>
			</li><?php
		}
		
		if ($access == 2)// load executive menu
		{ ?>
			<li><a href="#" 
				onmouseover="mopen('m2')"
				onmouseout="mclosetime()">PIM</a>
				<div id="m2" 
					onmouseover="mcancelclosetime()" 
					onmouseout="mclosetime()">
				<a href="profile.php">My Personal Information</a>
				</div>
			</li>
			<li><a href="#" 
				onmouseover="mopen('m3')"
				onmouseout="mclosetime()">Leave</a>
				<div id="m3"
					onmouseover="mcancelclosetime()" 
					onmouseout="mclosetime()">
                <a href="leave_list.php?a=reset&order=leave_id&type=desc">Leave Management</a>
                <a href="history.php?a=reset">My Leave History</a>
				<a href="apply.php">Apply New Leave</a>
				</div>
			</li>
            <li><a href="#"
				onmouseover="mopen('m4')"
				onmouseout="mclosetime()">Claim</a>
				<div id="m4"
					onmouseover="mcancelclosetime()"
					onmouseout="mclosetime()">
                <a href="medical_slip_apply.php">Apply New Medical Claim</a>
                </div>
			</li><?php
		}

		if ($access == 3)// load user menu
		{ ?>
			<li><a href="#" 
				onmouseover="mopen('m2')"
				onmouseout="mclosetime()">PIM</a>
				<div id="m2"
					onmouseover="mcancelclosetime()"
					onmouseout="mclosetime()">
				<a href="profile.php">My Personal Information</a>
				</div>
			</li>
			<li><a href="#"
				onmouseover="mopen('m3')" 
				onmouseout="mclosetime()">Leave</a>
				<div id="m3"
					onmouseover="mcancelclosetime()"
					onmouseout="mclosetime()">
                <a href="history.php?a=reset">My Leave History</a>
				<a href="apply.php">Apply New Leave</a>
				</div>
			</li>
            <li><a href="#"
				onmouseover="mopen('m4')"
				onmouseout="mclosetime()">Claim</a>
				<div id="m4"
					onmouseover="mcancelclosetime()"
					onmouseout="mclosetime()">
                <a href="medical_slip_apply.php">Apply New Medical Claim</a>
                </div>
			</li><?php
		} ?>
		<li><a href="help.php">Help</a></li>
		</ul>
<?php			
	}
?>