<?php require "init1.php";
 if (isset($_GET["pid"])) $pid = @$_GET["pid"];

?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link rel="stylesheet" type="text/css" href="../style1.css">
    <link rel="stylesheet" type="text/css" href="../style2.css">
	<title>Upload Files</title>
	</head>
<body>
<table width="100%">
<tr><td width=10>&nbsp;</td><td colspan=2><p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Attachment File/Profile Picture Upload</span></p>
<hr size="1" color=#dcdbdb noshade> </td></tr>
</table>
<div id="content"></div>
</body>

<div id="choice" style="display:none">
<table>
<tr><td width=10>&nbsp;</td><td></td>
<td><input type='button' id='picUpload' value='Picture' onclick='uploadPicture();'></td><td>&nbsp;Upload/Remove Profile Picture.</td>
</tr>
<tr><td width=10>&nbsp;</td><td></td>
<td><input type='button' id='fileUpload' value='File' onclick='uploadFile();'></td><td>&nbsp;Upload/Remove Attachment File(Resume/CV).</td>
</tr>
</table>
</div>

<div id="file" style="display:none">
<table width="100%">
<tr><td width=10>&nbsp;</td><td></td>
<td>
<form action="../upload_file.php?sid=<?php echo rand(1000,9999); ?>" method="post" enctype="multipart/form-data">
<p>Please select a file (7z/rar/zip) to be uploaded.<br />
The file size should not be more then 2Mb.<br /><br />
Note: Leaving the "Filename" blank, will remove the existing file.<br /></p>
<label for="file">Filename:</label>
<input type="file" name="file" id="file" />
<input type="hidden" name="pid" value="<?php echo $pid ?>" />
<br /><br />
<input type="submit" name="submit" value="Upload" />
</form></td></tr>
</table>
</div>

<div id="picture" style="display:none">
<table width="100%">
<tr><td width=10>&nbsp;</td><td></td>
<td>
<form action="../upload_pic.php?sid=<?php echo rand(1000,9999); ?>" method="post" enctype="multipart/form-data">
<p>Please select a picture file (gif/jpg/bmp/png) to be uploaded.<br />
The file size should not be more then 1Mb.<br /><br />
Note: Leaving the "Picture" blank, will remove the existing picture.<br /></p>
<label for="file">Picture:</label>
<input type="file" name="file" id="file" />
<input type="hidden" name="pid" value="<?php echo $pid ?>" />
<br /><br />
<input type="submit" name="submit" value="Upload" />
</form></td></tr>
</table>
</div>

<script src="../js/upload.js" type="text/javascript"></script>
