<?
if(isset($HTTP_COOKIE_VARS["screen_height"]))$screen_height = $HTTP_COOKIE_VARS["screen_height"];
?>

<div class="footer" valign="bottom">
<table class="contentpadding" width="100%" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" valign="bottom" height="<?php if(isset($HTTP_COOKIE_VARS["screen_height"])) echo ($screen_height/3) ?>px">
<tbody><tr>
  <td colspan="3" valign="bottom" align="center">
    <table width="100%" border="0" cellpadding="6" cellspacing="0">
      <tbody><tr>
        <td colspan="2" class="footernavL1" valign="bottom" align="left">
		<a href="#">Email Support</a><span class="vertbarfooter_padding">|</span>
        <a href="#">Email Suggestion</a>
        </td>
      </tr>
      <tr>
        <td class="bordertop" valign="bottom" width="75%" align="left" nowrap>
          <span class="footernavL1">Copyright &copy  2009 Blue Mission Technology Sdn Bhd, All rights reserved.</span>
		</td>
        <td class="bordertop" valign="bottom" align="right">
          <img src="images/life.gif" width="141" height="20">
        </td>
      </tr>
    </tbody></table>
  </td>
</tr>
<tr>
  <td colspan="3" align="center"><br></td>
</tr>
</tbody></table>
</div>