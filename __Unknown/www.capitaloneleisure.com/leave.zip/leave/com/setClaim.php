<?php
require "conn.php";

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}

function getLimit($profile_id)
{
    global $conn;

    $sql = mysql_query("SELECT Sum(medical_claim) AS sum_medical_claim FROM profile WHERE profile_id = ".$profile_id,$conn);
	$res = mysql_fetch_array($sql);
    return $res["sum_medical_claim"];
}

function getClaim($profile_id)
{
    global $conn;

    $sql = mysql_query("SELECT Sum(claim_amount) AS sum_claim_amount FROM medical_slip WHERE Year(date_visit) = ".sqlvalue(date("Y"), true)." AND profile_id = ".$profile_id,$conn);
	$res = mysql_fetch_array($sql);
    return $res["sum_claim_amount"];
}


//checks cookies to make sure they are logged in
if(isset($_COOKIE['id']) && isset($_POST['a']) && isset($_POST['id']))
{
  $a = @$_POST['a'];
  $profile_id = @$_POST['id'];

  $limit = getLimit($profile_id);

  if($a=="limit")
  {
     echo $limit;
  }
  elseif($a=="balance")
  {
     $balance = $limit - getClaim($profile_id);
     echo $balance;
  }
  return;
}
?>