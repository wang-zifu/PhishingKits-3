<?php require "init1.php";
require "encrypt.php";
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<link rel="stylesheet" type="text/css" href="../style1.css">
<title><?php print($title); ?></title>
</head>
<body>
<table width="98%">
<tr><td width=10>&nbsp;</td><td colspan=2><p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Job Application Invitation - <?php echo $_GET["name"] ?></span></p>
<hr size="1" color=#dcdbdb noshade></td></tr>
</table>
<form>
<input type="hidden" id="id" value="<?php echo $_GET["id"] ?>">
<div id="content"></div>
</form>
</body>
</html>

<div id="choice" style="display:none">
<table>
<tr>
<td width=10>&nbsp;</td>
<td></td>
<td><input type='button' id='button1' value='Get' onclick='manual();'>&nbsp;</td><td>Get the online application form address.</td>
</tr>
<tr>
<td width=10>&nbsp;</td>
<td></td>
<td><input type='button' id='button2' value='Send' onclick='email();'>&nbsp;</td><td>Send the online application form to the potential candidate.</td>
</tr>
</table>
</div>

<div id="get" style="display:none">
<table>
<tr><td>&nbsp;&nbsp;&nbsp;</td><td colspan=2><div id="title">Form URL:</div></td></tr>
<tr><td>&nbsp;&nbsp;&nbsp;</td><td colspan=2 class="textsubtitlegry"><div id="address"></div></td></tr>
<tr><td colspan=3>&nbsp;</td></tr>
<tr>
<td colspan=2></td><td><input type='button' id='close' value='Close' onclick='window.top.hidePopWin()'></td>
</tr>
</table>
</div>

<div id="send" style="display:none">
<table>
<tr><td></td><td colspan=2>Send the online application form to the email address below.</td></tr>
<tr><td colspan=3>&nbsp;</td></tr>
<tr>
<td width=10>&nbsp;</td><td><label>Email</label></td>
<td><input class='input2' type='input' name='email' id='email' value="<?php echo $_GET["email"] ?>"/></td>
</tr>
<tr>
<td colspan=2></td><td><input type='button' id='send' value='Send' onclick='emailsend();'>&nbsp;<input type='button' id='cancel2' value='cancel' onclick='window.top.hidePopWin()'></td>
</tr>
</table>
</div>
<script src="../js/invite.js" type="text/javascript"></script>