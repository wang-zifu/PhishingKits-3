<?php require "init2.php"; ?>
<?php require "../email/approve.php"; ?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link rel="stylesheet" type="text/css" href="../style1.css">
    <link rel="stylesheet" type="text/css" href="../style4.css">
	<title><?php print($title); ?></title>
	</head>
<body>
<table>
<tr><td width=10>&nbsp;</td><td colspan=2><p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Leave Application Details</span></p></td></tr>
</table>
<input type="hidden" id="id" value="<?php echo $id ?>">
<div id="content">
<?php
if (isset($_POST["lid"])) {$lid = @$_POST["lid"];} else {$lid = $_GET["lid"];}
if (isset($_POST["a"])) $a = @$_POST["a"];
if (isset($_POST["handler"])) $handler = @$_POST["handler"];

switch ($a) {
    case "cancel":
      cancel();
      break;
    case "post":
      post();
      break;
    case "approve":
      approve();
      break;
    case "reject":
      reject();
      break;
    default:
      show();
      break;
  }

?>
</div>
</body>

<?php
function show()
{
  global $lid;
  $res = sql_select($lid);
  $row = mysql_fetch_assoc($res);
  ?>
  <table>
  <tr><td width=10>&nbsp;</td><td>
  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
  <table class="tbl" border="0" cellspacing="1" cellpadding="5" width="550">
  <tr>
  <td class="hr" width="50">App.ID / Sys.ID</td>
  <td class="dr" colspan=2><?php echo $row["leave_id"]." / ".$row["profile_id"]; ?></td>
  <td class="hr" width="50" valign="top" rowspan=3>Remark</td>
  <td class="dr" width="40%" rowspan=3><?php echo $row["remark"]; ?></td></tr>
  <tr>
  <td class="hr">Name (Emp.ID)</td>
  <td class="dr" colspan=2><?php echo $row["name"]." (".$row["employee_id"].")"; ?></td></tr>
  <tr>
  <td class="hr">Leave Type</td>
  <td class="dr" colspan=2><?php echo $row["leave_type_name"]; ?></td></tr>
  <tr>
  <td class="hr">Leave From</td>
  <td class="dr" colspan=2><?php echo $row["date_from"]; ?></td>
  <td class="hr">Leave To</td>
  <td class="dr"><?php echo $row["date_to"]; ?></td></tr>
  <tr>
  <td class="hr">From</td >
  <td class="dr" colspan=2><?php if ($row["am_from"] == 1) { echo "AM";} else { echo "PM";} ?></td>
  <td class="hr">Duration(day)</td>
  <td class="dr"><?php echo $row["period"]; ?></td></tr>
  <tr><td colspan=6>&nbsp;</td></tr>
  <tr>
  <td class="hr">Modified Date&nbsp;</td>
  <td class="dr" colspan=2><?php echo htmlspecialchars($row["date_modified"]) ?></td>
  <td class="hr" width="50" valign="top" rowspan=2><span style="color:#F99;">Officer Remark</span></td>
  <td class="dr" rowspan=2>
  <textarea class="input2" cols="35" rows="2" name="handler" maxlength="255"><?php echo str_replace('"', '&quot;', trim($row["handler"])) ?></textarea>
  <input type="hidden" name="lid" value="<?php echo $lid; ?>" />
  <input type="hidden" name="profile_id" value="<?php echo $row["profile_id"]; ?>" />
  <input type="hidden" name="date_from" value="<?php echo $row["date_from"]; ?>" />
  <input type="hidden" name="date_to" value="<?php echo $row["date_to"]; ?>" />
  </td></tr>
  <tr>
  <td class="hr">Modified By&nbsp;</td>
  <td class="dr" colspan=2><?php echo get_author($row["modified_by"]) ?></td>
  </tr>
  <tr><td colspan=6>&nbsp;</td></tr>
  <?php option($row["indicator"], $row["leave_type_id"], $row["leave_id"], $row["profile_id"]); ?>
  </table></form></td></tr></table><?php
  mysql_free_result($res);
}

function option($indicator, $leave_type_id, $leave_id, $profile_id)
{
  global $access;
  $ehandler = 0;
  if ($access == 1) //Administrator
  {
      switch ($indicator) {
    case 0:
        $msg = "Application is seeking for approval. Please select an option?";
        break;
    case 1:
        $msg = "Application has been approved. Please select an option to make changes.";
        break;
    case 2:
        $msg = "Application has been cancelled. Please select an option to make changes.";
        break;
    case 3:
        $msg = "Application has been rejected. Please select an option to make changes.";
        break;
    default:
        $msg = "Error(".$indicator."): Please contact the administrator.";
        $ehandler = 1;
        ?><tr><td colspan=6><span style="font-size:13px;color:#F00;"><?php echo $msg; ?></span></td></tr>
        <tr><td colspan=6>
        <input type='button' value='close' onclick='window.top.hidePopWin()'>
        </td></tr><?php
        break;
    }
    if ($ehandler == 0)
    {
        ?><tr><td colspan=6><span style="font-size:13px;color:#F00;"><?php echo $msg; ?></span></td></tr>
        <tr>
        <td><input type="radio" name="a" value="approve">Aprove</td>
        <td><input type="radio" name="a" value="reject">Reject</td>
        <td><input type="radio" name="a" value="cancel">Cancel</td>
        <td><input type="radio" name="a" value="post" checked>Remark</td>
        <td colspan=4><input type='submit' value='post'>
        <input type='button' value='close' onclick='window.top.hidePopWin()'>
        </td></tr><?php
    }
  }
  else //Other Access
  {
    switch ($indicator) {
    case 0:
        if($leave_type_id==3)//Check for medical slip if its sick leave
        {
          $slip = sql_countslip($leave_id, $profile_id);
          switch ($slip) {
          case "0":
            $msg = "The leave is still waiting for verification.";
            setInterface($msg,0);
            break;
          case "1": //Check if slip exist
            $msg = "Application is seeking for approval. Please select an option?";
            ?><tr><td colspan=6><span style="font-size:13px;color:#F00;"><?php echo $msg; ?></span></td></tr>
            <tr>
            <td><input type="radio" name="a" value="approve">Aprove</td>
            <td><input type="radio" name="a" value="reject">Reject</td>
            <td colspan=4><input type='submit' value='post'>
            <input type='button' value='close' onclick='window.top.hidePopWin()'>
            </td></tr><?php
            break;
          default:
            $msg = "Error(800): Duplicated Leave ID in Medical Slip.";
            setInterface($msg,0);
            break;
          }
        }
        else
        {
          echo "no check";
          echo $leave_type_id;
          $msg = "Application is seeking for approval. Please select an option?";
          ?><tr><td colspan=6><span style="font-size:13px;color:#F00;"><?php echo $msg; ?></span></td></tr>
          <tr>
          <td><input type="radio" name="a" value="approve">Aprove</td>
          <td><input type="radio" name="a" value="reject">Reject</td>
          <td colspan=4><input type='submit' value='post'>
          <input type='button' value='close' onclick='window.top.hidePopWin()'>
          </td></tr><?php
        }
        break;
    case 1:
        $msg = "Application has been approved. Please post to make changes to the 'Officer Remark'.";
        setInterface($msg);
        break;
    case 2:
        $msg = "Application has been canceled. Please post to make changes to the 'Officer Remark'.";
        setInterface($msg);
        break;
    case 3:
        $msg = "Application has been rejected. Please post to make changes to the 'Officer Remark'.";
        setInterface($msg);
        break;
    default:
        $msg = "Error(".$indicator."): Please contact the administrator.";
        setInterface($msg,0);
        break;
    }
  }
}

function sql_countslip($leave_id, $profile_id)
{
    global $conn;

    $sql = mysql_query("SELECT COUNT(*) AS count FROM medical_slip WHERE profile_id =  ".sqlvalue($profile_id,false)." AND leave_id =  ".sqlvalue($leave_id,false),$conn);
	$res = mysql_fetch_array($sql);
    return $res["count"];
}

function setInterface($msg,$post=1)
{
  ?><tr><td colspan=6><span style="font-size:13px;color:#F00;"><?php echo $msg; ?></span></td></tr>
  <tr><td colspan=6>
  <?php if($post==1){?>
  <input type="hidden" name="a" value="post" />
  <input type='submit' value='post'>
  <?}?>
  <input type='button' value='close' onclick='window.top.hidePopWin()'>
  </td></tr><?php
}

function cancel()
{
  global $lid;
  global $handler;
  sql_update($lid,2,"Canceled by Admin");
  ?>
  <table>
  <tr><td width=10>&nbsp;</td><td>
  <table class="tbl" border="0" cellspacing="1" cellpadding="5"width="40%">
  <tr>
  <td colspan=3><span style="font-size:13px;color:#F00;">Application's has been canceled.</span></td></tr>
  <tr>
  <td colspan=3><input type="button" value="close" onclick="window.top.hidePopWin();history.go();"> </td></tr>
  </table></td></tr></table><?php
}

function post()
{
  global $lid;
  global $handler;
  sql_update($lid,-10,$handler);
  //echo $handler;
  ?>
  <table>
  <tr><td width=10>&nbsp;</td><td>
  <table class="tbl" border="0" cellspacing="1" cellpadding="5"width="40%">
  <tr>
  <td colspan=3><span style="font-size:13px;color:#F00;">Application's officer remark updated.</span></td></tr>
  <tr>
  <td colspan=3><input type="button" value="close" onclick="window.top.hidePopWin();history.go();"> </td></tr>
  </table></td></tr></table><?php
}

function get_leave_info($lid)
{
	global $conn;

	$sql = "SELECT `leave_id`, `profile_id`, `leave_type_id`, `date_from`, `date_to`, `period`, `am_from`, `am_to`, `remark`, `handler`, `indicator`, `date_created` FROM `leave_dat` WHERE `leave_id` = ".$lid;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row;
	}
}
function get_author($id)
{
	global $conn;

	$sql = "SELECT `name` FROM `profile` WHERE `profile_id` = ".$id;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["name"];
	}
}

function get_leave_type($id)
{
	global $conn;

	$sql = "SELECT `leave_type_name` FROM `leave_type` WHERE `leave_type_id` = ".$id;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["leave_type_name"];
	}
}

function approve()
{
  global $application;
  global $id;
  global $lid;
  global $handler;
  sql_update($lid,1,$handler);
  $row = get_leave_info($lid);


  //Email to Applicant
  $to = get_email(@$_POST["profile_id"]);

  $message = str_replace("[DATE]", $row["date_created"], $application);
  $message = str_replace("[SYSTEMID]", $row["profile_id"], $message);
  $message = str_replace("[NAME]", get_author($row["profile_id"]), $message);
  $message = str_replace("[LEAVEID]", $row["leave_id"], $message);
  $message = str_replace("[LEAVETYPE]", get_leave_type($row["leave_id"]), $message);
  $message = str_replace("[AMPM]", returnAMPM($row["am_from"]), $message);
  $message = str_replace("[LEAVEFROM]", $row["date_from"], $message);
  $message = str_replace("[LEAVETO]", $row["date_to"], $message);
  $message = str_replace("[DURATION]", $row["period"], $message);
  if(strlen($row["remark"])>0){$message = str_replace("[REMARK]", $row["remark"], $message);} else {$message = str_replace("[REMARK]", "-", $message);}
  $message = str_replace("[ACTION]", "APPLICATION APPROVED", $message);
  $message = str_replace("[APPROVER]", get_author($id), $message);

  $msg = sendapplication($to,$message);

  ?>
  <table>
  <tr><td width=10>&nbsp;</td><td>
  <table class="tbl" border="0" cellspacing="1" cellpadding="5"width="40%">
  <tr><td colspan=3><span style="font-size:13px;color:#F00;">Leave application approved.</span></td></tr>
  <?php if(strlen($msg)>0){ ?><tr><td colspan=3><span style="font-size:13px;">Send Email to Applicant: <?php echo $msg; ?></span></td></tr><?php } ?>
  <tr><td colspan=3><input type="button" value="close" onclick="window.top.hidePopWin();history.go();"> </td></tr>
  </table></td></tr></table><?php
}

function reject()
{
  global $application;
  global $id;
  global $lid;
  global $handler;
  sql_update($lid,3,$handler);
  $row = get_leave_info($lid);

  //Email to Applicant
  $to = get_email(@$_POST["profile_id"]);

  $message = str_replace("[DATE]", $row["date_created"], $application);
  $message = str_replace("[SYSTEMID]", $row["profile_id"], $message);
  $message = str_replace("[NAME]", get_author($row["profile_id"]), $message);
  $message = str_replace("[LEAVEID]", $row["leave_id"], $message);
  $message = str_replace("[LEAVETYPE]", get_leave_type($row["leave_id"]), $message);
  $message = str_replace("[AMPM]", returnAMPM($row["am_from"]), $message);
  $message = str_replace("[LEAVEFROM]", $row["date_from"], $message);
  $message = str_replace("[LEAVETO]", $row["date_to"], $message);
  $message = str_replace("[DURATION]", $row["period"], $message);
  if(strlen($row["remark"])>0){$message = str_replace("[REMARK]", $row["remark"], $message);} else {$message = str_replace("[REMARK]", "-", $message);}
  $message = str_replace("[ACTION]", "APPLICATION REJECTED", $message);
  $message = str_replace("[APPROVER]", get_author($id), $message);

  $msg = sendapplication($to,$message);

  ?>
  <table>
  <tr><td width=10>&nbsp;</td><td>
  <table class="tbl" border="0" cellspacing="1" cellpadding="5"width="40%">
  <tr><td colspan=3><span style="font-size:13px;color:#F00;">Leave application rejected.</span></td></tr>
  <?php if(strlen($msg)>0){ ?><tr><td colspan=3><span style="font-size:13px;">Send Email to Applicant: <?php echo $msg; ?></span></td></tr><?php } ?>
  <tr><td colspan=3><input type="button" value="close" onclick="window.top.hidePopWin();history.go();"> </td></tr>
  </table></td></tr></table><?php
}

function sendmessage($from, $to, $subject, $message)
{
	$headers = "From: ".$from."\r\nReply-To: ".$from;
	$mail_sent = @mail( $to, $subject, $message, $headers );
	return $mail_sent;
}

function sendapplication($to,$message)
{
    global $email;
    $from=$email;
	$subject="HRM - Leave Application";
	if (sendmessage($from, $to, $subject, $message))
	{$returnstring = "Successfully Send";}
	else
	{$returnstring = "Sending Failed";}
    return 	$returnstring;
}

function get_email($id)
{
	global $conn;

	$sql = "SELECT `email` FROM `profile` WHERE `profile_id` = ".$id;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["email"];
	}
}

function sql_update($lid, $indicator, $handler)
{
  global $conn;
  global $id;

  $sql = "update `leave_dat` set ";

  if ($indicator > -1)
  {
    $sql .= "`indicator` = ".sqlvalue($indicator,false).", ";
  }

  $sql .= "`handler` = ".sqlvalue($handler,true).", `date_modified` = " .sqlvalue(date("Y-m-d H:i:s"), true).", `modified_by` = " .sqlvalue($id, false) ." where leave_id = ".sqlvalue($lid, false);
  mysql_query($sql, $conn) or die(mysql_error());
}

function sql_select($id)
{
  global $conn;

  $sql = "SELECT ld.leave_id, ld.profile_id, p.employee_id, p.name, d.dept_desc, ld.leave_type_id, lt.leave_code, lt.leave_type_name, ld.date_from, ld.date_to, ld.period, ld.remark, ld.handler, ld.indicator, ld.date_created, ld.date_modified, ld.created_by, ld.modified_by, ld.am_from
  FROM leave_dat AS ld, leave_type AS lt, profile AS p, dept as d
  WHERE ld.leave_type_id = lt.leave_type_id
  AND ld.profile_id = p.profile_id
  AND p.dept_id = d.dept_id
  AND ld.leave_id = ".sqlvalue($id,false);

  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}

function returnAMPM ($ampm) {
  return $ampm ? 'AM' : 'PM' ;
}
?>

