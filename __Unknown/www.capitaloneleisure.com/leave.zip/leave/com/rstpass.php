<?php
require "init1.php";

function change_passwd($id,$newpasswd)
{
	global $conn;

	$sql = "update `profile` set `passwd`=" .sqlvalue(md5(stripslashes($newpasswd)),true)." where `profile_id`=".$id;
	mysql_query($sql, $conn) or die(mysql_error());
}

function sendmessage($from, $to, $subject, $message)
{
	//define the message to be sent. Each line should be separated with \n
	//$message = "Hello World!\n\nThis is my first mail.";
	
	//define the headers we want passed. Note that they are separated with \r\n
	$headers = "From: ".$from."\r\nReply-To: ".$from;
	
	//send the email
	$mail_sent = @mail( $to, $subject, $message, $headers );
	
	//if the message is sent successfully print "Mail sent". Otherwise print "Mail failed" 
	return $mail_sent;
}

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}

$returnstring="Failed - Please Get Advice From Vendor.";

//checks cookies to make sure they are logged in
if(isset($_COOKIE['id']))
{
    global $email;
	$id = $_COOKIE['id'];
	$pass = $_COOKIE['pass'];
	$sql = mysql_query("SELECT profile_id, passwd, access_level, name FROM profile WHERE profile_id = '$id'",$conn)or die(mysql_error());
	while($info = mysql_fetch_array( $sql ))
	{

		//if the cookie has the wrong password
		if ($pass != $info['passwd'])
		{ 
			$returnstring =  "Failed - Permission Denied.";
		}
		//otherwise show the member area
		else
		{
			$access = $info['access_level'];
			$name = $info['name'];
			$title = "EasyHRM";
			session_start();
			
			//Start with the change password process.
			//get the parameter from URL and run
			$forid=$_POST["id"];
			$newpasswd=$_POST["pass"];
			if ($access != 1)
			{
				$returnstring =  "Failed - Permission Denied.";
			}
			else
			{
				change_passwd($forid,$newpasswd);
			
				if (isset($_POST["email"]))//check if it is a reset.
				{
					$from=$email;
					$to=$_POST["email"];
					$subject="HRM-Password";
					$message="Your password for User ID '".$forid."' has been reset.\nPlease change your password immediately upon login\nwith the temporary password below:\n\n Password: ".$newpasswd;
					if (sendmessage($from, $to, $subject, $message))
					{
						$returnstring = "Successful - Password Changed.";
					}
					else
					{
						$returnstring = "Email Send Failed - Please Check The Email Address.";
					}
				}
				else
				{
					$returnstring = "Successful - Password Changed.";
				}
			}
		}	
	}
}
else //if the cookie does not exist.
{
$returnstring =  "Failed - Permission Denied.";
}
echo "<div align='center'><p>".$returnstring."<p><input type='button' id='close' value='close' onclick='window.top.hidePopWin()'></div>";
?>