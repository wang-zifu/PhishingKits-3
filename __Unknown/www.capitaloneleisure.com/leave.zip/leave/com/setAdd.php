<?php
require "conn.php";

//checks cookies to make sure they are logged in
if(isset($_COOKIE['id']))
{

   $clinic_id=$_POST["clinic_id"];
   if ($clinic_id > 1)
   {
     $sql2 = mysql_query("SELECT address, postcode, city, province, country FROM clinic WHERE clinic_id = ".$clinic_id,$conn);
     $res = mysql_fetch_array($sql2);
     $ret = "";
     if(strlen($res["address"])>0){$ret .= ", ".$res["address"];}
     if(strlen($res["city"])>0){$ret .= ", ".$res["city"];}
     if(strlen($res["postcode"])>0)
     {
        if(strlen($res["province"])>0)
        {
          $ret .= ", ".$res["postcode"]." ".$res["province"];
        }
        else
        {
          $ret .= ", ".$res["postcode"];
        }
     }
     else
     {
       if(strlen($res["province"])>0)
        {
          $ret .= ", ".$res["province"];
        }
     }

     if(strlen($res["country"])>0){$ret .= ", ".$res["country"];}
     echo substr($ret,2);
     return;
   }
 }
?>