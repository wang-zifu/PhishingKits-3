<?php require "com/init.php";

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}

function sql_update($pid,$file)
{
  global $conn;
  global $id;
  $sql = "update `profile` set `file_pic`=".sqlvalue($file, true)
  .", `date_modified`=" .sqlvalue(date("Y-m-d H:i:s"), true)
  .", `modified_by`=" .sqlvalue($id, false) ." where `profile_id`=".$pid;
  mysql_query($sql, $conn) or die(mysql_error());
}

function get_filetype()
{
  $extend = ".gif";
  switch ($_FILES["file"]["type"]) {
      case "image/jpeg":
      $extend = ".jpg";
          break;
      case "image/bmp":
          $extend = ".bmp";
          break;
      case "image/png":
          $extend = ".png";
          break;
      case "image/pjpeg":
          $extend = ".jpg";
          break;
  }
  return $extend;
}

$pid = @$_POST["pid"];
$str = "";

if (isset($_POST["a"])) $a = @$_POST["a"];
if(strlen($_FILES["file"]["name"])==0)
{
  foreach (glob("picture/".$pid."pic*.*") as $filename) {
    unlink($filename);
    $str .= "File Removed: " . $filename . "<br />";
  }
  if(strlen($str)<1){$str .= "No File Removed.<br />";}
  sql_update($pid,"default.gif");
}
else
{
  if ((($_FILES["file"]["type"] == "image/gif")
  || ($_FILES["file"]["type"] == "image/jpeg")
  || ($_FILES["file"]["type"] == "image/bmp")
  || ($_FILES["file"]["type"] == "image/png")
  || ($_FILES["file"]["type"] == "image/pjpeg"))
  && ($_FILES["file"]["size"] < 1000000))
  {
    if ($_FILES["file"]["error"] > 0)
    {
      $str = "Return Code: " . $_FILES["file"]["error"] . "<br />";
    }
    else
    {
      $str = "Upload: " . $_FILES["file"]["name"] . "<br />";
      $str .= "Type: " . $_FILES["file"]["type"] . "<br />";
      $str .= "Size: " . round(($_FILES["file"]["size"] / 1024),2) . " Kb<br />";

      $extend = get_filetype();
      $file = $pid."pic".rand(1000,9999).$extend;

      //foreach (glob("picture/".$pid."pic*.*") as $filename) {
          //unlink($filename);
      //}

      move_uploaded_file($_FILES["file"]["tmp_name"],"picture/".$file);
      sql_update($pid,$file);
      $str .= "Successfully Uploaded.";
    }
  }
  else
  {
    $str =  "Error : Invalid file or file size.<br /><br />";
    $str .=  "Type: " . $_FILES["file"]["type"] . "<br />";
    $str .= "Size: " . round(($_FILES["file"]["size"] / 1024),2) . " Kb<br />";
  }
}
//<input type="button" value="close" onclick="window.top.hidePopWin();history.go();">
echo $str;
?>