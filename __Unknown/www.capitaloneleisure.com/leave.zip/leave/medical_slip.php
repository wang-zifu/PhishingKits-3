<?php require "com/init1.php"; ?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head><link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link rel="stylesheet" type="text/css" href="style1.css">
	<link rel="stylesheet" type="text/css" href="style4.css">
	<script src="js/menu.js" type="text/javascript"></script>
	
	<link rel="stylesheet" type="text/css" href="sub/style.css" />
	<link rel="stylesheet" type="text/css" href="sub/subModal.css" />
	<script type="text/javascript" src="sub/common.js"></script>
	<script type="text/javascript" src="sub/subModal.js"></script>
	<title><?php print($title); ?></title>
	</head>
<?php
  if (isset($_GET["order"])) $order = @$_GET["order"];
  if (isset($_GET["type"])) $ordtype = @$_GET["type"];

  if (isset($_POST["filter"])) $filter = @$_POST["filter"];
  if (isset($_POST["filter2"])) $filter2 = @$_POST["filter2"];
  if (isset($_POST["filter_field"])) $filterfield = @$_POST["filter_field"];
  $wholeonly = false;
  if (isset($_POST["wholeonly"])) $wholeonly = @$_POST["wholeonly"];

  if (!isset($order) && isset($_SESSION["order"])) $order = $_SESSION["order"];
  if (!isset($ordtype) && isset($_SESSION["type"])) $ordtype = $_SESSION["type"];
  if (!isset($filter) && isset($_SESSION["filter"])) $filter = $_SESSION["filter"];
  if (!isset($filterfield) && isset($_SESSION["filter_field"])) $filterfield = $_SESSION["filter_field"];
  if (!isset($filter2) && isset($_SESSION["filter2"])) $filter2 = $_SESSION["filter2"];
?>

<body>
<div class="mainContainer" id="mainContainer">

<!-- HEADER START HERE ... -->
<table width="100%" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" height="75">
<tbody><tr><td valign="top"><table class="contentpadding" width="100%" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" width="201" align="left"><img src="images/logo.gif" alt="Blue Mission Technology" name="bmtlogo" id="logo" width="121" border="0" height="33"></td>
<td class="topnav" valign="middle" align="right" height="80"  nowrap><span class="btnfindsoftware"><?php echo date('l, jS \of F Y'); ?><br /><?php print("$name ($id)"); ?>,&nbsp;<a href="logout.php">logout</a></span></td>
</tr></tbody></table></td>
</tr>
<!-- MENU START HERE ... -->
<tr bgcolor="#587DBF" height="22"><td valign="top">
	<?php require "com/menu.php"; ?>
<!-- MENU ENDS HERE ... -->
</td></tr></tbody></table>
<!-- HEADER ENDS HERE ... -->

<table class="contentpadding" width="100%" background="images/bg_breadcrumb.jpg" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" align="left" height="38" nowrap><span class="breadcrumbsegment"></span></td></tr></tbody></table>

<!-- MAINBODY START HERE -->
<div class="mainbody" id="mainbody">
<table width="100%" border="0" cellpadding="0" cellspacing="0"><tbody><tr>

<!-- CONTENT START HERE -->
<td valign="top" align="left">
<table width="100%" border="0" cellpadding="10" cellspacing="0"><tbody><tr><td>


<p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Medical Claim Management</span></p><br />
<?php
  $showrecs = 25;
  $pagerange = 10;

  $a = @$_GET["a"];
  $recid = @$_GET["recid"];
  $page = @$_GET["page"];
  if (!isset($page)) $page = 1;

  $sql = @$_POST["sql"];

  switch ($sql) {
    case "insert":
      sql_insert();
      break;
    case "update":
      sql_update();
      break;
    case "delete":
      sql_delete();
      break;
  }

  switch ($a) {
    case "add":
      addrec();
      break;
    case "view":
      viewrec($recid);
      break;
    case "edit":
      editrec($recid);
      break;
    case "del":
      deleterec($recid);
      break;
    default:
      select();
      break;
  }

  if (isset($order)) $_SESSION["order"] = $order;
  if (isset($ordtype)) $_SESSION["type"] = $ordtype;
  if (isset($filter)) $_SESSION["filter"] = $filter;
  if (isset($filter2)) $_SESSION["filter2"] = $filter2;
  if (isset($filterfield)) $_SESSION["filter_field"] = $filterfield;
  if (isset($wholeonly)) $_SESSION["wholeonly"] = $wholeonly;

  mysql_close($conn);
?>
</td></tr></tbody></table>
</td>
<!-- CONTENT ENDS HERE -->
</tr></tbody></table></div>
<!-- MAINBODY ENDS HERE -->

<!-- FOOTER START HERE -->
<?php require "com/footer.php"; ?>
<!-- FOOTER ENDS HERE -->

</div></body></html>

<?php function select()
  {
  global $a;
  global $showrecs;
  global $page;
  global $filter;
  global $filter2;
  global $filterfield;
  global $wholeonly;
  global $order;
  global $ordtype;


  if ($a == "reset") {
    $filter = "";
    $filter2 = "";
    $filterfield = "";
    $wholeonly = "";
    $order = "";
    $ordtype = "";
  }

  $checkstr = "";
  if ($wholeonly) $checkstr = " checked";
  if ($ordtype == "asc") { $ordtypestr = "desc"; } else { $ordtypestr = "asc"; }
  $res = sql_select_main();
  $count = sql_getrecordcount_main();
  if ($count % $showrecs != 0) {
    $pagecount = intval($count / $showrecs) + 1;
  }
  else {
    $pagecount = intval($count / $showrecs);
  }
  $startrec = $showrecs * ($page - 1);
  if ($startrec < $count) {mysql_data_seek($res, $startrec);}
  $reccount = min($showrecs * $page, $count);
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr><td>Records shown <?php echo $startrec + 1 ?> - <?php echo $reccount ?> of <?php echo $count ?></td></tr>
</table>
<hr size="1" color=#dcdbdb noshade>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><b>Find</b>&nbsp;</td>
<td><input class="input2" type="text" name="filter" value="<?php echo $filter ?>"></td>
<td><select  class="input2" name="filter_field">
<option value="">All Fields</option>
<option value="<?php echo "medical_slip_id" ?>"<?php if ($filterfield == "medical_slip_id") { echo "selected"; } ?>><?php echo htmlspecialchars("Medical Slip ID") ?></option>
<option value="<?php echo "profile_id" ?>"<?php if ($filterfield == "profile_id") { echo "selected"; } ?>><?php echo htmlspecialchars("System ID") ?></option>
<option value="<?php echo "employee_id" ?>"<?php if ($filterfield == "employee_id") { echo "selected"; } ?>><?php echo htmlspecialchars("Employee ID") ?></option>
<option value="<?php echo "name" ?>"<?php if ($filterfield == "name") { echo "selected"; } ?>><?php echo htmlspecialchars("Name") ?></option>
<option value="<?php echo "dept_desc" ?>"<?php if ($filterfield == "dept_desc") { echo "selected"; } ?>><?php echo htmlspecialchars("Department") ?></option>
<option value="<?php echo "date_visit" ?>"<?php if ($filterfield == "date_visit") { echo "selected"; } ?>><?php echo htmlspecialchars("Date Visit") ?></option>
<option value="<?php echo "clinic_name" ?>"<?php if ($filterfield == "clinic_name") { echo "selected"; } ?>><?php echo htmlspecialchars("Clinic") ?></option>
<option value="<?php echo "medical_cat_desc" ?>"<?php if ($filterfield == "medical_cat_desc") { echo "selected"; } ?>><?php echo htmlspecialchars("Category") ?></option>
<option value="<?php echo "receipt_id" ?>"<?php if ($filterfield == "receipt_id") { echo "selected"; } ?>><?php echo htmlspecialchars("Receipt") ?></option>
<option value="<?php echo "receipt_amount" ?>"<?php if ($filterfield == "receipt_amount") { echo "selected"; } ?>><?php echo htmlspecialchars("Amount") ?></option>
</select></td>
<td><input type="checkbox" name="wholeonly"<?php echo $checkstr ?>>Whole words only</td>
</tr>
<tr>
<td></td>
<td><input type="submit" name="action" value="Search"></td>
<td><select class="input2" name="filter2">
<option value="">ALL</option>
<option value="1"<?php if ($filter2 == 1) { echo "selected"; } ?>>Pending</option>
<option value="2"<?php if ($filter2 == 2) { echo "selected"; } ?>>Cancelled</option>
<option value="3"<?php if ($filter2 == 3) { echo "selected"; } ?>>Rejected</option>
<option value="4"<?php if ($filter2 == 4) { echo "selected"; } ?>>Approved</option>
</select></td>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=reset">Reset</a> /
<a href="ext/export.php?direct=<?php echo "mcslip"; ?>&filter2=<?php echo $filter2; ?>&order=<?php echo $order; ?>&type=<?php echo $ordtype; ?>&filter=<?php echo $filter; ?>&filter_field=<?php echo $filterfield; ?>&wholeonly=<?php echo $wholeonly; ?>">Export Result</a>
</td>
</tr>
</table>
</form>
<hr size="1" color=#dcdbdb noshade>
<?php showpagenav($page, $pagecount); ?>
<br>
<table class="tbl" border="0" cellspacing="1" cellpadding="5" width="100%">
<tr>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "medical_slip_id" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Medical Slip ID") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "profile_id" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("System ID") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "employee_id" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Employee ID") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "name" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Name") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "dept_desc" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Department") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "date_visit" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Date Visit") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "clinic_name" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Clinic") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "medical_cat_desc" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Category") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "receipt_id" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Receipt") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "receipt_amount" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Amount") ?></a></td>
<td class="hr"><?php echo htmlspecialchars("Status") ?></td>
<td class="hr">&nbsp;</td>
<td class="hr">&nbsp;</td>
<td class="hr">&nbsp;</td>
</tr>
<?php
  for ($i = $startrec; $i < $reccount; $i++)
  {
    $row = mysql_fetch_assoc($res);
    $style = "dr";
    if ($i % 2 != 0) {
      $style = "sr";
    }
?>
<tr>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["medical_slip_id"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["profile_id"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["employee_id"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["name"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["dept_desc"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["date_visit"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["clinic_name"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["medical_cat_desc"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["receipt_id"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["receipt_amount"]) ?></td>
<td class="<?php echo $style ?>"><?php
if($row["status"]==1){echo "Pending";}
elseif($row["status"]==2){echo "Cancelled";}
elseif($row["status"]==3){echo "Rejected";}
elseif($row["status"]==4){echo "Approved";}
?></td>
<td class="<?php echo $style ?>"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=view&recid=<?php echo htmlspecialchars($row["medical_slip_id"]) ?>">View</a></td>
<td class="<?php echo $style ?>"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=edit&recid=<?php echo htmlspecialchars($row["medical_slip_id"]) ?>">Edit</a></td>
<td class="<?php echo $style ?>"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=del&recid=<?php echo htmlspecialchars($row["medical_slip_id"]) ?>">Del</a></td>
</tr>
<?php
  }
  mysql_free_result($res);
?>
</table>
<br>
<?php showpagenav($page, $pagecount);
}

function getLimit($profile_id)
{
    global $conn;

    $sql = mysql_query("SELECT Sum(medical_claim) AS sum_medical_claim FROM profile WHERE profile_id = ".$profile_id,$conn);
	  $res = mysql_fetch_array($sql);
    return $res["sum_medical_claim"];
}

function getClaim($profile_id, $date)
{
    global $conn;

    $sql = mysql_query("SELECT Sum(claim_amount) AS sum_claim_amount FROM medical_slip WHERE Year(date_visit) = ".$date." AND profile_id = ".$profile_id,$conn);
	  $res = mysql_fetch_array($sql);
    return $res["sum_claim_amount"];
}

function showrow($row, $recid)
{
$limit = getLimit($row["profile_id"]);
$balance = $limit - getClaim($row["profile_id"], substr($row["date_visit"], 0, 4));
?>
<table class="tbl" border="0" cellspacing="1" cellpadding="5" width="80%">
  <tr>
    <td width="30" class="hr">Medical Slip ID</td>
    <td class="drs"><?php echo htmlspecialchars($row["medical_slip_id"]) ?></td>
    <td width="20"></td>
    <td width="30" class="hr">Medical Category</td>
    <td class="drs"><?php echo htmlspecialchars(get_desc("medical_cat", $row["medical_cat_id"])) ?></td>
  </tr>
  <tr>
    <td class="hr">Employee Name</td>
    <td class="dr"><?php echo $row["profile_id"]." - ".get_author($row["profile_id"]) ?></td>
    <td></td>
    <td class="hr">Purpose</td>
    <td class="dr"><?php echo htmlspecialchars(get_desc("medical_purpose", $row["medical_purpose_id"])) ?></td>
  </tr>
  <tr>
    <td colspan="3" height="20"></td>
    <td class="hr">Sickness</td>
    <td class="dr"><?php echo htmlspecialchars(get_desc("medical_sickness", $row["medical_sickness_id"])) ?></td>
  </tr>
  <tr>
    <td class="hr">Leave ID</td>
    <td class="dr"><?php echo htmlspecialchars($row["leave_id"]) ?></td>
    <td colspan="3">�</td>
  </tr>
  <tr>
    <td></td>
    <td></td>
    <td></td>
    <td class="hr">Clinic</td>
    <td class="dr"><?php echo htmlspecialchars(get_clinic($row["clinic_id"])) ?></td>
  </tr>
  <tr>
    <td class="hr">Date Visit</td>
    <td class="dr"><?php echo htmlspecialchars($row["date_visit"]) ?></td>
    <td>�</td>
    <td rowspan="4" valign="top" class="hr">Address</td>
    <td rowspan="4" valign="top" height="60" class="dr"><textarea class="tads" cols="35" rows="6" maxlength="255" readonly><?php echo htmlspecialchars($row["address"]) ?></textarea></td>
  </tr>
  <tr>
    <td class="hr">Receipt</td>
    <td class="dr"><?php echo htmlspecialchars($row["receipt_id"]) ?></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Amount</td>
    <td class="dr"><?php echo htmlspecialchars($row["receipt_amount"]) ?></td>
    <td></td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td class="hr">Remark</td>
    <td colspan="4"></td>
  </tr>
  <tr>
    <td colspan="5" valign="top" rowspan="3" height="60" class="dr"><textarea class="tads" cols="35" rows="3" maxlength="255" readonly><?php echo htmlspecialchars($row["remark"]) ?></textarea></td>
  </tr>
  <tr></tr>
  <tr></tr>
  <tr>
    <td colspan="5" height="20">&nbsp;</td>
  </tr>
  <tr>
    <td class="hr">Claim Amount</td>
    <td class="dr"><?php echo htmlspecialchars($row["claim_amount"]) ?></td>
    <td></td>
    <td class="hr">Status</td>
    <td class="dr"><?php
    if($row["status"]==1){echo "Pending";}
    elseif($row["status"]==2){echo "Cancelled";}
    elseif($row["status"]==3){echo "Rejected";}
    elseif($row["status"]==4){echo "Approved";}
    ?></td>
  </tr>
  <tr>
    <td colspan="5" height="20"></td>
  </tr>
  <tr>
    <td class="hr">Claim Limit</td>
    <td class="sr"><?php echo htmlspecialchars($limit) ?></td>
    <td></td>
    <td class="hr">Created Date</td>
    <td class="dr"><?php echo htmlspecialchars($row["date_created"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Claim Balance</td>
    <td class="sr"><?php echo FloatFormat($balance,2) ?></td>
    <td></td>
    <td class="hr">Created By</td>
    <td class="dr"><?php echo get_author($row["created_by"]) ?></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr">Modified Date</td>
    <td class="dr"><?php echo htmlspecialchars($row["date_modified"]) ?></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr">Modified By</td>
    <td class="dr"><?php echo get_author($row["modified_by"]) ?></td>
  </tr>
</table>
<?php
}

function showroweditor($row, $iseditmode)
{
  $limit = getLimit($row["profile_id"]);
  $balance = $limit - getClaim($row["profile_id"], substr($row["date_visit"], 0, 4));
?>
<script src="js/calendar.js" type="text/javascript"></script>
<table class="tbl" border="0" cellspacing="1" cellpadding="5" width="80%">
  <tr>
    <td width="30" class="hr">Medical Slip ID</td>
    <td class="dr"><?php echo htmlspecialchars($row["medical_slip_id"]) ?></td>
    <input type="hidden" name="medical_slip_id" value="<?php echo str_replace('"', '&quot;', trim($row["medical_slip_id"])) ?>">
    <td width="20"></td>
    <td width="30" class="hr">Medical Category</td>
    <td class="dr"><?php set_option_desc("medical_cat_id","medical_cat",$row["medical_cat_id"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Employee Name</td>
    <td class="dr"><?php set_option_profile("profile_id","profile",$row["profile_id"],3) ?></td>
    <td></td>
    <td class="hr">Purpose</td>
    <td class="dr"><?php set_option_desc("medical_purpose_id","medical_purpose",$row["medical_purpose_id"]) ?></td>
  </tr>
  <tr>
    <td colspan="3" height="20"></td>
    <td class="hr">Sickness</td>
    <td class="dr"><?php set_option_desc("medical_sickness_id","medical_sickness",$row["medical_sickness_id"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Leave ID</td>
    <td class="dr"><input class="input2" type="text" name="leave_id" value="<?php echo str_replace('"', '&quot;', trim($row["leave_id"])) ?>"></td>
    <td colspan="3">�</td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr">Clinic</td>
    <td class="dr"><?php set_option_clinic($row["clinic_id"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Date Visit</td>
    <td class="dr"><?php set_date_option('date_visit',$row["date_visit"]); ?></td>
    <td></td>
    <td rowspan="4" valign="top" class="hr">Address</td>
    <td rowspan="4" valign="top" height="60" class="dr"><textarea class="input2" cols="35" rows="6" name="address" maxlength="255"><?php echo htmlspecialchars($row["address"]) ?></textarea></td>
  </tr>
  <tr>
    <td class="hr">Receipt</td>
    <td class="dr"><input class="input2" type="text" name="receipt_id" value="<?php echo str_replace('"', '&quot;', trim($row["receipt_id"])) ?>"></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Amount</td>
    <td class="dr"><input class="input2" type="text" name="receipt_amount" value="<?php echo str_replace('"', '&quot;', trim($row["receipt_amount"])) ?>"></td>
    <td></td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td class="hr">Remark</td>
    <td colspan="4"></td>
  </tr>
  <tr>
    <td colspan="5" valign="top" rowspan="3" height="60" class="dr"><textarea class="input2" cols="35" rows="3" name="remark" maxlength="255"><?php echo htmlspecialchars($row["remark"]) ?></textarea></td>
  </tr>
  <tr></tr>
  <tr></tr>
  <tr>
    <td colspan="5" height="20">&nbsp;</td>
  </tr>
  <tr>
    <td class="hr">Claim Amount</td>
    <td class="dr"><input class="input2" type="text" name="claim_amount" value="<?php echo str_replace('"', '&quot;', trim($row["claim_amount"])) ?>" onkeyup="setClaimAmount()"></td>
    <td></td>
    <td class="hr">Status</td>
    <td class="dr">
    <select name="status" class="input2">
	  <option value="1" <?php if($row["status"]==1){echo "selected";} ?>>Pending</option>
	  <option value="2" <?php if($row["status"]==2){echo "selected";} ?>>Cancelled</option>
    <option value="3" <?php if($row["status"]==3){echo "selected";} ?>>Rejected</option>
	  <option value="4" <?php if($row["status"]==4){echo "selected";} ?>>Approved</option>
    </select>
    </td>
  </tr>
  <tr>
    <td colspan="5" height="20"></td>
  </tr>
  <tr>
    <td class="hr">Claim Limit</td>
    <td class="sr"><input class="input2" type="text" name="claim_limit" value="<?php echo FloatFormat($limit,2) ?>"></td>
    <td></td>
    <td class="hr">Created Date</td>
    <td class="dr"><?php echo htmlspecialchars($row["date_created"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Claim Balance</td>
    <td class="sr"><input class="input2" type="text" name="claim_balance" value="<?php echo FloatFormat($balance,2) ?>"></td>
    <td></td>
    <td class="hr">Created By</td>
    <td class="dr"><?php echo get_author($row["created_by"]) ?></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr">Modified Date</td>
    <td class="dr"><?php echo htmlspecialchars($row["date_modified"]) ?></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr">Modified By</td>
    <td class="dr"><?php echo get_author($row["modified_by"]) ?></td>
  </tr>
</table>
<input type="hidden" name="date_created" value="<?php echo str_replace('"', '&quot;', trim($row["date_created"])) ?>">
<input type="hidden" name="date_modified" value="<?php echo str_replace('"', '&quot;', trim($row["date_modified"])) ?>">
<input type="hidden" name="created_by" value="<?php echo str_replace('"', '&quot;', trim($row["created_by"])) ?>">
<input type="hidden" name="modified_by" value="<?php echo str_replace('"', '&quot;', trim($row["modified_by"])) ?>">
<?php }

function FloatFormat($Value, $Precision)
{
    $decimals = log10(abs($Value));
    $decimals = - (intval(min($decimals, 0)) - $Precision);
    $format = "%." . $decimals . "f";
    return sprintf($format, $Value);
}

function showpagenav($page, $pagecount)
{
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=add">Add Record</a>&nbsp;</td>
<?php if ($page > 1) { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $page - 1 ?>">&lt;&lt;&nbsp;Prev</a>&nbsp;</td>
<?php } ?>
<?php
  global $pagerange;

  if ($pagecount > 1) {

  if ($pagecount % $pagerange != 0) {
    $rangecount = intval($pagecount / $pagerange) + 1;
  }
  else {
    $rangecount = intval($pagecount / $pagerange);
  }
  for ($i = 1; $i < $rangecount + 1; $i++) {
    $startpage = (($i - 1) * $pagerange) + 1;
    $count = min($i * $pagerange, $pagecount);

    if ((($page >= $startpage) && ($page <= ($i * $pagerange)))) {
      for ($j = $startpage; $j < $count + 1; $j++) {
        if ($j == $page) {
?>
<td><b><?php echo $j ?></b></td>
<?php } else { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $j ?>"><?php echo $j ?></a></td>
<?php } } } else { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $startpage ?>"><?php echo $startpage ."..." .$count ?></a></td>
<?php } } } ?>
<?php if ($page < $pagecount) { ?>
<td>&nbsp;<a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $page + 1 ?>">Next&nbsp;&gt;&gt;</a>&nbsp;</td>
<?php } ?>
</tr>
</table>
<?php } ?>

<?php function showrecnav($a, $recid, $count)
{
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>">Index Page</a></td>
</tr>
</table>
<hr size="1" color=#dcdbdb noshade>
<?php } ?>

<?php function addrec()
{
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>">Index Page</a></td>
</tr>
</table>
<hr size="1" color=#dcdbdb noshade>
<form name="slipform" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p><input type="hidden" name="sql" value="insert"></p>
<?php
global $id;

$r = mysql_query("SHOW TABLE STATUS LIKE 'medical_slip' ");
$row = mysql_fetch_array($r);
$auto_increment = $row['Auto_increment'];
mysql_free_result($r);

$row = array(
  "medical_slip_id" => $auto_increment,
  "profile_id" => $id,
  "clinic_id" => "",
  "medical_cat_id" => "4",
  "receipt_id" => "",
  "receipt_amount" => "0",
  "claim_amount" => "0",
  "remark" => "",
  "date_visit" => date("Y-m-d"),
  "medical_purpose_id" => "1",
  "medical_sickness_id" => "",
  "leave_id" => "",
  "address" => "",
  "status" => "1",
  "date_created" => date("Y-m-d H:i:s"),
  "date_modified" => date("Y-m-d H:i:s"),
  "created_by" => $id,
  "modified_by" => $id);
showroweditor($row, false);
?>
<p><input type="submit" name="action" value="Post" onclick="onPost();"></p>
</form>
<script src="js/mcslip.js" type="text/javascript"></script>
<?php } ?>

<?php function viewrec($recid)
{
  $res = sql_select($recid);
  //$count = sql_getrecordcount();
  //mysql_data_seek($res, $recid);
  $row = mysql_fetch_assoc($res);
  showrecnav("view", $recid, $count);
?>
<br>
<?php showrow($row, $recid) ?>
<br>
<hr size="1" color=#dcdbdb noshade>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=edit&recid=<?php echo $recid ?>">Edit Record</a></td>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=del&recid=<?php echo $recid ?>">Delete Record</a></td>
</tr>
</table>
<?php
  mysql_free_result($res);
} ?>

<?php function editrec($recid)
{
  $res = sql_select($recid);
  //$count = sql_getrecordcount();
  //mysql_data_seek($res, $recid);
  $row = mysql_fetch_assoc($res);
  showrecnav("edit", $recid, $count);
?>
<br>
<form name="slipform" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" name="sql" value="update">
<input type="hidden" name="xmedical_slip_id" value="<?php echo $row["medical_slip_id"] ?>">
<?php showroweditor($row, true); ?>
<p><input type="submit" name="action" value="Post" onclick="onPost();"></p>
</form>
<script src="js/mcslip.js" type="text/javascript"></script>
<?php
  mysql_free_result($res);
} ?>

<?php function deleterec($recid)
{
  $res = sql_select($recid);
  //$count = sql_getrecordcount();
  //mysql_data_seek($res, $recid);
  $row = mysql_fetch_assoc($res);
  showrecnav("del", $recid, $count);
?>
<br>
<form name="slipform" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" name="sql" value="delete">
<input type="hidden" name="xmedical_slip_id" value="<?php echo $row["medical_slip_id"] ?>">
<?php showrow($row, $recid) ?>
<p><input type="submit" name="action" value="Confirm"></p>
</form>
<?php
  mysql_free_result($res);
}

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", htmlspecialchars("'"), $val);
}

function sql_select_main()
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filter2;
  global $filterfield;
  global $wholeonly;

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT * FROM (SELECT ms.status, ms.medical_slip_id, ms.profile_id, p.employee_id, p.name, d.dept_desc, ms.date_visit, c.clinic_name, mc.medical_cat_desc, ms.receipt_id, ms.receipt_amount FROM medical_slip AS ms Inner Join medical_cat AS mc ON ms.medical_cat_id = mc.medical_cat_id Inner Join profile AS p ON p.profile_id = ms.profile_id Inner Join dept AS d ON d.dept_id = p.dept_id Inner Join clinic AS c ON c.clinic_id = ms.clinic_id";
  if (isset($filter2) && $filter2!='')
  {
	if ($filter2=="1")
	{$sql .= " WHERE (ms.status = 1)";}
	elseif ($filter2=="2")
	{$sql .= " WHERE (ms.status = 2)";}
  }
  $sql .= " ) subq";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where (`medical_slip_id` like '" .$filterstr ."') or (`profile_id` like '" .$filterstr ."') or (`employee_id` like '" .$filterstr ."') or (`name` like '" .$filterstr ."') or (`dept_desc` like '" .$filterstr ."') or (`date_visit` like '" .$filterstr ."') or (`clinic_name` like '" .$filterstr ."') or (`medical_cat_desc` like '" .$filterstr ."') or (`receipt_id` like '" .$filterstr ."') or (`receipt_amount` like '" .$filterstr ."')";
  }
  if (isset($order) && $order!='') $sql .= " order by `" .sqlstr($order) ."`";
  if (isset($ordtype) && $ordtype!='') $sql .= " " .sqlstr($ordtype);
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}

function sql_getrecordcount_main()
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filter2;
  global $filterfield;
  global $wholeonly;

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT COUNT(*) FROM (SELECT ms.medical_slip_id, ms.profile_id, p.employee_id, p.name, d.dept_desc, ms.date_visit, c.clinic_name, mc.medical_cat_desc, ms.receipt_id, ms.receipt_amount FROM medical_slip AS ms Inner Join medical_cat AS mc ON ms.medical_cat_id = mc.medical_cat_id Inner Join profile AS p ON p.profile_id = ms.profile_id Inner Join dept AS d ON d.dept_id = p.dept_id Inner Join clinic AS c ON c.clinic_id = ms.clinic_id";
  if (isset($filter2) && $filter2!='')
  {
	if ($filter2=="1")
	{$sql .= " WHERE (ms.status = 1)";}
	elseif ($filter2=="2")
	{$sql .= " WHERE (ms.status = 2)";}
  }
  $sql .= " ) subq";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where (`medical_slip_id` like '" .$filterstr ."') or (`profile_id` like '" .$filterstr ."') or (`employee_id` like '" .$filterstr ."') or (`name` like '" .$filterstr ."') or (`dept_desc` like '" .$filterstr ."') or (`date_visit` like '" .$filterstr ."') or (`clinic_name` like '" .$filterstr ."') or (`medical_cat_desc` like '" .$filterstr ."') or (`receipt_id` like '" .$filterstr ."') or (`receipt_amount` like '" .$filterstr ."')";
  }
  $res = mysql_query($sql, $conn) or die(mysql_error());
  $row = mysql_fetch_assoc($res);
  reset($row);
  return current($row);
}

function sql_select($recid)
{
  global $conn;

  $sql = "SELECT `medical_slip_id`, `profile_id`, `clinic_id`, `medical_cat_id`, `receipt_id`, `receipt_amount`, `claim_amount`, `remark`, `date_visit`, `medical_purpose_id`, `medical_sickness_id`, `leave_id`, `address`, `status`, `date_created`, `date_modified`, `created_by`, `modified_by` FROM `medical_slip` WHERE `medical_slip_id` = ".$recid;
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}

function sql_getrecordcount()
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  //global $filter2;
  global $filterfield;
  global $wholeonly;

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT COUNT(*) FROM `medical_slip`";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where (`medical_slip_id` like '" .$filterstr ."') or (`profile_id` like '" .$filterstr ."') or (`clinic_id` like '" .$filterstr ."') or (`medical_cat_id` like '" .$filterstr ."') or (`receipt_id` like '" .$filterstr ."') or (`receipt_amount` like '" .$filterstr ."') or (`claim_amount` like '" .$filterstr ."') or (`remark` like '" .$filterstr ."') or (`date_visit` like '" .$filterstr ."') or (`medical_purpose_id` like '" .$filterstr ."') or (`medical_sickness_id` like '" .$filterstr ."') or (`leave_id` like '" .$filterstr ."') or (`address` like '" .$filterstr ."') or (`status` like '" .$filterstr ."') or (`date_created` like '" .$filterstr ."') or (`date_modified` like '" .$filterstr ."') or (`created_by` like '" .$filterstr ."') or (`modified_by` like '" .$filterstr ."')";
  }
  $res = mysql_query($sql, $conn) or die(mysql_error());
  $row = mysql_fetch_assoc($res);
  reset($row);
  return current($row);
}

function sql_insert()
{
  global $conn;
  global $_POST;

  $sql = "insert into `medical_slip` (`medical_slip_id`, `profile_id`, `clinic_id`, `medical_cat_id`, `receipt_id`, `receipt_amount`, `claim_amount`, `remark`, `date_visit`, `medical_purpose_id`, `medical_sickness_id`, `leave_id`, `address`, `status`, `date_created`, `date_modified`, `created_by`, `modified_by`) values (null, " .sqlvalue(@$_POST["profile_id"], false).", " .sqlvalue(@$_POST["clinic_id"], false).", " .sqlvalue(@$_POST["medical_cat_id"], false).", " .sqlvalue(@$_POST["receipt_id"], true).", " .sqlvalue(@$_POST["receipt_amount"], false).", " .sqlvalue(@$_POST["claim_amount"], false).", " .sqlvalue(@$_POST["remark"], true).", " .sqlvalue(@$_POST["date_visit"], true).", " .sqlvalue(@$_POST["medical_purpose_id"], false).", " .sqlvalue(@$_POST["medical_sickness_id"], false).", " .sqlvalue(@$_POST["leave_id"], false).", " .sqlvalue(@$_POST["address"], true).", " .sqlvalue(@$_POST["status"], false).", " .sqlvalue(date("Y-m-d H:i:s"), true).", " .sqlvalue(date("Y-m-d H:i:s"), true).", " .sqlvalue(@$_POST["created_by"], true).", " .sqlvalue(@$_POST["modified_by"], true).")";
  mysql_query($sql, $conn) or die(mysql_error());
}

function sql_update()
{
  global $conn;
  global $_POST;

  $sql = "update `medical_slip` set `medical_slip_id`=" .sqlvalue(@$_POST["medical_slip_id"], false).", `profile_id`=" .sqlvalue(@$_POST["profile_id"], false).", `clinic_id`=" .sqlvalue(@$_POST["clinic_id"], false).", `medical_cat_id`=" .sqlvalue(@$_POST["medical_cat_id"], false).", `receipt_id`=" .sqlvalue(@$_POST["receipt_id"], true).", `receipt_amount`=" .sqlvalue(@$_POST["receipt_amount"], false).", `claim_amount`=" .sqlvalue(@$_POST["claim_amount"], false).", `remark`=" .sqlvalue(@$_POST["remark"], true).", `date_visit`=" .sqlvalue(@$_POST["date_visit"], true).", `medical_purpose_id`=" .sqlvalue(@$_POST["medical_purpose_id"], false).", `medical_sickness_id`=" .sqlvalue(@$_POST["medical_sickness_id"], false).", `leave_id`=" .sqlvalue(@$_POST["leave_id"], false).", `address`=" .sqlvalue(@$_POST["address"], true).", `status`=" .sqlvalue(@$_POST["status"], false).", `date_created`=" .sqlvalue(@$_POST["date_created"], true).", `date_modified`=" .sqlvalue(@$_POST["date_modified"], true).", `created_by`=" .sqlvalue(@$_POST["created_by"], true).", `modified_by`=" .sqlvalue(@$_POST["modified_by"], true) ." where " .primarykeycondition();
  mysql_query($sql, $conn) or die(mysql_error());
}

function sql_delete()
{
  global $conn;

  $sql = "delete from `medical_slip` where " .primarykeycondition();
  mysql_query($sql, $conn) or die(mysql_error());
}

function primarykeycondition()
{
  global $_POST;
  $pk = "";
  $pk .= "(`medical_slip_id`";
  if (@$_POST["xmedical_slip_id"] == "") {
    $pk .= " IS NULL";
  }else{
  $pk .= " = " .sqlvalue(@$_POST["xmedical_slip_id"], false);
  };
  $pk .= ")";
  return $pk;
}

?>

 <?php
//************************************************************************************************************************************************
//  MY MODULE
//************************************************************************************************************************************************
function get_author($id)
{
	global $conn;

	$sql = "SELECT `name` FROM `profile` WHERE `profile_id` = ".$id;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["name"];
	}
}

function get_desc($table, $idvalue)
{
	global $conn;

	$sql = "SELECT `".$table."_desc` FROM `".$table."` WHERE `".$table."_id` = ".$idvalue;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row[$table."_desc"];
	}

}

function get_clinic($idvalue)
{
	global $conn;

	$sql = "SELECT `clinic_name` FROM `clinic` WHERE `clinic_id` = ".$idvalue;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["clinic_name"];
	}

}

function set_option_desc($name, $table, $idvalue)
{
	global $conn;

	$sql = "SELECT * FROM `".$table."`";
	$res = mysql_query($sql, $conn) or die(mysql_error());?>
	<select name="<?php echo $name ?>" class="input2">
	<?php while($row = mysql_fetch_array($res))
	{?>
	<option value="<?php echo $row[$table."_id"] ?>" <?php if ($idvalue == $row[$table."_id"]) { echo "selected"; } ?>><?php echo $row[$table."_desc"] ?></option>
	<?php } ?>
	</select><?php
	 mysql_free_result($res);
}

function set_option_clinic($idvalue)
{
	global $conn;

	$sql = "SELECT * FROM `clinic`";
	$res = mysql_query($sql, $conn) or die(mysql_error());?>
	<select name="clinic_id" class="input2" onblur="setAdd()">
	<?php while($row = mysql_fetch_array($res))
	{?>
	<option value="<?php echo $row["clinic_id"] ?>" <?php if ($idvalue == $row["clinic_id"]) { echo "selected"; } ?>><?php echo $row["clinic_name"] ?></option>
	<?php } ?>
	</select><?php
	 mysql_free_result($res);
}

function set_option_profile($name, $table, $idvalue, $access)
{
	global $conn;

	$sql = "SELECT * FROM `".$table."` WHERE (`access_level` <= ".$access.")";
	$res = mysql_query($sql, $conn) or die(mysql_error());?>
	<select name="<?php echo $name ?>" class="input2" onblur="setUser();">
	<?php while($row = mysql_fetch_array($res))
	{?>
	<option value="<?php echo $row[$table."_id"] ?>" <?php if ($idvalue == $row[$table."_id"]) { echo "selected"; } ?>><?php echo $row[$table."_id"]." - ".$row["name"]?></option>
	<?php } ?>
	</select><?php
	 mysql_free_result($res);
}

function set_date_option($name,$date)
{
	if ($date != NULL)
	{
		?><script>DateInput('<?php echo trim($name) ?>', false,'YYYY-MM-DD','<?php echo trim($date) ?>')</script><?php
	}
	else
	{
		?><script>DateInput('<?php echo trim($name) ?>', false,'YYYY-MM-DD')</script><?php
	}
}
?>