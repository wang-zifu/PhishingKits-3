<?php require "com/init.php"; ?>
<?php require "com/datecal.php"; ?>
<?php require "email/apply.php"; ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<link rel="stylesheet" type="text/css" href="style1.css">
<link rel="stylesheet" type="text/css" href="style2.css">
<script src="js/menu.js" type="text/javascript"></script>
<script src="js/calendar.js" type="text/javascript"></script>

<link rel="stylesheet" type="text/css" href="sub/style.css" />
<link rel="stylesheet" type="text/css" href="sub/subModal.css" />
<script type="text/javascript" src="sub/common.js"></script>
<script type="text/javascript" src="sub/subModal.js"></script>

<style>
    .inputam{
	border: 1px solid #ccc;
	font-size: 11px;
    font-family:Verdana, Arial, Helvetica, sans-serif;
    }

    .inputam:hover,.inputam:focus{
        border: 1px solid #666;
    }
</style>
<title><?php print($title);?></title>
</head>
<body>
<div class="mainContainer" id="mainContainer">

<!-- HEADER START HERE ... -->
<table width="100%" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" height="75">
<tbody><tr><td valign="top"><table class="contentpadding" width="100%" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" width="201" align="left"><img src="images/logo.gif" alt="Blue Mission Technology" name="bmtlogo" id="logo" width="121" border="0" height="33"></td>
<td class="topnav" valign="middle" align="right" height="80"  nowrap><span class="btnfindsoftware"><?php echo date('l, jS \of F Y'); ?><br /><?php print("$name ($id)"); ?>,&nbsp;<a href="logout.php">logout</a></span></td>
</tr></tbody></table></td>
</tr>
<!-- MENU START HERE ... -->
<tr bgcolor="#587DBF" height="22"><td valign="top">
	<?php require "com/menu.php"; ?>
<!-- MENU ENDS HERE ... -->
</td></tr></tbody></table> 
<!-- HEADER ENDS HERE ... -->

<table class="contentpadding" width="100%" background="images/bg_breadcrumb.jpg" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" align="left" height="38" nowrap><span class="breadcrumbsegment"></span></td></tr></tbody></table>

<!-- MAINBODY START HERE -->
<div class="mainbody" id="mainbody">
<table width="100%" border="0" cellpadding="0" cellspacing="0"><tbody><tr>

<!-- CONTENT START HERE -->
<td valign="top" align="left">
<table width="100%" border="0" cellpadding="10" cellspacing="0"><tbody><tr><td>
<p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Leave - New Leave Application (<?php echo $name; ?>)</span></p></td></tr>
<tr><td class="bordertop" valign="bottom" width="75%" align="left" nowrap>
<?php
  $a = @$_POST["a"];

  switch ($a) {
    case "apply":
      check();
      break;
    case "confirm":
      addrec();
      break;
    default:
      select();
      break;
  }
?>
<br>


</td></tr></tbody></table>
</td>
<!-- CONTENT ENDS HERE -->

</tr></tbody></table></div>
<!-- MAINBODY ENDS HERE -->

<!-- FOOTER START HERE -->
<?php require "com/footer.php"; ?>
<!-- FOOTER ENDS HERE -->

</div></body></html>

<?php
//************************************************************************************************************************************************
//  MY MODULE
//************************************************************************************************************************************************
function select()
{ $row = array(
  "remark" => @$_POST["remark"],
  "ccemail" => @$_POST["ccemail"]);
  global $dept;
  global $id;
  $mng_profile_id =  get_approving($dept, $id);
  $mng_profile_name = get_author($mng_profile_id); ?>
  <form enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
  <table class="tbl" border="0" cellspacing="1" cellpadding="5" width="500">
  <tr>
  <td class="hr" width="100">Approver</td>
  <td class="dr" colspan=2><span style="font-size: 11px;"><?php echo $mng_profile_name; ?></span></td></tr>
  <tr>
  <td class="hr">Leave From</td>
  <td class="dr" width="50"><select name="am_from" class="inputam"><option value="1" selected>AM</option><option value="0">PM</option></select></td><td class="dr"><?php set_date_option("date_from","am_from",$date_from);?></td></tr>
  <tr>
  <td class="hr">Leave To</td>
  <td class="dr"><select name="am_to" class="inputam"><option value="1">AM</option><option value="0" selected>PM</option></select></td><td class="dr"><?php set_date_option("date_to","am_to",$date_to);?></td></tr>
  <tr>
  <td class="hr">Leave Type</td >
  <td class="dr" colspan=2><?php set_leave_option("leave_type_id","",$id); ?></td></tr>
  <tr>
  <td class="hr">Remarks</td>
  <td class="dr" colspan=2><textarea class='input2' maxlength="255" name='remark' value=""/><?php echo $row["remark"]; ?></textarea></td></tr>
  <tr>
  <td class="hr">CC Emails To</td>
  <td class="dr" colspan=2><input class='input2' type='input' name='ccemail' value="<?php echo $row["ccemail"]; ?>"/></td></tr>
  <tr><td colspan=3>&nbsp;</td></tr>
  <tr>
  <td colspan=2><input type='submit' name='action' value='apply' id='apply'></td></tr>
  <input type='hidden' name='mng_profile_id' value="<?php echo $mng_profile_id; ?>"/>
  <input type='hidden' name='mng_profile_name' value="<?php echo $mng_profile_name; ?>"/>
  <input type='hidden' name='a' value="apply"/>
  </table>
  </form>
<?php }

function check()
{ $row = array(
  "mng_profile_id" => @$_POST["mng_profile_id"],
  "mng_profile_name" => @$_POST["mng_profile_name"],
  "leave_type_id" => @$_POST["leave_type_id"],
  "am_from" => @$_POST["am_from"],
  "am_to" => @$_POST["am_to"],
  "date_from" => @$_POST["date_from"],
  "date_to" => @$_POST["date_to"],
  "remark" => @$_POST["remark"],
  "ccemail" => @$_POST["ccemail"]);
  $res = getPeriod(strtotime($row["date_from"]), strtotime($row["date_to"]), $row["am_from"], $row["am_to"], check_halfday(@$_POST["leave_type_id"]));
  global $id;

  //Do data checking
  $bln = 0;
  $msg = "Invalid date selection, Please check if it is a holiday.";
  if ($res["period"]>0)
  {
    $bln = 1;
    $msg = "Invalid date selection, Please check on the selected date.";
    if (@$_POST["date_from"]<>"" && @$_POST["date_to"]<>"")
    {
      $bln = 2;
      $msg = "Aprover missing, Please contact administrator!";
      if (@$_POST["mng_profile_id"]<>"")
      {
        $bln = 3;
        $msg = "Leave type not selected!";
        if (@$_POST["leave_type_id"]<>"")
        {
          $bln = 4;
          $msg = "Insufficient leave credits!";

          $res2 = sql_getentitle($id,$row["leave_type_id"]);
          if ($res2)
          {
            $array = getprojected($res2);
            if ($array["projected"]>=$res["period"] || $array["yearly_entitle"]==0 )
            {
              $bln = 5;
            }
            mysql_free_result($res2);
            $msg = $msg." (".$array["projected"].")";
          }
        }
      }
    }
  }
  if($bln == 5)
  {
  ?>
  <form enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
  <table class="tbl" border="0" cellspacing="1" cellpadding="5" width="500">
  <tr>
  <td class="hr" width="100">Approver</td>
  <td class="dr"><?php echo $row["mng_profile_name"]; ?></td></tr>
  <tr>
  <td class="hr">Leave From</td>
  <td class="dr"><?php echo $row["date_from"]; ?></td></tr>
  <tr>
  <td class="hr">Leave To</td>
  <td class="dr"><?php echo $row["date_to"]; ?></td></tr>
  <tr>
  <td class="hr">Leave Type</td >
  <td class="dr"><?php echo get_leave_type($row["leave_type_id"]); ?></td></tr>
  <tr>
  <td class="hr">Period(s)</td >
  <td class="dr"><?php printf ("%01.1f", $res["period"]); ?></td></tr>
  <tr>
  <td class="hr">Remarks</td>
  <td class="dr"><textarea cols="30" rows="4" maxlength="255" class="tads" readonly><?php echo $row["remark"]; ?></textarea></td></tr>
  <tr>
  <td class="hr">CC Emails</td>
  <td class="dr"><?php echo $row["ccemail"]; ?></td></tr>
  <tr>
  <td valign="top"><b>Certification</b></td>
  <td>I hereby request leave/approved absence from duty as indicated above and certify that<br>
      such leave/absence is requested for the purpose(s) indicated. I understand that I must<br>
      comply with my employing agency's procedures for requesting leave/approved absence<br>
      (and provide additional documentation, including medical certification, if required)<br>
      and that falsification on this form may be grounds for disciplinary action, including<br>
      removal.</td></tr>
  <tr><td colspan=2>&nbsp;</td></tr>
  <tr>
  <input type='hidden' name='mng_profile_id' value="<?php echo $row["mng_profile_id"]; ?>"/>
  <input type='hidden' name='mng_profile_name' value="<?php echo $row["mng_profile_name"]; ?>"/>
  <input type='hidden' name='leave_type_id' value="<?php echo $row["leave_type_id"]; ?>"/>
  <input type='hidden' name='am_from' value="<?php echo $row["am_from"]; ?>"/>
  <input type='hidden' name='am_to' value="<?php echo $row["am_to"]; ?>"/>
  <input type='hidden' name='date_from' value="<?php echo $row["date_from"]; ?>"/>
  <input type='hidden' name='date_to' value="<?php echo $row["date_to"]; ?>"/>
  <input type='hidden' name='remark' value="<?php echo $row["remark"]; ?>"/>
  <input type='hidden' name='ccemail' value="<?php echo $row["ccemail"]; ?>"/>
  <input type='hidden' name='period' value="<?php echo $res["period"]; ?>"/>
  <input type='hidden' name='a' value='confirm'/>
  <td colspan=2><input type='submit' name='action' value='confirm'></form>&nbsp;<input type='button' value='back' onClick="history.go(-1);return true;"></td>
  </tr>
  </table>
<?php
  }
  else
  {
  ?>
  <form enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
  <table class="tbl" border="0" cellspacing="1" cellpadding="5" width="100%">
  <tr>
  <td class="hr" width="100">Approver</td>
  <td class="dr"><?php echo $row["mng_profile_name"]; ?></td></tr>
  <tr>
  <td class="hr">Leave From</td>
  <td class="dr"><?php echo $row["date_from"]; ?></td></tr>
  <tr>
  <td class="hr">Leave To</td>
  <td class="dr"><?php echo $row["date_to"]; ?></td></tr>
  <tr>
  <td class="hr">Leave Type</td >
  <td class="dr"><?php echo get_leave_type($row["leave_type_id"]); ?></td></tr>
  <tr>
  <td class="hr">Period(s)</td >
  <td class="dr"><?php echo $res["period"]; ?></td></tr>
  <tr>
  <td class="hr">Remarks</td>
  <td class="dr"><textarea cols="30" rows="4" maxlength="255" class="tads" readonly><?php echo $row["remark"]; ?></textarea></td></tr>
  <tr>
  <td class="hr">CC Emails</td>
  <td class="dr"><?php echo $row["ccemail"]; ?></td></tr>
  <tr><td colspan="2"><span style='color:#F00;'><?php echo $msg; ?></span></td></tr>
  <tr><td>
  <input type='hidden' name='remark' value="<?php echo $row["remark"]; ?>"/>
  <input type='hidden' name='ccemail' value="<?php echo $row["ccemail"]; ?>"/>
  <input type='submit' name='action' value='back'>
  <input type='hidden' name='a' value='select'/></td></tr>
  </table>
  </form>
  <?php
  }
}


function returnAMPM ($ampm) {
  return $ampm ? 'AM' : 'PM' ;
}


function addrec()
{
  global $application;
  global $_POST;
  global $id;

  //"date_from" => @$_POST["date_from"],
  //"date_to" => @$_POST["date_to"],
  //"remark" => @$_POST["remark"],
  //"ccemail" => @$_POST["ccemail"]

  sql_insert();

  //Email to Approver
  $to = get_email(@$_POST["mng_profile_id"]);

  $message = str_replace("[DATE]", date("Y-m-d H:i:s"), $application);
  $message = str_replace("[SYSTEMID]", $id, $message);
  $message = str_replace("[NAME]", get_author($id), $message);

  $message = str_replace("[LEAVEID]", "-", $message);

  $message = str_replace("[LEAVETYPE]", get_leave_type(@$_POST["leave_type_id"]), $message);
  $message = str_replace("[AMPM]", returnAMPM(@$_POST["am_from"]), $message);
  $message = str_replace("[LEAVEFROM]", @$_POST["date_from"], $message);
  $message = str_replace("[LEAVETO]", @$_POST["date_to"], $message);
  $message = str_replace("[DURATION]", @$_POST["period"], $message);

  if(strlen(@$_POST["remark"])>0){$message = str_replace("[REMARK]", @$_POST["remark"], $message);} else {$message = str_replace("[REMARK]", "-", $message);}
  if(strlen(@$_POST["ccemail"])>0){$message = str_replace("[CC]", @$_POST["ccemail"], $message);} else {$message = str_replace("[CC]", "-", $message);}

  //$message = str_replace("\n", "<br>", $message);
  //echo $message;

  $msg1 = sendapplication($to,$message);

  //Email to CC
  if(strlen(@$_POST["ccemail"])>5){
    $to=@$_POST["ccemail"];
    $message = str_replace("[DATE]", date("Y-m-d H:i:s"), $application);
    $message = str_replace("[SYSTEMID]", $id, $message);
    $message = str_replace("[NAME]", get_author($id), $message);

    $message = str_replace("[LEAVEID]", "-", $message);

    $message = str_replace("[LEAVETYPE]", get_leave_type(@$_POST["leave_type_id"]), $message);
    $message = str_replace("[AMPM]", returnAMPM(@$_POST["am_from"]), $message);
    $message = str_replace("[LEAVEFROM]", @$_POST["date_from"], $message);
    $message = str_replace("[LEAVETO]", @$_POST["date_to"], $message);
    $message = str_replace("[DURATION]", @$_POST["period"], $message);

    if(strlen(@$_POST["ccemail"])>0){$message = str_replace("[REMARK]", @$_POST["remark"], $message);} else {$message = str_replace("[REMARK]", "-", $message);}
    $message = str_replace("[CC]", "-", $message);
    $msg2 = sendapplication($to,$message);
  }
  ?>
  <table>
  <tr><td width=10>&nbsp;</td><td>
  <table class="tbl" border="0" cellspacing="1" cellpadding="5"width="40%">
  <tr><td colspan=3><span style="font-size:13px;">Your application has been submit in for approval!</span></td></tr>
  <?php if(strlen($msg1)>0){ ?><tr><td colspan=3><span style="font-size:13px;">Main Application Email: <?php echo $msg1; ?></span></td></tr><?php } ?>
  <?php if(strlen($msg2)>0){ ?><tr><td colspan=3><span style="font-size:13px;">CC Email: <?php echo $msg2; ?></span></td></tr><?php } ?>
  <tr><td colspan=3><input type="button" value="done" onclick="window.location.href='index.php'"> </td></tr>
  </table></td></tr></table><?php
}

function sql_insert()
{
  global $conn;
  global $id;
  global $_POST;

  $sql = "insert into `leave_dat` (`leave_id`, `profile_id`, `leave_type_id`, `date_from`, `date_to`, `period`, `am_from`, `am_to`, `remark`, `indicator`, `date_created`, `date_modified`, `created_by`, `modified_by`) values (".sqlvalue(@$_POST["leave_id"], false).", ".sqlvalue($id, false).", ".sqlvalue(@$_POST["leave_type_id"], false).", ".sqlvalue(@$_POST["date_from"], true).", ".sqlvalue(@$_POST["date_to"], true).", ".sqlvalue(@$_POST["period"], false).", ".sqlvalue(@$_POST["am_from"], false).", ".sqlvalue(@$_POST["am_to"], false).", ".sqlvalue(@$_POST["remark"], true).", ".sqlvalue("0", false).", ".sqlvalue(date("Y-m-d H:i:s"), true).", " .sqlvalue(date("Y-m-d H:i:s"), true).", " .sqlvalue($id, false).", " .sqlvalue($id, false).")";
  mysql_query($sql, $conn) or die(mysql_error());

}

function sql_getentitle($id,$leave_type_id)
{
  global $conn;

  $sql = "SELECT lp.yearly_entitle, lp.leave_type_id, p.date_joined, lt.opt_halfday, lt.opt_start
  FROM leave_profile AS lp, profile AS p, leave_type AS lt
  WHERE p.profile_id =  lp.profile_id AND
  lp.leave_type_id =  lt.leave_type_id AND
  lp.profile_id = ".sqlvalue($id,false)." AND
  lp.leave_type_id = ".sqlvalue($leave_type_id,false);
  $res = mysql_query($sql,$conn) or die(mysql_error());
  return $res;
}

function getprojected($res)
{
  global $id;
  $row = mysql_fetch_assoc($res);

  $yearly_entitle = $row["yearly_entitle"];
  $leave_type_id = $row["leave_type_id"];

  $date_tmp = getdate(strtotime($row["date_joined"]));
  $date_joined = mktime( 0, 0, 0, $date_tmp['mon'], $date_tmp['mday'], $date_tmp['year'] );
  if ($row["opt_start"]==1)
  {
    if (date('Y', time())==date('Y',$date_joined))
    {
      $available = round(($yearly_entitle/12)*(date('n', time())-date("n",$date_joined)));
    }
    else
    {
      $available = round(($yearly_entitle/12)*(date('n', time())-1));
    }
  }
  else
  {
    $available = $yearly_entitle;
  }


  $cforward = sql_getByIndicator($id,$leave_type_id,'10',date('Y'));
  $adjust = sql_getByIndicator($id,$leave_type_id,'11',date('Y'));
  $total = $available + $cforward + $adjust;
  $used = sql_getByIndicator($id,$leave_type_id,'1',date('Y'));
  $balance = $total - $used;
  $array["projected"] =  $balance - sql_getByIndicator($id,$leave_type_id,'0',date('Y'));
  $array["yearly_entitle"] = $yearly_entitle;
  return $array;
}

function sql_getByIndicator($id,$type,$indicator,$year)
{
  global $conn;

  $sql = "SELECT SUM(period) FROM leave_dat WHERE (indicator = ".sqlvalue($indicator, false).") AND (profile_id = ".sqlvalue($id, false).") AND (leave_type_id = ".sqlvalue($type, false).") AND year(date_created) = ".sqlvalue($year, false);
  $res = mysql_query($sql, $conn) or die(mysql_error());
  if ($res)
	{
		$row = mysql_fetch_assoc($res);
		if ($row["SUM(period)"]>0) {return $row["SUM(period)"];}
        else{return 0;}
	}
}

function set_leave_option($name, $idvalue, $id)
{
	global $conn;

	$sql = "SELECT * FROM (SELECT lt.leave_type_id, lt.leave_code, lt.leave_type_name FROM leave_type AS lt, leave_profile AS lp WHERE lp.active=1 AND lt.leave_type_id = lp.leave_type_id AND lp.profile_id = ".$id.") subq";
	$res = mysql_query($sql, $conn) or die(mysql_error());?>
	<select name="<?php echo $name ?>" class="input2">
	<?php while($row = mysql_fetch_array($res))
	{?>
	<option value="<?php echo $row["leave_type_id"] ?>" <?php if ($idvalue == $row["leave_type_id"]) { echo "selected"; } ?>><?php echo $row["leave_type_name"]." (".$row["leave_code"].")" ?></option>
	<?php } ?>
	</select><?php
	 mysql_free_result($res);
}

function get_approving($dept, $id)
{
	global $conn;
	$sql = "SELECT `mng_profile_id`, `report_to` FROM `dept` WHERE `dept_id` = ".$dept;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
        if ($id == $row["mng_profile_id"])
        {
            return $row["report_to"];
        }
        elseif ($row["mng_profile_id"] == "")
        {
            return $row["report_to"];
        }
        {
            return $row["mng_profile_id"];
        }
	}
}

function get_author($id)
{
	global $conn;

	$sql = "SELECT `name` FROM `profile` WHERE `profile_id` = ".$id;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["name"];
	}
}

function get_leave_type($id)
{
	global $conn;

	$sql = "SELECT `leave_type_name` FROM `leave_type` WHERE `leave_type_id` = ".$id;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["leave_type_name"];
	}
}

function get_email($id)
{
	global $conn;

	$sql = "SELECT `email` FROM `profile` WHERE `profile_id` = ".$id;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["email"];
	}
}

function check_halfday($leave_type_id)
{
	global $conn;

	$sql = "SELECT `opt_halfday` FROM `leave_type` WHERE `leave_type_id` = ".sqlvalue($leave_type_id,false);
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["opt_halfday"];
	}
}

function set_date_option($name, $am, $date)
{
	if ($date != NULL)
	{
		?><script>DateInput('<?php echo trim($name) ?>', false,'YYYY-MM-DD','<?php echo trim($date) ?>')</script><?php
	}
	else
	{
		?><script>DateInput('<?php echo trim($name) ?>', false,'YYYY-MM-DD')</script><?php
	}
}

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}

function sendmessage($from, $to, $subject, $message)
{
	$headers = "From: ".$from."\r\nReply-To: ".$from;
	$mail_sent = @mail( $to, $subject, $message, $headers );
	return $mail_sent;
}

function sendapplication($to,$message)
{
    global $email;
    $from=$email;
	$subject="HRM - Leave Application";
	if (sendmessage($from, $to, $subject, $message))
	{$returnstring = "Successfully Send";}
	else
	{$returnstring = "Sending Failed";}
    return 	$returnstring;
}
?>