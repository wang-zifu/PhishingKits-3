<?php require "com/init.php"; ?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head><link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link rel="stylesheet" type="text/css" href="style1.css">
	<link rel="stylesheet" type="text/css" href="style4.css">
	<script src="js/menu.js" type="text/javascript"></script>

	<link rel="stylesheet" type="text/css" href="sub/style.css" />
	<link rel="stylesheet" type="text/css" href="sub/subModal.css" />
	<script type="text/javascript" src="sub/common.js"></script>
	<script type="text/javascript" src="sub/subModal.js"></script>
	<title><?php print($title); ?></title>
	</head>

<body>
<div class="mainContainer" id="mainContainer">

<!-- HEADER START HERE ... -->
<table width="100%" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" height="75">
<tbody><tr><td valign="top"><table class="contentpadding" width="100%" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" width="201" align="left"><img src="images/logo.gif" alt="Blue Mission Technology" name="bmtlogo" id="logo" width="121" border="0" height="33"></td>
<td class="topnav" valign="middle" align="right" height="80"  nowrap><span class="btnfindsoftware"><?php echo date('l, jS \of F Y'); ?><br /><?php print("$name ($id)"); ?>,&nbsp;<a href="logout.php">logout</a></span></td>
</tr></tbody></table></td>
</tr>
<!-- MENU START HERE ... -->
<tr bgcolor="#587DBF" height="22"><td valign="top">
	<?php require "com/menu.php"; ?>
<!-- MENU ENDS HERE ... -->
</td></tr></tbody></table> 
<!-- HEADER ENDS HERE ... -->

<table class="contentpadding" width="100%" background="images/bg_breadcrumb.jpg" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" align="left" height="38" nowrap><span class="breadcrumbsegment"></span></td></tr></tbody></table>

<!-- MAINBODY START HERE -->
<div class="mainbody" id="mainbody">
<table width="900" border="0" cellpadding="0" cellspacing="0"><tbody><tr>

<!-- CONTENT START HERE -->
<td valign="top" align="left">
<table width="100%" border="0" cellpadding="10" cellspacing="0"><tbody><tr><td>


<p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry"> Medical Claim - New Application</span></p><br />
<?php
  $sql = @$_POST["sql"];

  if($sql=="insert")
  {
    sql_insert();
    ?>
    <hr size="1" color=#dcdbdb noshade>  
    <table class="tbl" border="0" cellspacing="1" cellpadding="5"width="40%">
    <tr><td colspan=3><span style="font-size:13px;">Your application has been submit in for approvel!</span></td></tr>
    <tr><td colspan=3><input type="button" value="done" onclick="window.location.href='index.php'"> </td></tr>
     <tr><td colspan=3 height=300px></td></tr><?php
  }
  else
  {addrec();}

  mysql_close($conn);
?>
</td></tr></tbody></table>
</td>
<!-- CONTENT ENDS HERE -->
</tr></tbody></table></div>
<!-- MAINBODY ENDS HERE -->

<!-- FOOTER START HERE -->
<?php require "com/footer.php"; ?>
<!-- FOOTER ENDS HERE -->

</div></body></html>

<?php

function getLimit($profile_id)
{
    global $conn;

    $sql = mysql_query("SELECT Sum(medical_claim) AS sum_medical_claim FROM profile WHERE profile_id = ".$profile_id,$conn);
	  $res = mysql_fetch_array($sql);
    return $res["sum_medical_claim"];
}

function getClaim($profile_id, $date)
{
    global $conn;

    $sql = mysql_query("SELECT Sum(claim_amount) AS sum_claim_amount FROM medical_slip WHERE Year(date_visit) = ".$date." AND profile_id = ".$profile_id,$conn);
	  $res = mysql_fetch_array($sql);
    return $res["sum_claim_amount"];
}

function showroweditor($row, $iseditmode)
{
  $limit = getLimit($row["profile_id"]);
  $balance = $limit - getClaim($row["profile_id"], substr($row["date_visit"], 0, 4));
?>
<script src="js/calendar.js" type="text/javascript"></script>
<table class="tbl" border="0" cellspacing="1" cellpadding="5" width="80%">
  <tr>
    <td width="30" class="hr">System ID</td>
    <td class="dr"><?php echo htmlspecialchars($row["profile_id"]) ?></td>
    <input type="hidden" name="medical_slip_id" value="<?php echo str_replace('"', '&quot;', trim($row["medical_slip_id"])) ?>">
    <td width="20"></td>
    <td width="30" class="hr">Medical Category</td>
    <td class="dr"><?php set_option_desc("medical_cat_id","medical_cat",$row["medical_cat_id"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Employee Name</td>
    <td class="dr"><?php echo get_author($row["profile_id"]); ?></td>
    <input type="hidden" name="profile_id" value="<?php echo str_replace('"', '&quot;', trim($row["profile_id"])) ?>">
    <td></td>
    <td class="hr">Purpose</td>
    <td class="dr"><?php set_option_desc("medical_purpose_id","medical_purpose",$row["medical_purpose_id"]) ?></td>
  </tr>
  <tr>
    <td colspan="3" height="20"></td>
    <td class="hr">Sickness</td>
    <td class="dr"><?php set_option_desc("medical_sickness_id","medical_sickness",$row["medical_sickness_id"]) ?></td>
  </tr>
  <tr>
    <td class="hr"><u>Date Visit</u></td>
    <td class="dr"><?php set_date_option('date_visit',$row["date_visit"]); ?></td>
    <td colspan="3"></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr"><u>Clinic<u></td>
    <td class="dr"><?php set_option_clinic($row["clinic_id"]) ?></td>
  </tr>
  <tr>
    <td class="hr"><u>Receipt</u></td>
    <td class="dr"><input class="input2" type="text" name="receipt_id" value="<?php echo str_replace('"', '&quot;', trim($row["receipt_id"])) ?>"></td>
    <td></td>
    <td rowspan="4" valign="top" class="hr"><u>Address</u></td>
    <td rowspan="4" valign="top" height="60" class="dr"><textarea class="input2" cols="35" rows="6" name="address" maxlength="255"><?php echo htmlspecialchars($row["address"]) ?></textarea></td>
  </tr>
  <tr>
    <td class="hr"><u>Amount</u></td>
    <td class="dr"><input class="input2" type="text" name="receipt_amount" value="<?php echo str_replace('"', '&quot;', trim($row["receipt_amount"])) ?>"></td>
    <td></td>
  </tr>
  <tr>
    <td class="sr" colspan="2">Please fill in all the <u>underline</u> details.</td>
    <td></td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td class="hr">Remark</td>
    <td colspan="4"></td>
  </tr>
  <tr>
    <td colspan="5" valign="top" rowspan="3" height="60" class="dr"><textarea class="input2" cols="35" rows="3" name="remark" maxlength="255"><?php echo htmlspecialchars($row["remark"]) ?></textarea></td>
  </tr>
  <tr></tr>
  <tr></tr>
  <tr>
    <td colspan="5" height="20">&nbsp;</td>
  </tr>
  <tr>
    <td class="hr">Claim Limit</td>
    <td class="sr"><input class="input2" type="text" name="claim_limit" value="<?php echo FloatFormat($limit,2) ?>"></td>
    <td></td>
    <td class="hr">Created Date</td>
    <td class="sr"><?php echo htmlspecialchars($row["date_created"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Claim Balance</td>
    <td class="sr"><input class="input2" type="text" name="claim_balance" value="<?php echo FloatFormat($balance,2) ?>"></td>
    <td></td>
    <td class="hr">Created By</td>
    <td class="sr"><?php echo get_author($row["created_by"]) ?></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr">Modified Date</td>
    <td class="sr"><?php echo htmlspecialchars($row["date_modified"]) ?></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr">Modified By</td>
    <td class="sr"><?php echo get_author($row["modified_by"]) ?></td>
  </tr>
</table>
<input type="hidden" name="date_created" value="<?php echo str_replace('"', '&quot;', trim($row["date_created"])) ?>">
<input type="hidden" name="date_modified" value="<?php echo str_replace('"', '&quot;', trim($row["date_modified"])) ?>">
<input type="hidden" name="created_by" value="<?php echo str_replace('"', '&quot;', trim($row["created_by"])) ?>">
<input type="hidden" name="modified_by" value="<?php echo str_replace('"', '&quot;', trim($row["modified_by"])) ?>">
<input type="hidden" name="status" value="<?php echo str_replace('"', '&quot;', trim($row["status"])) ?>">
<input type="hidden" name="claim_amount" value="<?php echo str_replace('"', '&quot;', trim($row["claim_amount"])) ?>">
<?php }

function FloatFormat($Value, $Precision)
{
    $decimals = log10(abs($Value));
    $decimals = - (intval(min($decimals, 0)) - $Precision);
    $format = "%." . $decimals . "f";
    return sprintf($format, $Value);
}

function addrec()
{
?>
<hr size="1" color=#dcdbdb noshade>
<form name="slipform" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" onsubmit="return checkContent()">
<p><input type="hidden" name="sql" value="insert"></p>
<?php
global $id;

  $row = array(
  "medical_slip_id" => "",
  "profile_id" => $id,
  "clinic_id" => "",
  "medical_cat_id" => "4",
  "receipt_id" => "",
  "receipt_amount" => "",
  "claim_amount" => "0",
  "remark" => "",
  "date_visit" => date("Y-m-d"),
  "medical_purpose_id" => "1",
  "medical_sickness_id" => "",
  "leave_id" => "",
  "address" => "",
  "status" => "1",
  "date_created" => date("Y-m-d H:i:s"),
  "date_modified" => date("Y-m-d H:i:s"),
  "created_by" => $id,
  "modified_by" => $id);
  showroweditor($row, false);
?>
<p><input type="submit" name="action" value="Post" onclick="onPost()"></p>
</form>
<script src="js/mcslip.js" type="text/javascript"></script>
<?php }


function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}

function sql_select()
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filterfield;
  global $wholeonly;

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT `medical_slip_id`, `profile_id`, `clinic_id`, `medical_cat_id`, `receipt_id`, `receipt_amount`, `claim_amount`, `remark`, `date_visit`, `medical_purpose_id`, `medical_sickness_id`, `leave_id`, `address`, `status`, `date_created`, `date_modified`, `created_by`, `modified_by` FROM `medical_slip`";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where (`medical_slip_id` like '" .$filterstr ."') or (`profile_id` like '" .$filterstr ."') or (`clinic_id` like '" .$filterstr ."') or (`medical_cat_id` like '" .$filterstr ."') or (`receipt_id` like '" .$filterstr ."') or (`receipt_amount` like '" .$filterstr ."') or (`claim_amount` like '" .$filterstr ."') or (`remark` like '" .$filterstr ."') or (`date_visit` like '" .$filterstr ."') or (`medical_purpose_id` like '" .$filterstr ."') or (`medical_sickness_id` like '" .$filterstr ."') or (`leave_id` like '" .$filterstr ."') or (`address` like '" .$filterstr ."') or (`status` like '" .$filterstr ."') or (`date_created` like '" .$filterstr ."') or (`date_modified` like '" .$filterstr ."') or (`created_by` like '" .$filterstr ."') or (`modified_by` like '" .$filterstr ."')";
  }
  if (isset($order) && $order!='') $sql .= " order by `" .sqlstr($order) ."`";
  if (isset($ordtype) && $ordtype!='') $sql .= " " .sqlstr($ordtype);
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}

function sql_getrecordcount()
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filterfield;
  global $wholeonly;

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT COUNT(*) FROM `medical_slip`";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where (`medical_slip_id` like '" .$filterstr ."') or (`profile_id` like '" .$filterstr ."') or (`clinic_id` like '" .$filterstr ."') or (`medical_cat_id` like '" .$filterstr ."') or (`receipt_id` like '" .$filterstr ."') or (`receipt_amount` like '" .$filterstr ."') or (`claim_amount` like '" .$filterstr ."') or (`remark` like '" .$filterstr ."') or (`date_visit` like '" .$filterstr ."') or (`medical_purpose_id` like '" .$filterstr ."') or (`medical_sickness_id` like '" .$filterstr ."') or (`leave_id` like '" .$filterstr ."') or (`address` like '" .$filterstr ."') or (`status` like '" .$filterstr ."') or (`date_created` like '" .$filterstr ."') or (`date_modified` like '" .$filterstr ."') or (`created_by` like '" .$filterstr ."') or (`modified_by` like '" .$filterstr ."')";
  }
  $res = mysql_query($sql, $conn) or die(mysql_error());
  $row = mysql_fetch_assoc($res);
  reset($row);
  return current($row);
}

function sql_insert()
{
  global $conn;
  global $_POST;
  ////" .sqlvalue(@$_POST["medical_slip_id"], false)."
  $sql = "insert into `medical_slip` (
  `medical_slip_id`, `profile_id`, `clinic_id`, `medical_cat_id`, `receipt_id`, `receipt_amount`, `claim_amount`, `remark`, `date_visit`,
  `medical_purpose_id`, `medical_sickness_id`, `leave_id`, `address`, `status`, `date_created`, `date_modified`,`created_by`, `modified_by`)
  values (null, " .sqlvalue(@$_POST["profile_id"], false).", " .sqlvalue(@$_POST["clinic_id"], false).", "
  .sqlvalue(@$_POST["medical_cat_id"], false).", " .sqlvalue(@$_POST["receipt_id"], true).", "
  .sqlvalue(@$_POST["receipt_amount"], false).", " .sqlvalue(@$_POST["claim_amount"], false).", "
  .sqlvalue(@$_POST["remark"], true).", " .sqlvalue(@$_POST["date_visit"], true).", "
  .sqlvalue(@$_POST["medical_purpose_id"], false).", " .sqlvalue(@$_POST["medical_sickness_id"], false).", null, "
  .sqlvalue(@$_POST["address"], true).", "
  .sqlvalue(@$_POST["status"], false).", " .sqlvalue(date("Y-m-d H:i:s"), true).", "
  .sqlvalue(date("Y-m-d H:i:s"), true).", " .sqlvalue(@$_POST["created_by"], true).", "
  .sqlvalue(@$_POST["modified_by"], true).")";
  mysql_query($sql, $conn) or die(mysql_error());
}

function primarykeycondition()
{
  global $_POST;
  $pk = "";
  $pk .= "(`medical_slip_id`";
  if (@$_POST["xmedical_slip_id"] == "") {
    $pk .= " IS NULL";
  }else{
  $pk .= " = " .sqlvalue(@$_POST["xmedical_slip_id"], false);
  };
  $pk .= ")";
  return $pk;
}

?>

 <?php
//************************************************************************************************************************************************
//  MY MODULE
//************************************************************************************************************************************************
function get_author($id)
{
	global $conn;

	$sql = "SELECT `name` FROM `profile` WHERE `profile_id` = ".$id;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["name"];
	}
}

function get_desc($table, $idvalue)
{
	global $conn;

	$sql = "SELECT `".$table."_desc` FROM `".$table."` WHERE `".$table."_id` = ".$idvalue;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row[$table."_desc"];
	}

}

function get_clinic($idvalue)
{
	global $conn;

	$sql = "SELECT `clinic_name` FROM `clinic` WHERE `clinic_id` = ".$idvalue;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["clinic_name"];
	}

}

function set_option_desc($name, $table, $idvalue)
{
	global $conn;

	$sql = "SELECT * FROM `".$table."`";
	$res = mysql_query($sql, $conn) or die(mysql_error());?>
	<select name="<?php echo $name ?>" class="input2">
	<?php while($row = mysql_fetch_array($res))
	{?>
	<option value="<?php echo $row[$table."_id"] ?>" <?php if ($idvalue == $row[$table."_id"]) { echo "selected"; } ?>><?php echo $row[$table."_desc"] ?></option>
	<?php } ?>
	</select><?php
	 mysql_free_result($res);
}

function set_option_clinic($idvalue)
{
	global $conn;

	$sql = "SELECT * FROM `clinic`";
	$res = mysql_query($sql, $conn) or die(mysql_error());?>
	<select name="clinic_id" class="input2" onblur="setAdd()">
	<?php while($row = mysql_fetch_array($res))
	{?>
	<option value="<?php echo $row["clinic_id"] ?>" <?php if ($idvalue == $row["clinic_id"]) { echo "selected"; } ?>><?php echo $row["clinic_name"] ?></option>
	<?php } ?>
	</select><?php
	 mysql_free_result($res);
}

function set_option_profile($name, $table, $idvalue, $access)
{
	global $conn;

	$sql = "SELECT * FROM `".$table."` WHERE (`access_level` <= ".$access.")";
	$res = mysql_query($sql, $conn) or die(mysql_error());?>
	<select name="<?php echo $name ?>" class="input2" onblur="setUser();">
	<?php while($row = mysql_fetch_array($res))
	{?>
	<option value="<?php echo $row[$table."_id"] ?>" <?php if ($idvalue == $row[$table."_id"]) { echo "selected"; } ?>><?php echo $row[$table."_id"]." - ".$row["name"]?></option>
	<?php } ?>
	</select><?php
	 mysql_free_result($res);
}

function set_date_option($name,$date)
{
	if ($date != NULL)
	{
		?><script>DateInput('<?php echo trim($name) ?>', false,'YYYY-MM-DD','<?php echo trim($date) ?>')</script><?php
	}
	else
	{
		?><script>DateInput('<?php echo trim($name) ?>', false,'YYYY-MM-DD')</script><?php
	}
}
?>

