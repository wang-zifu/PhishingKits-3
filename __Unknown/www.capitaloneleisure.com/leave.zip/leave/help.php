<?php require "com/init.php"; ?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head><link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link rel="stylesheet" type="text/css" href="style1.css">

	<script src="js/menu.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="js/ajaxtabs.css" />

	<title><?php print($title); ?></title>
	</head>
<body>
<div class="mainContainer" id="mainContainer">

<!-- HEADER START HERE ... -->
<table width="100%" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" height="75">
<tbody><tr><td valign="top"><table class="contentpadding" width="100%" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" width="201" align="left"><img src="images/logo.gif" alt="Blue Mission Technology" name="bmtlogo" id="logo" width="121" border="0" height="33"></td>
<td class="topnav" valign="middle" align="right" height="80"  nowrap><span class="btnfindsoftware"><?php echo date('l, jS \of F Y'); ?><br /><?php print("$name ($id)"); ?>,&nbsp;<a href="logout.php">logout</a></span></td>
</tr></tbody></table></td>
</tr>
<!-- MENU START HERE ... -->
<tr bgcolor="#587DBF" height="22"><td valign="top">
	<?php require "com/menu.php"; ?>
<!-- MENU ENDS HERE ... -->
</td></tr></tbody></table> 
<!-- HEADER ENDS HERE ... -->

<table class="contentpadding" width="100%" background="images/bg_breadcrumb.jpg" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" align="left" height="38" nowrap><span class="breadcrumbsegment"></span></td></tr></tbody></table>

<!-- MAINBODY START HERE -->
<div class="mainbody" id="mainbody">
<table width="100%" border="0" cellpadding="0" cellspacing="0"><tbody><tr>

<!-- CONTENT START HERE -->
<td valign="top" align="left">
<table width="100%" border="0" cellpadding="10" cellspacing="0"><tbody><tr><td>

<script type="text/javascript" src="js/ajaxtabs.js"></script>

<p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Help - Simple Guide To Get Started</span></p><br />
<hr size="1" color=#dcdbdb noshade><br />


<div id="flowertabs" class="modernbricksmenu2">
<ul>
<li><a href="external1.htm" rel="flowerdivcontainer" class="selected">Browsing</a></li>
<li><a href="external2.htm" rel="flowerdivcontainer">Editing</a></li>
<li><a href="external3.htm" rel="flowerdivcontainer">Leave</a></li>
<li><a href="external4.htm" rel="flowerdivcontainer">Medical Slip</a></li>
</ul>
</div>
<br style="clear: left" />
<div id="flowerdivcontainer" style="border:1px solid gray; width: 650px; height: 450px; background-color: white; padding: 7px"></div>



<script type="text/javascript">

var myflowers=new ddajaxtabs("flowertabs", "flowerdivcontainer")
myflowers.setpersist(true)
myflowers.setselectedClassTarget("link") //"link" or "linkparent"
myflowers.init()

</script>






</td></tr></tbody></table>
</td>
<!-- CONTENT ENDS HERE -->
</tr></tbody></table></div>
<!-- MAINBODY ENDS HERE -->

<!-- FOOTER START HERE -->
<?php require "com/footer.php"; ?>
<!-- FOOTER ENDS HERE -->

</div></body></html>