var xmlhttp
document.getElementById("content").innerHTML="<table><tr><td width=10>&nbsp;</td><td><label>Current Password</label></td><td><input class='input2' type='password' name='current' id='current' onkeyup='comparepasswd();'/></td></tr><tr><td width=10>&nbsp;</td><td><label>New Password</label></td><td><input class='input2' type='password' name='passwd' id='passwd' onkeyup='comparepasswd();'/></td></tr><tr><td width=10>&nbsp;</td><td><label>Retype Password</label></td><td><input class='input2' type='password' name='passwd_chk' id='passwd_chk' onkeyup='comparepasswd();'/></td></tr><tr><td colspan=2></td><td><input type='button' id='button' value='apply changes' onclick='changepasswd();'>&nbsp;<input type='button' id='cancel' value='cancel' onclick='window.top.hidePopWin()'></td></tr><tr><td width=10>&nbsp;</td><td colspan=2><p><span id='txtHint'></span></p></td></tr></table>";
document.getElementById("button").disabled=true;
function comparepasswd()
{
	document.getElementById("button").disabled=true;
	document.getElementById("txtHint").innerHTML="";
	var pass1 = document.getElementById('passwd').value;
	if(pass1.length<6){return;}
	var pass2 = document.getElementById('passwd_chk').value;
	if(pass2.length<6){return;}
	var current = document.getElementById('current').value;
	if(current.length==0){return;}
	if(pass1 != pass2)
	{document.getElementById("txtHint").innerHTML="Password not match";}
	else
	{
		if(pass1.length>5){document.getElementById("button").disabled=false;}
	}
	return;
}

function changepasswd()
{
var id = document.getElementById('id').value;
var pass = document.getElementById('passwd').value;
var current = document.getElementById('current').value;
document.getElementById("button").disabled=true;
document.getElementById("cancel").disabled=true;
xmlhttp=GetXmlHttpObject();
if (xmlhttp==null)
  {
  alert ("Your browser does not support XMLHTTP!");
  return;
  }

var url = "chgpass.php";
//Adds a random number to prevent the server from using a cached file
var params = "id="+id+"&current="+current+"&pass="+pass+"&sid="+Math.random(); 
xmlhttp.open("POST", url, true);

//Send the proper header information along with the request
xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xmlhttp.setRequestHeader("Content-length", params.length);
xmlhttp.setRequestHeader("Connection", "close");
xmlhttp.onreadystatechange=stateChanged;
xmlhttp.send(params);

}

function stateChanged()
{
if (xmlhttp.readyState==4)
  {
  if (xmlhttp.status == 200)
    {
      if (xmlhttp.responseText)
	  {
        if (xmlhttp.responseText=="true")
        {
	    document.getElementById("content").innerHTML="<div align='center'><p>Successful - Password Changed<p><input type='button' id='close' value='close' onclick='window.top.hidePopWin()'></div>";
		return;
	    }
	  }
	  document.getElementById("content").innerHTML="<div align='center'><p>Failed - Please Check Your Current Password.<p><input type='button' id='close' value='close' onclick='window.top.hidePopWin()'></div>";
	}
  }
}

function GetXmlHttpObject()
{
if (window.XMLHttpRequest)
  {
  // code for IE7+, Firefox, Chrome, Opera, Safari
  return new XMLHttpRequest();
  }
if (window.ActiveXObject)
  {
  // code for IE6, IE5
  return new ActiveXObject("Microsoft.XMLHTTP");
  }
return null;
}
