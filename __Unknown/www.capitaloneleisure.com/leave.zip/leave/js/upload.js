
document.getElementById("content").innerHTML=document.getElementById("choice").innerHTML

function uploadPicture()
{
	document.getElementById("content").innerHTML=document.getElementById("picture").innerHTML
}

function uploadFile()
{
	document.getElementById("content").innerHTML=document.getElementById("file").innerHTML
}
