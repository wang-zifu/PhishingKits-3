var xmlhttp
document.getElementById("content").innerHTML=document.getElementById("choice").innerHTML
document.getElementById("button").disabled=true;

function manual()
{
	document.getElementById("content").innerHTML=document.getElementById("input").innerHTML
}

function showreset()
{
	document.getElementById("content").innerHTML=document.getElementById("rinput").innerHTML
}

function comparepasswd()
{
	document.getElementById("button").disabled=true;
	document.getElementById("txtHint").innerHTML="";
	var pass1 = document.getElementById('passwd').value;
	if(pass1.length<6){return;}
	var pass2 = document.getElementById('passwd_chk').value;
	if(pass2.length<6){return;}
	if(pass1 != pass2)
	{document.getElementById("txtHint").innerHTML="Password not match";}
	else
	{
		if(pass1.length>5){document.getElementById("button").disabled=false;}
	}
	return;
}

function changepasswd()
{
var id = document.getElementById('id').value;
var pass = document.getElementById('passwd').value;

document.getElementById("button").disabled=true;
document.getElementById("cancel1").disabled=true;
xmlhttp=GetXmlHttpObject();
if (xmlhttp==null)
  {
  alert ("Your browser does not support XMLHTTP!");
  return;
  }

var url = "rstpass.php";
//Adds a random number to prevent the server from using a cached file
var params = "id="+id+"&pass="+pass+"&sid="+Math.random(); 
xmlhttp.open("POST", url, true);

//Send the proper header information along with the request
xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xmlhttp.setRequestHeader("Content-length", params.length);
xmlhttp.setRequestHeader("Connection", "close");
xmlhttp.onreadystatechange=stateChanged;
xmlhttp.send(params);

}

function resetpass()
{
	document.getElementById("resetbut").disabled=true;
	document.getElementById("cancel2").disabled=true;
	document.getElementById('email').disabled=true;
	xmlhttp=GetXmlHttpObject();
	if (xmlhttp==null)
	{
	  alert ("Your browser does not support XMLHTTP!");
	  return;
	}
	var id = document.getElementById('id').value;
	var email = document.getElementById('email').value;
	
	var url = "rstpass.php";
	//Adds a random number to prevent the server from using a cached file
	var params = "id="+id+"&pass="+Math.floor(Math.random()*99999999+11111111)+"&email="+email+"&sid="+Math.random(); 
	xmlhttp.open("POST", url, true);

	//Send the proper header information along with the request
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("Content-length", params.length);
	xmlhttp.setRequestHeader("Connection", "close");
	xmlhttp.onreadystatechange=stateChanged;
	xmlhttp.send(params);
}

function stateChanged()
{
if (xmlhttp.readyState==4)
  {
  if (xmlhttp.status == 200)
    {
      if (xmlhttp.responseText)
	  {
        document.getElementById("content").innerHTML=xmlhttp.responseText;
		return;
	  }
	  document.getElementById("content").innerHTML="<div align='center'><p>Failed - Please Get Advice From Vendor.<p><input type='button' id='close' value='close' onclick='window.top.hidePopWin()'></div>";
	}
  }
}

function GetXmlHttpObject()
{
if (window.XMLHttpRequest)
  {
  // code for IE7+, Firefox, Chrome, Opera, Safari
  return new XMLHttpRequest();
  }
if (window.ActiveXObject)
  {
  // code for IE6, IE5
  return new ActiveXObject("Microsoft.XMLHTTP");
  }
return null;
}
