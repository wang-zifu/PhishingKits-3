var xmlhttp;
var pfile;
var dept;
var leave;

document.rpt.filter.style.backgroundColor="#FFFFFF";
setInterface();

function setInterface()
{
  clearOptions();
  switch (document.rpt.filter_field.value)
  {
    case "p.dept_id":
    {
        if(dept==null){getDept();}else{setOptions(dept);}
        document.rpt.filter.disabled=false;
        break;
    }
    case "p.profile_id":
    {
        if(pfile==null){getProfile();}else{setOptions(pfile);}
        document.rpt.filter.disabled=false;
        break;
    }
    default:{document.rpt.filter.disabled=true; break}
  }
}

function setSelected()
{
   var sObj = document.rpt.filter;
   var i=0;
   for(i=0; i < sObj.length; i++)
   {
      if(filter==parseInt(sObj.options[i].value)){sObj.selectedIndex=i;}
   }
   sObj.options[sObj.selectedIndex].selected=true;
}

function setOptions(sData)
{
   var sObj = document.rpt.filter;
   var sArray = sData.split(";");
   var i=0;
   for(i=0; i < sArray.length; i++)
   {
      var sTmp = sArray[i].split("~");
      if(sTmp.length>1){addOptions(sObj, sTmp[0]+" - "+sTmp[1], sTmp[0]);}
   }
   //setTimeout("setSelected()",500);
   setSelected();
}

function addOptions(sObj, sText, sValue)
{
  var elOptNew = document.createElement('option');
  elOptNew.text = sText;
  elOptNew.value = sValue;

  try {
    sObj.add(elOptNew, null); // standards compliant; doesn't work in IE
  }
  catch(ex) {
    sObj.add(elOptNew); // IE only
  }

}

function clearOptions()
{
	var sObj = document.rpt.filter;
	var selectParentNode = sObj.parentNode;
	var newSelectObj = sObj.cloneNode(false); // Make a shallow copy
	selectParentNode.replaceChild(newSelectObj, sObj);
	return newSelectObj;
}

function getDept()
{
	xmlhttp=GetXmlHttpObject();
	if (xmlhttp==null)
	{
	  alert ("Your browser does not support XMLHTTP!");
	  return;
	}

	var url = "leave_rpt_list.php";
	//Adds a random number to prevent the server from using a cached file
	var params = "a=dept&sid="+Math.random();
	xmlhttp.open("POST", url, true);

	//Send the proper header information along with the request
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("Content-length", params.length);
	xmlhttp.setRequestHeader("Connection", "close");
	xmlhttp.onreadystatechange=stateDept;
	xmlhttp.send(params);
}

function stateDept()
{
if (xmlhttp.readyState==4)
  {
  if (xmlhttp.status == 200)
    {
      if (xmlhttp.responseText)
	  {
        dept = xmlhttp.responseText;
        setOptions(dept);
		return;
	  }
	}
  }
}

function getProfile()
{
	xmlhttp=GetXmlHttpObject();
	if (xmlhttp==null)
	{
	  alert ("Your browser does not support XMLHTTP!");
	  return;
	}

	var url = "leave_rpt_list.php";
	//Adds a random number to prevent the server from using a cached file
	var params = "a=pfile&sid="+Math.random();
	xmlhttp.open("POST", url, true);

	//Send the proper header information along with the request
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("Content-length", params.length);
	xmlhttp.setRequestHeader("Connection", "close");
	xmlhttp.onreadystatechange=stateProfile;
	xmlhttp.send(params);
}

function stateProfile()
{
if (xmlhttp.readyState==4)
  {
  if (xmlhttp.status == 200)
    {
      if (xmlhttp.responseText)
	  {
        pfile = xmlhttp.responseText;
        setOptions(pfile);
		return;
	  }
	}
  }
}

function GetXmlHttpObject()
{
if (window.XMLHttpRequest)
  {
  // code for IE7+, Firefox, Chrome, Opera, Safari
  return new XMLHttpRequest();
  }
if (window.ActiveXObject)
  {
  // code for IE6, IE5
  return new ActiveXObject("Microsoft.XMLHTTP");
  }
return null;
}