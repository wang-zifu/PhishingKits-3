var xmlhttp
document.getElementById("content").innerHTML=document.getElementById("choice").innerHTML
document.getElementById("button").disabled=true;

function manual()
{
	xmlhttp=GetXmlHttpObject();
	if (xmlhttp==null)
	{
	  alert ("Your browser does not support XMLHTTP!");
	  return;
	}
	var id = document.getElementById('id').value;

	var url = "encrypt.php";
	//Adds a random number to prevent the server from using a cached file
	var params = "record_id="+id+"&sid="+Math.random();
	xmlhttp.open("POST", url, true);

	//Send the proper header information along with the request
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("Content-length", params.length);
	xmlhttp.setRequestHeader("Connection", "close");
	xmlhttp.onreadystatechange=manualChanged;
	xmlhttp.send(params);
}

function manualChanged()
{
if (xmlhttp.readyState==4)
  {
  if (xmlhttp.status == 200)
    {
      if (xmlhttp.responseText)
	  {
        document.getElementById("address").innerHTML=xmlhttp.responseText;
        document.getElementById("content").innerHTML=document.getElementById("get").innerHTML;
		return;
	  }
      document.getElementById("address").innerHTML="Failed to get address!";
	  document.getElementById("content").innerHTML=document.getElementById("get").innerHTML;
	}
  }
}

function email()
{
  document.getElementById("content").innerHTML=document.getElementById("send").innerHTML;
}

function emailsend()
{
    xmlhttp=GetXmlHttpObject();
	if (xmlhttp==null)
	{
	  alert ("Your browser does not support XMLHTTP!");
	  return;
	}
	var id = document.getElementById('id').value;
    var email = document.getElementById('email').value;

	var url = "invitesend.php";
	//Adds a random number to prevent the server from using a cached file
	var params = "record_id="+id+"&email="+email+"&sid="+Math.random();
	xmlhttp.open("POST", url, true);

	//Send the proper header information along with the request
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("Content-length", params.length);
	xmlhttp.setRequestHeader("Connection", "close");
	xmlhttp.onreadystatechange=emailChanged;
	xmlhttp.send(params);
    document.body.style.cursor = "wait";
    document.getElementById("content").innerHTML="&nbsp;&nbsp;&nbsp;Please wait...";
}

function emailChanged()
{
if (xmlhttp.readyState==4)
  {
  if (xmlhttp.status == 200)
    {
      document.body.style.cursor = "default";
      if (xmlhttp.responseText)
	  {
	    document.getElementById("title").innerHTML="";
        document.getElementById("address").innerHTML=xmlhttp.responseText;
        document.getElementById("content").innerHTML=document.getElementById("get").innerHTML;
		return;
	  }
      document.getElementById("title").innerHTML="";
      document.getElementById("address").innerHTML="Failed to get address!";
	  document.getElementById("content").innerHTML=document.getElementById("get").innerHTML;
	}
  }
}

function GetXmlHttpObject()
{
if (window.XMLHttpRequest)
  {
  // code for IE7+, Firefox, Chrome, Opera, Safari
  return new XMLHttpRequest();
  }
if (window.ActiveXObject)
  {
  // code for IE6, IE5
  return new ActiveXObject("Microsoft.XMLHTTP");
  }
return null;
}
