var xmlhttp;
document.slipform.claim_balance.disabled=true;
document.slipform.claim_balance.style.backgroundColor="#FFFFFF";
document.slipform.claim_balance.style.borderColor="#FFFFFF";
document.slipform.claim_limit.disabled=true;
document.slipform.claim_limit.style.backgroundColor="#FFFFFF";
document.slipform.claim_limit.style.borderColor="#FFFFFF";

var claim_amount = parseFloat(document.slipform.claim_amount.value);
var claim_limit = parseFloat(document.slipform.claim_limit.value);
var claim_balance = parseFloat(document.slipform.claim_balance.value);

var clinic_id = document.slipform.clinic_id.value;
if (clinic_id >= 2)
{
  var non_panel = "";
  document.slipform.address.disabled=true;
  document.slipform.address.style.backgroundColor="#FFFFFF";
}
else
{var non_panel = document.slipform.address.value;}

function checkContent()
{
    var bOK = false;
    var vDate = document.slipform.date_visit.value;
    var vAdd = document.slipform.address.value;
    var vReceipt = document.slipform.receipt_id.value;
    var vAmount = document.slipform.receipt_amount.value;

    if(vDate.length>0 && vAdd.length>0 && vReceipt.length>0 && vAmount.length>0){bOK = true;}

    if(bOK == false){
      if (clinic_id >= 2){
        document.slipform.address.disabled=true;
        document.slipform.address.style.backgroundColor="#FFFFFF";
      }
      alert("Please make sure to key-in all the underline fields!");
      return false;
      }
}

function onPost()
{
  document.slipform.address.disabled=false;
}

function setUser()
{
  setLimit();
}

function setLimit()
{
  xmlhttp=GetXmlHttpObject();
  if (xmlhttp==null)
  {
    //alert ("Your browser does not support XMLHTTP!");
    return;
  }

  var id = document.slipform.profile_id.value;
  var url = "com/setClaim.php";
  //Adds a random number to prevent the server from using a cached file
  var params = "a=limit&id="+id+"&sid="+Math.random();
  xmlhttp.open("POST", url, true);

  //Send the proper header information along with the request
  xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlhttp.setRequestHeader("Content-length", params.length);
  xmlhttp.setRequestHeader("Connection", "close");
  xmlhttp.onreadystatechange=changeLimit;
  xmlhttp.send(params);
}

function setBalance()
{
  xmlhttp=GetXmlHttpObject();
  if (xmlhttp==null)
  {
    //alert ("Your browser does not support XMLHTTP!");
    return;
  }

  var id = document.slipform.profile_id.value;
  var url = "com/setClaim.php";
  //Adds a random number to prevent the server from using a cached file
  var params = "a=balance&id="+id+"&sid="+Math.random();
  xmlhttp.open("POST", url, true);

  //Send the proper header information along with the request
  xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlhttp.setRequestHeader("Content-length", params.length);
  xmlhttp.setRequestHeader("Connection", "close");
  xmlhttp.onreadystatechange=changeBalance;
  xmlhttp.send(params);
}

function changeLimit()
{
if (xmlhttp.readyState==4)
  {
  if (xmlhttp.status == 200)
    {
      if (xmlhttp.responseText)
	  {
        claim_limit = parseFloat(xmlhttp.responseText);
        document.slipform.claim_limit.value = claim_limit.toFixed(2);
        setBalance();
	  }
	}
  }
}

function changeBalance()
{
if (xmlhttp.readyState==4)
  {
  if (xmlhttp.status == 200)
    {
      if (xmlhttp.responseText)
	  {
        claim_balance = parseFloat(xmlhttp.responseText);
        document.slipform.claim_balance.value = claim_balance.toFixed(2);
	  }
	}
  }
}

function setClaimAmount()
{
  var new_claim_balance = claim_balance + claim_amount;
  var new_claim_amount = parseFloat(document.slipform.claim_amount.value);
  new_claim_balance = new_claim_balance - new_claim_amount;
  if(isNaN(new_claim_balance))
  {
    var res = claim_balance + claim_amount;
  }else
  {
    var res = new_claim_balance;
  }
  document.slipform.claim_balance.value = res.toFixed(2);
  return;
}

function setAdd()
{
  var clinic_id = document.slipform.clinic_id.value;
  if (clinic_id >= 2)
  {
    xmlhttp=GetXmlHttpObject();
    if (xmlhttp==null)
    {
      //alert ("Your browser does not support XMLHTTP!");
      return;
    }
    document.slipform.address.disabled=true;
    document.slipform.address.style.backgroundColor="#FFFFFF";
    var url = "com/setAdd.php";
    //Adds a random number to prevent the server from using a cached file
    var params = "clinic_id="+clinic_id+"&sid="+Math.random();
    xmlhttp.open("POST", url, true);

    //Send the proper header information along with the request
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.setRequestHeader("Content-length", params.length);
    xmlhttp.setRequestHeader("Connection", "close");
    xmlhttp.onreadystatechange=addChanged;
    xmlhttp.send(params);
  }
  else if (clinic_id == 1)
  {
    document.slipform.address.value = non_panel;
    document.slipform.address.disabled=false;
  }
  else
  {
    document.slipform.address.value = "";
    document.slipform.address.disabled=false;
  }
}

function addChanged()
{
if (xmlhttp.readyState==4)
  {
  if (xmlhttp.status == 200)
    {
      if (xmlhttp.responseText)
	  {
        document.slipform.address.value = xmlhttp.responseText;
	  }
	}
  }
}

function GetXmlHttpObject()
{
if (window.XMLHttpRequest)
  {
  // code for IE7+, Firefox, Chrome, Opera, Safari
  return new XMLHttpRequest();
  }
if (window.ActiveXObject)
  {
  // code for IE6, IE5
  return new ActiveXObject("Microsoft.XMLHTTP");
  }
return null;
}
