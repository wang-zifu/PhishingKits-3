<?php
require "../com/conn.php";
require "func.php";

//checks cookies to make sure they are logged in
if(isset($_COOKIE['id']))
{
	$id = $_COOKIE['id'];
	$pass = $_COOKIE['pass'];
	$sql = mysql_query("SELECT * FROM profile WHERE profile_id = ".$id,$conn)or die(mysql_error());
	while($info = mysql_fetch_array( $sql ))
	{
		//if the cookie has the wrong password
		if ($pass == $info['passwd'])
		{
		  //if access level is allow
          if($info['access_level'] == 1)
    	  {
              if (isset($_GET["order"])) $order = @$_GET["order"];
              if (isset($_GET["type"])) $ordtype = @$_GET["type"];
              if (isset($_GET["filter"])) $filter = @$_GET["filter"];
              if (isset($_GET["filter2"])) $filter2 = @$_GET["filter2"];
              if (isset($_GET["filter_field"])) $filterfield = @$_GET["filter_field"];
              if (isset($_GET["filter_resign"])) $filterresign = @$_GET["filter_resign"];
              if (isset($_GET["filter_status"])) $filterstatus = @$_GET["filter_status"];
              if (isset($_GET["wholeonly"])) $wholeonly = @$_GET["wholeonly"];
              if (isset($_GET["direct"])) $direct = @$_GET["direct"];
              include $direct.".php";
              exportData($file, $res, $title);
    	  }
		}
	}
}

// Functions for export to excel.
function exportData($filename, $res, $title=0)
{
  header("Pragma: no-cache");
  header("Expires: 0");
  header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
  //header("Content-Type: application/force-download");
  //header("Content-Type: application/download");
  header("Content-Type: application/octet-stream");
  header("Content-Disposition: attachment;filename=".$filename.".xls ");
  header("Content-Transfer-Encoding: binary ");

  xlsBOF();

  // Make column labels and get types.
  $fields = mysql_num_fields($res);
  for ($i=0; $i < $fields; $i++)
  {
    $type  = mysql_field_type($res, $i);
    $name  = mysql_field_name($res, $i);
    $define[$i]["name"] =  $name;
    $define[$i]["type"] =  $type;
    if($title==0)
    {
      xlsWriteLabel(0,$i,$name);
    }
    else
    {
      xlsWriteLabel(0,$i,$title[$i]);
    }
  }

  $xlsRow = 1;

  // Put data records from mysql by while loop.
  while($row=mysql_fetch_array($res))
  {
    for ($i=0; $i < $fields; $i++)
    {
      if($define[$i]["type"] == "int")
      {
         xlsWriteNumber($xlsRow,$i,$row[$define[$i]["name"]]);
      }
      else
      {
         xlsWriteLabel($xlsRow,$i,$row[$define[$i]["name"]]);
      }
    }

    $xlsRow++;
  }
  xlsEOF();
  exit();
}
?>