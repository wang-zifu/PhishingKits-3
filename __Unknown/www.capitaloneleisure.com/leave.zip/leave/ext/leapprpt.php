<?
require "../com/conn.php";
require "func.php";

//checks cookies to make sure they are logged in
if(isset($_COOKIE['id']))
{
	$id = $_COOKIE['id'];
	$pass = $_COOKIE['pass'];
	$sql = mysql_query("SELECT * FROM profile WHERE profile_id = ".$id,$conn)or die(mysql_error());
	while($info = mysql_fetch_array( $sql ))
	{
		//if the cookie has the wrong password
		if ($pass == $info['passwd'])
		{
		  //if access level is allow
          if($info['access_level'] == 1)
    	  {
    	      if (isset($_GET["a"])) $a = @$_GET["a"];
              if (isset($_GET["year"])) $year = @$_GET["year"];
              if (isset($_GET["month"])) $month = @$_GET["month"];
              if (isset($_GET["day"])) $day = @$_GET["day"];
              if (isset($_GET["order"])) $order = @$_GET["order"];
              if (isset($_GET["type"])) $ordtype = @$_GET["type"];
              if (isset($_GET["filter"])) $filter = @$_GET["filter"];
              if (isset($_GET["filter2"])) $filter2 = @$_GET["filter2"];
              if (isset($_GET["filter_field"])) $filterfield = @$_GET["filter_field"];
              if (isset($_GET["filter_resign"])) $filterresign = @$_GET["filter_resign"];
              if (isset($_GET["filter_status"])) $filterstatus = @$_GET["filter_status"];
              if (isset($_GET["wholeonly"])) $wholeonly = @$_GET["wholeonly"];
              if (isset($_GET["direct"])) $direct = @$_GET["direct"];
              $res = sql_select();
              $file = "leave_report";
              switch ($a) {
                 case "emp":
                      $title = Array(
                      0 => "System ID",
                      1 => "Name",
                      2 => "Pending",
                      3 => "Duration",
                      4 => "Approved",
                      5 => "Duration",
                      6 => "Rejected",
                      7 => "Duration",
                      8 => "Canceled",
                      9 => "Duration",
                      10 => "Total Applications",
                      11 => "Total Duration"
                    );
                  break;
                 case "day":
                  $title = Array(
                    0 => "Day",
                    1 => "Pending",
                    2 => "Duration",
                    3 => "Approved",
                    4 => "Duration",
                    5 => "Rejected",
                    6 => "Duration",
                    7 => "Canceled",
                    8 => "Duration",
                    9 => "Total Applications",
                    10 => "Total Duration"
                  );
                  break;
                case "month":
                  $title = Array(
                    0 => "Month",
                    1 => "Pending",
                    2 => "Duration",
                    3 => "Approved",
                    4 => "Duration",
                    5 => "Rejected",
                    6 => "Duration",
                    7 => "Canceled",
                    8 => "Duration",
                    9 => "Total Applications",
                    10 => "Total Duration"
                  );
                  break;
                default:
                  $title = Array(
                    0 => "Year",
                    1 => "Pending",
                    2 => "Duration",
                    3 => "Approved",
                    4 => "Duration",
                    5 => "Rejected",
                    6 => "Duration",
                    7 => "Canceled",
                    8 => "Duration",
                    9 => "Total Applications",
                    10 => "Total Duration"
                  );
                  break;
              }
              exportData($file, $res, $title);
    	  }
		}
	}
}

// Functions for export to excel.
function exportData($filename, $res, $title=0)
{
  global $a;
  global $year;
  global $month;
  global $day;

  header("Pragma: no-cache");
  header("Expires: 0");
  header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
  //header("Content-Type: application/force-download");
  //header("Content-Type: application/download");
  header("Content-Type: application/octet-stream");
  header("Content-Disposition: attachment;filename=".$filename.".xls ");
  header("Content-Transfer-Encoding: binary ");

  xlsBOF();

  switch ($a) {
    case "emp":
        $desc = "View: Year(".$year.") > Month(".$month.") > Day(".$day.") > Details";
        break;
    case "day":
        $desc = "View: Year(".$year.") > Month(".$month.") > Day";
        break;
    case "month":
        $desc = "View: Year(".$year.") > Month";
        break;
    default:
        $desc = "View: Year";
        break;
  }
  xlsWriteLabel(0,0,$desc);

  // Make column labels and get types.
  $fields = mysql_num_fields($res);
  for ($i=0; $i < $fields; $i++)
  {
    $type  = mysql_field_type($res, $i);
    $name  = mysql_field_name($res, $i);
    $define[$i]["name"] =  $name;
    $define[$i]["type"] =  $type;
    if($title==0)
    {
      xlsWriteLabel(2,$i,$name);
    }
    else
    {
      xlsWriteLabel(2,$i,$title[$i]);
    }
  }

  $xlsRow = 3;

  // Put data records from mysql by while loop.
  while($row=mysql_fetch_array($res))
  {
    for ($i=0; $i < $fields; $i++)
    {
      if($define[$i]["type"] == "int")
      {
         xlsWriteNumber($xlsRow,$i,$row[$define[$i]["name"]]);
      }
      else
      {
         xlsWriteLabel($xlsRow,$i,$row[$define[$i]["name"]]);
      }
    }

    $xlsRow++;
  }
  xlsEOF();
  exit();
}

function sql_select()
{
  global $a;
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filter2;
  global $filterfield;
  global $year;
  global $month;
  global $day;

  switch ($a) {
     case "emp":
      $front = "p.profile_id, p.name, ";
      $mid = " AND YEAR(l.date_from) = ".sqlstr($year)."
             AND MONTH(l.date_from) = ".sqlstr($month)."
             AND DAY(l.date_from) = ".sqlstr($day);
      $back = " GROUP BY p.profile_id) subq";
      break;
     case "day":
      $front = "DAY(l.date_from) AS day_select, ";
      $mid = " AND YEAR(l.date_from) = ".sqlstr($year)."
             AND MONTH(l.date_from) = ".sqlstr($month);
      $back = " GROUP BY DAY(l.date_from)) subq";
      break;
    case "month":
      $front = "MONTH(l.date_from) AS month_select, ";
      $mid = " AND YEAR(l.date_from) = ".sqlstr($year);
      $back = " GROUP BY MONTH(l.date_from)) subq";
      break;
    default:
      $front = "YEAR(l.date_from) AS year_select, ";
      $mid = "";
      $back = " GROUP BY YEAR(l.date_from)) subq";
      break;
  }

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT * FROM (SELECT ";
  $sql .= $front;
  $sql .= "Sum(if(l.indicator = 0 ,1,0)) AS waiting, Sum(if(l.indicator = 0 ,l.period,0)) AS waiting_period,
  Sum(if(l.indicator = 1 ,1,0)) AS approve, Sum(if(l.indicator = 1 ,l.period,0)) AS approve_period,
  Sum(if(l.indicator = 3 ,1,0)) AS reject, Sum(if(l.indicator = 3 ,l.period,0)) AS reject_period,
  Sum(if(l.indicator = 2 ,1,0)) AS cancel, Sum(if(l.indicator = 2 ,l.period,0)) AS cancel_period,
  Sum(1) AS total_aplication, Sum(l.period) AS total_period
  FROM leave_dat AS l ,  profile AS p
  WHERE p.profile_id =  l.profile_id
  AND l.indicator < 4";
  $sql .= $mid;
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " AND ".$filterfield." = ".$filter;
  }
  if (isset($filter2) && $filter2!='') {
    $sql .= " AND l.leave_type_id = ".$filter2;
  }
  $sql .= $back;

  if (isset($order) && $order!='') $sql .= " order by `" .sqlstr($order) ."`";
  if (isset($ordtype) && $ordtype!='') $sql .= " " .sqlstr($ordtype);
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}

function sql_getrecordcount($a)
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filter2;
  global $filterfield;
  global $year;
  global $month;
  global $day;

  switch ($a) {
     case "emp":
      $front = "p.profile_id, p.name, ";
      $mid = " AND YEAR(l.date_from) = ".sqlstr($year)."
             AND MONTH(l.date_from) = ".sqlstr($month)."
             AND DAY(l.date_from) = ".sqlstr($day);
      $back = " GROUP BY p.profile_id) subq";
      break;
     case "day":
      $front = "DAY(l.date_from) AS day_select, ";
      $mid = " AND YEAR(l.date_from) = ".sqlstr($year)."
             AND MONTH(l.date_from) = ".sqlstr($month);
      $back = " GROUP BY DAY(l.date_from)) subq";
      break;
    case "month":
      $front = "MONTH(l.date_from) AS month_select, ";
      $mid = " AND YEAR(l.date_from) = ".sqlstr($year);
      $back = " GROUP BY MONTH(l.date_from)) subq";
      break;
    default:
      $front = "YEAR(l.date_from) AS year_select, ";
      $mid = "";
      $back = " GROUP BY YEAR(l.date_from)) subq";
      break;
  }

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT COUNT(*) FROM (SELECT ";
  $sql .= $front;
  $sql .= "Sum(if(l.indicator = 0 ,1,0)) AS waiting, Sum(if(l.indicator = 0 ,l.period,0)) AS waiting_period,
  Sum(if(l.indicator = 1 ,1,0)) AS approve, Sum(if(l.indicator = 1 ,l.period,0)) AS approve_period,
  Sum(if(l.indicator = 3 ,1,0)) AS reject, Sum(if(l.indicator = 3 ,l.period,0)) AS reject_period,
  Sum(if(l.indicator = 2 ,1,0)) AS cancel, Sum(if(l.indicator = 2 ,l.period,0)) AS cancel_period,
  Sum(1) AS total_aplication, Sum(l.period) AS total_period
  FROM leave_dat AS l ,  profile AS p
  WHERE p.profile_id =  l.profile_id
  AND l.indicator < 4";
  $sql .= $mid;
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " AND ".$filterfield." = ".$filter;
  }
  if (isset($filter2) && $filter2!='') {
    $sql .= " AND l.leave_type_id = ".$filter2;
  }
  $sql .= $back;

  $res = mysql_query($sql, $conn) or die(mysql_error());
  $row = mysql_fetch_assoc($res);
  reset($row);
  return current($row);
}
?>