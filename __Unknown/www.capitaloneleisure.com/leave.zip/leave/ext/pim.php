<?
$res = sql_select();
$file = "profile";
$title = Array(
    0 => "System ID",
    1 => "Employee ID",
    2 => "Department",
    3 => "Designation",
    4 => "Name",
    5 => "Address",
    6 => "Postcode",
    7 => "City",
    8 => "State",
    9 => "Country",
    10 => "EPF",
    11 => "SOCSO",
    12 => "TAX",
    13 => "Zakat",
    14 => "NIRC/Passport",
    15 => "DOB",
    16 => "Gender",
    17 => "Marital Status",
    18 => "Race",
    19 => "Religion",
    20 => "Nationality",
    21 => "Tel",
    22 => "Fax",
    23 => "Mobile",
    24 => "Email",
    25 => "Medical History",
    26 => "Medical Claim Limit",
    27 => "Blood Group",
    28 => "Qualification",
    29 => "Institution",
    30 => "Prev. Company",
    31 => "Prev. Designation",
    32 => "Prev. Salary",
    33 => "Joined",
    34 => "Confirmed",
    35 => "Resignation",
    36 => "Contact Person",
    37 => "Contact Number",
    38 => "Optional",
    39 => "Access Level"
);


function sql_select()
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filterfield;
  global $filterresign;
  global $wholeonly;

  $checkstr = "";
  if ($wholeonly) $checkstr = " checked";
  if ($ordtype == "asc") { $ordtypestr = "desc"; } else { $ordtypestr = "asc"; }

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT * FROM (SELECT p.profile_id, p.employee_id, d.dept_desc, p.staffpos, p.name, p.address, p.postcode, p.city, p.province, p.country, p.epf,
  p.socso, p.tax, p.zakat, p.nric, p.dob, g.gender_desc, m.marital_status_desc, p.race, p.religion, p.nationality, p.telno, p.faxno,
  p.mobile, p.email, p.medical_history, p.medical_claim, b.blood_group_desc, p.ed_qualification, p.ed_institution, p.prev_company_name,
  p.prev_digsination, p.prev_salary, p.date_joined, p.date_confirmed, p.date_resignation, p.contact_person, p.contact_number,
  p.optional, a.access_level_desc FROM profile AS p , dept AS d , gender AS g , marital_status AS m , blood_group AS b, access_level AS a WHERE p.dept_id = d.dept_id
  AND p.gender = g.gender_id AND p.marital_status = m.marital_status_id AND p.blood_group = b.blood_group_id AND p.access_level = a.access_level_id AND p.profile_id <> 999";
  if (isset($filterresign) && $filterresign!='')
  {
	if ($filterresign=="1")
	{$sql .= " AND (`date_resignation` IS NULL)";}
	elseif ($filterresign=="2")
	{$sql .= " AND (`date_resignation` IS NOT NULL)";}
    elseif ($filterresign=="3")
	{$sql .= " AND (`date_confirmed` IS NOT NULL)";}
    elseif ($filterresign=="4")
	{$sql .= " AND (`date_confirmed` IS NULL)";}
    elseif ($filterresign=="5")
	{$sql .= " AND (`date_confirmed` IS NOT NULL) AND (`date_resignation` IS NULL)";}
    elseif ($filterresign=="6")
	{$sql .= " AND (`date_confirmed` IS NOT NULL) AND (`date_resignation` IS NOT NULL)";}
    elseif ($filterresign=="7")
	{$sql .= " AND (`date_confirmed` IS NULL) AND (`date_resignation` IS NULL)";}
    elseif ($filterresign=="8")
	{$sql .= " AND (`date_confirmed` IS NULL) AND (`date_resignation` IS NOT NULL)";}
  }
  $sql .= " ORDER BY p.profile_id) subq";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where ((`profile_id` like '" .$filterstr ."') or (`employee_id` like '" .$filterstr ."') or (`dept_desc` like '" .$filterstr ."') or (`staffpos` like '" .$filterstr ."') or (`name` like '" .$filterstr ."') or (`access_level_desc` like '" .$filterstr ."'))";
  }
  if (isset($order) && $order!='') $sql .= " order by `" .sqlstr($order) ."`";
  if (isset($ordtype) && $ordtype!='') $sql .= " " .sqlstr($ordtype);
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}
?>