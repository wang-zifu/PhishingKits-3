<?
require "../com/conn.php";
require "func.php";

$res = sql_select();
$file = "summary";

//checks cookies to make sure they are logged in
if(isset($_COOKIE['id']))
{
	$id = $_COOKIE['id'];
	$pass = $_COOKIE['pass'];
	$sql = mysql_query("SELECT * FROM profile WHERE profile_id = ".$id,$conn)or die(mysql_error());
	while($info = mysql_fetch_array( $sql ))
	{
		//if the cookie has the wrong password
		if ($pass == $info['passwd'])
		{
		  //if access level is allow
          if($info['access_level'] == 1)
    	  {
              if (isset($_GET["order"])) $order = @$_GET["order"];
              if (isset($_GET["type"])) $ordtype = @$_GET["type"];
              if (isset($_GET["filter"])) $filter = @$_GET["filter"];
              if (isset($_GET["filter2"])) $filter2 = @$_GET["filter2"];
              if (isset($_GET["filter_field"])) $filterfield = @$_GET["filter_field"];
              if (isset($_GET["filter_resign"])) $filterresign = @$_GET["filter_resign"];
              if (isset($_GET["filter_status"])) $filterstatus = @$_GET["filter_status"];
              if (isset($_GET["wholeonly"])) $wholeonly = @$_GET["wholeonly"];
              if (isset($_GET["direct"])) $direct = @$_GET["direct"];
              $lasty = $filter2 - 1;
              $title = Array(
                  0 => "System ID",
                  1 => "Employee ID",
                  2 => "Name",
                  3 => "Department",
                  4 => "Code",
                  5 => "Type",
                  6 => "Yearly Entitle",
                  7 => "To Date Entitle",
                  8 => "C/Forward From ".$lasty,
                  9 => "Adjust",
                  10 => "Total",
                  11 => "Used",
                  12 => "Current Balance",
                  13 => "Projected Balance"
              );
              exportData($file, $res, $title);
    	  }
		}
	}
}

// Functions for export to excel.
function exportData($filename, $res, $title=0)
{
  global $filter2;

  header("Pragma: no-cache");
  header("Expires: 0");
  header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
  header("Content-Type: application/force-download");
  header("Content-Type: application/download");
  header("Content-Type: application/octet-stream");
  header("Content-Disposition: attachment;filename=".$filename.".xls ");
  header("Content-Transfer-Encoding: binary ");

  xlsBOF();
  xlsWriteLabel(0,0,"* Projected Balance is calculated as Current Balance minus Net Pending Duration.");

  // Make column labels and get types.
  $fields = mysql_num_fields($res);
  for ($i=0; $i < 14; $i++)
  {
    if($i < $fields)
    {
      $type  = mysql_field_type($res, $i);
      $name  = mysql_field_name($res, $i);
      $define[$i]["name"] =  $name;
      $define[$i]["type"] =  $type;
    }
    xlsWriteLabel(2,$i,$title[$i]);
  }

  $xlsRow = 3;

  // Put data records from mysql by while loop.
  while($row=mysql_fetch_array($res))
  {
    for ($i=0; $i < $fields - 3; $i++)
    {
      if($define[$i]["type"] == "int")
      {
         xlsWriteNumber($xlsRow,$i,$row[$define[$i]["name"]]);
      }
      else
      {
         xlsWriteLabel($xlsRow,$i,$row[$define[$i]["name"]]);
      }
    }

    $date_tmp = getdate(strtotime($row["date_joined"]));
    $tmp["date_joined"] = mktime( 0, 0, 0, $date_tmp['mon'], $date_tmp['mday'], $date_tmp['year'] );

    //Setup the right month.
    if ($filter2 < date('Y',time()))
    {
      $month = 12;
    }
    else
    {
      $month = date('n', time());
    }

    if ($row["opt_start"]==1)
    {
      if ($filter2==date('Y',$tmp["date_joined"]))
      {
        $tmp["available"] = round(($row["yearly_entitle"]/12)*($month-date('n',$tmp["date_joined"])+1));
      }
      else
      {
        $tmp["available"] = round(($row["yearly_entitle"]/12)*$month);
      }
    }
    else
    {
      $tmp["available"] = $row["yearly_entitle"];
    }

    $tmp["cforward"] = sql_getByIndicator($row["profile_id"],$row["leave_type_id"],'10',$filter2);
    $tmp["adjust"] = sql_getByIndicator($row["profile_id"],$row["leave_type_id"],'11',$filter2);
    $tmp["total"] = $tmp["available"] + $tmp["cforward"] + $tmp["adjust"];
    $tmp["used"] = sql_getByIndicator($row["profile_id"],$row["leave_type_id"],'1',$filter2);
    $tmp["balance"] = $tmp["total"] - $tmp["used"];
    $tmp["projected"] =  $tmp["total"] - $tmp["used"] - sql_getByIndicator($row["profile_id"],$row["leave_type_id"],'0',$filter2);

    xlsWriteNumber($xlsRow,$i,$tmp["available"]);
    xlsWriteNumber($xlsRow,$i+1,$tmp["cforward"]);
    xlsWriteNumber($xlsRow,$i+2,$tmp["adjust"]);
    xlsWriteNumber($xlsRow,$i+3,$tmp["total"]);
    xlsWriteNumber($xlsRow,$i+4,$tmp["used"]);
    xlsWriteNumber($xlsRow,$i+5,$tmp["balance"]);
    xlsWriteNumber($xlsRow,$i+6,$tmp["projected"]);

    $xlsRow++;
  }
  xlsEOF();
  exit();
}

function sql_select()
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filterfield;
  global $wholeonly;

  $checkstr = "";
  if ($wholeonly) $checkstr = " checked";
  if ($ordtype == "asc") { $ordtypestr = "desc"; } else { $ordtypestr = "asc"; }

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT * FROM (SELECT p.profile_id, p.employee_id, p.name, d.dept_desc, lt.leave_code, lt.leave_type_name, lp.yearly_entitle, p.date_joined, lt.opt_start, lp.leave_type_id FROM leave_profile AS lp , leave_type AS lt , profile AS p , dept AS d WHERE (lp.leave_type_id =  lt.leave_type_id) AND (p.dept_id = d.dept_id) AND (p.profile_id =  lp.profile_id)) subq";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where (`profile_id` like '" .$filterstr ."') or (`employee_id` like '" .$filterstr ."') or (`dept_desc` like '" .$filterstr ."') or (`name` like '" .$filterstr ."') or (`leave_code` like '" .$filterstr ."') or (`leave_type_name` like '" .$filterstr ."')";
  }
  if (isset($order) && $order!='') $sql .= " order by `" .sqlstr($order) ."`";
  if (isset($ordtype) && $ordtype!='') $sql .= " " .sqlstr($ordtype);
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}

function sql_getByIndicator($id,$type,$indicator,$year)
{
  global $conn;

  $sql = "SELECT SUM(period) FROM leave_dat WHERE (indicator = ".sqlvalue($indicator, false).") AND (profile_id = ".sqlvalue($id, false).") AND (leave_type_id = ".sqlvalue($type, false).") AND year(date_created) = ".sqlvalue($year, false);
  $res = mysql_query($sql, $conn) or die(mysql_error());
  if ($res)
	{
		$row = mysql_fetch_assoc($res);
		if ($row["SUM(period)"]>0) {return $row["SUM(period)"];}
        else{return 0;}
	}
}
?>