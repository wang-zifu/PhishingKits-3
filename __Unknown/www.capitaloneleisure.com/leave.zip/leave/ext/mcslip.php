<?
$res = sql_select();
$file = "mcslip";
$title = Array(
    0 => "Medical Slip ID",
    1 => "SystemID",
    2 => "Employee ID",
    3 => "Name",
    4 => "Department",
    5 => "Leave ID",
    6 => "Date Visit",
    7 => "Date Created",
    8 => "Clinic",
    9 => "Address",
    10 => "Category",
    11 => "Purpose",
    12 => "Sickness",
    13 => "Receipt ID",
    14 => "Receipt Amount",
    15 => "Status",
    16 => "Remark",
    17 => "Claim Amount",
    18 => "Claim Limit"
);


function sql_select()
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filterfield;
  global $filter2;
  global $wholeonly;

  $checkstr = "";
  if ($wholeonly) $checkstr = " checked";
  if ($ordtype == "asc") { $ordtypestr = "desc"; } else { $ordtypestr = "asc"; }

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT * FROM (SELECT ms.medical_slip_id, ms.profile_id, p.employee_id, p.name, d.dept_desc, ms.leave_id, ms.date_visit, ms.date_created, c.clinic_name, ms.address,
  mc.medical_cat_desc, mp.medical_purpose_desc, msk.medical_sickness_desc, ms.receipt_id, ms.receipt_amount, ms.status, ms.remark, ms.claim_amount, p.medical_claim
  FROM medical_slip AS ms Inner Join medical_cat AS mc ON ms.medical_cat_id = mc.medical_cat_id Inner Join profile AS p ON p.profile_id = ms.profile_id
  Inner Join dept AS d ON d.dept_id = p.dept_id Inner Join clinic AS c ON c.clinic_id = ms.clinic_id Inner Join medical_purpose AS mp ON mp.medical_purpose_id = ms.medical_purpose_id
  Inner Join medical_sickness AS msk ON msk.medical_sickness_id = ms.medical_sickness_id";
  if (isset($filter2) && $filter2!='')
  {
	if ($filter2=="1")
	{$sql .= " WHERE (ms.status = 1)";}
	elseif ($filter2=="2")
	{$sql .= " WHERE (ms.status = 2)";}
  }
  $sql .= " ) subq";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where (`medical_slip_id` like '" .$filterstr ."') or (`profile_id` like '" .$filterstr ."') or (`employee_id` like '" .$filterstr ."') or (`name` like '" .$filterstr ."') or (`dept_desc` like '" .$filterstr ."') or (`date_visit` like '" .$filterstr ."') or (`clinic_name` like '" .$filterstr ."') or (`medical_cat_desc` like '" .$filterstr ."') or (`receipt_id` like '" .$filterstr ."') or (`receipt_amount` like '" .$filterstr ."')";
  }
  if (isset($order) && $order!='') $sql .= " order by `" .sqlstr($order) ."`";
  if (isset($ordtype) && $ordtype!='') $sql .= " " .sqlstr($ordtype);
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}
?>