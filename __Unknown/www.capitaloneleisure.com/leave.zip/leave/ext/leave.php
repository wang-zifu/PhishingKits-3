<?
$res = sql_select();
$file = "leave";
$title = Array(
    0 => "Leave ID",
    1 => "System ID",
    2 => "Employee ID",
    3 => "Name",
    4 => "Department",
    5 => "Code",
    6 => "Type",
    7 => "From",
    8 => "To",
    9 => "Duration",
    10 => "From",
    11 => "Status",
    12 => "Created",
    13 => "Modified",
);


function sql_select()
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filterfield;
  global $filterstatus;
  global $wholeonly;

  $checkstr = "";
  if ($wholeonly) $checkstr = " checked";
  if ($ordtype == "asc") { $ordtypestr = "desc"; } else { $ordtypestr = "asc"; }

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT * FROM (SELECT ld.leave_id, ld.profile_id, p.employee_id, p.name, d.dept_desc, lt.leave_code, lt.leave_type_name, ld.date_from, ld.date_to, ld.period, ld.am_from, ld.indicator, ld.date_created, ld.date_modified
  FROM leave_dat AS ld, leave_type AS lt, profile AS p, dept as d
  WHERE ld.leave_type_id = lt.leave_type_id
  AND ld.profile_id = p.profile_id
  AND p.dept_id = d.dept_id
  AND (ld.indicator < 10)";
  if (isset($filterstatus) && $filterstatus!='')
  {
    if ($filterstatus=="1")
	{$sql .= " AND (ld.indicator = 0)";}
    if ($filterstatus=="2")
	{$sql .= " AND (ld.indicator = 1)";}
	elseif ($filterstatus=="3")
	{$sql .= " AND (ld.indicator = 2)";}
    elseif ($filterstatus=="4")
	{$sql .= " AND (ld.indicator = 3)";}
    elseif ($filterstatus=="5")
	{$sql .= " AND (ld.indicator = 3) AND (ld.handler IS NOT NULL)";}
    elseif ($filterstatus=="6")
	{$sql .= " AND (ld.indicator = 3) AND (ld.handler IS NULL)";}
  }
  $sql .= ") subq";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where (`leave_id` like '" .$filterstr ."') or (`profile_id` like '" .$filterstr ."') or (`employee_id` like '" .$filterstr ."') or (`name` like '" .$filterstr ."') or (`dept_desc` like '" .$filterstr ."') or (`leave_code` like '" .$filterstr ."') or (`leave_type_name` like '" .$filterstr ."') or (`date_from` like '" .$filterstr ."') or (`date_to` like '" .$filterstr ."') or (`period` like '" .$filterstr ."') or (`am_from` like '" .$filterstr ."') or (`indicator` like '" .$filterstr ."') or (`date_created` like '" .$filterstr ."')";
  }
  if (isset($order) && $order!='') $sql .= " order by `" .sqlstr($order) ."`";
  if (isset($ordtype) && $ordtype!='') $sql .= " " .sqlstr($ordtype);
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}
?>