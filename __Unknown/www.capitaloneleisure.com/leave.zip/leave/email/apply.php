<?php
$application = "HRM - LEAVE APPLICATION\n\n";
$application .= "Date of Application: [DATE]\n\n";
$application .= "PART I - Applicant Information\n";
$application .= "System ID: [SYSTEMID]\n";
$application .= "Name: [NAME]\n\n";
$application .= "PART II - Nature of Leave\n";
$application .= "Leave ID: [LEAVEID]\n";
$application .= "Leave Type: [LEAVETYPE]\n";
$application .= "Start (AM/PM): [AMPM]\n";
$application .= "Leave From: [LEAVEFROM]\n";
$application .= "Leave To: [LEAVETO]\n";
$application .= "Duration (Day): [DURATION]\n";
$application .= "Remark: [REMARK]\n\n";
$application .= "PART III - System Remarks\n";
$application .= "CC to: [CC]";
?>