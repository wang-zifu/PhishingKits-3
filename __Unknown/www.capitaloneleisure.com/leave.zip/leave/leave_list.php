<?php require "com/init2.php"; ?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head><link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link rel="stylesheet" type="text/css" href="style1.css">
	<link rel="stylesheet" type="text/css" href="style2.css">
	<script src="js/menu.js" type="text/javascript"></script>
	
	<link rel="stylesheet" type="text/css" href="sub/style.css" />
	<link rel="stylesheet" type="text/css" href="sub/subModal.css" />
	<script type="text/javascript" src="sub/common.js"></script>
	<script type="text/javascript" src="sub/subModal.js"></script>
	<title><?php print($title); ?></title>
	</head>
<?php 
  if (isset($_GET["order"])) $order = @$_GET["order"];
  if (isset($_GET["type"])) $ordtype = @$_GET["type"];

  if (isset($_POST["filter"])) $filter = @$_POST["filter"];
  if (isset($_POST["filter_field"])) $filterfield = @$_POST["filter_field"];
  if (isset($_POST["filter_status"])) $filterstatus = @$_POST["filter_status"];
  $wholeonly = false;
  if (isset($_POST["wholeonly"])) $wholeonly = @$_POST["wholeonly"];

  if (!isset($order) && isset($_SESSION["order"])) $order = $_SESSION["order"];
  if (!isset($ordtype) && isset($_SESSION["type"])) $ordtype = $_SESSION["type"];
  if (!isset($filter) && isset($_SESSION["filter"])) $filter = $_SESSION["filter"];
  if (!isset($filterfield) && isset($_SESSION["filter_field"])) $filterfield = $_SESSION["filter_field"];
  if (!isset($filterstatus) && isset($_SESSION["filter_status"])) $filterstatus = $_SESSION["filter_status"];
?>

<body>
<div class="mainContainer" id="mainContainer">

<!-- HEADER START HERE ... -->
<table width="100%" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" height="75">
<tbody><tr><td valign="top"><table class="contentpadding" width="100%" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" width="201" align="left"><img src="images/logo.gif" alt="Blue Mission Technology" name="bmtlogo" id="logo" width="121" border="0" height="33"></td>
<td class="topnav" valign="middle" align="right" height="80"  nowrap><span class="btnfindsoftware"><?php echo date('l, jS \of F Y'); ?><br /><?php print("$name ($id)"); ?>,&nbsp;<a href="logout.php">logout</a></span></td>
</tr></tbody></table></td>
</tr>
<!-- MENU START HERE ... -->
<tr bgcolor="#587DBF" height="22"><td valign="top">
	<?php require "com/menu.php"; ?>
<!-- MENU ENDS HERE ... -->
</td></tr></tbody></table> 
<!-- HEADER ENDS HERE ... -->

<table class="contentpadding" width="100%" background="images/bg_breadcrumb.jpg" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" align="left" height="38" nowrap><span class="breadcrumbsegment"></span></td></tr></tbody></table>

<!-- MAINBODY START HERE -->
<div class="mainbody" id="mainbody">
<table width="100%" border="0" cellpadding="0" cellspacing="0"><tbody><tr>

<!-- CONTENT START HERE -->
<td valign="top" align="left">
<table width="100%" border="0" cellpadding="10" cellspacing="0"><tbody><tr><td>


<p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Leave Management</span></p><br />
<?php
  $conn = connect();
  $showrecs = 25;
  $pagerange = 10;

  $a = @$_GET["a"];
  $recid = @$_GET["recid"];
  $page = @$_GET["page"];
  if (!isset($page)) $page = 1;

  switch ($a) {
    default:
      select();
      break;
  }

  if (isset($order)) $_SESSION["order"] = $order;
  if (isset($ordtype)) $_SESSION["type"] = $ordtype;
  if (isset($filter)) $_SESSION["filter"] = $filter;
  if (isset($filterfield)) $_SESSION["filter_field"] = $filterfield;
  if (isset($filterstatus)) $_SESSION["filter_status"] = $filterstatus;
  if (isset($wholeonly)) $_SESSION["wholeonly"] = $wholeonly;

  mysql_close($conn);
?>
</td></tr></tbody></table>
</td>
<!-- CONTENT ENDS HERE -->
</tr></tbody></table></div>
<!-- MAINBODY ENDS HERE -->

<!-- FOOTER START HERE -->
<?php require "com/footer.php"; ?>
<!-- FOOTER ENDS HERE -->

</div></body></html>

<?php function select()
  {
  global $a;
  global $showrecs;
  global $page;
  global $filter;
  global $filterstatus;
  global $filterfield;
  global $wholeonly;
  global $order;
  global $ordtype;
  global $access;


  if ($a == "reset") {
    $filter = "";
    $filterfield = "";
    $filterstatus = "";
    $wholeonly = "";
    $order = "";
    $ordtype = "";
  }

  $checkstr = "";
  if ($wholeonly) $checkstr = " checked";
  if ($ordtype == "asc") { $ordtypestr = "desc"; } else { $ordtypestr = "asc"; }

  $res = sql_select();
  $count = sql_getrecordcount();

  if ($count % $showrecs != 0) {
    $pagecount = intval($count / $showrecs) + 1;
  }
  else {
    $pagecount = intval($count / $showrecs);
  }
  $startrec = $showrecs * ($page - 1);
  if ($startrec < $count) {mysql_data_seek($res, $startrec);}
  $reccount = min($showrecs * $page, $count);
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr><td>Records shown <?php echo $startrec + 1 ?> - <?php echo $reccount ?> of <?php echo $count ?></td></tr>
</table>
<hr size="1" color=#dcdbdb noshade>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><b>Find</b>&nbsp;</td>
<td><input class="input2" type="text" name="filter" value="<?php echo $filter ?>"></td>
<td><select class="input2" name="filter_field">
<option value="">All Fields</option>
<option value="<?php echo "leave_id" ?>"<?php if ($filterfield == "leave_id") { echo "selected"; } ?>><?php echo htmlspecialchars("ID") ?></option>
<option value="<?php echo "profile_id" ?>"<?php if ($filterfield == "profile_id") { echo "selected"; } ?>><?php echo htmlspecialchars("System ID") ?></option>
<option value="<?php echo "employee_id" ?>"<?php if ($filterfield == "employee_id") { echo "selected"; } ?>><?php echo htmlspecialchars("Employee ID") ?></option>
<option value="<?php echo "name" ?>"<?php if ($filterfield == "name") { echo "selected"; } ?>><?php echo htmlspecialchars("Name") ?></option>
<option value="<?php echo "dept_desc" ?>"<?php if ($filterfield == "dept_desc") { echo "selected"; } ?>><?php echo htmlspecialchars("Department") ?></option>
<option value="<?php echo "leave_code" ?>"<?php if ($filterfield == "leave_code") { echo "selected"; } ?>><?php echo htmlspecialchars("Code") ?></option>
<option value="<?php echo "leave_type_name" ?>"<?php if ($filterfield == "leave_type_name") { echo "selected"; } ?>><?php echo htmlspecialchars("Type") ?></option>
<option value="<?php echo "date_created" ?>"<?php if ($filterfield == "date_created") { echo "selected"; } ?>><?php echo htmlspecialchars("Applied On") ?></option>
<option value="<?php echo "date_from" ?>"<?php if ($filterfield == "date_from") { echo "selected"; } ?>><?php echo htmlspecialchars("From") ?></option>
<option value="<?php echo "date_to" ?>"<?php if ($filterfield == "date_to") { echo "selected"; } ?>><?php echo htmlspecialchars("To") ?></option>
<option value="<?php echo "period" ?>"<?php if ($filterfield == "period") { echo "selected"; } ?>><?php echo htmlspecialchars("Duration") ?></option>
</select></td>
<td><input type="checkbox" name="wholeonly"<?php echo $checkstr ?>>Whole words only</td></tr>
<tr>
<td>&nbsp;</td>
<td><input type="submit" name="action" value="Search"></td>
<td><select class="input2" name="filter_status">
<option value="">Show All</option>
<option value="1" <?php if ($filterstatus == 1) { echo "selected"; } ?>>Pending</option>
<option value="2" <?php if ($filterstatus == 2) { echo "selected"; } ?>>Approved</option>
<option value="3" <?php if ($filterstatus == 3) { echo "selected"; } ?>>Cancelled</option>
<option value="4" <?php if ($filterstatus == 4) { echo "selected"; } ?>>Rejected</option>
<option value="5" <?php if ($filterstatus == 5) { echo "selected"; } ?>>Rejected Handled</option>
<option value="6" <?php if ($filterstatus == 6) { echo "selected"; } ?>>Rejected Not Handled</option>
</select></td>
<td>
<a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=reset">Reset</a>
<?php if($access==1){ ?> / <a href="ext/export.php?direct=<?php echo "leave"; ?>&filter_status=<?php echo $filterstatus; ?>&order=<?php echo $order; ?>&type=<?php echo $ordtype; ?>&filter=<?php echo $filter; ?>&filter_field=<?php echo $filterfield; ?>&wholeonly=<?php echo $wholeonly; ?>">Export Result</a><?php } ?>
</td>
</tr>
</table>
</form>
<hr size="1" color=#dcdbdb noshade>
<?php showpagenav($page, $pagecount); ?>
<br>
<table class="tbl" border="0" cellspacing="1" cellpadding="5"width="100%">
<tr>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "leave_id" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("ID") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "profile_id" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("System ID") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "employee_id" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Employee ID") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "name" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Name") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "dept_desc" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Department") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "leave_code" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Code") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "leave_type_name" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Type") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "date_created" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Applied On") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "date_from" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("From") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "date_to" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("To") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "period" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Duration") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "am_from" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("From") ?></a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "indicator" ?>&type=<?php echo $ordtypestr ?>"><?php echo htmlspecialchars("Status") ?></a></td>
<td class="hr">&nbsp;</td>
</tr>
<?php
  for ($i = $startrec; $i < $reccount; $i++)
  {
    $row = mysql_fetch_assoc($res);
    $style = "dr";
    if ($i % 2 != 0) {
      $style = "sr";
    }
    switch ($row["indicator"]){
    case 0:
        $indicator = "Pending";
        break;
    case 1:
        $indicator = "<font color=#090>Approved</font>";
        break;
    case 2:
        $indicator = "Cancelled";
        break;
    case 3:
        $indicator = "<font color=#F00>Rejected</font>";
        break;
    }
?>
<tr>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["leave_id"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["profile_id"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["employee_id"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["name"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["dept_desc"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["leave_code"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["leave_type_name"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["date_created"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["date_from"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["date_to"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["period"]) ?></td>
<td class="<?php echo $style ?>"><?php if ($row["am_from"] == 1) { echo "AM";} else { echo "PM";} ?></td>
<td class="<?php echo $style ?>"><?php echo $indicator;?></td>
<td class="<?php echo $style ?>">
<input type="button" value="details" onclick="showPopWin('com/approve.php?a=show&lid=<?php echo htmlspecialchars($row["leave_id"]) ?>', 600, 400, null);">
</td>
</tr>
<?php
  }
  mysql_free_result($res);
?>
</table>
<br>
<?php showpagenav($page, $pagecount); ?>
<?php } ?>

<?php function showpagenav($page, $pagecount)
{
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<?php if ($page > 1) { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $page - 1 ?>">&lt;&lt;&nbsp;Prev</a>&nbsp;</td>
<?php } ?>
<?php
  global $pagerange;

  if ($pagecount > 1) {

  if ($pagecount % $pagerange != 0) {
    $rangecount = intval($pagecount / $pagerange) + 1;
  }
  else {
    $rangecount = intval($pagecount / $pagerange);
  }
  for ($i = 1; $i < $rangecount + 1; $i++) {
    $startpage = (($i - 1) * $pagerange) + 1;
    $count = min($i * $pagerange, $pagecount);

    if ((($page >= $startpage) && ($page <= ($i * $pagerange)))) {
      for ($j = $startpage; $j < $count + 1; $j++) {
        if ($j == $page) {
?>
<td><b><?php echo $j ?></b></td>
<?php } else { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $j ?>"><?php echo $j ?></a></td>
<?php } } } else { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $startpage ?>"><?php echo $startpage ."..." .$count ?></a></td>
<?php } } } ?>
<?php if ($page < $pagecount) { ?>
<td>&nbsp;<a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $page + 1 ?>">Next&nbsp;&gt;&gt;</a>&nbsp;</td>
<?php } ?>
</tr>
</table>
<?php } ?>

<?php function showrecnav($a, $recid, $count)
{
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>">Index Page</a></td>
<?php if ($recid > 0) { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=<?php echo $a ?>&recid=<?php echo $recid - 1 ?>">Prior Record</a></td>
<?php } if ($recid < $count - 1) { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=<?php echo $a ?>&recid=<?php echo $recid + 1 ?>">Next Record</a></td>
<?php } ?>
</tr>
</table>
<hr size="1" color=#dcdbdb noshade>
<?php } ?>

<?php

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}

function sql_select()
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filterfield;
  global $filterstatus;
  global $wholeonly;
  global $id;
  global $access;

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT * FROM (SELECT ld.leave_id, ld.profile_id, p.employee_id, p.name, d.dept_desc, lt.leave_code, lt.leave_type_name, ld.date_from, ld.date_to, ld.period, ld.indicator, ld.date_created, ld.date_modified, ld.am_from
  FROM leave_dat AS ld, leave_type AS lt, profile AS p, dept as d
  WHERE ld.leave_type_id = lt.leave_type_id
  AND ld.profile_id = p.profile_id
  AND p.dept_id = d.dept_id
  AND (ld.indicator < 10) ";
  if ($access <> 1)
  {
    $sql .= " AND (d.mng_profile_id = ".sqlvalue($id, false)." OR d.mng2_profile_id = ".sqlvalue($id, false)." OR d.report_to = ".sqlvalue($id, false).")
    AND (ld.profile_id <> ".sqlvalue($id, false).")
    AND (ld.profile_id <> d.mng_profile_id)";
  }
  if (isset($filterstatus) && $filterstatus!='')
  {
    if ($filterstatus=="1")
	{$sql .= " AND (ld.indicator = 0)";}
    if ($filterstatus=="2")
	{$sql .= " AND (ld.indicator = 1)";}
	elseif ($filterstatus=="3")
	{$sql .= " AND (ld.indicator = 2)";}
    elseif ($filterstatus=="4")
	{$sql .= " AND (ld.indicator = 3)";}
    elseif ($filterstatus=="5")
	{$sql .= " AND (ld.indicator = 3) AND (ld.handler IS NOT NULL)";}
    elseif ($filterstatus=="6")
	{$sql .= " AND (ld.indicator = 3) AND (ld.handler IS NULL)";}
  }
  $sql .= ") subq";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where (`leave_id` like '" .$filterstr ."') or (`profile_id` like '" .$filterstr ."') or (`employee_id` like '" .$filterstr ."') or (`name` like '" .$filterstr ."') or (`dept_desc` like '" .$filterstr ."') or (`leave_code` like '" .$filterstr ."') or (`leave_type_name` like '" .$filterstr ."') or (`date_from` like '" .$filterstr ."') or (`date_to` like '" .$filterstr ."') or (`period` like '" .$filterstr ."') or (`indicator` like '" .$filterstr ."') or (`date_created` like '" .$filterstr ."')";
  }
  if (isset($order) && $order!='') $sql .= " order by `" .sqlstr($order) ."`";
  if (isset($ordtype) && $ordtype!='') $sql .= " " .sqlstr($ordtype);
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}

function sql_getrecordcount()
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filterstatus;
  global $filterfield;
  global $wholeonly;
  global $id;
  global $access;

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT COUNT(*) FROM (SELECT ld.leave_id, ld.profile_id, p.employee_id, p.name, d.dept_desc, lt.leave_code, lt.leave_type_name, ld.date_from, ld.date_to, ld.period, ld.indicator, ld.date_created, ld.date_modified
  FROM leave_dat AS ld, leave_type AS lt, profile AS p, dept as d
  WHERE ld.leave_type_id = lt.leave_type_id
  AND ld.profile_id = p.profile_id
  AND p.dept_id = d.dept_id
  AND (ld.indicator < 10) ";
  if ($access <> 1)
  {
    $sql .= " AND (d.mng_profile_id = ".sqlvalue($id, false)." OR d.mng2_profile_id = ".sqlvalue($id, false)." OR d.report_to = ".sqlvalue($id, false).")
    AND (ld.profile_id <> ".sqlvalue($id, false).")
    AND (ld.profile_id <> d.mng_profile_id)";
  }
  if (isset($filterstatus) && $filterstatus!='')
  {
    if ($filterstatus=="1")
	{$sql .= " AND (ld.indicator = 0)";}
    if ($filterstatus=="2")
	{$sql .= " AND (ld.indicator = 1)";}
	elseif ($filterstatus=="3")
	{$sql .= " AND (ld.indicator = 2)";}
    elseif ($filterstatus=="4")
	{$sql .= " AND (ld.indicator = 3)";}
    elseif ($filterstatus=="5")
    {$sql .= " AND (ld.indicator = 3) AND (ld.handler IS NOT NULL)";}
    elseif ($filterstatus=="6")
	{$sql .= " AND (ld.indicator = 3) AND (ld.handler IS NULL)";}
  }
  $sql .= ") subq";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where (`leave_id` like '" .$filterstr ."') or (`profile_id` like '" .$filterstr ."') or (`employee_id` like '" .$filterstr ."') or (`name` like '" .$filterstr ."') or (`dept_desc` like '" .$filterstr ."') or (`leave_code` like '" .$filterstr ."') or (`leave_type_name` like '" .$filterstr ."') or (`date_from` like '" .$filterstr ."') or (`date_to` like '" .$filterstr ."') or (`period` like '" .$filterstr ."') or (`indicator` like '" .$filterstr ."') or (`date_created` like '" .$filterstr ."')";
  }
  $res = mysql_query($sql, $conn) or die(mysql_error());
  $row = mysql_fetch_assoc($res);
  reset($row);
  return current($row);
} ?>
