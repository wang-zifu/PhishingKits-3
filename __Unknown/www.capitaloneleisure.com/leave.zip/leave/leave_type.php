<?php require "com/init1.php"; ?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head><link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link rel="stylesheet" type="text/css" href="style1.css">
	<link rel="stylesheet" type="text/css" href="style6.css">
	<script src="js/menu.js" type="text/javascript"></script>
	
	<link rel="stylesheet" type="text/css" href="sub/style.css" />
	<link rel="stylesheet" type="text/css" href="sub/subModal.css" />
	<script type="text/javascript" src="sub/common.js"></script>
	<script type="text/javascript" src="sub/subModal.js"></script>
	<title><?php print($title); ?></title>
	</head>
<?php 
  if (isset($_GET["order"])) $order = @$_GET["order"];
  if (isset($_GET["type"])) $ordtype = @$_GET["type"];

  if (isset($_POST["filter"])) $filter = @$_POST["filter"];
  if (isset($_POST["filter_field"])) $filterfield = @$_POST["filter_field"];
  $wholeonly = false;
  if (isset($_POST["wholeonly"])) $wholeonly = @$_POST["wholeonly"];

  if (!isset($order) && isset($_SESSION["order"])) $order = $_SESSION["order"];
  if (!isset($ordtype) && isset($_SESSION["type"])) $ordtype = $_SESSION["type"];
  if (!isset($filter) && isset($_SESSION["filter"])) $filter = $_SESSION["filter"];
  if (!isset($filterfield) && isset($_SESSION["filter_field"])) $filterfield = $_SESSION["filter_field"];
?>

<body>
<div class="mainContainer" id="mainContainer">

<!-- HEADER START HERE ... -->
<table width="100%" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" height="75">
<tbody><tr><td valign="top"><table class="contentpadding" width="100%" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" width="201" align="left"><img src="images/logo.gif" alt="Blue Mission Technology" name="bmtlogo" id="logo" width="121" border="0" height="33"></td>
<td class="topnav" valign="middle" align="right" height="80"  nowrap><span class="btnfindsoftware"><?php echo date('l, jS \of F Y'); ?><br /><?php print("$name ($id)"); ?>,&nbsp;<a href="logout.php">logout</a></span></td>
</tr></tbody></table></td>
</tr>
<!-- MENU START HERE ... -->
<tr bgcolor="#587DBF" height="22"><td valign="top">
	<?php require "com/menu.php"; ?>
<!-- MENU ENDS HERE ... -->
</td></tr></tbody></table> 
<!-- HEADER ENDS HERE ... -->

<table class="contentpadding" width="100%" background="images/bg_breadcrumb.jpg" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" align="left" height="38" nowrap><span class="breadcrumbsegment"></span></td></tr></tbody></table>

<!-- MAINBODY START HERE -->
<div class="mainbody" id="mainbody">
<table width="100%" border="0" cellpadding="0" cellspacing="0"><tbody><tr>

<!-- CONTENT START HERE -->
<td valign="top" align="left">
<table width="100%" border="0" cellpadding="10" cellspacing="0"><tbody><tr><td>


<p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Leave Type Setting</span></p><br />
<?php
  $showrecs = 25;
  $pagerange = 10;

  $a = @$_GET["a"];
  $recid = @$_GET["recid"];
  $page = @$_GET["page"];
  if (!isset($page)) $page = 1;

  $sql = @$_POST["sql"];

  switch ($sql) {
    case "insert":
      sql_insert();
      break;
    case "update":
      sql_update();
      break;
    case "delete":
      sql_delete();
      break;
  }

  switch ($a) {
    case "add":
      addrec();
      break;
    case "view":
      viewrec($recid);
      break;
    case "edit":
      editrec($recid);
      break;
    case "del":
      deleterec($recid);
      break;
    default:
      select();
      break;
  }

  if (isset($order)) $_SESSION["order"] = $order;
  if (isset($ordtype)) $_SESSION["type"] = $ordtype;
  if (isset($filter)) $_SESSION["filter"] = $filter;
  if (isset($filterfield)) $_SESSION["filter_field"] = $filterfield;
  if (isset($wholeonly)) $_SESSION["wholeonly"] = $wholeonly;

  mysql_close($conn);
?>
</td></tr></tbody></table>
</td>
<!-- CONTENT ENDS HERE -->
</tr></tbody></table></div>
<!-- MAINBODY ENDS HERE -->

<!-- FOOTER START HERE -->
<?php require "com/footer.php"; ?>
<!-- FOOTER ENDS HERE -->

</div></body></html>

<?php function select()
  {
  global $a;
  global $showrecs;
  global $page;

  $res = sql_select();
  $count = sql_getrecordcount();
  if ($count % $showrecs != 0) {
    $pagecount = intval($count / $showrecs) + 1;
  }
  else {
    $pagecount = intval($count / $showrecs);
  }
  $startrec = $showrecs * ($page - 1);
  if ($startrec < $count) {mysql_data_seek($res, $startrec);}
  $reccount = min($showrecs * $page, $count);
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr><td>Records shown <?php echo $startrec + 1 ?> - <?php echo $reccount ?> of <?php echo $count ?></td></tr>
</table>
<hr size="1" color=#dcdbdb noshade>
<?php showpagenav($page, $pagecount); ?>
<br>
<table class="tbl" border="0" cellspacing="1" cellpadding="5"width="70%">
<tr>
<td class="hr"><?php echo "ID" ?></td>
<td class="hr"><?php echo "Code" ?></td>
<td class="hr"><?php echo "Type" ?></td>
<td class="hr"><?php echo "Default Value" ?></td>
<td class="hr"><?php echo "Halfday" ?></td>
<td class="hr"><?php echo "Start On Date Joined" ?></td>
<td class="hr"><?php echo "Apply To" ?></td>
<td class="hr">&nbsp;</td>
<td class="hr">&nbsp;</td>
</tr>
<?php
  for ($i = $startrec; $i < $reccount; $i++)
  {
    $row = mysql_fetch_assoc($res);
    $style = "dr";
    if ($i % 2 != 0) {
      $style = "sr";
    }
?>
<tr>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["leave_type_id"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["leave_code"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["leave_type_name"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["default_fullyear"]) ?></td>
<td class="<?php echo $style ?>"><?php if($row["opt_halfday"]==1){echo "Yes";}else{echo "No";} ?></td>
<td class="<?php echo $style ?>"><?php if($row["opt_start"]==1){echo "Yes";}else{echo "No";} ?></td>
<td class="<?php echo $style ?>"><?php if($row["apply_to"]==2){echo "Male";}elseif($row["apply_to"]==1){echo "Female";}else{echo "All";} ?></td>
<td class="<?php echo $style ?>"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=edit&recid=<?php echo $i ?>">Edit</a></td>
<?php if($row["leave_type_id"]>3){?>
<td class="<?php echo $style ?>"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=del&recid=<?php echo $i ?>">Delete</a></td>
<?php }else {?>
<td class="<?php echo $style ?>"></td>
<?php } ?>
</tr>
<?php
  }
  mysql_free_result($res);
?>
</table>
<br>
<?php showpagenav($page, $pagecount); ?>
<?php } ?>

<?php function showrow($row, $recid)
  {
?>
<table class="tbl" border="0" cellspacing="1" cellpadding="5"width="50%">
<tr>
<td class="hr"><?php echo htmlspecialchars("ID")."&nbsp;" ?></td>
<td class="dr"><?php echo htmlspecialchars($row["leave_type_id"]) ?></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Code")."&nbsp;" ?></td>
<td class="dr"><?php echo htmlspecialchars($row["leave_code"]) ?></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Type")."&nbsp;" ?></td>
<td class="dr"><?php echo htmlspecialchars($row["leave_type_name"]) ?></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Default Value")."&nbsp;" ?></td>
<td class="dr"><?php echo htmlspecialchars($row["default_fullyear"]) ?></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Halfday")."&nbsp;" ?></td>
<td class="dr"><?php if($row["opt_halfday"]==1){echo "Yes";}else{echo "No";} ?></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Start On Date Joined")."&nbsp;" ?></td>
<td class="dr"><?php if($row["opt_start"]==1){echo "Yes";}else{echo "No";} ?></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Apply To")."&nbsp;" ?></td>
<td class="dr"><?php if($row["apply_to"]==2){echo "Male";}elseif($row["apply_to"]==1){echo "Female";}else{echo "All";} ?></td>
</tr>
<tr><td colspan=2>&nbsp;</td></tr>
<tr>
<td class="hr">Date Created</td>
<td class="dr"><?php echo htmlspecialchars($row["date_created"]) ?></td>
</tr>
<tr>
<td class="hr">Created By</td>
<td class="dr"><?php echo get_author($row["created_by"]) ?></td>
</tr>
<tr>
<td class="hr">Date Modified</td>
<td class="dr"><?php echo htmlspecialchars($row["date_modified"]) ?></td>
</tr>
<tr>
<td class="hr">Modified By</td>
<td class="dr"><?php echo get_author($row["modified_by"]) ?></td>
</tr>
</table>
<?php } ?>

<?php function showroweditor($row, $iseditmode)
  {
  global $conn;
?>
<table class="tbl" border="0" cellspacing="1" cellpadding="5"width="50%">
<tr>
<td class="hr"><?php echo htmlspecialchars("ID")."&nbsp;" ?></td>
<td class="dr"><?php echo str_replace('"', '&quot;', trim($row["leave_type_id"])) ?></td>
<input type="hidden" name="leave_type_id" value="<?php echo str_replace('"', '&quot;', trim($row["leave_type_id"])) ?>">
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Code")."&nbsp;" ?></td>
<td class="dr"><input class="input2" type="text" name="leave_code" maxlength="3" value="<?php echo str_replace('"', '&quot;', trim($row["leave_code"])) ?>"></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Type")."&nbsp;" ?></td>
<td class="dr"><input class="input2" type="text" name="leave_type_name" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["leave_type_name"])) ?>"></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Default Value")."&nbsp;" ?></td>
<td class="dr"><input class="input2" type="text" name="default_fullyear" value="<?php echo str_replace('"', '&quot;', trim($row["default_fullyear"])) ?>"></td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Halfday")."&nbsp;" ?></td>
<td class="dr">
    <select name="opt_halfday" class="input2">
    <option value="1" <?php if (1 == $row["opt_halfday"]) { echo "selected"; } ?>>Yes</option>
    <option value="0" <?php if (0 == $row["opt_halfday"]) { echo "selected"; } ?>>No</option>
    </select>
</td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Start On Date Joined")."&nbsp;" ?></td>
<td class="dr">
    <select name="opt_start" class="input2">
    <option value="1" <?php if (1 == $row["opt_start"]) { echo "selected"; } ?>>Yes</option>
    <option value="0" <?php if (0 == $row["opt_start"]) { echo "selected"; } ?>>No</option>
    </select>
</td>
</tr>
<tr>
<td class="hr"><?php echo htmlspecialchars("Apply To")."&nbsp;" ?></td>
<td class="dr">
    <select name="apply_to" class="input2">
    <option value="2" <?php if (1 == $row["apply_to"]) { echo "selected"; } ?>>Male</option>
    <option value="1" <?php if (1 == $row["apply_to"]) { echo "selected"; } ?>>Female</option>
    <option value="0" <?php if (0 == $row["apply_to"]) { echo "selected"; } ?>>All</option>
    </select>
</td>
</tr>
<tr><td colspan=2>&nbsp;</td></tr>
<tr>
  <td class="hr">Date Created</td>
  <td class="dr"><?php echo htmlspecialchars($row["date_created"]) ?></td>
 </tr>
 <tr>
  <td class="hr">Created By</td>
  <td class="dr"><?php echo get_author($row["created_by"]) ?></td>
 </tr>
 <tr>
  <td class="hr">Date Modified</td>
  <td class="dr"><?php echo htmlspecialchars($row["date_modified"]) ?></td>
 </tr>
 <tr>
  <td class="hr">Modified By</td>
  <td class="dr"><?php echo get_author($row["modified_by"]) ?></td>
 </tr>
</table>
<input type="hidden" name="date_created" value="<?php echo str_replace('"', '&quot;', trim($row["date_created"])) ?>">
<input type="hidden" name="date_modified" value="<?php echo str_replace('"', '&quot;', trim($row["date_modified"])) ?>">
<input type="hidden" name="created_by" value="<?php echo str_replace('"', '&quot;', trim($row["created_by"])) ?>">
<input type="hidden" name="modified_by" value="<?php echo str_replace('"', '&quot;', trim($row["modified_by"])) ?>">
<?php } ?>

<?php function showpagenav($page, $pagecount)
{
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=add">Add Record</a>&nbsp;</td>
<?php if ($page > 1) { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $page - 1 ?>">&lt;&lt;&nbsp;Prev</a>&nbsp;</td>
<?php } ?>
<?php
  global $pagerange;

  if ($pagecount > 1) {

  if ($pagecount % $pagerange != 0) {
    $rangecount = intval($pagecount / $pagerange) + 1;
  }
  else {
    $rangecount = intval($pagecount / $pagerange);
  }
  for ($i = 1; $i < $rangecount + 1; $i++) {
    $startpage = (($i - 1) * $pagerange) + 1;
    $count = min($i * $pagerange, $pagecount);

    if ((($page >= $startpage) && ($page <= ($i * $pagerange)))) {
      for ($j = $startpage; $j < $count + 1; $j++) {
        if ($j == $page) {
?>
<td><b><?php echo $j ?></b></td>
<?php } else { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $j ?>"><?php echo $j ?></a></td>
<?php } } } else { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $startpage ?>"><?php echo $startpage ."..." .$count ?></a></td>
<?php } } } ?>
<?php if ($page < $pagecount) { ?>
<td>&nbsp;<a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $page + 1 ?>">Next&nbsp;&gt;&gt;</a>&nbsp;</td>
<?php } ?>
</tr>
</table>
<?php } ?>

<?php function showrecnav($a, $recid, $count)
{
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>">Index Page</a></td>
<?php if ($recid > 0) { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=<?php echo $a ?>&recid=<?php echo $recid - 1 ?>">Prior Record</a></td>
<?php } if ($recid < $count - 1) { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=<?php echo $a ?>&recid=<?php echo $recid + 1 ?>">Next Record</a></td>
<?php } ?>
</tr>
</table>
<hr size="1" color=#dcdbdb noshade>
<?php } ?>

<?php function addrec()
{
  global $id;
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>">Index Page</a></td>
</tr>
</table>
<hr size="1" color=#dcdbdb noshade>
<form enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p><input type="hidden" name="sql" value="insert"></p>
<?php
$r = mysql_query("SHOW TABLE STATUS LIKE 'leave_type' ");
$row = mysql_fetch_array($r);
$auto_increment = $row['Auto_increment'];
$row = array(
  "leave_type_id" => $auto_increment,
  "leave_code" => "",
  "leave_type_name" => "",
  "default_fullyear" => 1,
  "opt_halfday" => "",
  "opt_cforward" => "",
  "opt_start" => "",
  "apply_to" => "",
  "date_created" => date("Y-m-d H:i:s"),
  "date_modified" => date("Y-m-d H:i:s"),
  "created_by" => $id,
  "modified_by" => $id);
showroweditor($row, false);
?>
<p><input type="submit" name="action" value="Post"></p>
</form>
<?php } ?>
<?php function editrec($recid)
{
  $res = sql_select();
  $count = sql_getrecordcount();
  mysql_data_seek($res, $recid);
  $row = mysql_fetch_assoc($res);
  showrecnav("edit", $recid, $count);
?>
<br>
<form enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" name="sql" value="update">
<input type="hidden" name="xleave_type_id" value="<?php echo $row["leave_type_id"] ?>">
<?php showroweditor($row, true); ?>
<p><input type="submit" name="action" value="Post"></p>
</form>
<?php
  mysql_free_result($res);
} ?>

<?php function deleterec($recid)
{
  $res = sql_select();
  $count = sql_getrecordcount();
  mysql_data_seek($res, $recid);
  $row = mysql_fetch_assoc($res);
  showrecnav("del", $recid, $count);
?>
<br>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" name="sql" value="delete">
<input type="hidden" name="xleave_type_id" value="<?php echo $row["leave_type_id"] ?>">
<?php showrow($row, $recid) ?>
<p><input type="submit" name="action" value="Confirm"></p>
</form>
<?php
  mysql_free_result($res);
} ?>

<?php

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}

function sql_select()
{
  global $conn;
  $sql = "SELECT `leave_type_id`, `leave_code`, `leave_type_name`, `default_fullyear`, `opt_halfday`, `opt_start`, `apply_to`, `opt_cforward`, `date_created`, `date_modified`, `created_by`, `modified_by` FROM `leave_type`";
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}

function sql_getrecordcount()
{
  global $conn;
  $sql = "SELECT COUNT(*) FROM `leave_type`";
  $res = mysql_query($sql, $conn) or die(mysql_error());
  $row = mysql_fetch_assoc($res);
  reset($row);
  return current($row);
}

function sql_insert()
{
  global $conn;
  global $_POST;

  $sql = "insert into `leave_type` (`leave_type_id`, `leave_code`, `leave_type_name`, `default_fullyear`, `opt_halfday`, `opt_cforward`, `opt_start`, `apply_to`, `date_created`, `date_modified`, `created_by`, `modified_by`) values ("
  .sqlvalue(@$_POST["leave_type_id"], false).", "
  .sqlvalue(@$_POST["leave_code"], true).", "
  .sqlvalue(@$_POST["leave_type_name"], true).", "
  .sqlvalue(@$_POST["default_fullyear"], false).", "
  .sqlvalue(@$_POST["opt_halfday"], false).", "
  .sqlvalue(@$_POST["opt_cforward"], false).", "
  .sqlvalue(@$_POST["opt_start"], false).", "
  .sqlvalue(@$_POST["apply_to"], false).", "
  .sqlvalue(@$_POST["date_created"], true).", "
  .sqlvalue(@$_POST["date_modified"], true).", "
  .sqlvalue(@$_POST["created_by"], false).", "
  .sqlvalue(@$_POST["modified_by"], false).")";
  mysql_query($sql, $conn) or die(mysql_error());
}

function sql_update()
{
  global $conn;
  global $_POST;
  global $id;

  $sql = "update `leave_type` set `leave_type_id`=" .sqlvalue(@$_POST["leave_type_id"], false)
  .", `leave_code`=" .sqlvalue(@$_POST["leave_code"], true)
  .", `leave_type_name`=" .sqlvalue(@$_POST["leave_type_name"], true)
  .", `default_fullyear`=" .sqlvalue(@$_POST["default_fullyear"], false)
  .", `opt_halfday`=" .sqlvalue(@$_POST["opt_halfday"], false)
  .", `opt_cforward`=" .sqlvalue(@$_POST["opt_cforward"], false)
  .", `opt_start`=" .sqlvalue(@$_POST["opt_start"], false)
  .", `apply_to`=" .sqlvalue(@$_POST["apply_to"], false)
  .", `date_created`=" .sqlvalue(@$_POST["date_created"], true)
  .", `date_modified`=" .sqlvalue(date("Y-m-d H:i:s"), true)
  .", `created_by`=" .sqlvalue(@$_POST["created_by"], false)
  .", `modified_by`=" .sqlvalue($id, false) ." where " .primarykeycondition();
  mysql_query($sql, $conn) or die(mysql_error());
}

function sql_delete()
{
  global $conn;

  $sql = "delete from `leave_type` where " .primarykeycondition();
  mysql_query($sql, $conn) or die(mysql_error());
}
function primarykeycondition()
{
  global $_POST;
  $pk = "";
  $pk .= "(`leave_type_id`";
  if (@$_POST["xleave_type_id"] == "") {
    $pk .= " IS NULL";
  }else{
  $pk .= " = " .sqlvalue(@$_POST["xleave_type_id"], false);
  };
  $pk .= ")";
  return $pk;
}
 ?>

 <?php
//************************************************************************************************************************************************
//  MY MODULE
//************************************************************************************************************************************************
function get_author($id)
{
	global $conn;
	
	$sql = "SELECT `name` FROM `profile` WHERE `profile_id` = ".$id;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["name"];
	}
}

function set_option_desc($name, $table, $idvalue)
{
	global $conn;

	$sql = "SELECT * FROM `".$table."` WHERE (`access_level` = 1) OR (`access_level` = 2)";
	$res = mysql_query($sql, $conn) or die(mysql_error());?>
	<select name="<?php echo $name ?>" class="input2">
	<option value=""></option>
	<?php while($row = mysql_fetch_array($res))
	{?>
	<option value="<?php echo $row[$table."_id"] ?>" <?php if ($idvalue == $row[$table."_id"]) { echo "selected"; } ?>><?php echo $row[$table."_id"]." - ".$row["name"]?></option>
	<?php } ?>
	</select><?php
	 mysql_free_result($res);
}
?>
