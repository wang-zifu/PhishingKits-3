<?php
// Connects to Database
require "com/conn.php";

//Checks if there is a login cookie
if(isset($_COOKIE['id']))
{	//if there is, it logs you in and directes you to the members page
	$id = $_COOKIE['id'];
	$pass = $_COOKIE['pass'];
	$check = mysql_query("SELECT profile_id, passwd, access_level, name, date_resignation FROM profile WHERE profile_id = ".$id." AND date_resignation IS NULL")or die(mysql_error());
	while($info = mysql_fetch_array( $check ))
	{
		if ($pass == $info['passwd'])
		{
			header("Location: index.php");
		}
	}
}

//if the login form is submitted
if (isset($_POST['submit']))
{	// if form has been submitted

	// makes sure they filled it in
    if(isset($_POST['id'])) $id = @$_POST['id'];
    if(isset($_POST['pass'])) $pass = @$_POST['pass'];
	if(!isset($id,$pass) || (strlen($id)<2 && strlen($pass)<3))
	{
		header("Location: ".$_SERVER['PHP_SELF']."?err=1");
	}
    else
    {
    	// checks it against the database
        $check = mysql_query("SELECT profile_id, passwd, access_level, name, date_resignation FROM profile WHERE profile_id = ".$id." AND date_resignation IS NULL")or die(mysql_error());

    	//Gives error if user dosen't exist
    	$check2 = mysql_num_rows($check);
    	if ($check2 == 0)
    	{
    		header("Location: ".$_SERVER['PHP_SELF']."?err=2&id=".$id);
    	}
    	while($info = mysql_fetch_array( $check ))
    	{
            if ($info['date_resignation'] > 0)
        	{
        		header("Location: ".$_SERVER['PHP_SELF']."?err=2&id=".$id);
        	}

    		$pass = md5(stripslashes($pass));
    		$info['passwd'] = stripslashes($info['passwd']);

    		//gives error if the password is wrong
    		if ($pass != $info['passwd'])
    		{
    			header("Location: ".$_SERVER['PHP_SELF']."?err=3&id=".$id);
    		}
    		else
    		{
    			// if login is ok then add a cookie
    			$id = stripslashes($id);
    			$hour = time() + 17200; //3600;
    			setcookie(id, $id, $hour);
    			setcookie(pass, $pass, $hour);

    			//then redirect them to the members area
    			header("Location: index.php");
    		}
    	}
    }
}
else
{

// if they are not logged in
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">

<script language="javascript">
<!--
writeCookie();

function writeCookie()
{
 var today = new Date();
 var the_date = new Date("December 31, 2050");
 var the_cookie_date = the_date.toGMTString();
 var the_cookie = "screen_height="+ screen.height;
 var the_cookie = the_cookie + ";expires=" + the_cookie_date;
 document.cookie = the_cookie
}
//-->
</script>

<head>
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<?php include "scroll.php" ?>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<link rel="stylesheet" type="text/css" href="style1.css">
<script src="js/menu.js" type="text/javascript"></script>
<title>EasyHRM</title>
</head>
<body>

<div class="mainContainer" id="mainContainer">

<!-- HEADER START HERE ... -->
<table width="100%" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" height="75">
<tbody><tr><td valign="top"><table class="contentpadding" width="100%" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" width="201" align="left"><img src="images/logo.gif" alt="Blue Mission Technology" name="bmtlogo" id="logo" width="121" border="0" height="33"></td>
<td class="topnav" valign="middle" align="right" height="80"  nowrap><span class="btnfindsoftware"><?php echo date('l, jS \of F Y'); ?></span></td>
</tr></tbody></table></td>
</tr>
<!-- MENU START HERE ... -->
<tr bgcolor="#587DBF" height="22"><td valign="top">
&nbsp;
<!-- MENU ENDS HERE ... -->
</td></tr></tbody></table> 
<!-- HEADER ENDS HERE ... -->

<table class="contentpadding" width="100%" background="images/bg_breadcrumb.jpg" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" align="left" height="38" nowrap><span class="breadcrumbsegment">"Welcome to a new level of HR Management."</span></td></tr></tbody></table>

<!-- MAINBODY START HERE -->
<div class="mainbody" id="mainbody">
<table width="100%" border="0" cellpadding="0" cellspacing="0"><tbody><tr>

<!-- CONTENT START HERE -->
<td valign="top" align="left">
<table width="100%" border="0" cellpadding="10" cellspacing="0"><tbody><tr><td>
<p style="line-height: 20px;"><span class="textheadertitle">EasyHRM System</span><br>
<span class="textheadersubtitlegry">Please Sign-in Here</span></p><br />
<form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
	<table width="80%" align="center">
		<tbody>
			<tr>
				<td align="right" valign="top" nowrap><label>ID:</label></td>
				<td><input name="id" type="text" class="input" value="<?php if(isset($_GET['id'])){echo $_GET['id'];} ?>"></td>
			</tr>
			<tr>
				<td align="right" valign="top" nowrap><label>Password:</label></td>
				<td><input name="pass" type="password" class="input"></td>
			</tr>
		</tbody>
		<tfoot>
			<tr>
				<td></td>
				<td><input name="submit" type="submit" value="login" class="button" />&nbsp;<input type="reset" value="cancel" /></td>
			</tr>
            <tr>
				<td></td>
				<td>
                <?php if(isset($_GET['err']))
            	{
            		echo "<p><font color=#f00>";
            		switch ($_GET['err'])
            		{
            			case 1;
            				echo "Please fill in a required field.";
            				break;
            			case 2;
            				echo "Please check your ID and Password.";//"ID does not exist, please check your ID.";
            				break;
            			case 3;
            				echo "Please check your ID and Password.";//"Incorrect password, please try again.";
            				break;
            		}
            		echo "</font></p>";
            	}
            	?>
                </td>
			</tr>
		</tfoot>
	</table>
</form>
	<br>
</td></tr></tbody></table>
</td>
<!-- CONTENT ENDS HERE -->

<!-- SIDEBAR START HERE -->
<td valign="top" width="250" align="left" height="500"><div id="sidebar">
<table class="menuTable" width="250" align="right" border="0" cellpadding="0" cellspacing="0"><tbody><tr valign="top"><td>
<p><b>EasyHRM</b> comes as a comprehensive solution for the efficient management of your Human Resource. It will assist you in the complex
and strategic process of managing this crucial resource of your enterprise. Based on modular architecture, it facilitates a vast range
of HR activities, with features that reflect the main HR management activities.</p>
<p>It comes as a web-enabled application and considering the available flexibility, it is a perfect platform for achieving a new level of HR Management.</p>
<p><i>Recommanded Browser: Mozilla Fire 3.0 and above. Click <a href="http://www.mozilla.com/en-US/firefox/firefox.html">here</a> to download.</i></p>
<p><i>Recommanded Zip/Compression Tool: Click <a href="http://www.7-zip.org/download.html">here</a> to download 7-zip.</i></p>
</td></tr></tbody></table></div></td>
<!-- SIDEBAR ENDS HERE -->

</tr></tbody></table></div>
<!-- MAINBODY ENDS HERE -->

<!-- FOOTER START HERE -->
<?php require "com/footer.php"; ?>
<!-- FOOTER ENDS HERE -->

</div></body></html>
<?php } ?> 