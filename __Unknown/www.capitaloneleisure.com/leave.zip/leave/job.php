<?php
require "com/conn.php";
require "com/encrypt.php";
if(isset($_POST["sql"])){$sql= @$_POST["sql"];}
if(isset($_GET["key"])){$key = @$_GET["key"];}else{if(isset($_POST["key"])){$key = @$_POST["key"];}};
$decrypted = split(";",decrypt($key, date("Y-m-d")));
$recid =  $decrypted[0];
list($year, $month, $day) = split("-", $decrypted[1]);
//echo "Month: ".$month."; Day: ".$day."; Year: ".$year."<br />\n";
if($decrypted[1]==date("Y-m-d")){
  //echo $recid;
  if($sql == "update") {sql_update();}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<link rel="stylesheet" type="text/css" href="style1.css">
<link rel="stylesheet" type="text/css" href="style7.css">
<link rel="stylesheet" type="text/css" href="sub/style.css" />
<title>EasyHRM</title>
</head>

<body>
<div class="mainContainer" id="mainContainer">

<!-- HEADER START HERE ... -->
<table width="100%" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" height="75">
<tbody><tr><td valign="top"><table class="contentpadding" width="100%" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" width="201" align="left"><img src="images/logo.gif" alt="Blue Mission Technology" name="bmtlogo" id="logo" width="121" border="0" height="33"></td>
<td class="topnav" valign="middle" align="right" height="80"  nowrap><span class="btnfindsoftware"><?php echo date('l, jS \of F Y'); ?></span></td>
</tr></tbody></table></td>
</tr>
<!-- MENU START HERE ... -->
<tr bgcolor="#587DBF" height="22"><td valign="top">
&nbsp;
<!-- MENU ENDS HERE ... -->
</td></tr></tbody></table>
<!-- HEADER ENDS HERE ... -->

<table class="contentpadding" width="100%" background="images/bg_breadcrumb.jpg" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" align="left" height="38" nowrap><span class="breadcrumbsegment"></span></td></tr></tbody></table>

<!-- MAINBODY START HERE -->
<div class="mainbody" id="mainbody">
<table width="100%" border="0" cellpadding="0" cellspacing="0"><tbody><tr>

<!-- CONTENT START HERE -->
<td valign="top" align="left">
<table width="100%" border="0" cellpadding="10" cellspacing="0"><tbody><tr><td>


<p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Candidate's Details Form</span></p>
<p>Please fill in all the details and click "Post" to save it.</p>
<br />
<hr size="1" color=#dcdbdb noshade>
<?php

  editrec($recid);

  mysql_close($conn);
?>
</td></tr></tbody></table>
</td>
<!-- CONTENT ENDS HERE -->
</tr></tbody></table></div>
<!-- MAINBODY ENDS HERE -->

<!-- FOOTER START HERE -->
<?php require "com/footer.php"; ?>
<!-- FOOTER ENDS HERE -->

</div></body></html>
<?php
if($sql == "update") {echo "<script>alert('Information updated!')</script>"; }
}

function editrec($recid)
{
  global $key;
  $res = sql_select();
  mysql_data_seek($res, 0);
  $row = mysql_fetch_assoc($res);
?>
<br>
<form enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" name="sql" value="update">
<input type="hidden" name="xpotential_id" value="<?php echo $row["potential_id"] ?>">
<input type="hidden" name="key" value="<?php echo $key ?>">
<?php showroweditor($row, true); ?>
<p><input type="submit" name="action" value="Post"></p>
</form>
<?php
  mysql_free_result($res);
} ?>

<?php function showroweditor($row, $iseditmode)
  {
  global $conn;
?>
<script src="js/calendar.js" type="text/javascript"></script>
<table class="tbl" border="0" cellspacing="1" cellpadding="5" width="90%">
    <input type="hidden" name="potential_id" value="<?php echo str_replace('"', '&quot;', trim($row["potential_id"])) ?>">
    <tr height="20">
      <td width="100" class="hr">Name</td>
      <td width="35%" class="dr"><input class="input2" type="text" name="name" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["name"])) ?>"></td>
      <td></td>
      <td width="100" class="hr">NIRC/Passport</td>
      <td width="35%" class="dr"><input class="input2" type="text" name="nric" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["nric"])) ?>"></td>
    </tr>
    <tr height="20">
      <td colspan="3" height="20"></td>
      <td class="hr">Date of Birth</td>
      <td class="dr"><?php set_date_option('dob',$row["dob"]); ?></td>
    </tr>
    <tr height="20">
      <td class="hr">Address</td>
      <td class="dr"><input class="input2" type="text" name="address" maxlength="255" value="<?php echo str_replace('"', '&quot;', trim($row["address"])) ?>"></td>
      <td></td>
      <td class="hr">Gender</td>
      <td class="dr"><?php set_option_desc("gender","gender",$row["gender"]) ?></td>
    </tr>
    <tr height="20">
      <td class="hr">Postcode</td>
      <td class="dr"><input class="input2" type="text" name="postcode" maxlength="5" value="<?php echo str_replace('"', '&quot;', trim($row["postcode"])) ?>"></td>
      <td></td>
      <td class="hr" valign="top">Marital Status</td>
      <td class="dr"><?php set_option_desc("marital_status","marital_status",$row["marital_status"]) ?></td>
    </tr>
    <tr height="20">
      <td class="hr">City</td>
      <td class="dr"><input class="input2" type="text" name="city" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["city"])) ?>"></td>
      <td colspan="3"></td>
    </tr>
    <tr height="20">
      <td class="hr">State</td>
      <td class="dr"><input class="input2" type="text" name="province" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["province"])) ?>"></td>
      <td></td>
      <td class="hr">Race</td>
      <td class="dr"><input class="input2" type="text" name="race" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["race"])) ?>"></td>
    </tr>
    <tr height="20">
      <td class="hr">Country</td>
      <td class="dr"><input class="input2" type="text" name="country" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["country"])) ?>"></td>
      <td></td>
      <td class="hr">Religion</td>
      <td class="dr"><input class="input2" type="text" name="religion" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["religion"])) ?>"></td>
    </tr>
    <tr height="20">
      <td colspan="3" height="20"></td>
      <td class="hr">Nationality</td>
      <td class="dr"><input class="input2" type="text" name="nationality" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["nationality"])) ?>"></td>
    </tr>
    <tr height="20">
      <td class="hr">EPF</td>
      <td class="dr"><input class="input2" type="text" name="epf" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["epf"])) ?>"></td>
      <td colspan="3"></td>
    </tr>
    <tr height="20">
      <td class="hr">SOCSO</td>
      <td class="dr"><input class="input2" type="text" name="socso" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["socso"])) ?>"></td>
      <td></td>
      <td class="hr" rowspan="3" valign=top>Medical History</td>
      <td class="dr" rowspan="3" valign=top width="150px"><textarea class="input2" cols="35" rows="4" name="medical_history" maxlength="255"><?php echo str_replace('"', '&quot;', trim($row["medical_history"])) ?></textarea></td>
    </tr>
    <tr height="20">
      <td class="hr">TAX</td>
      <td class="dr"><input class="input2" type="text" name="tax" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["tax"])) ?>"></td>
      <td></td>
    </tr>
    <tr height="20">
      <td class="hr">Zakat</td>
      <td class="dr"><input class="input2" type="text" name="zakat" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["zakat"])) ?>"></td>
      <td></td>
    </tr>
    <tr height="20">
      <td colspan="3" height="20"></td>
      <td class="hr">Blood Group</td>
      <td class="dr"><?php set_option_desc("blood_group","blood_group",$row["blood_group"]) ?></td>
    </tr>
    <tr height="20">
      <td class="hr">Tel</td>
      <td class="dr"><input class="input2" type="text" name="telno" maxlength="25" value="<?php echo str_replace('"', '&quot;', trim($row["telno"])) ?>"></td>
      <td colspan="3"></td>
    </tr>
    <tr height="20">
      <td class="hr">Fax</td>
      <td class="dr"><input class="input2" type="text" name="faxno" maxlength="25" value="<?php echo str_replace('"', '&quot;', trim($row["faxno"])) ?>"></td>
      <td></td>
      <td colspan="2"><b>Highest Qualification</b></td>
    </tr>
    <tr height="20">
      <td class="hr">Mobile</td>
      <td class="dr"><input class="input2" type="text" name="mobile" maxlength="25" value="<?php echo str_replace('"', '&quot;', trim($row["mobile"])) ?>"></td>
      <td></td>
      <td class="hr">Qualification</td>
      <td class="dr"><input class="input2" type="text" name="ed_qualification" maxlength="100" value="<?php echo str_replace('"', '&quot;', trim($row["ed_qualification"])) ?>"></td>
    </tr>
    <tr height="20">
      <td class="hr">Email</td>
      <td class="dr"><input class="input2" type="text" name="email" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["email"])) ?>"></td>
      <td></td>
      <td class="hr">Institution�</td>
      <td class="dr"><input class="input2" type="text" name="ed_institution" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["ed_institution"])) ?>"></td>
    </tr>
    <tr>
      <td colspan="5">&nbsp;</td>
    </tr>
    <tr>
      <td valign="top" colspan="2" rowspan="4"></td>
      <td rowspan="4"></td>
      <td colspan="2"><b>Previous Company</b></td>
    </tr>
    <tr>
      <td class="hr">Company Name</td>
      <td class="dr"><input class="input2" type="text" name="prev_company_name" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["prev_company_name"])) ?>"></td>
    </tr>
    <tr height="20">
      <td class="hr">Designation</td>
      <td class="dr"><input class="input2" type="text" name="prev_digsination" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["prev_digsination"])) ?>"></td>
    </tr>
    <tr height="20">
      <td class="hr">Salary</td>
      <td class="dr"><input class="input2" type="text" name="prev_salary" value="<?php echo str_replace('"', '&quot;', trim($row["prev_salary"])) ?>"></td>
    </tr>
</table>
<input type="hidden" name="date_created" value="<?php echo str_replace('"', '&quot;', trim($row["date_created"])) ?>">
<input class="input2" type="hidden" name="date_modified" value="<?php echo str_replace('"', '&quot;', trim($row["date_modified"])) ?>">
<input type="hidden" name="modified_by" value="<?php echo str_replace('"', '&quot;', trim($row["modified_by"])) ?>">
<?php }

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", htmlspecialchars("'"), $val);
}


function sql_select()
{
  global $conn;
  global $recid;
  $sql = "SELECT `potential_id`, `name`, `address`, `postcode`, `city`, `province`, `country`, `epf`, `socso`, `tax`, `zakat`, `nric`, `dob`, `gender`, `marital_status`, `race`, `religion`, `nationality`, `telno`, `faxno`, `mobile`, `email`, `medical_history`, `blood_group`, `ed_qualification`, `ed_institution`, `prev_company_name`, `prev_digsination`, `prev_salary`, `date_created`, `date_modified`, `modified_by` FROM `potential`";
  $sql .= " WHERE `potential_id` = " . sqlvalue($recid, false);
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}

function sql_update()
{
  global $conn;
  global $_POST;

  $sql = "update `potential` set `potential_id`=" .sqlvalue(@$_POST["potential_id"], false).", `name`=" .sqlvalue(@$_POST["name"], true).", `address`=" .sqlvalue(@$_POST["address"], true).", `postcode`=" .sqlvalue(@$_POST["postcode"], true).", `city`=" .sqlvalue(@$_POST["city"], true).", `province`=" .sqlvalue(@$_POST["province"], true).", `country`=" .sqlvalue(@$_POST["country"], true).", `epf`=" .sqlvalue(@$_POST["epf"], true).", `socso`=" .sqlvalue(@$_POST["socso"], true).", `tax`=" .sqlvalue(@$_POST["tax"], true).", `zakat`=" .sqlvalue(@$_POST["zakat"], true).", `nric`=" .sqlvalue(@$_POST["nric"], true).", `dob`=" .sqlvalue(@$_POST["dob"], true).", `gender`=" .sqlvalue(@$_POST["gender"], false).", `marital_status`=" .sqlvalue(@$_POST["marital_status"], false).", `race`=" .sqlvalue(@$_POST["race"], true).", `religion`=" .sqlvalue(@$_POST["religion"], true).", `nationality`=" .sqlvalue(@$_POST["nationality"], true).", `telno`=" .sqlvalue(@$_POST["telno"], true).", `faxno`=" .sqlvalue(@$_POST["faxno"], true).", `mobile`=" .sqlvalue(@$_POST["mobile"], true).", `email`=" .sqlvalue(@$_POST["email"], true).", `medical_history`=" .sqlvalue(@$_POST["medical_history"], true).", `blood_group`=" .sqlvalue(@$_POST["blood_group"], false).", `ed_qualification`=" .sqlvalue(@$_POST["ed_qualification"], true).", `ed_institution`=" .sqlvalue(@$_POST["ed_institution"], true).", `prev_company_name`=" .sqlvalue(@$_POST["prev_company_name"], true).", `prev_digsination`=" .sqlvalue(@$_POST["prev_digsination"], true).", `prev_salary`=" .sqlvalue(@$_POST["prev_salary"], false).", `date_created`=" .sqlvalue(@$_POST["date_created"], true).", `date_modified`=" .sqlvalue(@$_POST["date_modified"], true).", `modified_by`=" .sqlvalue(@$_POST["modified_by"], false) ." where " .primarykeycondition();
  mysql_query($sql, $conn) or die(mysql_error());
}

function primarykeycondition()
{
  global $_POST;
  $pk = "";
  $pk .= "(`potential_id`";
  if (@$_POST["xpotential_id"] == "") {
    $pk .= " IS NULL";
  }else{
  $pk .= " = " .sqlvalue(@$_POST["xpotential_id"], false);
  };
  $pk .= ")";
  return $pk;
}
 ?>

 <?php
//************************************************************************************************************************************************
//  MY MODULE
//************************************************************************************************************************************************
function get_author($id)
{
	global $conn;

	$sql = "SELECT `name` FROM `profile` WHERE `profile_id` = ".$id;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["name"];
	}
}

function get_desc($table, $idvalue)
{
	global $conn;

	$sql = "SELECT `".$table."_desc` FROM `".$table."` WHERE `".$table."_id` = ".$idvalue;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row[$table."_desc"];
	}
}

function set_option_desc($name, $table, $idvalue)
{
	global $conn;

	$sql = "SELECT * FROM `".$table."`";//<option value=""></option>
	$res = mysql_query($sql, $conn) or die(mysql_error());?>
	<select name="<?php echo $name ?>" class="input2">
	<?php while($row = mysql_fetch_array($res))
	{?>
	<option value="<?php echo $row[$table."_id"] ?>" <?php if ($idvalue == $row[$table."_id"]) { echo "selected"; } ?>><?php echo $row[$table."_desc"] ?></option>
	<?php } ?>
	</select><?php
	 mysql_free_result($res);
}

function set_date_option($name,$date)
{
	if ($date != NULL)
	{
		?><script>DateInput('<?php echo trim($name) ?>', false,'YYYY-MM-DD','<?php echo trim($date) ?>')</script><?php
	}
	else
	{
		?><script>DateInput('<?php echo trim($name) ?>', false,'YYYY-MM-DD')</script><?php
	}
}
?>
