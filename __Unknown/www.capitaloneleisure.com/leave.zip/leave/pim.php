<?php require "com/init1.php";?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head><link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link rel="stylesheet" type="text/css" href="style1.css">
	<link rel="stylesheet" type="text/css" href="style2.css">
	<script src="js/menu.js" type="text/javascript"></script>
	
	<link rel="stylesheet" type="text/css" href="sub/style.css" />
	<link rel="stylesheet" type="text/css" href="sub/subModal.css" />
	<script type="text/javascript" src="sub/common.js"></script>
	<script type="text/javascript" src="sub/subModal.js"></script>
	<title><?php print($title); ?></title>
	</head>
<?php 
  if (isset($_GET["order"])) $order = @$_GET["order"];
  if (isset($_GET["type"])) $ordtype = @$_GET["type"];

  if (isset($_POST["filter"])) $filter = @$_POST["filter"];
  if (isset($_POST["filter_field"])) $filterfield = @$_POST["filter_field"];
  if (isset($_POST["filter_resign"])) $filterresign = @$_POST["filter_resign"];
  $wholeonly = false;
  if (isset($_POST["wholeonly"])) $wholeonly = @$_POST["wholeonly"];

  if (!isset($order) && isset($_SESSION["order"])) $order = $_SESSION["order"];
  if (!isset($ordtype) && isset($_SESSION["type"])) $ordtype = $_SESSION["type"];
  if (!isset($filter) && isset($_SESSION["filter"])) $filter = $_SESSION["filter"];
  if (!isset($filterfield) && isset($_SESSION["filter_field"])) $filterfield = $_SESSION["filter_field"];
  if (!isset($filterresign) && isset($_SESSION["filter_resign"])) $filterresign = $_SESSION["filter_resign"];
?>

<body>
<div class="mainContainer" id="mainContainer">

<!-- HEADER START HERE ... -->
<table width="100%" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" height="75">
<tbody><tr><td valign="top"><table class="contentpadding" width="100%" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" width="201" align="left"><img src="images/logo.gif" alt="Blue Mission Technology" name="bmtlogo" id="logo" width="121" border="0" height="33"></td>
<td class="topnav" valign="middle" align="right" height="80"  nowrap><span class="btnfindsoftware"><?php echo date('l, jS \of F Y'); ?><br /><?php print("$name ($id)"); ?>,&nbsp;<a href="logout.php">logout</a></span></td>
</tr></tbody></table></td>
</tr>
<!-- MENU START HERE ... -->
<tr bgcolor="#587DBF" height="22"><td valign="top">
	<?php require "com/menu.php"; ?>
<!-- MENU ENDS HERE ... -->
</td></tr></tbody></table> 
<!-- HEADER ENDS HERE ... -->

<table class="contentpadding" width="100%" background="images/bg_breadcrumb.jpg" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="middle" align="left" height="38" nowrap><span class="breadcrumbsegment"></span></td></tr></tbody></table>

<!-- MAINBODY START HERE -->
<div class="mainbody" id="mainbody">
<table width="100%" border="0" cellpadding="0" cellspacing="0"><tbody><tr>

<!-- CONTENT START HERE -->
<td valign="top" align="left">
<table width="100%" border="0" cellpadding="10" cellspacing="0"><tbody><tr><td>


<p style="line-height: 20px;"><span class="textheadertitle">EasyHRM</span><br>
<span class="textheadersubtitlegry">Personal Information Management</span></p><br />
<?php
  $showrecs = 25;
  $pagerange = 10;

  $a = @$_GET["a"];
  $recid = @$_GET["recid"];
  $page = @$_GET["page"];
  if (!isset($page)) $page = 1;

  $sql = @$_POST["sql"];
  
  switch ($sql) {
    case "insert":
      sql_insert();
      $prifile_id = mysql_insert_id();
      //do add leave for new emplyee
      $res = sql_get_leave();
      if ($res)
      {
        while ($row = mysql_fetch_assoc($res))
        {
          sql_insert_leave($row["default_fullyear"],$row["leave_type_id"],$prifile_id);
        }
        mysql_free_result($res);
      }
      //do add leave adjustment (-1) if today > 14th of the month
      //if (date("d")>14)
      //{
        //sql_insert_adjustment($prifile_id);
      //}
      break;
    case "update":
      sql_update();
      break;
    case "delete":
      sql_delete();
      break;
  }

  switch ($a) {
    case "add":
      addrec();
      break;
    case "view":
      viewrec($recid);
      break;
    case "edit":
      editrec($recid);
      break;
    case "del":
      deleterec($recid);
      break;
    default:
      select();
      break;
  }

  if (isset($order)) $_SESSION["order"] = $order;
  if (isset($ordtype)) $_SESSION["type"] = $ordtype;
  if (isset($filter)) $_SESSION["filter"] = $filter;
  if (isset($filterfield)) $_SESSION["filter_field"] = $filterfield;
  if (isset($filterresign)) $_SESSION["filter_resign"] = $filterresign;
  if (isset($wholeonly)) $_SESSION["wholeonly"] = $wholeonly;

  mysql_close($conn);
?>
</td></tr></tbody></table>
</td>
<!-- CONTENT ENDS HERE -->
</tr></tbody></table></div>
<!-- MAINBODY ENDS HERE -->

<!-- FOOTER START HERE -->
<?php require "com/footer.php"; ?>
<!-- FOOTER ENDS HERE -->

</div></body></html>

<?php
  //************************************************************************************************************************************************
  //   SELECT MODULE
  //************************************************************************************************************************************************
  function select()
  {
  global $a;
  global $showrecs;
  global $page;
  global $filter;
  global $filterfield;
  global $filterresign;
  global $wholeonly;
  global $order;
  global $ordtype;


  if ($a == "reset") {
    $filter = "";
    $filterfield = "";
	$filterresign = "";
    $wholeonly = "";
    $order = "";
    $ordtype = "";
  }

  $checkstr = "";
  if ($wholeonly) $checkstr = " checked";
  if ($ordtype == "asc") { $ordtypestr = "desc"; } else { $ordtypestr = "asc"; }
  $res = sql_select_main();
  $count = sql_getrecordcount_main();
  if ($count % $showrecs != 0) {
    $pagecount = intval($count / $showrecs) + 1;
  }
  else {
    $pagecount = intval($count / $showrecs);
  }
  $startrec = $showrecs * ($page - 1);
  if ($startrec < $count) {mysql_data_seek($res, $startrec);}
  $reccount = min($showrecs * $page, $count);
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr><td>Records shown <?php echo $startrec + 1 ?> - <?php echo $reccount ?> of <?php echo $count ?></td></tr>
</table>
<hr size="1" color=#dcdbdb noshade>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><b>Find</b>&nbsp;</td>
<td><input class="input2" type="text" name="filter" value="<?php echo $filter ?>"></td>
<td><select class="input2" name="filter_field">
<option value="">All Fields</option>
<option value="<?php echo "profile_id" ?>"<?php if ($filterfield == "profile_id") { echo "selected"; } ?>>System ID</option>
<option value="<?php echo "employee_id" ?>"<?php if ($filterfield == "employee_id") { echo "selected"; } ?>>Employee ID</option>
<option value="<?php echo "dept_desc" ?>"<?php if ($filterfield == "dept_desc") { echo "selected"; } ?>>Department</option>
<option value="<?php echo "staffpos" ?>"<?php if ($filterfield == "staffpos") { echo "selected"; } ?>>Designation</option>
<option value="<?php echo "name" ?>"<?php if ($filterfield == "name") { echo "selected"; } ?>>Name</option>
<option value="<?php echo "access_level_desc" ?>"<?php if ($filterfield == "access_level_desc") { echo "selected"; } ?>>Access Level</option>
</select></td>
<td><input type="checkbox" name="wholeonly"<?php echo $checkstr ?>>Whole words only</td>
</tr>
<tr>
<td>&nbsp;</td>
<td><input type="submit" name="action" value="Search"></td>
<td><select class="input2" name="filter_resign">
<option value="">All Personnel</option>
<option value="1" <?php if ($filterresign == 1) { echo "selected"; } ?>>Active Personnel</option>
<option value="2" <?php if ($filterresign == 2) { echo "selected"; } ?>>Resigned Personnel</option>
<option value="3" <?php if ($filterresign == 3) { echo "selected"; } ?>>Confirmed Personnel</option>
<option value="4" <?php if ($filterresign == 4) { echo "selected"; } ?>>Unconfirmed Personnel</option>
<option value="5" <?php if ($filterresign == 5) { echo "selected"; } ?>>Confirmed And Active</option>
<option value="6" <?php if ($filterresign == 6) { echo "selected"; } ?>>Confirmed But Resigned</option>
<option value="7" <?php if ($filterresign == 7) { echo "selected"; } ?>>Unconfirmed But Still Active</option>
<option value="8" <?php if ($filterresign == 8) { echo "selected"; } ?>>Unconfirmed And Resigned</option>
</select></td>
<td>
<a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=reset">Reset</a> /
<a href="ext/export.php?direct=<?php echo "pim"; ?>&filter_resign=<?php echo $filterresign; ?>&order=<?php echo $order; ?>&type=<?php echo $ordtype; ?>&filter=<?php echo $filter; ?>&filter_field=<?php echo $filterfield; ?>&wholeonly=<?php echo $wholeonly; ?>">Export Result</a>
</td>
</tr>
</table>
</form>
<hr size="1" color=#dcdbdb noshade>
<?php showpagenav($page, $pagecount); ?>
<br>
<table class="tbl" border="0" cellspacing="1" cellpadding="5"width="100%">
<tr>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "profile_id" ?>&type=<?php echo $ordtypestr ?>">System ID</a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "employee_id" ?>&type=<?php echo $ordtypestr ?>">Employee ID</a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "dept_desc" ?>&type=<?php echo $ordtypestr ?>">Department</a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "staffpos" ?>&type=<?php echo $ordtypestr ?>">Designation</a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "name" ?>&type=<?php echo $ordtypestr ?>">Name</a></td>
<td class="hr"><a class="hr" href="<?php echo $_SERVER['PHP_SELF']; ?>?order=<?php echo "access_level_desc" ?>&type=<?php echo $ordtypestr ?>">Access Level</a></td>
<td class="hr">Probation End</td>
<td class="hr">&nbsp;</td>
<td class="hr">&nbsp;</td>
<td class="hr">&nbsp;</td>
<td class="hr">&nbsp;</td>
</tr>
<?php
  for ($i = $startrec; $i < $reccount; $i++)
  {
    $row = mysql_fetch_assoc($res);
    $style = "dr";
    if ($i % 2 != 0) {
      $style = "sr";
    }
?>
<tr>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["profile_id"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["employee_id"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["dept_desc"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["staffpos"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["name"]) ?></td>
<td class="<?php echo $style ?>"><?php echo htmlspecialchars($row["access_level_desc"]) ?></td>
<?php
    if($row["date_confirmed"]==null)
    {
      $date_time = strtotime($row["date_joined"]);
      $jdate = mktime( 0, 0, 0, date('m', $date_time), date('d', $date_time), date('Y', $date_time));
      $jdate = date('Y-m-d',strtotime("+".$row["probation_desc"]." months",$jdate)); ?>
      <td class="<?php echo $style ?>"><?php echo $jdate; ?></td>
    <?}
    else
    { ?>
    <td class="<?php echo $style ?>"></td>
    <?php }
?>
<td class="<?php echo $style ?>"><a href="#" onclick="showPopWin('com/supass.php?id=<?php echo $row["profile_id"] ?>&name=<?php echo $row["name"] ?>&sid=<?php echo rand(1000,9999) ?>&email=<?php echo $row["email"] ?>', 400, 220, null);">Pwd</a></td>
<td class="<?php echo $style ?>"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=view&recid=<?php echo $i ?>">View</a></td>
<td class="<?php echo $style ?>"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=edit&recid=<?php echo $i ?>">Edit</a></td>
<td class="<?php echo $style ?>"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=del&recid=<?php echo $i ?>">Del</a></td>
</tr>
<?php
  }
  mysql_free_result($res);
?>
</table>
<br>
<?php showpagenav($page, $pagecount); ?>
<?php } ?>

<?php 
//************************************************************************************************************************************************
//  SHOW RECORD NAVIGATION MODULE
//************************************************************************************************************************************************
function showrecnav($a, $recid, $count)
{
global $page;
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $page ?>">Index Page</a></td>
<?php if ($recid > 0) { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=<?php echo $a ?>&recid=<?php echo $recid - 1 ?>">Prior Record</a></td>
<?php } if ($recid < $count - 1) { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=<?php echo $a ?>&recid=<?php echo $recid + 1 ?>">Next Record</a></td>
<?php } ?>
</tr>
</table>
<hr size="1" color=#dcdbdb noshade>
<?php } ?>

<?php
  //************************************************************************************************************************************************
  //   SHOW PAGE NAV MODULE
  //************************************************************************************************************************************************
  function showpagenav($page, $pagecount)
  {
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=add">Add Record</a>&nbsp;</td>
<?php if ($page > 1) { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $page - 1 ?>">&lt;&lt;&nbsp;Prev</a>&nbsp;</td>
<?php } ?>
<?php
  global $pagerange;

  if ($pagecount > 1) {

  if ($pagecount % $pagerange != 0) {
    $rangecount = intval($pagecount / $pagerange) + 1;
  }
  else {
    $rangecount = intval($pagecount / $pagerange);
  }
  for ($i = 1; $i < $rangecount + 1; $i++) {
    $startpage = (($i - 1) * $pagerange) + 1;
    $count = min($i * $pagerange, $pagecount);

    if ((($page >= $startpage) && ($page <= ($i * $pagerange)))) {
      for ($j = $startpage; $j < $count + 1; $j++) {
        if ($j == $page) {
?>
<td><b><?php echo $j ?></b></td>
<?php } else { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $j ?>"><?php echo $j ?></a></td>
<?php } } } else { ?>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $startpage ?>"><?php echo $startpage ." ... " .$count ?></a></td>
<?php } } } ?>
<?php if ($page < $pagecount) { ?>
<td>&nbsp;<a href="<?php echo $_SERVER['PHP_SELF']; ?>?page=<?php echo $page + 1 ?>">Next&nbsp;&gt;&gt;</a>&nbsp;</td>
<?php } ?>
</tr>
</table>
<?php } ?>

<?php
  //************************************************************************************************************************************************
  //   SQL MODULE
  //************************************************************************************************************************************************

function sqlvalue($val, $quote)
{
  if ($quote)
    $tmp = sqlstr($val);
  else
    $tmp = $val;
  if ($tmp == "")
    $tmp = "NULL";
  elseif ($quote)
    $tmp = "'".$tmp."'";
  return $tmp;
}

function sqlstr($val)
{
  return str_replace("'", "''", $val);
}

function sql_select_main()
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filterfield;
  global $filterresign;
  global $wholeonly;

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT * FROM (SELECT
  p.profile_id,
  p.employee_id,
  d.dept_desc,
  p.staffpos,
  p.name,
  a.access_level_desc,
  p.date_joined,
  p.date_confirmed,
  b.probation_desc,
  p.email
  FROM profile AS p, dept AS d, access_level AS a, probation AS b
  WHERE (p.dept_id = d.dept_id) AND (p.access_level = a.access_level_id)
  AND (p.probation = b.probation_id)
  AND (p.profile_id > 999)";
  if (isset($filterresign) && $filterresign!='')
  {
	if ($filterresign=="1")
	{$sql .= " AND (`date_resignation` IS NULL)";}
	elseif ($filterresign=="2")
	{$sql .= " AND (`date_resignation` IS NOT NULL)";}
    elseif ($filterresign=="3")
	{$sql .= " AND (`date_confirmed` IS NOT NULL)";}
    elseif ($filterresign=="4")
	{$sql .= " AND (`date_confirmed` IS NULL)";}
    elseif ($filterresign=="5")
	{$sql .= " AND (`date_confirmed` IS NOT NULL) AND (`date_resignation` IS NULL)";}
    elseif ($filterresign=="6")
	{$sql .= " AND (`date_confirmed` IS NOT NULL) AND (`date_resignation` IS NOT NULL)";}
    elseif ($filterresign=="7")
	{$sql .= " AND (`date_confirmed` IS NULL) AND (`date_resignation` IS NULL)";}
    elseif ($filterresign=="8")
	{$sql .= " AND (`date_confirmed` IS NULL) AND (`date_resignation` IS NOT NULL)";}
  }
  $sql .= " ORDER BY p.profile_id) subq";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where ((`profile_id` like '" .$filterstr ."') or (`employee_id` like '" .$filterstr ."') or (`dept_desc` like '" .$filterstr ."') or (`staffpos` like '" .$filterstr ."') or (`name` like '" .$filterstr ."') or (`access_level_desc` like '" .$filterstr ."'))";
  }
  if (isset($order) && $order!='') $sql .= " order by `" .sqlstr($order) ."`";
  if (isset($ordtype) && $ordtype!='') $sql .= " " .sqlstr($ordtype);
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}

function sql_getrecordcount_main()
{
  global $conn;
  global $order;
  global $ordtype;
  global $filter;
  global $filterfield;
  global $filterresign;
  global $wholeonly;

  $filterstr = sqlstr($filter);
  if (!$wholeonly && isset($wholeonly) && $filterstr!='') $filterstr = "%" .$filterstr ."%";
  $sql = "SELECT COUNT(*) FROM (SELECT
  p.profile_id,
  p.employee_id,
  d.dept_desc,
  p.staffpos,
  p.name,
  a.access_level_desc,
  p.date_joined,
  p.date_confirmed,
  b.probation_desc,
  p.email
  FROM profile AS p, dept AS d, access_level AS a, probation AS b
  WHERE (p.dept_id = d.dept_id) AND (p.access_level = a.access_level_id)
  AND (p.probation = b.probation_id)
  AND (p.profile_id > 999)";
  if (isset($filterresign) && $filterresign!='')
  {
	if ($filterresign=="1")
	{$sql .= " AND (`date_resignation` IS NULL)";}
	elseif ($filterresign=="2")
	{$sql .= " AND (`date_resignation` IS NOT NULL)";}
    elseif ($filterresign=="3")
	{$sql .= " AND (`date_confirmed` IS NOT NULL)";}
    elseif ($filterresign=="4")
	{$sql .= " AND (`date_confirmed` IS NULL)";}
    elseif ($filterresign=="5")
	{$sql .= " AND (`date_confirmed` IS NOT NULL) AND (`date_resignation` IS NULL)";}
    elseif ($filterresign=="6")
	{$sql .= " AND (`date_confirmed` IS NOT NULL) AND (`date_resignation` IS NOT NULL)";}
    elseif ($filterresign=="7")
	{$sql .= " AND (`date_confirmed` IS NULL) AND (`date_resignation` IS NULL)";}
    elseif ($filterresign=="8")
	{$sql .= " AND (`date_confirmed` IS NULL) AND (`date_resignation` IS NOT NULL)";}
  }
  $sql .= ") subq";
  if (isset($filterstr) && $filterstr!='' && isset($filterfield) && $filterfield!='') {
    $sql .= " where " .sqlstr($filterfield) ." like '" .$filterstr ."'";
  } elseif (isset($filterstr) && $filterstr!='') {
    $sql .= " where ((`profile_id` like '" .$filterstr ."') or (`employee_id` like '" .$filterstr ."') or (`dept_desc` like '" .$filterstr ."') or (`staffpos` like '" .$filterstr ."') or (`name` like '" .$filterstr ."') or (`access_level_desc` like '" .$filterstr ."'))";
  }
  $res = mysql_query($sql, $conn) or die(mysql_error());
  $row = mysql_fetch_assoc($res);
  reset($row);
  return current($row);
} 

function sql_select()
{
  global $conn;
  global $primarykey;

  $sql = "SELECT `profile_id`, `employee_id`, `access_level`, `dept_id`, `name`, `address`, `postcode`, `city`, `province`, `country`, `staffpos`, `epf`, `socso`, `tax`, `zakat`, `nric`, `dob`, `gender`, `marital_status`, `race`, `religion`, `nationality`, `telno`, `faxno`, `mobile`, `email`, `medical_history`, `medical_claim`, `blood_group`, `ed_qualification`, `ed_institution`, `prev_company_name`, `prev_digsination`, `prev_salary`, `file_doc`, `file_pic`, `date_joined`, `date_confirmed`, `date_resignation`, `probation`, `contact_person`, `contact_number`, `optional`, `remark`, `date_created`, `date_modified`, `modified_by`, `created_by` FROM `profile` WHERE `profile_id` = ".$primarykey;
  $res = mysql_query($sql, $conn) or die(mysql_error());
  return $res;
}

function sql_getrecordcount()
{
  global $conn;
  global $primarykey;

  $sql = "SELECT COUNT(*) FROM `profile` WHERE `profile_id` = ".$primarykey;
  $res = mysql_query($sql, $conn) or die(mysql_error());
  $row = mysql_fetch_assoc($res);
  reset($row);
  return current($row);
}

function sql_insert()
{
  global $conn;
  global $_POST;
  global $id;

  $sql = "insert into `profile` (`profile_id`, `employee_id`, `access_level`, `dept_id`, `name`, `address`, `postcode`,
  `city`, `province`, `country`, `staffpos`, `epf`, `socso`, `tax`, `zakat`, `nric`, `dob`, `gender`, `marital_status`,
  `race`, `religion`, `nationality`, `telno`, `faxno`, `mobile`, `email`, `medical_history`, `medical_claim`, `blood_group`,
  `ed_qualification`, `ed_institution`, `prev_company_name`, `prev_digsination`, `prev_salary`, `date_joined`, `date_confirmed`,
  `date_resignation`, `probation`, `date_created`, `date_modified`, `modified_by`, `created_by`, `file_doc`, `file_pic`, `contact_person`,
  `contact_number`, `optional`, `remark`) values ("
  .sqlvalue(@$_POST["profile_id"], false).", " .sqlvalue(@$_POST["employee_id"], true).", "
  .sqlvalue(@$_POST["access_level"], false).", " .sqlvalue(@$_POST["dept_id"], false).", "
  .sqlvalue(@$_POST["name"], true).", " .sqlvalue(@$_POST["address"], true).", "
  .sqlvalue(@$_POST["postcode"], true).", " .sqlvalue(@$_POST["city"], true).", "
  .sqlvalue(@$_POST["province"], true).", " .sqlvalue(@$_POST["country"], true).", "
  .sqlvalue(@$_POST["staffpos"], true).", " .sqlvalue(@$_POST["epf"], true).", "
  .sqlvalue(@$_POST["socso"], true).", " .sqlvalue(@$_POST["tax"], true).", "
  .sqlvalue(@$_POST["zakat"], true).", " .sqlvalue(@$_POST["nric"], true).", "
  .sqlvalue(@$_POST["dob"], true).", " .sqlvalue(@$_POST["gender"], false).", "
  .sqlvalue(@$_POST["marital_status"], false).", " .sqlvalue(@$_POST["race"], true).", "
  .sqlvalue(@$_POST["religion"], true).", " .sqlvalue(@$_POST["nationality"], true).", "
  .sqlvalue(@$_POST["telno"], true).", " .sqlvalue(@$_POST["faxno"], true).", "
  .sqlvalue(@$_POST["mobile"], true).", " .sqlvalue(@$_POST["email"], true).", "
  .sqlvalue(@$_POST["medical_history"], true).", " .sqlvalue(@$_POST["medical_claim"], false).", "
  .sqlvalue(@$_POST["blood_group"], false).", " .sqlvalue(@$_POST["ed_qualification"], true).", "
  .sqlvalue(@$_POST["ed_institution"], true).", " .sqlvalue(@$_POST["prev_company_name"], true).", "
  .sqlvalue(@$_POST["prev_digsination"], true).", " .sqlvalue(@$_POST["prev_salary"], false).", "
  .sqlvalue(date("Y-m-d H:i:s"), true).", " .sqlvalue(@$_POST["date_confirmed"], true).", "
  .sqlvalue(@$_POST["date_resignation"], true).", ".sqlvalue(@$_POST["probation"], false).", "
  .sqlvalue(date("Y-m-d H:i:s"), true).", " .sqlvalue(date("Y-m-d H:i:s"), true).", "
  .sqlvalue($id, false).", " .sqlvalue($id, false).", " .sqlvalue(@$_POST["file_doc"], true).", "
  .sqlvalue(@$_POST["file_pic"], true).", " .sqlvalue(@$_POST["contact_person"], true).", "
  .sqlvalue(@$_POST["contact_number"], true).", " .sqlvalue(@$_POST["optional"], true).", "
  .sqlvalue(@$_POST["remark"], true).")";
  mysql_query($sql, $conn) or die(mysql_error());
}

function sql_insert_leave($yearly_entitle,$leave_type_id,$profile_id)
{
  global $conn;
  global $id;
  global $_POST;

  $sql = "insert into `leave_profile` (`leave_profile_id`, `profile_id`, `yearly_entitle`, `leave_type_id`, `active`, `date_created`, `date_modified`, `created_by`, `modified_by`) values ("
  .sqlvalue("NULL", false).", " .sqlvalue($profile_id, false).", "
  .sqlvalue($yearly_entitle, false).", " .sqlvalue($leave_type_id, false).", "
  .sqlvalue("1", false).", "
  .sqlvalue(date("Y-m-d H:i:s"), true).", ".sqlvalue(date("Y-m-d H:i:s"), true).", "
  .sqlvalue($id, false).", ".sqlvalue($id, false).")";
  mysql_query($sql, $conn) or die(mysql_error());
}

function sql_insert_adjustment($profile_id)
{
  global $conn;
  global $id;
  global $_POST;

  $sql = "insert into `leave_dat` (
  `leave_id`,
  `profile_id`,
  `leave_type_id`,
  `date_from`,
  `date_to`,
  `period`,
  `am_from`,
  `am_to`,
  `remark`,
  `handler`,
  `indicator`,
  `date_created`,
  `date_modified`,
  `created_by`,
  `modified_by`) values ("
  .sqlvalue("NULL", false).", "
  .sqlvalue($profile_id, false).", "
  .sqlvalue("1", false).", "
  .sqlvalue("NULL", false).", "
  .sqlvalue("NULL", false).", "
  .sqlvalue("1", false).", "
  .sqlvalue("NULL", false).", "
  .sqlvalue("NULL", false).", "
  .sqlvalue("NULL", false).", "
  .sqlvalue("NULL", false).", "
  .sqlvalue("11", false).", "
  .sqlvalue(date("Y-m-d H:i:s"), true).", "
  .sqlvalue(date("Y-m-d H:i:s"), true).", "
  .sqlvalue($id, false).", "
  .sqlvalue($id, false).")";
  mysql_query($sql, $conn) or die(mysql_error());
}

function sql_get_leave()
{
  global $conn;
  global $_POST;
  $gender = "";

  switch (@$_POST["gender"]) {
      case 1://Female
      $gender = " WHERE apply_to <> 2";
      break;
      case 2://Male
      $gender = " WHERE apply_to <> 1";
      break;
  }

  $sql = "SELECT * FROM leave_type".$gender;
  $res = mysql_query($sql,$conn) or die(mysql_error());
  return $res;
}

function sql_update()
{
  global $conn;
  global $_POST;
  global $id;

  $sql = "update `profile` set `profile_id`=" .sqlvalue(@$_POST["profile_id"], false)
  .", `employee_id`=" .sqlvalue(@$_POST["employee_id"], true).", `access_level`=" .sqlvalue(@$_POST["access_level"], false)
  .", `dept_id`=" .sqlvalue(@$_POST["dept_id"], false).", `name`=" .sqlvalue(@$_POST["name"], true)
  .", `address`=" .sqlvalue(@$_POST["address"], true).", `postcode`=" .sqlvalue(@$_POST["postcode"], true)
  .", `city`=" .sqlvalue(@$_POST["city"], true).", `province`=" .sqlvalue(@$_POST["province"], true)
  .", `country`=" .sqlvalue(@$_POST["country"], true).", `staffpos`=" .sqlvalue(@$_POST["staffpos"], true)
  .", `epf`=" .sqlvalue(@$_POST["epf"], true).", `socso`=" .sqlvalue(@$_POST["socso"], true)
  .", `tax`=" .sqlvalue(@$_POST["tax"], true).", `zakat`=" .sqlvalue(@$_POST["zakat"], true)
  .", `nric`=" .sqlvalue(@$_POST["nric"], true).", `dob`=" .sqlvalue(@$_POST["dob"], true)
  .", `gender`=" .sqlvalue(@$_POST["gender"], false).", `marital_status`=" .sqlvalue(@$_POST["marital_status"], false)
  .", `race`=" .sqlvalue(@$_POST["race"], true).", `religion`=" .sqlvalue(@$_POST["religion"], true)
  .", `nationality`=" .sqlvalue(@$_POST["nationality"], true).", `telno`=" .sqlvalue(@$_POST["telno"], true)
  .", `faxno`=" .sqlvalue(@$_POST["faxno"], true).", `mobile`=" .sqlvalue(@$_POST["mobile"], true)
  .", `email`=" .sqlvalue(@$_POST["email"], true).", `medical_history`=" .sqlvalue(@$_POST["medical_history"], true)
  .", `medical_claim`=" .sqlvalue(@$_POST["medical_claim"], false).", `blood_group`=" .sqlvalue(@$_POST["blood_group"], false)
  .", `ed_qualification`=" .sqlvalue(@$_POST["ed_qualification"], true).", `ed_institution`=" .sqlvalue(@$_POST["ed_institution"], true)
  .", `prev_company_name`=" .sqlvalue(@$_POST["prev_company_name"], true).", `prev_digsination`=" .sqlvalue(@$_POST["prev_digsination"], true)
  .", `prev_salary`=" .sqlvalue(@$_POST["prev_salary"], false).", `date_joined`=" .sqlvalue(@$_POST["date_joined"], true)
  .", `date_confirmed`=" .sqlvalue(@$_POST["date_confirmed"], true).", `date_resignation`=" .sqlvalue(@$_POST["date_resignation"], true)
  .", `probation`=" .sqlvalue(@$_POST["probation"], false)
  .", `date_created`=" .sqlvalue(@$_POST["date_created"], true).", `date_modified`=" .sqlvalue(date("Y-m-d H:i:s"), true)
  .", `modified_by`=" .sqlvalue($id, false).", `created_by`=" .sqlvalue(@$_POST["created_by"], false)
  //.", `file_doc`=" .sqlvalue(@$_POST["file_doc"], true).", `file_pic`=" .sqlvalue(@$_POST["file_pic"], true)
  .", `contact_person`=" .sqlvalue(@$_POST["contact_person"], true).", `contact_number`=" .sqlvalue(@$_POST["contact_number"], true)
  .", `optional`=" .sqlvalue(@$_POST["optional"], true).", `remark`=" .sqlvalue(@$_POST["remark"], true)
  ." where " .primarykeycondition();
  mysql_query($sql, $conn) or die(mysql_error());
}

function sql_delete()
{
  global $conn;

  $sql = "delete from `profile` where ".primarykeycondition();
  mysql_query($sql, $conn) or die(mysql_error());
}

function primarykeycondition()
{
  global $_POST;
  $pk = "";
  $pk .= "(`profile_id`";
  if (@$_POST["xprofile_id"] == "") {
    $pk .= " IS NULL";
  }else{
  $pk .= " = " .sqlvalue(@$_POST["xprofile_id"], false);
  };
  $pk .= ")";
  return $pk;
}
?>

<?php 
//************************************************************************************************************************************************
//  VIEW RECORD MODULE
//************************************************************************************************************************************************

function viewrec($recid)
{
  global $primarykey;
  
  $res = sql_select_main();
  $count = sql_getrecordcount_main();
  mysql_data_seek($res, $recid);
  $row = mysql_fetch_assoc($res);
  
  $primarykey = $row["profile_id"];
  $res = sql_select();
  $row = mysql_fetch_assoc($res);
  showrecnav("view", $recid, $count);
?>
<br>
<?php showrow($row, $recid) ?>
<br>
<hr size="1" color=#dcdbdb noshade>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=edit&recid=<?php echo $recid ?>">Edit Record</a></td>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?a=del&recid=<?php echo $recid ?>">Delete Record</a></td>
</tr>
</table>
<?php
  mysql_free_result($res);
} ?>

<?php
//************************************************************************************************************************************************
//  EDIT RECORD MODULE
//************************************************************************************************************************************************
function editrec($recid)
{
  global $primarykey;
  
  $res = sql_select_main();
  $count = sql_getrecordcount_main();
  mysql_data_seek($res, $recid);
  $row = mysql_fetch_assoc($res);

  $primarykey = $row["profile_id"];
  $res = sql_select();
  $row = mysql_fetch_assoc($res);
  showrecnav("edit", $recid, $count);
?>
<br>
<form enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" name="sql" value="update">
<input type="hidden" name="xprofile_id" value="<?php echo $row["profile_id"] ?>">
<?php showroweditor($row, true); ?>
<p><input type="submit" name="action" value="Post"></p>
</form>
<?php
  mysql_free_result($res);
} ?>

<?php
//************************************************************************************************************************************************
//  DELETE RECORD MODULE
//************************************************************************************************************************************************
function deleterec($recid)
{
  global $primarykey;
  
  $res = sql_select_main();
  $count = sql_getrecordcount_main();
  mysql_data_seek($res, $recid);
  $row = mysql_fetch_assoc($res);
  
  $primarykey = $row["profile_id"];
  $res = sql_select();
  $row = mysql_fetch_assoc($res);
  showrecnav("del", $recid, $count);
?>
<br>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" name="sql" value="delete">
<input type="hidden" name="xprofile_id" value="<?php echo $row["profile_id"] ?>">
<?php showrow($row, $recid) ?>
<p><input type="submit" name="action" value="Confirm"></p>
</form>
<?php
  mysql_free_result($res);
} ?>

<?php
//************************************************************************************************************************************************
//  ADD RECORD MODULE
//************************************************************************************************************************************************
function addrec()
{
global $id;
?>
<table class="bd" border="0" cellspacing="1" cellpadding="4">
<tr>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>">Index Page</a></td>
</tr>
</table>
<hr size="1" color=#dcdbdb noshade>
<form enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p><input type="hidden" name="sql" value="insert"></p>
<?php
  $r = mysql_query("SHOW TABLE STATUS LIKE 'profile' ");
  $row = mysql_fetch_array($r);
  $auto_increment = $row['Auto_increment'];
  $row = array(
  "profile_id" => $auto_increment,
  "employee_id" => "",
  "access_level" => 3,
  "dept_id" => 1,
  "name" => "",
  "address" => "",
  "postcode" => "",
  "city" => "",
  "province" => "",
  "country" => "",
  "staffpos" => "",
  "epf" => "",
  "socso" => "",
  "tax" => "",
  "zakat" => "",
  "nric" => "",
  "dob" => "",
  "gender" => 1,
  "marital_status" => 1,
  "race" => "",
  "religion" => "",
  "nationality" => "",
  "telno" => "",
  "faxno" => "",
  "mobile" => "",
  "email" => "",
  "medical_history" => "",
  "medical_claim" => 300,
  "blood_group" => 3,
  "ed_qualification" => "",
  "ed_institution" => "",
  "prev_company_name" => "",
  "prev_digsination" => "",
  "prev_salary" => "",
  "file_doc" => "",
  "file_pic" => "default.gif",
  "date_joined" => date("Y-m-d"),
  "date_confirmed" => "",
  "date_resignation" => "",
  "probation" => 1,
  "date_created" => date("Y-m-d H:i:s"),
  "date_modified" => date("Y-m-d H:i:s"),
  "created_by" => $id,
  "modified_by" => $id);

  if (isset($_POST["name"])) $row["name"] = @$_POST["name"];
  if (isset($_POST["nric"])) $row["nric"] = @$_POST["nric"];
  if (isset($_POST["dob"])) $row["dob"] = @$_POST["dob"];
  if (isset($_POST["address"])) $row["address"] = @$_POST["address"];
  if (isset($_POST["gender"])) $row["gender"] = @$_POST["gender"];
  if (isset($_POST["postcode"])) $row["postcode"] = @$_POST["postcode"];
  if (isset($_POST["marital_status"])) $row["marital_status"] = @$_POST["marital_status"];
  if (isset($_POST["city"])) $row["city"] = @$_POST["city"];
  if (isset($_POST["province"])) $row["province"] = @$_POST["province"];
  if (isset($_POST["race"])) $row["race"] = @$_POST["race"];
  if (isset($_POST["country"])) $row["country"] = @$_POST["country"];
  if (isset($_POST["religion"])) $row["religion"] = @$_POST["religion"];
  if (isset($_POST["nationality"])) $row["nationality"] = @$_POST["nationality"];
  if (isset($_POST["epf"])) $row["epf"] = @$_POST["epf"];
  if (isset($_POST["socso"])) $row["socso"] = @$_POST["socso"];
  if (isset($_POST["medical_history"])) $row["medical_history"] = @$_POST["medical_history"];
  if (isset($_POST["email"])) $row["email"] = @$_POST["email"];
  if (isset($_POST["tax"])) $row["tax"] = @$_POST["tax"];
  if (isset($_POST["zakat"])) $row["zakat"] = @$_POST["zakat"];
  if (isset($_POST["blood_group"])) $row["blood_group"] = @$_POST["blood_group"];
  if (isset($_POST["telno"])) $row["telno"] = @$_POST["telno"];
  if (isset($_POST["faxno"])) $row["faxno"] = @$_POST["faxno"];
  if (isset($_POST["mobile"])) $row["mobile"] = @$_POST["mobile"];
  if (isset($_POST["ed_qualification"])) $row["ed_qualification"] = @$_POST["ed_qualification"];
  if (isset($_POST["ed_institution"])) $row["ed_institution"] = @$_POST["ed_institution"];
  if (isset($_POST["prev_company_name"])) $row["prev_company_name"] = @$_POST["prev_company_name"];
  if (isset($_POST["prev_digsination"])) $row["prev_digsination"] = @$_POST["prev_digsination"];
  if (isset($_POST["prev_salary"])) $row["prev_salary"] = @$_POST["prev_salary"];

  showroweditor($row, false);
?>
<p><input type="submit" name="action" value="Post"></p>
</form>
<?php } ?>

<?php
//************************************************************************************************************************************************
//  SHOW ROW EDITOR MODULE
//************************************************************************************************************************************************
function showroweditor($row)
{
global $a;
?>
<script src="js/calendar.js" type="text/javascript"></script>
<table class="tbl" border="0" cellspacing="1" cellpadding="5" width="90%">
<tr>
    <td class="hr" width="130">System ID</td>
    <td class="dr" width="40%"><input class="input2" type="text" name="profile_id" value="<?php echo str_replace('"', '&quot;', trim($row["profile_id"])) ?>"></td>
    <td></td>
    <td class="dr" rowspan="6" width="130"><img src="picture/<?php if (strlen($row["file_pic"])<4){echo "default.gif";} else {echo htmlspecialchars($row["file_pic"]);} ?>" width="130" height="155"/></td>
  </tr>
  <tr>
    <td class="hr">Name</td>
    <td class="dr"><input class="input2" type="text" name="name" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["name"])) ?>"></td>
  </tr>
  <tr>
    <td class="hr">Access Level</td>
    <td class="dr"><?php set_option_desc("access_level","access_level",$row["access_level"]) ?></td>
    <td></td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td class="hr">Employee ID</td>
    <td class="dr"><input class="input2" type="text" name="employee_id" maxlength="25" value="<?php echo str_replace('"', '&quot;', trim($row["employee_id"])) ?>"></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Designation</td>
    <td class="dr"><input class="input2" type="text" name="staffpos" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["staffpos"])) ?>"></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Department</td>
    <td class="dr"><?php set_option_desc("dept_id","dept",$row["dept_id"]) ?></td>
    <td colspan="3" width="389"></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr">Race</td>
    <td class="dr" width="40%"><input class="input2" type="text" name="race" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["race"])) ?>"></td>
  </tr>
  <tr>
    <td rowspan="3" class="hr" height="60" valign=top>Address</td>
    <td rowspan="3" class="dr" valign=top><textarea class="input2" cols="35" rows="4" name="address" maxlength="255"><?php echo str_replace('"', '&quot;', trim($row["address"])) ?></textarea></td>
    <td></td>
    <td class="hr">Religion</td>
    <td class="dr"><input class="input2" type="text" name="religion" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["religion"])) ?>"></td>
  </tr>
  <tr>
    <td></td>
    <td class="hr">Nationality</td>
    <td class="dr"><input class="input2" type="text" name="nationality" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["nationality"])) ?>"></td>
  </tr>
  <tr>
    <td></td>
    <td class="hr">Gender</td>
    <td class="dr"><?php set_option_desc("gender","gender",$row["gender"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Postcode</td>
    <td class="dr"><input class="input2" type="text" name="postcode" maxlength="5" value="<?php echo str_replace('"', '&quot;', trim($row["postcode"])) ?>"></td>
    <td></td>
    <td class="hr">Marital Status</td>
    <td class="dr"><?php set_option_desc("marital_status","marital_status",$row["marital_status"]) ?></td>
  </tr>
  <tr>
    <td class="hr">City</td>
    <td class="dr"><input class="input2" type="text" name="city" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["city"])) ?>"></td>
    <td colspan="3" width="389"></td>
  </tr>
  <tr>
    <td class="hr">State</td>
    <td class="dr"><input class="input2" type="text" name="province" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["province"])) ?>"></td>
    <td></td>
    <td colspan="2"><b>Medical Details</b></td>
  </tr>
  <tr>
    <td class="hr">Country</td>
    <td class="dr"><input class="input2" type="text" name="country" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["country"])) ?>"></td>
    <td></td>
    <td class="hr">Claim Limit</td>
    <td class="dr"><input class="input2" type="text" name="medical_claim" maxlength="11" value="<?php echo str_replace('"', '&quot;', trim($row["medical_claim"])) ?>"></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr">Blood Group</td>
    <td class="dr"><?php set_option_desc("blood_group","blood_group",$row["blood_group"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Telephone</td>
    <td class="dr"><input class="input2" type="text" name="telno" maxlength="25" value="<?php echo str_replace('"', '&quot;', trim($row["telno"])) ?>"></td>
    <td></td>
    <td class="hr" rowspan="3" valign=top>History</td>
    <td class="dr" rowspan="3" valign=top><textarea class="input2" cols="35" rows="4" name="medical_history" maxlength="255"><?php echo str_replace('"', '&quot;', trim($row["medical_history"])) ?></textarea></td>
  </tr>
  <tr>
    <td class="hr">Fax</td>
    <td class="dr"><input class="input2" type="text" name="faxno" maxlength="25" value="<?php echo str_replace('"', '&quot;', trim($row["faxno"])) ?>"></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Mobile</td>
    <td class="dr"><input class="input2" type="text" name="mobile" maxlength="25" value="<?php echo str_replace('"', '&quot;', trim($row["mobile"])) ?>"></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Email</td>
    <td class="dr"><input class="input2" type="text" name="email" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["email"])) ?>"></td>
    <td colspan="3"></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td colspan="2"><b>Highest Education</b></td>
  </tr>
  <tr>
    <td class="hr">TAX</td>
    <td class="dr"><input class="input2" type="text" name="tax" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["tax"])) ?>"></td>
    <td></td>
    <td class="hr">Qualification</td>
    <td class="dr"><input class="input2" type="text" name="ed_qualification" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["ed_qualification"])) ?>"></td>
  </tr>
  <tr>
    <td class="hr">EPF</td>
    <td class="dr"><input class="input2" type="text" name="epf" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["epf"])) ?>"></td>
    <td></td>
    <td class="hr">Institution</td>
    <td class="dr"><input class="input2" type="text" name="ed_institution" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["ed_institution"])) ?>"></td>
  </tr>
  <tr>
    <td class="hr">SOCSO</td>
    <td class="dr"><input class="input2" type="text" name="socso" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["socso"])) ?>"></td>
    <td colspan="3"></td>
  </tr>
  <tr>
    <td class="hr">Zakat</td>
    <td class="dr"><input class="input2" type="text" name="zakat" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["zakat"])) ?>"></td>
    <td></td>
    <td colspan="2"><b>Employment History</b></td>
  </tr>
  <tr>
    <td class="hr">NIRC / Passport</td>
    <td class="dr"><input class="input2" type="text" name="nric" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["nric"])) ?>"></td>
    <td></td>
    <td class="hr">Company Name</td>
    <td class="dr"><input class="input2" type="text" name="prev_company_name" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["prev_company_name"])) ?>"></td>
  </tr>
  <tr>
    <td class="hr">Date of Birth</td>
    <td class="dr"><?php set_date_option('dob',$row["dob"]); ?></td>
    <td></td>
    <td class="hr">Designation</td>
    <td class="dr"><input class="input2" type="text" name="prev_digsination" maxlength="30" value="<?php echo str_replace('"', '&quot;', trim($row["prev_digsination"])) ?>"></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr">Salary</td>
    <td class="dr"><input class="input2" type="text" name="prev_salary" maxlength="11" value="<?php echo str_replace('"', '&quot;', trim($row["prev_salary"])) ?>"></td>
  </tr>
  <tr>
    <td class="hr">Probation (Months)</td>
    <td class="dr"><?php set_option_desc('probation','probation',$row["probation"]); ?></td>
    <td colspan="3"></td>
  </tr>
  <tr>
    <td class="hr">Joined Date</td>
    <td class="dr"><?php set_date_option('date_joined',$row["date_joined"]); ?></td>
    <td></td>
    <td colspan="2"><b>Emergency Contact Person</b></td>
  </tr>
  <tr>
    <td class="hr">Confirmed Date</td>
    <td class="dr"><?php set_date_option('date_confirmed',$row["date_confirmed"]); ?></td>
    <td></td>
    <td class="hr">Name</td>
    <td class="dr"><input class="input2" type="text" name="contact_person" maxlength="50" value="<?php echo str_replace('"', '&quot;', trim($row["contact_person"])) ?>"></td>
  </tr>
  <tr>
    <td class="hr">Resignation Date</td>
    <td class="dr"><?php set_date_option('date_resignation',$row["date_resignation"]); ?></td>
    <td></td>
    <td class="hr">Contact Number</td>
    <td class="dr"><input class="input2" type="text" name="contact_number" maxlength="11" value="<?php echo str_replace('"', '&quot;', trim($row["contact_number"])) ?>"></td>
  </tr>
  <tr>
    <td colspan="5">&nbsp;</td>
  </tr>
  <tr>
    <td class="hr">Attachment</td>
    <td class="sr"><?php if (strlen($row["file_doc"])>4){ ?><a href="<?php echo htmlspecialchars(curPageURL()."/upload/".$row["file_doc"]) ?>">Download File</a><?php } ?></td>
    <td></td>
    <td rowspan="4" class="hr" valign=top>Optional</td>
    <td rowspan="4" class="dr" valign=top><textarea name="optional" cols="30" rows="6" maxlength="255" class="input2"><?php echo htmlspecialchars($row["optional"]) ?></textarea></td>
  </tr>
  <tr>
    <td></td>
    <td class="sr" align="right">&nbsp;<?php if($a=="edit"){?><input type="button" value="upload" onclick="showPopWin('com/upload.php?pid=<?php echo htmlspecialchars($row["profile_id"]) ?>&sid=<?php echo rand(1000,9999); ?>', 400, 300, null);"><?php } ?></td>
    <td></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Date Created</td>
    <td class="sr"><?php echo htmlspecialchars($row["date_created"]) ?></td>
    <td colspan="3"></td>
  </tr>
  <tr>
    <td class="hr">Created By</td>
    <td class="sr"><?php echo get_author($row["created_by"]) ?></td>
    <td></td>
    <td rowspan="3" class="hr" valign=top>Remark</td>
    <td rowspan="3" class="dr" valign=top><textarea name="remark" cols="30" rows="4" maxlength="255" class="input2"><?php echo htmlspecialchars($row["remark"]) ?></textarea></td>
  </tr>
  <tr>
    <td class="hr">Date Modified</td>
    <td class="sr"><?php echo htmlspecialchars($row["date_modified"]) ?></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Modified By</td>
    <td class="sr"><?php echo get_author($row["modified_by"]) ?></td>
    <td></td>
  </tr>
</table>
<input type="hidden" name="date_created" value="<?php echo str_replace('"', '&quot;', trim($row["date_created"])) ?>">
<input type="hidden" name="date_modified" value="<?php echo str_replace('"', '&quot;', trim($row["date_modified"])) ?>">
<input type="hidden" name="created_by" value="<?php echo str_replace('"', '&quot;', trim($row["created_by"])) ?>">
<input type="hidden" name="modified_by" value="<?php echo str_replace('"', '&quot;', trim($row["modified_by"])) ?>">
<?php } ?>

<?php
//************************************************************************************************************************************************
//  SHOW ROW MODULE
//************************************************************************************************************************************************
function showrow($row)
  {
?>
<table class="tbl" border="0" cellspacing="1" cellpadding="5" width="90%" style='table-layout:fixed'>
<tr>
    <td class="hr" width="130">System ID</td>
    <td class="dr"><?php echo htmlspecialchars($row["profile_id"]) ?></td>
    <td width="20">&nbsp;</td>
    <td class="dr" rowspan="6" width="130"><img src="picture/<?php if (strlen($row["file_pic"])<4){echo "default.gif";} else {echo htmlspecialchars($row["file_pic"]);} ?>" width="130" height="155"/></td>
  </tr>
  <tr>
    <td class="hr">Name</td>
    <td class="dr"><?php echo htmlspecialchars($row["name"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Access Level</td>
    <td class="dr"><?php echo htmlspecialchars(get_desc("access_level", $row["access_level"])) ?></td>
    <td></td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td class="hr">Employee ID</td>
    <td class="dr"><?php echo htmlspecialchars($row["employee_id"]) ?></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Designation</td>
    <td class="dr"><?php echo htmlspecialchars($row["staffpos"]) ?></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Department</td>
    <td class="dr"><?php echo htmlspecialchars(get_desc("dept", $row["dept_id"])) ?></td>
    <td colspan="3" width="389"></td>
  </tr>
  <tr>
    <td colspan="3" width="410"></td>
    <td class="hr">Race</td>
    <td class="dr"><?php echo htmlspecialchars($row["race"]) ?></td>
  </tr>
  <tr>
    <td rowspan="3" class="hr" height="60" valign=top>Address</td>
    <td rowspan="3" class="dr" valign=top><textarea cols="30" rows="4" maxlength="255" class="tads" readonly><?php echo htmlspecialchars($row["address"]) ?></textarea></td>
    <td></td>
    <td class="hr">Religion</td>
    <td class="dr"><?php echo htmlspecialchars($row["religion"]) ?></td>
  </tr>
  <tr>
    <td></td>
    <td class="hr">Nationality</td>
    <td class="dr"><?php echo htmlspecialchars($row["nationality"]) ?></td>
  </tr>
  <tr>
    <td></td>
    <td class="hr">Gender</td>
    <td class="dr"><?php echo htmlspecialchars(get_desc("gender", $row["gender"])) ?></td>
  </tr>
  <tr>
    <td class="hr">Postcode</td>
    <td class="dr"><?php echo htmlspecialchars($row["postcode"]) ?></td>
    <td></td>
    <td class="hr">Marital Status</td>
    <td class="dr"><?php echo htmlspecialchars(get_desc("marital_status", $row["marital_status"])) ?></td>
  </tr>
  <tr>
    <td class="hr">City</td>
    <td class="dr"><?php echo htmlspecialchars($row["city"]) ?></td>
    <td colspan="3" width="389"></td>
  </tr>
  <tr>
    <td class="hr">State</td>
    <td class="dr"><?php echo htmlspecialchars($row["province"]) ?></td>
    <td></td>
    <td colspan="2"><b>Medical Details</b></td>
  </tr>
  <tr>
    <td class="hr">Country</td>
    <td class="dr"><?php echo htmlspecialchars($row["country"]) ?></td>
    <td></td>
    <td class="hr">Claim Limit</td>
    <td class="dr"><?php echo htmlspecialchars($row["medical_claim"]) ?></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr">Blood Group</td>
    <td class="dr"><?php echo htmlspecialchars(get_desc("blood_group", $row["blood_group"])) ?></td>
  </tr>
  <tr>
    <td class="hr">Telephone</td>
    <td class="dr"><?php echo htmlspecialchars($row["telno"]) ?></td>
    <td></td>
    <td class="hr" rowspan="3" valign=top>History</td>
    <td class="dr" rowspan="3" valign=top width="150px"><textarea cols="30" rows="4" maxlength="255" class="tads" readonly><?php echo htmlspecialchars($row["medical_history"]) ?></textarea></td>
  </tr>
  <tr>
    <td class="hr">Fax</td>
    <td class="dr"><?php echo htmlspecialchars($row["faxno"]) ?></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Mobile</td>
    <td class="dr"><?php echo htmlspecialchars($row["mobile"]) ?></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Email</td>
    <td class="dr"><?php echo htmlspecialchars($row["email"]) ?></td>
    <td colspan="3"></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td colspan="2"><b>Highest Education</b></td>
  </tr>
  <tr>
    <td class="hr">TAX</td>
    <td class="dr"><?php echo htmlspecialchars($row["tax"]) ?></td>
    <td></td>
    <td class="hr">Qualification</td>
    <td class="dr"><?php echo htmlspecialchars($row["ed_qualification"]) ?></td>
  </tr>
  <tr>
    <td class="hr">EPF</td>
    <td class="dr"><?php echo htmlspecialchars($row["epf"]) ?></td>
    <td></td>
    <td class="hr">Institution</td>
    <td class="dr"><?php echo htmlspecialchars($row["ed_institution"]) ?></td>
  </tr>
  <tr>
    <td class="hr">SOCSO</td>
    <td class="dr"><?php echo htmlspecialchars($row["socso"]) ?></td>
    <td colspan="3"></td>
  </tr>
  <tr>
    <td class="hr">Zakat</td>
    <td class="dr"><?php echo htmlspecialchars($row["zakat"]) ?></td>
    <td></td>
    <td colspan="2"><b>Employment History</b></td>
  </tr>
  <tr>
    <td class="hr">NIRC / Passport</td>
    <td class="dr"><?php echo htmlspecialchars($row["nric"]) ?></td>
    <td></td>
    <td class="hr">Company Name</td>
    <td class="dr"><?php echo htmlspecialchars($row["prev_company_name"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Date of Birth</td>
    <td class="dr"><?php echo htmlspecialchars($row["dob"]) ?></td>
    <td></td>
    <td class="hr">Designation</td>
    <td class="dr"><?php echo htmlspecialchars($row["prev_digsination"]) ?></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td class="hr">Salary</td>
    <td class="dr"><?php echo htmlspecialchars($row["prev_salary"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Probation (Months)</td>
    <td class="dr"><?php echo htmlspecialchars(get_desc("probation",$row["probation"])) ?></td>
    <td colspan="3"></td>
  </tr>
  <tr>
    <td class="hr">Joined Date</td>
    <td class="dr"><?php echo htmlspecialchars($row["date_joined"]) ?></td>
    <td></td>
    <td colspan="2"><b>Emergency Contact Person</b></td>
  </tr>
  <tr>
    <td class="hr">Confirmed Date</td>
    <td class="dr"><?php echo htmlspecialchars($row["date_confirmed"]) ?></td>
    <td></td>
    <td class="hr">Name</td>
    <td class="dr"><?php echo htmlspecialchars($row["contact_person"]) ?></td>
  </tr>
  <tr>
    <td class="hr">Resignation Date</td>
    <td class="dr"><?php echo htmlspecialchars($row["date_resignation"]) ?></td>
    <td></td>
    <td class="hr">Contact Number</td>
    <td class="dr"><?php echo htmlspecialchars($row["contact_number"]) ?></td>
  </tr>
  <tr>
    <td colspan="5">&nbsp;</td>
  </tr>
  <tr>
    <td class="hr">Attachment</td>
    <td class="sr"><?php if (strlen($row["file_doc"])>4){ ?><a href="<?php echo htmlspecialchars(curPageURL()."/upload/".$row["file_doc"]) ?>">Download File</a><?php } ?></td>
    <td></td>
    <td rowspan="4" class="hr" valign=top>Optional</td>
    <td rowspan="4" class="dr" valign=top><textarea cols="30" rows="6" maxlength="255" class="tads" readonly><?php echo htmlspecialchars($row["optional"]) ?></textarea></td>
  </tr>
  <tr>
    <td></td>
    <td class="sr">&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td colspan="2"></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Date Created</td>
    <td class="sr"><?php echo htmlspecialchars($row["date_created"]) ?></td>
    <td colspan="3"></td>
  </tr>
  <tr>
    <td class="hr">Created By</td>
    <td class="sr"><?php echo get_author($row["created_by"]) ?></td>
    <td></td>
    <td rowspan="3" class="hr" valign=top>Remark</td>
    <td rowspan="3" class="dr" valign=top><textarea cols="30" rows="4" maxlength="255" class="tads" readonly><?php echo htmlspecialchars($row["remark"]) ?></textarea></td>
  </tr>
  <tr>
    <td class="hr">Date Modified</td>
    <td class="sr"><?php echo htmlspecialchars($row["date_modified"]) ?></td>
    <td></td>
  </tr>
  <tr>
    <td class="hr">Modified By</td>
    <td class="sr"><?php echo get_author($row["modified_by"]) ?></td>
    <td></td>
  </tr>
</table>
<?php } ?>

<?php
//************************************************************************************************************************************************
//  MY MODULE
//************************************************************************************************************************************************
function get_author($id)
{
	global $conn;

	$sql = "SELECT `name` FROM `profile` WHERE `profile_id` = ".$id;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row["name"];
	}
}

function get_desc($table, $idvalue)
{
	global $conn;

	$sql = "SELECT `".$table."_desc` FROM `".$table."` WHERE `".$table."_id` = ".$idvalue;
	$res = mysql_query($sql, $conn);
	if ($res)
	{
		$row = mysql_fetch_assoc($res);
		return $row[$table."_desc"];
	}
}

function set_option_desc($name, $table, $idvalue)
{
	global $conn;

	$sql = "SELECT * FROM `".$table."`";//<option value=""></option>
	$res = mysql_query($sql, $conn) or die(mysql_error());?>
	<select name="<?php echo $name ?>" class="input2">
	<?php while($row = mysql_fetch_array($res))
	{?>
	<option value="<?php echo $row[$table."_id"] ?>" <?php if ($idvalue == $row[$table."_id"]) { echo "selected"; } ?>><?php echo $row[$table."_desc"] ?></option>
	<?php } ?>
	</select><?php
	 mysql_free_result($res);
}

function set_date_option($name,$date)
{
	if ($date != NULL)
	{
		?><script>DateInput('<?php echo trim($name) ?>', false,'YYYY-MM-DD','<?php echo trim($date) ?>')</script><?php
	}
	else
	{
		?><script>DateInput('<?php echo trim($name) ?>', false,'YYYY-MM-DD')</script><?php
	}
}

function curPageURL() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].substr($_SERVER["SCRIPT_NAME"],0,strrpos($_SERVER["SCRIPT_NAME"],"/"));//$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].substr($_SERVER["SCRIPT_NAME"],0,strrpos($_SERVER["SCRIPT_NAME"],"/"));//$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 return $pageURL;
}

?>
