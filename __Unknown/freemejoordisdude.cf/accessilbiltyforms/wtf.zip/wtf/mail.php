<?php

$to = "resultdropper@yandex.com";

?>