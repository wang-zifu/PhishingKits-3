<?php

// This file is here solely to protect your directory.

// Look for Settings.php....
if (file_exists("../blow_include/settings.php"))
{
	// Found it!
	require"../blow_include/settings.php";
	header('Location: ' . $address);
}
// Can't find it... just forget it.
else
	exit;

?>