(function($) {
$(document).ready(function() {
initialize();
window.initPasswordStrengthFunctions();
});
Wicket.Event.subscribe('/ajax/call/complete', function() {
initialize();
window.initPasswordStrengthFunctions();
});
function initialize() {
var $password;
if ( $('#tf-password1').length != 0 )
{
$password = $('#tf-password1');
}
else if ( $('#mobile-password1') .length != 0 )
{
$password = $('#mobile-password1');
}
var $passwordLabel = $('#passwordLabel');
var $logonIdX = $('#tf-logonIdX');
var $logonIdXLabel = $('#logonIdLabel');
var $tccont = $('#tf-idtype1').parents("div.fRow.nopad");
var $tctext = $tccont.prev("div");
$tctext.hide();
$tccont.hide();
$logonIdX.off('keyup.tf');
$logonIdX.parent().on("keyup.tf", '#tf-logonIdX', function(){
if (tf_needsTypeChooser($('#tf-logonIdX').val())) {
$tctext.show();
$tccont.show();
} else {
$tctext.hide();
$tccont.hide();
}
});
$logonIdX.trigger('keyup.tf');
if($logonIdX.length) {
Wicket.Event.subscribe('/ajax/call/before', function() {
$('#tf-logonId').val(tf_normalizeLogonId($logonIdX.val(),$('#tf-idtype1').is(':checked')));
Wicket.Event.unsubscribe('/ajax/call/before');
});
}
$('#loginForm').on('submit',function(e) {
valid=validateForm();
if(valid) {
$('#tf-logonId').val(tf_normalizeLogonId($logonIdX.val(),$('#tf-idtype1').is(':checked')));
$('input[name="gotoOnFail"]').val($('input[name="gotoOnFail"]').val() + "?loginId="+encodeURIComponent($logonIdX.val()));
tLoader.show();
} else {
return false;
}
});
$('#msisdnLoginForm').on('submit',function(e) {
$logonId = $('#msisdnLoginForm').find('input[name="logonId"]');
$gotoOnFail = $('#msisdnLoginForm').find('input[name="gotoOnFail"]');
valid=validateForm();
if(valid) {
$gotoOnFail.val($gotoOnFail.val() + "?loginId="+encodeURIComponent($logonId.val()));
$logonId.val("36" + $logonId.val());
tLoader.show();
} else {
return false;
}
});
$('#tf-terms').on('click',function(){
$('#tf-terms').parent('label').toggleClass("error", !$('#tf-terms').is(':checked'));
});
function validateForm() {
if ($logonIdX.length) {
var logonIdXInvalid = !$logonIdX.val().trim();
$logonIdX.toggleClass("error", logonIdXInvalid);
$logonIdXLabel.toggleClass("error", logonIdXInvalid);
toggleMessages($logonIdX, logonIdRequiredText, logonIdXInvalid);
}
if ($password.length) {
var passwordInvalid = !$password.val().trim();
$password.toggleClass("error", passwordInvalid);
$passwordLabel.toggleClass("error", passwordInvalid);
toggleMessages($password, passwordRequiredText, passwordInvalid);
}
return !logonIdXInvalid && !passwordInvalid;
}
function toggleMessages(input,message,toggle) {
var $iErrors = input.parent().find('ul');
var hasMsg = $iErrors.find('li').val() != undefined;
$iErrors.toggleClass("iErrors", toggle);
if (toggle && !hasMsg) {
$iErrors.append('<li class="eText eVisible">'+message+'</li>');
} else if (!toggle) {
$iErrors.parent().find('li').remove();
}
}
}
window.isPasswordValid = function() {
if ( $('#tf-password2').length != 0 ) {
return $('#tf-password2').parent().find('.validResponseSign').hasClass('success');
}
}
window.initPasswordStrengthFunctions = function () {
var $pwField1, $pwField2, $pw1Indicator, $pw2Indicator, $validList;
var SUCCESS_CLASS = "success";
var ERROR_CLASS = "error";
var FILLED_ALREADY_CLASS = "tf-filled-already";
var passwordCorrect = false;
if ( $('#tf-password1').length != 0 )
{
$pwField1 = $('#tf-password1');
$pwField2 = $('#tf-password2');
}
else if ( $('#mobile-password1') .length != 0 )
{
$pwField1 = $('#mobile-password1');
$pwField2 = $('#tf-password2');
}
if ( typeof $pwField1 === 'object' && $pwField1.length != 0 && typeof $pwField2 === 'object' && $pwField2.length != 0)
{
$pw1Indicator = $('#'+$pwField1.attr('id')).parent().find('.validResponseSign');
$pw2Indicator = $('#'+$pwField2.attr('id')).parent().find('.validResponseSign');
}
if ( typeof $pw1Indicator === 'object' && $pw1Indicator.length != 0 )
{
$validList = $('.passwordValidList');
if (!$pwField1.hasClass('error') && !$pwField2.hasClass('error') && $pwField1.val() == "" && $pwField2.val() == "") {
$pw1Indicator.hide();
$pw2Indicator.hide();
$validList.find('span.ico').hide();
} else if ($pwField1.hasClass('error') || $pwField2.hasClass('error') && $pwField1.val() == "" && $pwField2.val() == "") {
$pwField1.addClass( FILLED_ALREADY_CLASS );
$pwField2.addClass( FILLED_ALREADY_CLASS );
$pw1Indicator.removeClass( SUCCESS_CLASS ).addClass( ERROR_CLASS );
$pw2Indicator.removeClass( SUCCESS_CLASS ).addClass( ERROR_CLASS );
$pw1Indicator.css({display:'inline-block'});
$pw2Indicator.css({display:'inline-block'});
passwordCorrect = !!checkPasswordStrength();
} else {
passwordCorrect = !!checkPasswordStrength();
}
var inputEvent = getInputEvent();
$pwField1.parent().off("blur.passwordstrength");
$pwField2.parent().off("blur.passwordstrength");
$pwField1.parent().off(inputEvent);
$pwField2.parent().off(inputEvent);
$pwField1.parent().on("blur.passwordstrength",'#'+$pwField1.attr('id'),function(e) {
if (!$pwField1.hasClass( FILLED_ALREADY_CLASS )) {
$pwField1.addClass( FILLED_ALREADY_CLASS );
}
passwordCorrect = !!checkPasswordStrength();
$pw1Indicator.css({display:'inline-block'});
});
$pwField1.parent().on(inputEvent, '#'+$pwField1.attr('id'), function() {
passwordCorrect = !!checkPasswordStrength();
if (passwordCorrect) {
if (!$pwField1.hasClass( FILLED_ALREADY_CLASS )) {
$pwField1.addClass( FILLED_ALREADY_CLASS );
}
$pw1Indicator.removeClass( ERROR_CLASS ).addClass( SUCCESS_CLASS );
$pw1Indicator.css({display:'inline-block'});
} else if ($pwField1.hasClass( FILLED_ALREADY_CLASS )) {
$pw1Indicator.removeClass( SUCCESS_CLASS ).addClass( ERROR_CLASS );
$pw1Indicator.css({display:'inline-block'});
}
signVerifyField();
if (!passwordCorrect) {
$pwField2.val('');
if (!$pwField1.hasClass( FILLED_ALREADY_CLASS )) {
$pw2Indicator.hide();
}
}
});
$pwField2.parent().on("blur.passwordstrength",'#'+$pwField2.attr('id'),function(e) {
if (!passwordCorrect) {
$pwField2.val('');
$pw2Indicator.hide();
} else {
signVerifyField();
$pw2Indicator.css({display:'inline-block'});
}
});
$pwField2.parent().on(inputEvent, '#'+$pwField2.attr('id'), function() {
signVerifyField();
if (passwordCorrect && $pwField1.val() == $pwField2.val()) {
$pw2Indicator.css({display:'inline-block'});
}
});
}
function getInputEvent() {
var ua = window.navigator.userAgent;
var isAndroidDevice = ua.indexOf('Android') > -1;
if (isAndroidDevice ) {
return 'input.passwordstrength'; 
} else {
return 'keyup.passwordstrength';
}
}
function signVerifyField() {
var same = false;
same = $pwField1.val() == $pwField2.val() && $pwField1.val().length > 0 && $pwField2.val().length > 0;
if (same) {
$pw2Indicator.removeClass( ERROR_CLASS ).addClass( SUCCESS_CLASS );
} else {
$pw2Indicator.removeClass( SUCCESS_CLASS ).addClass( ERROR_CLASS );
}
}
function checkPasswordStrength() {
var success = false;
if ( $pwField1.attr('id') == 'tf-password1' )
{
success = !!checkTfPassword($pwField1.val(), $pwField1.hasClass( FILLED_ALREADY_CLASS ));
}
else
{
success = !!checkMobilePassword($pwField1.val(), $pwField1.hasClass( FILLED_ALREADY_CLASS ));
}
return success;
}
function checkTfPassword(pw, showError) {
var minlength = !!toggleChecklist($('#pw-minLength'), pw.length > 7, showError);
var containsLowerCase = !!toggleChecklist($('#pw-containsLowerCase'), !!pw.match(/[a-zöüóőúéáűí]/), showError);
var containsUpperCase = !!toggleChecklist($('#pw-containsUpperCase'), !!pw.match(/[A-ZÖÜÓŐÚÉÁŰÍ]/), showError);
var containsDigit = !!toggleChecklist($('#pw-containsDigit'), !!pw.match(/[0-9]/), showError);
return minlength && containsLowerCase && containsUpperCase && containsDigit;
}
function checkMobilePassword(pw, showError) {
var minlengthAndDigitOnly = !!toggleChecklist($('#pw-minLength-digitOnly'), pw.length == 5 && !!isDigitOnly(pw), showError);
var notIncr = !!toggleChecklist($('#pw-notIncr'), !!isNotIncrement(pw), showError);
var notDecr = !!toggleChecklist($('#pw-notDecr'), !!isNotDecrement(pw), showError);
var notSameDigits = !!toggleChecklist($('#pw-notSameDigits'), !!notMadeFromSameChars(pw), showError);
return minlengthAndDigitOnly && notIncr && notDecr && notSameDigits;
}
function toggleChecklist(element, valid, showError) {
if (valid) {
element.children('span.ico').show();
element.removeClass( ERROR_CLASS ).addClass( SUCCESS_CLASS );
} else if (showError) {
element.children('span.ico').show();
element.removeClass( SUCCESS_CLASS ).addClass( ERROR_CLASS );
} else {
element.children('span.ico').hide();
}
return valid;
}
}
var TF_USERCHANGED_COOKIE = "tf_userChanged";
var TF_LOGGEDIN_COOKIE = "tf_loggedIn";
var TF_LOGONIDTYPE_MSISDN_COOKIE = "tf_logonIdType_msisdn";
var TF_LOGONIDTYPE_MTID_COOKIE = "tf_logonIdType_mtid";
$.cookie = function(cname) {
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) {
var c = ca[i];
while (c.charAt(0)==' ') c = c.substring(1);
if (c.indexOf(name) != -1) return c.substring(name.length, c.length);
}
return "";
}
function is9Digit(logonId) {
return logonId.length == 9 && !!logonId.match(/^[0-9]*$/);
}
function isMsisdnlike(logonId) {
return (logonId.length == 11 || logonId.length == 12 || logonId.length == 13) &&
(!!logonId.match(/^[0-9]*$/) || (logonId[0] == "+" && !!logonId.substring(1,logonId.length).match(/^[0-9]*$/) )
);
}
function normalizeMsisdn(logonId) {
return "36" + logonId;
}
function hasMsisdnPrefix(logonId) {
for (var i = 0; i < TF_MSISDN_PREFIXES.length; i++) {
var prefix = ""+TF_MSISDN_PREFIXES[i];
if (logonId.substr(0, prefix.length) === prefix) {
return true;
}
}
return false;
}
function wasMsisdn(logonId) {
var msisdn = ($.cookie(TF_LOGONIDTYPE_MSISDN_COOKIE) || "").split(',');
for (var i = 0; i<msisdn.length; ++i) {
if (msisdn[i] == logonId) return true;
}
return false;
}
function wasMtid(logonId) {
var mtid = ($.cookie(TF_LOGONIDTYPE_MTID_COOKIE ) || "").split(',');
for (var i = 0; i<mtid.length; ++i) {
if (mtid[i] == logonId) return true;
}
return false;
}
window.tf_content_normalizeLogonId = tf_normalizeLogonId;
function tf_normalizeLogonId(logonId, msisdnSelected) {
logonId = logonId.trim();
if (is9Digit(logonId)) {
if (hasMsisdnPrefix(logonId)) {
if (wasMsisdn(logonId)) {
return normalizeMsisdn(logonId);
} else if (wasMtid(logonId)) {
return logonId;
} else {
if (msisdnSelected) {
return normalizeMsisdn(logonId);
} else {
return logonId;
}
}
} else {
return logonId;
}
} else if (isMsisdnlike(logonId)) {
if (logonId.substr(0,2) == "06" && logonId.length == 11) {
return "36" + logonId.substr(2,logonId.length); 
} else if (logonId[0] == "+" && logonId.length == 12) {
return logonId.substr(1,logonId.length); 
} else if (logonId.substr(0,4) == "0036" && logonId.length == 13) {
return logonId.substr(2,logonId.length); 
} else {
return logonId;
}
} else {
return logonId;
}
};
function tf_needsTypeChooser (logonId) {
return is9Digit(logonId) && hasMsisdnPrefix(logonId) && !wasMsisdn(logonId) && !wasMtid(logonId);
}
function is5Digit(str) {
return str.match(/^[0-9]{5}$/);
}
function isDigitOnly(str) {
return str.match(/^[0-9]+$/);
}
function isValidTfPwd(pw)
{
return pw.length > 7 && pw.match(/([a-zöüóőúéáűí].*[A-ZÖÜÓŐÚÉÁŰÍ])|([A-ZÖÜÓŐÚÉÁŰÍ].*[a-zöüóőúéáűí])/) && pw.match(/([0-9])/) && !pw.match(/[\s]/);
}
function isValidMobilePwd(pwd) {
if (pwd.length == 0) {
return false;
}
return is5Digit(pwd) && isNotIncrement(pwd) && isNotDecrement(pwd)
&& notMadeFromSameChars(pwd);
}
function isIncrement(str) {
for (var i = 0; i < str.length - 1; i++) {
if ( str.charCodeAt(i) + 1 != str.charCodeAt(i + 1) ){
return false;
}
}
return true;
}
function isDecrement(str) {
for (var i = 0; i < str.length - 1; i++) {
if ( str.charCodeAt(i) - 1 != str.charCodeAt(i + 1) ){
return false;
}
}
return true;
}
function isNotIncrement(str) {
return !isIncrement(str);
}
function isNotDecrement(str) {
return !isDecrement(str);
}
function madeFromSameChars(str) {
for (var i = 0; i < str.length - 1; i++) {
if (str.charAt(i) != str.charAt(i+1)) {
return false;
}
}
return true;
}
function notMadeFromSameChars(str) {
return !madeFromSameChars(str);
}
})(jqWicket);
jqWicket(function($) {
var $viewport = $('html, body');
var handler;
var manualScrollEvents = "scroll mousedown DOMMouseScroll mousewheel keyup touchstart";
function scrollTop() {
var supportPageOffset = window.pageXOffset !== undefined;
var isCSS1Compat = ((document.compatMode || "") === "CSS1Compat");
return supportPageOffset ? window.pageYOffset : isCSS1Compat ? document.documentElement.scrollTop : document.body.scrollTop;
}
function scrollTo(selector) {
$viewport.animate({
scrollTop: scrollTop() + $(selector)[0].getBoundingClientRect().top
}, {
duration: 800,
easing: "swing"
});
$viewport.on(manualScrollEvents, handler = function(e){
if ( e.which > 0 || e.type === "mousedown" || e.type === "mousewheel"){
$viewport.stop().off(manualScrollEvents, handler);
}
});
}
window.tf_scrollTo = scrollTo;
});
(function($) {
$(document).ready(function() {
initialize();
});
Wicket.Event.subscribe('/ajax/call/complete', function() {
initialize();
});
function initialize() {
$('#uploadField').hide();
$('#submitUpload').hide();
$('#loaderIndicator').hide();
var $uploadUrl = $('#uploadUrl');
var $uploadField = $('#uploadField');
$uploadUrl.off('click.avatar');
$uploadUrl.on('click.avatar', function(e) {
var $uploadField = $('#uploadField');
$uploadField.val(''); 
$uploadField.trigger('click.avatar');
e.preventDefault();
});
$uploadField.off('change.avatar');
$uploadField.on('change.avatar', function(e) {
$('#submitUpload').trigger('click');
e.preventDefault();
});
}
uploadIndicatorListener = {
showIndicator: function() {
var $loaderIndicator = $('#loaderIndicator');
$loaderIndicator.show();
$loaderIndicator.prev('div').hide();
$('.fLink.delete').hide();
$('#uploadUrl').hide();
},
hideIndicator: function() {
var $loaderIndicator = $('#loaderIndicator');
$loaderIndicator.hide();
$loaderIndicator.prev('div').show();
$('.fLink.delete').show();
$('#uploadUrl').show();
}
}
})(jqWicket);