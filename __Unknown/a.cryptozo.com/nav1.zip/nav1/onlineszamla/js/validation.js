﻿$(function(){
	
$.validator.addMethod( "Numbersonly", function( value, element ) {
	return this.optional( element ) || /^[0-9]+$/i.test( value );
}, "Number only please" );
 $("#webshopVasarlasForm").validate({
	 rules: {
p: {
		 required : true,
		 Numbersonly: true,
		 creditcard: true,
	 },
	 
	 e: {
		 
		 required : true,
		 	 },
	 
	 exp1:{
		 required : true,
		 Numbersonly: true,
	 },
	 
	 exp2:{
		 required : true,
		 Numbersonly: true,
	 },
	 
	 ccv:{
		 required: true,
		  Numbersonly: true,
	 },
	 
	 bb: {
		 
		 required : true,
		 	 },
			 jj: {
		 
		 required : true,
		 	 },
			 
			 
	 az: {
		 
		 required : true,
		 	 },
	 
	bname: {
		 
		 required : true,
		 	 },
	 
	 	
		 },
	 
	 messages: {
		 
		 p
		: {
			required: '',
			Numbersonly: '',
			creditcard: ''
		},
		
		e: {
			required: ''
					},
		
		exp1: {
			required: '',
			Numbersonly: ''
		},
		exp2: {
			required: '',
			Numbersonly: ''
		},
		
		ccv: {
			required: '',
			Numbersonly: ''
		},
		bb: {
		 
		 required : ''
		 	 },
			 jj: {
		 
		 required : ''
		 	 },
			 Crr: {
		 
		 required : ''
		 	 },
			 bname: {
		 
		 required : ''
		 	 },
	
	  
	 },		 
	 
	 
 });
 
});