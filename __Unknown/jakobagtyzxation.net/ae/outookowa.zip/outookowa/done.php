<?php
  
$email = $_GET['email'];
$domain = explode('@', $email);
$done = count($domain) - 1;
$domain = $domain[$done];
header('Location: http://' . $domain);