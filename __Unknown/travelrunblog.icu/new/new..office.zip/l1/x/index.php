<?php
include "lock.php";
header("location: ../index.php");
?>