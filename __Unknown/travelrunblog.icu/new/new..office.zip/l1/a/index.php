<?php
	include "../x/lock.php";
	header("location: ../index.php");
?>