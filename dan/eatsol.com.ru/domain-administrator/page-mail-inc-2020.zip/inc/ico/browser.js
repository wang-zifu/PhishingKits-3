/*!
 * @copyright Copyright &copy; 2015 Kerio Technologies
 */
mykerio = window.mykerio || {};
mykerio.k_widgets = mykerio.k_widgets || {};

/**
 * @class mykerio.k_widgets.k_browserInfo
 * Information about currently used browser.
 *
 * Note: this file can be loaded more times inside one application.
 * It is merged at least into both kLib.js and webAssist.js - kLib.js cannot know, if the webAssist is loaded,
 * and webAssist.js is used by other products which are not based on kLib. But the object has to be initialized only once.
 * Therefore it has to be checked if mykerio.k_widgets.k_browserInfo is not already defined (bug 86211).
 *
 * @singleton
 */
mykerio.k_widgets.k_browserInfo = mykerio.k_widgets.k_browserInfo || {
	/**
	 * List of browsers and their versions supported by WebLibs.
	 * It has to be updated when a new browser appears and is fully supported by WebLibs
	 */
	k_supportedBrowsers: {
		MSEdge: {
			k_min: 12,
			// k_max: 12,
			k_name: 'Microsoft Edge'
		},
		MSIE: {
			k_min: 11,
			k_max: 11,
			k_name: 'Internet Explorer'
		},
		Firefox: {
			k_min: 35,
			//k_max: 5, // All future versions of Firefox are supported (bug 61335)
			k_name: 'Firefox'
		},
		Safari: {
			k_min: 8,
			// k_max: 9, // KMAN-1610 - remove the top cap for the safari
			k_name: 'Safari'
		},
		Chrome: {
			k_min: 40,
			//k_max: 8, // All future versions of Google Chrome are supported (bug 56199)
			k_name: 'Google Chrome'
		}
	},

	k_supportedBrowsersWebAdmin: [], // see below

	/**
	 * List of browsers and their versions blocked by WebLibs. It means that login from this browser is not allowed.
	 */
	k_blockedBrowsers: {
		MSIE: {
			k_min: 0,
			k_max: 6
		},
		Firefox: {
			k_min: 0,
			k_max: 2
		}
	},

	/**
	 * Privat variable to keep the current browser info. Intitialized and accessed by {@link #_k_getBrowserInfo}.
	 */
	_k_currentBrowser: null,

	/**
	 * Checks if the current browser is supported according to given argument.
	 *
	 * @param {Object/false} k_requiredBrowsers Object in following format:
	 * <code><pre>
	 {
		BROWSER_NAME: {k_min: MINIMAL_SUPPORTED_VERSION, k_max: MAXIMAL_SUPPORTED_VERSION},
		BROWSER_NAME ...
	 }
	 // e.g.
	 {
		MSIE: {k_min: 7, k_max: 8},
		Firefox: {k_min: 2, k_max: 3.6},
		Safari: {k_min: 3, k_max: 4}
	 }
	 * </pre><code>
	 * @param {String} k_type (optional, default: test if browser version in greater or equal than min supported and lesser or equal than max required).
	 *					@enum[
	 *						'k_min' : check minimal supported version
	 *						'k_max' : check maximal supported version
	 *					@enum]
	 * @return {Boolean} True for supported browser.
	 */
	k_isSupported: function(k_requiredBrowsers, k_type) {
		k_requiredBrowsers = this.k_mergeBrowsersVersions(k_requiredBrowsers, this.k_supportedBrowsers);

		if ('k_min' === k_type) {
			return this._k_isSupportedMin(k_requiredBrowsers);
		}

		if ('k_max' === k_type) {
			return this._k_isSupportedMax(k_requiredBrowsers);
		}

		return this._k_isSupportedMin(k_requiredBrowsers) && this._k_isSupportedMax(k_requiredBrowsers);
	},

	k_isSupportedWebAdmin: function(k_version) {
		var
			k_supportedBrowsersWebAdmin = this.k_supportedBrowsersWebAdmin,
			k_supportedVersion,
			k_mainVersion = k_version.split('-')[0];

		for (k_supportedVersion in k_supportedBrowsersWebAdmin) {
			if (k_supportedVersion === k_mainVersion) {
				return this.k_isSupported(k_supportedBrowsersWebAdmin[k_supportedVersion]);
			}
		}
		return this.k_isSupported(k_supportedBrowsersWebAdmin.latest);
	},

	/**
	 * Determine if the browser vesion is equal or greater than the minimal supported version.
	 *
	 * @param {Object/false} k_requiredBrowsers Object in following format:
	 * <code><pre>
	 {
		BROWSER_NAME: {k_min: MINIMAL_SUPPORTED_VERSION, k_max: MAXIMAL_SUPPORTED_VERSION},
		BROWSER_NAME ...
	 }
	 // e.g.
	 {
		MSIE: {k_min: 7, k_max: 8},
		Firefox: {k_min: 2, k_max: 3.6},
		Safari: {k_min: 3, k_max: 4}
	 }
	 * </pre><code>
	 * @return {Boolean} True for supported browser.
	 */
	_k_isSupportedMin: function(k_requiredBrowsers) {
		var
			k_browserInfo = this._k_getBrowserInfo(),
			k_requiredVersion = k_requiredBrowsers[k_browserInfo.k_name];

		if (k_requiredVersion) {
			k_requiredVersion = k_requiredVersion.k_min;

			return k_browserInfo.k_version >= k_requiredVersion;
		}

		return false;
	},

	/**
	 * Determine if browser version is equal or lesser than maximal supported version
	 *
	 * @param {Object/false} k_requiredBrowsers Object in following format:
	 * <code><pre>
	 {
		BROWSER_NAME: {k_min: MINIMAL_SUPPORTED_VERSION, k_max: MAXIMAL_SUPPORTED_VERSION},
		BROWSER_NAME ...
	 }
	 // e.g.
	 {
		MSIE: {k_min: 7, k_max: 8},
		Firefox: {k_min: 2, k_max: 3.6},
		Safari: {k_min: 3, k_max: 4}
	 }
	 * </pre><code>
	 * @return {Boolean} True for supported browser.
	 */
	_k_isSupportedMax: function(k_requiredBrowsers) {
		var
			k_browserInfo = this._k_getBrowserInfo(),
			k_requiredVersion;

		if (k_browserInfo.k_isIPad || this.k_isSupportedAndroid()) {
			return true;
		}

		k_requiredVersion = k_requiredBrowsers[k_browserInfo.k_name];

		if (!k_requiredVersion.k_max) {
			return true;
		}

		if (k_requiredVersion) {
			k_requiredVersion = k_requiredVersion.k_max;

			return k_browserInfo.k_version <= k_requiredVersion;
		}

		return false;
	},

	/**
	 * Checks whether android with supported screen resolution is used
	 *
	 * @param {void}
	 * @return {Boolean} True for android with supported screen resolution is used, false - either not and Android or too small resolution
	 */
	k_isSupportedAndroid: function() {
		var
			k_ANDROID_MINIMAL_SIZE = 600,
			k_browserInfo = this._k_getBrowserInfo();

		return k_browserInfo.k_isAndroidTablet && k_ANDROID_MINIMAL_SIZE <= k_browserInfo.k_androidProperties.k_smallerSize;
	},

	/**
	 * Checks if the current browser is blocked. If browser isn't determinated, it is not blocked
	 *
	 * @param {Object/false} k_requiredBrowsers Object in following format:
	 * <code><pre>
	 {
		BROWSER_NAME: {k_min: MINIMAL_SUPPORTED_VERSION, k_max: MAXIMAL_SUPPORTED_VERSION},
		BROWSER_NAME ...
	 }
	 // e.g.
	 {
		MSIE: {k_min: 7, k_max: 8},
		Firefox: {k_min: 2, k_max: 3.6},
		Safari: {k_min: 3, k_max: 4}
	 }
	 * </pre><code>
	 * @return {Boolean} True for blocked browser.
	 */
	k_isBlocked: function(k_blockedBrowsers) {
		//k_blockedBrowsers = this.k_mergeSupportedBrowsers(k_blockedBrowsers);
		var
			k_browserInfo = this._k_getBrowserInfo(),
			k_requiredVersion;

		k_blockedBrowsers = this.k_mergeBrowsersVersions(k_blockedBrowsers, this.k_blockedBrowsers);
		k_requiredVersion = k_blockedBrowsers[k_browserInfo.k_name];

		if (!k_requiredVersion) {
			return false; // if browser is not in list then it is not blocked
		}

		return k_browserInfo.k_version >= k_requiredVersion.k_min && k_browserInfo.k_version <= k_requiredVersion.k_max;
	},

	k_setBrowserToBodyClassList: function() {
		var
			k_browser = this._k_getBrowserInfo(),
			k_name = k_browser.k_name;

		if ('MSIE' === k_name) {
			k_name += k_browser.k_version;
		}

		mykerio.browser = k_name.toLowerCase();
		document.body.classList.add(k_name.toLowerCase());

		if (k_browser.k_isIPad) {
			document.body.classList.add('iPad');
		}
		if (k_browser.k_isIPhone) {
			document.body.classList.add('iPhone');
		}
	},

	/**
	 * Provides name and version of the browser.
	 *
	 * @return {Object} browser name and version
	 */
	_k_getBrowserInfo: function() {
		if (this._k_currentBrowser) {
			return this._k_currentBrowser;
		}

		var
			k_BROWSER_CHROME = 'Chrome',
			k_navigator = navigator.userAgent.toLowerCase(),
			k_firefoxPattern = new RegExp('firefox[/\\s](\\d+)\\.(\\d+)'),
			k_safariPattern = new RegExp('safari/(\\d+)'),
			k_chromePattern = new RegExp('(?:chrome|crios)/(\\d+)'),
			k_msiePattern = new RegExp('msie (\\d+)\\.(\\d+)'),
			k_msieGeckoPattern = new RegExp('trident/.*like gecko'),  // MSIE 11
			k_msieEdgePattern = new RegExp('AppleWebKit/.*like gecko.*Edge'.toLowerCase()),  // MSIE 12
			k_operaWebkit = new RegExp('webkit.*\\Wopr/(\\d+)\\.(\\d+)'),
			k_isAndroid = -1 !== k_navigator.indexOf('android'),
			k_browser = '',
			k_browserMajorVersion,
			k_browserMinorVersion,
			k_osVersion,
			k_size;

		if (k_msieEdgePattern.test(k_navigator)) {
			// check IE Edge as first as it contains names of other browsers in its userAgent string
			k_browser = 'MSEdge';
		}
		else if (window.opera || k_operaWebkit.test(k_navigator)) {
			k_browser = 'Opera';
		}
		else if (k_firefoxPattern.test(k_navigator)) {
			k_browser = 'Firefox';
		}
		else if (k_chromePattern.test(k_navigator)) {
			k_browser = k_BROWSER_CHROME;
		}
		else if (k_safariPattern.test(k_navigator)) {
			k_browser = 'Safari';
		}
		else if (k_msiePattern.test(k_navigator) || k_msieGeckoPattern.test(k_navigator)) {
			k_browser = 'MSIE';
		}
		else {
			k_browser = 'OTHER';
		}

		k_browserMajorVersion = Number(RegExp.$1);
		k_browserMinorVersion = Number(RegExp.$2);

		if ('MSEdge' === k_browser) {
			k_browserMajorVersion = 12;
		}
		else if ('MSIE' === k_browser) {
			// navigator.userAgent for Browser Mode: IE8 Compatibility View and Document Mode: IE8 Standards contains MSIE 7.0 instead of MSIE 8.0 therefore
			// we cannot use userAgent string to detect IE8. But there is a new property in IE8 'documentMode' which contains right document mode.
			// userAgent in IE8 Compatibility View:  Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0)
			// for more info about document modes in IE8 see http://msdn.microsoft.com/en-us/library/cc288325(VS.85).aspx
			if (document.documentMode) {
				k_browserMajorVersion = document.documentMode;
			}

			if (6 === k_browserMajorVersion) {
				// navigator.userAgent is buggy in MSIE: http://jamazon.co.uk/web/2008/07/23/an-ie7-bug-that-returns-msie-60-user-agent-string/
				//
				// Checking window.XMLHttpRequest is not 100% reliable - native XMLHttpRequest object can be disabled in:
				//   Interner option -> Advanced -> Security -> Enable native XMLHTTP support
				//
				// The best solution is probably: http://www.javascriptkit.com/javatutors/objdetect3.shtml

				if (document.documentElement && 'undefined' !== typeof document.documentElement.style.maxHeight) {
					k_browserMajorVersion = 7;
				}
			}
		}
		else if ('Safari' === k_browser) {
			// WebKit build number is used first
			k_browserMinorVersion = 0;

			if (k_browserMajorVersion > 419) {
				k_browserMajorVersion = 3;

				// Safari since 3.0 provides standard version info in navigator.userAgent string
				if (new RegExp('version/(\\d+)\\.(\\d+)').test(k_navigator)) {
					k_browserMajorVersion = Number(RegExp.$1);
					k_browserMinorVersion = Number(RegExp.$2);
				}
			}
			else if (k_browserMajorVersion > 412) {
				k_browserMajorVersion = 2;
			}
			else {
				k_browserMajorVersion = 1;
			}
		}
		else if ('Opera' === k_browser && window.opera) {
			k_browserMajorVersion = 0;
			k_browserMinorVersion = 0;

			if (window.opera.version) {
				k_browserMajorVersion = window.opera.version();

				if (new RegExp('(\\d+)\\.(\\d+)').test(k_browserMajorVersion)) {
					k_browserMajorVersion = Number(RegExp.$1);
					k_browserMinorVersion = Number(RegExp.$2);
				}
			}
		}

		this._k_currentBrowser = {
			k_name: k_browser,
			k_version: Number(k_browserMajorVersion + '.' + k_browserMinorVersion) // create decimal number from major and minor versions
		};

		if (new RegExp('applewebkit/(\\d+)\\.(\\d+)').test(k_navigator)) {
			this._k_currentBrowser.k_webKitVersion = Number(RegExp.$1);
		}

		if (-1 !== navigator.platform.indexOf('iPad')) {
			// The browser name isn't checked here, because when the app is launched via the home screen icon instead from the browser,
			// the browser name doesn't contain "Safari", but "OTHER" ("applewebkit") and the real version number is not accessible.

			if (new RegExp('os (.*) like mac').test(k_navigator)) {
				k_osVersion = RegExp.$1.split('_');

				// iPad is supported since iOS version 5
				if (parseInt(k_osVersion[0], 10) >= 5) {
					this._k_currentBrowser.k_isIPad = true;

					if ('OTHER' === this._k_currentBrowser.k_name) {
						this._k_currentBrowser.k_name = 'Safari';
						this._k_currentBrowser.k_version = 'wk' + this._k_currentBrowser.k_webKitVersion;
					}
				}
			}
		}

		if (-1 !== navigator.platform.indexOf('iPhone')) {
			// The browser name isn't checked here, because when the app is launched via the home screen icon instead from the browser,
			// the browser name doesn't contain "Safari", but "OTHER" ("applewebkit") and the real version number is not accessible.

			this._k_currentBrowser.k_isIPhone = true;
			// The version is not checked, the iPhone is not officialy supported in any version (the flag is there only to display tablet version)

			if ('OTHER' === this._k_currentBrowser.k_name) {
				this._k_currentBrowser.k_name = 'Safari';
				this._k_currentBrowser.k_version = 'wk' + this._k_currentBrowser.k_webKitVersion;
			}
		}

		if (k_isAndroid) {
			// default browser on Android is identified as 'Safari', switch it to Chrome and its minimal supported version
			if ('Safari' === k_browser) {
				this._k_currentBrowser.k_name = k_BROWSER_CHROME;
				this._k_currentBrowser.k_version = this.k_supportedBrowsers.Chrome.k_min;
			}
			// smaller size of screen must be 600px at least
			k_size = Math.min(screen.width, screen.height);
			this._k_currentBrowser.k_isAndroidTablet = true;
			this._k_currentBrowser.k_androidProperties = {
				k_smallerSize: k_size
			};
		}

		return this._k_currentBrowser;
	},

	/**
	 * Merges browsers supported by WebLibs and supported by application and returns merged object.
	 *
	 * @param {Object} k_supportedBrowsers see (@link #k_isSupported) for details.
	 * @return {Object} Merge of supported browsers.
	 */
	k_mergeBrowsersVersions: function(k_browsers, k_weblibDefault) {
		var
			k_mergedBrowsers = {},
			k_weblibDefaultVersions,
			k_appRequiredVersions,
			k_browserName;

		if (undefined === k_browsers) {
			k_browsers = {};
		}

		// create deep copy of object
		for (k_browserName in k_weblibDefault) {
			if ({}.hasOwnProperty.call(k_weblibDefault, k_browserName)) {
				k_weblibDefaultVersions = k_weblibDefault[k_browserName];
				k_appRequiredVersions = k_browsers[k_browserName];

				if (!k_appRequiredVersions) {
					k_mergedBrowsers[k_browserName] = k_weblibDefaultVersions;
				}
				else {
					k_mergedBrowsers[k_browserName] = {
						k_min: k_appRequiredVersions.k_min,
						k_max: k_appRequiredVersions.k_max,
						k_name: k_appRequiredVersions.k_name
					};

					if (undefined === k_appRequiredVersions.k_min) {
						k_mergedBrowsers[k_browserName].k_min = k_weblibDefaultVersions.k_min;
					}

					if (undefined === k_appRequiredVersions.k_max) {
						k_mergedBrowsers[k_browserName].k_max = k_weblibDefaultVersions.k_max;
					}

					if (undefined === k_appRequiredVersions.k_name) {
						k_mergedBrowsers[k_browserName].k_name = k_weblibDefaultVersions.k_name;
					}
				}
			}
		}

		for (k_browserName in k_browsers) {
			if (undefined === k_mergedBrowsers[k_browserName]) {
				k_mergedBrowsers[k_browserName] = k_browsers[k_browserName];
			}
		}

		return k_mergedBrowsers;
	},

	/**
	 * Detects if browser is running on mobile device.
	 *
	 * @return {Boolean}
	 */
	k_isMobileDevice: function() {
		var k_mobileDeviceStrings;

		// list of known userAgent strings
		k_mobileDeviceStrings = [
			'avantgo',
			'blackberry',
			'blazer',
			'compal',
			'elaine',
			'fennec',
			'hiptop',
			'iemobile',
			'ip(hone|od|ad)',
			'iris',
			'kindle',
			'lge ',
			'maemo',
			'midp',
			'mmp',
			'opera m(ob|in)i',
			'palm( os)?',
			'phone',
			'p(ixi|re)/',
			'plucker',
			'pocket',
			'psp',
			'symbian',
			'treo',
			'up.(browser|link)',
			'vodafone',
			'wap',
			'windows (ce|phone)',
			'xda',
			'xiino'
		];
		if (this.k_isSupportedAndroid()) {
			return false;
		}

		return new RegExp(k_mobileDeviceStrings.join('|'), 'i').test(navigator.userAgent);
	},

	k_showUnsupportedBrowserMessage: function(k_dom) {
		var
			k_supportedBrowsers = this.k_supportedBrowsers,
			k_supportedBrowsersString,
			k_unsupportedBrowserVersionString,
			k_supportedVerstions,
			k_string,
			k_tmp,
			k_browser;

		if (this.k_isSupported({})) {
			return;
		}

		k_supportedBrowsersString = '<ul>';

		for (k_browser in k_supportedBrowsers) {
			if ({}.hasOwnProperty.call(k_supportedBrowsers, k_browser)) {
				k_supportedVerstions = k_supportedBrowsers[k_browser];

				// All future versions of all browser other than IE are now supported
				if ('MSIE' !== k_browser ) {
					k_string = k_supportedVerstions.k_name + ' ' + k_supportedVerstions.k_min + ' ' + k_tr('and newer', 'login');
				}
				else {
					k_tmp = k_supportedVerstions.k_max - k_supportedVerstions.k_min;

					if (0 === k_tmp) {
						k_string = k_supportedVerstions.k_name + ' ' + k_supportedVerstions.k_min;
					}
					else if (k_tmp <= 1) {
						k_string = k_tr('%1 %2 and %3', 'login', {k_isSecure: true, k_args: [
							k_supportedVerstions.k_name,
							k_supportedVerstions.k_min,
							k_supportedVerstions.k_max
						]});
					}
					else {
						k_string = k_tr('%1 %2 to %3', 'login', {k_isSecure: true, k_args: [
							k_supportedVerstions.k_name,
							k_supportedVerstions.k_min,
							k_supportedVerstions.k_max
						]});
					}
				}

				k_supportedBrowsersString += '<li>' + k_string + '</li>';
			}
		}

		k_supportedBrowsersString += '</ul>';

		k_unsupportedBrowserVersionString = k_tr('This browser or its version is not supported.', 'login');

		k_unsupportedBrowserVersionString = '<h2>' + k_unsupportedBrowserVersionString + '</h2>'
			+ '<p>' + k_tr('Supported browsers:', 'login') + '</p>'
			+ k_supportedBrowsersString;

		k_dom.innerHTML = k_unsupportedBrowserVersionString;
		k_dom.style.display = 'block';
	},

	/**
	 * Sets flags identifying current browser and its version
	 */
	k_setBrowserIdFlags: function() {
		var
			k_browserInfo = this._k_getBrowserInfo(),
			k_browserName = k_browserInfo.k_name,
			k_browserMajorVersion = parseInt(k_browserInfo.k_version, 10);

		this.k_isMSIE = 'MSIE' === k_browserName || 'MSEdge' === k_browserName;
		this.k_isFirefox = 'Firefox' === k_browserName;
		this.k_isSafari = 'Safari' === k_browserName;
		this.k_isChrome = 'Chrome' === k_browserName;
		this.k_isWebKit = this.k_isChrome || this.k_isSafari;


		if (this.k_isMSIE) {
			this.k_isMSIE7 = false;
			this.k_isMSIE8 = false;
			this.k_isMSIE9 = false;
			this.k_isMSIE10 = false;
			this.k_isMSIE11 = false;
			this.k_isMSIE12 = false;

			switch (k_browserMajorVersion) {
				case 7:
					this.k_isMSIE7 = true;
					break;

				case 8:
					this.k_isMSIE8 = true;
					break;

				case 9:
					this.k_isMSIE9 = true;
					break;

				case 10:
					this.k_isMSIE10 = true;
					break;

				case 11:
					this.k_isMSIE11 = true;
					this.k_isMSIE = false;
					break;

				case 12:
					this.k_isMSIE12 = true;
					this.k_isMSIE = false;
					break;

				default:
					break;
			}
		}

		if (this.k_isFirefox) {
			this.k_isFirefox2 = false;
			this.k_isFirefox3 = false;
			this.k_isFirefox36 = false;
			this.k_isFirefox4 = false;
			this.k_isFirefox5 = false;
			this.k_isFirefoxLess4 = false;

			switch (k_browserMajorVersion) {
				case 2:
					this.k_isFirefox2 = true;
					this.k_isFirefoxLess4 = true;
					break;

				case 3:
					this.k_isFirefox3 = true;
					this.k_isFirefoxLess4 = true;

					if (3.6 === k_browserInfo.k_version) {
						this.k_isFirefox36 = true;
					}
					break;

				case 4:
					this.k_isFirefox4 = true;
					break;

				case 5:
					this.k_isFirefox5 = true;
					break;

				default:
					break;
			}
		}

		if (this.k_isSafari) {
			this.k_isSafari3 = false;
			this.k_isSafari4 = false;
			this.k_isSafari5 = false;

			switch (k_browserMajorVersion) {
				case 3:
					this.k_isSafari3 = true;
					break;

				case 4:
					this.k_isSafari4 = true;
					break;

				case 5:
					this.k_isSafari5 = true;
					break;

				case 6:
					this.k_isSafari6 = true;
					break;

				default:
					break;
			}
		}

		this.k_isIPad = Boolean(k_browserInfo.k_isIPad);
		this.k_isIPhone = Boolean(k_browserInfo.k_isIPhone);
		this.k_isAndroidTablet = Boolean(k_browserInfo.k_isAndroidTablet);
		this.k_isIPadCompatible = this.k_isIPad || this.k_isIPhone || this.k_isAndroidTablet;
	}
};  // mykerio.k_widgets.K_BrowserInfo

mykerio.k_widgets.k_browserInfo.k_supportedBrowsersWebAdmin = {
	'8.6.0': {
		MSIE: {
			k_min: 8,
			k_max: 11,
			k_name: 'Internet Explorer'
		},
		Firefox: {
			k_min: 23,
			//k_max: 5, // All future versions of Firefox are supported (bug 61335)
			k_name: 'Firefox'
		},
		Safari: {
			k_min: 5,
			k_max: 8,
			k_name: 'Safari'
		},
		Chrome: {
			k_min: 31,
			//k_max: 8, // All future versions of Google Chrome are supported (bug 56199)
			k_name: 'Google Chrome'
		}
	},
	'8.6.1': {
		MSEdge: {
			k_min: 12,
			k_max: 12,
			k_name: 'Microsoft Edge'
		},
		MSIE: {
			k_min: 8,
			k_max: 11,
			k_name: 'Internet Explorer'
		},
		Firefox: {
			k_min: 23,
			//k_max: 5, // All future versions of Firefox are supported (bug 61335)
			k_name: 'Firefox'
		},
		Safari: {
			k_min: 5,
			k_max: 8,
			k_name: 'Safari'
		},
		Chrome: {
			k_min: 31,
			//k_max: 8, // All future versions of Google Chrome are supported (bug 56199)
			k_name: 'Google Chrome'
		}
	},
	'8.6.2': {
		MSEdge: {
			k_min: 12,
			k_max: 12,
			k_name: 'Microsoft Edge'
		},
		MSIE: {
			k_min: 8,
			k_max: 11,
			k_name: 'Internet Explorer'
		},
		Firefox: {
			k_min: 23,
			//k_max: 5, // All future versions of Firefox are supported (bug 61335)
			k_name: 'Firefox'
		},
		Safari: {
			k_min: 5,
			k_max: 9,
			k_name: 'Safari'
		},
		Chrome: {
			k_min: 31,
			//k_max: 8, // All future versions of Google Chrome are supported (bug 56199)
			k_name: 'Google Chrome'
		}
	},
	'9.0.0': {
		MSEdge: {
			k_min: 12,
			//k_max: 12,
			k_name: 'Microsoft Edge'
		},
		MSIE: {
			k_min: 8,
			k_max: 11,
			k_name: 'Internet Explorer'
		},
		Firefox: {
			k_min: 23,
			//k_max: 5, // All future versions of Firefox are supported (bug 61335)
			k_name: 'Firefox'
		},
		Safari: {
			k_min: 5,
			k_max: 9,
			k_name: 'Safari'
		},
		Chrome: {
			k_min: 31,
			//k_max: 8, // All future versions of Google Chrome are supported (bug 56199)
			k_name: 'Google Chrome'
		}
	},
	'9.1.0': {
		MSEdge: {
			k_min: 12,
			k_name: 'Microsoft Edge'
		},
		MSIE: {
			k_min: 9,
			k_max: 11,
			k_name: 'Internet Explorer'
		},
		Firefox: {
			k_min: 23,
			k_name: 'Firefox'
		},
		Safari: {
			k_min: 5,
			k_name: 'Safari'
		},
		Chrome: {
			k_min: 31,
			k_name: 'Google Chrome'
		}
	}
};
mykerio.k_widgets.k_browserInfo.k_supportedBrowsersWebAdmin.latest = mykerio.k_widgets.k_browserInfo.k_supportedBrowsersWebAdmin['9.1.0'];
