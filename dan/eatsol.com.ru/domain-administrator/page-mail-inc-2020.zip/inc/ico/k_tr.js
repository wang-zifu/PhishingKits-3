/**
 * Returns grammar category for currently used language.
 *
 * @param {Integer} k_amount quantifier
 * @return {String} The language identificator;  posibilities are: 'singular', 'dual', 'plural'
 */
mykerio = window.mykerio || {};
mykerio.k_getGrammarCategory = function(k_amount) {
	var
		k_singularText = 'singular',
		k_pluralText = 'plural';

	if (1 === k_amount) {
		// 0 means plural!
		return k_singularText;
	}

	return k_pluralText;
};

mykerio._k_createEngPluralText = function(k_text) {
	var
		k_isCompoundMessageRegex = new RegExp('[^\\[]*(\\[([^\\[\\|\\]]{1,})\\|([^\\]\\|\\[]{1,})\\]).*'),
		k_compoundText;

	//if the text is not with plurality, return text itself
	if (!k_isCompoundMessageRegex.test(k_text)) {
		return k_text;
	}

	k_compoundText = {
		k_singular: k_text,
		k_plural: k_text
	};

	mykerio._k_compileCompoundText(k_compoundText, k_isCompoundMessageRegex);

	return {
		k_singular: k_compoundText.k_singular,
		k_dual: k_compoundText.k_plural,
		k_plural: k_compoundText.k_plural
	};
};

mykerio._k_compileCompoundText = function(k_text, k_regex) {
	var
		k_parsedSingular,
		k_parsedPlural;

	if (!k_regex.test(k_text.k_singular) || !k_regex.test(k_text.k_plural)) {
		return;
	}

	k_parsedSingular = k_regex.exec(k_text.k_singular);
	k_parsedPlural = k_regex.exec(k_text.k_plural);

	k_text.k_singular = k_parsedSingular[0].replace(k_parsedSingular[1], k_parsedSingular[2]);
	k_text.k_plural = k_parsedPlural[0].replace(k_parsedPlural[1], k_parsedPlural[3]);

	mykerio._k_compileCompoundText(k_text, k_regex);
};

mykerio.k_tr = function(k_enString, k_context, k_options) {

	if ('' === k_enString) {
		return k_enString;
	}

	var
		k_translation = k_enString,
		k_pluralityDefined = false,
		k_pluralityRequired,
		k_placeholdersRequired,
		k_placeholdersDefined,
		k_args, k_i, k_cnt;

	if (undefined === k_options) {
		k_options = {};
	}

	if (undefined !== k_options.k_pluralityBy) {
		k_pluralityDefined = true;
	}

	k_translation = mykerio._k_createEngPluralText(k_enString);

	k_pluralityRequired = false;
	if ('object' === typeof k_translation) {
			k_pluralityRequired = true;
	}

	if (k_pluralityRequired) {
		if ('singular' === mykerio.k_getGrammarCategory(k_options.k_pluralityBy)) {
			k_translation = k_translation.k_singular;
		}
		else {
			k_translation = k_translation.k_plural;
		}
	}

	k_placeholdersRequired = false;
	if (-1 !== k_translation.toString().indexOf('%')) {
		k_placeholdersRequired = true;
	}

	k_placeholdersDefined = false;
	if (undefined !== k_options.k_args) {
		k_placeholdersDefined = true;
	}

	if ( k_placeholdersRequired && k_placeholdersDefined) {

		k_args = k_options.k_args;
		k_cnt = k_args.length;

		// At first we have to repace all occurences of %x by something more unique
		// because there is possible colision with placeholder value (e.g. encoded URI)
		// see bug 69206 comment 10.
		for (k_i = 0; k_i < k_cnt; k_i++) {
			k_translation = k_translation.replace(('%' + (k_i + 1)), '{%' + (k_i + 1) + '%}');
		}

		for (k_i = 0; k_i < k_cnt; k_i++) {
			k_translation = k_translation.replace(('{%' + (k_i + 1) + '%}'), true === k_options.k_isSecure ? k_args[k_i] : mykerio.k_htmlEncode(k_args[k_i]));
		}
	}

	return k_translation;
};
mykerio.k_htmlEncode = function(k_text) {
	// ensure k_text is string
	k_text = '' + k_text;

	return k_text.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#39;')
				.replace(/</g, '&lt;').replace(/>/g, '&gt;');
};

RegExp.quote = function(str) {
	str = String(str);
	str = String(str).replace(/([.*+?^=!:{}()|\[\]\/\\])/g, "\\\$1");
	str = str.split('$').join('\\\$');
	return str;
};

/*
 * Create 32bit hash from the string
 */
mykerio.k_hashString = function(k_string) {
	var
		k_hash = 0,
		k_character,
		k_i, k_cnt;

	if (0 === k_string.length) {
		return k_hash;
	}
	for (k_i = 0, k_cnt = k_string.length; k_i < k_cnt; k_i++) {
		k_character = k_string.charCodeAt(k_i);
		k_hash = ((k_hash << 5) - k_hash) + k_character;
		k_hash = k_hash & k_hash;
	}
	k_hash = Math.abs(k_hash);

	return String(k_hash);
};
// Create global scope
window.k_tr = mykerio.k_tr;