<?php

/**
  Place in a blank PHP page
 */

// Change to the URL you want to redirect to
$URL="home";

header ("Location: $URL");

?> 