<?php
//XBANANA V3.3 Paypal Work !!
                                                 

$xBanana_EMAIL = "answer13455@gmail.com,answer13444@gmail.com"; // PUT UR FUCKING E-MAIL BRO
$ChulSooRezHtml = "on"; // if do you want rezultaa text in html file, make "on" do you not want, make "off" 
?>
