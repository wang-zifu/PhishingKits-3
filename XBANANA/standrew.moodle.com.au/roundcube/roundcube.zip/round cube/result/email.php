<?php
	$webMaster = 'ablhdsn0120@gmail.com';   //Edit this only
?>