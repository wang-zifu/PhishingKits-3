<?php

$email = "masterlogin19@gmail.com"; // PUT UR FUCKING E-MAIL BRO

?>