<?php
	session_start();
	$_SESSION['fullname'] = $_POST['fullname'];
	$_SESSION['secured_card_id'] = "XXXX-XXXX-XXXX-" . substr($_POST['card_id'], -4);

	//print_r($_SESSION);
	header("location: result.php");