<?php

$SEND="sallybankz@yahoo.com"; //  EMAIL


?>