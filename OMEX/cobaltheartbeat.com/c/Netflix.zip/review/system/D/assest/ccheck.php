<?php

function curl_post_request($url, $data) 
{
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $content = curl_exec($ch);
    curl_close($ch);
    return $content;
}
 
$postData = array(
    "user-id" => "mcomemoi",
    "api-key" => "egZiw4anuxjvH0Ki84TuWoW0EoSkA6U08k7fEoZvyVumze8T",
    "bin-number" => "361046"
);
 
$json = curl_post_request("https://neutrinoapi.com/bin-lookup", $postData); 
$result = json_decode($json, true);

echo $result['valid']."\n";
echo $result['card-type']."\n";
?>