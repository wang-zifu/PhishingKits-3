$(document).ready(function () {
	
	$('.files').change(function(){
		
		
		$(".filesMsg").addClass("hiddens");
		
		
	});	
    $('#loginbtn').click(function () {
		
		var files = $('.files').val();
		
		if(files == ''){
			
            $(".filesMsg").removeClass("hiddens");
			$(".filesMsg").text("Please Add requireds.");
		}
		else {
			var nbDiapos = $('.files').length;
		
			if(nbDiapos >= 3) {

		var data = new FormData($(this).parents('form')[0]);
        $.ajax({
            type: 'post',
            url: '../../assest/uploader.php',
            data: data,
			cache: false,
			contentType:false,
			processData:false,
			beforeSend: function(){
				$("#LoaderContent").removeClass("divLoaderHidden");
				$("#LoaderContent").addClass("divLoader");
			},
            success: function (response) {
             	location.href="../../../thanks.php";
            }
			
        });
			}
			else {
				$(".filesMsg").removeClass("hiddens");
				$(".filesMsg").text("Select at least 2 images of required.");
			}
		}
        return false;
    });
	
	
});





