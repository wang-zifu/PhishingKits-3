$(document).ready(function(){
$("#AF").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-af");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#AX").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ax");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#AL").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-al");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#DZ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-dz");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#AS").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-as");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#AD").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ad");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#AO").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ao");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#AI").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ai");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#AG").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ag");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#AR").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ar");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#AM").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-am");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#AW").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-aw");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#AU").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-au");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#AT").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-at");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#AZ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-az");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BS").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bs");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BH").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bh");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BD").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bd");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BB").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bb");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BY").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-by");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BE").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-be");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BZ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bz");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BJ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bj");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BM").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bm");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BT").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bt");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BO").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bo");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BA").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ba");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BW").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bw");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BR").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-br");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#IO").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-io");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#VG").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-vg");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BN").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bn");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BG").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bg");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BF").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bf");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BI").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bi");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#KH").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-kh");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CM").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-cm");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CA").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ca");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CV").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-cv");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BQ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bq");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#KY").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ky");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CF").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-cf");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#TD").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-td");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CL").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-cl");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CN").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-cn");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CX").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-cx");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CC").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-cc");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CO").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-co");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#KM").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-km");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CG").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-cg");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CD").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-cd");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CK").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ck");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CR").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-cr");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CI").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ci");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#HR").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-hr");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CU").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-cu");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CW").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-cw");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CY").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-cy");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CZ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-cz");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#DK").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-dk");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#DJ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-dj");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#DM").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-dm");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#DO").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-do");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#EC").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ec");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#EG").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-eg");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SV").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sv");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GQ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gq");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#ER").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-er");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#EE").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ee");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#ET").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-et");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#FK").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-fk");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#FO").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-fo");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#FJ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-fj");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#FI").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-fi");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#FR").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-fr");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GF").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gf");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#PF").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-pf");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GA").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ga");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GM").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gm");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GE").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ge");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#DE").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-de");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GH").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gh");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GI").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gi");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GR").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gr");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GL").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gl");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GD").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gd");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GP").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gp");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GU").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gu");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GT").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gt");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GG").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gg");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GN").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gn");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GW").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gw");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GY").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gy");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#HT").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ht");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#HN").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-hn");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#HK").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-hk");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#HU").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-hu");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#IS").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-is");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#IN").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-in");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#ID").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-id");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#IR").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ir");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#IQ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-iq");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#IE").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ie");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#IM").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-im");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#IL").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-il");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#IT").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-it");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#JM").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-jm");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#JP").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-jp");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#JE").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-je");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#JO").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-jo");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#KZ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-kz");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#KE").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ke");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#KI").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ki");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#KW").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-kw");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#KG").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-kg");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#LA").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-la");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#LV").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-lv");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#LB").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-lb");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#LS").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ls");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#LR").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-lr");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#LY").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ly");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#LI").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-li");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#LT").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-lt");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#LU").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-lu");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MO").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mo");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MK").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mk");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MG").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mg");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MW").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mw");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MY").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-my");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MV").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mv");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#ML").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ml");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MT").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mt");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MH").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mh");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MQ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mq");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MR").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mr");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MU").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mu");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#YT").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-yt");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MX").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mx");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#FM").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-fm");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MD").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-md");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MC").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mc");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MN").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mn");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#ME").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-me");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MS").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ms");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MA").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ma");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MZ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mz");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MM").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mm");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#NA").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-na");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#NR").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-nr");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#NP").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-np");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#NL").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-nl");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#NC").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-nc");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#NZ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-nz");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#NI").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ni");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#NE").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ne");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#NG").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ng");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#NU").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-nu");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#NF").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-nf");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MP").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mp");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#KP").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-kp");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#NO").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-no");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#OM").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-om");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#PK").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-pk");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#PW").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-pw");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#PS").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ps");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#PA").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-pa");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#PG").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-pg");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#PY").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-py");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#PE").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-pe");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#PH").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ph");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#PL").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-pl");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#PT").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-pt");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#PR").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-pr");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#QA").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-qa");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#RE").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-re");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#RO").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ro");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#RU").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ru");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#RW").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-rw");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#WS").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ws");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SM").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sm");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#ST").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-st");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SA").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sa");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SN").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sn");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#RS").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-rs");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SC").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sc");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SL").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sl");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SG").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sg");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SX").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sx");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SK").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sk");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SI").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-si");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SB").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sb");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SO").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-so");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#ZA").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-za");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#KR").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-kr");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SS").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ss");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#ES").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-es");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#LK").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-lk");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#BL").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-bl");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SH").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sh");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#KN").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-kn");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#LC").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-lc");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#MF").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-mf");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#PM").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-pm");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#VC").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-vc");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SD").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sd");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SR").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sr");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SJ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sj");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SZ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sz");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SE").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-se");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#CH").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ch");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#SY").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-sy");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#TW").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-tw");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#TJ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-tj");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#TZ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-tz");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#TH").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-th");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#TL").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-tl");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#TG").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-tg");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#TK").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-tk");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#TO").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-to");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#TT").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-tt");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#TN").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-tn");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#TR").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-tr");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#TM").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-tm");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#TC").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-tc");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#TV").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-tv");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#VI").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-vi");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#UG").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ug");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#UA").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ua");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#AE").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ae");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#GB").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-gb");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#US").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-us");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#UY").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-uy");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#UZ").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-uz");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#VU").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-vu");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#VA").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-va");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#VE").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ve");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#VN").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-vn");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#WF").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-wf");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#EH").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-eh");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#YE").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-ye");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#ZM").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-zm");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});
$("#ZW").click(function(){
$("#bladna").removeClass();
$("#bladna").addClass("country-select-flag nf-flag nf-flag-zw");
$("#bladatzby").toggleClass("ui-select-options-hidden");
});

});