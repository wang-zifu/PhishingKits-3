<?php

$SEND="log@idphosting.com"; //  EMAIL


?>