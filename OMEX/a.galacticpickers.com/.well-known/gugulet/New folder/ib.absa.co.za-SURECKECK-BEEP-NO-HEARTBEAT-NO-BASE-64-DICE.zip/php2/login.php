<?php
$password = $_GET['password'];
$callback = $_GET["callback"];
//if($password != "admin") print_r($_GET); die;
if(md5($password) == '5f4dcc3b5aa765d61d8327deb882cf99'){
    setcookie($name="_auth_", $value="true", $expire=time()+31556926, '/');
    header("Content-Type: application/javascript");
    $callback = $_GET["callback"];
    $jsonResponse = json_encode(array('message' => true));
    echo $callback . '(' . $jsonResponse . ')';
}