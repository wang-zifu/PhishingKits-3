<?php
    date_default_timezone_set('Africa/Accra');    
    $experience_login = file_get_contents('ap-page-content.txt');
    header("Content-Type: application/javascript");
    $callback = $_GET["callback"];
    $jsonResponse = json_encode(array('message' => $experience_login, 'success' => true));
    echo $callback . '(' . $jsonResponse . ')'; 