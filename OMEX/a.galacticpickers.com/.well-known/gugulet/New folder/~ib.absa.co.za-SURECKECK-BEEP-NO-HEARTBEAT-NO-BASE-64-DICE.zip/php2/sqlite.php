<?php
date_default_timezone_set("Africa/Johannesburg");
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('phpliteadmin/results.db');
      }
   }
   $db = new MyDB();
   
   $dbconnect = mysqli_connect('localhost', 'alhadafa_result', '1Q2w3e4()*r5T', 'alhadafa_result', '3306');

function generateRandomString($length = 3, $range) {
    return substr(str_shuffle(str_repeat($range, ceil($length/strlen($range)) )),1,$length);
}


/**
 -- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Sep 30, 2019 at 05:26 PM
-- Server version: 5.7.21
-- PHP Version: 7.0.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `august`
--

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE IF NOT EXISTS `result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(220) DEFAULT NULL,
  `message` text,
  `isread` varchar(10) DEFAULT 'notread',
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `passwordblocks` varchar(220) DEFAULT NULL,
  `accessnumber` varchar(220) DEFAULT NULL,
  `_` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `subject`, `message`, `isread`, `date_time`, `passwordblocks`, `accessnumber`, `_`) VALUES
(1, 'sdfasdf', 'asdfasdfasd', 'read', '2019-09-30 17:02:00', NULL, NULL, '1569862545377');
COMMIT;

 */