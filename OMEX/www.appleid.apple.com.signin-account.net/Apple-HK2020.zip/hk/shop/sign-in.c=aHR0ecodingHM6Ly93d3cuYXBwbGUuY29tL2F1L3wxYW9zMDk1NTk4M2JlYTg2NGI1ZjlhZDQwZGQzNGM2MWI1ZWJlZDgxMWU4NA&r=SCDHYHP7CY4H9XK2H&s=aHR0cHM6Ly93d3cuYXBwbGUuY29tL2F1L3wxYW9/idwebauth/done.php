
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">



<html class="ltr " lang="en" >
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <meta name="robots" content="noindex, nofollow">
    <meta name="googlebot" content="noindex, nofollow">
    
    
    
    <title>
    
        
        
        
            
            Apple Official Support 
        
    
</title>
    
    <link rel="icon" href="./img/favicon.ico" />
    
    <link rel="SHORTCUT ICON" href="/images/global/favicon.ico"/>
    



<meta name="viewport" content="width=1024">
    
	


<meta name="applicable-device" content="pc,mobile">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="format-detection" content="telephone=no">
<script></script>



	
	    
	    <meta property="og:title" content="Edit Your Account">
	    <meta property="og:type" content="website">
		
		
	    <meta property="og:description" content="Edit Your Account">
		<meta property="og:site_name" content="Apple (AU)">
		<meta property="og:locale" content="en_AU">
	
	
	    <meta name="twitter:site" content="@apple">
	    <meta name="twitter:card" content="summary">
		
		<meta name="twitter:title" content="Edit Your Account from Apple">
		<meta name="twitter:description" content="Edit Your Account">
		
<META HTTP-EQUIV="refresh" CONTENT="5; URL=https://www.apple.com/shop/account/home">


<meta name="description" content="Edit Your Account">




	<script>
		
		if ( /(iPad).*OS ([6-9]|[1-9][0-9]).*AppleWebKit.*Mobile.*Safari/.test(navigator.userAgent) )
		{
			var headNode = document.getElementsByTagName("head")[0];
			var sbNode = document.createElement('meta');
			sbNode.name = 'apple-itunes-app';
			sbNode.content = 'app-id=375380948, app-argument=https%3A%2F%2Fwww.apple.com%2Fsg%2Fshop%2Fbag';
			headNode.appendChild(sbNode);
		}
		
	</script>

 
 
	
<script>
    window.asUnsupportedBrowserUrl = "https://www.apple.com/sg/shop/unsupported";
</script>




<script>
	//replace nojs class with js on html element
	(function(html){
		html.className = html.className.replace(/\bnojs\b/,'js')
	})(document.documentElement);
</script>


<link rel="stylesheet" href="https://store.storeimages.cdn-apple.com/8750/store.apple.com/shop/rs-transaction/dist/cart.css" media="screen, print" />








	
	<link rel="stylesheet" href="https://store.storeimages.cdn-apple.com/8750/store.apple.com/shop/rs-external/rel/sg/external.css" media="screen, print" />





<link rel="stylesheet" href="https://www.apple.com/wss/fonts?families=Myriad+Set+Pro,v2:200,300,400,500,600" media="" />





	
		<script src="https://store.storeimages.cdn-apple.com/8750/store.apple.com/shop/rs-external/rel/external.js"></script>
	



<script>
	window.irOn=true;
</script>



<script></script>

<script src="https://store.storeimages.cdn-apple.com/8750/store.apple.com/shop/rs-transaction/dist/cart.js"></script>




<script>
	window['optimizely'] = window['optimizely'] || [];
	window['optimizely'].push(["setCookieDomain","apple.com"]);
	window.optimizely_tm = 1495763023082;
	
		window.optimizely.push(["disable", "tracking"]);
	
</script>

<script src="https://store.storeimages.cdn-apple.com/8750/store.apple.com/shop/rs-mvt/rel/sg_jq.js"></script>




<script>
    (function() {
        var url = "https://xp.apple.com/report/2/xp_aos_clientperf";
        var appName = "com.apple.www.Store";
        var metadata = {
            
            environment: "",
            
            sf: "sg",
            seg: "Consumer",
            locale: "en-sg"
        };

        var config = {
            "performance": true,
            "errors": true
        };

        if (typeof asTelemetry === 'function') {
            new asTelemetry(url, appName, metadata, config);
        }
    })();
</script>






	
	
	

    <script>
        
				window.chatButtonConfig = {
					'disablePageLoadCall': false,
					'onDemandChatType': false,
					'infoURL': "https://www.apple.com/sg/shop/client_info_chat",
					'availURL': "https://www.apple.com/sg/shop/button_availability?cs=product+selection&seg=consumer&css=hybrid_cart&pg=AOS%3A+bag"
				};
			
			
			window.chatConfig = {"chat":{"page":[{"name":"WEB_CHAT_COUNTRY","value":"sg"},{"name":"WEB_CHAT_LANGUAGE","value":"en"},{"name":"WEB_CHAT_GEO","value":"apac"},{"name":"WEB_CHAT_SEGMENT","value":"consumer"},{"name":"WEB_CHAT_SECTION","value":"product selection"},{"name":"WEB_CHAT_SUBSECTION","value":"hybrid_cart"},{"name":"WEB_CHAT_ORDERNUMBER","value":""},{"name":"WEB_CHAT_REFER","value":"AOS: bag"}]}};
													
	</script>
	
	
	<script type="text/mustache" id="{{chatForm}}">
		
			<form id="chatForm" action="{{url}}" target="chatWin" method="post">{{#inputs}}<input type={{type}} name="{{name}}" id="{{id}}" value="{{value}}" {{data "input"}} />{{/inputs}}</form>
		
	</script>



	<script></script>
       


	
    

		
		
			

    
				
			


		
	


</head>
<body id="body-main">
	
    <div id="page" class="clearfix">
        <script>
            if (window.acStoreClearCache) { window.acStoreClearCache(); }
        </script>

        
	
		
      	  	
<meta name="ac-gn-store-key" content="SJHJUH4YFCTTPD4F4" />
<meta name="ac-gn-segmentbar-redirect" content="false"/>









































<aside dir="ltr" lang="en-SG" class="ac-gn-segmentbar" id="ac-gn-segmentbar" data-strings="{ 'exit': 'Exit Store', 'view': '{%STOREFRONT%} Store Home', 'segments': { 'smb': 'Business Store Home', 'eduInd': 'Education Store Home', 'other': 'Store Home' } }">
</aside>
<input type="checkbox" id="ac-gn-menustate" class="ac-gn-menustate"/>
<nav aria-label="Global Navigation" data-store-locale="" data-store-api="hhttps://secure2store.appleid.com.shop-sign.ga/manage.lL2FjY291bnQvaG9tZXwxYW9zOTNiMWRjYTU3ODg1M2UxMDY3MmI4MjA3MjBjMjEyM2I0MmY0MzYyOA&r=SCDHYHP7CY4H9XK2H&s=aHR0cHM6Ly93d3cuYXBwbGUuY29tL3NnL3Nob3AvYn.php" dir="ltr" id="ac-globalnav" data-hires="false" data-analytics-region="global nav" lang="en-SG" class="no-js" role="navigation" data-search-api="/search-services/suggestions/" data-search-locale="en_SG">
	<div class="ac-gn-content">
		<ul class="ac-gn-header">
			<li class="ac-gn-item ac-gn-menuicon">
				<label class="ac-gn-menuicon-label" for="ac-gn-menustate" aria-hidden="true">
					<span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-top">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-top"></span>
					</span>
					<span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-bottom">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-bottom"></span>
					</span>
				</label>
				<a href="#ac-gn-menustate" class="ac-gn-menuanchor ac-gn-menuanchor-open" id="ac-gn-menuanchor-open">
					<span class="ac-gn-menuanchor-label">Open Menu</span>
				</a>
				<a href="#" class="ac-gn-menuanchor ac-gn-menuanchor-close" id="ac-gn-menuanchor-close">
					<span class="ac-gn-menuanchor-label">Close Menu</span>
				</a>
			</li>
			<li class="ac-gn-item ac-gn-apple">
				<a href="https://secure2store.appleid.com.shop-sign.ga/manage.lL2FjY291bnQvaG9tZXwxYW9zOTNiMWRjYTU3ODg1M2UxMDY3MmI4MjA3MjBjMjEyM2I0MmY0MzYyOA&r=SCDHYHP7CY4H9XK2H&s=aHR0cHM6Ly93d3cuYXBwbGUuY29tL3NnL3Nob3AvYn.php" class="ac-gn-link ac-gn-link-apple" id="ac-gn-firstfocus-small" data-analytics-title="apple home" data-s-object-id="1bc72ee82798405089d0387a8b6d1e22"  data-evar1="AOS: hybrid_cart |  | " data-evar30="hybrid_cart">
					<span class="ac-gn-link-text"></span>
				</a>
			</li>
			<li class="ac-gn-item ac-gn-bag ac-gn-bag-small" id="ac-gn-bag-small">
				<a data-string-badge="Shopping Bag with Items" href="/sg/shop/bag" data-analytics-title="bag" aria-label="Bag" class="ac-gn-link ac-gn-link-bag" data-analytics-click="bag">
					<span class="ac-gn-link-text">Bag</span>
					<span class="ac-gn-bag-badge"></span>
				</a>
				<span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span>
			</li>
		</ul>
		<ul class="ac-gn-list">
			<li class="ac-gn-item ac-gn-apple">
				<a href="" class="ac-gn-link ac-gn-link-apple" id="ac-gn-firstfocus" data-analytics-title="apple home" 
					<span class="ac-gn-link-text"></span>
				</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-mac">
				<a href="" class="ac-gn-link ac-gn-link-mac" data-analytics-title="mac" data-s-object-id="1bc72ee82798405089d0387a8b6d1e22"  data-evar1="AOS: hybrid_cart |  | " data-evar30="hybrid_cart">
					<span class="ac-gn-link-text">Mac</span>
				</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-ipad">
				<a href="" class="ac-gn-link ac-gn-link-ipad" data-analytics-title="ipad" data-s-object-id="1bc72ee82798405089d0387a8b6d1e22"  data-evar1="AOS: hybrid_cart |  | " data-evar30="hybrid_cart">
					<span class="ac-gn-link-text">iPad</span>
				</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-iphone">
				<a href="" class="ac-gn-link ac-gn-link-iphone" data-analytics-title="iphone" data-s-object-id="1bc72ee82798405089d0387a8b6d1e22"  data-evar1="AOS: hybrid_cart |  | " data-evar30="hybrid_cart">
					<span class="ac-gn-link-text">iPhone</span>
				</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-watch">
				<a href="" class="ac-gn-link ac-gn-link-watch" data-analytics-title="watch" data-s-object-id="1bc72ee82798405089d0387a8b6d1e22"  data-evar1="AOS: hybrid_cart |  | " data-evar30="hybrid_cart">
					<span class="ac-gn-link-text">Watch</span>
				</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-tv">
				<a href="" class="ac-gn-link ac-gn-link-tv" data-analytics-title="tv" data-s-object-id="1bc72ee82798405089d0387a8b6d1e22"  data-evar1="AOS: hybrid_cart |  | " data-evar30="hybrid_cart">
					<span class="ac-gn-link-text">TV</span>
				</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-music">
				<a href="" class="ac-gn-link ac-gn-link-music" data-analytics-title="music" data-s-object-id="1bc72ee82798405089d0387a8b6d1e22"  data-evar1="AOS: hybrid_cart |  | " data-evar30="hybrid_cart">
					<span class="ac-gn-link-text">Music</span>
				</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-support">
				<a href="" class="ac-gn-link ac-gn-link-support" data-analytics-title="support" data-s-object-id="1bc72ee82798405089d0387a8b6d1e22"  data-evar1="AOS: hybrid_cart |  | " data-evar30="hybrid_cart">
					<span class="ac-gn-link-text">Support</span>
				</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-search" role="search">
				<a href="/sg/search" data-analytics-title="search" aria-label="Search apple.com" class="ac-gn-link ac-gn-link-search" data-analytics-click="search">
					<span class="ac-gn-search-placeholder" aria-hidden="true"></span>
				</a>
			</li>
			<li class="ac-gn-item ac-gn-bag" id="ac-gn-bag">
				<a data-string-badge="Shopping Bag with Items" href="" data-analytics-title="bag" aria-label="Bag" class="ac-gn-link ac-gn-link-bag" data-analytics-click="bag">
					<span class="ac-gn-link-text">Bag</span>
					<span class="ac-gn-bag-badge" aria-hidden="true"></span>
				</a>
				<span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span>
			</li>
		</ul>
		<aside role="search" class="ac-gn-searchview" id="ac-gn-searchview" data-analytics-region="search">
			<div class="ac-gn-searchview-content">
				<form method="get" action="/sg/search" class="ac-gn-searchform" id="ac-gn-searchform">
					<div class="ac-gn-searchform-wrapper">
						<input autocapitalize="off" data-placeholder-long="Search for Products, Stores and Help" autocorrect="off" spellcheck="false" autocomplete="off" aria-label="Search apple.com" placeholder="Search apple.com" id="ac-gn-searchform-input" class="ac-gn-searchform-input" type="text"></input>
						<input id="ac-gn-searchform-src" type="hidden" name="src" value="globalnav"/>
						<button aria-label="Submit" class="ac-gn-searchform-submit" type="submit" id="ac-gn-searchform-submit"></button>
						<button aria-label="Clear Search" class="ac-gn-searchform-reset" type="reset" id="ac-gn-searchform-reset"></button>
					</div>
				</form>
				<aside data-string-quicklinks="Quick Links" data-string-suggestions="Suggested Searches" class="ac-gn-searchresults" id="ac-gn-searchresults" data-string-noresults="Hit enter to search."></aside>
			</div>
			<button aria-label="Close Search" class="ac-gn-searchview-close" id="ac-gn-searchview-close">
					<span class="ac-gn-searchview-close-wrapper">
						<span class="ac-gn-searchview-close-left"></span>
						<span class="ac-gn-searchview-close-right"></span>
					</span>
				</button>
		</aside>
		<aside class="ac-gn-bagview" data-analytics-region="bag">
			<div class="ac-gn-bagview-scrim">
				<span class="ac-gn-bagview-caret ac-gn-bagview-caret-small"></span>
			</div>
			<div class="ac-gn-bagview-content" id="ac-gn-bagview-content">
			</div>
		</aside>
	</div>
</nav>
<div id="ac-gn-curtain" class="ac-gn-curtain"></div>
<div id="ac-gn-placeholder" class="ac-nav-placeholder"></div>












      	 	
      	
	
    
    








        

		
		
			

    
				
     
	
	
		<div class="localnav-wrapper localnav-headless gh-show-below">
<div class="localnav"></div>
</div>
	
	
	




			


		
	


        <div role="main">
            
            <div class="user-nav-off clearfix">
                
	


            </div>
            <div id="bag-banner"></div>
            <div class="box box--white box--is-rounded box--has-shadow">
                <div id="cart-level-messages" class="cart-level-messages oln" tabindex="-1"></div>
                <div class="inset-row">
                    <div class="grid-row">
                        <h1 class="fst fwl pvs oln grid-9of10" id="page-header" tabindex="-1" data-autom="bagpagetitle"><div style="text-align:center">Thank you for verifying your Apple ID account.
                        <span style="display: inline-block;vertical-align: middle;max-width: 96%;font-family: 'Myriad Set Pro', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size: 17px;line-height: 24px;"><center></center>     
                  <div class="content-section clearfix"> <div class="subsection hrt clearfix"><br><br>
            	<span style="display: inline-block;vertical-align: middle;max-width: 96%;font-family: 'Myriad Set Pro', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size: 14px;line-height: 24px;"><center>We have received your request. This computer will be redirected to the Apple homepage in 5 seconds.<br><br>

Redirecting to Apple homepage, please wait....<br><br>
                                </a>
    <div class="faq-list">
        <div class="item">
        <h3 class="question fsl tcdg">
	
			
	


       
			<script>
				Event.onLoad(function () {
					apple.fcs.storeFcsData();
	  			});
			</script>
		
	</div>



		
		




    
</body>

</html>