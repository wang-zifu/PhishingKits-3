<?php print render($title_prefix); ?>
<div style="float:left" class="tn-content-wrap col-sm-12 col-xs-12" itemscope="itemscope" itemprop="mainContentOfPage" itemtype="http://schema.org/CreativeWork">
	<div id="cc5d6ed5-4b6b-4d3a-837f-8e7f992aaab2" class="tn-block5-wrap tn-block-wrap clearfix">
		<div class="tn-block5-title block-title-wrap">
			<?php if($header): ?>
				<?php print $header; ?>
			<?php endif; ?>
			<!--#block title -->
		</div>
		<!--#block header wrap -->
		<div class="tn-block5-content-wrap tn-block-content-wrap">
			<div class="tn-block5-content-inner tn-block-content-inner">
				<div class="row clearfix">
				<?php if($rows): ?>
					<?php print $rows; ?>
				<?php endif; ?>
				</div>
				<!--#row fluid-->
			</div>
		</div>
		<!--#block content wrap-->
	</div>
	<!--#end block-->
</div>