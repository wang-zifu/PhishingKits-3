<?php 
	global $user;
	if(isset($node->field_header_style) && !empty($node->field_header_style)){
		$basic_header_style = $node->field_header_style['und'][0]['value'];

	}else{
		$basic_header_style = theme_get_setting('header_style', 'zmagazine');
		if(empty($basic_header_style)){
			$basic_header_style = 'style1';
		}

	}
	
	if(isset($node->field_banner) && !empty($node->field_banner)){
		$banner_image_url = file_create_url($node->field_banner['und'][0]['uri']);
		$is_field_banner = TRUE;
	}else{
		$banner_default = theme_get_setting('banner_default', 'zmagazine');
		$banner_image = theme_get_setting('banner_image','zmagazine');
		if(!empty($banner_image)){
			$banner_image_url = file_create_url(file_load($banner_image)->uri);
		}
		$is_field_banner = FALSE;
	}
	if(isset($node->field_header_background) && !empty($node->field_header_background)){
		$basic_header_background_image = $node->field_header_background['und'][0]['uri'];
		$header_background_image_url = file_create_url($basic_header_background_image);
	}else{
		$header_background_image = theme_get_setting('header_background_image','zmagazine');
		if(!empty($header_background_image)){
			$header_background_image_url = file_create_url(file_load($header_background_image)->uri);
		}
	}
	$mobile_logo = theme_get_setting('mobile_logo_image', 'zmagazine');
	if(isset($mobile_logo) && !empty($mobile_logo)){
		$mobile_logo_url = file_create_url(file_load($mobile_logo)->uri);
	}
	$default_logo = theme_get_setting('default_mobile_logo', 'zmagazine');
	$header_social_networks = theme_get_setting('header_social_networks', 'zmagazine');
	$header_social_networks_more = theme_get_setting('header_social_networks_more', 'zmagazine');
?>

<?php if($basic_header_style == 'style1'){ ?>
<!-- Top Bar -->
<div id="tn-top-bar-wrap" class="clearfix">
	<div class="tn-container">
		<div class="tn-top-bar-inner row">
			<div class="tn-top-left-bar">
				<?php if($page['top_menu']): ?>
					<?php print render($page['top_menu']); ?>
				<?php endif; ?>
			</div>
			<!--#left top bar -->
			<?php if(!$user->uid){ ?>
			<div class="tn-top-right-bar">
				<div class="tn-logged-wrap topbar-right-element clearfix">
					<span class="tn-login-element"><a href="#" id="tn-login-popup" data-mfp-src="#tn-login-form-popup" data-effect="mpf-login-effect"><?php print t('log in'); ?><i class="fa fa-sign-in"></i></a></span>
					<div id="tn-login-form-popup" class="tn-form-popup-wrap mfp-hide mfp-animation">
						<div class="tn-login-tab-wrap">
							<ul class="tn-login-tab">
								<li class="tn-login-tab-element"><a href="#" id="tn-login-link"><?php print t('Log in'); ?></a></li>
							</ul>
						</div>
						<!--#login tab wrap-->
						<div class="tn-login-content-wrap">
							<div class="tn-login-inner tn-login-link">
								<?php if($page['user_login']): ?>
									<?php print render($page['user_login']); ?>
								<?php endif; ?>
							</div>
							<!--#login inner-->
							<div id="tn-forgot-pass-inner" class="tn-hide">
								<div class="forgot-pass-text"><?php print t('lost your password?'); ?></div>
								<?php if($page['forgot_password']): ?>
									<?php print render($page['forgot_password']); ?>
								<?php endif; ?>
							</div>
							<!--#forgot pass inner-->
						</div>
						<!--#login content wrap-->
					</div>
					<!--#login form popup-->
				</div>
				<!--#tn-logged-wrap--> 
			</div>
			<?php }else{?>
			<div class="tn-top-right-bar">
				<div class="tn-logged-wrap topbar-right-element clearfix">
					<span class="tn-login-element"><a href="<?php print base_path().'user/logout'; ?>" id="tn-logout"><?php print t('log out'); ?><i class="fa fa-sign-out"></i></a></span>
					</div>
				</div>
			</div>
			<?php } ?>
			<!--#right top bar-->
		</div>
		<!--#top bar inner -->
	</div>
	<!-- tn container -->
</div>
<!--#Top Bar wrap -->
<div class="tn-banner-wrap banner-classic-style clearfix">
	<div class="tn-container logo-area-inner clearfix">
		<div class="tn-site-logo-wrap" role="banner" itemscope="itemscope"
			itemtype="http://schema.org/Organization">
			<a itemprop="url" class="logo-image" href="<?php print base_path(); ?>"><?php if($is_field_banner != TRUE){ ?><?php if($banner_default == '1'){ ?><img class="logo-image-data" data-no-retina itemprop="image"
				src="<?php print base_path().path_to_theme(); ?>/images/logo1.png" alt="<?php print $site_name; ?>"><?php }elseif($banner_image){ ?><img class="logo-image-data" data-no-retina itemprop="image"
				src="<?php print $banner_image_url; ?>" alt="<?php print $site_name; ?>"><?php } ?> <?php }else{ ?><img class="logo-image-data" data-no-retina itemprop="image"
				src="<?php print $banner_image_url; ?>" alt="<?php print $site_name; ?>"><?php } ?></a>
			<meta itemprop="name" content="<?php print $site_name; ?>">
		</div>
		<!-- #logo wrap -->
	</div>
	<!--#logo area inner-->
</div>
<!--#banner wrap --> <!--#logo area -->
<div id="tn-main-menu-sticky" class="clearfix">
	<div class="tn-main-menu-wrap">
		<div class="tn-container">
			<div class="tn-main-menu-inner clearfix">
				<div class="tn-mobile-main-menu-button"> <a href="#" id="tn-button-mobile-menu-open"> <span class="tn-mobile-menu-button"></span> </a> </div>
				<!-- #mobile button -->
				
				<div class="tn-main-menu-responsive clearfix" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
					<div class="tn-mobile-site-title"> <a href="<?php print base_path(); ?>"><img data-no-retina src="<?php if($default_logo != '1' && isset($mobile_logo_url)){ print $mobile_logo_url;}else{ ?><?php print base_path().path_to_theme(); ?>/images/mobile-logo.png<?php } ?>" alt="<?php print $site_name; ?>"> </a> </div>
					<!--#mobile site -->

					<?php if($page['main_menu']): ?>
						<?php print render($page['main_menu']); ?>
					<?php endif; ?>

					<div class="tn-main-menu-right-area">
						<?php if(!empty($header_social_networks_more) || !empty($header_social_networks)): ?>
						<div class="tn-social-bar-wrap"><?php if(!empty($header_social_networks)) print $header_social_networks; ?>
							<?php if(!empty($header_social_networks_more)): ?>
							<div class="more-social-share">
								<div class="social-box-hidden-wrap"><?php print $header_social_networks_more; ?></div>
							</div>
							<?php endif; ?>
							<!--social box -->
						</div>
						<!--#social bar --> 
						<?php endif; ?>
					</div>
					<!--# main menu right area --> 
				</div>
				<!--#menu responsive --> 
			</div>
			<!--#menu inner --> 
		</div>
		<!--#tn container --> 
	</div>
	<!--#tn main-menu--> 
</div>
<?php if($breadcrumb): ?>
<div class="tn-breadcrumbs-wrap clearfix">

<div class="tn-breadcrumbs-inner tn-container"><?php print $breadcrumb; ?></div>
<!--#breadcrumbs --> 
</div>
<?php endif; ?>
<?php }elseif($basic_header_style == 'style2'){ ?>
<!-- Top Bar -->

<div class="tn-banner-wrap banner-background-image-style clearfix">
	<?php if(isset($header_background_image_url) && !empty($header_background_image_url)):?>
	<div class="tn-banner-parallax-wrap">
		<div data-background-image-header="<?php  print $header_background_image_url; ?>" id="tn-banner-image-parallax"></div>
	</div>
	<!--#banner parallax wrap-->
	<img src="<?php print $header_background_image_url; ?>" id="img-background-image-header" alt="" style="display:none;"/>
	<?php endif; ?>
	<div class="logo-area-inner-parallax clearfix">
		<div class="tn-site-logo-wrap" role="banner" itemscope="itemscope"
         itemtype="http://schema.org/Organization"><a itemprop="url" class="logo-image" href="<?php print base_path(); ?>"><?php if($is_field_banner != TRUE){ ?><?php if($banner_default == '1'){ ?><img class="logo-image-data" data-no-retina itemprop="image"
				src="<?php print base_path().path_to_theme(); ?>/images/logo1.png" alt="<?php print $site_name; ?>"><?php }elseif($banner_image){ ?><img class="logo-image-data" data-no-retina itemprop="image"
				src="<?php print $banner_image_url; ?>" alt="<?php print $site_name; ?>"><?php } ?> <?php }else{ ?><img class="logo-image-data" data-no-retina itemprop="image"
				src="<?php print $banner_image_url; ?>" alt="<?php print $site_name; ?>"><?php } ?></a>
			<meta itemprop="name" content="Magazine">
		</div>
		<!-- #logo wrap --> 
	</div>
	<!--#logo area inner-->
</div>
<!--#banner wrap --> <!--#logo area -->

<div id="tn-main-menu-sticky" class="clearfix">
	<div class="tn-main-menu-wrap">
		<div class="tn-container">
			<div class="tn-main-menu-inner clearfix">
				<div class="tn-mobile-main-menu-button"> <a href="#" id="tn-button-mobile-menu-open"> <span class="tn-mobile-menu-button"></span> </a> </div>
				<!-- #mobile button -->
				
				<div class="tn-main-menu-responsive tn-menu-center clearfix" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
					<div class="tn-mobile-site-title"> <a href="<?php print base_path(); ?>"><img data-no-retina src="<?php if($default_logo != '1' && isset($mobile_logo_url)){ print $mobile_logo_url;}else{ ?><?php print base_path().path_to_theme(); ?>/images/mobile-logo.png<?php } ?>" alt="<?php print $site_name; ?>"> </a> </div>
					<!--#mobile site -->
					
					<?php if($page['main_menu']): ?>
						<?php print render($page['main_menu']); ?>
					<?php endif; ?>
				</div>
				<!--#menu responsive --> 
			</div>
			<!--#menu inner --> 
		</div>
		<!--#tn container --> 
	</div>
	<!--#tn main-menu--> 
</div>
<?php if($breadcrumb): ?>
<div class="tn-breadcrumbs-wrap clearfix">

<div class="tn-breadcrumbs-inner tn-container"><?php print $breadcrumb; ?></div>
<!--#breadcrumbs --> 
</div>
<?php endif; ?>
<?php }else{ ?>
<div id="tn-top-bar-wrap" class="clearfix">
	<div class="tn-container">
		<div class="tn-top-bar-inner row">
			<div class="tn-top-left-bar">
				<?php if($page['top_menu']): ?>
					<?php print render($page['top_menu']); ?>
				<?php endif; ?>
			</div>
			<!--#left top bar -->
			<?php if(!empty($header_social_networks)): ?>
			<div class="tn-top-right-bar">
				<div class="widget-social-content-wrap topbar-right-element">
					<div class="tn-topbar-social-wrap"><?php print $header_social_networks; ?></div>
					<!--#social bar --> 
				</div>
			</div>
			<!--#right top bar-->
			<?php endif; ?>
			
		</div>
		<!--#top bar inner --> 
	</div>
	<!-- tn container --> 
</div>
<!--#Top Bar wrap -->

<div class="tn-banner-wrap banner-background-image-style clearfix">
	<?php if(isset($header_background_image_url) && !empty($header_background_image_url)):?>
	<div class="style-3 tn-banner-parallax-wrap">
		<div data-background-image-header="<?php  print $header_background_image_url; ?>" id="tn-banner-image-parallax"></div>
	</div>
	<!--#banner parallax wrap-->
	<img src="<?php print $header_background_image_url; ?>" id="img-background-image-header" alt="" style="display:none;"/>
	<?php endif; ?>
	<div class="logo-area-inner-parallax clearfix">
		<div class="tn-site-logo-wrap" role="banner" itemscope="itemscope"
         itemtype="http://schema.org/Organization"><a itemprop="url" class="logo-image" href="<?php print base_path(); ?>"><?php if($is_field_banner != TRUE){ ?><?php if($banner_default == '1'){ ?><img class="logo-image-data" data-no-retina itemprop="image"
				src="<?php print base_path().path_to_theme(); ?>/images/logo1.png" alt="<?php print $site_name; ?>"><?php }elseif($banner_image){ ?><img class="logo-image-data" data-no-retina itemprop="image"
				src="<?php print $banner_image_url; ?>" alt="<?php print $site_name; ?>"><?php } ?> <?php }else{ ?><img class="logo-image-data" data-no-retina itemprop="image"
				src="<?php print $banner_image_url; ?>" alt="<?php print $site_name; ?>"><?php } ?></a>
			<meta itemprop="name" content="Magazine">
		</div>
		<!-- #logo wrap --> 
	</div>
	<!--#logo area inner-->
</div>
<!--#banner wrap --> <!--#logo area -->

<div id="tn-main-menu-sticky" class="clearfix">
	<div class="tn-main-menu-wrap">
		<div class="tn-container">
			<div class="tn-main-menu-inner clearfix">
				<div class="tn-mobile-main-menu-button"> <a href="#" id="tn-button-mobile-menu-open"> <span class="tn-mobile-menu-button"></span> </a> </div>
				<!-- #mobile button -->
				
				<div class="tn-main-menu-responsive clearfix" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
					<div class="tn-mobile-site-title"> <a href="<?php print base_path(); ?>"><span><?php print $site_name; ?></span></a> </div>
					<!--#mobile site -->
					
					<?php if($page['main_menu']): ?>
						<?php print render($page['main_menu']); ?>
					<?php endif; ?>
				</div>
				<!--#menu responsive --> 
			</div>
			<!--#menu inner --> 
		</div>
		<!--#tn container --> 
	</div>
	<!--#tn main-menu--> 
</div>
<?php if($breadcrumb): ?>
<div class="tn-breadcrumbs-wrap clearfix">

<div class="tn-breadcrumbs-inner tn-container"><?php print $breadcrumb; ?></div>
<!--#breadcrumbs --> 
</div>
<?php endif; ?>
<?php } ?>
