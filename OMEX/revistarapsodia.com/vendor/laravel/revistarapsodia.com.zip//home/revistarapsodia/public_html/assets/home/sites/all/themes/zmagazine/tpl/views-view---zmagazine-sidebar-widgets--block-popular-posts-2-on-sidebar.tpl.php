<?php print render($title_prefix); ?>
<div id="5619e57e0bf64" class="tn-block-post-wrap tn-block-wrap clearfix">
	<div class="tn-block-post-title block-title-wrap">
		
		<?php if($header): ?>
			<?php print $header; ?>
		<!--#block title -->
		<?php endif; ?>
		
	</div>
	<!--#block header wrap -->
	<?php if($rows): ?>
	<div class="tn-block-post-content-wrap tn-block-content-wrap">
		<div class="tn-block-post-content-inner tn-block-content-inner">
			<?php print $rows; ?>
		</div>
	</div>
	<!--#block content wrap-->
	<?php endif; ?>
</div>