<?php print render($title_prefix); ?>
<div class="hide_cart_widget_if_empty">
    <div class="widget_shopping_cart_content">
    	<?php if($rows): ?>
        <ul class="cart_list product_list_widget ">
           <?php print $rows; ?>
        </ul>
    	<?php endif; ?>
        <?php if($footer): ?>
        	<?php print $footer; ?>
        <?php endif; ?>
        <p class="buttons">
			<a href="<?php print base_path(); ?>cart" class="button wc-forward"><?php print t('View Cart'); ?></a>
			<a href="<?php print base_path();?>checkout" class="button checkout wc-forward"><?php print t('Checkout'); ?></a>
		</p>
    </div>
</div>
