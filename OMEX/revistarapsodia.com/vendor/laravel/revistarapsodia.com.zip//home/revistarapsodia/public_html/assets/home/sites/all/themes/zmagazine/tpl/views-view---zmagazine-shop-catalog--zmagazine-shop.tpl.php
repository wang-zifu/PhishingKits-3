<?php print render($title_prefix); ?>
<?php if($exposed): ?>
	<?php print $exposed; ?>
<?php endif; ?>
<?php if($rows): ?>
<ul class="products">
	<?php print $rows; ?>
</ul>
<?php endif; ?>
<?php if($pager): ?>
	<?php print $pager; ?>
<?php endif; ?>
