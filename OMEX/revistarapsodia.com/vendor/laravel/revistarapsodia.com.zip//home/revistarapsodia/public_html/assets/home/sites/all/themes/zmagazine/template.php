<?php

	function zmagazine_preprocess_node(&$vars) {



		unset($vars['content']['links']['statistics']['#links']['statistics_counter']);



  		// Get a list of all the regions for this theme

	  	foreach (system_region_list($GLOBALS['theme']) as $region_key => $region_name) {



	    // Get the content for each region and add it to the $region variable

		    if ($blocks = block_get_blocks_by_region($region_key)) {

		      $vars['region'][$region_key] = $blocks;

		    }

		    else {

		      $vars['region'][$region_key] = array();

	    	}

  		}

  		/*if ($block_region_name = block_get_blocks_by_region('bottom_blog')) {

    		$vars['bottom_blog'] = $block_region_name;

  		}*/



		

		

		

	}



	function zmagazine_preprocess_html(&$variables){



  	//-- Google web fonts -->

		$variables['mobile_menu'] = block_get_blocks_by_region('mobile_main_menu');
		$variables['left_box'] = block_get_blocks_by_region('left_box');

	  	drupal_add_css('http://fonts.googleapis.com/css?family=Roboto+Condensed:300,400', array('type' => 'external'));

	  	//drupal_add_js('https://maps.googleapis.com/maps/api/js', array('type' => 'external'));

 		drupal_add_css('http://fonts.googleapis.com/css?family=Playfair+Display:400,900,700', array('type' => 'external'));

 		drupal_add_css('http://fonts.googleapis.com/css?family=Oswald:300', array('type' => 'external'));

 		drupal_add_css('http://fonts.googleapis.com/css?family=Raleway:600&amp;subset=latin', array('type' => 'external'));

 		

 	}

 	function zmagazine_form_comment_form_alter(&$form, &$form_state) {

  		$form['comment_body']['#after_build'][] = 'zmagazine_customize_comment_form';

	}

	function zmagazine_customize_comment_form(&$form) {

  		$form[LANGUAGE_NONE][0]['format']['#access'] = FALSE;

  		return $form;

	}

 	function zmagazine_preprocess_page(&$vars){

  		if (isset($vars['node'])){

    		$vars['theme_hook_suggestions'][] = 'page__'. $vars['node']->type;

  		}

  		//Taxonomy page

  		/*if (arg(0) == 'taxonomy'){

      		$vars['theme_hook_suggestions'][] = 'page__taxonomy';

    	}*/

    	//View template

    	if(views_get_page_view()){

    		$vars['theme_hook_suggestions'][] = 'page__view';

    	}

    	drupal_add_js('jQuery.extend(Drupal.settings, { "pathToTheme": "' .base_path().path_to_theme() . '" });', 'inline');



    	if(arg(0) == 'taxonomy' && arg(1) == 'term') {

	        $tid = (int)arg(2);

	        $term = taxonomy_term_load($tid);

        	if(is_object($term)) {

           		$vars['theme_hook_suggestions'][] = 'page__taxonomy__'.$term->vocabulary_machine_name;

        	}

  		}

  		if (drupal_is_front_page()) {

    		unset($vars['page']['content']['system_main']['default_message']); //will remove message "no front page content is created"

  		}

  		 if(arg(0) == 'taxonomy' && arg(1) == 'term' && is_numeric(arg(2))) {

    		unset($vars['page']['content']['system_main']['term_heading']);

  		}

  		if (arg(0)=='user'){ // we are somewhere down in search/node/term or similar

    		$vars['theme_hook_suggestions'][] = 'page__user';

  		}	

	}

	function zmagazine_breadcrumb($variables) {

		$crumbs ='';

		$breadcrumb = $variables['breadcrumb'];

		if (!empty($breadcrumb)) {

			$crumbs .= '';

			foreach($breadcrumb as $value) {



				$crumbs .= '<span>'.strip_tags($value,'<a>').'</span><i class="fa fa-angle-right next-breadcrumbs"></i>';

			}

			$crumbs .= drupal_get_title();

			return $crumbs;

		}else{

			return NULL;

		}

	}

	function zmagazine_node_view_alter(&$build){

    	if ($build['#view_mode'] == 'teaser'){

        // remove "add comment" link from node teaser mode display

        unset($build['links']['comment']['#links']['comment-add']);

        // and if logged out this will cause another list item to appear, so let's get rid of that

        unset($build['links']['comment']['#links']['comment_forbidden']);

    	}

	}

	function zmagazine_links($links) {

    	return theme_links($links);

	}

	function zmagazine_menu_tree__menu_top_menu($variables) {

	  	if (preg_match("/\bexpanded\b/i", $variables['tree'])){

	    	return '<ul class="tn-top-menu">' . $variables['tree'] . '</ul>';

	  	}else{

	    	return '<ul class="sub-menu">' . $variables['tree'] . '</ul>';

	  	}

	}

	

	function zmagazine_menu_link__menu_top_menu(array $variables) {

	  	$element = $variables['element'];

	  	$sub_menu = '';



	  	$element['#attributes']['class'][] = 'menu-item';



	  	if ($element['#below']) {

	    	$sub_menu = drupal_render($element['#below']);

	  	}

	  	$output = l($element['#title'], $element['#href'], $element['#localized_options']);

	  	return '<li' . drupal_attributes($element['#attributes']) . '>' . $output . $sub_menu . "</li>\n";

	}

	$i = '';

	function zmagazine_menu_tree__main_menu(array $variables){		





	    	return '<ul class="tn-sub-menu">' . $variables['tree'] . '</ul>';





	  	

	}

	function zmagazine_menu_link__main_menu(array $variables) {

  		$element = $variables['element'];

  		$sub_menu = '';

  		$element['#attributes']['class'][] = 'menu-item';

  		if ($element['#below']) {

   			$sub_menu = drupal_render($element['#below']);

  		}

  		$output = l($element['#title'], $element['#href'], $element['#localized_options']);

  		return '<li' . drupal_attributes($element['#attributes']) . '>' . $output . $sub_menu . "</li>\n";

	}

	function zmagazine_menu_tree__menu_footer_menu(array $variables){		

	    return '<ul id="menu-footer-menu" class="footer-menu">' . $variables['tree'] . '</ul>';  	

	}

	function zmagazine_menu_link__menu_footer_menu(array $variables) {

  		$element = $variables['element'];

  		$sub_menu = '';

  		$element['#attributes']['class'][] = 'menu-item';

  		if ($element['#below']) {

   			$sub_menu = drupal_render($element['#below']);

  		}

  		$output = l($element['#title'], $element['#href'], $element['#localized_options']);

  		return '<li' . drupal_attributes($element['#attributes']) . '>' . $output . $sub_menu . "</li>\n";

	}

	function zmagazine_preprocess_block(&$variables, $hook) {

  		$block = $variables['block'];

  		if (isset($block->title) && strlen($block->title) > 0) {

    		$variables['title'] = $block->title;

  		}

	}

	function zmagazine_menu_tree__menu_main_menu_for_mobile(array $variables){		

	    return '<ul class="sub-menu">' . $variables['tree'] . '</ul>';  	

	}

	function zmagazine_menu_link__menu_main_menu_for_mobile(array $variables) {

  		$element = $variables['element'];

  		$sub_menu = '';

  		$element['#attributes']['class'][] = 'menu-item';

  		if ($element['#below']) {

   			$sub_menu = drupal_render($element['#below']);

  		}

  		$output = l($element['#title'], $element['#href'], $element['#localized_options']);

  		return '<li' . drupal_attributes($element['#attributes']) . '>' . $output . $sub_menu . "</li>\n";

	}