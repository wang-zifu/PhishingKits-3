<?php namespace App\Http\Controllers;

use App\AuthorsModel;
use App\Core\FileUtil;
use App\MenuModel;
use App\PostContentModel;
use App\PostModel;
use App\PostMultiContentModel;
use App\SliderModel;
use PhpParser\Node\Scalar\MagicConst\File;
use PhpSpec\Exception\Exception;

class HomeController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Home Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders your application's "dashboard" for users that
	| are authenticated. Of course, you are free to change or remove the
	| controller as you wish. It is just here to get your app started!
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('auth');
	}



	/**
	 * Show the application dashboard to the user.
	 *
	 * @return Response
	 */
	public function getPosts()
	{

		return view('admin.posts.home')
			->with('menus', MenuModel::all());
	}

	/**
	 * Show the application dashboard to the user.
	 *
	 * @return Response
	 */
	public function getNewPost($idMenu = 0, $idKid = 0){

		$pth = PostModel::where('menu_id', $idMenu)->where('menu_kids_id', $idKid)->where('history', false)->get();
		if(count($pth) > 0)
			foreach ($pth as $postH) {
				$postH->history = true;
				$postH->save();
			}

		$post = new PostModel;
		$post->menu_id = $idMenu;
		$post->menu_kids_id = $idKid;
		$post->template_id = 1;
		//TEMPLATE: GENERAL
		//HABLANDO ENTRE MÚSICOS
		//A PROPOSITO DE
		//TU QUE OPINAS

		if (
			($idMenu == 2 && $idKid == 4) ||
			($idMenu == 5 && $idKid == 9)
		)
			$post->template_id = 2;
		//TEMPLATE: 1 y 1
		//LO TIENES QUE ESCUCHAR

		if (
			($idMenu == 2 && $idKid == 2) ||
			($idMenu == 3 && $idKid == 6) ||
			($idMenu == 4 && $idKid == 8) ||
			($idMenu == 5 && $idKid == 10) ||
			($idMenu == 6 && $idKid == 0)
		)
			$post->template_id = 3;
		//TEMPLATE: IMAGEN GRANDE DE CABECERA
		//ENTRE MUSICOS
		//REPORTAJE
		//REPORTAJE(Sonido local)


		if (
			($idMenu == 3 && $idKid == 5) ||
			($idMenu == 4 && $idKid == 7)
		)
			$post->template_id = 4;
		//TEMPLATE: PARALAX DE CABECERA
		//EN ENTREVISTA

		if (
		($idMenu == 5 && $idKid == 11) ||
 		($idMenu == 4 && $idKid == 11)
		)
			$post->template_id = 5;

		//TEMPLATE : LAS DOS PLANTILLAS JUNTAS
		$post->save();
		return redirect()->back();
	}


	public function getAddToPost($id){
		$PostMultiContentModel = new PostMultiContentModel;
		$PostMultiContentModel->post_id = $id;
		$PostMultiContentModel->save();
		return redirect()->back();
	}


	/**
	 * Show the application dashboard to the user.
	 *
	 * @return Response
	 */
	public function getPost($idMenu = null, $idKid = null){
		$posts = PostModel::where('menu_id', $idMenu)->where('menu_kids_id', $idKid)->get();

		return view('admin.posts.post')
			->with('posts', $posts)
			->with('idMenu', $idMenu)
			->with('idKid', $idKid);
	}


	public function getPostForm(FileUtil $fileUtil, $idPost){
		$post = PostModel::find($idPost);

		if($post->content == null)
		{
			$post->content = new PostContentModel;
			$post->content->post_id = $post->id;
			$post->content->save();
		}



		if(\Request::isMethod('post')){

			$post = PostModel::find(\Input::get('id'));

			if($post == null){
				return redirect()->back();
			}



			$requestModel = \Input::all();




			$post->fill($requestModel);
			$post->save();
			$id= \Input::get('id');
			$requestModel = \Input::all();

			if(\Request::isMethod('post')){
				if($post->id != $id){
					$post = PostModel::find(\Input::get('id'));
				}

				if($post->template_id == 1 || $post->template_id == 3 || $post->template_id == 4 || $post->template_id == 5 ){ // POST GENERAL

					if(array_key_exists('url', $requestModel)) {
						$isIframe = (explode('src="', $requestModel['url']));
						if (is_array($isIframe) && count($isIframe) > 1) {
							$requestModel['url'] = explode('"', $isIframe[1])[0];
						}
					}

					if($post->template_id == 4){
						$requestModel['choice'] = "image";
					}

					if($requestModel['choice'] == "image"){
						$requestModel['url'] = "";
					}

					if (\Input::hasFile('url_image'))
					{
						$requestModel['url_image'] = $fileUtil->uploadIndexImage(\Input::file('url_image'), 'post' . $post->id);

					}

					if (\Input::hasFile('image'))
					{
						$requestModel['image'] = $fileUtil->uploadIndexImage(\Input::file('image'), 'post' . $post->id);
					}
					$post->content->fill($requestModel);
					$post->content->save();
				}

				if($post->template_id == 2 || $post->template_id == 5 ) { // POST GENERAL
					if(Count($post->multiContent) > 0){
						foreach($post->multiContent as $m){
							$m->subtitle = $requestModel["subtitle_".$m->id];

							$isIframe = (explode('src="', $requestModel["url_".$m->id]));
							if(is_array($isIframe) && count($isIframe) > 1){
								$requestModel["url_".$m->id] = explode('"', $isIframe[1])[0];
							}

    						$m->url = $requestModel["url_".$m->id];

							if (\Input::hasFile('preview_'.$m->id))
							{
								$m->preview = $fileUtil->uploadIndexImage(\Input::file('preview_'.$m->id), 'post'.$post->id. '/p_'. $m->id);
							}

    						$m->text = $requestModel["text_".$m->id];
    						if(isset($requestModel["dataContent_".$m->id]))
    							$m->dataContent = $requestModel["dataContent_".$m->id];

							$m->save();
						}
					}
				}


				return redirect()->back();
			}



			return redirect()->back();
		}

		return view('admin.posts.postform')
			->with('post', $post);

	}

	/*
	public function getPost(FileUtil $fileUtil, $idMenu = null, $idKid = null)
	{
		//$idMenu = \Input::get('idMenu');
		//$idKid = \Input::get('idKid');
		$post = PostModel::where('menu_id', $idMenu)->where('menu_kids_id', $idKid)->first();
		if($post == null){
			$post = PostModel::where('menu_id', $idMenu)->where('menu_kids_id', null)->first();
		}

		if($post == null){
			$post = PostModel::where('menu_id', $idMenu)->where('menu_kids_id', null)->first();
			if($post == null) {
				$post = new PostModel;
				$post->menu_id = $idMenu;
				$post->menu_kids_id = $idKid;
				$post->save();
			}
		}

		if(\Request::isMethod('post')){
			if($post->id != \Input::get('id')){
				$post = PostModel::find(\Input::get('id'));
			}
			$requestModel = \Input::all();
			$post->fill($requestModel);

			unset($requestModel["_token"]);
			unset($requestModel["author_id"]);
			unset($requestModel["id"]);
			unset($requestModel["template_id"]);
			unset($requestModel["idKid"]);
			unset($requestModel["idMenu"]);
			unset($requestModel["_wysihtml5_mode"]);

			foreach($requestModel as $k => $v){
				$key = explode('_', $k);
				if(is_array($key) && count($key) > 1){
					if($key[0] == "name") {
						$id = $key[1];
						$contentIntoPost = $post->content->find($id);
						if ($contentIntoPost != null) {
							if ($contentIntoPost->type_insert_post_id == 3) {
								// SI ES MULTIMEDIA SE SUBE PREVIEW
								$isIframe = (explode('src="', $v));
								if(is_array($isIframe) && count($isIframe) > 1){
									$v = explode('"', $isIframe[1])[0];
								}

								if (\Request::hasFile('file_' . $id)) {
									$contentIntoPost->preview = $fileUtil->uploadIndexImage(\Input::file('file_' . $id), 'post' . $post->id);
									unset($requestModel["file_".$id]);
								}
								$contentIntoPost->name = $v;

							} elseif ($contentIntoPost->type_insert_post_id == 4) {
								// SI ES IMAGEN SE SUBE ARCHIVO
								if (\Request::hasFile('file_' . $id)) {
									$contentIntoPost->name = $fileUtil->uploadIndexImage(\Input::file('file_' . $id), 'post' . $post->id);
									unset($requestModel["file_".$id]);
								}

							} else {

								$contentIntoPost->name = $v;
							}
							$contentIntoPost->save();
						}
					}
				}

			}

			$post->save();
			return redirect()->back();
		}

		return view('admin.posts.post')
			->with('post', $post);
	}
/////////
	public function getAuthors(){
		return view('admin.authors')
			->with('authors', AuthorsModel::all());
	}

	public function getCreateUpdateAuthor(){

		return view('admin.authors')
			->with('authors', AuthorsModel::all());
	}
	*/

	public function postAddToPost()
	{
		$model = \Input::all();
		$PostContentModel = new PostContentModel;
		$PostContentModel->fill($model);
		$PostContentModel->save();
		return \Response::json(['success' => true]);
	}

	public function postRemoveToPost(){
		$id = \Input::get('id');
		PostContentModel::destroy($id);
		return \Response::json(['success' => true]);
	}


	public function getDeleteoneone($id){
		PostMultiContentModel::destroy($id);
		return redirect()->back();

	}


}
