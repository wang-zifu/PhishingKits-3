<?php print render($title_prefix); ?>
<div id="bb9b223f-57de-4669-9291-7c97592b8b98" class="tn-block3-wrap tn-block-wrap clearfix">
	<?php if($header): ?>
		<?php print $header; ?>
	<?php endif; ?>
	<!--#block header wrap -->
	<div class="tn-block3-content-wrap tn-block-content-wrap">
		<div class="tn-block3-content-inner tn-block-content-inner">			
			<?php if($rows): ?>
				<?php print $rows; ?>
			<?php endif; ?>
			<!--#row fluid-->
		</div>
	</div>
	<!--#block content wrap-->
	<!--#load more wrap-->
</div>
<!--#end block-->
