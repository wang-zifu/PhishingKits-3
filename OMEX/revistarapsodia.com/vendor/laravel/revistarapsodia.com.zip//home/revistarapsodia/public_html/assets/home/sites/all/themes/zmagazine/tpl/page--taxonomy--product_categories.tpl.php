
<?php require_once(drupal_get_path('theme','zmagazine').'/tpl/header.tpl.php'); ?>
<!-- Start Page Template -->
<div class="tn-container tn-section-content-wrap row clearfix">
    <div style="float:left" class="tn-content-wrap col-sm-8 col-xs-12">
	    <ul class="products">
			<?php if($page['content']):?>
			<?php
				if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
					print render($tabs);
				endif;
				print $messages;
			?>
			<?php print render($page['content']); ?>
			<?php endif; ?>
		</ul>
    </div> 
    <!--#content of section content-->
    <div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
        <div class="tn-sidebar-sticky">
            <div class="tn-sticky-sidebar">
                <?php if($page['sidebar_second']): ?>
                    <?php print render($page['sidebar_second']); ?>
                <?php endif; ?>
            </div>
            <!--#end sticky -->
        </div>
    </div>
    <!--#close sidebar -->
</div>

<?php require_once(drupal_get_path('theme','zmagazine').'/tpl/footer.tpl.php'); ?>