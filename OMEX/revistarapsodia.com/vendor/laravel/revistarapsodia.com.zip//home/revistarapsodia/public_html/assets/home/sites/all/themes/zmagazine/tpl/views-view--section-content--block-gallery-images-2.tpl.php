<?php print render($title_prefix); ?>
<aside class="widget APTFIN_by_TAP">
    <!-- Using AlpinePT for Instagram v1.2.7 with JSON--><!-- Request made --><!-- Success using wp_remote_get() and JSON -->
    <div id="zmagazine-gallery-2" class="AlpinePhotoTiles_container_class_2">
        <div class="AlpinePhotoTiles_parent_class_2" style="width:100%;max-width:80%;padding:0px;margin:0px auto;text-align:center;">
            <?php if($rows): ?>
       		   <?php print $rows; ?>
            <?php endif; ?>
        	<div class="AlpinePhotoTiles_breakline"></div>
    	</div>
	</div>
</aside>