
<?php 
	$no_avatar = base_path().path_to_theme().'/images/no_avatar.gif';
 ?>
<li class="comment even thread-even depth-1">
	<div class="comment_container">
		<?php if(!$picture){ ?>
		<img alt='no-avatar' src='<?php print $no_avatar; ?>' srcset='<?php print $no_avatar ?>' class='avatar  photo' height='60' width='60' />
		<?php }else{ print '<div class="user-picture">'.strip_tags($picture,'<img>').'</div>';} ?>
		<div class="comment-text">
			
			<p class="meta"> <strong itemprop="author"><?php print $author; ?></strong> &ndash;
				<time><?php print format_date($comment->created, 'custom', 'F d, Y'); ?></time>
				<strong style="float:right"><?php print strip_tags(render($content['links']),'<a>'); ?></strong>
			</p>

			<div itemprop="description" class="description">
				<?php unset($content['links']); print render($content); ?>
			</div>
		</div>
	</div>
</li>