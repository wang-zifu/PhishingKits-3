<?php namespace App\Http\Controllers;

use App\GalleryModel;
use App\Core\FileUtil;

class GalleryController extends Controller {

    /*
    |--------------------------------------------------------------------------
    | Home Controller
    |--------------------------------------------------------------------------
    |
    | This controller renders your application's "dashboard" for users that
    | are authenticated. Of course, you are free to change or remove the
    | controller as you wish. It is just here to get your app started!
    |
    */
    /**
     * @var FileUtil
     */
    private $fileUtil;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(FileUtil $fileUtil)
    {
        $this->middleware('auth');
        $this->fileUtil = $fileUtil;
    }


    /**
     * Show the application dashboard to the user.
     *
     * @return Response
     */
    public function getBanner()
    {
        return view('admin.gallery')
            ->with('sliders', GalleryModel::all());
    }
    /**
     * @return \Illuminate\Http\RedirectResponse
     */
    public function newImageSlider(){
        $file = \Input::file('photo');
        $folder = \Input::get('folder');
        $name = $this->fileUtil->uploadIndexImage($file, $folder);
        $Slider = new GalleryModel;
        $Slider->img = $name;
        $Slider->title = \Input::get('title');
        $Slider->save();
        return redirect()->back();
    }

    /**
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function deleteSlider($id){
        $Slider = GalleryModel::find($id);
        if($Slider != null) {
            $folder = explode("/", $Slider->img);
            $folderIndex = "slider/";
            $this->fileUtil->deleteFolder($folderIndex.$folder[0]);
            GalleryModel::destroy($id);
        }
        return redirect()->back();
    }

}
