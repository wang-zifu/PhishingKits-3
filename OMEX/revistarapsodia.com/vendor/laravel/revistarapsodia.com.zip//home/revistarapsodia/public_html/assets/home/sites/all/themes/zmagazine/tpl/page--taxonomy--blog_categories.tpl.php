<?php
	$term = taxonomy_term_load(arg(2));
	$title = $term->name; 
	if(isset($term->field_layout) && !empty($term->field_layout)){
		$layout = $term->field_layout['und'][0]['value'];
	}else{
		$layout = 'layout1';
	}
	if($term->description){
		$description =  $term->description;
	}
	if(isset($term->field_sidebar) && !empty($term->field_sidebar)){
		$sidebar = $term->field_sidebar['und'][0]['value'];
	}else{
		$sidebar = 'none';
	}
	if($sidebar == 'right' || $sidebar == 'left'){
		$col = 'col-sm-8';
	}else{
		$col = 'col-sm-12';
	}
?>	
<?php require_once(drupal_get_path('theme','zmagazine').'/tpl/header.tpl.php'); ?>
<?php if($page['section']): ?>
	<?php print render($page['section']); ?>
<?php endif; ?>
<?php if($layout == 'layout1'){ ?>
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php if($sidebar == 'left'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_first']): ?>
				<?php print render($page['sidebar_first']); ?>
			<?php endif; ?>
		</div>
	</div>
	<!--#close sidebar -->
	<?php endif; ?>
	<div <?php if($sidebar == 'right'){ ?>style="float:left"<?php }elseif($sidebar == 'left'){ ?>style="float:right"<?php } ?> class="tn-content-wrap <?php print $col; ?> col-xs-12" itemscope="itemscope" itemprop="mainContentOfPage" itemtype="http://schema.org/CreativeWork">
		<div class="tn-header-category-wrap">
			<div class="tn-category-title">
				<h1 itemprop="name"><?php print $title; ?></h1>
				<span class="tn-category-7"><?php print t('category'); ?></span>
			</div>
			<?php if(isset($description) && !empty($description)): ?>
				<div class="tn-cate-description"><?php print $description; ?></div>
			<?php endif; ?>
		</div>
		<!--#header category -->
		<div class="tn-category-wrap">
			<div class="tn-page-classic-layout">


			<?php if($page['content']):?>
				<?php print render($page['content']); ?>
			<?php endif; ?>
			</div>
		</div>
		<!--category wrap -->
	</div>
	<!--#content of section content-->
	<?php if($sidebar == 'right'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_second']): ?>
				<?php print render($page['sidebar_second']); ?>
			<?php endif; ?>
		</div>
	</div>
	<!--#close sidebar -->
	<?php endif; ?>
</div>
<?php }elseif($layout == 'layout2'){ ?>
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php if($sidebar == 'left'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_first']): ?>
				<?php print render($page['sidebar_first']); ?>
			<?php endif; ?>
		</div>
	</div>
	<!--#close sidebar -->
	<?php endif; ?>

	<div <?php if($sidebar == 'right'){ ?>style="float:left"<?php }elseif($sidebar == 'left'){ ?>style="float:right"<?php } ?> class="tn-content-wrap <?php print $col; ?> col-xs-12">
		<div class="tn-header-category-wrap">
			<div class="tn-category-title">
				<h1 itemprop="name"><?php print $title; ?></h1>
				<span><?php print t('category'); ?></span>
			</div>
			<?php if($description): ?>
			<div class="tn-cate-description"><?php print $description; ?></div>
		<?php endif; ?>
		</div>
		<!--#header category -->
		<div class="tn-category-wrap">
			<?php if($page['content']): ?>
				<?php print render($page['content']); ?>
			<?php endif; ?>
			<!--#module 1 wrap -->
		</div>
		<!--category wrap -->
	</div>
	<!--#content of section content-->
	<?php if($sidebar == 'right'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_second']): ?>
				<?php print render($page['sidebar_second']); ?>
			<?php endif; ?>
		</div>
	</div>
	<!--#close sidebar -->
	<?php endif; ?>
</div>
<?php }elseif($layout == 'layout3'){ ?>
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php if($sidebar == 'left'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_first']): ?>
				<?php print render($page['sidebar_first']); ?>
			<?php endif; ?>
		</div>
	</div>
	<!--#close sidebar -->
	<?php endif; ?>
	<div <?php if($sidebar == 'right'){ ?>style="float:left"<?php }elseif($sidebar == 'left'){ ?>style="float:right"<?php } ?> class="tn-content-wrap <?php print $col; ?> col-xs-12">
		<!--#header category -->
		<div class="tn-header-category-wrap">
			<div class="tn-category-title">
				<h1 itemprop="name"><?php print $title; ?></h1>
				<span class="tn-category-11"><?php print t('category'); ?></span>
			</div>
			<?php if($description): ?>
			<div class="tn-cate-description"><?php print $description; ?></div>
			<?php endif; ?>
		</div>
		<!--#header category -->
		<div class="tn-category-wrap">
			<?php if($page['content']): ?>
				<?php print render($page['content']); ?>
			<?php endif; ?>
		</div>
		<!--category wrap --> 
	</div>
	<!--#content of section content-->
	<?php if($sidebar == 'right'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_second']): ?>
				<?php print render($page['sidebar_second']); ?>
			<?php endif; ?>
		</div>
	</div>
	<!--#close sidebar -->
	<?php endif; ?>
</div>
<?php }elseif($layout == 'layout4'){ ?>
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php if($sidebar == 'left'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_first']): ?>
				<?php print render($page['sidebar_first']); ?>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>
	<div <?php if($sidebar == 'right'){ ?>style="float:left"<?php }elseif($sidebar == 'left'){ ?>style="float:right"<?php } ?> class="tn-content-wrap <?php print $col; ?> col-xs-12" itemscope="itemscope" itemprop="mainContentOfPage" itemtype="http://schema.org/CreativeWork">
		<!--#header category -->
		<div class="tn-header-category-wrap">
			<div class="tn-category-title">
				<h1 itemprop="name"><?php print $title; ?></h1>
				<span><?php print t('category'); ?></span>
			</div>
			<?php if($description): ?>
			<div class="tn-cate-description"><?php print $description; ?></div>
			<?php endif; ?>
		</div>
		<!--#header category -->
		<div class="tn-category-wrap">
			<?php if($page['content']): ?>
				<?php print render($page['content']); ?>
			<?php endif; ?>
		</div>
		<!--category wrap --> 
	</div>
	<!--#content of section content-->
	<?php if($sidebar == 'right'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_second']): ?>
				<?php print render($page['sidebar_second']); ?>
			<?php endif; ?>
		</div>
	</div>
	<!--#close sidebar -->
	<?php endif; ?>
</div>
<?php }elseif($layout == 'layout5'){ ?>
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php if($sidebar == 'left'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_first']): ?>
				<?php print render($page['sidebar_first']); ?>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>
	<div <?php if($sidebar == 'right'){ ?>style="float:left"<?php }elseif($sidebar == 'left'){ ?>style="float:right"<?php } ?> class="tn-content-wrap <?php print $col; ?> col-xs-12">
		<!--#header category -->
		<div class="tn-header-category-wrap">
			<div class="tn-category-title">
				<h1 itemprop="name"><?php print $title; ?></h1>
				<span><?php print t('category'); ?></span>
			</div>
			<?php if($description): ?>
			<div class="tn-cate-description"><?php print $description; ?></div>
			<?php endif; ?>
		</div>
		<!--#header category -->
		<div class="tn-category-wrap">
			<?php if($page['content']): ?>
				<?php print render($page['content']); ?>
			<?php endif; ?>
		</div>
		<!--category wrap --> 
	</div>
	<!--#content of section content-->
	<?php if($sidebar == 'right'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_second']): ?>
				<?php print render($page['sidebar_second']); ?>
			<?php endif; ?>
		</div>
	</div>
	<!--#close sidebar -->
	<?php endif; ?>
</div>
<?php } ?>
<?php require_once(drupal_get_path('theme','zmagazine').'/tpl/footer.tpl.php'); ?>