<div  class="tn-block9-wrap tn-block-wrap clearfix">
	<div class="tn-container tn-black-style">
		<div class="tn-black-style-inner">
			<?php if($header): ?>
			<div class="tn-block9-title block-title-wrap">
				<?php print $header; ?>
			</div>
			<!--#block header wrap -->
			<?php endif; ?>
			<?php if($rows): ?>
			<div class="tn-block9-content-wrap tn-block-content-wrap">
				<div class="tn-block9-content-inner tn-block-content-inner">
					<div class="row clearfix">
						<?php print $rows; ?>
					</div>
					<!--#row fluid-->
				</div>
			</div>
			<!--#block content wrap-->
			<?php endif; ?>
		</div>
		<!--black style inner-->
	</div>
	<!--#end block-->
</div>