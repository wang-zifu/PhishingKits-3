<?php print render($title_prefix);?>
<?php if($rows):?>
<div class="tagcloud">
<?php print $rows;?>
</div>
<?php endif;?>