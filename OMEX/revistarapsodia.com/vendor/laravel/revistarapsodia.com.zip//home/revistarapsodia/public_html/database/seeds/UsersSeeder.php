<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class UsersSeeder extends Seeder {

	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
		$admin = new \App\User;
		$admin->name = "Admin";
		$admin->email = "admin@revistarapsodia.com";
		$admin->password = \Hash::make("revistarapsodia.com");
		$admin->save();

	}

}
