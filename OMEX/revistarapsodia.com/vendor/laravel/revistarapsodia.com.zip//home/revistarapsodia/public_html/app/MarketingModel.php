<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class MarketingModel extends Model {

	//
    protected $fillable = ['img', 'description', 'orderBy', 'count'];
}
