<?php 
	if(isset($node->field_sidebar) && !empty($node->field_sidebar)){
		$sidebar = $node->field_sidebar['und'][0]['value'];
	}else{
		$sidebar = 'none';
	}
	if($sidebar == 'left' || $sidebar == 'right'){
		$col = 'col-sm-8';
	}else{
		$col = 'col-sm-12';
	}
	if($sidebar == 'left'){
		$style_sidebar = 'style="float:right"';
	}elseif($sidebar == 'right'){
		$style_sidebar = 'style="float:left"';
	}else{
		$style_sidebar = 'style="float:left"';
	}
?>
<?php require_once(drupal_get_path('theme','zmagazine').'/tpl/header.tpl.php'); ?>
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php if($sidebar == 'left'): ?>
	
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary" itemscope="itemscope">
		<div class="tn-sidebar-sticky">
		<?php if($page['sidebar_first']): ?>
			<?php print render($page['sidebar_first']); ?>
		<?php endif; ?>
		</div>
	</div>
	<!--#close sidebar -->
	
	<?php endif; ?>
	<div <?php print $style_sidebar; ?> class="tn-content-wrap <?php print $col; ?> col-xs-12">
	<div class="clearfix"></div>
	<?php if($page['content']):?>
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php print render($page['content']); ?>
	<?php endif; ?>
	</div>
	<!--#content of section content-->
	<?php if($sidebar == 'right'): ?>
	
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary" itemscope="itemscope">
		<div class="tn-sidebar-sticky">
		<?php if($page['sidebar_second']): ?>
			<?php print render($page['sidebar_second']); ?>
		<?php endif; ?>
		</div>
	</div>
	<!--#close sidebar -->
	
	<?php endif; ?>
</div>

<?php require_once(drupal_get_path('theme','zmagazine').'/tpl/footer.tpl.php'); ?>