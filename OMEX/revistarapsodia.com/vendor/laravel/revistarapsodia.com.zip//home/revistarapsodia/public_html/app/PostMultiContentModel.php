<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class PostMultiContentModel extends Model {

	//
    protected $fillable = ['post_id', 'subtitle', 'url', 'preview', 'text', 'dataContent'];

}
