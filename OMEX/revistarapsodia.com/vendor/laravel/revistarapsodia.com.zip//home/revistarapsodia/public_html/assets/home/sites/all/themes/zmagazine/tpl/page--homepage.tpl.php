<?php require_once(drupal_get_path('theme','zmagazine').'/tpl/header.tpl.php'); ?>
<div class="tn-container tn-section-content-wrap row clearfix">
<?php

	if($page['content']):
	if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
		print render($tabs);
	endif;
	print $messages;
	endif;
	print render($page['content']);
?>
</div>
<?php if($page['section']): ?>
	<?php print render($page['section']); ?>
<?php endif; ?>
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php if($page['section_with_sidebar']):?>
		<?php print render($page['section_with_sidebar']); ?>
	<?php endif; ?>
	<!--#content of section content-->
	<?php if($page['sidebar_second']): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary" itemscope="itemscope">
		<div class="tn-sidebar-sticky">
			<?php print render($page['sidebar_second']); ?>
		</div>
	</div>
	<!--#close sidebar -->
	<?php endif; ?>
</div>
<?php if($page['section_bottom']): ?>
	<?php print render($page['section_bottom']); ?>
<?php endif; ?>


<?php require_once(drupal_get_path('theme','zmagazine').'/tpl/footer.tpl.php'); ?>