<?php namespace App\Http\Controllers;

use App\AuthorsModel;
use App\Core\FileUtil;
use App\SliderModel;
use App\User;

class AuthorsController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Home Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders your application's "dashboard" for users that
	| are authenticated. Of course, you are free to change or remove the
	| controller as you wish. It is just here to get your app started!
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('auth');
	}


	/**
	 * @return $this
     */
	public function getAuthors(){
		return view('admin.authors.home')
			->with('authors', AuthorsModel::all());
	}

	public function getCreateUpdateAuthor(FileUtil $fileUtil, $id = null){
		//$id =\Input::get('id');
		$Author = AuthorsModel::find($id);

		if($Author == null)
			$Author = new AuthorsModel;

		$Users = User::all();

		if(\Request::isMethod('post')){
			if($id == null)
				\Session::flash('msg', 'Autor creado correctamente');
			else
				\Session::flash('msg', 'Autor actualizado correctamente');

			$authorModel = \Input::all();
			if(\Input::hasFile('file'))
			{
				$folder = "authors";
				$authorModel['imageProfile'] = $fileUtil->uploadIndexImage(\Input::file('file'), $folder);
			}
			$Author->fill($authorModel);
			$Author->save();
			return redirect()->to(asset('Admin/autores'));
		}

		return view('admin.authors.createupdate')
			->with('author', $Author)
			->with('users', $Users);
	}

	public function getRemoveAuthor(){
		$id =\Input::get('id');
		AuthorsModel::destroy($id);
		return redirect()->to(asset('Admin/crearautor'));

	}

}
