<?php namespace App\Http\Controllers;

use App\SliderModel;
use App\Core\FileUtil;

class SliderController extends Controller {

    /*
    |--------------------------------------------------------------------------
    | Home Controller
    |--------------------------------------------------------------------------
    |
    | This controller renders your application's "dashboard" for users that
    | are authenticated. Of course, you are free to change or remove the
    | controller as you wish. It is just here to get your app started!
    |
    */
    /**
     * @var FileUtil
     */
    private $fileUtil;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(FileUtil $fileUtil)
    {
        $this->middleware('auth');
        $this->fileUtil = $fileUtil;
    }


    /**
     * Show the application dashboard to the user.
     *
     * @return Response
     */
    public function getBanner()
    {
        return view('admin.banner')
            ->with('sliders', SliderModel::all());
    }
    /**
     * @return \Illuminate\Http\RedirectResponse
     */
    public function newImageSlider(){
        $file = \Input::file('photo');
        $folder = \Input::get('folder');
        $name = $this->fileUtil->uploadIndexImage($file, $folder);
        $Slider = new SliderModel;
        $Slider->img = $name;
        $Slider->postUrl = \Input::get('postUrl');
        $Slider->description = \Input::get('description');
        $Slider->title = \Input::get('title');
        $Slider->save();
        return redirect()->back();
    }

    /**
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function deleteSlider($id){
        $Slider = SliderModel::find($id);
        if($Slider != null) {
            $folder = explode("/", $Slider->img);
            $folderIndex = "slider/";
            $this->fileUtil->deleteFolder($folderIndex.$folder[0]);
            SliderModel::destroy($id);
        }
        return redirect()->back();
    }

}
