<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('home', function(){
	return redirect()->to(asset('Admin/banner'));
});

Route::get('colaboraciones', function(){
	return View('rapsodia.colaboraciones');
});


Route::get('terminos', function(){
	return View('rapsodia.terminos');
});


Route::get('politicasprivacidad', function(){
	return View('rapsodia.politicasprivacidad');
});




Route::controllers([
	'auth' => 'Auth\AuthController',
	'password' => 'Auth\PasswordController',
]);




Route::group(['prefix' => 'Admin'], function(){
	//POST
	Route::get('posts', 'HomeController@getPosts');
	Route::match(['get', 'post'], 'post/{idMenu}/{idKid?}', 'HomeController@getPost');
	Route::match(['get'], 'newpost/{idMenu}/{idKid?}', 'HomeController@getNewPost');
	Route::match(['get', 'post'], 'postform/{idPost}', 'HomeController@getPostForm');
	Route::get( 'addToPost/{id}', 'HomeController@getAddToPost');
	Route::post('addToPost', 'HomeController@postAddToPost');
	Route::post('removeToPost', 'HomeController@postRemoveToPost');
	Route::get( 'deleteoneone/{id}', 'HomeController@getDeleteoneone');
	Route::get( 'postdelet/{id}', function($id){
		$model = \App\PostModel::find($id);
		$newModel = \App\PostModel::where("menu_id", $model->menu_id)->where("menu_kids_id", $model->menu_kids_id)->where("history", 1)->orderBy("id", "desc")->first();
		if($newModel != null){
			$newModel->history = null; // null, false not working :c
			$newModel->save();
		}
		\App\PostModel::destroy($id);
		return redirect()->back();
	});




	//Slider
	Route::get('banner', 'SliderController@getBanner');
	Route::get('deleteSlider/{id?}', 'SliderController@deleteSlider');
	Route::post('newImageSlider', 'SliderController@newImageSlider');

	//Galeria
	Route::get('galeria', 'GalleryController@getBanner');
	Route::get('deleteGarelia/{id?}', 'GalleryController@deleteSlider');
	Route::post('newGallery', 'GalleryController@newImageSlider');
	//Marketing
	Route::get('publicidad', 'MarketingController@getBanner');
	Route::get('deletepublicidad/{id?}', 'MarketingController@deleteMarketingModel');
	Route::post('newImagepublicidad', 'MarketingController@newImageMarketingModel');
	Route::match(['get','post'], 'modificarpublicidad/{id}', 'MarketingController@updateMarketingSection');

	//AUTORES
	Route::get('autores', 'AuthorsController@getAuthors');
	Route::get('borrarautor', 'AuthorsController@getRemoveAuthor');
	Route::match(['get', 'post'], 'crearautor', 'AuthorsController@getCreateUpdateAuthor');
	Route::match(['get', 'post'], 'actualizarautor/{id}', 'AuthorsController@getCreateUpdateAuthor');
	//Usuarios
	Route::get('usuarios', 'UsersController@getUsers');
	Route::get('borrarusuarior', 'UsersController@getRemoveUser');
	Route::match(['get', 'post'], 'crearusuario', 'UsersController@getCreateUpdateUser');
	Route::match(['get', 'post'], 'actualizarusuario/{id}', 'UsersController@getCreateUpdateUser');


	//Contenido Página
	Route::match(['get', 'post'],'contenido', 'PageContentController@index');
	Route::match(['get', 'post'],'cabeceras', 'PageContentController@cabeceras');
	Route::match(['get', 'post'],'terminos', 'PageContentController@terms');
	Route::match(['get', 'post'],'politicas', 'PageContentController@policies');
	Route::match(['get', 'post'],'parallax', 'PageContentController@parallax');

	//COLABORADORES
	Route::match(['get', 'post'],'colaboraciones', 'PageContentController@colaboraciones');
	Route::match(['get', 'post'],'EliminarColaborador/{id}', function($id){
		\App\StandModel::destroy($id);
		return redirect()->back();
	});


	

});


Route::get('/', 'WelcomeController@index');
Route::post('contactoforms', 'WelcomeController@contactoform');
Route::get('historial', 'WelcomeController@getHistory');
Route::get('historial/{section?}/{sub?}', 'WelcomeController@getHistory');
Route::get('contacto', 'WelcomeController@getContact');

foreach(App\MenuModel::all() as $menu) {
	if($menu->url != "/" && $menu->name != "CONTACTO") {
		Route::get($menu->url, 'WelcomeController@getPost');
		if (count($menu->kids) > 0) {
			foreach ($menu->kids as $kid) {
				Route::get($kid->url, 'WelcomeController@getPost');
			}
		}
	}
}


foreach(App\MenuModel::all() as $menu) {
	if($menu->url != "/" && $menu->name != "CONTACTO") {
		Route::get($menu->url. '/{id?}', 'WelcomeController@getPost');
		if (count($menu->kids) > 0) {
			foreach ($menu->kids as $kid) {
				Route::get($kid->url. '/{id?}', 'WelcomeController@getPost');
			}
		}
	}
}
