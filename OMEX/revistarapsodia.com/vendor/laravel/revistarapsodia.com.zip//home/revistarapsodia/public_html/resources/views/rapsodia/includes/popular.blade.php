<div class="block block-views tn-single-related-wrap" >
    <div class="single-related-title block-title-wrap">
        <h3>POPULARES</h3>
    </div>
    <!--#related title-->
    <div class="tn-block-content-wrap tn-single-related-content row">
        <div class="tn-block-content-inner clearfix">
            <?php $postsRandom = \App\PostModel::orderBy("counter", 'desc')->get(); ?>

                @for($i = 0; $i < 5; $i++)
                    @if(count($postsRandom) > $i)
                        <div class="related-content-element col-md-12">
                            <div class="tn-module-related-wrap tn-module-wrap tn-category-7 clearfix">
                                <div class="tn-module-related-inner">                                       
                                    <h3 itemprop="name" class="tn-module-title">
                                        <a itemprop="url" href="{{ asset(($postsRandom[$i]->menu->url == "#") ? $postsRandom[$i]->kid->url : $postsRandom[$i]->menu->url) }}/{{ $postsRandom[$i]->id }}" rel="bookmark" title="{{  $postsRandom[$i]->title }}">
                                            <b style="float:left; border: 1px solid black; padding: 10px; width: 30px; font-size: 13px;">{{ $i+1 }}</b>
                                            <b style="float:left; border: 1px solid transparent; padding: 10px; width: 10px; font-size: 13px;">&nbsp;</b>
                                            {{  $postsRandom[$i]->title }} </a>
                                        </h3>
                                    <div class="tn-module-related-meta-tags tn-tags-date-author"><span class="meta-tags-date">
                                        <time itemprop="dateCreated">
                                            &nbsp;&nbsp;&nbsp;{{ date('d/m/Y', strtotime($postsRandom[$i]->created_at)) }}
                                       </time>
                                    </div>

                                </div>
                            </div>
                        </div>
                    @endif
                @endfor

        </div>
    </div>
</div>