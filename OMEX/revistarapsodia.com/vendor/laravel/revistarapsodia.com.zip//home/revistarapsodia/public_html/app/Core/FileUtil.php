<?php
/**
 * Created by PhpStorm.
 * User: RazzFox
 * Date: 26/10/15
 * Time: 9:45
 */
namespace App\Core;

use Illuminate\Http\Request;
use Intervention\Image\ImageManager;
use League\Flysystem\Exception;


class FileUtil {

    /**
     * @var Request
     */

    public function __construct(){
    }



    /**
     * @param $file
     * @return array|bool|string
     */
    public function uploadIndexImage($file, $folder){

            try {

                if (
                    $file->getClientOriginalExtension() != 'jpg' &&
                    $file->getClientOriginalExtension() != 'jpeg' &&
                    $file->getClientOriginalExtension() != 'gif' &&
                    $file->getClientOriginalExtension() != 'png' &&
                    $file->getClientOriginalExtension() != 'bmp'
                ) {
                    return array(
                        'success' => false,
                        'msg' => 'El formato del archivo es incorrecto'
                    );
                }


                $newFolder = str_random(10);
                $pathRelative = storage_path();
                $path = $pathRelative . '/app/'.$folder. '/'.$newFolder;
                if (\File::exists($path)) {
                    \File::deleteDirectory($path);
                }
                \File::makeDirectory($path, 0775, true);


                //$nombre = $file->getClientOriginalName();
                $name = $newFolder.'/'.str_random(10).'.'.$file->getClientOriginalExtension();
                \Storage::disk('local')->put($folder.'/'.$name,  \File::get($file));
                return $name;
            }catch (Exception $e){
                return array(
                    'success' => false,
                    'msg' => 'Error al procesar informacion',
                    'Exception' => $e
                );
            }

    }

    public function deleteFolder($folder)
    {
        $pathRelative = storage_path();
        $path = $pathRelative . '/app/'.$folder;
        if (\File::exists($path)) {
            \File::deleteDirectory($path);
        }
    }

    public function newCatalogFile($file, $folder, $fileName){
        try {

            if (
                $file->getClientOriginalExtension() != 'pdf' &&
                $file->getClientOriginalExtension() != 'xls' &&
                $file->getClientOriginalExtension() != 'xlsx' &&
                $file->getClientOriginalExtension() != 'docx' &&
                $file->getClientOriginalExtension() != 'doc'

            ) {
                return array(
                    'success' => false,
                    'msg' => 'El formato del archivo es incorrecto'
                );
            }


            $pathRelative = storage_path();
            $path = $pathRelative . '/app/'.$folder;
            /*if (\File::exists($path)) {
                \File::deleteDirectory($path);
            }
            \File::makeDirectory($path, 0775, true);
            */
            $name = $fileName . '.' . $file->getClientOriginalExtension();
            \Storage::disk('local')->put($folder.'/'.$name,  \File::get($file));

        }catch (Exception $e){
            return array(
                'success' => false,
                'msg' => 'Error al procesar informacion',
                'Exception' => $e
            );
        }
        return true;
    }

}