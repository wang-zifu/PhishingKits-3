<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class TypeInsertPostSeeder extends Seeder {

	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
		$type = array(
				array('name' => 'Titulo', 'type' => 'string'),
				array('name' => 'Texto', 'type' => 'text'),
				array('name' => 'Multimedia', 'type' => 'url'),
				array('name' => 'Imagen', 'type' => 'file')
			);

		foreach($type as $t){
			DB::table('type_insert_post_models')->insert($t);
		}


	}

}
