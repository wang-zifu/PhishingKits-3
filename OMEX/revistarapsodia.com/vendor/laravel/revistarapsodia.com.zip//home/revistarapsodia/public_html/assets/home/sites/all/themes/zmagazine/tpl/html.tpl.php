<!doctype html >

<!--[if lt IE 7]>

<html class="no-js ie6 oldie" lang="en"> <![endif]-->

<!--[if IE 7]>

<html class="no-js ie7 oldie" lang="en"> <![endif]-->

<!--[if IE 8]>

<html class="no-js ie8 oldie" lang="en"> <![endif]-->

<!--[if IE 9]>

<html class="no-js ie9 oldie" lang="en"> <![endif]-->

<!--[if gt IE 8]><!-->

<html lang="<?php print $language->language; ?>">

<!--<![endif]-->

<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<title><?php print $head_title; ?></title>



<?php print $styles; print $head; ?>


<?php
    //Tracking code
    $tracking_code = theme_get_setting('general_setting_tracking_code', 'zmagazine');
    print $tracking_code;
    //Custom css
    $custom_css = theme_get_setting('custom_css', 'zmagazine');
    if(!empty($custom_css)):?>
    <style type="text/css" media="all">
    <?php print $custom_css;?>
    </style>
    <?php endif;?>


</head>

<!-- #head site-->

<body class="<?php print $classes;?>" <?php print $attributes;?>>

<div id="skip-link">

    <a href="#main-content" class="element-invisible element-focusable"><?php print t('Skip to main content'); ?></a>

</div>

<div id="tn-main-site-wrap" class="clearfix"><!--start main site wrap -->

	

	<div id="tn-main-mobile-menu" class="tn-main-mobile-menu-wrap"> <a href="#" id="tn-close-mobile-menu"><?php print t('close'); ?></a><!--#mobile close button -->

		<?php if($mobile_menu): ?>

			<?php print render($mobile_menu); ?>

		<?php endif; ?>

	</div>

	<!--#mobile menu wrap-->

	

	<div id="tn-main-container"> 

		

		<?php print $page_top; ?><?php print $page; ?><?php print $page_bottom; ?>

		

	</div>

	<!--#tn-main-container --> 

</div>





<?php print $scripts; ?>

<?php if($left_box): ?>
	<?php print render($left_box); ?>
<?php endif; ?>



</body>

</html>