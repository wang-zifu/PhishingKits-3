<?php namespace App\Http\Controllers;

use App\PageContentModel;
use App\Core\FileUtil;
use App\StandModel;


class PageContentController extends Controller {

    /*
    |--------------------------------------------------------------------------
    | Home Controller
    |--------------------------------------------------------------------------
    |
    | This controller renders your application's "dashboard" for users that
    | are authenticated. Of course, you are free to change or remove the
    | controller as you wish. It is just here to get your app started!
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function  index(){

        if(\Request::isMethod('post'))
        {
            for($i = 1; $i < 9; $i++) {
                $CP = PageContentModel::where('id', $i)->first();
                $CP->value = \Input::get($i);
                $CP->save();
            }

            $i = 17;
            $CP = PageContentModel::where('id', $i)->first();
            $CP->value = \Input::get($i);
            $CP->save();


            $i = 18;
            $CP = PageContentModel::where('id', $i)->first();
            $CP->value = \Input::get($i);
            $CP->save();


            return redirect()->back();

        }



        return view('admin.pageContent.index')
            ->with('ContentPage', PageContentModel::where("section", 1)->get());
    }


    public function policies(){

        if(\Request::isMethod('post'))
        {
            $CP = PageContentModel::where('id', 9)->first();
            $CP->value = \Input::get(9);
            $CP->save();
            return redirect()->back();
        }



        return view('admin.pageContent.policies')
            ->with('ContentPage', PageContentModel::find(9));
    }


    public function terms(){

        if(\Request::isMethod('post'))
        {
            $CP = PageContentModel::where('id', 10)->first();
            $CP->value = \Input::get(10);
            $CP->save();
            return redirect()->back();
        }



        return view('admin.pageContent.policies')
            ->with('ContentPage', PageContentModel::find(10));
    }


      public function parallax(FileUtil $fileUtil){

        
        if(\Request::isMethod('post'))
        {
            for($i = 11; $i < 15; $i++) {
                $CP = PageContentModel::where('id', $i)->first();
                if($i == 13){
                    $file = \Input::file($i);
                    if($file != null){
                        $folder = 'parallax';
                        $name = $fileUtil->uploadIndexImage($file, $folder);
                        $CP->value = $name;
                    }
                }else{
                    $CP->value = \Input::get($i);
                }
                $CP->save();
            }


            return redirect()->back();

        }



        return view('admin.pageContent.parallax')
            ->with('ContentPage', PageContentModel::where("section", 3)->get());

        }


         public function cabeceras(FileUtil $fileUtil){

        
        if(\Request::isMethod('post'))
        {
            for($i = 15; $i < 17; $i++) {
                $CP = PageContentModel::where('id', $i)->first();
                $file = \Input::file($i);
                if($file != null){
                    $folder = 'cabeceras';
                    $name = $fileUtil->uploadIndexImage($file, $folder);
                    $CP->value = $name;
                }
                $CP->save();
            }


            return redirect()->back();

        }



        return view('admin.pageContent.cabeceras')
            ->with('ContentPage', PageContentModel::where("section", 4)->get());

        }


    public function colaboraciones(){

        if(\Request::isMethod('post'))
        {
            $StandModel = StandModel::find(\Input::get('id'));

            if($StandModel == null)
                $StandModel = new StandModel;

            $StandModel->name = \Input::get('name');
            $StandModel->ocupation = \Input::get('ocupation');
            $StandModel->save();
            
            return redirect()->back();
        }



        return view('admin.pageContent.colaboraciones')
             ->with('ContentPage', StandModel::all());
    }



        



    


}
