@extends('master.home')
@section('content')
    <?php $posts = \App\PostModel::where('history', false)->get();  ?>

    <div class="block block-views tn-section-full-width-wrap clearfix" >
        @include('includes.banner')
    </div>
    <div  class="tn-block8-wrap tn-block-wrap clearfix">
        <div class="tn-container">
            <div class="tn-block8-title block-title-wrap">
                <h3><a class="block-title cate-7" href="#" title="Sonido Local">Sonido Local</a></h3>
            </div>
            <!--#block header wrap -->
            <div class="tn-block8-content-wrap tn-block-content-wrap">
                <div class="tn-block8-content-inner tn-block-content-inner">
                    <div class="row clearfix">
                        @foreach($posts as $post)
                            @if($post->menu->id == 4 && $post->content->text_1 != null)

                            <div class="tn-block8-element col-sm-4 col-sx-12">
                                <div class="tn-module2-wrap tn-module-wrap clearfix" itemscope itemtype="http://schema.org/Article">
                                    <div class="tn-module2-inner">
                                        <div class="tn-thumb-wrap">
                                            <img width="370" height="280" itemprop="image" src="{{ asset('storage/app/post'.$post->id. '/' . $post->content->url_image) }}" class="attachment-module1_thumb" alt="{{ $post->title }}" />
                                            <a  href="{{ asset($post->kid->url) }}" title="{{ $post->title }}"rel="bookmark"></a>
                                            <span class="tn-post-format"><i class="fa fa-camera"></i></span>
                                            <!--div class="tn-meta-thumb-views tn-meta-counter-wrap">
                                                <div class="tn-counter-num">597</div>
                                                <div class="tn-counter-content">Views</div>
                                            </div-->
                                        </div>
                                        <div class="tn-module-meta-tags">
                                            <div class="tn-category-tags-wrap">
                                                <a href="#" typeof="skos:Concept" property="rdfs:label skos:prefLabel" datatype="">{{ $post->kid->name }}</a>
                                            </div>
                                            <div class="tn-module-meta tn-tags-date-author"><span class="meta-tags-date">
                                  <time itemprop="dateCreated">{{ $post->created_at }}</time>
                                  </span>
                                                <span class="meta-tags-author">Por:
                                                    <span class="username" xml:lang="" about="#" typeof="sioc:UserAccount" property="foaf:name" datatype="">
                                                        {{ $post->author->name }}
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                        <h3 itemprop="name" class="tn-module-title">
                                            <a itemprop="url" href="#" rel="bookmark" title="{{ $post->title }}">{{ $post->title }}</a>
                                        </h3>
                                        <div class="tn-module-excerpt">
                                            {!!  substr($post->content->text_1, 0, 250) !!}...
                                        </div>
                                        <div class="tn-read-more-wrap">
                                            <a class="tn-read-more" href="{{ asset($post->kid->url) }}" title="{{ $post->title }}" rel="bookmark">Leer más</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endif
                        @endforeach
                    </div>
                    <!--#row fluid-->
                </div>
            </div>
            <!--#block content wrap-->
        </div>
        <!--tn container-->
    </div>
    <!--#end block-->






    <!-- INVESTIGACIÓN -->

    <div class="block block-views tn-section-full-width-wrap clearfix" >

        <div  class="tn-block9-wrap tn-block-wrap clearfix">
            <div class="tn-container tn-black-style">
                <div class="tn-black-style-inner">
                    <div class="tn-block9-title block-title-wrap">
                        <h3><a class="block-title" href="#" title="Music">INVESTIGACIÓN</a></h3>
                    </div>
                    <!--#block header wrap -->
                    <div class="tn-block9-content-wrap tn-block-content-wrap">
                        <div class="tn-block9-content-inner tn-block-content-inner">
                            <div class="row clearfix">
                                @foreach($posts as $post)
                                    @if($post->menu->id == 2 && $post->content->text_1 != null)
                                         <div class="tn-block9-element col-sm-4 col-sx-12">
                                    <div class="tn-module3-wrap tn-module-wrap clearfix" itemscope itemtype="http://schema.org/Article">
                                        <div class="tn-module3-inner">
                                            <div class="tn-module3-thumb">
                                                <div class="tn-thumb-wrap">
                                                    <img width="370" height="280" itemprop="image" src="{{ asset('storage/app/post'.$post->id. '/' . $post->content->url_image) }}" class="attachment-module1_thumb" alt="{{ $post->title }}" />
                                                    <a href="{{ $post->kid->url }}" title="Traveling Through Winter Spring Flower Seasons" rel="bookmark"></a>
                                                    <!--div class="tn-meta-thumb-views tn-meta-counter-wrap">
                                                        <div class="tn-counter-num">677</div>
                                                        <div class="tn-counter-content">Views</div>
                                                    </div-->
                                                </div>
                                                <div class="tn-read-more-wrap"><a class="tn-read-more" href="#" title="Traveling Through Winter Spring Flower Seasons" rel="bookmark">LEER MÁS</a></div>
                                            </div>
                                            <div class="tn-module3-meta-tags">
                                                <div class="tn-category-tags-wrap">
                                                    <a href="#" typeof="skos:Concept" property="rdfs:label skos:prefLabel" datatype="">{{ $post->kid->name }}</a>
                                                </div>
                                                <div class="tn-module3-meta-right tn-tags-date-author">
                                                            <span class="meta-tags-date">
                                                            <time itemprop="dateCreated">{{ date('d/m/Y', strtotime($post->created_at)) }}</time>
                                                            </span>
                                                    <span class="meta-tags-author">Por:
                                                        <span class="username" xml:lang="" about="#" typeof="sioc:UserAccount" property="foaf:name" datatype="">
                                                            {{ $post->author->name }}
                                                        </span>
                                                    </span>
                                                </div>
                                            </div>
                                            <h3 itemprop="name" class="tn-module-title">
                                                <a itemprop="{{ $post->kid->url }}" href="{{ $post->kid->url }}" rel="bookmark" title="">
                                                    {{ $post->title }}
                                                </a>
                                            </h3>
                                        </div>
                                    </div>
                                </div>
                                    @endif
                                 @endforeach
                            </div>
                            <!--#row fluid-->
                        </div>
                    </div>
                    <!--#block content wrap-->
                </div>
                <!--black style inner-->
            </div>
            <!--#end block-->
        </div>
    </div>




    <!-- MAAAAAAS -->
    <div class="tn-container tn-section-content-wrap row clearfix">
        <div class="block block-views tn-content-wrap col-sm-8 col-xs-12" >
            <div class="tn-block4-wrap tn-block-wrap clearfix">
                <div class="tn-block4-title block-title-wrap">
                    <h3>MÁS</h3>
                    <!--div-- class="tn-sub-cate-wrap">
                        <ul class="tn-sub-cate-inner">
                            <li class="tn-sub-cate-element"><a href="/demo/drupal/fmagazine/blog-categories/beauty">Beauty</a></li>
                            <li class="tn-sub-cate-element"><a href="/demo/drupal/fmagazine/blog-categories/fashion">Fashion</a></li>
                            <li class="tn-sub-cate-element"><a href="/demo/drupal/fmagazine/blog-categories/lifestyle">Lifestyle</a></li>
                            <li class="tn-sub-cate-element"><a href="/demo/drupal/fmagazine/blog-categories/music">Music</a></li>
                            <li class="tn-sub-cate-element"><a href="/demo/drupal/fmagazine/blog-categories/recipe">Recipe</a></li>
                        </ul>
                    </div-->
                </div>
                <!--#block header wrap -->
                <div class="tn-block4-content-wrap tn-block-content-wrap">
                    <div class="tn-block4-content-inner tn-block-content-inner">
                        @if(count($posts) > 0)
                        @foreach($posts as $post)
                            <!--if(($post->menu->id == 6 || $post->menu->id == 7) && $post->content->text_1 != null)-->
                                  <div class="tn-module1-wrap tn-module-wrap clearfix">
                            <div class="tn-module1-inner">
                                <div class="tn-module-section module1-section-left col-md-2 hidden-sm hidden-xs">
                                    <div class="tn-tags-date-author">
                                                   <span class="meta-tags-date">
                                                   <time itemprop="dateCreated">{{ date('d/m/Y', strtotime($post->createad_at)) }}</time>
                                                   </span>
                                    </div>
                                    <div class="tn-category-tags-wrap">
                                        <a href="{{ asset(($post->menu->url == "#") ? $post->kid->url : $post->menu->url) }}" typeof="skos:Concept" property="rdfs:label skos:prefLabel" datatype="">
                                            {{ ($post->menu->url == "#") ?  $post->kid->name : $post->menu->name }}
                                        </a>
                                    </div>
                                    <div class="tn-tags-date-author">
                                        <span class="meta-tags-author">Por:
                                            <span class="username" xml:lang="" about="" typeof="sioc:UserAccount" property="foaf:name" datatype="">
                                                {{ $post->author->name }}
                                            </span>
                                        </span>
                                    </div>
                                </div>
                                <div class="tn-module-section module1-section-center col-md-5 col-sm-6 col-xs-3">
                                    <div class="tn-thumb-wrap">
                                        <img width="370" height="280" itemprop="image" src="{{ asset('storage/app/post'.$post->id. '/' . $post->content->url_image) }}" class="attachment-module1_thumb" alt="{{ $post->title }}" />
                                        <a href="{{ asset(($post->menu->url == "#") ? $post->kid->url : $post->menu->url) }}" title="{{ $post->title }}" rel="bookmark"></a>
                                        <!--div class="tn-meta-thumb-views tn-meta-counter-wrap">
                                            <div class="tn-counter-num">677</div>
                                            <div class="tn-counter-content">Views</div>
                                        </div-->
                                    </div>
                                </div>
                                <div class="tn-module-section module1-section-right col-md-5 col-sm-6 col-xs-9">
                                    <h3 itemprop="name" class="tn-module-title">
                                        <a itemprop="url" href="{{ asset(($post->menu->url == "#") ? $post->kid->url : $post->menu->url) }}" rel="bookmark" title="{{ $post->title }}">{{ $post->title }}</a></h3>
                                    <div class="tn-module-excerpt">
                                        {!!  substr($post->content->text_1, 0, 250) !!}...
                                    </div>
                                    <div class="tn-read-more-wrap">
                                        <a class="tn-read-more" href="{{ asset(($post->menu->url == "#") ? $post->kid->url : $post->menu->url) }}" title="{{ $post->title }}" rel="bookmark">
                                            Leer más
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endforeach
                        @endif
                    </div>
                </div>
                <!--#block content wrap-->
                <div class="tn-load-more-wrap clearfix">
                    <span class="tn-load-more-liner"></span><!--#loadmore liner -->
                    <div class="tn-load-more-inner">
                        <a href="{{ asset("historial") }}"  class="tn-ajax-load-more" id="load-more-c2a61518-833e-49c7-86cc-c13fcd8f3265">
                            Cargar más
                        </a>
                    </div>
                </div>
                <!--#load more wrap-->
            </div>
        </div>
        <!--#content of section content-->
        <div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary" itemscope="itemscope">
            <div class="tn-sidebar-sticky">
                <aside class="block block-views widget block-post-widget" >
                    <div class="tn-block-post-wrap tn-block-wrap clearfix">
                        <div class="tn-block-post-title block-title-wrap">
                            <h3>EDITORIAL & COLABORACIONES</h3>
                        </div>
                        <!--#block header wrap -->
                        <div class="tn-block-post-content-wrap tn-block-content-wrap">
                            <div class="tn-block-post-content-inner tn-block-content-inner">
                                <div class="tn-module-small-wrap tn-module-wrap  clearfix" itemscope itemtype="http://schema.org/Article">
                                    La música es un mundo maravilloso de grandes satisfacciones y muy emocionante. Sin embargo, es una disciplina que requiere de un gran esfuerzo y un poco más que eso… Nuestra ciudad es cuna de grandes artistas, escénicos, músicos, escultores, pintores y tantos que forman parte de las bellas artes y que al final, sin importar a que rama te dediques, somos un solo hilo para transmitir lo más bello y grandes emociones al mundo. Lo mismo ocurre con la música, rock, jazz, música académica, boleros, latino, blues, folclórica, regional, soul, reggae, experimental, no importa! Al final, somos parte de un mismo centro.
                                    <div class="tn-read-more-wrap"><a class="tn-read-more" href="#" title="Leer más" rel="bookmark">LEER MÁS</a></div>
                                </div>
                                 @include('rapsodia.includes.hearitsecction')
                            </div>
                        </div>
                        <!--#block content wrap-->
                    </div>
                </aside>
                <aside class="block block-widget widget widget-twitter" >
                    <div class="widget-title">
                        <h3>&nbsp;</h3>
                    </div>

                    <div id="owl-example" class="owl-carousel">
                        @foreach(\App\MarketingModel::all() as $slider)
                        <div>
                            <img src="{{ asset('storage/app/marketing/'.$slider->img) }}" alt="{{ $slider->img }}" style="max-width: 100%;  display: block;  ">
                        </div>
                        @endforeach


                    </div>


                </aside>
            </div>
        </div>
        <!--#close sidebar -->
    </div>


    <!-- PARALLAX -->
    <div class="block block-block tn-section-full-width-wrap clearfix" >
        <div id="11bed708-d4fd-40f9-8915-9054428e46ed" class="tn-block-img-wrap tn-block-wrap clearfix">
            <div class="tn-block-img-content-wrap tn-block-content-wrap">
                <div class="tn-block-img-content-inner tn-block-content-inner">
                    <div class="tn-block-parallax-wrap">
                        <div id="tn-block-image-parallax" data-background-image="http://rapsodia.rx.app/storage/app/post4/Zhtj2DWUCr/x23ytHluzd.jpg"></div>
                    </div>
                    <div class="tn-block-image-content-wrap">
                        <div class="tn-block-image-title">
                            <h3>EN ENTREVISTA</h3>
                        </div>
                        <!--#title -->
                        <div class="tn-block-image-content">
                            <p>Músico, compositor y productor musical argentino.</p>
                        </div>
                        <!--#content -->
                        <div class="tn-block-image-read-more-wrap"><a class="tn-block-image-read-more tn-read-more"  href="http://google.com" title="Parallax image" rel="bookmark" target="_blank">LEER MÁS</a></div>
                        <!--#readmore wrap -->
                    </div>
                    <!--#content wrap-->
                </div>
            </div>
            <!--#block content wrap-->
        </div>
    </div>



@endsection

@section('scripts')
        <!-- Include js plugin -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.js"></script>
    <script>
        jQuery(function(){
            jQuery("#owl-example").owlCarousel({
                navigation : true, // Show next and prev buttons
                slideSpeed : 300,
                paginationSpeed : 400,
                singleItem : true,
                autoPlay : true,
                stopOnHover : true,
                pagination : false,
                navigation : false

            });
        });
    </script>
@endsection


@section('css')
        <!-- Important Owl stylesheet -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.css">

    <!-- Default Theme -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.css">


@endsection
