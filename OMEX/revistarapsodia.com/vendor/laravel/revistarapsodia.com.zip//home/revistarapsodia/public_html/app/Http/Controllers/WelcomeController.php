<?php namespace App\Http\Controllers;

use App\MarketingInSecctionModel;
use App\MarketingModel;
use App\MenuKidsModel;
use App\MenuModel;
use App\PostModel;
use App\SliderModel;

class WelcomeController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Welcome Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders the "marketing page" for the application and
	| is configured to only allow guests. Like most of the other sample
	| controllers, you are free to modify or remove it as you desire.
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
	}

	/**
	 * Show the application welcome screen to the user.
	 *
	 * @return Response
	 */
	public function index()
	{
		return view('rapsodia.home')
			->with('sliders', SliderModel::all());
	}

	/**
	 * Show the application welcome screen to the user.
	 *
	 * @return Response
	 */
	public function getPost($id = null)
	{

		$view = "";
		if($id == null) {
			$stringMenu = (str_replace('/', '', \Request::server('REQUEST_URI')));
			$section = MenuModel::where('url', $stringMenu)->first();
			if ($section == null)
				$section = MenuKidsModel::where('url', $stringMenu)->first();

			if ($section->menu_id != null) {
				$PostModel = PostModel::where('menu_id', $section->menu_id)->where('menu_kids_id', $section->id)
					->where('history', false)->first();
				$marketing = $this->getMarketingUrl($section->menu_id, $section->id);
			} else {
				$PostModel = PostModel::where('menu_id', $section->id)
					->where('history', false)->first();
				$marketing = $this->getMarketingUrl($section->menu_id, null);
			}
		}else{
			$stringMenu = explode('/', \Request::server('REQUEST_URI'))[1];
			$PostModel = PostModel::find($id);
			$section = MenuModel::where('url', $stringMenu)->first();
			if ($section == null)
				$section = MenuKidsModel::where('url', $stringMenu)->first();

			if ($section->menu_id != null) {
				$marketing = $this->getMarketingUrl($section->menu_id, $section->id);
			} else {
				$marketing = $this->getMarketingUrl($section->menu_id, null);
			}

		}


		if($PostModel->template_id == 1){
			$view = 'rapsodia.post1';
		}

		if($PostModel->template_id == 2){
			$view = 'rapsodia.post2';
		}


		if($PostModel->template_id == 3){
			$view = 'rapsodia.post3';
		}

		if($PostModel->template_id == 4){
			$view = 'rapsodia.post4';
		}

		if($PostModel->template_id == 5){
			$view = 'rapsodia.post5';
		}

		if($view == "")
			abort(404);

		if($PostModel->counter == null){
			$PostModel->counter = 1;
		}else{
			$PostModel->counter++;
		}

		$PostModel->save();

		return view($view)
			->with('post', $PostModel)
			->with('section', $section)
			->with('marketing', $marketing);
	}


	private function getMarketingUrl($menuId, $kidId = 0){

		$url = null;
		$marketingToShow = null;

		foreach(MarketingInSecctionModel::where('menu_id', $menuId)->where("kid_id", $kidId)->get() as $m){
			$marketingToShow[$m->marketing_id] = $m->marketing_id;
		}

		if(count($marketingToShow)>0) {
			$idModel = array_rand($marketingToShow);
			$m = MarketingModel::find($idModel);
			if($m != null)
			$url = asset('storage/app/marketing/'. $m->img);
		}



		return $url;
	}


	public function getHistory($section = 2, $sub = 1){

		$PostModel = PostModel::where('menu_id', $section)
				->where('menu_kids_id', $sub)
				->orderBy('created_at', 'desc')
			//	->where('history', true)
			->get();


		return view('rapsodia.history')
			->with('posts', $PostModel);
	}

	public function getContact(){
		return view('rapsodia.contact');
	}

	public function contactoform (){
		// Varios destinatarios
		$para  = 'contacto@revistarapsodia.com';

		// título
		$título = 'Formulario enviado desde Rapsodia';

		// mensaje
		$mensaje = '
		<html>
		<head>
		  <title>Formulario enviado desde Rapsodia</title>
		</head>
		<body>
		  <p>Formulario enviado desde Rapsodia</p>
		  <table>
		    
		    <tr>
		      <td>Nombre</td>
		      <td>' .\Input::get('name'). '</td>
		    </tr>

		    <tr>
		      <td>Email</td>
		      <td>' .\Input::get('email'). '</td>
		    </tr>

		    <tr>
		      <td>Descripción</td>
		      <td>' .\Input::get('message'). '</td>
		    </tr>

		  </table>
		</body>
		</html>
		';

		// Para enviar un correo HTML, debe establecerse la cabecera Content-type
		$cabeceras  = 'MIME-Version: 1.0' . "\r\n";
		$cabeceras .= 'Content-type: text/html; charset=utf-8' . "\r\n";

		// Cabeceras adicionales
		$cabeceras .= 'To: Contacto <contacto@revistarapsodia.com>' . "\r\n";
		$cabeceras .= 'From: Revistarapsodia <contacto@revistarapsodia.com>' . "\r\n";

		// Enviarlo
		mail($para, $título, $mensaje, $cabeceras);

		return \Response::json('true');
	}

}
