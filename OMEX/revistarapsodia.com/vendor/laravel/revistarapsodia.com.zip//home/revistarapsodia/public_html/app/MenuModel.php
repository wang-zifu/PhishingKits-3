<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class MenuModel extends Model {

	//

    public function kids(){
        return $this->hasMany('App\MenuKidsModel', 'menu_id', 'id');
    }

    public function kid(){
        return $this->hasOne('App\MenuKidsModel', 'menu_id', 'id');
    }

}
