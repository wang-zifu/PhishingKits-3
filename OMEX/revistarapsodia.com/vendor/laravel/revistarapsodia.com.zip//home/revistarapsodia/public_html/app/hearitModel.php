<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class hearitModel extends Model {

	//

}
