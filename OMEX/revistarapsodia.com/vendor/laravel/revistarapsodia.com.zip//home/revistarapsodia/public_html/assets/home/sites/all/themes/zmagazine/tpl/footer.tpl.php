<?php 
    $footer_social_networks = theme_get_setting('footer_social_networks', 'zmagazine');
    $copyright_text = theme_get_setting('copyright_text', 'zmagazine');
?>
<footer id="tn-footer" class="clearfix">
    <!-- Footer Ads -->
    <!--Sidebar Footer-->
    <div class="tn-container tn-sidebar-footer-wrap clearfix">
        <?php if($page['footer']): ?>
            <?php print render($page['footer']); ?>
        <?php endif; ?>
    </div>
    <!--#tn sidebar footer wrap-->
    <!-- Footer Copyright -->
    <div class="tn-copyright-wrap tn-copyright-center">
        <div class="tn-copyright-inner tn-container">
            <!--copy right -->            
            <?php if($page['footer_menu']): ?>
                <?php print render($page['footer_menu']); ?>
            <?php endif; ?>
            <!-- social icon -->
            <?php if($footer_social_networks): ?>
            <div class="copyright-social-wrap">
                <div class="tn-topbar-social-wrap">
                    <?php print $footer_social_networks; ?>
                </div>
                <!--#social bar --> 
            </div>
            <?php endif; ?>
            <?php if($copyright_text): ?>
            <!-- copyright text -->
            <div class="copyright">
                <?php print $copyright_text; ?>
            </div>
            <?php endif; ?>
        </div>
        <!--#tn copyright inner -->
    </div>
    <!--#tn copyright wrap -->
</footer>

