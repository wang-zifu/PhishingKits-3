
<?php
	global $user;
	$banner_image = theme_get_setting('blog_banner_image','zmagazine');
	if(!empty($banner_image)){
		$banner_image_url = file_create_url(file_load($banner_image)->uri);
	}
	$background_image = theme_get_setting('blog_background_image','zmagazine');
	if(!empty($background_image)){
		$background_image_url = file_create_url(file_load($background_image)->uri);
	}
	$blog_header_style = theme_get_setting('blog_header_style', 'zmagazine');
	if(empty($blog_header_style)){
		$blog_header_style = 'style1';
	}
	$banner_default = theme_get_setting('blog_banner_default', 'zmagazine');
   
	$header_social_networks = theme_get_setting('header_social_networks', 'zmagazine');
	$header_social_networks_more = theme_get_setting('header_social_networks_more', 'zmagazine');
	$mobile_logo = theme_get_setting('mobile_logo_image', 'zmagazine');
	if(isset($mobile_logo) && !empty($mobile_logo)){
		$mobile_logo_url = file_create_url(file_load($mobile_logo)->uri);
	}
	$default_logo = theme_get_setting('default_mobile_logo', 'zmagazine');
?>


<?php if(arg(0) != 'node'){ ?>
<?php if($blog_header_style == 'style1'){ ?>
<!-- Top Bar -->
<div id="tn-top-bar-wrap" class="clearfix">
	<div class="tn-container">
		<div class="tn-top-bar-inner row">
			<div class="tn-top-left-bar">
				<?php if($page['top_menu']): ?>
					<?php print render($page['top_menu']); ?>
				<?php endif; ?>
			</div>
			<!--#left top bar -->
			<?php if(!$user->uid){ ?>
			<div class="tn-top-right-bar">
				<div class="tn-logged-wrap topbar-right-element clearfix">
					<span class="tn-login-element"><a href="#" id="tn-login-popup" data-mfp-src="#tn-login-form-popup" data-effect="mpf-login-effect"><?php print t('log in'); ?><i class="fa fa-sign-in"></i></a></span>
					<div id="tn-login-form-popup" class="tn-form-popup-wrap mfp-hide mfp-animation">
						<div class="tn-login-tab-wrap">
							<ul class="tn-login-tab">
								<li class="tn-login-tab-element"><a href="#" id="tn-login-link"><?php print t('Log in'); ?></a></li>
							</ul>
						</div>
						<!--#login tab wrap-->
						<div class="tn-login-content-wrap">
							<div class="tn-login-inner tn-login-link">
								<?php if($page['user_login']): ?>
									<?php print render($page['user_login']); ?>
								<?php endif; ?>
							</div>
							<!--#login inner-->
							<div id="tn-forgot-pass-inner" class="tn-hide">
								<div class="forgot-pass-text"><?php print t('lost your password?'); ?></div>
								<?php if($page['forgot_password']): ?>
									<?php print render($page['forgot_password']); ?>
								<?php endif; ?>
							</div>
							<!--#forgot pass inner-->
						</div>
						<!--#login content wrap-->
					</div>
					<!--#login form popup-->
				</div>
				<!--#tn-logged-wrap--> 
			</div>
			<?php }else{?>
			<div class="tn-top-right-bar">
				<div class="tn-logged-wrap topbar-right-element clearfix">
					<span class="tn-login-element"><a href="<?php print base_path().'user/logout'; ?>" id="tn-logout"><?php print t('log out'); ?><i class="fa fa-sign-out"></i></a></span>
					</div>
				</div>
			</div>
			<?php } ?>
			<!--#right top bar-->
		</div>
		<!--#top bar inner -->
	</div>
	<!-- tn container -->
</div>
<!--#Top Bar wrap -->
<div class="tn-banner-wrap banner-background-image-style clearfix">
	<div class="tn-banner-parallax-wrap">
		<div data-background-image-header="<?php print $background_image_url; ?>" id="tn-banner-image-parallax"></div>
	</div>
	<!--#banner parallax wrap--><img src="<?php print $background_image_url; ?>" id="img-background-image-header" alt="" style="display:none;"/>
	<div class="logo-area-inner-parallax clearfix">
		<div class="tn-site-logo-wrap" role="banner" itemscope="itemscope"
         itemtype="http://schema.org/Organization"> <a itemprop="url" class="logo-image" href="<?php print base_path(); ?>"><?php if($banner_default == '1'){ ?><img class="logo-image-data" data-no-retina itemprop="image"
		src="<?php print base_path().path_to_theme(); ?>/images/logo1.png" alt="<?php print $site_name; ?>"><?php }elseif($banner_image){ ?><img class="logo-image-data" data-no-retina itemprop="image"
		src="<?php print $banner_image_url; ?>" alt="<?php print $site_name; ?>"><?php } ?> </a>
			<meta itemprop="name" content="Magazine">
		</div>
		<!-- #logo wrap --> 
	</div>
	<!--#logo area inner-->
</div>
<!--#banner wrap -->
<!--#banner wrap --> <!--#logo area -->
<div id="tn-main-menu-sticky" class="clearfix">
	<div class="tn-main-menu-wrap">
		<div class="tn-container">
			<div class="tn-main-menu-inner clearfix">
				<div class="tn-mobile-main-menu-button"> <a href="#" id="tn-button-mobile-menu-open"> <span class="tn-mobile-menu-button"></span> </a> </div>
				<!-- #mobile button -->
				
				<div class="tn-main-menu-responsive clearfix" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
					<div class="tn-mobile-site-title"> <a href="<?php print base_path(); ?>"><img data-no-retina src="<?php if($default_logo != '1' && isset($mobile_logo_url)){ print $mobile_logo_url;}else{ ?><?php print base_path().path_to_theme(); ?>/images/mobile-logo.png<?php } ?>" alt="<?php print $site_name; ?>"> </a> </div>
					<!--#mobile site -->

					<?php if($page['main_menu']): ?>
						<?php print render($page['main_menu']); ?>
					<?php endif; ?>

					<div class="tn-main-menu-right-area">
						<?php if(!empty($header_social_networks_more) || !empty($header_social_networks)): ?>
						<div class="tn-social-bar-wrap"><?php if(!empty($header_social_networks)) print $header_social_networks; ?>
							<?php if(!empty($header_social_networks_more)): ?>
							<div class="more-social-share">
								<div class="social-box-hidden-wrap"><?php print $header_social_networks_more; ?></div>
							</div>
							<?php endif; ?>
							<!--social box -->
						</div>
						<!--#social bar --> 
						<?php endif; ?>
					</div>
					<!--# main menu right area --> 
				</div>
				<!--#menu responsive --> 
			</div>
			<!--#menu inner --> 
		</div>
		<!--#tn container --> 
	</div>
	<!--#tn main-menu--> 
</div>
<?php if($breadcrumb): ?>
<div class="tn-breadcrumbs-wrap clearfix">

<div class="tn-breadcrumbs-inner tn-container"><?php print $breadcrumb; ?></div>
<!--#breadcrumbs --> 
</div>
<?php endif; ?>
<?php }elseif($blog_header_style == 'style2'){ ?>
<!-- Top Bar -->

<div class="tn-banner-wrap banner-background-image-style clearfix">
	<div class="tn-banner-parallax-wrap">
		<div data-background-image-header="<?php if(isset($background_image) && !empty($background_image)){ print $background_image_url; }?>" id="tn-banner-image-parallax"></div>
	</div>
	<!--#banner parallax wrap--><img src="<?php if(isset($background_image) && !empty($background_image)){ print $background_image_url; }?>" id="img-background-image-header" alt="<?php print $site_name; ?>" style="display:none;"/>
	<?php if(isset($banner_image) && !empty($banner_image)): ?>
	<div class="logo-area-inner-parallax clearfix">
		
		<div class="tn-site-logo-wrap" role="banner" itemscope="itemscope"
         itemtype="http://schema.org/Organization"> <a itemprop="url" class="logo-image" href="<?php print base_path(); ?>"> <img class="logo-image-data" data-no-retina itemprop="image"
                         src="<?php print $banner_image_url; ?>" alt="<?php print $site_name; ?>"> </a>
			<meta itemprop="name" content="<?php print $site_name; ?>">
		</div>
		<!-- #logo wrap --> 
	</div>
	<!--#logo area inner-->
	<?php endif; ?>
</div>
<!--#banner wrap --> <!--#logo area -->

<div id="tn-main-menu-sticky" class="clearfix">
	<div class="tn-main-menu-wrap">
		<div class="tn-container">
			<div class="tn-main-menu-inner clearfix">
				<div class="tn-mobile-main-menu-button"> <a href="#" id="tn-button-mobile-menu-open"> <span class="tn-mobile-menu-button"></span> </a> </div>
				<!-- #mobile button -->
				
				<div class="tn-main-menu-responsive tn-menu-center clearfix" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
					<div class="tn-mobile-site-title"> <a href="index_blog.html"> <img data-no-retina src="<?php if($default_logo != '1' && isset($mobile_logo_url)){ print $mobile_logo_url;}else{ ?><?php print base_path().path_to_theme(); ?>/images/mobile-logo.png<?php } ?>" alt="<?php print $site_name; ?>"> </a> </div>
					<!--#mobile site -->
					
					<?php if($page['main_menu']): ?>
						<?php print render($page['main_menu']); ?>
					<?php endif; ?>
				</div>
				<!--#menu responsive --> 
			</div>
			<!--#menu inner --> 
		</div>
		<!--#tn container --> 
	</div>
	<!--#tn main-menu--> 
</div>
<?php if($breadcrumb): ?>
<div class="tn-breadcrumbs-wrap clearfix">

<div class="tn-breadcrumbs-inner tn-container"><?php print $breadcrumb; ?></div>
<!--#breadcrumbs --> 
</div>
<?php endif; ?>
<!--#breadcrumbs wrap --> 
<!--#breadcrumbs wrap --> 
<?php }else{ ?>
<div id="tn-top-bar-wrap" class="clearfix">
	<div class="tn-container">
		<div class="tn-top-bar-inner row">
			<div class="tn-top-left-bar">
				<?php if($page['top_menu']): ?>
					<?php print render($page['top_menu']); ?>
				<?php endif; ?>
			</div>
			<!--#left top bar -->
			<?php if(!empty($header_social_networks)): ?>
			<div class="tn-top-right-bar">
				<div class="widget-social-content-wrap topbar-right-element">
					<div class="tn-topbar-social-wrap"><?php print $header_social_networks; ?></div>
					<!--#social bar --> 
				</div>
			</div>
			<!--#right top bar--> 
			<?php endif; ?>
		</div>
		<!--#top bar inner --> 
	</div>
	<!-- tn container --> 
</div>
<!--#Top Bar wrap -->

<div class="tn-banner-wrap banner-classic-style clearfix">
	<div class="tn-container logo-area-inner clearfix">
		<div class="tn-site-logo-wrap" role="banner" itemscope="itemscope"
			itemtype="http://schema.org/Organization">
			<a itemprop="url" class="logo-image" href="<?php print base_path(); ?>"><?php if($banner_default == '1'){ ?><img class="logo-image-data" data-no-retina itemprop="image"
				src="<?php print base_path().path_to_theme(); ?>/images/logo1.png" alt="<?php print $site_name; ?>"><?php }elseif($banner_image){ ?><img class="logo-image-data" data-no-retina itemprop="image"
				src="<?php print $banner_image_url; ?>" alt="<?php print $site_name; ?>"><?php } ?> </a>
			<meta itemprop="name" content="<?php print $site_name; ?>">
		</div>
		<!-- #logo wrap -->
	</div>
	<!--#logo area inner-->
</div>
<!--#banner wrap --><!--#logo area -->

<div id="tn-main-menu-sticky" class="clearfix">
	<div class="tn-main-menu-wrap">
		<div class="tn-container">
			<div class="tn-main-menu-inner clearfix">
				<div class="tn-mobile-main-menu-button"> <a href="#" id="tn-button-mobile-menu-open"> <span class="tn-mobile-menu-button"></span> </a> </div>
				<!-- #mobile button -->
				
				<div class="tn-main-menu-responsive clearfix" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
					<div class="tn-mobile-site-title"> <a href="<?php print base_path(); ?>"><span><?php print $site_name; ?></span></a> </div>
					<!--#mobile site -->
					
					<?php if($page['main_menu']): ?>
						<?php print render($page['main_menu']); ?>
					<?php endif; ?>
				</div>
				<!--#menu responsive --> 
			</div>
			<!--#menu inner --> 
		</div>
		<!--#tn container --> 
	</div>
	<!--#tn main-menu--> 
</div>
<?php if($breadcrumb): ?>
<div class="tn-breadcrumbs-wrap clearfix">

<div class="tn-breadcrumbs-inner tn-container"><?php print $breadcrumb; ?></div>
<!--#breadcrumbs --> 
</div>
<?php endif; ?>
<?php } ?>
<?php
	$blog_listing_sidebar = 'none';
	$blog_listing_sidebar = theme_get_setting('blog_listing_sidebar', 'zmagazine');
	if($blog_listing_sidebar == 'left' || $blog_listing_sidebar == 'right'){
		$blog_list_col = 'col-sm-8';
	}else{
		$blog_list_col = 'col-sm-12';
	}
?>
<!-- Start Page Template -->
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php if($blog_listing_sidebar == 'left'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">
		<div class="tn-sidebar-sticky">
			<div class="tn-sticky-sidebar">
			<?php if($page['sidebar_first']): ?>
				<?php print render($page['sidebar_first']); ?>
				<?php endif; ?>
			</div>
			<!--#end sticky -->
		</div>
	</div>
	<!--#close sidebar -->
	<?php endif; ?>
	<div <?php if($blog_listing_sidebar == 'left'){ ?> style="float:right" <?php }else{ ?>style="float:left"<?php } ?> class="tn-content-wrap <?php print $blog_list_col; ?> col-xs-12" itemscope="itemscope" itemprop="mainContentOfPage" itemtype="http://schema.org/CreativeWork">
		<div class="tn-archive-page-wrap">
			<div class="tn-page-classic-layout">
				<?php if($page['content']):?>
				<?php
					if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
						print render($tabs);
					endif;
					print $messages;
				?>
				<?php print render($page['content']); ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<!--#content of section content-->
	<?php if($blog_listing_sidebar == 'right'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">
		<div class="tn-sidebar-sticky">
			<div class="tn-sticky-sidebar">
			<?php if($page['sidebar_second']): ?>
				<?php print render($page['sidebar_second']); ?>
				<?php endif; ?>
			</div>
			<!--#end sticky -->
		</div>
	</div>
	<!--#close sidebar -->
	<?php endif; ?>
</div>
<!--#end section -->
<?php if($page['section_bottom']): ?>
	<?php print render($page['section_bottom']); ?>
<?php endif; ?>
<!--#section full width at top bottom -->

<?php }else{//single blog ?>
<?php
	$blog_single_header_style = theme_get_setting('blog_single_header_style', 'zmagazine');
	if(empty($blog_single_header_style)){
		$blog_single_header_style = 'style1';
	}

	$blog_single_banner_image = theme_get_setting('blog_single_banner_image','zmagazine');
	if(!empty($blog_single_banner_image)){
		$blog_single_banner_image_url = file_create_url(file_load($blog_single_banner_image)->uri);
	}
	$blog_single_background_image = theme_get_setting('blog_single_background_image','zmagazine');
	if(!empty($blog_single_background_image)){
		$blog_single_background_image_url = file_create_url(file_load($blog_single_background_image)->uri);
	}
	$blog_single_banner_default = theme_get_setting('blog_single_banner_default', 'zmagazine');
	if(isset($node->field_sidebar) && !empty($node->field_sidebar)){
		$sidebar = $node->field_sidebar['und'][0]['value'];
	}else{
		$sidebar = 'none';
	}
	if(isset($node->field_blog_format) && !empty($node->field_blog_format)){
 		$blog_format = $node->field_blog_format['und'][0]['value'];
 	}else{
 		$blog_format = 'classic';
 	}
	if(isset($node->field_image) && !empty($node->field_image)){
		$imageone_uri = $node->field_image['und'][0]['uri'];
		$imageone_url = file_create_url($imageone_uri);
	}
	if(isset($node->field_blog_categories) && !empty($node->field_blog_categories)){

	    $categories = field_view_field('node', $node, 'field_blog_categories');	
	}
	if(isset($node->field_tags) && !empty($node->field_tags)){

	    $tags = field_view_field('node', $node, 'field_tags');	
	}
	$nodevisit = statistics_get($node->nid);
	if(empty($nodevisit['totalcount'])){
		$nodevisit['totalcount'] = 0;
	}
	if(isset($node->field_video_embed) && !empty($node->field_video_embed)){

	    $video_embed = field_view_field('node', $node, 'field_video_embed');	
	}
?>

<?php if($blog_single_header_style == 'style1'){ ?>
<div id="single-blog-style1" class="tn-banner-wrap banner-background-image-style clearfix">
	<div class="tn-banner-parallax-wrap">
		<div data-background-image-header="<?php if(isset($blog_single_background_image) && !empty($blog_single_background_image)){ print $background_image_url; }?>" id="tn-banner-image-parallax"></div>
	</div>
	<!--#banner parallax wrap--><img src="<?php if(isset($blog_single_background_image) && !empty($background_image)){ print $background_image_url; }?>" id="img-background-image-header" alt="<?php print $site_name; ?>" style="display:none;"/>
	<?php if($blog_single_banner_default != '1'){ ?>
	<?php if(isset($blog_single_banner_image) && !empty($blog_single_banner_image)): ?>
	<div class="logo-area-inner-parallax clearfix">
		
		<div class="tn-site-logo-wrap" role="banner" itemscope="itemscope"
         itemtype="http://schema.org/Organization"> <a itemprop="url" class="logo-image" href="<?php print base_path(); ?>"> <img class="logo-image-data" data-no-retina itemprop="image"
                         src="<?php print $blog_single_banner_image_url; ?>" alt="<?php print $site_name; ?>"> </a>
			<meta itemprop="name" content="<?php print $site_name; ?>">
		</div>
		<!-- #logo wrap --> 
	</div>
	<!--#logo area inner-->
	<?php endif; ?>
	<?php }else{ ?>
	<div class="logo-area-inner-parallax clearfix">
		
		<div class="tn-site-logo-wrap" role="banner" itemscope="itemscope"
         itemtype="http://schema.org/Organization"> <a itemprop="url" class="logo-image" href="<?php print base_path(); ?>"> <img class="logo-image-data" data-no-retina itemprop="image"
                         src="<?php print base_path().path_to_theme(); ?>/images/logo1.png" alt="<?php print $site_name; ?>"> </a>
			<meta itemprop="name" content="<?php print $site_name; ?>">
		</div>
		<!-- #logo wrap --> 
	</div>
	<?php } ?>
</div>
<!--#banner wrap -->
<!--#banner wrap --> <!--#logo area -->
<div id="tn-main-menu-sticky" class="clearfix">
	<div class="tn-main-menu-wrap">
		<div class="tn-container">
			<div class="tn-main-menu-inner clearfix">
				<div class="tn-mobile-main-menu-button"> <a href="#" id="tn-button-mobile-menu-open"> <span class="tn-mobile-menu-button"></span> </a> </div>
				<!-- #mobile button -->
				
				<div class="tn-main-menu-responsive clearfix" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
					<div class="tn-mobile-site-title"> <a href="<?php print base_path(); ?>"><img data-no-retina src="<?php print base_path().path_to_theme(); ?>/images/mobile-logo.png" alt="<?php print $site_name; ?>"> </a> </div>
					<!--#mobile site -->

					<?php if($page['main_menu']): ?>
						<?php print render($page['main_menu']); ?>
					<?php endif; ?>

					<div class="tn-main-menu-right-area">
						<?php if(!empty($header_social_networks_more) || !empty($header_social_networks)): ?>
						<div class="tn-social-bar-wrap"><?php if(!empty($header_social_networks)) print $header_social_networks; ?>
							<?php if(!empty($header_social_networks_more)): ?>
							<div class="more-social-share">
								<div class="social-box-hidden-wrap"><?php print $header_social_networks_more; ?></div>
							</div>
							<?php endif; ?>
							<!--social box -->
						</div>
						<!--#social bar --> 
						<?php endif; ?>
					</div>
					<!--# main menu right area --> 
				</div>
				<!--#menu responsive --> 
			</div>
			<!--#menu inner --> 
		</div>
		<!--#tn container --> 
	</div>
	<!--#tn main-menu--> 
</div>
<?php if($breadcrumb): ?>
<div class="tn-breadcrumbs-wrap clearfix">

<div class="tn-breadcrumbs-inner tn-container"><?php print $breadcrumb; ?></div>
<!--#breadcrumbs --> 
</div>
<?php endif; ?>
<?php }elseif($blog_single_header_style == 'style2'){ ?>
<!-- Top Bar -->

<div class="tn-banner-wrap banner-background-image-style clearfix">
	<div class="tn-banner-parallax-wrap">
		<div data-background-image-header="<?php if(isset($blog_single_background_image) && !empty($blog_single_background_image)){ print $blog_single_background_image_url; }?>" id="tn-banner-image-parallax"></div>
	</div>
	<!--#banner parallax wrap--><img src="<?php if(isset($blog_single_background_image) && !empty($blog_single_background_image)){ print $blog_single_background_image_url; }?>" id="img-background-image-header" alt="<?php print $site_name; ?>" style="display:none;"/>
	<?php if($blog_single_banner_default != '1'){ ?>
	<?php if(isset($blog_single_banner_image) && !empty($blog_single_banner_image)): ?>
	<div class="logo-area-inner-parallax clearfix">
		
		<div class="tn-site-logo-wrap" role="banner" itemscope="itemscope"
         itemtype="http://schema.org/Organization"> <a itemprop="url" class="logo-image" href="<?php print base_path(); ?>"> <img class="logo-image-data" data-no-retina itemprop="image"
                         src="<?php print $blog_single_banner_image_url; ?>" alt="<?php print $site_name; ?>"> </a>
			<meta itemprop="name" content="<?php print $site_name; ?>">
		</div>
		<!-- #logo wrap --> 
	</div>
	<!--#logo area inner-->
	<?php endif; ?>
	<?php }else{ ?>
	<div class="logo-area-inner-parallax clearfix">
		
		<div class="tn-site-logo-wrap" role="banner" itemscope="itemscope"
         itemtype="http://schema.org/Organization"> <a itemprop="url" class="logo-image" href="<?php print base_path(); ?>"> <img class="logo-image-data" data-no-retina itemprop="image"
                         src="<?php print base_path().path_to_theme(); ?>/images/logo1.png" alt="<?php print $site_name; ?>"> </a>
			<meta itemprop="name" content="<?php print $site_name; ?>">
		</div>
		<!-- #logo wrap --> 
	</div>
	<?php } ?>
</div>
<!--#banner wrap --> <!--#logo area -->

<div id="tn-main-menu-sticky" class="clearfix">
	<div class="tn-main-menu-wrap">
		<div class="tn-container">
			<div class="tn-main-menu-inner clearfix">
				<div class="tn-mobile-main-menu-button"> <a href="#" id="tn-button-mobile-menu-open"> <span class="tn-mobile-menu-button"></span> </a> </div>
				<!-- #mobile button -->
				
				<div class="tn-main-menu-responsive tn-menu-center clearfix" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
					<div class="tn-mobile-site-title"> <a href="index_blog.html"> <img data-no-retina src="images/logo-blog-moible.png" alt="Magazine"> </a> </div>
					<!--#mobile site -->
					
					<?php if($page['main_menu']): ?>
						<?php print render($page['main_menu']); ?>
					<?php endif; ?>
				</div>
				<!--#menu responsive --> 
			</div>
			<!--#menu inner --> 
		</div>
		<!--#tn container --> 
	</div>
	<!--#tn main-menu--> 
</div>
<?php if($breadcrumb): ?>
<div class="tn-breadcrumbs-wrap clearfix">

<div class="tn-breadcrumbs-inner tn-container"><?php print $breadcrumb; ?></div>
<!--#breadcrumbs --> 
</div>
<?php endif; ?>
<?php }else{ ?>
<div id="tn-top-bar-wrap" class="clearfix">
	<div class="tn-container">
		<div class="tn-top-bar-inner row">
			<div class="tn-top-left-bar">
				<?php if($page['top_menu']): ?>
					<?php print render($page['top_menu']); ?>
				<?php endif; ?>
			</div>
			<!--#left top bar -->
			<?php if(!empty($header_social_networks)): ?>
			<div class="tn-top-right-bar">
				<div class="widget-social-content-wrap topbar-right-element">
					<div class="tn-topbar-social-wrap"><?php print $header_social_networks; ?></div>
				</div>
			</div>
			<!--#right top bar--> 
			<?php endif; ?>
		</div>
		<!--#top bar inner --> 
	</div>
	<!-- tn container --> 
</div>
<!--#Top Bar wrap -->

<div class="tn-banner-wrap banner-background-image-style clearfix">
	<?php if(isset($blog_single_background_image) && !empty($blog_single_background_image)):?>
	<div class="tn-banner-parallax-wrap">
		<div data-background-image-header="<?php print  $blog_single_background_image_url; ?>" id="tn-banner-image-parallax"></div>
	</div>
	<!--#banner parallax wrap-->
	<img src="<?php print  $blog_single_background_image_url; ?>" id="img-background-image-header" alt="<?php print $site_name; ?>" style="display:none;"/>
	<?php endif; ?>
	<?php if($blog_single_banner_default != '1'){ ?>
	<?php if(isset($blog_single_banner_image) && !empty($blog_single_banner_image)): ?>
	<div class="logo-area-inner-parallax clearfix">
		
		<div class="tn-site-logo-wrap" role="banner" itemscope="itemscope"
         itemtype="http://schema.org/Organization"> <a itemprop="url" class="logo-image" href="<?php print base_path(); ?>"> <img class="logo-image-data" data-no-retina itemprop="image"
                         src="<?php print $blog_single_banner_image_url; ?>" alt="<?php print $site_name; ?>"> </a>
			<meta itemprop="name" content="<?php print $site_name; ?>">
		</div>
		<!-- #logo wrap --> 
	</div>
	<!--#logo area inner-->
	<?php endif; ?>
	<?php }else{ ?>
	<div class="logo-area-inner-parallax clearfix">
		
		<div class="tn-site-logo-wrap" role="banner" itemscope="itemscope"
         itemtype="http://schema.org/Organization"> <a itemprop="url" class="logo-image" href="<?php print base_path(); ?>"> <img class="logo-image-data" data-no-retina itemprop="image"
                         src="<?php print base_path().path_to_theme(); ?>/images/logo1.png" alt="<?php print $site_name; ?>"> </a>
			<meta itemprop="name" content="<?php print $site_name; ?>">
		</div>
		<!-- #logo wrap --> 
	</div>
	<?php } ?>
</div>
<!--#banner wrap --><!--#logo area -->

<div id="tn-main-menu-sticky" class="clearfix">
	<div class="tn-main-menu-wrap">
		<div class="tn-container">
			<div class="tn-main-menu-inner clearfix">
				<div class="tn-mobile-main-menu-button"> <a href="#" id="tn-button-mobile-menu-open"> <span class="tn-mobile-menu-button"></span> </a> </div>
				<!-- #mobile button -->
				
				<div class="tn-main-menu-responsive clearfix" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
					<div class="tn-mobile-site-title"> <a href="<?php print base_path(); ?>"><span><?php print $site_name; ?></span></a> </div>
					<!--#mobile site -->
					
					<?php if($page['main_menu']): ?>
						<?php print render($page['main_menu']); ?>
					<?php endif; ?>
				</div>
				<!--#menu responsive --> 
			</div>
			<!--#menu inner --> 
		</div>
		<!--#tn container --> 
	</div>
	<!--#tn main-menu--> 
</div>
<?php if($breadcrumb): ?>
<div class="tn-breadcrumbs-wrap clearfix">

<div class="tn-breadcrumbs-inner tn-container"><?php print $breadcrumb; ?></div>
<!--#breadcrumbs --> 
</div>
<?php endif; ?>
<?php } ?>
<?php if($blog_format == 'classic'){//classic ?>
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php if($sidebar == 'left'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_first']): ?>
				<?php print render($page['sidebar_first']); ?>
			<?php endif; ?>	
		</div>
	</div>
	<?php endif; ?>
	<?php if($page['content']):?>
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php print render($page['content']); ?>
	<?php endif; ?>
	<?php if($sidebar == 'right'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_second']): ?>
				<?php print render($page['sidebar_second']); ?>
			<?php endif; ?>	
		</div>
	</div>
	<?php endif; ?>
</div>
<?php }elseif($blog_format == 'default_gallery'){ ?>
<div class="tn-single-style3-wrap tn-single-thumb-parallax">
	<?php if(isset($imageone_url)): ?>
	<div id="tn-single-image-parallax" data-background-image-header="<?php print $imageone_url; ?>"></div>
	<?php endif; ?>
	<div class="tn-single-style3-content-wrap">
		<div class="tn-single-style3-content-inner tn-container">
			<div class="tn-single-title-style3-wrap">
				<h1 itemprop="name" class="tn-single-title"><?php print $title; ?></h1>
				<!--#title-->
			</div>
			<!--#single title -->
			<div class="tn-single-top-meta-wrap">
				<div class="tn-category-tags-wrap tn-category-7"><?php print strip_tags(render($categories),'<a>');?></div>
				<span class="tn-single-tags single-meta-right-el"><span class="tn-single-tags-element"><i class="fa fa-tags"></i><?php print strip_tags(render($tags),'<a>'); ?></span></span>
				<!--category tags -->
				<div class="tn-single-top-meta-right">
					<span class="tn-single-top-meta-date disable-left-col single-meta-right-el"><i class="fa fa-calendar-o"></i><?php print format_date($node->created, 'custom', 'F d, Y'); ?></span>
					<span class="tn-single-top-meta-view-wrap single-meta-right-el">
						<span class="single-top-meta-views-num"><i class="fa fa-heart-o"></i><?php print $nodevisit['totalcount']; ?></span><!--#top meta views--><span class="single-top-meta-views-content"><?php print t('Views'); ?></span>
					</span>
				</div>
				<!--#top meta right-->
			</div>
			<!--#top meta wrap-->
		</div>
	</div>
	<!--#style 3 content -->
</div>
<?php if($sidebar != 'left' && $sidebar != 'right'){ ?>
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php if($page['content']):?>
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php print render($page['content']); ?>
	<?php endif; ?>
</div>
<?php }elseif($sidebar == 'left'){ ?>
<div class="tn-container tn-section-content-wrap row clearfix">
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_first']): ?>
				<?php print render($page['sidebar_first']); ?>
			<?php endif; ?>	
		</div>
	</div>
	<?php if($page['content']):?>
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php print render($page['content']); ?>
	<?php endif; ?>
</div>
<?php }elseif($sidebar == 'right'){ ?>
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php if($page['content']):?>
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php print render($page['content']); ?>
	<?php endif; ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_second']): ?>
				<?php print render($page['sidebar_second']); ?>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php } ?>
<?php }elseif($blog_format == 'gallery_post'){//gallery post ?>
<div class="tn-single-top-style5-wrap tn-container">
	<div class="tn-single-top-style5-inner">
		<div class="tn-single-big-thumb-title-wrap">
			<div class="tn-single-thumb-wrap">
				<div class="tn-single-thumb-inner">
					<div class="slider-loading"></div>

					<div id="tn-slider-single" class="tn-block-slider-wrap tn-slider-init tn-slider">
					<?php 
						foreach($node->field_image['und'] as $k => $v){
							$image_gallery_uri = $node->field_image['und'][$k]['uri'];
							print '<div>'.theme('image_style', array('path' => $image_gallery_uri, 'style_name' => 'image_1060x480', 'attributes'=>array('alt'=>$title))).'</div>';
						}

					?>
					</div>
					<!--#single slider-->
				</div>
				<!--#single slider wrap-->
				<div class="tn-single-big-thumb-title-inner">
					<div class="tn-single-title-wrap">
						<h1 itemprop="name" class="tn-single-title"><?php print $title; ?></h1>
						<!--#title-->
					</div>
					<!--#single title -->
					<div class="tn-single-top-meta-wrap">
						<div class="tn-category-tags-wrap tn-category-7"><?php print strip_tags(render($categories),'<a>');?></div>
						<!--category tags -->
						<div class="tn-single-top-meta-right">
							<span class="tn-single-top-meta-date single-meta-right-el"><i class="fa fa-calendar-o"></i><?php print format_date($node->created, 'custom', 'F d, Y'); ?></span><span class="tn-single-tags single-meta-right-el"><span class="tn-single-tags-element"><i class="fa fa-tags"></i><?php print strip_tags(render($tags),'<a>');?></span></span><!--#single tags-->
							<span class="tn-single-top-meta-view-wrap single-meta-right-el">
								<span class="single-top-meta-views-num"><i class="fa fa-heart-o"></i><?php print $nodevisit['totalcount']; ?></span><!--#top meta views--><span class="single-top-meta-views-content"><?php print t('Views'); ?></span>
							</span>
						</div>
						<!--#top meta right-->
					</div>
					<!--#top meta wrap-->
				</div>
				<!--#title wrap -->
			</div>
		</div>
		<!--#single title inner thumb-->
	</div>
	<!--#style 5 content -->
</div>
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php if($sidebar == 'left'): ?>
	<!--if left sidebar-->
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">
		<div class="tn-sidebar-sticky">
		<?php if($page['sidebar_first']): ?>
			<?php print render($page['sidebar_first']); ?>
		<?php endif; ?>
		</div>
	</div>
	<!--endif left sidebar-->
	<?php endif; ?>

	<?php if($page['content']):?>
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php print render($page['content']); ?>
	<?php endif; ?>
	<?php if($sidebar == 'right'): ?>
	<!--if right sidebar-->
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">
		<div class="tn-sidebar-sticky">
		<?php if($page['sidebar_second']): ?>
			<?php print render($page['sidebar_second']); ?>
		<?php endif; ?>
		</div>
	</div>
	<!--endif left sidebar-->
	<?php endif; ?>
</div>
<?php }elseif($blog_format == 'parallax_video'){?>
<div class="tn-single-style3-wrap tn-single-thumb-parallax">
	<?php if($imageone_url): ?>
	<div id="tn-single-image-parallax" class="tn-single-image-parallax">
		<div class="backstretch"><?php print theme('image_style', array('path' => $imageone_uri, 'style_name' => 'image_1368x768', 'attributes'=>array('alt'=>$title)));
			 ?></div>
	</div>
	<?php endif; ?>
	<div class="tn-single-style3-content-wrap">
		<div class="tn-single-style3-content-inner tn-container">
			<div class="tn-single-title-style3-wrap">
				<h1 itemprop="name" class="tn-single-title"><?php print $title; ?></h1>
				<!--#title-->
			</div>
			<!--#single title -->
			<div class="tn-single-top-meta-wrap">
				<div class="tn-category-tags-wrap tn-category-11"><?php print strip_tags(render($categories),'<a>'); ?></div>
				<!--category tags -->
				<div class="tn-single-top-meta-right">
					<span class="tn-single-top-meta-date single-meta-right-el"><i class="fa fa-calendar-o"></i><?php print format_date($node->created, 'custom', 'F d, Y'); ?></span>
					<span class="tn-single-top-meta-view-wrap single-meta-right-el">
						<span class="single-top-meta-views-num"><i class="fa fa-heart-o"></i><?php print $nodevisit['totalcount']; ?></span><!--#top meta views--><span class="single-top-meta-views-content"><?php print t('Views'); ?></span>
					</span>
					<meta itemprop="author" name="author" content="Margaret">
					<span class="tn-single-top-meta-comment-wrap single-meta-right-el">
						<span class="single-top-meta-comments-num"><i class="fa fa-comments"></i><?php print $node->comment_count; ?></span><!--#counter number--><span class="single-top-meta-comments-content"><?php print t('Comments'); ?></span>
					</span>
					<!--#comment wrap -->
				</div>
				<!--#top meta right-->
			</div>
			<!--#top meta wrap-->
		</div>
	</div>
	<!--#style 3 content -->
	<?php if($video_embed): ?>
	<div class="tn-single-media-overlay"></div>
	<div class="tn-single-media-icon"><i class="fa fa-play-circle"></i></div>	
	<div class="tn-single-media-parallax tn-single-video-parallax">
		<div class="tn-video-wrap tn-single-thumb-wrap">
			<?php print render($video_embed); ?>
		</div>
	</div>
	<?php endif; ?>
	<!--#audio overlay -->
</div>
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php if($sidebar == 'left'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_first']): ?>
				<?php print render($page['sidebar_first']); ?>
			<?php endif; ?>
		</div>
	</div>
	<!--#close sidebar -->
	<?php endif; ?>
	<?php if($page['content']):?>
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php print render($page['content']); ?>
	<?php endif; ?>
	<?php if($sidebar == 'right'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_second']): ?>
				<?php print render($page['sidebar_second']); ?>
			<?php endif; ?>
		</div>
	</div>
	<!--#close sidebar -->
	<?php endif; ?>
</div>
<?php }elseif($blog_format == 'video' || $blog_format == 'sound_cloud'){ ?>
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php if($sidebar == 'left'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_first']): ?>
				<?php print render($page['sidebar_first']); ?>
			<?php endif; ?>
		</div>
	</div>
	<!--#close sidebar -->
	<?php endif; ?>
	<?php if($page['content']):?>
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php print render($page['content']); ?>
	<?php endif; ?>
	<?php if($sidebar == 'right'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_second']): ?>
				<?php print render($page['sidebar_second']); ?>
			<?php endif; ?>
		</div>
	</div>
	<!--#close sidebar -->
	<?php endif; ?>
</div>
<?php }elseif($blog_format == 'parallax_without_title'){ ?>
<?php if($imageone_url): ?>
<div class="tn-single-style4-wrap tn-single-thumb-parallax">
	<div id="tn-single-image-parallax" data-background-image-header="<?php print $imageone_url; ?>"></div>
</div>
<?php endif; ?>
<div class="tn-container tn-section-content-wrap tn-single-style4-main-wrap row clearfix">
	<?php if($sidebar == 'left'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<?php if($page['sidebar_first']): ?>
			<?php print render($page['sidebar_first']); ?>
		<?php endif; ?>
	</div>
	<?php endif; ?>
	<?php if($page['content']):?>
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php print render($page['content']); ?>
	<?php endif; ?>
	<?php if($sidebar == 'right'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<?php if($page['sidebar_second']): ?>
			<?php print render($page['sidebar_second']); ?>
		<?php endif; ?>
	</div>
	<?php endif; ?>
</div>
<?php }elseif($blog_format == 'parallax_with_title'){ ?>
<div class="tn-single-style3-wrap tn-single-thumb-parallax">
	<?php if(isset($imageone_url)): ?>
	<div id="tn-single-image-parallax" data-background-image-header="<?php print $imageone_url; ?>"></div>
	<?php endif; ?>
	<div class="tn-single-style3-content-wrap">
		<div class="tn-single-style3-content-inner tn-container">
			<div class="tn-single-title-style3-wrap">
				<h1 itemprop="name" class="tn-single-title"><?php print $title; ?></h1>
				<!--#title-->
			</div>
			<!--#single title -->
			<div class="tn-single-top-meta-wrap">
				<div class="tn-category-tags-wrap tn-category-7"><?php print strip_tags(render($categories),'<a>');?></div>
				<span class="tn-single-tags single-meta-right-el"><span class="tn-single-tags-element"><i class="fa fa-tags"></i><?php print strip_tags(render($tags),'<a>'); ?></span></span>
				<!--category tags -->
				<div class="tn-single-top-meta-right"><span class="tn-single-top-meta-date disable-left-col single-meta-right-el"><i class="fa fa-calendar-o"></i><?php print format_date($node->created, 'custom', 'F d, Y'); ?></span><span class="tn-single-top-meta-view-wrap single-meta-right-el"><span class="single-top-meta-views-num"><i class="fa fa-heart-o"></i><?php print $nodevisit['totalcount']; ?></span><!--#top meta views--><span class="single-top-meta-views-content"><?php print t('Views'); ?></span></span>
				</div>
				<!--#top meta right-->
			</div>
			<!--#top meta wrap-->
		</div>
	</div>
	<!--#style 3 content -->
</div>
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php if($sidebar == 'left'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_first']): ?>
				<?php print render($page['sidebar_first']); ?>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>
	<?php if($page['content']):?>
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php print render($page['content']); ?>
	<?php endif; ?>
	<?php if($sidebar == 'right'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_second']): ?>
				<?php print render($page['sidebar_second']); ?>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>
</div>
<?php }elseif($blog_format == 'fullwidth_title'){ ?>
<div class="tn-container tn-section-content-wrap row clearfix">
	<?php if($sidebar == 'left'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
		<?php if($page['sidebar_first']): ?>
			<?php print render($page['sidebar_first']); ?>
		<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>
	<?php if($page['content']):?>
	<?php
		if (!empty($tabs['#primary']) || !empty($tabs['#secondary'])):
			print render($tabs);
		endif;
		print $messages;
	?>
	<?php print render($page['content']); ?>
	<?php endif; ?>
	<?php if($sidebar == 'right'): ?>
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
		<?php if($page['sidebar_second']): ?>
			<?php print render($page['sidebar_second']); ?>
		<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>
</div>
<?php } ?>
<?php } ?>
<?php require_once(drupal_get_path('theme','zmagazine').'/tpl/footer.tpl.php'); ?>