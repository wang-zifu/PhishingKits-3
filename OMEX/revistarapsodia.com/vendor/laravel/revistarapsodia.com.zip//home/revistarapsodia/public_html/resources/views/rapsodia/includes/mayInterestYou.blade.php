<div class="block block-views tn-single-related-wrap" >
    <div class="single-related-title block-title-wrap">
        <h3>TE PUEDE INTERESAR</h3>
    </div>
    <!--#related title-->
    <div class="tn-block-content-wrap tn-single-related-content row">
        <div class="tn-block-content-inner clearfix">
            <?php $postsRandom = \App\PostModel::orderByRaw("RAND()")->get(); ?>

                @for($i = 0; $i < 4; $i++)
                    @if(count($postsRandom) > $i)
                        <div class="related-content-element col-sm-3 col-xs-12">
                            <div class="tn-module-related-wrap tn-module-wrap tn-category-7 clearfix">
                                <div class="tn-module-related-inner">
                                    <div class="tn-module-related-thumb">
                                        <div class="tn-thumb-wrap">
                                            @if(strlen($postsRandom[$i]->content->url_image) > 0)
                                                <img width="200" height="250" itemprop="image" src="{{ asset('storage/app/post'.$postsRandom[$i]->id. '/' . $postsRandom[$i]->content->url_image) }}" alt="{{  $postsRandom[$i]->title }}" />
                                            @else
                                            <?php
                                                 $img = "";
                                                if( count($postsRandom[$i]->multiContent) > 0){
                                                    $m = $postsRandom[$i]->multiContent[0];
                                                    $img = asset('storage/app/post'.$postsRandom[$i]->id. '/p_'. $m->id. '/' . $m->preview);
                                                }
                                            ?>
                                                <img width="200" height="250" itemprop="image" src="{{$img}}" alt="{{  $postsRandom[$i]->title }}" />
                                            @endif
                                            <a href="{{ asset(($postsRandom[$i]->menu->url == "#") ? $postsRandom[$i]->kid->url : $postsRandom[$i]->menu->url) }}" title="{{  $postsRandom[$i]->title }}" rel="bookmark"></a>
                                            <!--span class="tn-post-format"><i class="fa fa-play-circle"></i></span-->
                                            <!--div class="tn-meta-thumb-views tn-meta-counter-wrap">
                                                <div class="tn-counter-num">309</div>
                                                <div class="tn-counter-content">Views</div>
                                            </div-->
                                        </div>
                                    </div>
                                    <div class="tn-module-related-meta-tags tn-tags-date-author"><span class="meta-tags-date">
                                       <time itemprop="dateCreated">
                                           {{ date('d/m/Y', strtotime($postsRandom[$i]->created_at)) }}
                                       </time>
                                       </span>
                                       @if($postsRandom[$i]->author != null)
                                        <span class="meta-tags-author">Por: <span class="username" xml:lang=""  typeof="sioc:UserAccount" property="foaf:name" datatype="">{{ $postsRandom[$i]->author->name }}</span></span>
                                        @endif
                                    </div>
                                    <h3 itemprop="name" class="tn-module-title">
                                        <a itemprop="url" href="{{ asset(($postsRandom[$i]->menu->url == "#") ? $postsRandom[$i]->kid->url : $postsRandom[$i]->menu->url) }}" rel="bookmark" title="{{  $postsRandom[$i]->title }}">{{  $postsRandom[$i]->title }} </a></h3>
                                </div>
                            </div>
                        </div>
                    @endif
                @endfor

        </div>
    </div>
</div>

