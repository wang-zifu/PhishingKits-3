<?php print render($title_prefix); ?>
<div id="56126ca284a7aa" class="tn-block-post-wrap tn-block-wrap clearfix">
	<?php if($header): ?>
	<div class="tn-block-post-title block-title-wrap">
		<?php print $header; ?>
	</div>
	<!--#block header wrap -->
	<?php endif; ?>
	<?php if($rows): ?>
	<div class="tn-block-post-content-wrap tn-block-content-wrap">
		<div class="tn-block-post-content-inner tn-block-content-inner">
			<?php print $rows; ?>
		</div>
	</div>
	<!--#block content wrap-->
	<?php endif; ?>
</div>
