<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class PostModel extends Model {

	//

    protected $fillable = ['author_id', 'template_id', 'menu_id', 'menu_kids_id', 'title'];



    public function menu(){
        return $this->hasOne('App\MenuModel', 'id', 'menu_id');
    }

    public function kid(){
        return $this->hasOne('App\MenuKidsModel', 'id', 'menu_kids_id');
    }

    public function content(){
        return $this->hasOne('App\PostContentModel', 'post_id', 'id');
    }

    public function multiContent(){
        return $this->hasMany('App\PostMultiContentModel', 'post_id', 'id');
    }

    public function author(){
        return $this->hasOne('App\AuthorsModel', 'id', 'author_id');
    }



}
