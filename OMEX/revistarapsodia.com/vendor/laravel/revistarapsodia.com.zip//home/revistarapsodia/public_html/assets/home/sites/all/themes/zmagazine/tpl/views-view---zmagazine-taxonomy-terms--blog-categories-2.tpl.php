<div class="tn-block9-title block-title-wrap">		
	<?php if($header): ?>
		<?php print $header; ?>
	<?php endif; ?>		
	<?php if($rows): ?>
	<div class="tn-sub-cate-wrap">
		<ul class="tn-sub-cate-inner">
			<?php print $rows; ?>
		</ul>
	</div>
	<?php endif; ?>
</div>