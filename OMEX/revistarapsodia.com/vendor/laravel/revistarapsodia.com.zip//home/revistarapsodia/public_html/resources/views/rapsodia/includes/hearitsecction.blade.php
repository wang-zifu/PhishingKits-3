<?php
$contentHearit = \App\PostModel::where("menu_id", 2)->where("menu_kids_id", 4)->where('history', false)->first();
?>
@if(count($contentHearit->multiContent) > 0)
<aside class="block block-views widget block-post-widget" >
    <div class="tn-block-post-wrap tn-block-wrap clearfix">
        <div class="tn-block-post-title block-title-wrap">
            <h3>LO TIENES QUE ESCUCHAR</h3>
        </div>
        <!--#block header wrap -->
        <div class="tn-block-post-content-wrap tn-block-content-wrap">
            <div class="tn-block-post-content-inner tn-block-content-inner">


                @foreach($contentHearit->multiContent as $m)
                <div class="tn-module-small-wrap tn-module-wrap  clearfix" itemscope itemtype="http://schema.org/Article">
                    <div class="tn-module-small-inner">
                        <div class="tn-thumb-wrap">

                            <img width="120" height="90" itemprop="image" src="{{ asset('storage/app/post'.$contentHearit->id. '/p_'. $m->id. '/' . $m->preview) }}" class="attachment-module_small_thumb" alt="{{$m->subtitle}}" />
                            <a href="{{asset('lotienesque#secction'.$m->id)}}" title="{{$m->subtitle}}" rel="bookmark">

                            </a>
                        </div>
                        <h3 itemprop="name" class="tn-module-title"><a itemprop="url" href="{{asset('lotienesque#secction'.$m->id)}}" rel="bookmark" title="{{$m->subtitle}}">{{$m->subtitle}}</a></h3>
                           <span class="meta-tags-date">
                           <time itemprop="dateCreated">{{ date('d/m/Y', strtotime($m->created_at)) }}</time>
                           </span>
                    </div>
                </div>
                @endforeach

            </div>
        </div>
        <!--#block content wrap-->
    </div>
</aside>
@endif

@include('rapsodia.includes.popular')
