<?php 
	$onsale = strip_tags(render($content['product:field_commerce_saleprice_on_sale']));
	if(isset($content['product:field_image']) && !empty($content['product:field_image'])){
		$imageone_uri  = $content['product:field_image']['#items'][0]['uri'];
		$imageone_url = file_create_url($imageone_uri);
	}
	$count_rate = strip_tags(render($content['product:field_rating']));
?>
<?php if($page){?>

<div class=" product type-product status-publish has-post-thumbnail sale shipping-taxable purchasable product-type-simple product-cat-posters instock">
	<?php if($onsale == 1): ?>
	<span class="onsale">Sale!</span>
	<?php endif; ?>
	<div class="images">
		<?php if($imageone_uri): ?>
		<a href="<?php if(isset($imageone_url)){ print $imageone_url;} ?>" itemprop="image" class="woocommerce-main-image zoom" data-rel="prettyPhoto[product-gallery]"><?php print theme('image_style', array('path' => $imageone_uri, 'style_name' => 'image_600x600', 'attributes'=>array('alt'=>$title))); ?></a>
		<?php endif; ?>
		<div class="thumbnails columns-3">
			<?php 
			foreach($content['product:field_image']['#items'] as $k => $v){
				$image_array_uri  = $content['product:field_image']['#items'][$k]['uri'];
		       	$image_array_url = file_create_url($image_array_uri);
		        print '<a href="'.$image_array_url.'" class="zoom" title="'.$title.'" data-rel="prettyPhoto[product-gallery]">'.theme('image_style', array('path' => $image_array_uri, 'style_name' => 'image_180x180', 'attributes'=>array('alt'=>$title,'class'=>'attachment-shop_thumbnail'))).'</a>';
			}
			?>
		</div>
	</div>
	<div class="summary entry-summary">
		<h1 itemprop="name" class="product_title entry-title"><?php print $title; ?></h1>
		<?php if($count_rate != 0): ?>
		<div class="woocommerce-product-rating">
			<?php print render($content['product:field_rating']); ?>
		</div>
		<?php endif; ?>
		<div itemprop="offers" itemscope itemtype="http://schema.org/Offer">
			<p class="price"><?php if($onsale == 1){ ?><del><span class="amount"><?php print strip_tags(render($content['product:commerce_price'])); ?></span></del> <ins><span class="amount"><?php print strip_tags(render($content['product:field_commerce_saleprice'])); ?></span></ins><?php }else{ ?><span class="amount"><?php print render($content['product:commerce_price']) ?></span><?php } ?></p>
			<link itemprop="availability" href="<?php print $node_url; ?>" />
		</div>
		<div itemprop="description">
			<?php print render($content['product:field_short_description']); ?>
		</div>
		<?php 
			hide($content['product:field_short_description']);
			hide($content['product:field_product_description']);
			hide($content['product:field_image']);
			hide($content['field_product_categories']);

            hide($content['product:field_rating']);
        	hide($content['product:field_image']);
        	hide($content['product:commerce_price']);
        	hide($content['product:field_commerce_saleprice']);

            hide($content['product:field_commerce_saleprice_on_sale']);
            hide($content['product:links']);
            hide($content['product:sku']);
            hide($content['comments']);
            hide($content['links']);
            unset($content['links']['node']['#links']['node-readmore']);
        	print render($content);
		?>
		<div class="product_meta product-categories"> <span class="posted_in"><?php print t('Categories'); ?>: <?php print strip_tags(render($content['field_product_categories']),'<a>'); ?></span> </div>
	</div>
	<!-- .summary -->
	<div class="woocommerce-tabs">
		<ul class="tabs">
			<li class="description_tab"> <a rel="tab-description" href="#tab-description"><?php print t('Description'); ?></a> </li>
			<li class="reviews_tab"> <a href="#tab-reviews" rel="tab-reviews"><?php print t('Comments'); ?> (<?php print $comment_count; ?>)</a> </li>
		</ul>
		<div class="panel entry-content" id="tab-description">
			<?php print render($content['product:field_product_description']); ?>
		</div>
		<div class="panel entry-content" id="tab-reviews">
			<?php print render($content['comments']); ?>
		</div>
	</div>
	<?php if($region['bottom_product']): ?>
		<?php print render($region['bottom_product']); ?>
	<?php endif ?>
</div>
<?php }else{ ?>
<li class="product type-product status-publish has-post-thumbnail shipping-taxable purchasable product-type-simple zmagazine-shop-catalog"> <a href="<?php print $node_url; ?>"><?php if($onsale == 1): ?>
	<span class="onsale">Sale!</span>
	<?php endif; ?><?php print theme('image_style', array('path' => $imageone_uri, 'style_name' => 'image_300x300', 'attributes'=>array('alt'=>$title))); ?>
    <h3><?php print $title; ?></h3>
    <?php if($count_rate != 0): ?>
    	<?php print render($content['product:field_rating']); ?>
	<?php endif ?>
	<span class="price"><?php if($onsale == 1){ ?><del><span class="amount"><?php print strip_tags(render($content['product:commerce_price'])); ?></span></del> <ins><span class="amount"><?php print strip_tags(render($content['product:field_commerce_saleprice'])); ?></span></ins><?php }else{ ?><span class="amount"><?php print strip_tags(render($content['product:commerce_price'])); ?></span><?php } ?></span> </a>		
		<?php 
			hide($content['product:field_short_description']);
			hide($content['product:field_product_description']);
			hide($content['product:field_image']);
			hide($content['field_product_categories']);

            hide($content['product:field_rating']);
        	hide($content['product:field_image']);
        	hide($content['product:commerce_price']);
        	hide($content['product:field_commerce_saleprice']);

            hide($content['product:field_commerce_saleprice_on_sale']);
            hide($content['product:links']);
            hide($content['product:sku']);
            hide($content['comments']);
            hide($content['links']);
            unset($content['links']['node']['#links']['node-readmore']);
        	print render($content);
		?>
</li>
<?php } ?>