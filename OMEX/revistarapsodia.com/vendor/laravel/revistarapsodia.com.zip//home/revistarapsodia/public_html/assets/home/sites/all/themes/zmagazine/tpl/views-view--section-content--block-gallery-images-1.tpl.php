<?php print render($title_prefix); ?>
<aside class="widget APTFIN_by_TAP">
    <!-- Using AlpinePT for Instagram v1.2.7 with JSON--><!-- Request made --><!-- Success using wp_remote_get() and JSON -->
    <div id="aptfinbytap_domain-2-AlpinePhotoTiles_container" class="AlpinePhotoTiles_container_class">
        <div id="aptfinbytap_domain-2-cascade-parent" class="AlpinePhotoTiles_parent_class" style="width:100%;max-width:100%;padding:0px;margin:0px auto;text-align:center;">
            <?php if($rows): ?>
       		   <?php print $rows; ?>
            <?php endif; ?>
        	<div class="AlpinePhotoTiles_breakline"></div>
    	</div>
	</div>
</aside>