<?php require_once(drupal_get_path('theme','zmagazine').'/tpl/header.tpl.php'); ?>
<div class="tn-container tn-section-content-wrap row clearfix">
	<div style="float:left" class="tn-content-wrap col-sm-8 col-xs-12">
		<!--#header category -->
		<div class="tn-header-category-wrap">
			<div class="tn-category-title">
				<h1 itemprop="name"><?php print $title; ?></h1>
			</div>
		</div>
		<!--#header category -->
		<div class="tn-category-wrap">
			<?php if($page['content']): ?>
				<?php print render($page['content']); ?>
			<?php endif; ?>
		</div>
		<!--category wrap --> 
	</div>
	<!--#content of section content-->
	<div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
		<div class="tn-sidebar-sticky">
			<?php if($page['sidebar_second']): ?>
				<?php print render($page['sidebar_second']); ?>
			<?php endif; ?>
		</div>
	</div>
	<!--#close sidebar -->
</div>
<?php require_once(drupal_get_path('theme','zmagazine').'/tpl/footer.tpl.php'); ?>