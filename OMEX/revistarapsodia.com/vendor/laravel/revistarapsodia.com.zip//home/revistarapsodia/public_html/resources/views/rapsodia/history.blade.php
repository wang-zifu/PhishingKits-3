@extends('master.home')


@section('adsense')
    
         <script async src="//"></script>
         <!-- Anuncios R1 -->
         <ins class="adsbygoogle"
              style="display:block"
              data-ad-client="ca-pub-7473782780390075"
              data-ad-slot="8544575149"
              data-ad-format="auto"></ins>
         <script>
         (adsbygoogle = window.adsbygoogle || []).push({});
         </script>
@endsection

@section('content')

    <div class="tn-breadcrumbs-wrap clearfix">
        <div class="tn-breadcrumbs-inner tn-container">
            <span><a href="{{ asset('/')}}">HOME</a></span>
            <i class="fa fa-angle-right next-breadcrumbs"></i>
            <span><a href="#">HISTORIAL</a></span>
            <!--#breadcrumbs -->
        </div>
    </div>

    <!-- Start Page Template -->
    <div class="tn-container tn-section-content-wrap row clearfix">
        <div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix" role="complementary" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">
            <div class="tn-sidebar-sticky">
                <div class="tn-sticky-sidebar">
                    <aside class="block block-views widget widget_categories" >
                        <div class="widget-title">
                            <h3>SECCIONES</h3>
                        </div>
                        <ul>
                            @foreach(\App\MenuModel::all() as $menu)
                                @if($menu->name != "CONTACTO" && $menu->name != "HOME")
                                    @if($menu->url != "/" && count($menu->kids) > 0)
                                        @foreach($menu->kids as $kid)
                                            <li class="cat-item">
                                                <a href="{{ asset('historial/'. $menu->id . '/'. $kid->id) }}">
                                                    <i class="fa fa-music" aria-hidden="true"></i>
                                                    {{ $kid->name }}
                                                </a>
                                            </li>
                                        @endforeach
                                    @else
                                        <li class="cat-item">
                                            <a href="{{ asset('historial/'. $menu->id . '/0') }}">
                                                <i class="fa fa-music" aria-hidden="true"></i>
                                                {{ $menu->name }}
                                            </a>
                                        </li>
                                    @endif
                                @endif
                            @endforeach
                        </ul>
                    </aside>
                    @include('rapsodia.includes.marketing')
                    @include('rapsodia.includes.popular')
                    

                </div>
                <!--#end sticky -->
            </div>
        </div>
        <!--#close sidebar -->
        <div  style="float:right"  class="tn-content-wrap col-sm-8 col-xs-12" itemscope="itemscope" itemprop="mainContentOfPage" itemtype="http://schema.org/CreativeWork">
            <div class="tn-archive-page-wrap">
                <div class="tn-page-classic-layout">

                    @if(count($posts) > 0)
                        @foreach($posts as $post)
                        <?php
                         $img = asset('storage/app/post'.$post->id. '/' . $post->content->url_image);
                         if(($post->content->url_image == "" || $post->content->url_image == null) && count($post->multiContent) > 0){
                            $m = $post->multiContent[0];
                            $img = asset('storage/app/post'.$post->id. '/p_'. $m->id. '/' . $m->preview);
                         }

                        ?>
                            <div class="tn-block6-element">
                                <div class="tn-module4-wrap tn-module-wrap clearfix">
                                    <div class="tn-module4-inner">
                                        <div class="tn-module4-thumb">
                                            <div class="tn-thumb-wrap">
                                                <img width="825" height="465"  itemprop="image" src="{{ $img }}" alt="{{ $post->title }}" />
                                                <a href="{{ asset( (($post->menu->url != "#") ? $post->menu->url : $post->kid->url) . '/'.$post->id ) }}" title="{{ $post->title }}" rel="bookmark"></a>
                                                <!--div class="tn-meta-thumb-views tn-meta-counter-wrap">
                                                    <div class="tn-counter-num">701</div>
                                                    <div class="tn-counter-content">Views</div>
                                                </div-->
                                                <!--#counter wrap -->
                                            </div>
                                            <!--#thumb wrap -->
                                        </div>
                                        <!--#thumb 4 wrap -->
                                        <div class="tn-module4-content">
                                            <div class="tn-module4-meta-tags">
                                                <div class="tn-category-tags-wrap">

                                                    <a href="{{ asset( (($post->menu->url != "#") ? $post->menu->url : $post->kid->url) . '/'.$post->id ) }}" typeof="skos:Concept" property="rdfs:label skos:prefLabel" datatype="">
                                                        {{ ($post->menu->url != "#") ? $post->menu->name : $post->kid->name }}
                                                    </a>    </div>
                                                <!--category tags -->
                                                <div class="tn-module4-meta-right tn-tags-date-author">
                                                    <span class="meta-tags-author">Por:
                                                        <span rel="sioc:has_creator"><span class="username" xml:lang="" about="/demo/drupal/fmagazine/users/admin" typeof="sioc:UserAccount" property="foaf:name" datatype="">
                                                                {{ $post->author->name }}
                                                            </span>
                                                        </span>
                                                    </span><!--#meta author-->
                                                </div>
                                                <!--#right meta-->
                                            </div>
                                            <!--#meta tags wrap-->
                                            <h3 itemprop="name" class="tn-module-title">
                                                <a itemprop="url" href="{{ asset( (($post->menu->url != "#") ? $post->menu->url : $post->kid->url) . '/'.$post->id ) }}" rel="bookmark" title="{{ $post->title }}">{{ $post->title }}</a></h3>
                                            <!--#module title -->
                                            <div class="tn-module-excerpt-wrap">
                                                <div class="tn-module4-date-wrap">
                                                    <a class="tn-hidden-link-left-col" href="{{ asset( (($post->menu->url != "#") ? $post->menu->url : $post->kid->url) . '/'.$post->id ) }}"></a><span  class="meta-tags-day">{{ date('d', strtotime($post->created_at)) }}</span><!--#meta day-->
                                                    <meta itemprop="interactionCount" content="UserComments:0"/>
                                                    <span  class="meta-tags-month" style="color: white">{{ date('M', strtotime($post->created_at)) }}</span><!--#meta month-->
                                                </div>
                                                <!--#date wrap -->
                                                <div class="tn-module-excerpt">
                                                    <?php
                                                         $description = trim(substr(strip_tags($post->content->text_1), 0, 135)); 
                                                         $description =  preg_replace( "/\r|\n/", "", trim(str_replace('&nbsp;', '', $description)));

                                                         if( ($description == "" || $description == null) && $post->multiContent != null){

                                                            $description = trim(substr(strip_tags($post->multiContent[0]->text), 0, 135)); 
                                                            $description =  preg_replace( "/\r|\n/", "", trim(str_replace('&nbsp;', '', $description)));

                                                         }
                                                        ?>


                                                    {{ $description }}...
                                                </div>
                                                <div class="tn-read-more-wrap"><a class="tn-read-more"  href="{{ asset( (($post->menu->url != "#") ? $post->menu->url : $post->kid->url) . '/'.$post->id ) }}" title="{{ $post->title }}" rel="bookmark">Leer más</a></div>
                                                <!--#read more button -->
                                            </div>
                                            <!--#module excerpt-->
                                        </div>
                                        <!--#module 4 content -->
                                    </div>
                                    <!--#module 4 inner -->
                                </div>
                                <!--#module 4 wrap -->
                             </div>
                        @endforeach
                    @else
                                No hay post para esta sección
                    @endif
                    <!--h2 class="element-invisible">Pages</h2>
                    <div class="item-list">
                        <ul class="pager">
                            <li class="pager-current first">1</li>
                            <li class="pager-item"><a title="Go to page 2" href="/demo/drupal/fmagazine/blog?page=1">2</a></li>
                            <li class="pager-item"><a title="Go to page 3" href="/demo/drupal/fmagazine/blog?page=2">3</a></li>
                            <li class="pager-next"><a title="Go to next page" href="/demo/drupal/fmagazine/blog?page=1">next ›</a></li>
                            <li class="pager-last last"><a title="Go to last page" href="/demo/drupal/fmagazine/blog?page=2">last »</a></li>
                        </ul>
                    </div-->
                </div>
            </div>
        </div>
        <!--#content of section content-->
    </div>



@endsection

@section('scripts')

@endsection


@section('css')


@endsection
