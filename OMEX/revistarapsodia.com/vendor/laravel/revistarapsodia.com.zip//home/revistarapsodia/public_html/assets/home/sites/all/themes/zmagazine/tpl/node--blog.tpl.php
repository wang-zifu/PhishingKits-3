<?php

	//total views

	$nodevisit = statistics_get($node->nid);

	if(empty($nodevisit['totalcount'])){

		$nodevisit['totalcount'] = 0;

	}

	//get records

	if(isset($node->field_sidebar) && !empty($node->field_sidebar)){

		$sidebar = $node->field_sidebar['und'][0]['value'];

	}else{

		$sidebar = 'none';

	}

	if(isset($node->body) && !empty($node->body['und'][0]['summary'])){

		$summary = $node->body['und'][0]['summary'];

	}

	if(isset($node->field_image) && !empty($node->field_image)){

		$imageone_uri = $node->field_image['und'][0]['uri'];

		$imageone_url = file_create_url($imageone_uri);

	}

    

    $count = count($node->field_image['und']);

    if(isset($node->field_author_name) && !empty($node->field_author_name)){

    	$author_name = $node->field_author_name['und'][0]['value'];

    }

    

    if(isset($node->field_author_description) && !empty($node->field_author_description)){

    	$author_description = $node->field_author_description['und'][0]['value'];

    }

    if(isset($node->field_author_avatar) && !empty($node->field_author_avatar)){

    	$author_avatar = $node->field_author_avatar['und'][0]['uri'];

    	$author_avatar_url = file_create_url($author_avatar);

	}



	//get background image from theme settings

	$background_image = theme_get_setting('blog_background_image','zmagazine');

	if(!empty($background_image)){

		$background_image_url = file_create_url(file_load($background_image)->uri);

	}

	if(isset($node->field_facebook) && !empty($node->field_facebook)){

		$facebook = $node->field_facebook['und'][0]['value'];

	}

	if(isset($node->field_twitter) && !empty($node->field_twitter)){

		$twitter = $node->field_twitter['und'][0]['value'];

	}

	if(isset($node->field_pinterest) && !empty($node->field_pinterest)){

		$pinterest = $node->field_pinterest['und'][0]['value'];

	}

	if(isset($node->field_linkedin) && !empty($node->field_linkedin)){

		$linkedin = $node->field_linkedin['und'][0]['value'];

	}

	if(isset($node->field_flickr) && !empty($node->field_flickr)){

		$flickr = $node->field_flickr['und'][0]['value'];

	}

	if(isset($node->field_tumblr) && !empty($node->field_tumblr)){

		$tumblr = $node->field_tumblr['und'][0]['value'];

	}

	

	if(isset($node->field_blog_format) && !empty($node->field_blog_format)){

 		$blog_format = $node->field_blog_format['und'][0]['value'];

 	}else{

 		$blog_format = 'classic';

 	}



?>

<?php if(!$page && !(arg(0) ==  "taxonomy" && arg(1) == "term" && is_numeric(arg(2)) && arg(3) == "")){ ?>

<div class="tn-block6-element">

	<div class="tn-module4-wrap tn-module-wrap clearfix">

		<div class="tn-module4-inner">

			<div class="tn-module4-thumb">

				<div class="tn-thumb-wrap">

					<img width="825" height="465"  itemprop="image" src="<?php print $imageone_url; ?>" alt="<?php print $title; ?>" /><a href="<?php print $node_url; ?>" title="<?php print $title; ?>" rel="bookmark"></a>

					<div class="tn-meta-thumb-views tn-meta-counter-wrap">

						<div class="tn-counter-num"><?php print $nodevisit['totalcount'];  ?></div>

						<!--#counter number-->

						<div class="tn-counter-content"><?php print t('Views'); ?></div>

					</div>

					<!--#counter wrap -->

				</div>

				<!--#thumb wrap -->

			</div>

			<!--#thumb 4 wrap -->

			<div class="tn-module4-content">

				<div class="tn-module4-meta-tags">

					<div class="tn-category-tags-wrap"><?php print strip_tags(render($content['field_blog_categories']),'<a>'); ?></div>

					<!--category tags -->

					<div class="tn-module4-meta-right tn-tags-date-author">

						<span class="meta-tags-author"><?php print t('by') ?>: <?php print $name; ?></span><!--#meta author-->

					</div>

					<!--#right meta-->

				</div>

				<!--#meta tags wrap-->

				<h3 itemprop="name" class="tn-module-title"><a itemprop="url" href="<?php print $node_url; ?>" rel="bookmark" title="<?php print $title; ?>"><?php print $title; ?></a></h3>

				<!--#module title -->

				<div class="tn-module-excerpt-wrap">

					<div class="tn-module4-date-wrap">

						<a class="tn-hidden-link-left-col" href="<?php print $node_url; ?>"></a><span  class="meta-tags-day"><?php print format_date($node->created,'custom','d'); ?></span><!--#meta day-->

						<meta itemprop="interactionCount" content="UserComments:0"/>

						<span  class="meta-tags-month"><?php print format_date($node->created,'custom','M'); ?></span><!--#meta month-->

					</div>

					<!--#date wrap -->

					<div class="tn-module-excerpt">

					<?php 

						print $summary.'...';

					?>

					</div>

					<div class="tn-read-more-wrap"><a class="tn-read-more"  href="<?php print $node_url; ?>" title="<?php print $title; ?>" rel="bookmark"><?php print t('Read more'); ?></a></div>

					<!--#read more button -->

				</div>

				<!--#module excerpt-->

			</div>

			<!--#module 4 content -->

		</div>

		<!--#module 4 inner -->

	</div>

	<!--#module 4 wrap -->

</div>

<?php }elseif(arg(0) ==  "taxonomy" && arg(1) == "term" && is_numeric(arg(2)) && arg(3) == ""){ ?>

<?php 

	foreach($node->field_blog_categories['und'] as $k => $v){

		$layout = $node->field_blog_categories['und'][$k]['taxonomy_term']->field_layout['und'][0]['value'];

		$term_id = $node->field_blog_categories['und'][$k]['tid'];
		if(isset($node->field_tags['und'][$k]) && !empty($node->field_tags['und'][$k])){
			$tags_id = $node->field_tags['und'][$k]['tid'];

		}

?>	

		<?php if(arg(2) == $term_id && $layout == 'layout1'){?>

			<div class="tn-block6-element">

				<div class="tn-module4-wrap tn-module-wrap clearfix">

					<div class="tn-module4-inner">

						<div class="tn-module4-thumb">

							<div class="tn-thumb-wrap"><?php print theme('image_style', array('path' => $imageone_uri, 'style_name' => 'image_1368x768', 'attributes'=>array('alt'=>$title)));?><a href="<?php print $node_url;?>" title="<?php print $title; ?>" rel="bookmark"></a><?php if($blog_format == 'video' || $blog_format == 'parallax_video'){ ?><span class="tn-post-format"><i class="fa fa-play-circle"></i></span><?php }elseif($blog_format == 'sound_cloud'){ ?><span class="tn-post-format"><i class="fa fa-headphones"></i></span><?php }elseif($blog_format == 'default_gallery' || $blog_format == 'gallery_post'){ ?><span class="tn-post-format"><i class="fa fa-camera"></i></span><?php } ?>

								<div class="tn-meta-thumb-views tn-meta-counter-wrap">

									<div class="tn-counter-num"><?php print $nodevisit['totalcount']; ?></div>

									<!--#counter number-->

									<div class="tn-counter-content"><?php print t('Views'); ?></div>

								</div>

								<!--#counter wrap -->

								</div>

							<!--#thumb wrap -->

							</div>

						<!--#thumb 4 wrap -->

						<div class="tn-module4-content">

							<div class="tn-module4-meta-tags">

								<div class="tn-category-tags-wrap"><?php print render($content['field_blog_categories']); ?></div>

								<!--category tags -->

								<div class="tn-module4-meta-right tn-tags-date-author"><span class="meta-tags-author">by: <?php print $name; ?></span><!--#meta author--></div>

								<!--#right meta-->

							</div>

							<!--#meta tags wrap-->

							<h3 itemprop="name" class="tn-module-title"><a itemprop="url" href="<?php print $node_url; ?>" rel="bookmark" title="<?php print $title; ?>"><?php print $title; ?></a></h3>

							<!--#module title -->

							<div class="tn-module-excerpt-wrap">

								<div class="tn-module4-date-wrap"><a class="tn-hidden-link-left-col" href=""></a><span  class="meta-tags-day"><?php print format_date($node->created, 'custom', 'd'); ?></span><!--#meta day-->

									<meta itemprop="interactionCount" content="UserComments:0"/>

									<span  class="meta-tags-month"><?php print format_date($node->created, 'custom', 'M'); ?></span><!--#meta month--></div>

								<!--#date wrap -->

								<div class="tn-module-excerpt"><?php print $summary.'...'; ?></div>

								<div class="tn-read-more-wrap"><a class="tn-read-more"  href="<?php print $node_url; ?>" title="<?php print $title; ?>" rel="bookmark"><?php print t('Read more'); ?></a>

								</div>

							<!--#read more button -->

							</div>

						<!--#module excerpt-->

						</div>

					<!--#module 4 content -->

					</div>

				<!--#module 4 inner -->

				</div>

			<!--#module 4 wrap -->

			</div>

		<?php }elseif(arg(2) == $term_id && $layout == 'layout2'){?>

			<div class="tn-module1-wrap tn-module-wrap clearfix">

				<div class="tn-module1-inner">

					<div class="tn-module-section module1-section-left col-md-2 hidden-sm hidden-xs">

						<div class="tn-tags-date-author">

							<span  class="meta-tags-date">

							<time itemprop="dateCreated"><?php print format_date($node->created,'custom','F d, Y'); ?></time>

							</span><!--#meta date-->

							<meta itemprop="interactionCount" content="UserComments:0"/>

						</div>

						<div class="tn-category-tags-wrap"><?php print render($content['field_blog_categories']); ?></div>

						<!--category tags -->

						<div class="tn-tags-date-author">

							<span class="meta-tags-author"><?php print t('by'); ?>: <?php print $name; ?></span><!--#meta author-->

						</div>

					</div>

					<!-- left section -->

					<div class="tn-module-section module1-section-center col-md-5 col-sm-6 col-xs-3">

						<div class="tn-thumb-wrap">

							<?php print theme('image_style', array('path' => $imageone_uri, 'style_name' => 'image_370x280', 'attributes'=>array('alt'=>$title)));?><a href="<?php print $node_url; ?>" title="<?php print $title; ?>" rel="bookmark"></a><?php if($blog_format == 'video' || $blog_format == 'parallax_video'){ ?><span class="tn-post-format"><i class="fa fa-play-circle"></i></span><?php }elseif($blog_format == 'sound_cloud'){ ?><span class="tn-post-format"><i class="fa fa-headphones"></i></span><?php }elseif($blog_format == 'default_gallery' || $blog_format == 'gallery_post'){ ?><span class="tn-post-format"><i class="fa fa-camera"></i></span><?php } ?>

							<div class="tn-meta-thumb-views tn-meta-counter-wrap">

								<div class="tn-counter-num"><?php print $nodevisit['totalcount']; ?></div>

								<!--#counter number-->

								<div class="tn-counter-content"><?php print t('Views'); ?></div>

							</div>

							<!--#counter wrap -->

						</div>

						<!--#thumb wrap -->

					</div>

					<!--#center section -->

					<div class="tn-module-section module1-section-right col-md-5 col-sm-6 col-xs-9">

						<h3 itemprop="name" class="tn-module-title"><a itemprop="url" href="<?php print $node_url; ?>" rel="bookmark" title="<?php print $title; ?>"><?php print $title; ?></a></h3>

						<!--#module title -->

						<div class="tn-module-excerpt"><?php print $summary.'...'; ?></div>

						<!--#module excerpt-->

						<div class="tn-read-more-wrap"><a class="tn-read-more"  href="<?php print $node_url; ?>" title="<?php print $title; ?>" rel="bookmark"><?php print t('Read more'); ?></a></div>

						<!--#read more button -->

					</div>

					<!-- right section -->

				</div>

				<!--#module 1 inner -->

			</div>

		<?php }elseif(arg(2) == $term_id && $layout == 'layout3'){?>

			<div class="tn-block5-element col-sm-6 col-sx-12">

				<div class="tn-module3-wrap tn-module-wrap tn-category-11 clearfix">

					<div class="tn-module3-inner">

						<div class="tn-module3-thumb">

							<div class="tn-thumb-wrap">

								<?php print theme('image_style', array('path' => $imageone_uri, 'style_name' => 'image_370x280', 'attributes'=>array('alt'=>$title)));?><a href="<?php print $node_url; ?>" title="<?php print $title; ?>" rel="bookmark"></a><?php if($blog_format == 'video' || $blog_format == 'parallax_video'){ ?><span class="tn-post-format"><i class="fa fa-play-circle"></i></span><?php }elseif($blog_format == 'sound_cloud'){ ?><span class="tn-post-format"><i class="fa fa-headphones"></i></span><?php }elseif($blog_format == 'default_gallery' || $blog_format == 'gallery_post'){ ?><span class="tn-post-format"><i class="fa fa-camera"></i></span><?php } ?>

								<div class="tn-meta-thumb-views tn-meta-counter-wrap">

									<div class="tn-counter-num"><?php print $nodevisit['totalcount']; ?></div>

									<!--#counter number-->

									<div class="tn-counter-content"><?php print t('Views'); ?></div>

								</div>

								<!--#counter wrap -->

							</div>

							<!--#thumb wrap -->

							<div class="tn-read-more-wrap"><a class="tn-read-more"  href="<?php print $node_url; ?>" title="<?php print $title; ?>" rel="bookmark"><?php print t('Read more'); ?></a></div>

							<!--#read more button -->

						</div>

						<!--#thumb 3 wrap -->

						<div class="tn-module3-meta-tags">

							<div class="tn-category-tags-wrap"><?php print render($content['field_blog_categories']); ?></div>

							<!--category tags -->

							<div class="tn-module3-meta-right tn-tags-date-author">

								<span  class="meta-tags-date">

								<time itemprop="dateCreated"><?php print format_date($node->created,'custom','F d, Y'); ?></time>

								</span><!--#meta date-->

								<meta itemprop="interactionCount" content="UserComments:0"/>

								<span class="meta-tags-author"><?php print t('by'); ?>: <?php print $name; ?></span><!--#meta author-->

							</div>

							<!--#right meta-->

						</div>

						<!--#meta tags wrap-->

						<h3 itemprop="name" class="tn-module-title"><a itemprop="url" href="<?php print $node_url; ?>" rel="bookmark" title="<?php print $title; ?>"><?php print $title; ?></a></h3>

						<!--#module title -->

					</div>

					<!--#module 3 inner -->

				</div>

				<!--#module 3 wrap -->

			</div>

		<?php }elseif(arg(2) == $term_id && $layout == 'layout4'){?>

			<div class="tn-module5-wrap tn-module-wrap  clearfix">

				<div class="tn-module5-inner">

					<div class="tn-module-section col-sm-5 col-xs-3">

						<div class="tn-thumb-wrap">

							<?php print theme('image_style', array('path' => $imageone_uri, 'style_name' => 'image_370x280', 'attributes'=>array('alt'=>$title)));?><a href="<?php print $node_url; ?>" title="<?php print $title; ?>" rel="bookmark"></a><?php if($blog_format == 'video' || $blog_format == 'parallax_video'){ ?><span class="tn-post-format"><i class="fa fa-play-circle"></i></span><?php }elseif($blog_format == 'sound_cloud'){ ?><span class="tn-post-format"><i class="fa fa-headphones"></i></span><?php }elseif($blog_format == 'default_gallery' || $blog_format == 'gallery_post'){ ?><span class="tn-post-format"><i class="fa fa-camera"></i></span><?php } ?>

							<div class="tn-meta-thumb-views tn-meta-counter-wrap">

								<div class="tn-counter-num"><?php print $nodevisit['totalcount']; ?></div>

								<!--#counter number-->

								<div class="tn-counter-content"><?php print t('Views'); ?></div>

							</div>

							<!--#counter wrap -->

						</div>

						<!--#thumb wrap -->

					</div>

					<!--#left section-->

					<div class="tn-module-section col-sm-7 col-xs-9">

						<div class="tn-module5-meta-tags">

							<div class="tn-category-tags-wrap"><a class="tn-category-tags" href="" title="Lifestyle">Lifestyle</a></div>

							<!--category tags -->

							<div class="tn-module5-meta-right tn-tags-date-author">

								<span  class="meta-tags-date">

								<time itemprop="dateCreated"><?php print format_date($node->created,'custom','F d, Y'); ?></time>

								</span><!--#meta date-->

								<meta itemprop="interactionCount" content="UserComments:0"/>

								<span class="meta-tags-author"><?php print t('by'); ?>: <?php print $name; ?></span><!--#meta author-->

							</div>

							<!--#right meta-->

						</div>

						<!--#module 5 meta-->

						<h3 itemprop="name" class="tn-module-title"><a itemprop="url" href="<?php print $node_url; ?>" rel="bookmark" title="<?php print $title; ?>"><?php print $title; ?></a></h3>

						<!--#module title -->

						<div class="tn-module-excerpt"><?php print $summary.'...'; ?></div>

						<!--#module excerpt-->

						<div class="tn-read-more-wrap"><a class="tn-read-more"  href="<?php print $node_url; ?>" title="<?php print $title; ?>" rel="bookmark"><?php print t('Read more') ?></a></div>

						<!--#read more button -->

					</div>

					<!-- right section -->

				</div>

				<!--#module 5 inner -->

			</div>

		<?php }elseif(arg(2) == $term_id && $layout == 'layout5'){?>

			<div class="tn-block3-element col-sm-6 col-sx-12">

				<div class="tn-module2-wrap tn-module-wrap  clearfix">

					<div class="tn-module2-inner">

						<div class="tn-thumb-wrap">

							<?php print theme('image_style', array('path' => $imageone_uri, 'style_name' => 'image_370x280', 'attributes'=>array('alt'=>$title)));?><a href="<?php print $node_url; ?>" title="<?php print $title; ?>" rel="bookmark"></a><?php if($blog_format == 'video' || $blog_format == 'parallax_video'){ ?><span class="tn-post-format"><i class="fa fa-play-circle"></i></span><?php }elseif($blog_format == 'sound_cloud'){ ?><span class="tn-post-format"><i class="fa fa-headphones"></i></span><?php }elseif($blog_format == 'default_gallery' || $blog_format == 'gallery_post'){ ?><span class="tn-post-format"><i class="fa fa-camera"></i></span><?php } ?>

							<div class="tn-meta-thumb-views tn-meta-counter-wrap">

								<div class="tn-counter-num"><?php print $nodevisit['totalcount']; ?></div>

								<!--#counter number-->

								<div class="tn-counter-content"><?php print t('Views'); ?></div>

							</div>

							<!--#counter wrap -->

						</div>

						<!--#thumb wrap -->

						<div class="tn-module-meta-tags">

							<div class="tn-category-tags-wrap"><?php print render($content['field_blog_categories']); ?></div>

							<!--category tags -->

							<div class="tn-module-meta tn-tags-date-author">

								<span  class="meta-tags-date">

								<time itemprop="dateCreated"><?php print format_date($node->created, 'custom', 'F d, Y'); ?></time>

								</span><!--#meta date-->

								<meta itemprop="interactionCount" content="UserComments:0"/>

								<span class="meta-tags-author"><?php print t('by'); ?>: <?php print $name; ?></span><!--#meta author-->

							</div>

							<!--meta tags -->

						</div>

						<!--#meta tags wrap-->

						<h3 itemprop="name" class="tn-module-title"><a itemprop="url" href="<?php print $node_url; ?>" rel="bookmark" title="<?php print $title; ?>"><?php print $title; ?></a></h3>

						<!--#module title -->

						<div class="tn-module-excerpt"><?php print $summary.'...'; ?></div>

						<!--#module excerpt-->

						<div class="tn-read-more-wrap"><a class="tn-read-more"  href="<?php print $node_url; ?>" title="<?php print $title; ?>" rel="bookmark"><?php print t('Read more'); ?></a></div>

						<!--#read more button -->

					</div>

					<!--#module 2 inner -->

				</div>

				<!--#module 2 wrap -->

			</div>

		<?php }elseif(isset($tags_id) && arg(2) == $tags_id){ ?>

			<div class="tn-block6-element">

				<div class="tn-module4-wrap tn-module-wrap clearfix">

					<div class="tn-module4-inner">

						<div class="tn-module4-thumb">

							<div class="tn-thumb-wrap">

								<img width="825" height="465"  itemprop="image" src="<?php print $imageone_url; ?>" alt="<?php print $title; ?>" /><a href="<?php print $node_url; ?>" title="<?php print $title; ?>" rel="bookmark"></a>

								<div class="tn-meta-thumb-views tn-meta-counter-wrap">

									<div class="tn-counter-num"><?php print $nodevisit['totalcount'];  ?></div>

									<!--#counter number-->

									<div class="tn-counter-content"><?php print t('Views'); ?></div>

								</div>

								<!--#counter wrap -->

							</div>

							<!--#thumb wrap -->

						</div>

						<!--#thumb 4 wrap -->

						<div class="tn-module4-content">

							<div class="tn-module4-meta-tags">

								<div class="tn-category-tags-wrap"><?php print strip_tags(render($content['field_blog_categories']),'<a>'); ?></div>

								<!--category tags -->

								<div class="tn-module4-meta-right tn-tags-date-author">

									<span class="meta-tags-author"><?php print t('by') ?>: <?php print $name; ?></span><!--#meta author-->

								</div>

								<!--#right meta-->

							</div>

							<!--#meta tags wrap-->

							<h3 itemprop="name" class="tn-module-title"><a itemprop="url" href="<?php print $node_url; ?>" rel="bookmark" title="<?php print $title; ?>"><?php print $title; ?></a></h3>

							<!--#module title -->

							<div class="tn-module-excerpt-wrap">

								<div class="tn-module4-date-wrap">

									<a class="tn-hidden-link-left-col" href="<?php print $node_url; ?>"></a><span  class="meta-tags-day"><?php print format_date($node->created,'custom','d'); ?></span><!--#meta day-->

									<meta itemprop="interactionCount" content="UserComments:0"/>

									<span  class="meta-tags-month"><?php print format_date($node->created,'custom','M'); ?></span><!--#meta month-->

								</div>

								<!--#date wrap -->

								<div class="tn-module-excerpt">

								<?php 

									print $summary.'...';

								?>

								</div>

								<div class="tn-read-more-wrap"><a class="tn-read-more"  href="<?php print $node_url; ?>" title="<?php print $title; ?>" rel="bookmark"><?php print t('Read more'); ?></a></div>

								<!--#read more button -->

							</div>

							<!--#module excerpt-->

						</div>

						<!--#module 4 content -->

					</div>

					<!--#module 4 inner -->

				</div>

				<!--#module 4 wrap -->

			</div>

		<?php } ?>



<?php } ?>

<?php }else{ ?>

<?php 

	$pageURL = 'http';	

 	if(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on'){

 		$pageURL .= "s";

 	}

	$pageURL .= '://';

 	if($_SERVER['SERVER_PORT'] != '80'){

  	$pageURL .= $_SERVER['SERVER_NAME'].":".$_SERVER['SERVER_PORT'].$_SERVER['REQUEST_URI'];

 	}else{

  		$pageURL .= $_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];

 	}

	if($sidebar == 'left' || $sidebar == 'right'){

		$col = 'col-sm-8';

	}else{

		$col = 'col-sm-12';

	}

?>

<?php if($blog_format == 'classic'){ ?>

<?php if($sidebar != 'left' && $sidebar != 'right'){ ?>

<article style="float:left"  class="tn-content-wrap col-sm-12 col-xs-12 post type-post status-publish format-gallery has-post-thumbnail hentry post_format-post-format-gallery">

	<div class="tn-single-title-wrap">

		<h1 itemprop="name" class="tn-single-title"><?php print $title; ?></h1>

		<!--#title-->

	</div>

	<!--#single title -->

	<div class="tn-single-share-wrap tn-single-top-share-wrap">

		<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

			'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

			'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

			'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

	</div>

	<!--#single top share -->

	<div class="tn-single-top-meta-wrap">

		<div class="tn-category-tags-wrap tn-category-10"><?php print strip_tags(render($content['field_blog_categories']),'<a>'); ?></div>
		<span class="tn-single-tags single-meta-right-el"><span class="tn-single-tags-element"><i class="fa fa-tags"></i><?php print strip_tags(render($content['field_tags']),'<a>'); ?></span></span>

		<!--category tags -->

		<div class="tn-single-top-meta-right">

			<span class="tn-single-top-meta-date single-meta-right-el"><i class="fa fa-calendar-o"></i><?php print format_date($node->created,'custom', 'F d, Y'); ?></span>

			<span class="tn-single-top-meta-view-wrap single-meta-right-el">

				<span class="single-top-meta-views-num"><i class="fa fa-heart-o"></i><?php print $nodevisit['totalcount'];  ?></span><!--#top meta views--><span class="single-top-meta-views-content"><?php print t('Views'); ?></span>

			</span>

		</div>

		<!--#top meta right-->

	</div>

	<!--#top meta wrap-->

	<div class="tn-single-thumb-wrap">

		<div class="tn-single-thumb-inner">

			<div class="slider-loading"></div>

			<div id="tn-slider1_562dec8d3d8c9" class="tn-block-slider-wrap tn-slider-init">

				<?php 

					foreach($node->field_image['und'] as $key => $value){

						$image_multi_uri  = $node->field_image['und'][$key]['uri'];

						$image_multi_url = file_create_url($image_multi_uri);

						//print '<div><img width="825" height="465" src="'.$image_multi_url.'" class="attachment-blog_classic_thumb" alt="'.$title.'" /></div>';

						print '<div>'.theme('image_style', array('path' => $image_multi_uri, 'style_name' => 'image_700x500', 'attributes'=>array('class'=>'attachment-blog_classic_thumb','alt'=>$title))).'</div>';

					}

				?>

			</div>

			<!--#single slider-->

		</div>

		<!--#single slider wrap-->

	</div>

	<div class="tn-single-content-wrap row">

		<div class="tn-single-meta-inner col-sm-2 hidden-xs">

			<div class="tn-single-date-wrap">

				<div class="tn-single-date">

					<span  class="single-tags-day"><?php print format_date($node->created,'custom', 'd'); ?></span><!--#meta day-->

					<span  class="single-tags-month"><?php print format_date($node->created,'custom', 'M'); ?></span><!--#meta day-->

				</div>

			</div>

			<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

			<div class="single-tags-author">

				<?php if(isset($author_avatar) && !empty($author_avatar)): ?>

				<img alt='<?php print $author_name; ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-75 photo' height='75' width='75' />

				<?php endif; ?>

				<div class="single-tags-author-content">

					<div class="single-tags-author-content-inner">

						<?php if(isset($author_name) && !empty($author_name)): ?>

						<?php print $author_name; ?>

						<?php endif; ?>

						<?php if(isset($author_description) && !empty($author_description)): ?>

						<div class="single-tags-author-description"><?php print $author_description; ?></div>

						<?php endif; ?>

					</div>

				</div>

				<!--#content-->

			</div>

			<?php endif; ?>

			<!--#tags author-->

			<div class="single-tags-share">

				<i class="fa fa-share single-tags-share-icon"></i>

				<div class="single-tags-share-content">

					<div class="single-tags-share-content-inner">

						<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

					</div>

				</div>

				<!--#content-->

			</div>

			<!--#tags author-->

		</div>

		<!--#single meta-->

		<div class="tn-single-content-inner col-sm-10 col-xs-12">

			<div class="single-post-content">

				<?php print render($content['body'][0]['#markup']); ?>

			</div>

			<!--content-->

		</div>

		<!--#post content inner-->

	</div>

	<!--#post content wrap-->

	<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

	<div class="tn-author-box-wrap clearfix">

		<div class="tn-author-thumb">

		<?php if(isset($author_avatar) && !empty($author_avatar)): ?>

		<img alt='<?php print $author_name ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-105 photo' height='105' width='105' /></div>

		<?php endif; ?>

		<?php if(isset($author_name) && !empty($author_name)): ?>

		<h3 class="author-title"><?php print $author_name ?></h3>

		<?php endif; ?>

		<?php if(isset($author_description) && !empty($author_description)): ?>

		<div class="author-description"><?php print $author_description; ?></div>

		<?php endif; ?>

		<div class="author-social">

			<div class="tn-author-bar-full-box"><?php if(isset($facebook) && !empty($facebook)){ ?><a title="Facebook" href="<?php print $facebook; ?>" target="_blank"><i class="fa fa-facebook color-facebook"></i></a><?php } ?><?php if(isset($twitter) && !empty($twitter)){ ?><a title="Twitter" href="<?php print $twitter; ?>" target="_blank"><i class="fa fa-twitter color-twitter"></i></a><?php } ?><?php if(isset($pinterest) && !empty($pinterest)){ ?><a title="Pinterest" href="<?php print $pinterest ?>" target="_blank"><i class="fa fa-pinterest color-pinterest"></i></a><?php } ?><?php if(isset($linkedin) && !empty($linkedin)){ ?><a title="LinkedIn" href="<?php print $linkedin; ?>" target="_blank"><i class="fa fa-linkedin color-linkedin"></i></a><?php } ?><?php if(isset($flickr) && !empty($flickr)){?><a title="Flickr" href="<?php print $flickr; ?>" target="_blank"><i class="fa fa-flickr color-flickr"></i></a><?php } ?><?php if(isset($tumblr) && !empty($tumblr)){?><a title="Tumblr" href="<?php print $tumblr; ?>" target="_blank"><i class="fa fa-tumblr color-tumblr"></i></a><?php } ?></div>

		</div>

		<!--author-social-->

	</div>



	<?php endif; ?>

	<div class="woocommerce-tabs">

		<div class="panel entry-content" id="tab-reviews">

			<?php print render($content['comments']); ?>

		</div>

	</div>

	<?php if($region['bottom_blog']): ?>

		<?php print render($region['bottom_blog']); ?>

	<?php endif; ?>

</article>

<!--#end section -->

<?php }elseif($sidebar == 'left'){ ?>	

<article style="float:right"  class="tn-content-wrap col-sm-8 col-xs-12 post type-post status-publish format-gallery has-post-thumbnail hentry post_format-post-format-gallery">

	<div class="tn-single-title-wrap">

		<h1 itemprop="name" class="tn-single-title"><?php print $title; ?></h1>

		<!--#title-->

	</div>

	<!--#single title -->

	<div class="tn-single-share-wrap tn-single-top-share-wrap">

		<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

			'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

			'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

			'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

	</div>

	<!--#single top share -->

	<div class="tn-single-top-meta-wrap">

		<div class="tn-category-tags-wrap tn-category-10"><?php print strip_tags(render($content['field_blog_categories']),'<a>'); ?></div>
		<span class="tn-single-tags single-meta-right-el"><span class="tn-single-tags-element"><i class="fa fa-tags"></i><?php print strip_tags(render($content['field_tags']),'<a>'); ?></span></span>

		<!--category tags -->

		<div class="tn-single-top-meta-right">

			<span class="tn-single-top-meta-date single-meta-right-el"><i class="fa fa-calendar-o"></i><?php print format_date($node->created,'custom', 'F d, Y'); ?></span>

			<span class="tn-single-top-meta-view-wrap single-meta-right-el">

				<span class="single-top-meta-views-num"><i class="fa fa-heart-o"></i><?php print $nodevisit['totalcount'];  ?></span><!--#top meta views--><span class="single-top-meta-views-content"><?php print t('Views'); ?></span>

			</span>

		</div>

		<!--#top meta right-->

	</div>

	<!--#top meta wrap-->

	<div class="tn-single-thumb-wrap">

		<div class="tn-single-thumb-inner">

			<div class="slider-loading"></div>

			<div id="tn-slider1_562dec8d3d8c9" class="tn-block-slider-wrap tn-slider-init">

				<?php 

					foreach($node->field_image['und'] as $key => $value){

						$image_multi_uri  = $node->field_image['und'][$key]['uri'];

						$image_multi_url = file_create_url($image_multi_uri);

						//print '<div><img width="825" height="465" src="'.$image_multi_url.'" class="attachment-blog_classic_thumb" alt="'.$title.'" /></div>';

						print '<div>'.theme('image_style', array('path' => $image_multi_uri, 'style_name' => 'image_700x500', 'attributes'=>array('class'=>'attachment-blog_classic_thumb','alt'=>$title))).'</div>';

					}

				?>

			</div>

			<!--#single slider-->

		</div>

		<!--#single slider wrap-->

	</div>

	<div class="tn-single-content-wrap row">

		<div class="tn-single-meta-inner col-sm-2 hidden-xs">

			<div class="tn-single-date-wrap">

				<div class="tn-single-date">

					<span  class="single-tags-day"><?php print format_date($node->created,'custom', 'd'); ?></span><!--#meta day-->

					<span  class="single-tags-month"><?php print format_date($node->created,'custom', 'M'); ?></span><!--#meta day-->

				</div>

			</div>

			<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

			<div class="single-tags-author">

				<?php if(isset($author_avatar) && !empty($author_avatar)): ?>

				<img alt='<?php print $author_name; ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-75 photo' height='75' width='75' />

				<?php endif; ?>

				<div class="single-tags-author-content">

					<div class="single-tags-author-content-inner">

						<?php if(isset($author_name) && !empty($author_name)): ?>

						<?php print $author_name; ?>

						<?php endif; ?>

						<?php if(isset($author_description) && !empty($author_description)): ?>

						<div class="single-tags-author-description"><?php print $author_description; ?></div>

						<?php endif; ?>

					</div>

				</div>

				<!--#content-->

			</div>

			<?php endif; ?>

			<!--#tags author-->

			<div class="single-tags-share">

				<i class="fa fa-share single-tags-share-icon"></i>

				<div class="single-tags-share-content">

					<div class="single-tags-share-content-inner">

						<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

					</div>

				</div>

				<!--#content-->

			</div>

			<!--#tags author-->

		</div>

		<!--#single meta-->

		<div class="tn-single-content-inner col-sm-10 col-xs-12">

			<div class="single-post-content">

				<?php print render($content['body'][0]['#markup']); ?>

			</div>

			<!--content-->

		</div>

		<!--#post content inner-->

	</div>

	<!--#post content wrap-->

	<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

	<div class="tn-author-box-wrap clearfix">

		<div class="tn-author-thumb">

		<?php if(isset($author_avatar) && !empty($author_avatar)): ?>

		<img alt='<?php print $author_name ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-105 photo' height='105' width='105' /></div>

		<?php endif; ?>

		<?php if(isset($author_name) && !empty($author_name)): ?>

		<h3 class="author-title"><?php print $author_name ?></h3>

		<?php endif; ?>

		<?php if(isset($author_description) && !empty($author_description)): ?>

		<div class="author-description"><?php print $author_description; ?></div>

		<?php endif; ?>

		<div class="author-social">

			<div class="tn-author-bar-full-box"><?php if(isset($facebook) && !empty($facebook)){ ?><a title="Facebook" href="<?php print $facebook; ?>" target="_blank"><i class="fa fa-facebook color-facebook"></i></a><?php } ?><?php if(isset($twitter) && !empty($twitter)){ ?><a title="Twitter" href="<?php print $twitter; ?>" target="_blank"><i class="fa fa-twitter color-twitter"></i></a><?php } ?><?php if(isset($pinterest) && !empty($pinterest)){ ?><a title="Pinterest" href="<?php print $pinterest ?>" target="_blank"><i class="fa fa-pinterest color-pinterest"></i></a><?php } ?><?php if(isset($linkedin) && !empty($linkedin)){ ?><a title="LinkedIn" href="<?php print $linkedin; ?>" target="_blank"><i class="fa fa-linkedin color-linkedin"></i></a><?php } ?><?php if(isset($flickr) && !empty($flickr)){?><a title="Flickr" href="<?php print $flickr; ?>" target="_blank"><i class="fa fa-flickr color-flickr"></i></a><?php } ?><?php if(isset($tumblr) && !empty($tumblr)){?><a title="Tumblr" href="<?php print $tumblr; ?>" target="_blank"><i class="fa fa-tumblr color-tumblr"></i></a><?php } ?></div>

		</div>

		<!--author-social-->

	</div>

	<?php endif; ?>

	<div class="woocommerce-tabs">

		<div class="panel entry-content" id="tab-reviews">

			<?php print render($content['comments']); ?>

		</div>

	</div>

	<?php if($region['bottom_blog']): ?>

		<?php print render($region['bottom_blog']); ?>

	<?php endif; ?>

</article>

<?php }elseif($sidebar == 'right'){ ?>

<article style="float:left"  class="tn-content-wrap col-sm-8 col-xs-12 post type-post status-publish format-gallery has-post-thumbnail hentry post_format-post-format-gallery">

	<div class="tn-single-title-wrap">

		<h1 itemprop="name" class="tn-single-title"><?php print $title; ?></h1>

		<!--#title-->

	</div>

	<!--#single title -->

	<div class="tn-single-share-wrap tn-single-top-share-wrap">

		<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

			'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

			'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

			'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

	</div>

	<!--#single top share -->

	<div class="tn-single-top-meta-wrap">

		<div class="tn-category-tags-wrap tn-category-10"><?php print strip_tags(render($content['field_blog_categories']),'<a>'); ?></div>
		<span class="tn-single-tags single-meta-right-el"><span class="tn-single-tags-element"><i class="fa fa-tags"></i><?php print strip_tags(render($content['field_tags']),'<a>'); ?></span></span>

		<!--category tags -->

		<div class="tn-single-top-meta-right">

			<span class="tn-single-top-meta-date single-meta-right-el"><i class="fa fa-calendar-o"></i><?php print format_date($node->created,'custom', 'F d, Y'); ?></span>

			<span class="tn-single-top-meta-view-wrap single-meta-right-el">

				<span class="single-top-meta-views-num"><i class="fa fa-heart-o"></i><?php print $nodevisit['totalcount'];  ?></span><!--#top meta views--><span class="single-top-meta-views-content"><?php print t('Views'); ?></span>

			</span>

		</div>

		<!--#top meta right-->

	</div>

	<!--#top meta wrap-->

	<div class="tn-single-thumb-wrap">

		<div class="tn-single-thumb-inner">

			<div class="slider-loading"></div>

			<div id="tn-slider1_562dec8d3d8c9" class="tn-block-slider-wrap tn-slider-init">

				<?php 

					foreach($node->field_image['und'] as $key => $value){

						$image_multi_uri  = $node->field_image['und'][$key]['uri'];

						$image_multi_url = file_create_url($image_multi_uri);

						//print '<div><img width="825" height="465" src="'.$image_multi_url.'" class="attachment-blog_classic_thumb" alt="'.$title.'" /></div>';

						print '<div>'.theme('image_style', array('path' => $image_multi_uri, 'style_name' => 'image_700x500', 'attributes'=>array('class'=>'attachment-blog_classic_thumb','alt'=>$title))).'</div>';

					}

				?>

			</div>

			<!--#single slider-->

		</div>

		<!--#single slider wrap-->

	</div>

	<div class="tn-single-content-wrap row">

		<div class="tn-single-meta-inner col-sm-2 hidden-xs">

			<div class="tn-single-date-wrap">

				<div class="tn-single-date">

					<span  class="single-tags-day"><?php print format_date($node->created,'custom', 'd'); ?></span><!--#meta day-->

					<span  class="single-tags-month"><?php print format_date($node->created,'custom', 'M'); ?></span><!--#meta day-->

				</div>

			</div>

			<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

			<div class="single-tags-author">

				<?php if(isset($author_avatar) && !empty($author_avatar)): ?>

				<img alt='<?php print $author_name; ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-75 photo' height='75' width='75' />

				<?php endif; ?>

				<div class="single-tags-author-content">

					<div class="single-tags-author-content-inner">

						<?php if(isset($author_name) && !empty($author_name)): ?>

						<?php print $author_name; ?>

						<?php endif; ?>

						<?php if(isset($author_description) && !empty($author_description)): ?>

						<div class="single-tags-author-description"><?php print $author_description; ?></div>

						<?php endif; ?>

					</div>

				</div>

				<!--#content-->

			</div>

			<?php endif; ?>

			<!--#tags author-->

			<div class="single-tags-share">

				<i class="fa fa-share single-tags-share-icon"></i>

				<div class="single-tags-share-content">

					<div class="single-tags-share-content-inner">

						<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

					</div>

				</div>

				<!--#content-->

			</div>

			<!--#tags author-->

		</div>

		<!--#single meta-->

		<div class="tn-single-content-inner col-sm-10 col-xs-12">

			<div class="single-post-content">

				<?php print render($content['body'][0]['#markup']); ?>

			</div>

			<!--content-->

		</div>

		<!--#post content inner-->

	</div>

	<!--#post content wrap-->

	<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

	<div class="tn-author-box-wrap clearfix">

		<div class="tn-author-thumb">

		<?php if(isset($author_avatar) && !empty($author_avatar)): ?>

		<img alt='<?php print $author_name ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-105 photo' height='105' width='105' /></div>

		<?php endif; ?>

		<?php if(isset($author_name) && !empty($author_name)): ?>

		<h3 class="author-title"><?php print $author_name ?></h3>

		<?php endif; ?>

		<?php if(isset($author_description) && !empty($author_description)): ?>

		<div class="author-description"><?php print $author_description; ?></div>

		<?php endif; ?>

		<div class="author-social">

			<div class="tn-author-bar-full-box"><?php if(isset($facebook) && !empty($facebook)){ ?><a title="Facebook" href="<?php print $facebook; ?>" target="_blank"><i class="fa fa-facebook color-facebook"></i></a><?php } ?><?php if(isset($twitter) && !empty($twitter)){ ?><a title="Twitter" href="<?php print $twitter; ?>" target="_blank"><i class="fa fa-twitter color-twitter"></i></a><?php } ?><?php if(isset($pinterest) && !empty($pinterest)){ ?><a title="Pinterest" href="<?php print $pinterest ?>" target="_blank"><i class="fa fa-pinterest color-pinterest"></i></a><?php } ?><?php if(isset($linkedin) && !empty($linkedin)){ ?><a title="LinkedIn" href="<?php print $linkedin; ?>" target="_blank"><i class="fa fa-linkedin color-linkedin"></i></a><?php } ?><?php if(isset($flickr) && !empty($flickr)){?><a title="Flickr" href="<?php print $flickr; ?>" target="_blank"><i class="fa fa-flickr color-flickr"></i></a><?php } ?><?php if(isset($tumblr) && !empty($tumblr)){?><a title="Tumblr" href="<?php print $tumblr; ?>" target="_blank"><i class="fa fa-tumblr color-tumblr"></i></a><?php } ?></div>

		</div>

		<!--author-social-->

	</div>

	<?php endif; ?>

	<div class="woocommerce-tabs">

		<div class="panel entry-content" id="tab-reviews">

			<?php print render($content['comments']); ?>

		</div>

	</div>

	<?php if($region['bottom_blog']): ?>

		<?php print render($region['bottom_blog']); ?>

	<?php endif; ?>

</article>

<?php } ?>

<?php }elseif($blog_format == 'default_gallery'){//default gallery ?>

<article <?php if($sidebar == 'right'){ ?>style="float:left"<?php }elseif($sidebar == 'left'){ ?>style="float:right"<?php } ?> class="tn-content-wrap tn-fw-mode <?php print $col; ?> col-xs-12 post type-post status-publish has-post-thumbnail hentry" itemscope itemtype="http://schema.org/Article">

	<div class="tn-single-share-wrap tn-single-top-share-wrap">

			<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

	</div>

	<!--#single top share -->

	<div class="tn-single-content-wrap tn-single-no-left-col">

		<div class="tn-single-content-inner">

			<div class="single-post-content">

				<?php print render($content['body'][0]['#markup']); ?>

			</div>

			<!--content-->

		</div>

		<!--#post content inner-->

	</div>

	<!--#post content wrap-->

	<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

	<div class="tn-author-box-wrap clearfix">

		<?php if(isset($author_avatar_url) && !empty($author_avatar_url)): ?>

		<div class="tn-author-thumb"><img alt='<?php print $author_name; ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-105 photo' height='105' width='105' /></div>

		<?php endif; ?>

		<?php if(isset($author_name) && !empty($author_name)): ?>

		<h3 class="author-title"><?php print $author_name; ?></h3>

		<?php endif; ?>

		<?php if(isset($author_description) && !empty($author_description)): ?>

		<div class="author-description"><?php print $author_description; ?></div>

		<?php endif; ?>

		<div class="author-social">

			<div class="tn-author-bar-full-box"><?php if(isset($facebook) && !empty($facebook)){ ?><a title="Facebook" href="<?php print $facebook; ?>" target="_blank"><i class="fa fa-facebook color-facebook"></i></a><?php } ?><?php if(isset($twitter) && !empty($twitter)){ ?><a title="Twitter" href="<?php print $twitter; ?>" target="_blank"><i class="fa fa-twitter color-twitter"></i></a><?php } ?><?php if(isset($pinterest) && !empty($pinterest)){ ?><a title="Pinterest" href="<?php print $pinterest ?>" target="_blank"><i class="fa fa-pinterest color-pinterest"></i></a><?php } ?><?php if(isset($linkedin) && !empty($linkedin)){ ?><a title="LinkedIn" href="<?php print $linkedin; ?>" target="_blank"><i class="fa fa-linkedin color-linkedin"></i></a><?php } ?><?php if(isset($flickr) && !empty($flickr)){?><a title="Flickr" href="<?php print $flickr; ?>" target="_blank"><i class="fa fa-flickr color-flickr"></i></a><?php } ?><?php if(isset($tumblr) && !empty($tumblr)){?><a title="Tumblr" href="<?php print $tumblr; ?>" target="_blank"><i class="fa fa-tumblr color-tumblr"></i></a><?php } ?></div>

		</div>

		<!--author-social-->

	</div>

	<!--#author box -->

	<?php endif; ?>

	<div class="woocommerce-tabs">

		<div class="panel entry-content" id="tab-reviews">

			<?php print render($content['comments']); ?>

		</div>

	</div>

	<?php if($region['bottom_blog']): ?>

	<?php print render($region['bottom_blog']); ?>

	<?php endif; ?>

</article>

<?php }elseif($blog_format == 'gallery_post'){ //gallery post?>

<article <?php if($sidebar == 'right'){ ?> style="float:left"<?php }elseif($sidebar == 'left'){ ?>style="float:right"<?php } ?> class="tn-content-wrap <?php print $col; ?> col-xs-12 post type-post status-publish format-audio has-post-thumbnail hentry " itemscope itemtype="http://schema.org/Article">

	<!--#single title -->

	<div class="tn-single-share-wrap tn-single-top-share-wrap">

			<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

	</div>

	<!--#single top share -->

	<div class="tn-single-top-meta-wrap">

		<div class="tn-category-tags-wrap"><?php print strip_tags(render($content['field_blog_categories']),'<a>'); ?></div>
		<span class="tn-single-tags single-meta-right-el"><span class="tn-single-tags-element"><i class="fa fa-tags"></i><?php print strip_tags(render($content['field_tags']),'<a>'); ?></span></span>
		<!--category tags -->

		<div class="tn-single-top-meta-right">

			<span class="tn-single-top-meta-date single-meta-right-el"><i class="fa fa-calendar-o"></i><?php print format_date($node->created, 'custom','F d, Y'); ?></span>

			<span class="tn-single-top-meta-view-wrap single-meta-right-el">

				<span class="single-top-meta-views-num"><i class="fa fa-heart-o"></i><?php print $nodevisit['totalcount']; ?></span><!--#top meta views--><span class="single-top-meta-views-content"><?php print t('Views'); ?></span>

			</span>

		</div>

		<!--#top meta right-->

	</div>

	<!--#top meta wrap-->

	<!--#thumb & audio wrap -->

	<div class="tn-single-content-wrap row">

		<div class="tn-single-meta-inner col-sm-2 hidden-xs">

			<div class="tn-single-date-wrap">

				<div class="tn-single-date">

					<span class="single-tags-day"><?php print format_date($node->created, 'custom','d'); ?></span><!--#meta day-->

					<span class="single-tags-month"><?php print format_date($node->created, 'custom','M'); ?></span><!--#meta day-->

				</div>

			</div>

			<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

			<div class="single-tags-author">

				<?php if(isset($author_avatar) && !empty($author_avatar)): ?>

				<img alt='<?php print $author_name; ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-75 photo' height='75' width='75' />

				<?php endif; ?>

				<div class="single-tags-author-content">

					<div class="single-tags-author-content-inner">

						<?php if(isset($author_name) && !empty($author_name)): ?>

						<?php print $author_name; ?>

						<?php endif; ?>

						<?php if(isset($author_description) && !empty($author_description)): ?>

						<div class="single-tags-author-description"><?php print $author_description; ?></div>

						<?php endif; ?>

					</div>

				</div>

				<!--#content-->

			</div>

			<?php endif; ?>

			<!--#tags author-->

			<div class="single-tags-share">

				<i class="fa fa-share single-tags-share-icon"></i>

				<div class="single-tags-share-content">

					<div class="single-tags-share-content-inner">

						<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

					</div>

				</div>

				<!--#content-->

			</div>

			<!--#tags author-->

		</div>

		<!--#single meta-->

		<div class="tn-single-content-inner col-sm-10 col-xs-12">

			<div class="single-post-content">

				<?php print render($content['body'][0]['#markup']); ?>

			</div>

			<!--content-->

		</div>

		<!--#post content inner-->

	</div>

	<!--#post content wrap-->

	<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

	<div class="tn-author-box-wrap clearfix">

		<?php if(isset($author_avatar_url) && !empty($author_avatar_url)): ?>

		<div class="tn-author-thumb"><img alt='<?php print $author_name; ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-105 photo' height='105' width='105' /></div>

		<?php endif; ?>

		<?php if(isset($author_name) && !empty($author_name)): ?>

		<h3 class="author-title"><?php print $author_name; ?></h3>

		<?php endif; ?>

		<?php if(isset($author_description) && !empty($author_description)): ?>

		<div class="author-description"><?php print $author_description; ?></div>

		<?php endif; ?>

		<div class="author-social">

			<div class="tn-author-bar-full-box"><?php if(isset($facebook) && !empty($facebook)){ ?><a title="Facebook" href="<?php print $facebook; ?>" target="_blank"><i class="fa fa-facebook color-facebook"></i></a><?php } ?><?php if(isset($twitter) && !empty($twitter)){ ?><a title="Twitter" href="<?php print $twitter; ?>" target="_blank"><i class="fa fa-twitter color-twitter"></i></a><?php } ?><?php if(isset($pinterest) && !empty($pinterest)){ ?><a title="Pinterest" href="<?php print $pinterest ?>" target="_blank"><i class="fa fa-pinterest color-pinterest"></i></a><?php } ?><?php if(isset($linkedin) && !empty($linkedin)){ ?><a title="LinkedIn" href="<?php print $linkedin; ?>" target="_blank"><i class="fa fa-linkedin color-linkedin"></i></a><?php } ?><?php if(isset($flickr) && !empty($flickr)){?><a title="Flickr" href="<?php print $flickr; ?>" target="_blank"><i class="fa fa-flickr color-flickr"></i></a><?php } ?><?php if(isset($tumblr) && !empty($tumblr)){?><a title="Tumblr" href="<?php print $tumblr; ?>" target="_blank"><i class="fa fa-tumblr color-tumblr"></i></a><?php } ?></div>

		</div>

		<!--author-social-->

	</div>

	<!--#author box -->

	<?php endif; ?>

	<div class="woocommerce-tabs">

		<div class="panel entry-content" id="tab-reviews">

			<?php print render($content['comments']); ?>

		</div>

	</div>

	<?php if($region['bottom_blog']): ?>

		<?php print render($region['bottom_blog']); ?>

	<?php endif; ?>

</article>

<?php }elseif($blog_format == 'parallax_video'){ ?>

<article <?php if($sidebar == 'right'){ ?>style="float:left"<?php }elseif($sidebar == 'left'){ ?>style="float:right"<?php } ?> class="tn-content-wrap <?php print $col; ?> col-xs-12 post type-post status-publish format-audio has-post-thumbnail hentry " itemscope itemtype="http://schema.org/Article">

	<!--#single title -->

	<div class="tn-single-share-wrap tn-single-top-share-wrap">

		<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

						'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

						'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

						'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

	</div>

	<!--#single top share -->

	<div class="tn-single-top-meta-wrap">

		<div class="tn-category-tags-wrap"><?php print strip_tags(render($content['field_blog_categories']),'<a>'); ?></div>
		<span class="tn-single-tags single-meta-right-el"><span class="tn-single-tags-element"><i class="fa fa-tags"></i><?php print strip_tags(render($content['field_tags']),'<a>'); ?></span></span>
		<!--category tags -->

		<div class="tn-single-top-meta-right">

			<span class="tn-single-top-meta-date single-meta-right-el"><i class="fa fa-calendar-o"></i><?php print format_date($node->created, 'custom','F d, Y'); ?></span>

			<span class="tn-single-top-meta-view-wrap single-meta-right-el">

				<span class="single-top-meta-views-num"><i class="fa fa-heart-o"></i><?php print $nodevisit['totalcount']; ?></span><!--#top meta views--><span class="single-top-meta-views-content"><?php print t('Views'); ?></span>

			</span>

		</div>

		<!--#top meta right-->

	</div>

	<!--#top meta wrap-->

	<!--#thumb & audio wrap -->

	<div class="tn-single-content-wrap row">

		<div class="tn-single-meta-inner col-sm-2 hidden-xs">

			<div class="tn-single-date-wrap">

				<div class="tn-single-date">

					<span  class="single-tags-day"><?php print format_date($node->created, 'custom','d'); ?></span><!--#meta day-->

					<meta itemprop="interactionCount" content="UserComments:0"/>

					<span  class="single-tags-month"><?php print format_date($node->created, 'custom','M'); ?></span><!--#meta day-->

				</div>

			</div>

			<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

			<div class="single-tags-author">

				<?php if(isset($author_avatar) && !empty($author_avatar)): ?>

				<img alt='<?php print $author_name; ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-75 photo' height='75' width='75' />

				<?php endif; ?>

				<div class="single-tags-author-content">

					<div class="single-tags-author-content-inner">

						<?php if(isset($author_name) && !empty($author_name)): ?>

						<?php print $author_name; ?>

						<?php endif; ?>

						<?php if(isset($author_description) && !empty($author_description)): ?>

						<div class="single-tags-author-description"><?php print $author_description; ?></div>

						<?php endif; ?>

					</div>

				</div>

				<!--#content-->

			</div>

			<?php endif; ?>

			<!--#tags author-->

			<div class="single-tags-share">

				<i class="fa fa-share single-tags-share-icon"></i>

				<div class="single-tags-share-content">

					<div class="single-tags-share-content-inner">

						<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

					</div>

				</div>

				<!--#content-->

			</div>

			<!--#tags author-->

		</div>

		<!--#single meta-->

		<div class="tn-single-content-inner col-sm-10 col-xs-12">

			<div class="single-post-content">

				<?php print render($content['body'][0]['#markup']); ?>

			</div>

			<!--content-->

		</div>

		<!--#post content inner-->

	</div>

	<!--#post content wrap-->

	<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

	<div class="tn-author-box-wrap clearfix">

		<?php if(isset($author_avatar_url) && !empty($author_avatar_url)): ?>

		<div class="tn-author-thumb"><img alt='<?php print $author_name; ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-105 photo' height='105' width='105' /></div>

		<?php endif; ?>

		<?php if(isset($author_name) && !empty($author_name)): ?>

		<h3 class="author-title"><?php print $author_name; ?></h3>

		<?php endif; ?>

		<?php if(isset($author_description) && !empty($author_description)): ?>

		<div class="author-description"><?php print $author_description; ?></div>

		<?php endif; ?>

		<div class="author-social">

			<div class="tn-author-bar-full-box"><?php if(isset($facebook) && !empty($facebook)){ ?><a title="Facebook" href="<?php print $facebook; ?>" target="_blank"><i class="fa fa-facebook color-facebook"></i></a><?php } ?><?php if(isset($twitter) && !empty($twitter)){ ?><a title="Twitter" href="<?php print $twitter; ?>" target="_blank"><i class="fa fa-twitter color-twitter"></i></a><?php } ?><?php if(isset($pinterest) && !empty($pinterest)){ ?><a title="Pinterest" href="<?php print $pinterest ?>" target="_blank"><i class="fa fa-pinterest color-pinterest"></i></a><?php } ?><?php if(isset($linkedin) && !empty($linkedin)){ ?><a title="LinkedIn" href="<?php print $linkedin; ?>" target="_blank"><i class="fa fa-linkedin color-linkedin"></i></a><?php } ?><?php if(isset($flickr) && !empty($flickr)){?><a title="Flickr" href="<?php print $flickr; ?>" target="_blank"><i class="fa fa-flickr color-flickr"></i></a><?php } ?><?php if(isset($tumblr) && !empty($tumblr)){?><a title="Tumblr" href="<?php print $tumblr; ?>" target="_blank"><i class="fa fa-tumblr color-tumblr"></i></a><?php } ?></div>

		</div>

		<!--author-social-->

	</div>

	<!--#author box -->

	<?php endif; ?>

	<div class="woocommerce-tabs">

		<div class="panel entry-content" id="tab-reviews">

			<?php print render($content['comments']); ?>

		</div>

	</div>

	<?php if($region['bottom_blog']): ?>

		<?php print render($region['bottom_blog']); ?>

	<?php endif; ?>

</article>

<?php }elseif($blog_format == 'video'){ ?>

<article <?php if($sidebar == 'right'){ ?>style="float:left"<?php }elseif($sidebar == 'left'){ ?>style="float:right"<?php } ?> class="tn-content-wrap <?php print $col; ?> col-xs-12 post type-post status-publish format-audio has-post-thumbnail hentry " itemscope itemtype="http://schema.org/Article">

	<div class="tn-single-title-wrap">

		<h1 itemprop="name" class="tn-single-title"><?php print $title; ?></h1>

		<!--#title-->

	</div>

	<!--#single title -->

	<div class="tn-single-share-wrap tn-single-top-share-wrap">

		<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

						'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

						'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

						'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

	</div>

	<!--#single top share -->

	<div class="tn-single-top-meta-wrap">

		<div class="tn-category-tags-wrap"><?php print strip_tags(render($content['field_blog_categories']),'<a>'); ?></div>
		<span class="tn-single-tags single-meta-right-el"><span class="tn-single-tags-element"><i class="fa fa-tags"></i><?php print strip_tags(render($content['field_tags']),'<a>'); ?></span></span>
		<!--category tags -->

		<div class="tn-single-top-meta-right">

			<span class="tn-single-top-meta-date single-meta-right-el"><i class="fa fa-calendar-o"></i><?php print format_date($node->created, 'custom','F d, Y'); ?></span>

			<span class="tn-single-top-meta-view-wrap single-meta-right-el">

				<span class="single-top-meta-views-num"><i class="fa fa-heart-o"></i><?php print $nodevisit['totalcount']; ?></span><!--#top meta views--><span class="single-top-meta-views-content"><?php print t('Views'); ?></span>

			</span>

		</div>

		<!--#top meta right-->

	</div>

	<!--#top meta wrap-->



	<div class="tn-video-wrap tn-single-thumb-wrap">

	<?php print render($content['field_video_embed']); ?>

	</div>

	<!--#thumb & audio wrap -->

	<div class="tn-single-content-wrap row">

		<div class="tn-single-meta-inner col-sm-2 hidden-xs">

			<div class="tn-single-date-wrap">

				<div class="tn-single-date">

					<span  class="single-tags-day"><?php print format_date($node->created, 'custom','d'); ?></span><!--#meta day-->

					<meta itemprop="interactionCount" content="UserComments:0"/>

					<span  class="single-tags-month"><?php print format_date($node->created, 'custom','M'); ?></span><!--#meta day-->

				</div>

			</div>

			<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

			<div class="single-tags-author">

				<?php if(isset($author_avatar) && !empty($author_avatar)): ?>

				<img alt='<?php print $author_name; ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-75 photo' height='75' width='75' />

				<?php endif; ?>

				<div class="single-tags-author-content">

					<div class="single-tags-author-content-inner">

						<?php if(isset($author_name) && !empty($author_name)): ?>

						<?php print $author_name; ?>

						<?php endif; ?>

						<?php if(isset($author_description) && !empty($author_description)): ?>

						<div class="single-tags-author-description"><?php print $author_description; ?></div>

						<?php endif; ?>

					</div>

				</div>

				<!--#content-->

			</div>

			<?php endif; ?>

			<!--#tags author-->

			<div class="single-tags-share">

				<i class="fa fa-share single-tags-share-icon"></i>

				<div class="single-tags-share-content">

					<div class="single-tags-share-content-inner">

						<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

					</div>

				</div>

				<!--#content-->

			</div>

			<!--#tags author-->

		</div>

		<!--#single meta-->

		<div class="tn-single-content-inner col-sm-10 col-xs-12">

			<div class="single-post-content">

			<?php print render($content['body'][0]['#markup']); ?>

			</div>

			<!--content-->

		</div>

		<!--#post content inner-->

	</div>

	<!--#post content wrap-->

	<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

	<div class="tn-author-box-wrap clearfix">

		<?php if(isset($author_avatar_url) && !empty($author_avatar_url)): ?>

		<div class="tn-author-thumb"><img alt='<?php print $author_name; ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-105 photo' height='105' width='105' /></div>

		<?php endif; ?>

		<?php if(isset($author_name) && !empty($author_name)): ?>

		<h3 class="author-title"><?php print $author_name; ?></h3>

		<?php endif; ?>

		<?php if(isset($author_description) && !empty($author_description)): ?>

		<div class="author-description"><?php print $author_description; ?></div>

		<?php endif; ?>

		<div class="author-social">

			<div class="tn-author-bar-full-box"><?php if(isset($facebook) && !empty($facebook)){ ?><a title="Facebook" href="<?php print $facebook; ?>" target="_blank"><i class="fa fa-facebook color-facebook"></i></a><?php } ?><?php if(isset($twitter) && !empty($twitter)){ ?><a title="Twitter" href="<?php print $twitter; ?>" target="_blank"><i class="fa fa-twitter color-twitter"></i></a><?php } ?><?php if(isset($pinterest) && !empty($pinterest)){ ?><a title="Pinterest" href="<?php print $pinterest ?>" target="_blank"><i class="fa fa-pinterest color-pinterest"></i></a><?php } ?><?php if(isset($linkedin) && !empty($linkedin)){ ?><a title="LinkedIn" href="<?php print $linkedin; ?>" target="_blank"><i class="fa fa-linkedin color-linkedin"></i></a><?php } ?><?php if(isset($flickr) && !empty($flickr)){?><a title="Flickr" href="<?php print $flickr; ?>" target="_blank"><i class="fa fa-flickr color-flickr"></i></a><?php } ?><?php if(isset($tumblr) && !empty($tumblr)){?><a title="Tumblr" href="<?php print $tumblr; ?>" target="_blank"><i class="fa fa-tumblr color-tumblr"></i></a><?php } ?></div>

		</div>

		<!--author-social-->

	</div>

	<!--#author box -->

	<?php endif; ?>

	<div class="woocommerce-tabs">

		<div class="panel entry-content" id="tab-reviews">

			<?php print render($content['comments']); ?>

		</div>

	</div>

	<?php if($region['bottom_blog']): ?>

		<?php print render($region['bottom_blog']); ?>

	<?php endif; ?>

</article>

<?php }elseif($blog_format == 'sound_cloud'){ ?>

<article <?php if($sidebar == 'right'){ ?>style="float:left"<?php }elseif($sidebar == 'left'){ ?>style="float:right"<?php } ?> class="tn-content-wrap <?php print $col; ?> col-xs-12 post type-post status-publish format-audio has-post-thumbnail hentry " itemscope itemtype="http://schema.org/Article">

	<div class="tn-single-title-wrap">

		<h1 itemprop="name" class="tn-single-title"><?php print $title; ?></h1>

		<!--#title-->

	</div>

	<!--#single title -->

	<div class="tn-single-share-wrap tn-single-top-share-wrap">

		<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

						'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

						'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

						'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

	</div>

	<!--#single top share -->

	<div class="tn-single-top-meta-wrap">
		<div style="float:left">
		<div class="tn-category-tags-wrap"><?php print strip_tags(render($content['field_blog_categories']),'<a>'); ?></div>
		<span class="tn-single-tags single-meta-right-el"><span class="tn-single-tags-element"><i class="fa fa-tags"></i><?php print strip_tags(render($content['field_tags']),'<a>'); ?></span></span>
		<!--category tags -->
		</div>
		<div class="tn-single-top-meta-right">

			<span class="tn-single-top-meta-date single-meta-right-el"><i class="fa fa-calendar-o"></i><?php print format_date($node->created, 'custom','F d, Y'); ?></span>

			<span class="tn-single-top-meta-view-wrap single-meta-right-el">

				<span class="single-top-meta-views-num"><i class="fa fa-heart-o"></i><?php print $nodevisit['totalcount']; ?></span><!--#top meta views--><span class="single-top-meta-views-content"><?php print t('Views'); ?></span>

			</span>

		</div>

		<!--#top meta right-->

	</div>

	<!--#top meta wrap-->



	<div class="tn-single-thumb-wrap">

		<div class="tn-single-thumb-inner">

			<?php if($imageone_uri){ ?>

			<?php print theme('image_style', array('path' => $imageone_uri, 'style_name' => 'image_1368x768', 'attributes'=>array('class'=>'attachment-blog_classic_thumb','alt'=>$title)));?>

			<?php } ?>

			<div class="tn-audio-wrap">

				<?php print render($content['field_sound_cloud']); ?>

			</div>

		</div>

	</div>

	<!--#thumb & audio wrap -->

	<div class="tn-single-content-wrap row">

		<div class="tn-single-meta-inner col-sm-2 hidden-xs">

			<div class="tn-single-date-wrap">

				<div class="tn-single-date">

					<span  class="single-tags-day"><?php print format_date($node->created, 'custom','d'); ?></span><!--#meta day-->

					<meta itemprop="interactionCount" content="UserComments:0"/>

					<span  class="single-tags-month"><?php print format_date($node->created, 'custom','M'); ?></span><!--#meta day-->

				</div>

			</div>

			<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

			<div class="single-tags-author">

				<?php if(isset($author_avatar) && !empty($author_avatar)): ?>

				<img alt='<?php print $author_name; ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-75 photo' height='75' width='75' />

				<?php endif; ?>

				<div class="single-tags-author-content">

					<div class="single-tags-author-content-inner">

						<?php if(isset($author_name) && !empty($author_name)): ?>

						<?php print $author_name; ?>

						<?php endif; ?>

						<?php if(isset($author_description) && !empty($author_description)): ?>

						<div class="single-tags-author-description"><?php print $author_description; ?></div>

						<?php endif; ?>

					</div>

				</div>

				<!--#content-->

			</div>

			<?php endif; ?>

			<!--#tags author-->

			<div class="single-tags-share">

				<i class="fa fa-share single-tags-share-icon"></i>

				<div class="single-tags-share-content">

					<div class="single-tags-share-content-inner">

						<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

					</div>

				</div>

				<!--#content-->

			</div>

		</div>

		<!--#single meta-->

		<div class="tn-single-content-inner col-sm-10 col-xs-12">

			<div class="single-post-content">

			<?php print render($content['body'][0]['#markup']) ?>

			</div>

			<!--content-->

		</div>

		<!--#post content inner-->

	</div>

	<!--#post content wrap-->

	<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

	<div class="tn-author-box-wrap clearfix">

		<?php if(isset($author_avatar_url) && !empty($author_avatar_url)): ?>

		<div class="tn-author-thumb"><img alt='<?php print $author_name; ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-105 photo' height='105' width='105' /></div>

		<?php endif; ?>

		<?php if(isset($author_name) && !empty($author_name)): ?>

		<h3 class="author-title"><?php print $author_name; ?></h3>

		<?php endif; ?>

		<?php if(isset($author_description) && !empty($author_description)): ?>

		<div class="author-description"><?php print $author_description; ?></div>

		<?php endif; ?>

		<div class="author-social">

			<div class="tn-author-bar-full-box"><?php if(isset($facebook) && !empty($facebook)){ ?><a title="Facebook" href="<?php print $facebook; ?>" target="_blank"><i class="fa fa-facebook color-facebook"></i></a><?php } ?><?php if(isset($twitter) && !empty($twitter)){ ?><a title="Twitter" href="<?php print $twitter; ?>" target="_blank"><i class="fa fa-twitter color-twitter"></i></a><?php } ?><?php if(isset($pinterest) && !empty($pinterest)){ ?><a title="Pinterest" href="<?php print $pinterest ?>" target="_blank"><i class="fa fa-pinterest color-pinterest"></i></a><?php } ?><?php if(isset($linkedin) && !empty($linkedin)){ ?><a title="LinkedIn" href="<?php print $linkedin; ?>" target="_blank"><i class="fa fa-linkedin color-linkedin"></i></a><?php } ?><?php if(isset($flickr) && !empty($flickr)){?><a title="Flickr" href="<?php print $flickr; ?>" target="_blank"><i class="fa fa-flickr color-flickr"></i></a><?php } ?><?php if(isset($tumblr) && !empty($tumblr)){?><a title="Tumblr" href="<?php print $tumblr; ?>" target="_blank"><i class="fa fa-tumblr color-tumblr"></i></a><?php } ?></div>

		</div>

		<!--author-social-->

	</div>

	<!--#author box -->

	<?php endif; ?>

	<div class="woocommerce-tabs">

		<div class="panel entry-content" id="tab-reviews">

			<?php print render($content['comments']); ?>

		</div>

	</div>

	<?php if($region['bottom_blog']): ?>

		<?php print render($region['bottom_blog']); ?>

	<?php endif; ?>

</article>

<?php }elseif($blog_format == 'parallax_without_title'){ ?>

<article <?php if($sidebar == 'right'){ ?>style="float:left"<?php }elseif($sidebar == 'left'){ ?>style="float:right"<?php } ?> class="tn-content-wrap tn-fw-mode <?php print $col; ?> col-xs-12 post type-post status-publish format-standard has-post-thumbnail hentry">

	<div class="tn-single-top-meta-wrap">

		<div class="tn-category-tags-wrap"><?php print strip_tags(render($content['field_blog_categories']),'<a>') ?></div>

		<!--category tags -->

		<div class="tn-single-top-meta-right"><span class="tn-single-top-meta-date disable-left-col single-meta-right-el"><i class="fa fa-calendar-o"></i><?php print format_date($node->created,'custom','F d, Y'); ?></span><span class="tn-single-top-meta-view-wrap single-meta-right-el"><span class="single-top-meta-views-num"><i class="fa fa-heart-o"></i><?php print $nodevisit['totalcount'];?></span><!--#top meta views--><span class="single-top-meta-views-content"><?php print t('Views'); ?></span></span>

		</div>

		<!--#top meta right--></div>

	<!--#top meta wrap-->

	<div class="tn-single-title-wrap">

		<h1 itemprop="name" class="tn-single-title"><?php print $title; ?></h1>

		<!--#title-->

	</div>

	<!--#single title -->

	<div class="tn-single-share-wrap tn-single-top-share-wrap">

		

		<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL;?>" onclick="window.open(this.href, 'mywin',

'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL;?>" onclick="window.open(this.href, 'mywin',

'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://www.plus.google.com/share?url=<?php print $pageURL;?>" onclick="window.open(this.href, 'mywin',

'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

	</div>

	<!--#single top share -->

	<div class="tn-single-content-wrap tn-single-no-left-col">

		<div class="tn-single-content-inner">

			<div class="single-post-content">

			<?php

				print render($content['body'][0]['#markup']);

			?>

			</div>

			<!--content-->

		</div>

		<!--#post content inner-->

	</div>

	<!--#post content wrap-->

	<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

	<div class="tn-author-box-wrap clearfix">

		<div class="tn-author-thumb"><img alt='<?php print $author_name; ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-105 photo' height='105' width='105' /></div>

		<?php if(isset($author_name) && !empty($author_name)): ?>

		<h3 class="author-title"><?php print $author_name;?></h3>

		<?php endif; ?>

		<?php if(isset($author_description) && !empty($author_description)): ?>



		<div class="author-description"><?php print $author_description; ?></div>

		<?php endif; ?>

		<div class="author-social">

			<div class="tn-author-bar-full-box"><?php if(isset($facebook) && !empty($facebook)){ ?><a title="Facebook" href="<?php print $facebook; ?>" target="_blank"><i class="fa fa-facebook color-facebook"></i></a><?php } ?><?php if(isset($twitter) && !empty($twitter)){ ?><a title="Twitter" href="<?php print $twitter; ?>" target="_blank"><i class="fa fa-twitter color-twitter"></i></a><?php } ?><?php if(isset($pinterest) && !empty($pinterest)){ ?><a title="Pinterest" href="<?php print $pinterest ?>" target="_blank"><i class="fa fa-pinterest color-pinterest"></i></a><?php } ?><?php if(isset($linkedin) && !empty($linkedin)){ ?><a title="LinkedIn" href="<?php print $linkedin; ?>" target="_blank"><i class="fa fa-linkedin color-linkedin"></i></a><?php } ?><?php if(isset($flickr) && !empty($flickr)){?><a title="Flickr" href="<?php print $flickr; ?>" target="_blank"><i class="fa fa-flickr color-flickr"></i></a><?php } ?><?php if(isset($tumblr) && !empty($tumblr)){?><a title="Tumblr" href="<?php print $tumblr; ?>" target="_blank"><i class="fa fa-tumblr color-tumblr"></i></a><?php } ?></div>

		</div>

		<!--author-social-->

	</div>

	<?php endif; ?>

	<div class="woocommerce-tabs">

		<div class="panel entry-content" id="tab-reviews">

			<?php print render($content['comments']); ?>

		</div>

	</div>

	<?php if($region['bottom_blog']): ?>

		<?php print render($region['bottom_blog']); ?>

	<?php endif; ?>

</article>

<!--#single article--> 

<?php }elseif($blog_format == 'parallax_with_title'){ ?>

<article <?php if($sidebar == 'right'){ ?>style="float:left"<?php }elseif($sidebar == 'left'){ ?>style="float:right"<?php } ?> class="tn-content-wrap <?php print $col; ?> col-xs-12 post type-post status-publish has-post-thumbnail hentry">

	<div class="tn-single-share-wrap tn-single-top-share-wrap">

		<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

							'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

	</div>

	<!--#single top share -->

	<div class="tn-single-content-wrap row">

		<div class="tn-single-content-inner">

			<div class="single-post-content">

				<?php print render($content['body'][0]['#markup']); ?>

			</div>

			<!--content-->

		</div>

		<!--#post content inner-->

	</div>

	<!--#post content wrap-->

	<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

	<div class="tn-author-box-wrap clearfix">

		<?php if(isset($author_avatar_url) && !empty($author_avatar_url)): ?>

		<div class="tn-author-thumb"><img alt='<?php print $author_name; ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-105 photo' height='105' width='105' /></div>

		<?php endif; ?>

		<?php if(isset($author_name) && !empty($author_name)): ?>

		<h3 class="author-title"><?php print $author_name; ?></h3>

		<?php endif; ?>

		<?php if(isset($author_description) && !empty($author_description)): ?>

		<div class="author-description"><?php print $author_description; ?></div>

		<?php endif; ?>

		<div class="author-social">

			<div class="tn-author-bar-full-box"><?php if(isset($facebook) && !empty($facebook)){ ?><a title="Facebook" href="<?php print $facebook; ?>" target="_blank"><i class="fa fa-facebook color-facebook"></i></a><?php } ?><?php if(isset($twitter) && !empty($twitter)){ ?><a title="Twitter" href="<?php print $twitter; ?>" target="_blank"><i class="fa fa-twitter color-twitter"></i></a><?php } ?><?php if(isset($pinterest) && !empty($pinterest)){ ?><a title="Pinterest" href="<?php print $pinterest ?>" target="_blank"><i class="fa fa-pinterest color-pinterest"></i></a><?php } ?><?php if(isset($linkedin) && !empty($linkedin)){ ?><a title="LinkedIn" href="<?php print $linkedin; ?>" target="_blank"><i class="fa fa-linkedin color-linkedin"></i></a><?php } ?><?php if(isset($flickr) && !empty($flickr)){?><a title="Flickr" href="<?php print $flickr; ?>" target="_blank"><i class="fa fa-flickr color-flickr"></i></a><?php } ?><?php if(isset($tumblr) && !empty($tumblr)){?><a title="Tumblr" href="<?php print $tumblr; ?>" target="_blank"><i class="fa fa-tumblr color-tumblr"></i></a><?php } ?></div>

		</div>

		<!--author-social-->

	</div>

	<!--#author box -->

	<?php endif; ?>

	<div class="woocommerce-tabs">

		<div class="panel entry-content" id="tab-reviews">

			<?php print render($content['comments']); ?>

		</div>

	</div>

	<?php if($region['bottom_blog']): ?>

	<?php print render($region['bottom_blog']); ?>

	<?php endif; ?>

</article>

<?php }elseif($blog_format == 'fullwidth_title'){ ?>

<article <?php if($sidebar == 'right'){ ?>style="float:left"<?php }elseif($sidebar == 'left'){ ?>style="float:right"<?php } ?> class="tn-content-wrap <?php print $col; ?> col-xs-12 post type-post status-publish has-post-thumbnail hentry">

	<div class="tn-single-share-wrap tn-single-top-share-wrap">

		<div class="tn-share-social-box"><a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=<?php print $title; ?>&amp;url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

						'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text"><?php print t('Twitter'); ?></span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

						'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text"><?php print t('Facebook'); ?></span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=<?php print $pageURL; ?>" onclick="window.open(this.href, 'mywin',

						'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text"><?php print t('Google +'); ?></span></a></div>

	</div>

	<!--#single top share -->

	<?php if($imageone_uri): ?>

	<div class="tn-single-thumb-wrap">

		<div class="tn-single-thumb-inner"><?php print theme('image_style', array('path' => $imageone_uri, 'style_name' => 'image_1368x768', 'attributes'=>array('class' => 'attachment-blog_classic_thumb wp-post-image','alt'=>$title)));

			 ?>

		</div>

	</div>

	<?php endif; ?>

	<div class="tn-single-content-wrap row">

		<div class="tn-single-content-inner">

			<div class="single-post-content">

			<?php print render($content['body'][0]['#markup']); ?>

			</div>

			<!--content-->

		</div>

		<!--#post content inner-->

	</div>

	<!--#post content wrap-->

	<?php if((isset($author_avatar_url) && !empty($author_avatar_url)) || (isset($author_name) && !empty($author_name)) || (isset($author_description) && !empty($author_description))): ?>

	<div class="tn-author-box-wrap clearfix">

		<div class="tn-author-thumb"><img alt='<?php print $author_name; ?>' src='<?php print $author_avatar_url; ?>' srcset='<?php print $author_avatar_url; ?>' class='avatar avatar-105 photo' height='105' width='105' /></div>

		<?php if(isset($author_name) && !empty($author_name)): ?>

		<h3 class="author-title"><?php print $author_name;?></h3>

		<?php endif; ?>

		<?php if(isset($author_description) && !empty($author_description)): ?>



		<div class="author-description"><?php print $author_description; ?></div>

		<?php endif; ?>

		<div class="author-social">

			<div class="tn-author-bar-full-box"><?php if(isset($facebook) && !empty($facebook)){ ?><a title="Facebook" href="<?php print $facebook; ?>" target="_blank"><i class="fa fa-facebook color-facebook"></i></a><?php } ?><?php if(isset($twitter) && !empty($twitter)){ ?><a title="Twitter" href="<?php print $twitter; ?>" target="_blank"><i class="fa fa-twitter color-twitter"></i></a><?php } ?><?php if(isset($pinterest) && !empty($pinterest)){ ?><a title="Pinterest" href="<?php print $pinterest ?>" target="_blank"><i class="fa fa-pinterest color-pinterest"></i></a><?php } ?><?php if(isset($linkedin) && !empty($linkedin)){ ?><a title="LinkedIn" href="<?php print $linkedin; ?>" target="_blank"><i class="fa fa-linkedin color-linkedin"></i></a><?php } ?><?php if(isset($flickr) && !empty($flickr)){?><a title="Flickr" href="<?php print $flickr; ?>" target="_blank"><i class="fa fa-flickr color-flickr"></i></a><?php } ?><?php if(isset($tumblr) && !empty($tumblr)){?><a title="Tumblr" href="<?php print $tumblr; ?>" target="_blank"><i class="fa fa-tumblr color-tumblr"></i></a><?php } ?></div>

		</div>

		<!--author-social-->

	</div>

	<?php endif; ?>

	<div class="woocommerce-tabs">

		<div class="panel entry-content" id="tab-reviews">

			<?php print render($content['comments']); ?>

		</div>

	</div>

	<?php if($region['bottom_blog']): ?>

		<?php print render($region['bottom_blog']); ?>

	<?php endif; ?>

</article>

<?php } ?>

<?php } ?>