<?php 
	$out = '';
	if($block->region == 'main_menu'){
		$out .= '<div class="'.$classes.'" '.$attributes.'>';
		$out .= render($title_suffix);
		$out .= $content;
		$out .= '</div>';	
	}elseif($block->region == 'top_menu'){
		$out .= '<div class="tn-top-menu-wrap '.$classes.'" '.$attributes.'>';
		$out .= render($title_suffix);
		if ($block->subject):
			$out .= '<h5>'.$block->subject.'</h5>';
		endif;
		$out .= $content;
		$out .= '</div>';
	}elseif($block->region == 'sidebar_second' || $block->region == 'sidebar_first'){
		$out .= '<aside class="'.$classes.'" '.$attributes.'>';
		$out .= render($title_suffix);
		if ($block->subject):
			$out .= '<div class="widget-title"><h3>'.$block->subject.'</h3></div>';
		endif;
		$out .= $content;
		$out .= '</aside>';	
	}elseif($block->region == 'section' || $block->region == 'section_with_sidebar' || $block->region == 'section_bottom'){
		$out .= '<div class="'.$classes.'" '.$attributes.'>';
		$out .= render($title_suffix);
		if ($block->subject):
			$out .= '<h2>'.$block->subject.'</h2>';
		endif;
		$out .= $content;
		$out .= '</div>';	
	}elseif($block->region == 'footer'){
		$out .= '<div class="tn-sidebar-footer widget-area col-sm-4 col-xs-12" role="complementary">';
		$out .= '<aside class="'.$classes.'" '.$attributes.'>';
		$out .= render($title_suffix);
		if ($block->subject):
			$out .= '<div class="widget-title"><h3>'.$block->subject.'</h3></div>';
		endif;
		$out .= $content;
		$out .= '</aside></div>';
	}elseif($block->region == 'content'){
		$out .= render($title_suffix);
		$out .= $content;
	}else{
		$out .= '<div class="'.$classes.'" '.$attributes.'>';
		$out .= render($title_suffix);
		if ($block->subject):
			$out .= '<h5>'.$block->subject.'</h5>';
		endif;
		$out .= $content;
		$out .= '</div>';	
	}
	print $out;
?>

    