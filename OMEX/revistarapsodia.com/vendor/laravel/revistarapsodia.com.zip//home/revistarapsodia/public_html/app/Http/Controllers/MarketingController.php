<?php namespace App\Http\Controllers;

use App\MarketingInSecctionModel;
use App\MarketingModel;
use App\Core\FileUtil;
use App\MenuModel;

class MarketingController extends Controller {

    /*
    |--------------------------------------------------------------------------
    | Home Controller
    |--------------------------------------------------------------------------
    |
    | This controller renders your application's "dashboard" for users that
    | are authenticated. Of course, you are free to change or remove the
    | controller as you wish. It is just here to get your app started!
    |
    */
    /**
     * @var FileUtil
     */
    private $fileUtil;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(FileUtil $fileUtil)
    {
        $this->middleware('auth');
        $this->fileUtil = $fileUtil;
    }


    /**
     * Show the application dashboard to the user.
     *
     * @return Response
     */
    public function getBanner()
    {
        return view('admin.marketing')
            ->with('sliders', MarketingModel::all());
    }
    /**
     * @return \Illuminate\Http\RedirectResponse
     */
    public function newImageMarketingModel(){
        $file = \Input::file('photo');
        $folder = \Input::get('folder');
        $name = $this->fileUtil->uploadIndexImage($file, $folder);
        $MarketingModel = new MarketingModel;
        $MarketingModel->img = $name;
        $MarketingModel->url = \Input::get('url');
        $MarketingModel->save();
        return redirect()->back();
    }

    /**
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function deleteMarketingModel($id){
        $MarketingModel = MarketingModel::find($id);
        if($MarketingModel != null) {
            $folder = explode("/", $MarketingModel->img);
            $folderIndex = "marketing/";
            $this->fileUtil->deleteFolder($folderIndex.$folder[0]);
            MarketingModel::destroy($id);
        }
        return redirect()->back();
    }

    public function updateMarketingSection($id){

        if(\Request::isMethod('POST')){


            $r = \Input::get('sections');
            MarketingInSecctionModel::where('marketing_id', $id)->delete();
            if($r != null)
            foreach($r as $sectionToSet){
                $marketing = new MarketingInSecctionModel;
                if (strpos($sectionToSet, '_') !== false) {
                    $sectionToSet = explode("_", $sectionToSet);
                    $marketing->menu_id = $sectionToSet[0];
                    $marketing->kid_id = $sectionToSet[1];
                    $marketing->marketing_id = $id;


                }else{
                    $marketing->menu_id = $sectionToSet;
                    $marketing->kid_id = 0;
                    $marketing->marketing_id = $id;
                }
                $marketing->save();
            }


            return redirect()->to(asset('Admin/publicidad'));
        }

        return view("admin.marketingSection")
            ->with('id',$id)
            ->with('menus', MenuModel::all())
            ->with('selectedSections', MarketingInSecctionModel::where('marketing_id', $id)->get());


    }

}
