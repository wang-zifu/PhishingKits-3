<?php if($header): ?>
	<?php print $header; ?>
<?php endif; ?>
<div class="tn-sub-cate-wrap">
	<ul class="tn-sub-cate-inner">
		<?php if($rows): ?>
			<?php print $rows; ?>
		<?php endif; ?>
	</ul>
</div>