@extends('master.home')


@section('adsense')
    
         <script async src="//"></script>
         <!-- Anuncios R1 -->
         <ins class="adsbygoogle"
              style="display:block"
              data-ad-client="ca-pub-7473782780390075"
              data-ad-slot="8544575149"
              data-ad-format="auto"></ins>
         <script>
         (adsbygoogle = window.adsbygoogle || []).push({});
         </script>
@endsection

@section('content')
    <div class="tn-breadcrumbs-wrap clearfix">
        


                    @if(\Request::server('REQUEST_URI') == '/musicaincidental' || \Request::server('REQUEST_URI') == '/lanota')
                     
                        <div class="single-post-content container" style="margin-bottom: 0 !important;">
                            <div class="tn-breadcrumbs-wrap clearfix">
                                <div class="">
                                    <span><a href="{{ asset('/') }}">HOME</a></span>
                                    @if($section->menu != null)
                                        <i class="fa fa-angle-right next-breadcrumbs"></i>
                                        <span><a href="{{ asset($section->menu->url) }}">{{ $section->menu->name }}</a></span>
                                    @endif
                                    <i class="fa fa-angle-right next-breadcrumbs"></i>
                                    <span>{{ $section->name }}</span>
                                    <!--#breadcrumbs -->
                                </div>
                              </div>
                            <br>
                            <h1 style="font-family: 'Times New Roman'; font-size: 2.4em; font-weight: bold; ">{{ $post->title }}</h1>
                            <br>
                            <div class="tn-single-share-wrap tn-single-top-share-wrap">
                                <div class="tn-share-social-box">
                                                <a class="tn-single-share-button tn-social-facebook" href="javascript:;" id="shareBtn"><i class="fa fa-facebook"></i><span class="tn-social-text">FACEBOOK</span></a> 

                                        <a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=Revista Rapsodia - {{ $post->title }}&amp;url={{ asset($section->url) }}/{{$post->id}}" onclick="window.open(this.href, 'mywin',
                                        'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text">TWITTER</span></a> 
                                    </div>
                            </div>


                            <div class="tn-single-top-meta-wrap">
                            <div style="float:left">
                                <div class="tn-category-tags-wrap">         <a href="{{ asset($section->url) }}" typeof="skos:Concept" property="rdfs:label skos:prefLabel" datatype="">{{ $section->name }}</a>    </div>
                                </span></span>
                                        <!--category tags -->
                                    </div>
                                    <div class="tn-single-top-meta-right">
                                        <span class="tn-single-top-meta-date single-meta-right-el">{{ date('d/m/Y',  strtotime($post->created_at)) }}</span>
                                    </div>
                                    <!--#top meta right-->
                                </div>
                            </div>

                    @else
                    <div class="tn-breadcrumbs-inner tn-container">
                        <span><a href="{{ asset('/') }}">HOME</a></span>
                        @if($section->menu != null)
                            <i class="fa fa-angle-right next-breadcrumbs"></i>
                            <span><a href="{{ asset($section->menu->url) }}">{{ $section->menu->name }}</a></span>
                        @endif
                        <i class="fa fa-angle-right next-breadcrumbs"></i>
                        <span>{{ $section->name }}</span>
                        <!--#breadcrumbs -->
                    </div>
                    @endif




        <div class="tn-single-style3-wrap tn-single-thumb-parallax">
            <div id="x" class="tn-single-image-parallax">
                <div class="backstretch">
                    @if(strpos($post->content->url, 'http') !== false)
                        <iframe  style="width: 100%" height="570" src="{{ $post->content->url }}" frameborder="0" allowfullscreen></iframe>
                    @else
                        <img style="width: 100%" src="{{ asset('storage/app/post'.$post->id. '/' . $post->content->url_image) }}">
                    @endif

                </div>
            </div>
            <div class="tn-single-style3-content-wrap">
                <div class="tn-single-style3-content-inner tn-container">
                    <div class="tn-single-title-style3-wrap">
                        <!--h1 itemprop="name" class="tn-single-title">Biggest Wild Animal Fights #2 </h1-->
                        <!--#title-->
                    </div>
                    <!--#single title -->
                    <div class="tn-single-top-meta-wrap">
                        <!--div class="tn-category-tags-wrap tn-category-11">
                            <a href="/demo/drupal/fmagazine/blog-categories/lifestyle" typeof="skos:Concept" property="rdfs:label skos:prefLabel" datatype="">Lifestyle</a>
                        </div-->
                        <!--category tags -->
                        <!--div class="tn-single-top-meta-right">
                            <span class="tn-single-top-meta-date single-meta-right-el">November 11, 2015</span>
                               <span class="tn-single-top-meta-view-wrap single-meta-right-el">
                                  <span class="single-top-meta-views-num"><i class="fa fa-heart-o"></i>320</span>
                                  <span class="single-top-meta-views-content">Views</span>
                               </span>
                                            <meta itemprop="author" name="author" content="Margaret">
                               <span class="tn-single-top-meta-comment-wrap single-meta-right-el">
                                  <span class="single-top-meta-comments-num"><i class="fa fa-comments"></i>2</span>
                                  <span class="single-top-meta-comments-content">Comments</span>
                                 </  span>

                        </div -->
                        <!--#top meta right-->
                    </div>
                    <!--#top meta wrap-->
                </div>
            </div>
            <!--#style 3 content -->
            <div class="tn-single-media-overlay"></div>
            <!--div class="tn-single-media-icon"><i class="fa fa-play-circle"></i></div-->
            <!--div class="tn-single-media-parallax tn-single-video-parallax">
                <div class="tn-video-wrap tn-single-thumb-wrap">
                    <div class="embedded-video">
                        <div class="player">
                            <iframe class="" width="640" height="360" src="//www.youtube.com/embed/Evvwt5AcU2Y?width%3D640%26amp%3Bheight%3D360%26amp%3Bautoplay%3D0%26amp%3Bvq%3Dlarge%26amp%3Brel%3D0%26amp%3Bcontrols%3D1%26amp%3Bautohide%3D2%26amp%3Bshowinfo%3D1%26amp%3Bmodestbranding%3D0%26amp%3Btheme%3Ddark%26amp%3Biv_load_policy%3D1%26amp%3Bwmode%3Dopaque" frameborder="0" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            </div-->
            <!--#audio overlay -->
        </div>


        <div class="tn-container tn-section-content-wrap row clearfix">
            <article  class="tn-content-wrap col-sm-12 col-xs-12 post type-post status-publish format-audio has-post-thumbnail hentry " itemscope itemtype="http://schema.org/Article">
                <!--#single title -->
                <!--div class="tn-single-share-wrap tn-single-top-share-wrap">
                    <div class="tn-share-social-box">
                        <a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=Biggest Wild Animal Fights #2 &amp;url=http://drupalet.com/demo/drupal/fmagazine/biggest-wild-animal-fights-2" onclick="window.open(this.href, 'mywin',
      'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text">TWITTER</span></a> <a class="tn-single-share-button tn-social-facebook" href="http://www.facebook.com/sharer.php?u=http://drupalet.com/demo/drupal/fmagazine/biggest-wild-animal-fights-2" onclick="window.open(this.href, 'mywin',
      'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-facebook"></i><span class="tn-social-text">FACEBOOK</span></a> <a class="tn-single-share-button tn-social-google" href="http://plus.google.com/share?url=http://drupalet.com/demo/drupal/fmagazine/biggest-wild-animal-fights-2" onclick="window.open(this.href, 'mywin',
      'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-google-plus"></i><span class="tn-social-text">Google +</span></a></div>
                </div-->
                <!--#single top share -->
       

                <!--#top meta wrap-->
                <!--#thumb & audio wrap -->
                <div class="tn-single-content-wrap row">
                    <div class="tn-single-meta-inner col-sm-2 hidden-xs">
                        <div class="tn-single-date-wrap">
                            <div class="tn-single-date">
                                <span  class="single-tags-day">
                                    {{ date('d', strtotime($post->created_at)) }}
                                </span><!--#meta day-->
                                <meta itemprop="interactionCount" content="UserComments:0"/>
                                <span  class="single-tags-month" style="color:white;">{{ date('M', strtotime($post->created_at)) }}</span><!--#meta day-->
                            </div>
                        </div>
                        <!--div class="single-tags-author">
                            <img alt='Margaret' src='http://drupalet.com/demo/drupal/fmagazine/sites/default/files/8794a4ce65d03c1920e0c74a874316e2.jpeg' srcset='http://drupalet.com/demo/drupal/fmagazine/sites/default/files/8794a4ce65d03c1920e0c74a874316e2.jpeg' class='avatar avatar-75 photo' height='75' width='75' />
                            <div class="single-tags-author-content">
                                <div class="single-tags-author-content-inner">
                                    Margaret
                                    <div class="single-tags-author-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ea possunt paria non esse. Hoc sic expositum dissimile est superiori. Nihil opus est exemplis hoc facere longius. Nulla erit controversia.</div>
                                </div>
                            </div>

                        </div-->
                        <!--#tags author-->
                        <div class="single-tags-share">
                            <i class="fa fa-share single-tags-share-icon"></i>
                            <div class="single-tags-share-content">
                                <div class="single-tags-share-content-inner">
                                    <div class="tn-share-social-box">
                                        <a class="tn-single-share-button tn-social-facebook" href="javascript:;" id="shareBtn1"><i class="fa fa-facebook"></i><span class="tn-social-text">FACEBOOK</span></a> 

                                        <a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=Revista Rapsodia - {{ $post->title }}&amp;url={{ asset($section->url) }}/{{$post->id}}" onclick="window.open(this.href, 'mywin',
                  'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text">TWITTER</span></a> 
              </div>
                                </div>
                            </div>
                            <!--#content-->
                        </div>
                        <!--#tags author-->
                    </div>
                    <!--#single meta-->
                    <div class="tn-single-content-inner col-sm-10 col-xs-12">
                        <div class="single-post-content">

                            @if(\Request::server('REQUEST_URI') != '/musicaincidental' && \Request::server('REQUEST_URI') != '/lanota')
                            <h1 style="font-family: 'Times New Roman'; font-size: 2.4em; ">{{ $post->title }}</h1>
                               <!--#single title -->
                                <div class="tn-single-share-wrap tn-single-top-share-wrap">
                                    <div class="tn-share-social-box">

                                        <a class="tn-single-share-button tn-social-facebook" href="#" id="shareBtn2"><i class="fa fa-facebook"></i><span class="tn-social-text">FACEBOOK</span></a> 

                                        <a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=Revista Rapsodia - {{ $post->title }}&amp;url={{ asset($section->url) }}/{{$post->id}}" onclick="window.open(this.href, 'mywin',
                                        'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text">TWITTER</span></a> 
                                    </div>
                                </div>
                                 <!--#single top share -->
                                <div class="tn-single-top-meta-wrap">
                                    <div style="float:left">
                                        <div class="tn-category-tags-wrap">         <a href="{{ asset($section->url) }}" typeof="skos:Concept" property="rdfs:label skos:prefLabel" datatype="">{{ $section->name }}</a>    </div>

                                </span></span>
                                        <!--category tags -->
                                    </div>
                                    <div class="tn-single-top-meta-right">
                                        <span class="tn-single-top-meta-date single-meta-right-el">{{ date('d/m/Y',  strtotime($post->created_at)) }}</span>
                                    </div>
                                    <!--#top meta right-->
                                </div>
                                @endif
                                <!--#single top share -->
                            {!! $post->content->text_1 !!}


                            @if($post->content->image != null)
                            <div style="text-align: center;">
                                <img style="width: 80%" src="{{ asset('storage/app/post'.$post->id. '/' . $post->content->image) }}" >
                                <figcaption class="wp-caption-text">
                                    {{  $post->content->caption }}
                                </figcaption>
                            </div>
                            @endif

                            {!! $post->content->text_2 !!}

                            @if(strlen($post->content->sentence) > 1)
                                <blockquote>
                                    <p> {{ $post->content->sentence }}</p>
                                </blockquote>
                            @endif

                            {!! $post->content->text_3 !!}

                            <hr>
                            {!! $post->content->biography !!}
                            <br><br>
                            <aside class="block block-block widget about-widget" >
                                <div class="widget-title">
                                    <h3>AUTOR</h3>
                                </div>

                                <div class="about-widget-image col-md-4">
                                    <img src="{{ asset('storage/app/authors/'.$post->author->imageProfile) }}" alt="camera-man" style="width: 50%;"/>
                                </div>
                                <!--#image-->
                                <div class="about-widget-content  col-md-8">
                                    <p style="text-align: center; margin: 0 24px;">
                                        <strong style="font-size: 18px;">{{ $post->author->name }}</strong><br><br>
                                        {{ $post->author->description }}<br><br>
                                        <strong style="font-size: 14px;">{{ $post->author->jobTitle }}</strong>
                                    </p>
                                </div>

                            </aside>



                            <div id="fb-root"></div>
                                  <script>
                  window.fbAsyncInit = function() {
                    FB.init({
                      appId            : '1786715748275912',
                      autoLogAppEvents : true,
                      xfbml            : true,
                      version          : 'v2.10'
                    });
                    FB.AppEvents.logPageView();
                  };

                  (function(d, s, id){
                     var js, fjs = d.getElementsByTagName(s)[0];
                     if (d.getElementById(id)) {return;}
                     js = d.createElement(s); js.id = id;
                     js.src = "//connect.facebook.net/es_LA/sdk.js";
                     fjs.parentNode.insertBefore(js, fjs);
                   }(document, 'script', 'facebook-jssdk'));
                </script>
                            <div class="fb-comments" data-href="{{ asset('/' . $section->url . '/'. $post->id)}}" data-numposts="5" data-width="100%"></div>


                        </div>
                        <!--content-->

                    </div>
                    <!--#post content inner-->

                </div>
                <!--#post content wrap-->



                @include('rapsodia.includes.mayInterestYou')

            </article>
        </div>

@endsection

@section('scripts')
 

@endsection