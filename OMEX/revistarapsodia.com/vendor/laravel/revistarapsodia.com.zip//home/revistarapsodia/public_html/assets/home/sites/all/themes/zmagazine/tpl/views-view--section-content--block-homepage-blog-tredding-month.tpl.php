<?php print render($title_prefix); ?>
<div id="icf874d5-4c8e-47df-b332-2d8d85a1adba" class="tn-block8-wrap tn-block-wrap clearfix">
	<div class="tn-container tn-black-style">
		<div class="tn-black-style-inner">
			<div class="tn-block8-title block-title-wrap">
				<?php if($header): ?>
					<?php print $header; ?>
				<?php endif; ?>
			</div>
			<!--#block header wrap -->
			<?php if($rows): ?>
			<div class="tn-block8-content-wrap tn-block-content-wrap">
				<div class="tn-block8-content-inner tn-block-content-inner">
					<div class="row clearfix">
						<?php print $rows; ?>
					</div>
					<!--#row fluid-->
				</div>
			</div>
			<!--#block content wrap-->
			<?php endif; ?>
		</div>
		<!--black style inner-->
	</div>
	<!--tn container-->
</div>
<!--#end block-->