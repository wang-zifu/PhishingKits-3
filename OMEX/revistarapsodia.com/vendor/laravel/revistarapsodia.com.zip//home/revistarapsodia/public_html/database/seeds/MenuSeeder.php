<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class MenuSeeder extends Seeder {

	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
		$menus = array(
			array('name' => 'HOME', 'url' => '/'),
			array('name' => 'INVESTIGACIÓN', 'url' => "#"),
			array('name' => 'EN ENTREVISTA', 'url' => "#"),
			array('name' => 'SONIDO LOCAL', 'url' => "#"),
			array('name' => 'MÚSICA & ARTE', 'url' => "#"),
			array('name' => 'LA NOTA', 'url' => 'lanota'),
			array('name' => '¿TÚ QUÉ OPINAS?', 'url' => 'tuqueopinas'),
			array('name' => 'CONTACTO', 'url' => 'contacto')
		);

		foreach($menus as $menu){
			DB::table('menu_models')->insert($menu);
		}

		$sub_menus = array(
			array('menu_id' => 2, 'name' => 'HABLANDO DE MÚSICOS', 'url' => 'hablando'),
			array('menu_id' => 2, 'name' => 'ENTRE MÚSICOS', 'url' => 'entremusicos'),
			array('menu_id' => 2, 'name' => 'A PROPÓSITO DE...', 'url' => 'apropositode'),
			array('menu_id' => 2, 'name' => 'LO QUE TIENES QUE ESCUCHAR', 'url' => 'loquetienesque')
		);

		foreach($sub_menus as $menu){
			DB::table('menu_kids_models')->insert($menu);
		}

		$sub_menus = array(
			array('menu_id' => 3, 'name' => 'EN ENTREVISTA', 'url' => 'entrevista'),
			array('menu_id' => 3, 'name' => 'REPORTAJE', 'url' => 'reportaje')
		);

		foreach($sub_menus as $menu){
			DB::table('menu_kids_models')->insert($menu);
		}

		$sub_menus = array(
			array('menu_id' => 4, 'name' => 'ENTREVISTA', 'url' => 'entrevistasonido'),
			array('menu_id' => 4, 'name' => 'REPORTAJE', 'url' => 'reportajesonido')
		);

		foreach($sub_menus as $menu){
			DB::table('menu_kids_models')->insert($menu);
		}

		$sub_menus = array(
			array('menu_id' => 5, 'name' => '+ ARTE', 'url' => 'masarte'),
			array('menu_id' => 5, 'name' => 'MÚSICA INCIDENTAL', 'url' => 'musicaincidental')
		);

		foreach($sub_menus as $menu){
			DB::table('menu_kids_models')->insert($menu);
		}



	}

}
