<?php namespace App\Http\Controllers;

use App\User;

class UsersController extends Controller {

    /*
    |--------------------------------------------------------------------------
    | Home Controller
    |--------------------------------------------------------------------------
    |
    | This controller renders your application's "dashboard" for users that
    | are authenticated. Of course, you are free to change or remove the
    | controller as you wish. It is just here to get your app started!
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }


    /**
     * @return $this
     */
    public function getUsers(){
        return view('admin.users.home')
            ->with('users', User::all());
    }

    public function getCreateUpdateUser(){
        $id =\Input::get('id');
        $User = User::find($id);

        if($User == null)
            $User = new User;

        if(\Request::isMethod('post')){
            if($id == null)
                \Session::flash('msg', 'Usuario creado correctamente');
            else
                \Session::flash('msg', 'Usuario actualizado correctamente');

            $UserModel = \Input::all();

            if(array_key_exists('password', $UserModel))
                $UserModel['password'] = \Hash::make($UserModel['password']);
           
            $User->fill($UserModel);
            $User->save();
            return redirect()->to(asset('Admin/usuarios'));
        }

        return view('admin.users.createupdate')
            ->with('user', $User);
    }

    public function getRemoveUser(){
        $id =\Input::get('id');
        User::destroy($id);
        return redirect()->to(asset('Admin/usuarios'));

    }

}
