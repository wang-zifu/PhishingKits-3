<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class PostContentModel extends Model {

	//
    protected $fillable = ['post_id', 'url_image','choice', 'url', 'image', 'caption', 'text_1', 'text_2', 'text_3', 'sentence', 'biography'];

}
