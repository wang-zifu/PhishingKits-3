@extends('master.home')
@section('content')
    <div class="tn-breadcrumbs-wrap clearfix">
        <div class="tn-breadcrumbs-inner tn-container">
            <span><a href="{{ asset('/')}}">HOME</a></span>
            <i class="fa fa-angle-right next-breadcrumbs"></i>
            <span><a href="#">CONTACTO</a></span>
            <!--#breadcrumbs -->
        </div>
    </div>
    <div class="tn-container tn-section-content-wrap row clearfix">
        <div style="float:left" class="tn-content-wrap col-sm-12 col-xs-12">
            <div class="clearfix"></div>
            <div id="node-31" class="node node-page clearfix" about="{{ asset('/contactoform') }}" typeof="foaf:Document">
                <span property="dc:title" content="Contact" class="rdf-meta element-hidden"></span><span property="sioc:num_replies" content="0" datatype="xsd:integer" class="rdf-meta element-hidden"></span>
                <div class="content">
                    <div class="tn-single-content-wrap clearfix">
                        <h2 class="section-title" style="text-align: center; font-size: 34px;">MANTENTE EN CONTACTO</h2>
                        <div style="margin: 0 auto; border-bottom: 1px solid #333; display: block; width: 100px;"></div>
                        <p style="text-align: center; font-size: 20px; color: #666; font-weight: 300; margin: 30px 24px 0 24px;">Si estas interesado en anunciarte con nosotros, envíanos un email para obtener más información.   ¡Conoce nuestros planes!</p>
                        <div class="clearfix" style="margin-bottom: 48px; margin-top: 48px;">
                            <div class="col-sm-4 col-xs-12" style="text-align: center;">
                              &nbsp;
                            </div>
                            <div class="col-sm-4 col-xs-12" style="text-align: center;">
                                <i class="fa fa-envelope" style="font-size: 38px; display: block;"></i>
                                </p>
                                <h5>¡Anúnciate!</h5>
                                <p>
                                    <a href="mailto:ventas@revistarapsodia.com">ventas@revistarapsodia.com</a>
                                    <br />

                                </p>
                            </div>
                            <div class="col-sm-4 col-xs-12" style="text-align: center;">
                                &nbsp;
                            </div>
                        </div>
                        <h2 class="section-title" style="text-align: center; font-size: 34px; margin-top: 96px;">FORMULARIO DE CONTACTO</h2>
                        <div style="margin: 0 auto; border-bottom: 1px solid #333; display: block; width: 100px;"></div>
                        <p style="text-align: center; font-size: 20px; color: #666; font-weight: 300; margin: 30px 24px 48px 24px;">
                            Porque la Música es nuestro medio de comunicación. Envíanos tus comentarios o sugerencias.             
                            <br>¡Nos encantaría hablar contigo!
                        </p>
                        <p>&nbsp;</p>
                        <div class="col-sm-6 col-xs-12 tn-sidebar-wrap">
                            <div role="form" class="wpcf7" id="wpcf7-f597-p658-o1" lang="en-US" dir="ltr">
                                <div class="screen-reader-response"></div>
                                <form class="webform-client-form webform-client-form-30" enctype="multipart/form-data" action="{{ asset('/contactoform') }}" method="post" id="formularioContacto" accept-charset="UTF-8">
                                    <input type="hidden" value="{{ csrf_token() }}" name="_token">
                                    <div>
                                        <div  class="form-item webform-component webform-component-textfield webform-component--name">
                                            <label class="element-invisible" for="edit-submitted-name">Nombre <span class="form-required" title="This field is required.">*</span></label>
                                            <input required="required" placeholder="Nombre" type="text" id="edit-submitted-name" name="name" value="" size="60" maxlength="128" class="form-text required" />
                                        </div>
                                        <div  class="form-item webform-component webform-component-textfield webform-component--email">
                                            <label class="element-invisible" for="edit-submitted-email">Email <span class="form-required" title="This field is required.">*</span></label>
                                            <input required="required" placeholder="Email" type="text" id="edit-submitted-email" name="email" value="" size="60" maxlength="128" class="form-text required" />
                                        </div>
                                        <div  class="form-item webform-component webform-component-textarea webform-component--message">
                                            <label class="element-invisible" for="edit-submitted-message">Mensaje <span class="form-required" title="This field is required.">*</span></label>
                                            <div class="form-textarea-wrapper"><textarea required="required" placeholder="Mensaje" id="edit-submitted-message" name="message" cols="60" rows="5" class="form-textarea required"></textarea></div>
                                        </div>
                                       
                                        <div class="form-actions"><input class="webform-submit button-primary form-submit" type="submit" name="op" value="Enviar" id="envialexD"/></div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div style="margin-top:2em" class="col-sm-6 col-xs-12 tn-sidebar-wrap">
                            <img src="{{ asset('/assets/images/contacto.jpeg') }}" style="width: 100%">
                            <!--iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d208979.34053655996!2d-106.73142178449929!3d35.07418140911969!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1svi!2s!4v1445942967280" style="border:0px; width:100%; height:483px; " allowfullscreen></iframe-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script type="text/javascript">
        jQuery(function(){
            jQuery("#envialexD").click(function(){
                var FormData = jQuery("#formularioContacto").serialize();
                jQuery.post("{{asset('contactoforms')}}", 
                    {
                        name : jQuery("input[name=name]").val(),
                        email : jQuery("input[name=email]").val(),
                        message : jQuery("textarea[name=message]").val(),
                        _token : jQuery("input[name=_token]").val(),
                    }, function(data){
                        alert("Formulario enviado");
                        window.location.reload(true);
                    }).error(function(){
                        alert("Error al enviar formulario");
                    });

            });
        });
    </script>
@endsection
@section('css')
@endsection