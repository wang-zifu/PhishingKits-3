<?php if($title):?>
<?php print $title;?>
<?php if($subtitle):?>
<p class="block-subtitle"><?php print $subtitle;?></p>
<?php endif;?>
<?php endif;?>
