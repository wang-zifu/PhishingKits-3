<?php print render($title_prefix); ?>
<?php if($header): ?>
<div class="widget-title">
    <?php print $header; ?>
</div>
<?php endif; ?>
<?php if($rows): ?>
<ul class="product_list_widget">
   <?php print $rows; ?>
</ul>
<?php endif; ?>
