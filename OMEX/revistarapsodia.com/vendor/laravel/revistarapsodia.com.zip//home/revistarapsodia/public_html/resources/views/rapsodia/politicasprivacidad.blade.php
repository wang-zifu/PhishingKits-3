@extends('master.home')
@section('content')
    <div class="tn-breadcrumbs-wrap clearfix">
        <div class="tn-breadcrumbs-inner tn-container">
            <span><a href="{{ asset('/')}}">HOME</a></span>
            <i class="fa fa-angle-right next-breadcrumbs"></i>
            <span><a href="#">POLITICAS DE PRIVACIDAD</a></span>
            <!--#breadcrumbs -->
        </div>
    </div>
    <div class="tn-container tn-section-content-wrap row clearfix">
        <div style="float:left" class="tn-content-wrap col-sm-12 col-xs-12">
            <div class="clearfix"></div>
            <div id="node-31" class="node node-page clearfix" about="{{ asset('/contactoform') }}" typeof="foaf:Document">
            	<div id="node-31" class="node node-page clearfix" about="{{ asset('/contactoform') }}" typeof="foaf:Document"  style="font-family: 'AvenirLTStd'">
            		
            			{!! \App\PageContentModel::find(9)->value !!}
            		
            </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script type="text/javascript">
    
    </script>
@endsection
@section('css')
@endsection