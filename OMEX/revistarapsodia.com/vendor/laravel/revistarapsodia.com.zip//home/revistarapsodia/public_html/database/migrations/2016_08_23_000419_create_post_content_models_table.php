<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePostContentModelsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('post_content_models', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('post_id');
			$table->string('type_insert_post_id');
			$table->text('name');
			$table->text('preview');
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('post_content_models');
	}

}
