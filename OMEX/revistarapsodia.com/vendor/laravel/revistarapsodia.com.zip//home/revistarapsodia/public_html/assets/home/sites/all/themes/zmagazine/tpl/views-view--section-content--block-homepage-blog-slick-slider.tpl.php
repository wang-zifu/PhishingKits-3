<?php print render($title_prefix); ?>
<div id="d392ecbd-d804-465b-aa7a-07c6b5f5e919" class="tn-block1-wrap tn-block-wrap clearfix">
	<div class="tn-block1-content-wrap tn-block-content-wrap">
		<div class="tn-block1-content-inner tn-block-content-inner">
			<div class="slider-loading"></div>
			<div id="tn-slider1_5619e57d1170b" class="tn-block-slider-wrap tn-slider-init">
				<?php if($rows): ?>
					<?php print $rows; ?>
				<?php endif; ?>
				<!--#module slider -->
			</div>
			<!--#block slider-->
		</div>
	</div>
	<!--#block content wrap-->
</div>
<!--#end block-->