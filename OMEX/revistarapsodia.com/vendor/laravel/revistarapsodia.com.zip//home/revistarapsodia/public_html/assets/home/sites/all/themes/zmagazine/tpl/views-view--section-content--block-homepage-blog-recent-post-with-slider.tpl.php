<?php print render($title_prefix); ?>
<div class="tn-block2-wrap tn-block-wrap clearfix">
	<div class="tn-block2-content-wrap tn-block-content-wrap">
		<div class="tn-block2-content-inner tn-block-content-inner">
			<div class="slider-loading"></div>
			<div id="tn-slider1_56126ca14c65f" class="tn-block-slider-wrap tn-slider-init">
				<?php if($rows): ?>
					<?php print $rows; ?>
				<?php endif; ?>
			</div>
			<!--#block slider-->
		</div>
	</div>
	<!--#block content wrap-->
</div>
<!--#end block-->
<?php if($attachment_before): ?>
	<?php print $attachment_before; ?>
<?php endif; ?>
<!--#end block-->
<?php if($attachment_after): ?>
	<?php print $attachment_after; ?>
<?php endif; ?>