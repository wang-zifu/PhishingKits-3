<?php

if(isset($post)):
foreach(\App\MarketingInSecctionModel::where('menu_id', $post->menu_id)->where("kid_id", $post->menu_kids_id)->orderByRaw("RAND()")->get() as $m){
    $marketingToShow[$m->marketing_id] = $m->marketing_id;
}

$marketing = \App\MarketingModel::find($marketingToShow);


?>
@if(count($marketing) > 0)
    <aside class="block block-views widget block-post-widget" >
        <div class="tn-block-post-wrap tn-block-wrap clearfix">
            <div class="tn-block-post-title block-title-wrap">
                <h3>&nbsp;</h3>
            </div>
            <!--#block header wrap -->
            <div class="tn-block-post-content-wrap tn-block-content-wrap">


                @for($i = 0; $i < 3; $i++)
                    @if(count($marketing) > $i)
                        <div class="row">
                            <a href="{{ $marketing[$i]->url }}" target="_blank">
                                <img style="width: 100%;" itemprop="image" src="{{ asset('storage/app/marketing/'.$marketing[$i]->img) }}" class="" />
                            </a>
                        </div>
                        <div class="clearfix">&nbsp;</div>
                    @endif
                @endfor

            </div>
            <!--#block content wrap-->
        </div>
    </aside>
@endif

@endif
