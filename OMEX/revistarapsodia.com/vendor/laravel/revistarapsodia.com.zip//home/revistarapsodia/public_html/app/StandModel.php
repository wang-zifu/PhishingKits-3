<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class StandModel extends Model {

	//

}
