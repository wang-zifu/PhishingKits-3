<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class TemplateSeeder extends Seeder {

	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
		$template = array('T1', 'T2', 'T3');

		foreach ($template as $t) {
			$temp = new \App\TemplatesModel;
			$temp->name = $t;
			$temp->save();
		}

	}

}
