Title,published,file,GUID
"Tubing is awesome",205200720,<?php print $files[0]; ?>,0
"Jeff vs Tom",428112720,<?php print $files[1]; ?>,1
"Attersee",1151766000,<?php print $files[2]; ?>,2
"H Street NE",1256326995,<?php print $files[3]; ?>,3
"La Fayette Park",1256326995,<?php print $files[4]; ?>,4
