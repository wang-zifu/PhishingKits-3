<html>
<head>
	<title>Colaboraciones</title>
	<link rel="stylesheet" type="text/css" href="http://revistarapsodia.com/assets/home/sites/all/themes/zmagazine/css/bootstrap.min.css?o0lbpm">

    <link rel="stylesheet" href="http://revistarapsodia.com/assets/home/sites/all/themes/zmagazine/css/font-awesome.min.css"/>
</head>
<body>
<div class="row">
	
	<div class="col-md-8" style="background-image: url({{ asset('/assets/images/corchea.png') }}); background-size: 100% height: auto; background-repeat: no-repeat; height: 600px; width: 70%; float: left;">
		<h3>Editorial</h3>
		
		<p style="text-align: justify; width: 97%;" class="tn-module-excerpt">
			{{ \App\PageContentModel::find(1)->value }}
		</p>
		<p style="text-align: justify; font-size: 11px; padding: 5px; clear: both;">
			{{ \App\PageContentModel::find(18)->value }}
		</p>
	</div>

	<div class="col-md-4 container" style="background-color: #123;  height: auto; width: 29%; float: left; color: white;">
		<h3>&nbsp;&nbsp;Colaboraciones</h3>
		<ul style=" list-style-type: none; text-align: center; padding: 0 10px;" >
			@foreach(\App\StandModel::all() as $item)
				<li>@if($item->ocupation != null && $item->ocupation != "")<i class="fa fa-music" aria-hidden="true"></i> <strong> {{ $item->ocupation }} </strong> <br>@endif{{ $item->name }}</li>
			@endforeach
		</ul>
		<p style="text-align: justify; font-size: 11px; padding: 5px; clear: both;">
			{{ \App\PageContentModel::find(17)->value }}
		</p>

	</div>

</div>
</body>
</html>