<?php print render($title_prefix); ?>
<div class="widget-title">
<?php if($header): ?>
	<?php print $header; ?>
<?php endif; ?>
</div>
<?php if($rows): ?>
<ul class="products">
	<?php print $rows; ?>
</ul>
<?php endif; ?>