<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class MenuKidsModel extends Model {

	//
    public function menu(){
        return $this->belongsTo('App\MenuModel', 'menu_id', 'id');
    }

}
