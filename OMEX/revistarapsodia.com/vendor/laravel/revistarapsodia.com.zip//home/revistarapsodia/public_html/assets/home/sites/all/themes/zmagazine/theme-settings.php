<?php

function zmagazine_form_system_theme_settings_alter(&$form, &$form_state) {
    $theme_path = drupal_get_path('theme', 'zmagazine');
    $form['#submit'][] = 'zmagazine_settings_form_submit';

    // Get all themes.
    $themes = list_themes();
    // Get the current theme
    $active_theme = $GLOBALS['theme_key'];
    $form_state['build_info']['files'][] = str_replace("/$active_theme.info", '', $themes[$active_theme]->filename) . '/theme-settings.php';
  	
  	$form['settings'] = array(
      	'#type' => 'vertical_tabs',
      	'#title' => t('Theme settings'),
      	'#weight' => 2,
      	'#collapsible' => TRUE,
      	'#collapsed' => FALSE,
  	);
    $form['settings']['header'] = array(
      '#type' => 'fieldset',
      '#title' => t('Header settings'),
      '#collapsible' => TRUE,
      '#collapsed' => FALSE,
    );
     $form['settings']['header']['header_style'] = array(
      '#title' => t('Header style'),
      '#type' => 'select',
      '#options' => array(
        'style1' => t('Style 1'),
        'style2' => t('Style 2'),
        'style3' => t('Style 3'),
      ),
      '#default_value' => theme_get_setting('header_style', 'zmagazine'),
    );
    $form['settings']['header']['banner'] = array(
        '#type' => 'fieldset',
        '#title' => t('Banner'),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
    );
    
    $form['settings']['header']['banner']['banner_default'] = array(
      '#title' => t('Use the default banner'),
      '#type' => 'checkbox',
      '#default_value' => theme_get_setting('banner_default', 'zmagazine'),
      '#tree' => FALSE, 
    );

    $form['settings']['header']['banner']['upload_banner'] = array(
      '#type' => 'container', 
      '#states' => array(
        // Hide the banner settings when using the default banner.
        'invisible' => array(
          'input[name="banner_default"]' => array('checked' => TRUE),
        ),
      ),
    );
    $form['settings']['header']['banner']['upload_banner']['banner_image'] = array(
      '#type' => 'managed_file',
      '#title' => t('Image'),
      '#required' => FALSE,
      '#progress_message' => t('Please wait...'),
      '#progress_indicator' => 'bar',
      '#description'   => t("Upload banner image."),
      '#upload_location' => file_default_scheme() . '://banner_image/',
      '#default_value' => theme_get_setting('banner_image','zmagazine'),
      '#upload_validators' => array(
          'file_validate_extensions' => array('gif png jpg jpeg'),
      ),
    );
    //mobile-logo
    $form['settings']['header']['mobile'] = array(
        '#type' => 'fieldset',
        '#title' => t('Mobile logo'),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
    );
    $form['settings']['header']['mobile']['default_mobile_logo'] = array(
      '#title' => t('Use the default logo'),
      '#type' => 'checkbox',
      '#default_value' => theme_get_setting('default_mobile_logo', 'zmagazine'),
      '#tree' => FALSE, 
    );

    $form['settings']['header']['mobile']['upload_mobile_logo'] = array(
      '#type' => 'container', 
      '#states' => array(
        // Hide the banner settings when using the default logo.
        'invisible' => array(
          'input[name="default_mobile_logo"]' => array('checked' => TRUE),
        ),
      ),
    );
    $form['settings']['header']['mobile']['upload_mobile_logo']['mobile_logo_image'] = array(
      '#type' => 'managed_file',
      '#title' => t('Image'),
      '#required' => FALSE,
      '#progress_message' => t('Please wait...'),
      '#progress_indicator' => 'bar',
      '#description'   => t("Upload logo image."),
      '#upload_location' => file_default_scheme() . '://logo/',
      '#default_value' => theme_get_setting('mobile_logo_image','zmagazine'),
      '#upload_validators' => array(
          'file_validate_extensions' => array('gif png jpg jpeg'),
      ),
    );


    $form['settings']['header']['header_social_networks'] = array(
      '#type' => 'textarea',
      '#title' => t('Social networks'),
      '#default_value' => theme_get_setting('header_social_networks', 'zmagazine'),
    );
     $form['settings']['header']['header_social_networks_more'] = array(
      '#type' => 'textarea',
      '#title' => t('Social networks more'),
      '#default_value' => theme_get_setting('header_social_networks_more', 'zmagazine'),
    );
  	$form['settings']['general_setting'] = array(
      	'#type' => 'fieldset',
      	'#title' => t('General Settings'),
      	'#collapsible' => TRUE,
      	'#collapsed' => FALSE,
  	);

  	$form['settings']['general_setting']['general_setting_tracking_code'] = array(
      	'#type' => 'textarea',
      	'#title' => t('Tracking Code'),
      	'#default_value' => theme_get_setting('general_setting_tracking_code', 'zmagazine'),
  	);

  	
 // Blog settings
  $form['settings']['blog'] = array(
    '#type' => 'fieldset',
    '#title' => t('Blog settings'),
    '#collapsible' => TRUE,
    '#collapsed' => FALSE,
  );
  $form['settings']['blog']['blog_listing'] = array(
    '#type' => 'fieldset',
    '#title' => t('Blog listing'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  $form['settings']['blog']['blog_listing']['blog_header_settings'] = array(
    '#type' => 'fieldset',
    '#title' => t('Header settings'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  $form['settings']['blog']['blog_listing']['blog_listing_sidebar'] = array(
      '#title' => t('Blog listing sidebar'),
      '#type' => 'select',
      '#options' => array(
        'none' => t('None'),
        'left' => t('Left'),
        'right' => t('Right'),
      ),
      '#default_value' => theme_get_setting('blog_listing_sidebar', 'zmagazine'),
    );

  $form['settings']['blog']['blog_listing']['blog_header_settings']['blog_header_style'] = array(
      '#title' => t('Header style'),
      '#type' => 'select',
      '#options' => array(
        'style1' => t('Style 1'),
        'style2' => t('Style 2'),
        'style3' => t('Style 3'),
      ),
      '#default_value' => theme_get_setting('blog_header_style', 'zmagazine'),
    );
    $form['settings']['blog']['blog_listing']['blog_banner'] = array(
      '#type' => 'fieldset',
      '#title' => t('Banner'),
      '#collapsible' => TRUE,
      '#collapsed' => TRUE,
    );
      $form['settings']['blog']['blog_listing']['blog_banner']['blog_banner_default'] = array(
      '#title' => t('Use the default banner'),
      '#type' => 'checkbox',
      '#default_value' => theme_get_setting('blog_banner_default', 'zmagazine'),
    );
     $form['settings']['blog']['blog_listing']['blog_banner']['blog_upload_banner'] = array(
      '#type' => 'container', 
      '#states' => array(
        // Hide the banner settings when using the default banner.
        'invisible' => array(
          'input[name="blog_banner_default"]' => array('checked' => TRUE),
        ),
      ),
    );
    $form['settings']['blog']['blog_listing']['blog_banner']['blog_upload_banner']['blog_banner_image'] = array(
      '#type' => 'managed_file',
      '#title' => t('Image'),
      '#required' => FALSE,
      '#progress_message' => t('Please wait...'),
      '#progress_indicator' => 'bar',
      '#description'   => t("Upload banner image."),
      '#upload_location' => file_default_scheme() . '://banner_image/',
      '#default_value' => theme_get_setting('blog_banner_image','zmagazine'),
      '#upload_validators' => array(
          'file_validate_extensions' => array('gif png jpg jpeg'),
      ),
    );
    //blog header background
      $form['settings']['blog']['blog_listing']['blog_background'] = array(
      '#type' => 'fieldset',
      '#title' => t('Header background'),
      '#collapsible' => TRUE,
      '#collapsed' => TRUE,
    );
   
    $form['settings']['blog']['blog_listing']['blog_background']['blog_background_image'] = array(
      '#type' => 'managed_file',
      '#title' => t('Image'),
      '#required' => FALSE,
      '#progress_message' => t('Please wait...'),
      '#progress_indicator' => 'bar',
      '#description'   => t("Upload background image."),
      '#upload_location' => file_default_scheme() . '://background_image/',
      '#default_value' => theme_get_setting('blog_background_image','zmagazine'),
      '#upload_validators' => array(
          'file_validate_extensions' => array('gif png jpg jpeg'),
      ),
    );

     // Blog single settings

  $form['settings']['blog']['blog_single'] = array(
    '#type' => 'fieldset',
    '#title' => t('Blog single'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  $form['settings']['blog']['blog_single']['blog_single_header_settings'] = array(
    '#type' => 'fieldset',
    '#title' => t('Header settings'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  $form['settings']['blog']['blog_single']['blog_single_header_settings']['blog_single_header_style'] = array(
      '#title' => t('Header style'),
      '#type' => 'select',
      '#options' => array(
        'style1' => t('Style 1'),
        'style2' => t('Style 2'),
        'style3' => t('Style 3'),
      ),
      '#default_value' => theme_get_setting('blog_single_header_style', 'zmagazine'),
    );
    $form['settings']['blog']['blog_single']['blog_single_banner'] = array(
      '#type' => 'fieldset',
      '#title' => t('Banner'),
      '#collapsible' => TRUE,
      '#collapsed' => TRUE,
    );
      $form['settings']['blog']['blog_single']['blog_single_banner']['blog_single_banner_default'] = array(
      '#title' => t('Use the default banner'),
      '#type' => 'checkbox',
      '#default_value' => theme_get_setting('blog_single_banner_default', 'zmagazine'),
    );
     $form['settings']['blog']['blog_single']['blog_single_banner']['blog_single_upload_banner'] = array(
      '#type' => 'container', 
      '#states' => array(
        // Hide the banner settings when using the default banner.
        'invisible' => array(
          'input[name="blog_single_banner_default"]' => array('checked' => TRUE),
        ),
      ),
    );
    $form['settings']['blog']['blog_single']['blog_single_banner']['blog_single_upload_banner']['blog_single_banner_image'] = array(
      '#type' => 'managed_file',
      '#title' => t('Image'),
      '#required' => FALSE,
      '#progress_message' => t('Please wait...'),
      '#progress_indicator' => 'bar',
      '#description'   => t("Upload banner image."),
      '#upload_location' => file_default_scheme() . '://banner_image/',
      '#default_value' => theme_get_setting('blog_single_banner_image','zmagazine'),
      '#upload_validators' => array(
          'file_validate_extensions' => array('gif png jpg jpeg'),
      ),
    );
    //blog single header background
      $form['settings']['blog']['blog_single']['blog_single_background'] = array(
      '#type' => 'fieldset',
      '#title' => t('Header background'),
      '#collapsible' => TRUE,
      '#collapsed' => TRUE,
    );
   
    $form['settings']['blog']['blog_single']['blog_single_background']['blog_single_background_image'] = array(
      '#type' => 'managed_file',
      '#title' => t('Image'),
      '#required' => FALSE,
      '#progress_message' => t('Please wait...'),
      '#progress_indicator' => 'bar',
      '#description'   => t("Upload background image."),
      '#upload_location' => file_default_scheme() . '://background_image/',
      '#default_value' => theme_get_setting('blog_single_background_image','zmagazine'),
      '#upload_validators' => array(
          'file_validate_extensions' => array('gif png jpg jpeg'),
      ),
    );
  // custom css
	$form['settings']['custom_css'] = array(
		'#type' => 'fieldset',
		'#title' => t('Custom CSS'),
		'#collapsible' => TRUE,
		'#collapsed' => FALSE,
	);
  

	$form['settings']['custom_css']['custom_css'] = array(
		'#type' => 'textarea',
		'#title' => t('Custom CSS'),
		'#default_value' => theme_get_setting('custom_css', 'zmagazine'),
		'#description'  => t('<strong>Example:</strong><br/>h1 { font-family: \'Metrophobic\', Arial, serif; font-weight: 400; }')
	);
  //footer settings
  $form['settings']['footer'] = array(
    '#type' => 'fieldset',
    '#title' => t('Footer settings'),
    '#collapsible' => TRUE,
    '#collapsed' => FALSE,
  );
  $form['settings']['footer']['footer_social_networks'] = array(
    '#type' => 'textarea',
    '#title' => t('Social networks'),
    '#default_value' => theme_get_setting('footer_social_networks', 'zmagazine'),
  );
  $form['settings']['footer']['copyright_text'] = array(
    '#type' => 'textarea',
    '#title' => t('Copyright text'),
    '#default_value' => theme_get_setting('copyright_text', 'zmagazine'),
  );

}
function zmagazine_settings_form_submit(&$form, $form_state) {

  $image_fid  = $form_state['values']['blog_background_image'];
  $image_fid2 = $form_state['values']['blog_banner_image'];
  $image_fid3 = $form_state['values']['banner_image'];
  $image_fid4 = $form_state['values']['blog_single_banner_image'];
  $image_fid5 = $form_state['values']['blog_single_background_image'];
  $image_fid6 = $form_state['values']['mobile_logo_image'];
  $image1 = file_load($image_fid);
  $image2 = file_load($image_fid2);
  $image3 = file_load($image_fid3);
  $image4 = file_load($image_fid4);
  $image5 = file_load($image_fid5);
  $image6 = file_load($image_fid6);
  if (is_object($image1)) {
  // Check to make sure that the file is set to be permanent.
    if ($image1->status == 0) {
    // Update the status.
    $image1->status = FILE_STATUS_PERMANENT;
    // Save the update.
    file_save($image1);
    // Add a reference to prevent warnings.
    file_usage_add($image1, 'zmagazine', 'theme', 1);
    }
  }

  if (is_object($image2)) {
  // Check to make sure that the file is set to be permanent.
    if ($image2->status == 0) {
    // Update the status.
    $image2->status = FILE_STATUS_PERMANENT;
    // Save the update.
    file_save($image2);
    // Add a reference to prevent warnings.
    file_usage_add($image2, 'zmagazine', 'theme', 1);
    }
  }

  if (is_object($image3)) {
  // Check to make sure that the file is set to be permanent.
    if ($image3->status == 0) {
    // Update the status.
    $image3->status = FILE_STATUS_PERMANENT;
    // Save the update.
    file_save($image3);
    // Add a reference to prevent warnings.
    file_usage_add($image3, 'zmagazine', 'theme', 1);
    }
  }
  if (is_object($image4)) {
  // Check to make sure that the file is set to be permanent.
    if ($image4->status == 0) {
    // Update the status.
    $image4->status = FILE_STATUS_PERMANENT;
    // Save the update.
    file_save($image4);
    // Add a reference to prevent warnings.
    file_usage_add($image4, 'zmagazine', 'theme', 1);
    }
  }
  if (is_object($image5)) {
  // Check to make sure that the file is set to be permanent.
    if ($image5->status == 0) {
    // Update the status.
    $image5->status = FILE_STATUS_PERMANENT;
    // Save the update.
    file_save($image5);
    // Add a reference to prevent warnings.
    file_usage_add($image5, 'zmagazine', 'theme', 1);
    }
  }
  if (is_object($image6)) {
  // Check to make sure that the file is set to be permanent.
    if ($image6->status == 0) {
    // Update the status.
    $image6->status = FILE_STATUS_PERMANENT;
    // Save the update.
    file_save($image6);
    // Add a reference to prevent warnings.
    file_usage_add($image6, 'zmagazine', 'theme', 1);
    }
  }

}