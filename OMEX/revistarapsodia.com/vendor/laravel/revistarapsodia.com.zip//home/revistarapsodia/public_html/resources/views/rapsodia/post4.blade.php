@extends('master.home')


@section('adsense')
    
         <script async src="//"></script>
         <!-- Anuncios R1 -->
         <ins class="adsbygoogle"
              style="display:block"
              data-ad-client="ca-pub-7473782780390075"
              data-ad-slot="8544575149"
              data-ad-format="auto"></ins>
         <script>
         (adsbygoogle = window.adsbygoogle || []).push({});
         </script>
@endsection


@section('content')
    <div class="tn-breadcrumbs-wrap clearfix">
        <div class="tn-breadcrumbs-inner tn-container">
            <span><a href="{{ asset('/') }}">HOME</a></span>
            @if($section->menu != null)
                <i class="fa fa-angle-right next-breadcrumbs"></i>
                <span><a href="{{ asset($section->menu->url) }}">{{ $section->menu->name }}</a></span>
            @endif
            <i class="fa fa-angle-right next-breadcrumbs"></i>
            <span>{{ $section->name }}</span>
            <!--#breadcrumbs -->
        </div>
        <div class="tn-single-style4-wrap tn-single-thumb-parallax">
            <div id="tn-single-image-parallax" data-background-image-header="{{ asset('storage/app/post'.$post->id. '/' . $post->content->url_image) }}"></div>
        </div>
        <article class="tn-container tn-section-content-wrap tn-single-style4-main-wrap row clearfix">
            <article style="float:left" class="tn-content-wrap tn-fw-mode col-sm-8 col-xs-12 post type-post status-publish format-standard has-post-thumbnail hentry">
                <div class="tn-single-top-meta-wrap">
                    <div style="float:left">
                        <div class="tn-category-tags-wrap">         <a href="{{ asset($section->url) }}" typeof="skos:Concept" property="rdfs:label skos:prefLabel" datatype="">{{ $section->name }}</a>    </div>

                </span></span>
                        <!--category tags -->
                    </div>
                    <div class="tn-single-top-meta-right">
                        <span class="tn-single-top-meta-date single-meta-right-el">{{ date('d/m/Y',  strtotime($post->created_at)) }}</span>
                    </div>
                    <!--#top meta right-->
                </div>
                <!--#top meta wrap-->
                <div class="tn-single-title-wrap">
                    <h1 itemprop="name" class="tn-single-title">{{ $post->title }}</h1>
                    <!--#title-->
                </div>
                <!--#single title -->
                <div class="tn-single-share-wrap tn-single-top-share-wrap">
                    <div class="tn-share-social-box">
    <a class="tn-single-share-button tn-social-facebook" href="javascript:;" id="shareBtn"><i class="fa fa-facebook"></i><span class="tn-social-text">FACEBOOK</span></a>
                        <a class="tn-single-share-button tn-social-twitter" href="https://twitter.com/intent/tweet?text=Revista Rapsodia - {{ $post->title }}&amp;url={{ asset($section->url) }}/{{$post->id}}" onclick="window.open(this.href, 'mywin',
      'left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="fa fa-twitter"></i><span class="tn-social-text">TWITTER</span></a> 
  </div>
                </div>
                <!--#single top share -->
                <div class="tn-single-content-wrap tn-single-no-left-col">
                    <div class="tn-single-content-inner">
                        <div class="single-post-content">
                            {!! $post->content->text_1 !!}


                            @if($post->content->image != null)
                                <img style="width: 100%" src="{{ asset('storage/app/post'.$post->id. '/' . $post->content->image) }}" >
                                <figcaption class="wp-caption-text">
                                    {{  $post->content->caption }}
                                </figcaption>
                            @endif

                            {!! $post->content->text_2 !!}

                            @if(strlen($post->content->sentence) > 1)
                                <blockquote>
                                    <p> {{ $post->content->sentence }}</p>
                                </blockquote>
                            @endif

                            {!! $post->content->text_3 !!}

                            <hr>
                            {!! $post->content->biography !!}
                        </div>
                        <!--content-->
                    </div>
                    <!--#post content inner-->
                </div>
                <!--#post content wrap-->
                <div id="fb-root"></div>
                       <script>
                  window.fbAsyncInit = function() {
                    FB.init({
                      appId            : '1786715748275912',
                      autoLogAppEvents : true,
                      xfbml            : true,
                      version          : 'v2.10'
                    });
                    FB.AppEvents.logPageView();
                  };

                  (function(d, s, id){
                     var js, fjs = d.getElementsByTagName(s)[0];
                     if (d.getElementById(id)) {return;}
                     js = d.createElement(s); js.id = id;
                     js.src = "//connect.facebook.net/es_LA/sdk.js";
                     fjs.parentNode.insertBefore(js, fjs);
                   }(document, 'script', 'facebook-jssdk'));
                </script>
                <div class="fb-comments" data-href="{{ asset('/' . $section->url . '/'. $post->id)}}" data-numposts="5" data-width="100%"></div>

                @include('rapsodia.includes.mayInterestYou')

            </article>

            <div class="tn-sidebar-wrap col-sm-4 col-xs-12 clearfix">
                    <div class="tn-sidebar-sticky">
                        <aside class="block block-block widget about-widget" >
                            <div class="widget-title">
                                <h3>AUTOR</h3>
                            </div>
                            <div class="about-widget-image">
                                <img src="{{ asset('storage/app/authors/'.$post->author->imageProfile) }}" alt="camera-man" style="width: 50%;"/>
                            </div>
                            <!--#image-->
                            <div class="about-widget-content">
                                <p style="text-align: center; margin: 0 24px;">
                                    <strong style="font-size: 18px;">{{ $post->author->name }}</strong><br><br>
                                        {{ $post->author->description }}<br><br>
                                        <strong style="font-size: 14px;">{{ $post->author->jobTitle }}</strong>
                                </p>
                            </div>
                            <!--about-content-->
                            <!--div class="about-social-wrap">
                                <div class="tn-topbar-social-wrap"><a title="facebook" href="index_blog.html" target="_blank" class="icon-social icon-facebook"></a><a title="twitter" href="#" target="_blank" class="icon-social icon-twitter"></a><a title="google_plus" href="index_blog.html" target="_blank" class="icon-social icon-google_plus"></a><a title="pinterest" href="index_blog.html" target="_blank" class="icon-social icon-pinterest"></a><a title="youtube" href="index_blog.html" target="_blank" class="icon-social icon-youtube"></a><a title="vimeo" href="index_blog.html" target="_blank" class="icon-social icon-vimeo"></a><a title="skype" href="index_blog.html" target="_blank" class="icon-social icon-skype"></a><a title="rss" href="index_blog.html" target="_blank" class="icon-social icon-rss"></a></div>
                            </div-->
                        </aside>
                        <!--aside class="block block-views widget widget_tag_cloud" >
                            <img src="{{ $marketing }}" style="width: 100%;">
                        </aside>
                        <aside class="block block-views widget widget_categories" >
                            <img src="https://static.pexels.com/photos/36487/above-adventure-aerial-air.jpg" style="width: 100%;">
                        </aside-->
                        @include('rapsodia.includes.marketing')

                        @include('rapsodia.includes.hearitsecction')
                    </div>
                </div>

        </article>

    </div>

@endsection

@section('scripts')
s
@endsection