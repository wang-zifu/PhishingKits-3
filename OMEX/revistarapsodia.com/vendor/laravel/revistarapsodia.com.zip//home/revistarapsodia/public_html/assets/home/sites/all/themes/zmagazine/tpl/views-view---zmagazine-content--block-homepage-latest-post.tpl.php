<?php print render($title_prefix); ?>
<div class="tn-block4-wrap tn-block-wrap clearfix">
	<?php if($header): ?>
		<?php print $header; ?>
	<?php endif; ?>
	<!--#block header wrap -->
	<?php if($rows): ?>
	<div class="tn-block4-content-wrap tn-block-content-wrap">
		<div class="tn-block4-content-inner tn-block-content-inner">
			<?php print $rows; ?>
		</div>
	</div>
	<?php endif; ?>
	<!--#block content wrap-->
	<?php if($footer): ?>
	<div class="tn-load-more-wrap clearfix">
		<span class="tn-load-more-liner"></span><!--#loadmore liner -->
		<div class="tn-load-more-inner"><?php print $footer; ?></div>
	</div>
	<!--#load more wrap-->
	<?php endif; ?>
</div>
