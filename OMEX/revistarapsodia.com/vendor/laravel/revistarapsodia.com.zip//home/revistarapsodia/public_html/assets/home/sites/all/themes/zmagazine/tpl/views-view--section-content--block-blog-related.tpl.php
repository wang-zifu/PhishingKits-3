<?php print render($title_prefix); ?>
<?php if($header): ?>
<div class="single-related-title block-title-wrap">
	<?php print $header; ?>
</div>
<?php endif; ?>
<!--#related title-->
<?php if($rows): ?>
<div class="tn-block-content-wrap tn-single-related-content row">
	<div class="tn-block-content-inner clearfix">
		<?php print $rows; ?>
	</div>
</div>
<?php endif; ?>
