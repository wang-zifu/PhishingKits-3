<?php

$SEND="mdw.i@aol.com"; //  EMAIL


?>