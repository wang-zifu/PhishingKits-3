<?php

$SEND="awalshesq@aol.com"; //  EMAIL


?>