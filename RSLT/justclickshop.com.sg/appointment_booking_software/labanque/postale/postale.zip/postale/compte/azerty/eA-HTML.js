var default_lang = "fr";
var nolocalcheck = false;
var lastErrors = null;

function newErrors() {
    var a = [];
    a.add = function(c, d) {
        var b = new Object();
        b.field = c;
        b.error = d;
        this[this.length] = b;
        return this
    };
    a.find = function(c) {
        for (var b = 0; b < this.length;
            ++b) {
            if (this[b].field == c) {
                return this[b]
            }
        }
        return null
    };
    return a
}
var strboolean_en = new Array();
strboolean_en["true"] = "true";
strboolean_en["false"] = "false";
strboolean_en.yes = "yes";
strboolean_en.no = "no";
strboolean_en.y = "y";
strboolean_en.n = "n";
var strboolean_fr = new Array();
strboolean_fr["true"] = "vrai";
strboolean_fr["false"] = "faux";
strboolean_fr.yes = "oui";
strboolean_fr.no = "non";
strboolean_fr.y = "o";
strboolean_fr.n = "n";

function onsubmit_boolean(e, d, c, g) {
    var f = e.value;
    if (typeof g == "undefined") {
        ea_log("onsubmit_boolean V1");
        if (f == "") {
            c.add(e, NLSString("empty"))
        } else {
            var a = this["strboolean_" + getLang()];
            if (!a) {
                this["strboolean_" + getBaseLang()]
            }
            for (var b in a) {
                if (f == a[b]) {
                    return
                }
            }
        }
        c.add(e, NLSString("boolean"))
    } else {
        ea_log("onsubmit_boolean V3");
        if (f == "") {
            g.add(e, NLSString("empty"))
        } else {
            var a = this["strboolean_" + getLang()];
            if (!a) {
                this["strboolean_" + getBaseLang()]
            }
            for (var b in a) {
                if (f == a[b]) {
                    return
                }
            }
        }
        g.add(e, NLSString("boolean"))
    }
}

function onsubmit_java_lang_Boolean(c, b, a, d) {
    onsubmit_boolean(c, b, a, d)
}

function onsubmit_byte(c, b, a, e) {
    var d = c.value;
    if (typeof e == "undefined") {
        ea_log("onsubmit_byte V1");
        if (!b && d == "") {
            a.add(c, NLSString("empty"))
        } else {
            if (isNaN(d)) {
                a.add(c, NLSString("byte"))
            } else {
                if ((d > 127) || (d < -128)) {
                    a.add(c, NLSString("byte"))
                }
            }
        }
    } else {
        ea_log("onsubmit_byte V3");
        if (!b && d == "") {
            e.add(c, NLSString("empty"))
        } else {
            if (d != "" && a != "" && !d.match(a)) {
                e.add(c, NLSString("byte"))
            } else {
                if ((d > 127) || (d < -128)) {
                    e.add(c, NLSString("byte"))
                }
            }
        }
    }
}

function onsubmit_java_lang_Byte(c, b, a, d) {
    onsubmit_byte(c, b, a, d)
}

function onsubmit_java_util_Date(c, b, a, d) {
    if (typeof d == "undefined") {
        onsubmit_java_util_Date_V1(c, b, a, d)
    } else {
        onsubmit_java_util_Date_V3(c, b, a, d)
    }
}

function onsubmit_java_util_Date_V1(n, h, m, p) {
    ea_log("onsubmit_java_util_Date_V1");
    var g = n.value;
    if (typeof p == "undefined") {
        var a = /[0-9\.\-\/ ]/;
        var b = /^(\d{1,2})[- \.\/](\d{1,2})[- \.\/](\d{1,4})$/;
        var j = true;
        var c = "eu";
        var g = n.value;
        if (!h && g == "") {
            return m.add(n, NLSString("empty"))
        }
        if (h && g == "") {
            return
        }
        var o = g.match(b);
        if (o == null) {
            return m.add(n, NLSString("java.util.Date"))
        }
        var f = o[1];
        var l = o[2];
        var e = o[3];
        if (c == "us") {
            var r = l;
            l = f;
            f = r
        }
        var d = parseInt(f, 10);
        if (isNaN(d)) {
            return m.add(n, NLSString("java.util.Date"))
        }
        var q = parseInt(l, 10);
        if (isNaN(q)) {
            return m.add(n, NLSString("java.util.Date"))
        }
        var k = parseInt(e, 10);
        if (isNaN(k)) {
            return m.add(n, NLSString("java.util.Date"))
        }
        if (k < 100) {
            k += 2000
        }
        if (d < 1) {
            return m.add(n, NLSString("java.util.Date"))
        }
        if (q > 12 || q < 1) {
            return m.add(n, NLSString("java.util.Date"))
        }
        if (q == 2) {
            if (((k % 100 == 0) ? k % 400 : k % 4) == 0) {
                if (d > 29 || d < 1) {
                    j = false
                }
            } else {
                if (d > 28 || d < 1) {
                    j = false
                }
            }
        }
        if ((q == 1 || q == 3 || q == 5 || q == 7 || q == 8 || q == 10 || q == 12) && (d > 31 || d < 1)) {
            return m.add(n, NLSString("java.util.Date"))
        }
        if ((q == 4 || q == 6 || q == 9 || q == 11) && (d > 30 || d < 1)) {
            return m.add(n, NLSString("java.util.Date"))
        }
        if ((q == 2) && (j == false)) {
            return m.add(n, NLSString("java.util.Date"))
        }
        n.value = d + "/" + q + "/" + k
    }
}

function onsubmit_java_util_Date_V3(m, g, l, o) {
    ea_log("onsubmit_java_util_Date_V3");
    var b = getFieldName(m, new Array());
    var a = b.name;
    var f = getFieldValue(m.form, a);
    if (!g && f == "") {
        o.add(m, NLSString("empty"))
    } else {
        if (f != "" && l != "" && !f.match(l)) {
            o.add(m, NLSString("date"))
        } else {
            if (f != "") {
                var h = true;
                var f = getFieldValue(m.form, a);
                var n = "'" + f.match(l) + "'";
                if (l.indexOf("[0-1]") == 1) {
                    style = "en"
                } else {
                    style = "fr"
                }
                var e = "";
                var k = "";
                var d = "";
                if (style == "fr") {
                    e = n.substr(1, 2);
                    k = n.substr(4, 2);
                    d = n.substr(7, 4)
                } else {
                    k = n.substr(1, 2);
                    e = n.substr(4, 2);
                    d = n.substr(7, 4)
                }
                var c = parseInt(e, 10);
                if (isNaN(c)) {
                    return o.add(m, NLSString("date"))
                }
                var p = parseInt(k, 10);
                if (isNaN(p)) {
                    return o.add(m, NLSString("date"))
                }
                var j = parseInt(d, 10);
                if (isNaN(j)) {
                    return o.add(m, NLSString("date"))
                }
                if (j < 100) {
                    j += 2000
                }
                var q = new Date(j, p - 1, c);
                if ((c == q.getDate()) && (p == q.getMonth() + 1) && (j == q.getFullYear())) {
                    h = true
                } else {
                    h = false;
                    return o.add(m, NLSString("date"))
                }
                if (style == "fr") {
                    m.value = e + "/" + k + "/" + d
                } else {
                    if (style == "en") {
                        m.value = k + "." + e + "." + d
                    }
                }
            }
        }
    }
}

function onsubmit_java_sql_Date(c, b, a, d) {
    onsubmit_java_util_Date(c, b, a, d)
}

function onsubmit_java_util_Calendar(c, b, a, d) {
    onsubmit_java_util_Date(c, b, a, d)
}

function onsubmit_Currency(c, b, a, e) {
    var d = c.value;
    if (typeof e == "undefined") {} else {
        if (!b && d == "") {
            e.add(c, NLSString("empty"))
        } else {
            if (d != "" && a != "" && !d.match(a)) {
                e.add(c, NLSString("currency"))
            }
        }
    }
}

function onsubmit_EMail(c, b, a, e) {
    var d = c.value;
    if (typeof e == "undefined") {} else {
        if (!b && d == "") {
            e.add(c, NLSString("empty"))
        } else {
            if (d != "" && a != "" && !d.match(a)) {
                e.add(c, NLSString("email"))
            }
        }
    }
}

function onsubmit_char(c, b, a, e) {
    var d = c.value;
    if (typeof e == "undefined") {
        ea_log("onsubmit_char V1");
        if (!b && d == "") {
            a.add(c, NLSString("empty"))
        } else {
            if (d.length > 1) {
                a.add(c, NLSString("char"))
            }
        }
    } else {
        ea_log("onsubmit_char V3");
        if (!b && d == "") {
            e.add(c, NLSString("empty"))
        } else {
            if (d != "" && a != "" && !d.match(a)) {
                e.add(c, NLSString("char"))
            } else {
                if (d.length > 1) {
                    e.add(c, NLSString("char"))
                }
            }
        }
    }
}

function onsubmit_java_lang_Char(c, b, a, d) {
    onsubmit_char(c, b, a, d)
}

function onsubmit_short(c, b, a, e) {
    var d = c.value;
    if (typeof e == "undefined") {
        ea_log("onsubmit_short V1");
        if (!b && d == "") {
            a.add(c, NLSString("empty"))
        } else {
            if (isNaN(d)) {
                a.add(c, NLSString("short"))
            } else {
                if ((d > 32767) || (d < -32768)) {
                    a.add(c, NLSString("short"))
                }
            }
        }
    } else {
        ea_log("onsubmit_short V3");
        if (!b && d == "") {
            e.add(c, NLSString("empty"))
        } else {
            if (d != "" && a != "" && !d.match(a)) {
                e.add(c, NLSString("short"))
            } else {
                if ((d > 32767) || (d < -32768)) {
                    e.add(c, NLSString("short"))
                }
            }
        }
    }
}

function onsubmit_java_lang_Short(c, b, a, d) {
    onsubmit_short(c, b, a, d)
}

function onsubmit_int(c, b, a, e) {
    var d = c.value;
    if (typeof e == "undefined") {
        ea_log("onsubmit_int V1");
        if (!b && d == "") {
            a.add(c, NLSString("empty"))
        } else {
            if (isNaN(d)) {
                a.add(c, NLSString("int"))
            } else {
                if ((d > 2147483647) || (d < -2147483648)) {
                    a.add(c, NLSString("int"))
                }
            }
        }
    } else {
        ea_log("onsubmit_int V3");
        if (!b && d == "") {
            e.add(c, NLSString("empty"))
        } else {
            if (d != "" && a != "" && !d.match(a)) {
                e.add(c, NLSString("int"))
            } else {
                if ((d > 2147483647) || (d < -2147483648)) {
                    e.add(c, NLSString("int"))
                }
            }
        }
    }
}

function onsubmit_java_lang_Integer(c, b, a, d) {
    onsubmit_int(c, b, a, d)
}

function onsubmit_long(c, b, a, e) {
    var d = c.value;
    if (typeof e == "undefined") {
        ea_log("onsubmit_long V1");
        if (!b && d == "") {
            a.add(c, NLSString("empty"))
        } else {
            if (isNaN(d)) {
                a.add(c, NLSString("long"))
            } else {
                if ((d > 9223372036854776000) || (d < -9223372036854776000)) {
                    a.add(c, NLSString("long"))
                }
            }
        }
    } else {
        ea_log("onsubmit_int V3");
        if (!b && d == "") {
            e.add(c, NLSString("empty"))
        } else {
            if (d != "" && a != "" && !d.match(a)) {
                e.add(c, NLSString("long"))
            } else {
                if ((d > 9223372036854776000) || (d < -9223372036854776000)) {
                    e.add(c, NLSString("long"))
                }
            }
        }
    }
}

function onsubmit_java_lang_Long(c, b, a, d) {
    onsubmit_long(c, b, a, d)
}

function onsubmit_float(d, c, b, f) {
    var e = d.value;
    var a = parseFloat(e);
    if (typeof f == "undefined") {
        ea_log("onsubmit_float V1");
        if (!c && e == "") {
            b.add(d, NLSString("empty"))
        } else {
            if (isNaN(a)) {
                b.add(d, NLSString("float"))
            } else {
                if ((a > 3.4028235e+38) || ((a != 0) && (a < 1.4e-45))) {
                    b.add(d, NLSString("float"))
                }
            }
        }
    } else {
        ea_log("onsubmit_float V3");
        if (!c && e == "") {
            f.add(d, NLSString("empty"))
        } else {
            if (e != "" && b != "" && !e.match(b)) {
                f.add(d, NLSString("float"))
            } else {
                if ((a > 3.4028235e+38) || ((a != 0) && (a < 1.4e-45))) {
                    f.add(d, NLSString("float"))
                }
            }
        }
    }
}

function onsubmit_java_lang_Float(c, b, a, d) {
    onsubmit_float(c, b, a, d)
}

function onsubmit_double(c, b, a, e) {
    var d = c.value;
    if (typeof e == "undefined") {
        ea_log("onsubmit_double V1");
        if (!b && d == "") {
            a.add(c, NLSString("empty"))
        } else {
            if (isNaN(parseFloat(d))) {
                a.add(c, NLSString("double"))
            }
        }
    } else {
        ea_log("onsubmit_double V3");
        if (!b && d == "") {
            e.add(c, NLSString("empty"))
        } else {
            if (d != "" && a != "" && !d.match(a)) {
                e.add(c, NLSString("double"))
            }
        }
    }
}

function onsubmit_java_lang_Double(c, b, a, d) {
    onsubmit_double(c, b, a, d)
}

function onsubmit_java_lang_String(c, b, a, d) {
    if (typeof d == "undefined") {
        ea_log("onsubmit_String V1");
        if (!b && (c.value == "")) {
            a.add(c, NLSString("empty"))
        }
    } else {
        ea_log("onsubmit_String V3");
        if (!b && (c.value == "")) {
            d.add(c, NLSString("empty"))
        }
    }
}

function is_select_radio_checkbox(e, b, d, c, f) {
    ea_log("is_select_radio_checkbox V1");
    if (e.type == "select-one" || e.type == "select-multiple") {
        return true
    }
    if (e.type == "radio" || e.type == "checkbox") {
        return true
    }
    if (e.type == undefined && e.length != undefined) {
        for (var a = 0; a < e.length; a++) {
            if (e[a].type == "radio" || e[a].type == "checkbox") {
                return true
            }
        }
    }
    return false
}

function control_html_select(d, a, c, b, e) {
    if (typeof e == "undefined") {
        ea_log("control_html_select V1");
        if (!c && d.selectedIndex <= 0) {
            b.add(d, NLSString("empty"))
        }
    } else {
        ea_log("control_html_select V3");
        if (!c && d.selectedIndex <= 0) {
            e.add(d, NLSString("empty"))
        }
    }
    return
}

function detect_control_html_radio_checkbox_collection(e, b, d, c, h) {
    if (typeof h == "undefined") {
        ea_log("detect_control_html_radio_checkbox_collection V1 : " + b + "," + e.name)
    } else {
        ea_log("detect_control_html_radio_checkbox_collection V3 : " + b + "," + e.name)
    }
    if (e.type == "radio" || e.type == "checkbox") {
        if (typeof h == "undefined") {
            if (!d && !e.checked) {
                c.add(e, NLSString("empty"))
            }
        } else {
            if (!d && !e.checked) {
                h.add(e, NLSString("empty"))
            }
        }
        return true
    }
    if (e.type == undefined && e.length != undefined) {
        var g = false;
        var f = -1;
        for (var a = 0; a < e.length; a++) {
            if (e[a].type == "radio" || e[a].type == "checkbox") {
                if (f == -1) {
                    f = a
                }
                if (e[a].checked) {
                    g = true;
                    break
                }
            }
        }
        if (!d && f > -1 && !g) {
            h.add(e[f], NLSString("empty"))
        }
        if (f != -1) {
            return true
        }
    }
    return false
}

function onsubmit_field(h, g, e, f, j) {
    if (nolocalcheck) {
        return
    }
    if (h.type == "select-one" || h.type == "select-multiple") {
        control_html_select(h, g, e, f, j);
        return
    }
    if (detect_control_html_radio_checkbox_collection(h, g, e, f, j)) {
        return
    }
    if (h.type == undefined && h.length != undefined) {
        isChecked = false;
        idxRadioOrCheckbox = -1;
        for (i = 0; i < h.length; i++) {
            if (h[i].type == "radio" || h[i].type == "checkbox") {
                idxRadioOrCheckbox = i;
                if (h[i].checked) {
                    isChecked = true;
                    break
                }
            }
        }
        if (idxRadioOrCheckbox > -1 && !isChecked) {
            j.add(h[idxRadioOrCheckbox], NLSString("empty"))
        }
        return
    }
    if (h.name === undefined && getFieldType(h) != "fieldset") {
        alert("Error : bad field name");
        return
    }
    if (g != "") {
        if (g.indexOf("Currency") >= 0) {
            g = "Currency"
        } else {
            if (g.indexOf("InternetAddress") >= 0) {
                g = "EMail"
            }
        }
    }
    var d;
    var k;
    var c = h.form;
    var a = h.name;
    var b = h.id;
    if (c.name != "") {
        d = "onsubmit_" + c.name + "_" + a;
        k = "onsubmit_" + c.name + "_" + b
    } else {
        d = "onsubmit_" + a;
        k = "onsubmit_" + b
    }
    d = d.replace(/\./g, "_");
    k = k.replace(/\./g, "_");
    if (this[k]) {
        this[k](h, e, f, j)
    } else {
        if (this[d]) {
            this[d](h, e, f, j)
        } else {
            d = "onsubmit_" + g.replace(/\./g, "_");
            if (this[d]) {
                this[d](h, e, f, j)
            }
        }
    }
}

function onsubmit_validate(a, c) {
    ea_log("onsubmit_validate V3");
    if (nolocalcheck) {
        return
    }
    if (a.name != "") {
        var b = "onsubmit_validate_" + a.name;
        b = b.replace(/\./g, "_");
        if (this[b]) {
            this[b](a, c)
        }
    }
}

function onblur_field(c, a, d) {
    ea_log("onblur_field V1");
    if (nolocalcheck) {
        return
    }
    var f;
    var b = d.form;
    var e = d.id;
    if (e == null || e === undefined || e == "") {
        e = d.name
    }
    if (b.name != "") {
        f = "onblur_" + b.name + "_" + e
    } else {
        f = "onblur_" + e
    }
    f = f.replace(/\./g, "_");
    if (this[f]) {
        this[f](c, d)
    } else {
        f = "onblur_" + a.replace(/\./g, "_");
        if (this[f]) {
            this[f](c, d)
        }
    }
}

function onkeypress_char(b, a, c) {
    ea_log("onkeypress_char V1");
    b.returnValue = (c.value.length == 0)
}

function onkeypress_java_lang_Char(b, a, c) {
    onkeypress_char(b, a, c)
}

function onkeypress_field(c, a, d) {
    ea_log("onkeypress_field V1");
    if (nolocalcheck) {
        return
    }
    var g;
    var b = d.form;
    var f = d.id;
    if (f == null || f === undefined || f == "") {
        f = d.name
    }
    if (b.name != "") {
        g = "onkeypress_" + b.name + "_" + f
    } else {
        g = "onkeypress_" + f
    }
    g = g.replace(/\./g, "_");
    if (this[g]) {
        this[g](c, a, d)
    } else {
        var e = "charset_" + a.replace(/\./g, "_");
        if (this[e]) {
            c.returnValue = this[e].test(String.fromCharCode(c.keyCode))
        } else {
            g = "onkeypress_" + a.replace(/\./g, "_");
            if (this[g]) {
                this[g](c, a, d)
            }
        }
    }
}

function onmouseout_field(b, a, c) {
    ea_log("onmouseout_field V1");
    if (nolocalcheck) {
        return
    }
    window.status = ""
}

function onmouseover_field(b, a, c) {
    ea_log("onmouseover_field V1");
    if (nolocalcheck) {
        return
    }
    setErrorStatus(lastErrors, c)
}

function disableForm() {
    if (document.all || document.getElementById) {
        var a;
        if (document.getElementsByTagName) {
            a = document.getElementsByTagName("input")
        } else {
            if (document.layers) {
                a = new Array()
            } else {
                if (document.all) {
                    a = document.all.tags("input")
                }
            }
        }
        for (i = a.length - 1; i >= 0;
            --i) {
            var b = a[i];
            if (b.type.toLowerCase() == "submit" || b.type.toLowerCase() == "reset" || b.type.toLowerCase() == "image") {
                b.disabled = true
            }
        }
    }
}

function selectFirstError(e) {
    ea_log("selectFirstError : debut");
    for (i = 0; i < e.length;
        ++i) {
        if (e[i].field != null) {
            var c = e[i].field;
            if (getFieldType(c) == "radio" || getFieldType(c) == "checkbox") {
                continue
            }
            var b = c.form;
            if (getFieldType(c) == "hidden") {
                continue
            }
            if (getFieldType(c) == "fieldset") {
                c = document.getElementById(c.id + "_DateInputTagDay")
            }
            for (;;) {
                if (c.focus) {
                    var d = true;
                    if (c.disabled) {
                        d = false
                    }
                    if (d) {
                        c.focus();
                        if (c.select) {
                            c.select()
                        }
                        return
                    }
                }
                for (var a = 0; a < b.elements.length - 1;
                    ++a) {
                    if ((b.elements[a] == c) && (a < b.elements.length - 1)) {
                        c = b.elements[a + 1];
                        break
                    }
                }
            }
            break
        }
    }
}
var _cachedLabels = null;

function getLabels() {
    if (_cachedLabels == null) {
        var a;
        if (document.getElementsByTagName) {
            a = document.getElementsByTagName("label")
        } else {
            if (document.layers) {
                a = new Array()
            } else {
                if (document.all) {
                    a = document.all.tags("label")
                }
            }
        }
        _cachedLabels = a
    }
    return _cachedLabels
}

function resetLabels() {
    var b = getLabels();
    for (var a = 0; a < b.length;
        ++a) {
        b[a].style.color = ""
    }
}

function NLSString(a) {
    return (this["msgset_" + getLang()][a] || this["msgset_" + getBaseLang()][a] || " Erreur ")
}

function getLang() {
    var a = (document.body && document.body.lang) || default_lang || navigator.language || "en";
    a = a.replace(/-/g, "_");
    return a
}

function getBaseLang() {
    var b = (document.body && document.body.lang) || default_lang || navigator.language || "en";
    var a = b.indexOf("-");
    if (a != -1) {
        b = b.substring(0, a)
    }
    return b
}

function getFieldName(f, h) {
    var b = f.name;
    var e = null;
    var a;
    var d = f.form;
    if (d == undefined) {
        d = f[0].form
    }
    var g = f.id;
    if (g == undefined && (getFieldType(f) == "radio" || getFieldType(f) == "checkbox")) {
        g = f[0].id;
        if (g != undefined) {
            if (b != g && g.substring(g.length - 1, g.length) == "0") {
                g = g.substring(0, g.length - 1)
            }
        }
    }
    if (g == undefined || g == "") {
        g = f.name;
        if (g == undefined) {
            g = f[0].name
        }
    }
    if (getFieldType(f) == "fieldset") {
        b = g;
        f.name = g
    }
    if (d.name != "") {
        a = "fields" + d.name
    } else {
        a = "fields"
    }
    if (a && this[a] && this[a][g]) {
        b = e = this[a][g] + " "
    }
    if (h.length == 0) {
        b = g
    } else {
        for (var c = 0; c < h.length;
            ++c) {
            if (h[c].htmlFor == g) {
                if (e == null) {
                    b = h[c].firstChild.nodeValue
                }
                return {
                    name: b,
                    label: h[c]
                }
            } else {
                b = f.name;
                if (b == undefined) {
                    b = f[0].name
                }
            }
        }
    }
    return {
        name: b,
        label: null
    }
}
var labels = new Array();

function getFieldNameWithOutLabel(c) {
    var b = c.form;
    if (b == undefined) {
        b = c[0].form
    }
    var a = labels[b.name];
    if (a != null) {
        if (c.name != undefined) {
            a = labels[b.name][c.name]
        } else {
            a = labels[b.name][c[0].name]
        }
    } else {
        a = null
    }
    ea_log("getFieldNameWithOutLabel : fin");
    return a
}

function makeMessage(k) {
    resetLabels();
    var b = "";
    var c = "";
    var j = new RegExp("%{2}", "g");
    var g = new RegExp("FWMC_REAL_PERCENT", "g");
    var e = getLabels();
    for (var d = 0; d < k.length;
        ++d) {
        var h = k[d];
        var f = "";
        if (h.field != null) {
            var a = getFieldName(h.field, e);
            f = a.name;
            if (a.label != null) {
                a.label.style.color = "red"
            }
        }
        if (h.error) {
            c = h.error.replace(j, "FWMC_REAL_PERCENT");
            c = c.replace(/%/, f) + "\n";
            b = b + c
        } else {
            b = b + f + ": unknown error"
        }
    }
    b = b.replace(g, "%");
    return b
}

function setErrorStatus(f, c) {
    var d = "";
    var a = new RegExp("%{2}", "g");
    var e = new RegExp("FWMC_REAL_PERCENT", "g");
    if (f == null) {
        return
    }
    var b = f.find(c);
    if (b != null) {
        d = b.error.replace(a, "FWMC_REAL_PERCENT");
        d = d.replace(/%/, getFieldName(b.field, getLabels()).name);
        d = d.replace(e, "%");
        window.status = d
    }
}

function verification_minLength(aForm, marqueur, errors) {
    ea_log("verification_minLength V3");
    var nb = aForm.length;
    var i = 0;
    for (; i < nb; i++) {
        var nameElt = aForm.elements[i].name;
        if (nameElt != undefined) {
            if (nameElt.indexOf(marqueur) == 0) {
                var sizeCtrl = eval(aForm.elements[i].value);
                var nameField = nameElt.substring(marqueur.length);
                var sizeField = aForm.elements[nameField].value.length;
                var isDateInputTag = false;
                var msgSpecifiqueDateInputTag = "";
                var suffixesDateInputTag = new Array();
                suffixesDateInputTag[0] = new Array(new RegExp(/DateInputTagDay$/), "Le jour du champ ");
                suffixesDateInputTag[1] = new Array(new RegExp(/DateInputTagMonth$/), "Le mois du champ ");
                suffixesDateInputTag[2] = new Array(new RegExp(/DateInputTagYear$/), "L'ann\351e du champ ");
                var j = 0;
                for (; j < suffixesDateInputTag.length; j++) {
                    if (nameField.match(suffixesDateInputTag[j][0]) != null) {
                        msgSpecifiqueDateInputTag = suffixesDateInputTag[j][1];
                        nameField = nameField.split("_")[0];
                        isDateInputTag = true
                    }
                }
                if (sizeCtrl > sizeField & sizeField > 0) {
                    var msg = "";
                    if (isDateInputTag) {
                        msg += msgSpecifiqueDateInputTag
                    }
                    msg += "% doit contenir au moins " + sizeCtrl + " caract\350re(s)";
                    errors.add(aForm.elements[nameField], msg)
                }
            }
        }
    }
    return errors
}

function compterCarac(d, e, c) {
    var b = d.elements[e].value;
    var a = b.length;
    if (a > c) {
        alert("Pas plus de " + c + " caract\350res dans ce champ");
        a = c;
        d.elements[e].value = b.substring(0, c)
    }
}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_MandatoryClause(a, e, b, d) {
    var c = getFieldValue(a, b);
    if (c == undefined || c == null || c == "" || c == " ") {
        e.add(a[b], d.replace("{0}", b))
    }
}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_MoreThanClause(aForm, errors, name, msg, reference, value) {
    var fieldValue = getFieldValue(aForm, name).replace(",", ".");
    var max = eval(value);
    if (reference != "null") {
        max = eval(getFieldValue(aForm, reference))
    }
    if (fieldValue < max) {
        errors.add(aForm[name], msg.replace("{0}", max))
    }
}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_LessThanClause(aForm, errors, name, msg, reference, value) {
    var fieldValue = getFieldValue(aForm, name).replace(",", ".");
    var min = eval(value);
    if (reference != "null") {
        min = eval(getFieldValue(aForm, reference))
    }
    if (fieldValue > min) {
        errors.add(aForm[name], msg.replace("{0}", min))
    }
}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_EqualsClause(b, h, c, g, a, f) {
    var e = getFieldValue(b, c);
    var d = f;
    if (a != "null") {
        d = getFieldValue(b, a)
    }
    if (e != d) {
        h.add(b[c], g.replace("{0}", d))
    }
}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_NotEqualsClause(b, h, c, g, a, f) {
    var e = getFieldValue(b, c);
    var d = f;
    if (a != "null") {
        d = getFieldValue(b, a)
    }
    if ((e != undefined) && (e != null) && (e != "")) {
        if (e == d) {
            h.add(b[c], g.replace("{0}", d))
        }
    }
}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_RegExpClause(b, h, c, g, a, f) {
    var e = getFieldValue(b, c);
    var d = f;
    if (a != "null") {
        d = a
    }
    if (!e.match(d)) {
        h.add(b[c], g.replace("{0}", f))
    }
}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_MaxLengthClause(aForm, errors, name, msg, reference, value) {
    var fieldValue = getFieldValue(aForm, name);
    var max = eval(value);
    if (reference != "null") {
        max = eval(getFieldValue(aForm, reference))
    }
    if (fieldValue.length > max) {
        errors.add(aForm[name], msg.replace("{0}", max))
    }
}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_MinLengthClause(aForm, errors, name, msg, reference, value) {
    var fieldValue = getFieldValue(aForm, name);
    var min = eval(value);
    if (reference != "null") {
        min = eval(getFieldValue(aForm, reference))
    }
    if (fieldValue.length < min) {
        errors.add(aForm[name], msg.replace("{0}", min))
    }
}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_DecimalPartClause(aForm, errors, name, msg, reference, value) {
    var fieldValue = getFieldValue(aForm, name);
    var maxDec = eval(value);
    if (reference != "null") {
        maxDec = eval(getFieldValue(aForm, reference))
    }
    var reg = new RegExp("^([0-9]*|0)[.,]{0,1}[0-9]{0," + maxDec + "}$", "g");
    if (!fieldValue.match(reg)) {
        errors.add(aForm[name], msg.replace("{0}", maxDec))
    }
}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_PhoneClause(a, g, b, e, f, j) {
    var c = getFieldValue(a, b);
    var h = j;
    if (f != "null") {
        h = getFieldValue(a, f)
    }
    if (h == "xxxxxxxxxx") {
        var d = new RegExp("^[0-9]{10}$", "g")
    }
    if (h == "xx xx xx xx xx") {
        var d = new RegExp("([0-9]{2} ){4}[0-9]{2}$", "g")
    }
    if (h == "xx.xx.xx.xx.xx") {
        var d = new RegExp("^([0-9]{2}[.]){4}[0-9]{2}$", "g")
    }
    if (!c.match(d)) {
        g.add(a[b], e.replace("{0}", h))
    }
}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_TimeClause(a, g, b, e, f, j) {
    var c = getFieldValue(a, b);
    var h = j;
    if (f != "null") {
        h = getFieldValue(a, f)
    }
    if (h == "hh:mm:ss-SSS") {
        var d = new RegExp("^(([0-1]?[0-9])|(2[0-3])):[0-5][0-9]:[0-5][0-9]-[0-9]{3}$", "g")
    }
    if (h == "hh:mm:ss") {
        var d = new RegExp("^(([0-1]?[0-9])|(2[0-3])):[0-5][0-9]:[0-5][0-9]$", "g")
    }
    if (h == "hh:mm") {
        var d = new RegExp("^(([0-1]?[0-9])|(2[0-3])):[0-5][0-9]$", "g")
    }
    if (!c.match(d)) {
        g.add(a[b], e.replace("{0}", h))
    }
}

function date_yy2yyyy(yydate) {
    var annees = yydate;
    if (eval(annees) > 70) {
        annees = "19" + annees
    } else {
        annees = "20" + annees
    }
    return annees
}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_DateClause(aForm, errors, name, msg, reference, value) {
    var fieldValue = getFieldValue(aForm, name);
    if (fieldValue == "") {
        return
    }
    var format = value;
    if (reference != "null") {
        format = getFieldValue(aForm, reference)
    }
    var oDate = new Date();
    var jours;
    var mois;
    var annees;
    var isGestionAnnees = true;
    if (format == "dd/MM" && fieldValue.length == 5) {
        jours = fieldValue.substring(0, 2);
        mois = fieldValue.substring(3, 5);
        annees = oDate.getFullYear()
    } else {
        if (format == "dd/MM/yy" && fieldValue.length == 8) {
            jours = fieldValue.substring(0, 2);
            mois = fieldValue.substring(3, 5);
            annees = fieldValue.substring(6, 8);
            if (isNaN(annees)) {
                errors.add(aForm[name], msg.replace("{0}", format));
                return
            }
            annees = date_yy2yyyy(annees)
        } else {
            if (format == "dd/MM/yyyy" && fieldValue.length == 10) {
                jours = fieldValue.substring(0, 2);
                mois = fieldValue.substring(3, 5);
                annees = fieldValue.substring(6, 10)
            } else {
                if (format == "ddMMyy" && fieldValue.length == 6) {
                    jours = fieldValue.substring(0, 2);
                    mois = fieldValue.substring(2, 4);
                    annees = fieldValue.substring(4, 6);
                    if (isNaN(annees)) {
                        errors.add(aForm[name], msg.replace("{0}", format));
                        return
                    }
                    annees = date_yy2yyyy(annees)
                } else {
                    if (format == "ddMMyyyy" && fieldValue.length == 8) {
                        jours = fieldValue.substring(0, 2);
                        mois = fieldValue.substring(2, 4);
                        annees = fieldValue.substring(4, 8)
                    }
                }
            }
        }
    }
    if (isNaN(jours) || isNaN(mois)) {
        errors.add(aForm[name], msg.replace("{0}", format));
        return
    }
    if (isGestionAnnees && isNaN(annees)) {
        errors.add(aForm[name], msg.replace("{0}", format));
        return
    }
    oDate = new Date(annees, eval(mois - 1), jours);
    var isBissextile = (oDate.getFullYear() % 4 == 0);
    if (jours != oDate.getDate()) {
        if (isBissextile) {
            if (!((jours == 29) && (mois == 2))) {
                errors.add(aForm[name], msg.replace("{0}", format));
                return
            }
        } else {
            errors.add(aForm[name], msg.replace("{0}", format));
            return
        }
    }
    if (mois != oDate.getMonth() + 1) {
        if (isBissextile) {
            if (!((jours == 29) && (mois == 2))) {
                errors.add(aForm[name], msg.replace("{0}", format));
                return
            }
        } else {
            errors.add(aForm[name], msg.replace("{0}", format));
            return
        }
    }
    if (annees != oDate.getFullYear()) {
        errors.add(aForm[name], msg.replace("{0}", format));
        return
    }
}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_InternetAddressClause(a, f, b, e) {
    var d = getFieldValue(a, b);
    var c = new RegExp("^[^@;]+@[^@;.]+\\.[^@;]+$", "g");
    if (!d.match(c)) {
        f.add(a[b], e.replace("{0}", c))
    }
}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_FileExtensionClause(a, g, b, e, f, h) {
    var c = getFieldValue(a, b);
    var j = h;
    if (f != "null") {
        j = getFieldValue(a, f)
    }
    var d = new RegExp("[.]{1}" + j + "$", "g");
    if (!c.match(d)) {
        g.add(a[b], e.replace("{0}", j))
    }
}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_FileMaxSizeClause(b, f, c, e, a, d) {}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_FileMinSizeClause(b, f, c, e, a, d) {}

function onsubmit_fr_laposte_disf_fwmc_arch_web_form_clause_impl_FileXmlValidClause(a, d, b, c) {}

function getFieldValue(c, e) {
    var d = c.elements[e];
    var f = getFieldTypeByName(c, e);
    if (f == "text" || f == "password" || f == "hidden") {
        return d.value
    } else {
        if (f == "select-one") {
            return d.options[d.selectedIndex].value
        } else {
            if (f == "select-multiple") {
                if (d.selectedIndex == -1) {
                    return null
                } else {
                    return d.options[d.selectedIndex].value
                }
            } else {
                if (f == "radio" || f == "checkbox") {
                    var a = "";
                    for (i = 0; i < d.length; i++) {
                        if (d[i].checked) {
                            a = d[i].value
                        }
                    }
                    return a
                } else {
                    if (f == "fieldset") {
                        var a = "";
                        var g = document.getElementById(e + "_DateInputTagDay").value;
                        var b = document.getElementById(e + "_DateInputTagMonth").value;
                        var h = document.getElementById(e + "_DateInputTagYear").value;
                        if (g != "" && b != "" && h != "") {
                            a = a.concat(g, "/", b, "/", h)
                        }
                        return a
                    } else {
                        a = d.value;
                        if (a == undefined) {
                            a = ""
                        }
                        return a
                    }
                }
            }
        }
    }
}

function getFieldTypeByName(a, b) {
    return getFieldType(a.elements[b])
}

function getFieldType(b) {
    var a = b.type;
    if (b.tagName == "FIELDSET") {
        a = "fieldset"
    } else {
        if (a == undefined) {
            a = b[0].type
        }
    }
    return a
}

function auto_focus_date(j, a) {
    var b = j.name;
    var c = b.split("_")[0];
    var d = j.value.length;
    var h = b.match(/DateInputTagDay/) != null;
    var f = b.match(/DateInputTagMonth/) != null;
    var e = false;
    var k;
    if (window.event) {
        k = a.keyCode
    } else {
        if (a.which) {
            k = a.which
        }
    }
    if (96 <= k && k <= 105) {
        e = true
    }
    var g = d == 2 && (h || f) && e;
    if (g) {
        if (h) {
            document.getElementById(c + "_DateInputTagMonth").select()
        } else {
            document.getElementById(c + "_DateInputTagYear").select()
        }
    }
}

function closeHandler(a) {
    a.hide();
    _dynarch_popupCalendar = null
}

function dateSelected(b, a) {
    b.sel.value = a;
    b.sel.focus()
}

function showCalendar(f, e, a, d) {
    var b = document.getElementById(f);
    if (_dynarch_popupCalendar != null) {
        _dynarch_popupCalendar.hide()
    } else {
        var c = new Calendar(1, null, dateSelected, closeHandler);
        c.weekNumbers = false;
        c.setRange(a, d);
        _dynarch_popupCalendar = c;
        c.create()
    }
    if (e == "jj/mm/aaaa") {
        _dynarch_popupCalendar.setDateFormat("%d/%m/%Y")
    } else {
        _dynarch_popupCalendar.setDateFormat("%Y-%m-%d")
    }
    _dynarch_popupCalendar.parseDate(b.value);
    _dynarch_popupCalendar.sel = b;
    _dynarch_popupCalendar.showAtElement(document.getElementById(f + "_button"));
    return false
}

function dateSelectedThreeFields(d) {
    var a = document.getElementById(d.sel.id + "_DateInputTagDay");
    a.value = d.date.print("%d");
    var c = document.getElementById(d.sel.id + "_DateInputTagMonth");
    c.value = d.date.print("%m");
    var b = document.getElementById(d.sel.id + "_DateInputTagYear");
    b.value = d.date.print("%Y");
    b.focus()
}

function showCalendarThreeFields(h, a, g) {
    var e = document.getElementById(h);
    var b = document.getElementById(h + "_DateInputTagDay");
    var d = document.getElementById(h + "_DateInputTagMonth");
    var c = document.getElementById(h + "_DateInputTagYear");
    if (_dynarch_popupCalendar != null) {
        _dynarch_popupCalendar.hide()
    } else {
        var f = new Calendar(1, null, dateSelectedThreeFields, closeHandler);
        f.weekNumbers = false;
        f.setRange(a, g);
        _dynarch_popupCalendar = f;
        f.create()
    }
    _dynarch_popupCalendar.setDateFormat("%Y-%m-%d");
    _dynarch_popupCalendar.parseDate(c.value + "-" + d.value + "-" + b.value);
    _dynarch_popupCalendar.sel = e;
    _dynarch_popupCalendar.showAtElement(document.getElementById(h + "_button"));
    return false
}

function ea_log(a) {
    if (typeof(EA_LOGGER) != "undefined" && EA_LOGGER) {
        if (typeof console != "undefined") {
            console.warn(a)
        }
    }
};