var nolocalcheck=false;
var msgset_en=new Array();
msgset_en.date="% n'est pas au format date";
msgset_en.email="% n'est pas au format adresse e-mail";
msgset_en.currency="% n'est pas au format mon\351taire";
msgset_en.empty="% doit \352tre renseign\351 .";
msgset_en.correct="% n'est pas correct.";
msgset_en["boolean"]="% n'est pas un bool\351en.";
msgset_en["byte"]="% n'est pas un byte.";
msgset_en["char"]="% n'est pas un caract\350re.";
msgset_en["short"]="% n'est pas entier court.";
msgset_en["int"]="% n'est pas entier.";
msgset_en["long"]="% n'est pas entier long.";
msgset_en["float"]="% n'est pas un nombre flottant.";
msgset_en["double"]="% n'est pas un nombre flottant double.";
var msgset_fr=new Array();
msgset_fr.date="% n'est pas au format date";
msgset_fr.email="% n'est pas au format adresse e-mail";
msgset_fr.currency="% n'est pas au format mon\351taire";
msgset_fr.empty="% doit \352tre renseign\351.";
msgset_fr.correct="% n'est pas correct.";
msgset_fr["boolean"]="% n'est pas un bool\351en.";
msgset_fr["byte"]="% n'est pas un byte.";
msgset_fr["char"]="% n'est pas un caract\350re.";
msgset_fr["short"]="% n'est pas entier court.";
msgset_fr["int"]="% n'est pas entier.";
msgset_fr["long"]="% n'est pas entier long.";
msgset_fr["float"]="% n'est pas un nombre flottant.";
msgset_fr["double"]="% n'est pas un nombre flottant double.";
IS_FIRST_CLICK=true;
function submitForm(a,b){if(IS_FIRST_CLICK){IS_FIRST_CLICK=false;
if(b.length==0){return true
}else{showErrors(b);
IS_FIRST_CLICK=true;
return false
}}else{return false
}}function showErrors(a){if(a.length==0){return
}selectFirstError(a);
alert(makeMessage(a))
};