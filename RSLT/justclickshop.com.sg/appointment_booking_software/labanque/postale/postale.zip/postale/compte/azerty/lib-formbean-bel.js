var NumberUtils = {
    /**
	 * Controle 'chaine' soit numerique
	 */
	isNum : function(chaine) {
		var regexpNumeric = /^[-]?[0-9]+$/;
		return regexpNumeric.test(chaine);
	}
}

/**
 * @class SimpleDateFormat
 */
var SimpleDateFormat = function(strMask, utc) {

    /**
     * Accepts a date, a mask, or a date and a mask.
     * Returns a formatted version of the given date.
     * The date defaults to the current date/time.
     * The mask defaults to dateFormat.masks.default.
     */
    var dateFormat = function () {
        var	token = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZ]|"[^"]*"|'[^']*'/g,
        timezone = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g,
        timezoneClip = /[^-+\dA-Z]/g,
        pad = function (val, len) {
            val = String(val);
            len = len || 2;
            while (val.length < len) val = "0" + val;
            return val;
        };

        // Regexes and supporting functions are cached through closure
        return function (date, mask, utc) {
            var dF = dateFormat;

            // You can't provide utc if you skip other args (use the "UTC:" mask prefix)
            if (arguments.length == 1 && (typeof date == "string" || date instanceof String) && !/\d/.test(date)) {
                mask = date;
                date = undefined;
            }

            // Passing date through Date applies Date.parse, if necessary
            date = date ? new Date(date) : new Date();
            if (isNaN(date)) throw new SyntaxError("invalid date");

            mask = String(dF.masks[mask] || mask || dF.masks["default"]);

            // Allow setting the utc argument via the mask
            if (mask.slice(0, 4) == "UTC:") {
                mask = mask.slice(4);
                utc = true;
            }

            var	_ = utc ? "getUTC" : "get",
            d = date[_ + "Date"](),
            D = date[_ + "Day"](),
            M = date[_ + "Month"](),
            y = date[_ + "FullYear"](),
            H = date[_ + "Hours"](),
            m = date[_ + "Minutes"](),
            s = date[_ + "Seconds"](),
            L = date[_ + "Milliseconds"](),
            o = utc ? 0 : date.getTimezoneOffset(),
            flags = {
                d:    d,
                dd:   pad(d),
                ddd:  dF.i18n.dayNames[D],
                dddd: dF.i18n.dayNames[D + 7],
                M:    M + 1,
                MM:   pad(M + 1),
                MMM:  dF.i18n.monthNames[M],
                MMMM: dF.i18n.monthNames[M + 12],
                yy:   String(y).slice(2),
                yyyy: y,
                h:    H % 12 || 12,
                hh:   pad(H % 12 || 12),
                H:    H,
                HH:   pad(H),
                m:    m,
                mm:   pad(m),
                s:    s,
                ss:   pad(s),
                l:    pad(L, 3),
                L:    pad(L > 99 ? Math.round(L / 10) : L),
                t:    H < 12 ? "a"  : "p",
                tt:   H < 12 ? "am" : "pm",
                T:    H < 12 ? "A"  : "P",
                TT:   H < 12 ? "AM" : "PM",
                Z:    utc ? "UTC" : (String(date).match(timezone) || [""]).pop().replace(timezoneClip, ""),
                o:    (o > 0 ? "-" : "+") + pad(Math.floor(Math.abs(o) / 60) * 100 + Math.abs(o) % 60, 4),
                S:    ["th", "st", "nd", "rd"][d % 10 > 3 ? 0 : (d % 100 - d % 10 != 10) * d % 10]
            };

            return mask.replace(token, function ($0) {
                return $0 in flags ? flags[$0] : $0.slice(1, $0.length - 1);
            });
        };
    }();

    // Some common format strings
    dateFormat.masks = {
        "default":      "ddd MMM dd yyyy HH:mm:ss",
        shortDate:      "M/d/yy",
        mediumDate:     "MMM d, yyyy",
        longDate:       "MMMM d, yyyy",
        fullDate:       "dddd, MMMM d, yyyy",
        shortTime:      "h:mm TT",
        mediumTime:     "h:mm:ss TT",
        longTime:       "h:mm:ss TT Z",
        isoDate:        "yyyy-MM-dd",
        isoTime:        "HH:mm:ss",
        isoDateTime:    "yyyy-MM-dd'T'HH:mm:ss",
        isoUtcDateTime: "UTC:yyyy-MM-dd'T'HH:mm:ss'Z'"
    };

    // Internationalization strings
    dateFormat.i18n = {
        dayNames: [
        "Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam",
        "Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"
        ],
        monthNames: [
        "Janv.", "Févr.", "Mars", "Avr.", "Mai", "Juin", "Juil.", "Août", "Sept.", "Oct.", "Nov.", "Déc.",
        "Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"
        ]
    };
    
    this.format = function(date) {
        return dateFormat(date, strMask, utc);
    };
}


/**
 * StringUtils
 */
var StringUtils = {
    /**
	 * Retourne true si le champ ne contient aucune donnée.
	 *
	 * @param fieldValue Valeur du champ à tester
	 */
    isEmptyOrBlank : function(fieldValue) {
        return (fieldValue == undefined || fieldValue == null || fieldValue == "" || fieldValue == " " );
    },

    /**
	 * Retourne true si le champ contient une donnée.
	 *
	 * @param fieldValue Valeur du champ à tester
	 */
    isNotEmptyOrBlank : function(fieldValue) {
        return !(this.isEmptyOrBlank(fieldValue));
    },

    /**
     * @param chaine
     * @return boolean
     */
    isNombre : function(chaine) {
        var nbVirgule = 0;
        var a = ' ';
        for (var i=0; i < chaine.length; i++) {
            a = chaine.substring(i, i+1);
            if(a == '.') {
                nbVirgule++;
            }
            if ( (a < '0' && a != '.' && a != '-')
                || (a > '9' && a != '.' && a != '-')
                || (a == '-' && i != 0) || nbVirgule > 1) {
                return false;
            }
        }
        return true;
    }
    
}


/**
 * DateUtils
 */
var DateUtils = {

    nbJourMois : [31,29,31,30,31,30,31,31,30,31,30,31],
    /**
     *
     * @param
     * @return
     */
    isValid : function(strDate) {
        var isValid = new RegExp("^[0-9]{2}/[0-9]{2}/[0-9]{4}$","g");
        return isValid.test(strDate);
    },
    
    /**
     *
     * @param
     * @return
     */
    toDate : function(strDate) {
        var chaineTemp = strDate;

        var i = chaineTemp.indexOf("/");
        if (i != 2) {
            return null;
        }
        var chaineOut = chaineTemp.substring(0, i);
        chaineTemp = chaineTemp.substring(i+1, chaineTemp.length);
        var jour = chaineOut;
        if (!StringUtils.isNombre(jour)) {
            return null;
        }

        i = chaineTemp.indexOf("/");
        if (i != 2) {
            return null;
        }

        chaineOut = chaineTemp.substring(0, i) + chaineOut;

        var mois = chaineTemp.substring(0, i);
        if (!StringUtils.isNombre(mois)) {
            return null;
        }
        
        chaineTemp = chaineTemp.substring(i+1, chaineTemp.length);
        if (chaineTemp.length != 4) {
            return null;
        }

        chaineOut = chaineTemp + chaineOut;

        var ans = chaineTemp;
        if (!StringUtils.isNombre(ans)) {
            return null;
        }

        if (mois < 1 || mois > 12) {
            return null;
        }

        var ret = new Date(ans, mois-1, jour);
        ans = ans/4;
        var anChar = ans.toString();

        if (jour == 29 && mois == 02 && anChar.indexOf(".") != -1) {
            return null;
        } else if (jour < 1 || jour > this.nbJourMois[mois-1] ) {
            return null;
        }
        
        return ret;
    },

    toString : function(date) {
        var formater = SimpleDateFormat("dd/MM/yyyy");
        return formater.format(date);
    },

    /**
     * Renvois la date du jour.
     * @return Date Object
     */
    today : function() {
        return new Date();
    },

    /**
     * Teste si les dates sont dans l'ordre chronologique
     * @return boolean
     */
    isSorted : function(date1, date2) {
        return (date1.getTime() < date2.getTime());
    },

 
    /**
     * @param
     * @return
     */
    addDays : function(date, days) {
        var valDays = days*24*60*60*1000;
        var dateAdded = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 00, 00, 00);
        dateAdded.setTime(dateAdded.getTime() + valDays);
        return dateAdded;
    },

    /**
     * @param
     * @return
     */
    addMonthes : function(date, monthes) {
        return this.addDays(date, monthes*30)
    },

    /**
     * @param
     * @return
     */
    addYears : function(date, years) {
        return this.addDays(date, years*30)
    }

}


/**
 *
 * @class FormError
 */
var FormError = function(field, message) {
    this.field = field;
    this.message = message;
}

/**
 * @class Formulaire
 */
var Formulaire = function(form) {
    this.innerForm = form;
    /**
     * @param strName
     * @return the field value
     */
   this.getInputValue = function(strName) {
   		var ret = null;
        if(this.innerForm) {
			var elts = this.innerForm.elements[strName];   		
    		var typeFwmc = getFieldTypeByName(this.innerForm, strName);
        	ret = getFieldValue(this.innerForm, strName);
        	// cas special de la checkbox
			if(typeFwmc == "checkbox") {
	    		if($(elts).length == 1) {
					if(elts.value == "true") {
						ret = elts.checked;
					} else if(elts.checked) {
		        		var valeur = [];
						valeur[0] = elts.value;
						ret = valeur;
					}
	    		} else {
		    		var size = elts.length;
	        		var hasHidden = false;
					for( i = 0; i < size ; i++ ) {
						var type = elts[i].type;
			        	if(type == "hidden") {
				        	hasHidden = true;
				        	break;
			        	}
			        }
	
	        		var valeur = [];
		    		var j = 0;
					for( i = 0; i < size ; i++ ) {
						var type = elts[i].type;
			        	if(type == "checkbox") {
							if ((hasHidden && size > 2) || (!hasHidden && size > 1)) {
								if (elts[i].checked) {
									valeur[j] = elts[i].value;	
									j++;
								}
							} else {
								if(elts[i].value == "true") {
									ret = elts[i].checked;
									break;
								} else {
				    				if(elts.checked) {
										valeur[0] = elts[i].value;
									}
								}
							}
			        	} 
					}
					ret = valeur;
				}
			}
        } 
        return ret;
    }
}

/**
 * @class BELFormBean
 */
var BELFormBean = function() {

    /**
     * methode d'initialisation
     * @param formulaire le formulaire a valider
     * @param errors le tableux des erreurs à remonter
     */
    this.init = function(formulaire, errors) {
        // Encapsulation pour compatibilite avec fwmc
        this.form = new Formulaire(formulaire);
        this.fie = errors;
    }

    /**
     *
     * @param id
     * @param idMessage
     * @param params
     */
    this.createFormError = function(id, idMessage, params) {
        var message = eval(idMessage);
        if(params) {
            for (var i = 0; i < params.length; i++) {
                message = message.toString().replace("{"+i+"}", params[i]);
            }
        }
        var fe = new FormError(this.form.innerForm[id], message);
        return fe;
    }

    /**
     * 
     * @param fie
     * @param err
     */
    this.registerFormError = function(fie, err) {
        if(FormError.prototype.isPrototypeOf(err)) {
            fie.add(err.field, err.message);
        }
    }

    /**
     * @return array of error messages
     */
    this.validate = function() {
        return this.fie;
    }

}
