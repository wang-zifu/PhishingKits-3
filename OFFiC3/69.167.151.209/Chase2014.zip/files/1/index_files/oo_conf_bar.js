/* OnlineOpinion v5.4.1 */
/* Released: 7/25/2011 */
/* Components: Full */
/* The following code is Copyright 1998-2011 Opinionlab, Inc.  All rights reserved. Unauthorized use is prohibited. This product and other products of OpinionLab, Inc. are protected by U.S. Patent No. 6606581, 6421724, 6785717 B1 and other patents pending. http://www.opinionlab.com */

/*Script for URL rewrite*/
if(window.location.href.match(/\/$/)) {
 if(window.location.href.match(/\.com\/$/)) {
   var fullReplace = window.location.href + '?' + isLoggedIn + '/' + userSeg;
 }
 else {
   var fullReplace = window.location.href.substring(0, window.location.href.length-1) + '?' + isLoggedIn + '/' + userSeg;
 }
}
else {
 var fullReplace = window.location.href + '?'+ isLoggedIn + '/' + userSeg;
}

var ooPageId = window.pageId || '';

/* [+] Bar Icon configuration */
  var oo_bar = new OOo.Ocode({
	  bar: {
	    caption: 'Site Feedback'  
	  }
	, cookie: {
		  name: "oo_bar"
		, type: "domain"
		, expiration: 86400
	  }
	, disappearOnClick: true	  
    , referrerRewrite : {
    		replacePattern: fullReplace
    		}
	, onPageCard: {
//		  closeWithOverlay: {}
	  }
  , customVariables : {
  		domain: window.location.href
		, ProfileID: typeof (pfId) != "undefined" ? pfId : ''
		, BusinessSegment: typeof (userSeg) != "undefined" ? userSeg : ''
		, Page: typeof (ooPageId) != "undefined" ? ooPageId : ''
		, AppID: (typeof (AppID) != "undefined" && AppID != null && AppID.length > 0) ? AppID : ''
		, autherror: typeof (autherror) != "undefined" ? autherror : ''
  		}
  , commentCardUrl: 'https://chase-feedback.opinionlab.com/ccc01/comment_card_json_4_0_b.asp'
  });