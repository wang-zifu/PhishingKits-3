
function identifyUser() {
    var obj = document.frmReidentifyFilterView;
    if (obj.rdoAffiliate && obj.rdoTAUser) {
        if (!obj.rdoPersonal.checked && !obj.rdoBusiness.checked && !obj.rdoAffiliate.checked && !obj.rdoTAUser.checked) {
            alert("Please Select any option");
            return false;
        }
    }
    else {
        if (!obj.rdoPersonal.checked && !obj.rdoBusiness.checked) {
            alert("Please Select any option");
            return false;
        }
    }
}
var browserName = navigator.appName;
var browserRealnum = navigator.appVersion;
var browserNum = parseInt(navigator.appVersion);
var browserParsed = browserRealnum.substring(0, 4);
var cipher = navigator.cipher;
var keySize = navigator.keySize;
var userAgent = navigator.userAgent;
var msBrowserVersion = browserParsed

var tin1Length = 2
var tin2Length = 7
var ssn1Length = 3
var ssn2Length = 2
var ssn3Length = 4
var mmLength = 2
var ddLength = 2
var yydLength = 4
if (browserName == "Microsoft Internet Explorer") {
    p = browserRealnum.indexOf("MSIE") + 5;
    f = browserRealnum.substring(p, p + 2);
    if ((f.indexOf(" ") != -1) || (f.indexOf(";") != -1)) {
        f = browserRealnum.substring(p, p + 3);
    }
    if (f >= 5.0) {
        tin1Length = 2
        tin2Length = 7
        ssn1Length = 3
        ssn2Length = 2
        ssn3Length = 4
    }
}
else if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
    var userInfo = navigator.userAgent.split("/");

    if (userInfo[3].substring(0, 3) >= 6.0) {
        ssn1Length = 3
        ssn2Length = 2
        ssn3Length = 4
    }
}

function handleTabs(name) {
    if (name == "txtSSN1") {
        if ((!isInteger(document.getElementById("txtSSN1").value))) {
            alert(invalidSSN);
            document.getElementById("txtSSN1").focus();
        }
        else if ((isInteger(document.getElementById("txtSSN1").value)) && (document.getElementById("txtSSN1").value.length == ssn1Length)) {
            document.getElementById("txtSSN2").focus();
        }
    }
    if (name == "txtSSN2") {
        if ((!isInteger(document.getElementById("txtSSN2").value))) {
            alert(invalidSSN);
            document.getElementById("txtSSN2").focus();
        }
        else if ((isInteger(document.getElementById("txtSSN2").value)) && (document.getElementById("txtSSN2").value.length == ssn2Length)) {
            document.getElementById("txtSSN3").focus();
        }
    }
    if (name == "txtSSN3") {
        if ((!isInteger(document.getElementById("txtSSN3").value))) {
            alert(invalidSSN);
            document.getElementById("txtSSN3").focus();
        }
        else if ((isInteger(document.getElementById("txtSSN3").value)) && (document.getElementById("txtSSN3").value.length == ssn3Length)) {
            document.getElementById("txtSSN3").focus();
        }
    }
    if (name == "txtMM") {
        if ((isInteger(document.getElementById("txtMM").value)) && (document.getElementById("txtMM").value.length == mmLength)) {
            document.getElementById("txtDD").focus()
        }
    }
    if (name == "txtDD") {
        if ((isInteger(document.getElementById("txtDD").value)) && (document.getElementById("txtDD").value.length == ddLength)) {
            document.getElementById("txtYYD").focus()
        }
    }
    if (name == "txtYYD") {
        if ((isInteger(document.getElementById("txtYYD").value)) && (document.getElementById("txtYYD").value.length == yydLength)) {
            document.getElementById("txtYYD").focus()
        }
    }
    if (name == "txtTIN1") {
        if ((!isInteger(document.getElementById("txtTIN1").value))) {
            alert(invalidTIN);
            document.getElementById("txtTIN1").focus();
        }
        else if ((isInteger(document.getElementById("txtTIN1").value)) && (document.getElementById("txtTIN1").value.length == tin1Length)) {
            document.getElementById("txtTIN2").focus();
        }
    }
    if (name == "txtTIN2") {
        if ((!isInteger(document.getElementById("txtTIN2").value))) {
            alert(invalidTIN);
            document.getElementById("txtTIN2").focus();
        }
        else if ((isInteger(document.getElementById("txtTIN2").value)) && (document.getElementById("txtTIN2").value.length == tin2Length)) {
            document.getElementById("txtTIN2").focus();
        }
    }
}

function check() {
    if (document.getElementById("rdoSSN").checked) {
        var dob_1 = "";
        var dob_2 = "";
        var dob_3 = "";
        if (document.getElementById("hidSSNFlag").value == "ssn") {
            if ((isEmpty(document.getElementById("txtSSN1").value)) && (isEmpty(document.getElementById("txtSSN2").value)) &&
      (isEmpty(document.getElementById("txtSSN3").value))) {
                document.getElementById("txtSSN1").focus();
                document.getElementById("txtSSN1").select();
                alert(emptySSN);
                return false;
            }
            else if (checkSSN(document.getElementById("txtSSN1").value, document.getElementById("txtSSN2").value, document.getElementById("txtSSN3").value) == false) {
                document.getElementById("txtSSN1").focus();
                alert(invalidSSN);
                return false;
            }
        }
        else {
            var sysDate = getcurrentdate();
            var dtStr = "" + document.getElementById("txtMM").value + "/" + document.getElementById("txtDD").value + "/" + document.getElementById("txtYYD").value;
            if ((isEmpty(document.getElementById("txtMM").value)) && (isEmpty(document.getElementById("txtDD").value)) && (isEmpty(document.getElementById("txtYYD").value))) {
                document.getElementById("txtMM").focus();
                document.getElementById("txtMM").select();
                alert(emptyDOB);
                return false;
            }
            else if (isBirthDate(dtStr) == false) {
                alert(invalidDateOfBirth)
                document.getElementById("txtMM").focus()
                document.getElementById("txtMM").select();
                return false;
            }
            else if (compareDates(dtStr, sysDate) == false) {
                alert("Date Of Birth  cannot be later  than today's Date")
                document.getElementById("txtMM").focus();
                document.getElementById("txtMM").select();
                return false;
            }
        }
    }
    else if (document.getElementById("rdoTax").checked) {
        if (!checkTin())
            return false;
    }

    if (
      !document.getElementById("rdoDBorCCNumber").checked &&
      !document.getElementById("rdoOtherAcctNumber").checked &&
      !document.getElementById("rdoCmlLoanNumber").checked
     ) {
        alert("Please select an account number type to help us identify your accounts.");
        return false;
    }
    else if (
      document.getElementById("rdoDBorCCNumber").checked &&
      !filledBox(document.getElementById("txtAccountNumberDBorCC"))
     ) {
        alert(emptyAcctNum);
        document.getElementById("txtAccountNumberDBorCC").focus();
        return false;
    }
    else if (
      document.getElementById("rdoDBorCCNumber").checked &&
      !isAlphanumeric(document.getElementById("txtAccountNumberDBorCC").value)) {
        alert(invalidAcctNum);
        document.getElementById("txtAccountNumberDBorCC").focus();
        return false;
    }
    else if (
      document.getElementById("rdoOtherAcctNumber").checked &&
      !filledBox(document.getElementById("txtAccountNumberOther"))
     ) {
        alert(emptyAcctNum);
        document.getElementById("txtAccountNumberOther").focus();
        return false;
    }
    else if (
      document.getElementById("rdoOtherAcctNumber").checked &&
      !isAlphanumeric(document.getElementById("txtAccountNumberOther").value)) {
        alert(invalidAcctNum);
        return false;
    }
    else if (
      document.getElementById("rdoCmlLoanNumber").checked &&
      !filledBox(document.getElementById("txtCmlLoanAcctNumber"))
     ) {
        alert(emptyAcctNum);
        document.getElementById("txtCmlLoanAcctNumber").focus();
        return false;
    }
    else if (
      document.getElementById("rdoCmlLoanNumber").checked &&
      !isAlphanumeric(document.getElementById("txtCmlLoanAcctNumber").value)) {
        alert(invalidAcctNum);
        return false;
    }
    return true;
}

function checkSSN(ssn1, ssn2, ssn3) {
    var ssnValue = ssn1 + ssn2 + ssn3
    if (checkSSN.arguments.length == 1) {
        return false;
    }
    if (isEmpty(ssnValue)) {
        return false;
    }
    else {
        if ((ssn1 == validSSN1) || (areValidSSN(ssn1)) || (areAllZeros(ssn1)) || (areAllZeros(ssn2)) || (areAllZeros(ssn3)) || (areAllOnes(ssnValue)) || (!isSSN(ssnValue))) {
            return false;
        }
        else {
            return true;
        }
    }
}

function DOBHandleFocus() {
    if (document.getElementById("txtMM").value == "MM") {
        document.getElementById("txtMM").value = "";
        if (document.getElementById("txtDD").value == "DD") {
            document.getElementById("txtDD").value = "";
        }
        if (document.getElementById("txtYYD").value == "YYYY") {
            document.getElementById("txtYYD").value = "";
        }
    }
    else {
        document.getElementById("txtMM").select();
    }
    document.getElementById("txtMM").focus();
}

function handleBusinessTabs(name) {
    if (name == "txtSSN1") {
        if ((!isInteger(document.getElementById("txtSSN1").value))) {
            alert(invalidSSN);
            document.getElementById("txtSSN1").focus();
        }
        else if ((isInteger(document.getElementById("txtSSN1").value)) && (document.getElementById("txtSSN1").value.length == ssn1Length)) {
            document.getElementById("txtSSN2").focus();
        }
    }
    if (name == "txtSSN2") {
        if ((!isInteger(document.getElementById("txtSSN2").value))) {
            alert(invalidSSN);
            document.getElementById("txtSSN2").focus();
        }
        else if ((isInteger(document.getElementById("txtSSN2").value)) && (document.getElementById("txtSSN2").value.length == ssn2Length)) {
            document.getElementById("txtSSN3").focus();
        }
    }
    if (name == "txtSSN3") {
        if ((!isInteger(document.getElementById("txtSSN3").value))) {
            alert(invalidSSN);
            document.getElementById("txtSSN3").focus();
        }
        else if ((isInteger(document.getElementById("txtSSN3").value)) && (document.getElementById("txtSSN3").value.length == ssn3Length)) {
            document.getElementById("txtSSN3").focus();
        }
    }
    if (name == "txtMM") {
        if ((isInteger(document.getElementById("txtMM").value)) && (document.getElementById("txtMM").value.length == mmLength)) {
            document.getElementById("txtDD").focus()
        }
    }
    if (name == "txtDD") {
        if ((isInteger(document.getElementById("txtDD").value)) && (document.getElementById("txtDD").value.length == ddLength)) {
            document.getElementById("txtYYD").focus()
        }
    }
    if (name == "txtYYD") {
        if ((isInteger(document.getElementById("txtYYD").value)) && (document.getElementById("txtYYD").value.length == yydLength)) {
            document.getElementById("txtYYD").focus()
        }
    }
}

function checkTin() {
    if (isEmpty(document.getElementById("txtTIN1").value) && isEmpty(document.getElementById("txtTIN2").value)) {
        document.getElementById("txtTIN1").focus();
        document.getElementById("txtTIN1").select();
        alert(emptyTIN);
        return false;
    }

    if (checkTIN(document.getElementById("txtTIN1").value, document.getElementById("txtTIN2").value) == false) {
        document.getElementById("txtTIN1").focus();
        alert(invalidTIN);
        return false;
    }

    return true;
}

function tinHandleFocus() {
    if (document.getElementById("txtTIN1").value == "##") {
        document.getElementById("txtTIN1").value = "";
        if (document.getElementById("txtTIN2").value == "#######") {
            document.getElementById("txtTIN2").value = "";
        }
    }
    else {
        document.getElementById("txtTIN1").select();
    }
    document.getElementById("txtTIN1").focus();
}

function checkSSN(ssn1, ssn2, ssn3) {
    var ssnValue = ssn1 + ssn2 + ssn3
    if (checkSSN.arguments.length == 1) {
        return false;
    }
    if (isEmpty(ssnValue)) {
        return false;
    }
    else {
        if ((ssn1 == validSSN1) || (areValidSSN(ssn1)) || (areAllZeros(ssn1)) || (areAllZeros(ssn2)) || (areAllZeros(ssn3)) || (areAllOnes(ssnValue)) || (!isSSN(ssnValue))) {
            return false;
        }
        else {
            return true;
        }
    }
}

function checkTIN(tin1, tin2) {
    var tinValue = tin1 + tin2;
    if (checkTIN.arguments.length == 1) {
        return false;
    }
    if (isEmpty(tinValue)) {
        return false;
    }
    else {
        if ((tinValue == validTIN1) || (areAllZeros(tin1)) || (areAllZeros(tin2)) || (areAllOnes(tinValue)) || (!isSSN(tinValue))) {
            return false;
        }
        else {
            return true;
        }
    }
}

function NOSSN() {
    document.getElementById("trSSN").style.display = "none";
    document.getElementById("trDOB").style.display = "";
    document.getElementById("hidSSNFlag").value = "dob"; //If not an ssn.
    document.getElementById("txtSSN1").value = "";
    document.getElementById("txtSSN2").value = "";
    document.getElementById("txtSSN3").value = "";
}
function haveSSN() {
    document.getElementById("trDOB").style.display = "none";
    document.getElementById("trSSN").style.display = "";
    document.getElementById("hidSSNFlag").value = "ssn"; //If not an ssn.
    document.getElementById("txtMM").value = "MM";
    document.getElementById("txtDD").value = "DD";
    document.getElementById("txtYYD").value = "YYYY";
}

function getSelectedUserID() {
    if (document.getElementById("hidUserId").value == "UserIdDropDown") {
        var login = document.getElementById("ddlUserId").value;
    }
    else {
        var login = document.getElementById("hidlblUserId").value;
    }
    document.getElementById("hidUsrLogin").value = login;

    if (!validateNewUserId()) {
        return false;
    }
}

function validateNewUserId() {
    if (document.getElementById("hidNuidchoFlag").value == "true") {
        if (!isEmpty(document.getElementById("txtNewUserId").value)) {
            if (document.getElementById("hidUserId").value == "UserIdDropDown") {
                var login = document.getElementById("ddlUserId").value;
            }
            else {
                var login = document.getElementById("hidlblUserId").value
            }
            document.getElementById("hidNewUserId").value = document.getElementById("txtNewUserId").value;
            document.getElementById("hidOldUserId").value = login;
            document.getElementById("hidNewUserIdFlag").value = "true";
            if (!validateUserId()) {
                return false;
            }
        }
        else {
            document.getElementById("hidNewUserIdFlag").value = "false";
        }
    }
    return true;
}

function validateUserId() {
    var emptyId = "Please enter a new User ID.";
    var invalidId = "The new User ID you entered is not valid or is already being used by another customer.Please enter another User ID.";
    var sameasPrevious = "Your new User ID cannot be the same as your current User ID.  Please enter a new User ID.";
    var oldUsrId = document.getElementById("hidOldUserId").value;
    var newUsrId = document.getElementById("hidNewUserId").value;
    if (isUserIdEmpty(newUsrId)) {
        alert(emptyId);
        document.getElementById("txtNewUserId").focus();
        return false;
    }
    else {
        if (!isUserIdValid(newUsrId)) {
            alert(invalidId);
            document.getElementById("txtNewUserId").select();
            document.getElementById("txtNewUserId").focus();
            return false;
        }
        if (!checkUserIdInput(newUsrId)) {
            alert(invalidId);
            document.getElementById("txtNewUserId").select();
            document.getElementById("txtNewUserId").focus();
            return false;
        }
        if (!isUserIdAlphanumeric(newUsrId)) {
            alert(invalidId);
            document.getElementById("txtNewUserId").select();
            document.getElementById("txtNewUserId").focus();
            return false;
        }
        if (!isAnyDigitCheck(newUsrId)) {
            alert(invalidId);
            document.getElementById('txtNewUserId').focus();
            document.getElementById("txtNewUserId").select();
            return false;
        }
        if (!isAnyCharacterCheck(newUsrId)) {
            alert(invalidId);
            document.getElementById('txtNewUserId').focus();
            document.getElementById("txtNewUserId").select();
            return false;
        }
        if (newUsrId == oldUsrId) {
            alert(sameasPrevious);
            return false;
        }
    }
    return true;
}

function isEmpty(s) {
    return ((s == null) || (s.length == 0))
}

function isUserIdEmpty(s) {
    return ((s == null) || (s.length == 0))
}

function isUserIdValid(s) {
    if ((s.length < 8) || (s.length > 32))
        return false;
    return (isUserIdAlphanumeric(s))
}

function isUserIdAlphanumeric(s) {
    var i;
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if (!(isLetter(c) || isDigit(c)))
            return false;
    }
    return true;
}

function checkUserIdInput(formValue) {
    var alphaNumericStr = "abcdefghijklmnopqrstuvwxyz0123456789"
    retVal = true;
    for (i = 0; i < formValue.length; i++) {
        if (!(alphaNumericStr.indexOf(formValue.substring(i, i + 1).toLowerCase()) >= 0)) {
            retVal = false;
        }
    }
    return retVal;
}

function isAnyDigitCheck(formValue) {
    var i;
    for (i = 0; i < formValue.length; i++) {
        var c = formValue.charAt(i);
        if (isDigit(c)) {
            return true;
        }
    }
    return false;
}

function isAnyCharacterCheck(formValue) {
    var i;
    for (i = 0; i < formValue.length; i++) {
        var c = formValue.charAt(i);
        if (isLetter(c))
            return true;
    }
    return false;
}

function isBirthDate(dateStr) {
    if (dateStr != null && dateStr != '') {
        var datePat = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
        var matchArray = dateStr.match(datePat);
        if (matchArray == null) {
            return false;
        }
        month = matchArray[1];
        day = matchArray[3];
        year = matchArray[5];
        if (month < 1 || month > 12) {
            return false;
        }
        if (day < 1 || day > 31) {
            return false;
        }
        if ((month == 4 || month == 6 || month == 9 || month == 11) && day == 31) {
            return false;
        }
        if (month == 2) {
            var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
            if (day > 29 || (day == 29 && !isleap)) {
                return false;
            }
        }
    }
    return true;
}

function isValidEmailAddress(emailAddress) {
    var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    return re.test(emailAddress);
}

function isValidSecurityCode(obj) {
    var re = /^\w*(?=\w*\d)(?=\w*[a-zA-Z])\w*$/i;
    return re.test(obj.value);
}

function chkSecurityCode(obj, tr, span) {
    if (!(isValidSecurityCode(obj))) {
        return setResult(false, tr, span, "Security code is a required field. Please enter a valid security code and try again.", obj.id);
    }
    else {
        return setResult(true, tr, span, "", obj.id);
    }
}

function chkIDNumber(obj, tr, span) {
    var IDNumber = obj.value;
    if (IDNumber.length == 0) {
        return setResult(false, tr, span, "ID number is a required field. Please enter a valid ID number and try again.", obj.id);
    }
    else if (IDNumber.length > 0) {
        if (IDNumber.length < 6) {
            return setResult(false, tr, span, "ID number is a required field. Please enter a valid ID number and try again.", obj.id);
        }
        else if (/\W/.test(IDNumber) || (IDNumber.indexOf("_") > -1)) {
            return setResult(false, tr, span, "ID number is a required field. Please enter a valid ID number and try again.", obj.id);
        }
        else {
            return setResult(true, tr, span, "", obj.id);
        }
    }
}

function chkEmail(obj, tr, span) {
    if (!(isValidEmailAddress(obj.value))) {
        return setResult(false, tr, span, "E-mail address is a required field. Please enter a valid e-mail address and try again.", obj.id);
    }
    else {
        return setResult(true, tr, span, "", obj.id);
    }
    return true;
}

function displayToggle(boolResult, errTR, errSpan) {
    if (boolResult) {
        document.getElementById(errTR).style.display = "none";
        document.getElementById(errSpan).style.display = "none";
    }
    else {
        document.getElementById(errTR).style.display = "";
        document.getElementById(errSpan).style.display = "";
    }
}

function setResult(resultTopass, errTR, errSpan, strInnerHTML, errElement) {
    displayToggle(resultTopass, errTR, errSpan);
    if (resultTopass == true)
        document.getElementById(errElement).className = "inputTextBox";
    else
        document.getElementById(errElement).className = "inputTextBoxE";
    document.getElementById(errSpan).innerHTML = strInnerHTML;

    return resultTopass;
}

function change(linkname) {
    var rdossn;
    rdossn = document.getElementById("rdoSSN");
    if (linkname == 'helptextssn') {
        document.getElementById('trSSN').style.display = "";
        document.getElementById('trDOB').style.display = "none";
        document.getElementById('ssnlabel').innerHTML = "Social Security Number";

        if (rdossn != null) {
            document.all.rdoSSN.focus();
            document.getElementById('rdoSSN').setAttribute('title', 'Social Security Number');
        }
        document.getElementById('hidSSNFlag').value = "ssn";
        return false;
    }
    else if (linkname == 'helptextdob') {
        document.getElementById('trDOB').style.display = "";
        document.getElementById('trSSN').style.display = "none";
        document.getElementById('ssnlabel').innerHTML = "Date of Birth";
        if (rdossn != null) {
            document.all.rdoSSN.focus();
            document.getElementById('rdoSSN').setAttribute('title', 'Date of Birth');
        }
        document.getElementById('hidSSNFlag').value = "dob";
        return false;
    }
}


function ShowHideControls(rdObj) {
    if (rdObj.checked) {
        if (rdObj.id == "rdoSSN") {
            if (document.getElementById('hidSSNFlag').value == "ssn" || document.getElementById('hidSSNFlag').value == "") {
                document.getElementById('trSSN').style.display = "";
                document.getElementById('trDOB').style.display = "none";
            }
            else {
                document.getElementById('trSSN').style.display = "none";
                document.getElementById('trDOB').style.display = "";
            }
            document.getElementById('trTin').style.display = "none";
            document.getElementById('trBusiUser').style.display = "none";
            document.getElementById('trQuickPay').style.display = "none";
            document.getElementById('trPendApp').style.display = "none";
            document.getElementById('trAccounts').style.display = "";
            document.getElementById('imgMobileId').style.display = "";
            document.getElementById('dividerId').style.display = "";
            document.getElementById('dividerId1').style.display = "";
            document.getElementById('dividerId2').style.display = "";
        }
        else if (rdObj.id == "rdoTax") {
            document.getElementById('trSSN').style.display = "none";
            document.getElementById('trDOB').style.display = "none";
            document.getElementById('trTin').style.display = "";
            document.getElementById('trBusiUser').style.display = "none";
            document.getElementById('trQuickPay').style.display = "none";
            document.getElementById('trPendApp').style.display = "none";
            document.getElementById('trAccounts').style.display = "";
            document.getElementById('imgMobileId').style.display = "";
            document.getElementById('dividerId').style.display = "";
            document.getElementById('dividerId1').style.display = "";
            document.getElementById('dividerId2').style.display = "";
        }
        else if (rdObj.id == "rdoTAUser") {
            document.getElementById('trSSN').style.display = "none";
            document.getElementById('trDOB').style.display = "none";
            document.getElementById('trTin').style.display = "none";
            document.getElementById('trBusiUser').style.display = "";
            document.getElementById('trQuickPay').style.display = "none";
            document.getElementById('trPendApp').style.display = "none";
            document.getElementById('trAccounts').style.display = "none";
            document.getElementById('imgMobileId').style.display = "none";
            document.getElementById('dividerId').style.display = "none";
            document.getElementById('dividerId1').style.display = "none";
            document.getElementById('dividerId2').style.display = "none";
        }
        else if (rdObj.id == "rdoQPUser") {
            document.getElementById('trSSN').style.display = "none";
            document.getElementById('trDOB').style.display = "none";
            document.getElementById('trTin').style.display = "none";
            document.getElementById('trBusiUser').style.display = "none";
            document.getElementById('trQuickPay').style.display = "";
            document.getElementById('trPendApp').style.display = "none";
            document.getElementById('trAccounts').style.display = "none";
            document.getElementById('imgMobileId').style.display = "none";
            document.getElementById('dividerId').style.display = "none";
            document.getElementById('dividerId1').style.display = "none";
            document.getElementById('dividerId2').style.display = "none";
        }
        else if (rdObj.id == "rdoPAUser") {
            document.getElementById('trSSN').style.display = "none";
            document.getElementById('trDOB').style.display = "none";
            document.getElementById('trTin').style.display = "none";
            document.getElementById('trBusiUser').style.display = "none";
            document.getElementById('trQuickPay').style.display = "none";
            document.getElementById('trPendApp').style.display = "";
            document.getElementById('trAccounts').style.display = "none";
            document.getElementById('imgMobileId').style.display = "none";
            document.getElementById('dividerId').style.display = "none";
            document.getElementById('dividerId1').style.display = "none";
            document.getElementById('dividerId2').style.display = "none";
        }
        else if (rdObj.id == "rdoOtherAcctNumber") {
            document.getElementById('trAccountNumberOther').style.display = "";
            document.getElementById('trAccountNumberDBorCC').style.display = "none";
            document.getElementById('trCmlLoanId').style.display = "none";
        }
        else if (rdObj.id == "rdoDBorCCNumber") {
            document.getElementById('trAccountNumberOther').style.display = "none";
            document.getElementById('trAccountNumberDBorCC').style.display = "";
            document.getElementById('trCmlLoanId').style.display = "none";
        }
        else if (rdObj.id == "rdoCmlLoanNumber") {
            document.getElementById('trAccountNumberOther').style.display = "none";
            document.getElementById('trAccountNumberDBorCC').style.display = "none";
            document.getElementById('trCmlLoanId').style.display = "";

        }
        else {
            document.getElementById('trAccountNumberOther').style.display = "none";
            document.getElementById('trAccountNumberDBorCC').style.display = "none";
            document.getElementById('trCmlLoanId').style.display = "none";
        }
    }
}

function CheckREOData() {
    if (document.getElementById("trREO")) {
        if (
        !(chkEmail(document.getElementById("txtEmailAddREO"), 'errTRmailReo', 'errSPANmailReo'))
        |
        !(chkSecurityCode(document.getElementById("txtIDNumberREO"), 'errTRIDNumberREO', 'errSPANIDNumberREO'))
      )
            return false;
    }
    return true;
}

function CheckData() {
    var email = false;
    var securitycode = false;
    if (
      document.getElementById("rdoSSN").checked
      ||
      (document.getElementById("rdoTax") && document.getElementById("rdoTax").checked)
    ) {
        return check();
    }
    else if (document.getElementById("rdoTAUser") && document.getElementById("rdoTAUser").checked) 
    {
        email = !(chkEmail(document.getElementById("txtEmailAddTA"), 'errTRmailTA', 'errSPANmailTA'));
        securitycode = !(chkSecurityCode(document.getElementById("txtSecurityKeyTA"), 'errTRSecurityKeyTA', 'errSPANSecurityKeyTA'));
        if (email) {
            document.getElementById("errSPANmailTA").focus();
            return false;
        }
        if (securitycode) {
            document.getElementById("errSPANSecurityKeyTA").focus();
            return false;
        }

    }
    else if (document.getElementById("rdoQPUser") && document.getElementById("rdoQPUser").checked) 
    {
        email = !(chkEmail(document.getElementById("txtEmailAddQP"), 'errTRmailQP', 'errSPANmailQP'));
        securitycode = !(chkSecurityCode(document.getElementById("txtSecurityKeyQP"), 'errTRSecurityKeyQP', 'errSPANSecurityKeyQP'));
        if (email) {
            document.getElementById("errSPANmailQP").focus();
            return false;
        }
        if (securitycode) {
            document.getElementById("errSPANSecurityKeyQP").focus();
            return false;
        }
    }
    else if (document.getElementById("rdoPAUser") && document.getElementById("rdoPAUser").checked) 
    {
        email = !(chkEmail(document.getElementById("txtEmailAddPA"), 'errTRmailPA', 'errSPANmailPA'));
        securitycode = !(chkIDNumber(document.getElementById("txtIDNumberPA"), 'errTRIDNumberPA', 'errSPANIDNumberPA'));
        if (email) {
            document.getElementById("errSPANmailPA").focus();
            return false;
        }
        if (securitycode) {
            document.getElementById("errSPANIDNumberPA").focus();
            return false;
        }
    }
    else {
        alert('Please Select any option');
        return false;
    }
    return true;
}

function displaySelectedOptions() {
    if (document.getElementById("rdoSSN") && document.getElementById("rdoSSN").checked) {
        ShowHideControls(document.getElementById("rdoSSN"));
        if (document.getElementById('hidSSNFlag').value == "ssn")
            change("helptextssn");
        else
            change("helptextdob")
    }

    if (document.getElementById("rdoTax") && document.getElementById("rdoTax").checked)
        ShowHideControls(document.getElementById("rdoTax"));

    if (document.getElementById("rdoTAUser") && document.getElementById("rdoTAUser").checked)
        ShowHideControls(document.getElementById("rdoTAUser"));

    if (document.getElementById("rdoQPUser") && document.getElementById("rdoQPUser").checked)
        ShowHideControls(document.getElementById("rdoQPUser"));

    if (document.getElementById("rdoPAUser") && document.getElementById("rdoPAUser").checked)
        ShowHideControls(document.getElementById("rdoPAUser"));

    if (document.getElementById("rdoDBorCCNumber") && document.getElementById("rdoDBorCCNumber").checked)
        ShowHideControls(document.getElementById("rdoDBorCCNumber"));

    if (document.getElementById("rdoOtherAcctNumber") && document.getElementById("rdoOtherAcctNumber").checked)
        ShowHideControls(document.getElementById("rdoOtherAcctNumber"));

    if (document.getElementById("rdoCmlLoanNumber") && document.getElementById("rdoCmlLoanNumber").checked) {
        ShowHideControls(document.getElementById("rdoCmlLoanNumber"))
        ToggleCustomerId()
    };
}

function ToggleCustomerId() {
    var loanAcctLength = document.getElementById('txtCmlLoanAcctNumber').value.length;
    var customerIdField = document.getElementById('txtCmlLoanCustomerIdNumber');
    var customerIdLabel = document.getElementById('lblLoanCustomerId');
    var customerIdReq = document.getElementById('loanCustomerIdReqd');
    if (customerIdField) {
        if (loanAcctLength > 6) {
            customerIdField.style.backgroundColor = 'transparent';
            customerIdField.disabled = false;
            customerIdLabel.className = '';
            customerIdReq.className = 'alertText2';
        }
        else {
            customerIdField.style.backgroundColor = '#CCCCCC';
            customerIdField.value = '';
            customerIdField.disabled = true;
            customerIdLabel.className = 'greytext';
            customerIdReq.className = 'alertText2 greytext';
        }
    }
}
