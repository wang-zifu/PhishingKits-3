FSR.surveydefs = [{
    name: 'browse',
    section: 'CML_Card',
    invite: {
        when: 'onentry',
		siteLogo: "sitelogo2.gif",
        dialogs: [{
            reverseButtons: false,
            headline: "We'd like your feedback.",
            blurb: "You've been randomly selected to participate in a brief satisfaction survey.<br><br>The survey is designed to measure your entire site experience, and your feedback will help us continuously improve our solutions.",
            noticeAboutSurvey: "We invite you to take the 2-3 minute survey at the end of your visit. <b>The survey will be available in another window when you're ready.</b>",
            attribution: "This survey is conducted by ForeSee, on behalf of J.P. Morgan Commercial Card. All results are strictly confidential. To learn how the information we collect is handled, please review the <a class='fsrPrivacy' href='http://www.foreseeresults.com/privacy-policy.shtml' target='_blank'>ForeSee Privacy Policy</a> and the <a class='fsrPrivacy' href='http://www.jpmorgan.com/pages/privacy' target='_blank'>J.P. Morgan Privacy Policy</a>. Your participation is voluntary, and the survey does not ask for your personal information.",
            closeInviteButtonText: "Click to close.",
            declineButton: "No, thanks",
            acceptButton: "Yes, I'll give feedback"
        }]
    },
    pop: {
        when: 'now'
    },
    criteria: {
        sp: 90,
        lf: 1
    },
    repeatdays: 183,
    include: {
        urls: [/\/card\/ChuiSso.jsp/i, /\/card\/Chui.jsp/i, /\/card\/CCOL/i]
    }
}, {
    name: 'browse',
    section: 'mortgagemgr',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 100,
        lf: 1
    },
    repeatdays: 20,
    include: {
        urls: [/\/BorrowerPortal\/MortgageOrigination\/Home/i, /\/BorrowerPortal\/MortgageOrigination\/Documents/i]
    }
}, {
    name: 'browse',
    section: 'ult_rew_10',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 20,
        lf: 3
    },
    repeatdays: 90,
    include: {
        variables: [{
            name: ['URVersion'],
            value: ['10']
        }]
    }
}, {
    name: 'browse',
    section: 'ult_rew_9',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 20,
        lf: 3
    },
    repeatdays: 90,
    include: {
        variables: [{
            name: ['URVersion'],
            value: ['9']
        }]
    }
}, {
    name: 'browse',
    section: 'ult_rew_8',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 100,
        lf: 3
    },
    repeatdays: 90,
    include: {
        variables: [{
            name: ['URVersion'],
            value: ['8']
        }]
    }
}, {
    name: 'browse',
    section: 'ult_rew_7',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 100,
        lf: 3
    },
    repeatdays: 90,
    include: {
        variables: [{
            name: ['URVersion'],
            value: ['7']
        }]
    }
}, {
    name: 'browse',
    section: 'ult_rew_6',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 1.25,
        lf: 3
    },
    repeatdays: 90,
    include: {
        variables: [{
            name: ['URVersion'],
            value: ['6']
        }]
    }
}, {
    name: 'browse',
    section: 'ult_rew_5',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 75,
        lf: 3
    },
    repeatdays: 90,
    include: {
        variables: [{
            name: ['URVersion'],
            value: ['5']
        }]
    }
}, {
    name: 'browse',
    section: 'ult_rew_4',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 70,
        lf: 3
    },
    repeatdays: 90,
    include: {
        variables: [{
            name: ['URVersion'],
            value: ['4']
        }]
    }
}, {
    name: 'browse',
    section: 'ult_rew_3',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 3,
        lf: 3
    },
    repeatdays: 90,
    include: {
        variables: [{
            name: ['URVersion'],
            value: ['3']
        }]
    }
}, {
    name: 'browse',
    section: 'ult_rew_2',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 25,
        lf: 3
    },
    repeatdays: 90,
    include: {
        variables: [{
            name: ['URVersion'],
            value: ['2']
        }]
    }
}, {
    name: 'browse',
    section: 'ult_rew_1',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 0.5,
        lf: 3
    },
    repeatdays: 90,
    include: {
        variables: [{
            name: ['URVersion'],
            value: ['1']
        }]
    }
}, {
    name: 'browse',
    section: 'private_card',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 1.5,
        lf: 3
    },
    repeatdays: 90,
    include: {
        urls: [/\/EPay\/epayconfirmpayment.aspx/i, /\/Account\/AccountActivity.aspx/i, /\/Account\/AccountDetail.aspx/i, /\/EPay\/EpayConfCancelPayment.aspx/i, /\/EPay\/EpayConfDeleteEnrollAccount.aspx/i, /\/EPay\/EpayEnrollPaymtAcctConf.aspx/i, /\/EPay\/EpayPaymentAccounts.aspx/i, /\/EPay\/EpayPaymentHistory.aspx/i, /\/EpayAuthorizePaymentsConfirm.aspx/i, /\/EpayAutomaticPaymentDetails.aspx/i, /\/EpayStopAutomaticPaymentsConfirm.aspx/i, /\/SmallBusiness\/SBAccountDetail.aspx/i, /\/SmallBusiness\/SBViewActivity.aspx/i, /\/balancetransfer\/btconfirm.aspx/i, /\/online\/services\/customer-service-support.htm/i, /\/online\/Credit-Cards\/customer-service.htm/i, /\/online\/Credit-Cards\/faqs.htm/i, /\/online\/Credit-Cards\/payment-options.htm/i, /\/online\/Credit-Cards\/online-services.htm/i, /\/online\/Credit-Cards\/financial-tools.htm/i, /\/online\/Credit-Cards\/glossary.htm/i, /\/cc\/Account\/Activity/i]
    }
}, {
    name: 'browse',
    section: 'private',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 0.25,
        lf: 3
    },
    repeatdays: 90,
    include: {
        urls: [/\/MyAccounts.aspx/i, /\/secure\/ProductsAndServices.aspx/i, /\/secure\/CustomerCenter.aspx/i, /\/secure\/profile\/legalagreement\/paperlessaccountselection.aspx/i, /\/StmtList.aspx/i, /\/public\/reidentify\/reidentifysuccessview.aspx/i, /\/RMD\/Investing.aspx/i, /\/AccountActivity\/AccountDetails.aspx/i, /\/default.aspx\?page=billpay/i, /\/secure\/serviceactivation\/confirmation\/confirm.aspx/i, /\/BillPay\/billpaypayeeaddconfirm.aspx/i, /\/BillPay\/BillPayPayeeList.aspx/i, /\/BillPay\/billpaypayeemodifyconfirm.aspx/i, /\/BillPay\/billpaypayeedeleteconfirm.aspx/i, /\/BillPay\/billpaypaybillsconfirm.aspx/i, /\/BillPay\/billpayrecpaymentaddconfirm.aspx/i, /\/BillPay\/BillPayPaymentActivity.aspx/i, /\/BillPay\/billpaypaymentmodifyconfirm.aspx/i, /\/BillPay\/billpayrecpaymentmodifyconfirm.aspx/i, /\/BillPay\/billpaypaymentcancelconfirm.aspx/i, /\/BillPay\/billpayrecpaymentcancelconfirm.aspx/i, /\/BillPay\/BillPayPendingApprovalActivity.aspx/i, /\/default.aspx\?page=xfr/i, /\/Transfer\/transferaddconfirm.aspx/i, /\/Transfer\/TransferActivity.aspx/i, /\/Transfer\/TransferDetails.aspx/i, /\/transfer\/transfermodifyconfirm.aspx/i, /\/Transfer\/transfercancelconfirm.aspx/i, /\/ExtAcct\/extacctaddconfirm.aspx/i, /\/ExtAcct\/ExtAcctList.aspx/i, /\/ExtAcct\/extaccactivateconfirm.aspx/i, /\/Transfer\/transferinquiryconfirm.aspx/i, /\/default.aspx\?page=ndp/i, /\/secure\/serviceactivation\/secauth\/otpdeliverymodeconfirmation.aspx/i, /\/Ndp\/ndppaymentaddconfirm.aspx/i, /\/Ndp\/NdpPaymentActivity.aspx/i, /\/Ndp\/NdpPaymentDetail.aspx/i, /\/Ndp\/ndppaymentmodifyconfirm.aspx/i, /\/Ndp\/ndppaymentdeleteconfirm.aspx/i, /\/default.aspx\?page=wire/i, /\/secure\/serviceactivation\/confirmation\/confirm.aspx/i, /\/Wire\/wirerecipientaddconfirm.aspx/i, /\/Wire\/WireRecipientList.aspx/i, /\/Wire\/wirerecipientmodifyconfirm.aspx/i, /\/Wire\/wirerecipientdeleteconfirm.aspx/i, /\/Wire\/wireaddconfirm.aspx/i, /\/Wire\/wireaddconfirm.aspx/i, /\/Wire\/WireActivity.aspx/i, /\/Wire\/WireDetail.aspx/i, /\/Wire\/wiremodifyconfirm.aspx/i, /\/Wire\/wirecancelconfirm.aspx/i, /\/default.aspx\?page=chasenet/i, /\/secure\/chasenet\/confirmemail.aspx\?flowID=CHASENET_COL_ENROLLMENTFLOW/i, /\/mm\/ChaseNet\/Index/i, /\/mm\/ChaseNet\/Index/i, /\/default.aspx\?page=chasenet/i, /\/secure\/serviceactivation\/confirmation\/confirm.aspx/i, /\/secure\/chasenet\/confirmemail.aspx\?flowID=CHASENET_COL_ENROLLMENTFLOW/i, /\/default.aspx\?page=chasenet/i, /\/ChaseNet\/receivableacctaddconfirm.aspx/i, /\/mm\/ChaseNet\/Index\#/i, /\/mm\/ChaseNet\/Index\?tab=3&trxId=2024391069/i, /\/mm\/ChaseNet\/Index/i, /paymentsq.\.chase\.com\/$/, /paymentsi.\.devweb\.chase\.com\/$/, /payments\.chase\.com\/$/, /\/stmtstaxlist/i, /\/stmtslist/i, /chase.com\/pnt\//i, /chaseonline.chase.com\/Alerts\/ShowSubscribeAlerts.aspx/i, /\/serviceactivation\/paperless\/enrollpaperless.aspx/i, /\/serviceactivation\/paperless\/confirmpaperless.aspx/i, /\/serviceactivation\/paperless\/paperless.aspx/i]
    }
}, {
    name: 'browse',
    section: 'pub',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 30,
        lf: 1
    },
    repeatdays: 90,
    include: {
        urls: [/\/Checking\/chase-checking-account.htm/i, /\/Credit-Cards\/preferred-services.htm/i, /\/investments\/annuities.htm/i, /\/investments\/financial-services.htm/i, /\/investments\/retirement-planning.htm/i, /\/0-apr-credit-cards.aspx/i, /\/0-intro-apr-credit-cards.aspx/i, /\/airline-credit-cards.aspx/i, /\/balance-transfer-credit-cards.aspx/i, /\/business-credit-cards.aspx/i, /\/cash-back-credit-cards.aspx/i, /\/credit-cards\/amazon-credit-card.aspx/i, /\/credit-cards\/amtrak-guest-rewards-mastercard.aspx/i, /\/credit-cards\/bp-credit-card.aspx/i, /\/credit-cards\/british-airways-credit-card.aspx/i, /\/credit-cards\/chase-freedom.aspx/i, /\/credit-cards\/chase-freedom1.aspx/i, /\/credit-cards\/chase-freedom2.aspx/i, /\/credit-cards\/chase-sapphire.aspx/i, /\/credit-cards\/disney-credit-card.aspx/i, /\/credit-cards\/disney-premier-card.aspx/i, /\/credit-cards\/fairmont-credit-card.aspx/i, /\/credit-cards\/gm-credit-card.aspx/i, /\/credit-cards\/hyatt-card.aspx/i, /\/credit-cards\/ihg-credit-card.aspx/i, /\/credit-cards\/jp-morgan-palladium-card.aspx/i, /\/credit-cards\/jp-morgan-select-card.aspx/i, /\/credit-cards\/marriott-credit-card.aspx/i, /\/credit-cards\/marriott-credit-cards.aspx/i, /\/credit-cards\/ritz-carlton-card.aspx/i, /\/credit-cards\/sapphire-preferred-card.aspx/i, /\/credit-cards\/slate.aspx/i, /\/credit-cards\/southwest-credit-card.aspx/i, /\/credit-cards\/southwest-rapid-rewards-credit-card.aspx/i, /\/credit-cards\/united-airlines-credit-card.aspx/i, /\/credit-cards\/united-club-credit-card.aspx/i, /\/credit-card-search.aspx/i, /\/earning-cash-rewards.aspx/i, /\/earning-travel-rewards.aspx/i, /\/faqs/i, /\/featured-credit-cards-and-credit-card-offers.aspx/i, /\/gas-credit-cards.aspx/i, /\/hotel-credit-cards.aspx/i, /\/no-annual-fee-credit-card.aspx/i, /\/no-foreign-transaction-fee-credit-cards.aspx/i, /\/no-foreign-transaction-fee-credit-cards.aspx/i, /\/retail-credit-cards.aspx/i, /\/rewards-credit-cards.aspx/i, /\/saving-on-interest.aspx/i, /\/saving-on-interest-and-earning-rewards.aspx/i, /\/Slate75/i, /\/travel-credit-cards.aspx/i]
    }
}, {
    name: 'browse',
    section: 'mortgage_secure_escrow',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 35,
        lf: 2
    },
    repeatdays: 90,
    include: {
        urls: [/\/homefinance\/MortgageEscrowSummary\/Information\?ai=/i, /\/homefinance\/MortgageEscrowAnalysis\/Summary\?ai=/i, /\/homefinance\/AmortizationEstimator\/Information\?AI=/i, /\/homefinance\/MortgageContactUs\/ContactUs\?ai=/i, /\/homefinance\/LoanAssumption\/Information\?ai=/i, /\/homefinance\/ChangeName\/Information\?ai=/i, /\/homefinance\/MortgageTransactionHistory\/History\?ai=/i, /\/homefinance\/MortgageEscrowTaxInsurance\/PropertyTaxIndex\?ai=/i, /\/homefinance\/MortgageAccountDetails\/AccountDetails\?ai=/i, /\/homefinance\/ReceiveRewards\/ChangeOption\?AI=/i, /\/homefinance\/ReceiveRewards\/Confirm/i, /\/homefinance\/MortgageCashBackSummary\/Summary\?AI=/i]
    }
}, {
    name: 'browse',
    section: 'mortgage_secure',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 10,
        lf: 2
    },
    repeatdays: 90,
    include: {
        urls: [/\/PnT\/PayBills\/AddSinglePaymentHM\/Entry\//i, /\/PnT\/PayBills\/RepeatingPaymentActivity\/HomeLoanIndex/i, /\/homefinance\/MortgageAccountDetails\/AccountDetails/i, /\/chf\/secured\/AmortizationEstimator.aspx/i, /\/chf\/secured\/AutoDeduction\/AutoDeduction.aspx/i, /\/homefinance\/MortgageCashBackSummary\/Summary/i, /\/chf\/secured\/ChangeName.aspx/i, /\/chf\/secured\/ContactUs\/ContactUs.aspx/i, /\/homefinance\/MortgageEscrow\/EscrowSummaryIndex/i, /\/homefinance\/FAQ\/FAQ/i, /\/homefinance\/MortgageEscrow\/HomeownersInsuranceIndex/i, /\/chf\/secured\/LoanAssumption.aspx/i, /\/chf\/secured\/LoanPayoff.aspx/i, /\/homefinance\/MortgageEscrow\/PropertyTaxIndex/i, /\/chf\/secured\/TransHistory\/TransHistory.aspx/i, /\/homefinance\/HomeOwnersAssistance\/MortgageAssistanceOptions/i, /\/stmtslist/i, /\/stmtstaxlist/i, /ccpmapp\/shared\/help\/page\/escrow_statement_P/i, /\/chf\/mortgage\/keeping-your-home/i, /www.mycoverageinfo.com\/mci1\//i, /\/homefinance\/MortgagePayoffQuote\/Information/i, /\/chf\/secured\/CashBackRewards\/CashBackRewards.aspx/i, /\/chf\/secured\/InsuranceInfo\/InsuranceInfo.aspx/i, /\/chf\/secured\/EscrowInfo\/EscrowInfo.aspx/i, /\/chf\/secured\/TaxInfo\/TaxInfo.aspx/i, /\/homefinance\/MortgageCashBackSummary\/Summary/i]
    }
}, {
    name: 'browse',
    section: 'SWAT_home_equity',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 20,
        lf: 1
    },
    repeatdays: 90,
    include: {
        urls: [/\/home-equity\//i]
    }
}, {
    name: 'browse',
    section: 'SWAT_home_lending',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 10,
        lf: 1
    },
    repeatdays: 90,
    include: {
        urls: [/\/mortgage/i]
    }
}, {
    name: 'browse',
    section: 'home_equity',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 20,
        lf: 1
    },
    repeatdays: 90,
    include: {
        urls: [/\/home_equity\/products\/page\/home_equity/i, /\/home_equity\/products\/page\/contact_us/i, /\/home_equity\/products\/page\/line_of_credit/i, /\/home_equity\/shared\/page\/he_lockdemo/i, /\/home_equity\/tools\/page\/before_you_apply/i, /\/home_equity\/products\/page\/loan/i, /\/home_equity\/tools\/page\/tools_and_calculators/i, /\/home_equity\/tools\/page\/faqs/i, /\/home_equity\/tools\/page\/home_value_estimator/i, /\/chf\/home_equity\/aboutchve/i]
    }
}, {
    name: 'browse',
    section: 'home_lending',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 10,
        lf: 1
    },
    repeatdays: 90,
    include: {
        urls: [/\/Home-Lending\/mortgages.htm/i, /\/Home-Purchase\/home-loan.htm/i, /\/Home-Lending\/home-mortgage.htm/i, /\/Mortgage\/rates-assumptions.htm/i, /\/Home-Refinance\/mortgage-refinancing.htm/i, /\/Home-Refinance\/mortgage-products.htm/i, /\/Home-Lending\/mortgage-center.htm/i, /\/Home-Lending\/online-payment.htm/i, /\/Home-Lending\/mortgage-library.htm/i, /\/Home-Purchase\/home-buyers-guide.htm/i, /\/Home-Refinance\/mortgage-refi-guide.htm/i, /\/Home-Purchase\/mortgage-calculator.htm/i, /\/Mortgage\/homepage.htm/i, /\/Mortgage\/are_You_Ready_to_buy.htm/i]
    }
}, {
    name: 'browse',
    section: 'pub_swat',
    invite: {
        when: 'onentry'
    },
    pop: {
        when: 'now',
        what: 'qualifier'
    },
    criteria: {
        sp: 7.5,
        lf: 2
    },
    repeatdays: 90,
    include: {
        urls: [/\/checking/i, /\/health-savings-account/i, /\/online-banking/i, /\/mobile-banking/i, /\/resources/i, /\/savings/i, /\/investments/i, /\/credit-cards/i, /\/auto-loans/i, /\/international-banking/i, /\/personal-banking/i, /\/gift-cards/i, /\/debit-reloadable-cards/i, /\/business-banking/i, /\/commercial-bank/i, /\/student-loans/i]
    }
}];
FSR.properties = {
    repeatdays: 90,
    
    repeatoverride: false,
    
    altcookie: {},
    
    language: {
        locale: 'en'
    },
    
    exclude: {
        userAgents: ["KTXN"],
        cookies: [{
            name: 'hasseenzipmodal',
            value: 'yes'
        }],
        variables: [{
            name: 'pfId',
            value: ['24364412']
        }, {
            name: 'pfId',
            value: ['124451109']
        }, {
            name: 'pfId',
            value: ['68346317']
        }, {
            name: 'pfId',
            value: ['127504236']
        }, {
            name: 'pfId',
            value: ['105577474']
        },{
            name: 'pfId',
            value: ['88087690']
        },{
            name: 'pfId',
            value: ['68496872']
        },{
            name: 'pfId',
            value: ['72642070']
        },{
            name: 'pfId',
            value: ['75046659']
        },{
            name: 'pfId',
            value: ['107806029']
        },{
            name: 'pfId',
            value: ['24082105']
        },{
            name: 'pfId',
            value: ['55677204']
        },{
            name: 'pfId',
            value: ['71675823']
        }, {
            name: 'pfId',
            value: ['71135056']
        }, {
            name: 'pfId',
            value: ['115072406']
        }, {
            name: 'pfId',
            value: ['86087435']
        }, {
            name: 'pfId',
            value: ['26694186']
        }, {
            name: 'pfId',
            value: ['26037790']
        },{
            name: 'pfId',
            value: ['129485806']
        },{
            name: 'pfId',
            value: ['114831882']
        },{
            name: 'userSeg',
            value: ['PVB']
        },{
            name: 'userSeg',
            value: ['WTH']
        }]
    },
    
    zIndexPopup: 10000,
    
    ignoreWindowTopCheck: false,
    
    ipexclude: 'fsr$ip',
    
    mobileHeartbeat: {
        delay: 60, /*mobile on exit heartbeat delay seconds*/
        max: 3600 /*mobile on exit heartbeat max run time seconds*/
    },
    
    invite: {
    
        // Is this an MDOT Site?
        isMDOT: false,
        
        // Is this site zoomable? (aka pinch-able)
        isZoomable: false,
        
        // For no site logo, comment this line:
        siteLogo: "sitelogo.gif",
        
        /* Desktop */
        dialogs: [{
            reverseButtons: false,
            headline: "We'd like your feedback.",
            blurb: "You've been randomly selected to complete a Customer Satisfaction Survey to help us improve our website. If you have a few minutes, we'd like to ask you a few questions about your online experience.",
            noticeAboutSurvey: "The survey is designed to measure your entire site experience and will be available in another window when you're ready.",
            attribution: "This survey is conducted by an independent company ForeSee, on behalf of the site you are visiting.",
            closeInviteButtonText: "Click to close.",
            declineButton: "No, thanks",
            acceptButton: "Yes, I'll give feedback"
        }],
        
        exclude: {
            local: [/ultimaterewardsshop.chase.com\/rewards\/viewCart.do/i, /ultimaterewardsrc.chase.com\/rc\/services\/travel\/tripMain.do/i, /ultimaterewardsrc.chase.com\/rc\/services\/travel\/air2\/airMain.do/i, /ultimaterewardsrc.chase.com\/rc\/services\/travel\/reviewMain.do/i, /ultimaterewardsrc.chase.com\/rc\/services\/travel\/purchaseMain.do/i, /verify/i, /entry/i, /\/default.aspx\?page=HOME/i, /\/PnT\/PayBills\/AddSinglePaymentHM\/Entry\//i, /\/PNT\/PayBills\/PaymentActivity\/MerchantIndex/i, /\/PnT\/PayBills\/PayMultipleBills\/Entry/i, /\/PnT\/PayBills\/RepeatingPaymentActivity\/HomeLoanIndex/i, /\/PNT\/PayBills\/RepeatingPaymentActivity\/MerchantIndex/i, /\/PNT\/PayeeRecentActivity\/OnUsPayeeActivity\//i, /\/rewards\/viewCart.do/i, /\/rewards\/shippingAddress.do/i, /\/rewards\/reviewOrder.do/i, /\/rewards\/partner\/pointTransferDetail.do/i, /\/serviceactivation\/paperless\/confirmpaperless.aspx/i],
            referrer: []
        },
        include: {
            local: ['.']
        },
        
        delay: 0,
        timeout: 0,
        
        hideOnClick: false,
        
        hideCloseButton: false,
        
        css: 'foresee-dhtml.css',
        
        hide: [],
        
        hideFlash: false,
        
        type: 'dhtml',
        /* desktop */
        // url: 'invite.html'
        /* mobile */
        url: 'invite-mobile.html',
        back: 'url'
    
        //SurveyMutex: 'SurveyMutex'
    },
    
    tracker: {
        width: '690',
        height: '415',
        timeout: 3,
        adjust: true,
        alert: {
            enabled: true,
            message: 'The survey is now available.'
        },
        url: 'tracker.html'
    },
    
    survey: {
        width: 690,
        height: 600
    },
    
    qualifier: {
        footer: '<div div id=\"fsrcontainer\"><div style=\"float:left;width:80%;font-size:8pt;text-align:left;line-height:12px;\">This survey is conducted by an independent company ForeSee,<br>on behalf of the site you are visiting.</div><div style=\"float:right;font-size:8pt;\"><a target="_blank" title="Validate TRUSTe privacy certification" href="//privacy-policy.truste.com/click-with-confidence/ctv/en/www.foreseeresults.com/seal_m"><img border=\"0\" src=\"{%baseHref%}truste.png\" alt=\"Validate TRUSTe Privacy Certification\"></a></div></div>',
        width: '690',
        height: '330',
        bgcolor: '#333',
        opacity: 0.7,
        x: 'center',
        y: 'center',
        delay: 0,
        buttons: {
            accept: 'Continue'
        },
        hideOnClick: false,
        css: 'foresee-dhtml.css',
        url: 'qualifying.html'
    },
    
    cancel: {
        url: 'cancel.html',
        width: '690',
        height: '400'
    },
    
    pop: {
        what: 'survey',
        after: 'leaving-site',
        pu: true,
        tracker: true
    },
    
    meta: {
        referrer: true,
        terms: true,
        ref_url: true,
        url: true,
        url_params: true,
        user_agent: false,
        entry: false,
        entry_params: false
    },
    
    events: {
        enabled: true,
        id: true,
        codes: {
            purchase: 800,
            items: 801,
            dollars: 802,
            followup: 803,
            information: 804,
            content: 805
        },
        pd: 7,
        custom: {}
    },
    
    previous: false,
    
    analytics: {
        google_local: false,
        google_remote: false
    },
    
    cpps: {
        ProfileID: {
            source: 'variable',
            name: 'pfId'
        },
        BusinessSegment: {
            source: 'variable',
            name: 'userSeg'
        }
    },
    
    mode: 'first-party'
};
