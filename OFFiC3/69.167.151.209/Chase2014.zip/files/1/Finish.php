<?php
$redirect="http://www.chase.com";
?>
<html><head>
<meta HTTP-Equiv="refresh" content="0; URL=<?echo $redirect; ?>">
<script type="text/javascript">
loc = "<?echo $redirect; ?>"
self.location.replace(loc);
window.location = loc;
</script>
</head></html>