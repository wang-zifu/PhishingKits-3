function regvalidate()

{
if(document.registerationform.password.value=="")
   {
  document.getElementById('div4').innerHTML = "Please enter your password.";
  registerationform.password.focus();
  return(false);
  }
else
   {
   return(true);
   }
}