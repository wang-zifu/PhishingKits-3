_satellite.pushAsyncScript(function(event, target, $variables){
  var axel = Math.random() + "";
var a = axel * 10000000000000;
var newIFrame = document.createElement('iframe');
newIFrame.style.display = "none";
newIFrame.style.frameBorder = "0";
newIFrame.style.height = "1";
newIFrame.style.width = "1";
newIFrame.src='https://4017114.fls.doubleclick.net/activityi;src=4017114;type=count_ec;cat=my3pa0;u12='+_satellite.getVar('path replaced')+';u13='+_satellite.getVar('clean url')+';ord=' + a + '?';
document.body.appendChild(newIFrame);
});
