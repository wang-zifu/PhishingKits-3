_satellite.pushAsyncScript(function(event, target, $variables){
  $('*[data-intid]').click(function() {
  s.linkTrackVars='eVar4';
  s.eVar4 = $(this).data('intid');
  s.tl(this,'o','internal_tracking',null);
});
});
