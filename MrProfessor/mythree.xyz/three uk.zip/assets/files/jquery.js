/*! jQuery plugin for Hammer.JS - v1.1.1 - 2014-04-23
 * http://eightmedia.github.com/hammer.js
 *
 * Copyright (c) 2014 Jorik Tangelder <j.tangelder@gmail.com>;
 * Licensed under the MIT license */

!function(a){"use strict";function b(a,b){Date.now||(Date.now=function(){return(new Date).getTime()}),a.utils.each(["on","off"],function(c){a.utils[c]=function(a,d,e){b(a)[c](d,function(a){var c=b.extend({},a.originalEvent,a);e.call(this,c)})}}),a.Instance.prototype.trigger=function(a,c){var d=b(this.element);return d.has(c.target).length&&(d=b(c.target)),d.trigger({type:a,gesture:c})},b.fn.hammer=function(c){return this.each(function(){var d=b(this),e=d.data("hammer");e?e&&c&&a.utils.extend(e.options,c):d.data("hammer",new a(this,c||{}))})}}"function"==typeof define&&define.amd?define(["hammerjs","jquery"],b):b(a.Hammer,a.jQuery||a.Zepto)}(window);
//# sourceMappingURL=jquery.hammer.min.map