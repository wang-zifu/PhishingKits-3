_satellite.pushBlockingScript(function(event, target, $variables){
  $(document).ready(function(){
	// Add Home broadband to desktop navigation
  $('.navigation-menu h2:contains("Mobile broadband")').before('<h2 class="small"><a rel="nofollow" aria-label="Home broadband" data-intid="3main_hbb_meganavigation" href="/store/broadband/home-broadband">Home broadband</a></h2>');
  
  // Add Home broadband to mobile navigation
  $("#nav-and-search ul.depth-2 a:contains('Mobile broadband')").parent().before('<li class="menu-option"><a class="highlight-link" tabindex="0" role="menuitem" aria-haspopup="true" aria-expanded="false" data-intid="3main_hbb_meganavigation" href="/store/broadband/home-broadband"><span class="highlight-title">Home broadband</span><i class="icon-chevron-right-thin greycd"></i></a></li>');
  
  // Tablets appears under SIM Only on desktop
  $('header h2:contains("Mobile broadband")').next('ul').children('li:contains("Tablets")').remove();
  $('header h2:contains("SIM Only") + ul').after('<h2 class="small"><a rel="nofollow" aria-label="Tablets" href="/Store/tablet-listings">Tablets</a></h2>');
  
  // Tablets appears under SIM Only on mobile
  $("#nav-and-search ul.depth-3 a:contains('Tablets')").parent().remove();
  $("#nav-and-search ul.depth-2>li.menu-option:contains('SIM Only')").after('<li class="menu-option"><a class="highlight-link" tabindex="-1" href="/Store/tablet-listings" role="menuitem"><span class="highlight-title">Tablets</span><i class="icon-chevron-right-thin greycd"></i></a>');  
});
});
