_satellite.pushAsyncScript(function(event, target, $variables){
  function boldchatTracking() {
  (s.linkTrackVars = ''),
    (s.eVar7 = 'boldchat_widget:click'),
    (s.eVar9 = window.location.pathname),
    s.tl(this, 'o', 'boldchat_widget', null);
}

$('body').on(
  'click',
  '.bcFloat a img[src*="livechat_popout_small.png"]',
  function() {
    boldchatTracking();
  }
);
});
