_satellite.pushAsyncScript(function(event, target, $variables){
  var nowChatListner = false;

(function ($) {

// globals
var csSessionId = "";
var handlerLoaded= false;
var allowChatHandler = true;
var extLoggedChat = false;
var extLoggedProactiveChat = false;
var nowEventListners = false;

var extLoggedGetInTouch = false;
var extLoggedProactiveServiceChat = false;
var extLoggedProactiveServiceChatAcp = false;
var isInReferencegroup
var _interactionLogId;

return IMP_HL = {

    // on/off section - change true to false to turn off and vice versa

exist_handle_accepttel: function() { return true; },
exist_handle_show: function() { return true; },
exist_handle_page: function() { return false; },
exist_handle_acceptpuff: function() { return true; },
exist_handle_customized: function() { return true},
exist_handle_close: function() { return true; },
exist_handle_customized_number: function() { return true},
exist_handle_receiveInfo: function() { return false; },
exist_logUserGroup: function() { return false; },
exist_logSessionGroup: function() { return false; },
exist_appendLocalSiteProp: function() { return true; },
exist_handle_inithandler: function() { return true; },
exist_handle_runhandler: function() { return true; },
exist_handle_runhandlerresult: function() { return true; },
exist_check_handlerpattern: function() { return true; },
allow_nocookie: function() { return false; },
allow_storage: function() { return false; },

allow_chat: function() {

  return allowChatHandler;

  },



readCookie: function(cname) {
      var name = cname + "=";
        var ca = document.cookie.split(';');
        for(var i=0; i<ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0)==' ') c = c.substring(1);
            if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
        }
        return "";
   },



// the handlers

    logUserGroup: function (code) {

      },

handle_accepttel: function () {


  $(document).trigger( "nowinteractEvent", [ "accept","callback"] )




    },

handle_acceptpuff: function (code, interactionLogId, userkey, sessionkey) {

      $(document).trigger( "nowinteractEvent", [ "accept",""] )

      if(code === "showChat")
      {
          IMP.trackDisplay(interactionLogId, 0, 0);
          $(".bcFloat").clone(true).insertAfter(".bcFloat:last");
          $(".bcFloat:first").remove();
          $(".bcFloat").css("width","240px");
          $(".bcFloat div").css("margin-left","0px");
          $(".bcFloat").on("click",function(){

          $(".bcFloat").hide();
          $("#now-bc-start a").click();

              setTimeout(function(){

                IMP.trackAccept(interactionLogId);

              },200);
          });


      }



},



handle_show: function (caption) {

      $(document).trigger("nowinteractEvent",[ "show",caption])
},

handle_close: function (caption) {

  $(document).trigger( "nowinteractEvent", [ "close",caption])
},

handle_customized: function (code, interactionLogId, displayReason, displayReasonDetail, isReferenceMessage) {


    if(code === "hideChat")
    {
        $(".bcFloat").remove();

                var refreshIntervalId = setInterval(function () {
                    if ($(".bcFloat").is(":visible"))
                            {
                                $(".bcFloat").remove();
                                clearInterval(refreshIntervalId);
                            }
                  },2000);
    }

    if(code == "startChat")
    {
      IMP.trackDisplay(interactionLogId, displayReason, displayReasonDetail);
      $("#now-bc-start a").click();

      setTimeout(function(){

        IMP.trackAccept(interactionLogId);

      },200);


    }






    if(code === "showChat")
    {
        IMP.trackDisplay(interactionLogId, displayReason, displayReasonDetail);
        $(".bcFloat").clone(true).insertAfter(".bcFloat:last");
        $(".bcFloat:first").remove();
        $(".bcFloat").css("width","240px");
        $(".bcFloat div").css("margin-left","0px");
        $(".bcFloat").on("click",function(){

        $(".bcFloat").hide();
        $("#now-bc-start a").click();

            setTimeout(function(){

              IMP.trackAccept(interactionLogId);

            },200);
        });


    }
    },

handle_customized_number: function (noA,noB,interactionLogId, displayReason, displayReasonDetail) {

  var special = false;
  if(noA === "hideChat")
  {
      $(".bcFloat").hide();
  }

  if(noA === "showChat")
  {
    IMP.trackDisplay(interactionLogId, displayReason, displayReasonDetail);

    $(".bcFloat").clone(true).insertAfter(".bcFloat:last");
    $(".bcFloat:first").remove();
    $(".bcFloat").css("width","240px");
    $(".bcFloat div").css("margin-left","0px");

    $(".bcFloat").on("click",function(){

    setTimeout(function(){
      $("#now-bc-start a").click();
      IMP.trackAccept(interactionLogId);
      $(".bcFloat").hide();
    },200);

    });
  }

  if(noA == "changePhone")
  {


    $("h3:contains('Phone account.')").parent("div").children("ul").children("li.span6:first").html("<span class='contact-num'>"+noB+"</span>")
    $("h3:contains('Phone account.')").parent("div").children("ul").children("li.span6:first").removeClass("pad-bottom1")
    $("h3:contains('Phone account.')").parent("div").children("ul").children("li.span6:last").hide()
    $("h3:contains('Phone account.')").removeClass("pad-bottom1")

    special = true;

  }

  if(noA == "changeBroadband")
  {

    $("h3:contains('Mobile Broadband account.')").parent("div").children("ul").children("li.span6:first").html("<span class='contact-num'>"+noB+"</span>")
    $("h3:contains('Mobile Broadband account.')").parent("div").children("ul").children("li.span6:first").removeClass("pad-bottom1")
    $("h3:contains('Mobile Broadband account.')").parent("div").children("ul").children("li.span6:last").hide()
    $("h3:contains('Mobile Broadband account.')").removeClass("pad-bottom1")

    special = true;
  }


  if(noA == "changeSales")
  {

    $("h3:contains('Sales enquiries.')").parent("div").children("ul").find(".contact-num").html("<span class='contact-num'>"+noB+"</span>")
    special = true;
  }

  if(!special)
  {

  var numbers = noA.split('|');

  for(var n = 0; n < numbers.length; n++)
  {
    noA = numbers[n];
    var regexp = /^[\s()+-]*([0-9][\s()+-]*){6,20}$/

            if (!regexp.test(noB)) {
                return false;
            }

            var noA_html_text = noA.replace(/ /g, '\xa0');
            var noA_html = noA.replace(/ /g, '&nbsp;');

            var noA_link = noA.replace(/ /g, '');
      var noA_link2 = noA_link.replace(/-/g, '');

            var noB_link = noB.replace(/ /g, '');
            noB_link = noB_link.replace(/-/g, '');

            regTestA = noA;
            regTestA_html = noA_html;

            regTestA = regTestA.replace("(", '\\(')
            regTestA = regTestA.replace(")", '\\)')


          try
          {
            $('a[href^="tel:'+noA_link+'"]').attr("href","tel:"+noB_link+"")
            $('a[href^="tel:'+noA_link2+'"]').attr("href","tel:"+noB_link+"")


            trackDisplayed = false;

             //Limit only change number 5 times on same page
             for(i=0;i<5;i++)
             {

         $(":contains('" + noA + "'):last").html(function() {



          if(typeof $(":contains('" + noA + "'):last").html()!= "undefined")
          {
              trackDisplayed = true;
              return $(":contains('" + noA + "'):last").html().replace(new RegExp(regTestA, "igm"), noB)
          }
          else
          {
            return false;
          }


              });


        $(":contains('" + noA_html_text + "'):last").html(function() {

          if(typeof $(":contains('" + noA_html_text + "'):last").html()!= "undefined")
          {
            trackDisplayed = true;
               return $(":contains('" + noA_html_text + "'):last").html().replace(new RegExp(regTestA_html, "igm"), noB)

          }
          else
          {
            return false;
          }
              });

        }

        if(trackDisplayed)
        {
          $(document).trigger( "nowinteractEvent",[ "changeNumber",""] )



          IMP.trackDisplay(interactionLogId, displayReason, displayReasonDetail);

        }


      }
      catch(e)
      {}

  }
    }
    },
    displayNowMessage: function(evt){


    if (evt.origin == "https://imp3.nowinteract.com") {

          if(typeof evt.data.nowevent == "string")
          {
              if(evt.data.nowevent == "startChat")
                {

                  $("#now-bc-start-service a").click();
                  $("#ni_imp_prim").remove();
                  IMP.trackLogToolAccept("EVENT_EXT_CHAT_SERVICE", "Chat");

                }
                if(evt.data.nowevent == "startSalesChat")
                  {

                    $("#now-bc-start a").click();
                    $("#ni_imp_prim").remove();
                    IMP.trackLogToolAccept("EVENT_EXT_CHAT_SALES", "Chat");

                  }
          }
    }
    },
  appendLocalSiteProp: function () {




      try {
    var my_arr = new Array();
    my_arr = document.getElementsByTagName("title");

      if (my_arr.length > 0) {
        IMP.appendSiteProp("title", my_arr[0].innerHTML);
      }
    }
    catch (e) {
    }


    try {
                 ga(function(tracker) {
                  var clientId = tracker.get('clientId');
          IMP.appendSiteProp("gaid",clientId);
                });
                }
                catch(locex){}


        try {
        if(typeof IMP_HL.readCookie === 'function') {

      if (IMP_HL.readCookie("_sdsat_colour")) {
        IMP.appendSiteProp("Colour",getCookie("_sdsat_colour"));
      }


      if (IMP_HL.readCookie("_sdsat_product")) {
        IMP.appendSiteProp("Product",getCookie("_sdsat_product"));
      }

      if (IMP_HL.readCookie("_sdsat_package id")) {
        IMP.appendSiteProp("Package_id",getCookie("_sdsat_package id"));
      }

      if (IMP_HL.readCookie("_sdsat_tariff")) {
        IMP.appendSiteProp("Tariff",getCookie("_sdsat_tariff"));
      }
      if (IMP_HL.readCookie("_sdsat_vendor")) {
        IMP.appendSiteProp("Vendor",getCookie("_sdsat_vendor"));
      }


    }
    }
    catch(e){
    }
    if(!nowEventListners)
    {







      if (window.addEventListener) {
        window.addEventListener("message", IMP_HL.displayNowMessage, false);
      }
      else {
        window.attachEvent("onmessage", IMP_HL.displayNowMessage);
      }






      var nowObserver = new MutationObserver(function(mutations) {

        if(!extLoggedProactiveServiceChat)
        {


        if(document.querySelectorAll(".hwp-smart-button").length > 0)
          {
            extLoggedProactiveServiceChat = true;

              IMP.trackLogToolDisplay('EVENT_PROACTIVE_SERVICE_CHAT');

                $(document).on("click",'.hwp-smart-button',function(){

                  IMP.trackLogToolDisplayAccept('Chat')

                });


          }

              if(document.querySelectorAll("[id^='wb_drag_wrapper']").length > 0)
              {
                extLoggedProactiveServiceChat = true;

                  IMP.trackLogToolDisplay('EVENT_PROACTIVE_LIVE_VIDEO');


              }




        }
        if(!extLoggedProactiveServiceChatAcp)
        {

          if(document.querySelectorAll("[id^='wb_drag_wrapper']").length > 0)
          {

            if(document.querySelectorAll("[id^='wb_drag_wrapper']")[0].clientHeight > 230)
            {
                extLoggedProactiveServiceChatAcp = true;
                IMP.trackLogToolDisplayAccept('Chat')


            }

        }

      }

      });



      nowObserver.observe(document.documentElement, {
        attributes: false,
        characterData: false,
        childList: true,
        subtree: true,
        attributeOldValue: false,
        characterDataOldValue: false
      });



















        $(document).on("click",'#bc-start',function(){
        if(!extLoggedChat)
          {

              IMP.trackLogToolAccept('EVENT_EXTCHAT_STARTED','')
              extLoggedChat = true;
          }

        });

        $(document).on("click",'.bcFloat img',function(){
        if(!extLoggedProactiveChat)
          {

              IMP.trackLogToolAccept('EVENT_EXTPROACTIVECHAT_STARTED','')
              extLoggedChat = true;
          }

        });

        $(document).on("click",'#get-in-touch',function(){
        if(!extLoggedGetInTouch)
          {

              IMP.trackLogToolAccept('EVENT_GET_IN_TOUCH','Other')
              extLoggedGetInTouch = true;
          }

        });

        $(document).on("click","#imp_norm_decline",function(){

          if($(this).hasClass("Maximize"))
          {
            $(document).trigger( "nowinteractEvent", [ "maximize",""] )
          }
          else
          {
            $(document).trigger( "nowinteractEvent", [ "minimize",""] )

          }

        });


                      var chatBtnDisplay = false;

                        var refreshIntervalChatId = setInterval(function(){

                              if($(".multichat:visible").length > 0)
                              {
                                if(!chatBtnDisplay)
                                {
                                  IMP.trackLogToolAccept('EVENT_EXT_CHAT_START_BUTTON','Chat');
                                  clearInterval(refreshIntervalChatId);
                                  chatBtnDisplay = true;
                                }
                              }
                          },2000)





                            var wbtrackDisplay = false;
                            var wbtrackDisplayAccept = false;

                            var refreshIntervalwb = setInterval(function(){

                                if($("[id^='wb_drag_wrapper:visible']").length > 0)
                                {
                                  if($("[id^='wb_drag_wrapper']").width() == 372)
                                    {
                                      if($("[id^='wb_drag_wrapper']").height() <= 500)
                                      {
                                        if(!wbtrackDisplay)
                                        {
                                          wbtrackDisplay = true;
                                          IMP.trackLogToolDisplay('EVENT_EXT_VIDEOCHAT_PROACTIVE');
                                        }

                                      }
                                      else {

                                        if(wbtrackDisplay)
                                        {

                                          if(!wbtrackDisplayAccept)
                                          {
                                            clearInterval(refreshIntervalwb);
                                            wbtrackDisplayAccept = true;
                                            IMP.trackLogToolDisplayAccept('VideoChat')

                                          }

                                        }
                                        else {


                                          if(!wbtrackDisplayAccept)
                                          {
                                            clearInterval(refreshIntervalwb);
                                            wbtrackDisplayAccept = true;
                                            IMP.trackLogToolAccept('EVENT_EXT_VIDEOCHAT_INPAGE','VideoChat');

                                          }

                                        }

                                      }

                                    }

                                    if(wbtrackDisplay && $("[id^='wb_drag_wrapper']").height == 95)
                                    {
                                      clearInterval(refreshIntervalwb);
                                      IMP.trackLogToolClose();
                                    }
                                }

                            },2000)


        nowEventListners = true;
        }

        try
        {
        if(IMP_HL.readCookie("imp_uk")) {

        if(this.readCookie("imp_uk").substring(0,1) == "F")
        {
          allowChatHandler = false;

        }
        else
        {
          allowChatHandler = true;

        }
      }

        }
    catch(e){

      allowChatHandler = true;
    }
      },

isInReferencegroup: function () {

          rtn = false;

          try
          {
        if(IMP_HL.readCookie("imp_uk")) {


        if(this.readCookie("imp_uk").substring(0,1) == "F")
        {
          rtn = true;

        }
    }
        }
    catch(e){

    }
        return rtn;

      },
getCsSessionId: function (code) {
            return csSessionId;
      },

check_handlerpattern: function (url) {
    patternresult = "";
    if (url) {
    try {
       if ( (url.toString().indexOf("costream-") >= 0) )   {
        patternresult = "1";
       }
    } catch (handlerex) {
    }
  }
  return patternresult;
    },

    handle_inithandler: function (handlername) {
  try {

    if ((typeof CS_HL === 'object') || (handlerLoaded) ){
      return true;
    } else {
      var cs = document.createElement('script'); cs.type = 'text/javascript';
      cs.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'imp3.nowinteract.com/dialogue/threeuk/clientscript/costream/cs.min.js';
      var s = document.getElementsByTagName('script')[0];
      s.parentNode.insertBefore(cs, s);
      handlerLoaded=true;
    }
  } catch (handlerex) {

  }
    },

      handle_runhandler: function (handlername, startstop, sessionid, mode, csid, language) {
  var result=0;
  try {
    csSessionId = 'threeuk' + sessionid;
    if (typeof CS_HL === 'object') {
      initCOS();
    } else {
      IMP_HL.handle_inithandler(handlername);
    }
      }	catch (handlerex) {
    //console.log(handlerex);
  }
  return result;
      },

handle_runhandlerresult: function (runhandlerresult) {

      },

receiveInfo: function (actionText,actionUrl,actionLogId) {

      }
};
} )(jQuery);

(function(){function A(){try{return window.self!==window.top}catch(a){return!0}}function Xb(){try{return document.hasFocus()}catch(a){return!0}}var G,va,O=3E3,ja=[],Ga=[],ka=0,kb=0,Ha=[],k=[,"ni_imp_prim","ni_imp_secd","ni_imp_spec"],aa=k[1],Ia=[];Ia.ni_imp_prim=1;Ia.ni_imp_secd=2;Ia.ni_imp_spec=3;var v=[];v[k[1]]=0;v[k[2]]=0;v[k[3]]=0;var la=[];la[k[1]]=!1;la[k[2]]=!1;la[k[3]]=!1;var ma=[,0,0,0],U=[];U[k[1]]="";U[k[2]]="";U[k[3]]="";var Z=[];Z[k[1]]=0;Z[k[2]]=0;Z[k[3]]=0;var ba=[];ba[k[1]]="";ba[k[2]]=
"";ba[k[3]]="";var wa=[];wa[k[1]]="";wa[k[2]]="";wa[k[3]]="";var lb=[,0,0,0],mb=[,0,0,0],Ja=[,0,0,0],Ka=[,0,0,0],nb=[,0,0,0],V=[,0,0,0],La=[];V[1]=!1;V[2]=!1;V[3]=!1;var na=[];na[k[1]]=0;na[k[2]]=0;na[k[3]]=0;La=[];V[1]=!1;V[2]=!1;V[3]=!1;var ca=[];ca[k[1]]=!1;ca[k[2]]=!1;ca[k[3]]=!1;var Yb=[],l=[,[],[],[]];l[1][1]=[];l[1][2]=[];l[1][3]=[];l[1][4]=[];l[2][1]=[];l[2][2]=[];l[2][3]=[];l[2][4]=[];l[3][1]=[];l[3][2]=[];l[3][3]=[];l[3][4]=[];var ob=!1,da=[],Zb=[],$c=[],pb=[],$b=[],ac=[],P=[];P[k[1]]=[];
P[k[2]]=[];P[k[3]]=[];var xa,ya,qb,Ma,za,Na=0,Oa=!1,bc=0,cc="nowinteract.com",Pa=0,rb=0,dc="notset",Aa=0,ec=!1,sb=!1,tb=!1,Ba=!1,ub=!1,Qa=0,Ra=0,fc=0,vb=0,T=0,Sa=0,Ta=0,ea=!1,wb=!1,Ua="scroll_0",xb,Va=!1,gc=!1,hc=!1,Q,yb=!1,oa=0,zb=0,Wa=0,Xa=0;Math.round((new Date).getTime()/1E3);var C="",H="",fa="",Ya="",ic="",Ab=!1,jc=0,pa=!1,Bb=!1,Cb=!1,Za=!1,Db=0,$a=0,kc=0,qa=!0,lc=!1,ab=!1,bb=!1,mc=!1,nc=(new Date).getTime(),ad=(new Date).getTime(),Eb=(new Date).getTime();imprushdialogueany=!1;imprushdialogueparams=
[,"","",""];var I=[,"",""],oc=!1,Fb=!1,W=!1,ga,J=document,pc=window,t=pc.encodeURIComponent||escape,bd=pc.decodeURIComponent||unescape,w=J.location.href,R=J.referrer,ha="",qc=function(a){a=a.split(".");return 4===a.length?a.every(function(a){return 0<=parseInt(a,10)&&255>=parseInt(a,10)}):!1},ra="",ra=function(){var a=document.location.hostname,b=a.toString().substr(a.toString().length-3),c=a.lastIndexOf("."),d=qc(a);-1<c&&!d&&(c=a.lastIndexOf(".",c-1),-1<c&&(".uk"==b||".in"==b||".id"==b||".il"==
b||".za"==b||".cr"==b||".nz"==b||".jp"==b||".kr"==b||".pe"==b||".br"==b||".ck"==b?(b=a.lastIndexOf(".",c-1),-1<b&&(a=a.substr(b+1))):a=a.substr(c+1)));return a}(),rc=function(a){var b={},c=a.indexOf("?");if(-1==c)return b;a=a.substring(c+1).split("&");for(c=0;c<a.length;c++){var d=a[c].split("=");b[d[0]]=d[1]}return b},n=function(a,b,c,d,e,j){var g;c&&(g=new Date,g.setTime(g.getTime()+864E5*c));ra&&(e=ra);J.cookie=a+"="+t(b)+(c?";expires="+g.toGMTString():"")+";path="+(d?d:"/")+(e?";domain="+e:"")+
(j?";secure":"")},Gb=function(a,b,c,d,e,j){var g;c&&(g=new Date,g.setTime(g.getTime()+864E5*c));ra&&(e=ra);J.cookie=a+"="+b+(c?";expires="+g.toGMTString():"")+";path="+(d?d:"/")+(e?";domain="+e:"")+(j?";secure":"")},o=function(a){return(a=RegExp("(^|;)[ ]*"+a+"=([^;]*)").exec(J.cookie))?bd(a[2]):0},sc=function(){var a="",a=new Date,b=a.getDate().toString(),c;c=a.getMonth()+1;c=10>c?"0"+c.toString():c.toString();for(var d=a.getFullYear().toString(),e=navigator.userAgent.toString().replace(/[\/();:. ]/g,
"").toUpperCase(),j=e.length,g=Math.floor(j/22),a="",f=0,h=0;h<j;h+=g)22>f&&(a+=e.charAt(h)),f++;primitiveStartChar="A";15>g&&0<g&&(primitiveStartChar="0123456789ABCDEF".toString().charAt(g));return primitiveStartChar+a+"_"+d+c+b},E=function(){if(Oa)return sc();var a=o("imp_uk");a||(a=z("imp_uk"))||(a=cb());n("imp_uk",a,365);D("imp_uk",a);return a},M=function(a){if(Oa)return sc();var b=o("imp_sk"),c=o("imp_sb"),d;a:{try{if("object"===typeof IMP_HL&&"function"==typeof IMP_HL.session_persist){d=IMP_HL.session_persist();
break a}}catch(e){}d=!1}if(d)c?b=c:(c=b=cb(),a&&(tc(b),uc(E())));else if(!b||!c)c=b=cb(),a&&(tc(b),uc(E()));n("imp_sk",b);n("imp_sb",c,vc()/24);return b},wc=function(){n("imp_int",Math.round((new Date).getTime()/1E3),30)},xc=function(a){return btoa(encodeURIComponent(a).replace(/%([0-9A-F]{2})/g,function(a,c){return String.fromCharCode("0x"+c)}))},cd=function(a){return decodeURIComponent(atob(a).split("").map(function(a){return"%"+("00"+a.charCodeAt(0).toString(16)).slice(-2)}).join(""))},z=function(a,
b){var c="";try{if("object"===typeof localStorage&&"function"===typeof localStorage.getItem&&(c=localStorage.getItem(a),b))try{c=cd(c)}catch(d){}}catch(e){}return c},D=function(a,b,c){try{if("object"===typeof localStorage&&"function"===typeof localStorage.setItem){if(c)try{b=xc(b.toString())}catch(d){}localStorage.setItem(a,b.toString())}}catch(e){}},y=function(a){try{"object"===typeof localStorage&&"function"===typeof localStorage.setItem&&localStorage.removeItem(a)}catch(b){}},yc=function(a){for(var b=
a.split("/"),c=!1,d=a=0,e=1,j=0,g=1,f=1,h=1,f=0,r=!0,k=0,i=!1,m=!1,p=0,l=0,K="",u=0,n=0,q=0;q<b.length;q++){n++;if(100<n)break;currEventList=b[q].toString().split("|");if(0<currEventList.length){g=currEventList[0];if("scroll"==g)if(c)a++,d++,1<currEventList.length&&(g=currEventList[1].split("-"),1<g.length&&(f=g[0],g=g[1],f>e&&(e=f,j=Math.round(100*e/g),i=!0),f>h?(r||k++,r=!0):f<h&&(r&&k++,r=!1),1==f&&(m=!0),h=f,f=Math.round(100*h/g)));else{c=!0;continue}else if("click"==g||"change"==g||"copy"==g||
"paste"==g)"click"==g&&p++,d++;4<currEventList.length&&(l=Math.round(currEventList[4]/1E3));1<currEventList.length&&0==currEventList[1].toString().indexOf("IMG")&&u++;2<currEventList.length&&"INPUT"==currEventList[1]&&(K=currEventList[2])}}b={};if(!Ba)b.scrollCount=a,b.activityCount=d,b.scrollLatest=h,b.scrollLatestPerc=f,b.scrollDirChangeCount=k,b.scrollHasScrolled=i,b.scrollBackToTop=m,b.scrollMax=e,b.scrollMaxPerc=j;b.lastActivitySec=l;b.imageClickCount=u;b.lastInputField=K;a=0;for(x in b)if(a++,
20<a)break;return b},sa=function(a){try{a||(a=2);var b=z("imp_pt"),c=z("imp_lpt",!0),d=z("imp_plpt",!0),e=z("imp_lov"),j=z("imp_clpt",!0),g=z("imp_cov");if(b||c||2!=a)if(IMP.appendSiteProp("webevent",a),b&&IMP.appendSiteProp("webdata",b),c)if(a={},zc()){a.webdatalog=c;a.activity={};a.activity=yc(c);a.path=d;if(e)a.pattoverflow="1";if(j)a.content=j;if(g)a.contoverflow="1";if(1500<JSON.stringify(a).toString().length)a.webdatalog="",a.sumoverflow="1";IMP.appendSiteProp("webdatalog",JSON.stringify(a))}else IMP.appendSiteProp("webdatalog",
c),e&&IMP.appendSiteProp("implog","pattoverflow")}catch(f){}},db=function(){try{y("imp_pt"),y("imp_lpt"),y("imp_plpt"),y("imp_lov"),y("imp_clpt"),y(imp_longpattern_conenten_overflow_key),fa=H=C=""}catch(a){}},Hb=function(a,b){var c=o("imp_uk");c||(c="unknown");var d=o("imp_sk");d||(d="unknown");c!=a&&(IMP.appendSiteProp("imptransferuk",c),n("imp_uk",a,365));d!=b&&(IMP.appendSiteProp("imptransfersk",d),n("imp_sk",b),n("imp_sb",b,vc()/24))},Ac=function(){var a=o("imp_curr_selection");return a?a:"1"},
cb=function(){for(var a=[],b=0;32>b;b++)a[b]="0123456789ABCDEF".substr(Math.floor(16*Math.random()),1);a[12]="4";a[16]="0123456789ABCDEF".substr(a[16]&3|8,1);return a.join("")},eb=function(){var a="",b;a:{try{if("object"===typeof IMP_HL&&"function"==typeof IMP_HL.allowed_propenc){b=IMP_HL.allowed_propenc();break a}}catch(c){}b=""}var d=!1;for(keyIndex=0;keyIndex<ka;keyIndex++){var e;a:{e=ja[keyIndex];if(b){var j=b.split(",");for(propIndex=0;propIndex<j.length;propIndex++)if(e==j[propIndex]){e=!0;
break a}}e=!1}e?(a+="&KeyValue="+t(ja[keyIndex])+":"+t(xc(Ga[keyIndex])),d=!0):a+="&KeyValue="+t(ja[keyIndex])+":"+t(Ga[keyIndex])}d&&(a+="&KeyValue="+t("impenc")+":"+t(b));return a},X=function(a,b){var c;c="siteid="+ha+"&url="+t(w)+"&urlref="+t(R)+"&userkey="+t(E())+"&impsess="+t(M(!1))+"&rand="+Math.random();b&&Bc();c+=eb();W&&(c+="&ispriority=1");return G+c},L=function(a,b){var c;c="siteid="+ha+"&url="+t("https://impevent")+"&urlref="+t(w)+"&userkey="+t(E())+"&impsess="+t(M(!1))+"&rand="+Math.random();
b&&Bc();c+=eb();W&&(c+="&ispriority=1");return G+c},dd=function(){var a="siteid="+ha+"&url="+t(w)+"&userkey="+t(E())+"&impsess="+t(M(!1))+"&rand="+Math.random();W&&(a+="&ispriority=1");return G+a},ed=function(){var a="siteid="+ha+"&url="+t(w)+"&urlref="+t(R)+"&userkey="+t(E())+"&impsess="+t(M(!1))+"&rand="+Math.random();return a+=eb()},fd=function(a,b,c){b="InteractionLogId="+t(b)+"&PhoneNumber="+t(c)+"&uk="+t(E())+"&rand="+Math.random();return a+"?"+b},s=function(a){return isNaN(a)?0:a},S=function(a){return a?
a:!1},gd=function(a,b){var c;c=a;var d=a.lastIndexOf("/");-1<d&&(c=a.slice(d+1));return c?"-"==c.toString().substr(0,1)?"":-1<c.toString().indexOf("--")?"":a:ia(b)+"close.png"},ia=function(a){var b="",b=a.lastIndexOf("/");-1<b?b=a.substr(0,b+1):(b=G.lastIndexOf("/"),b=-1<b?G.substr(0,b+1):"");return b},Cc=function(a){var a=ia(a).toString(),a=a.replace("https://",""),a=a.replace("http://",""),b=a.indexOf("/");0<b&&(a=a.substr(0,b));return a},hd=function(a){if(oc)return!1;if(o("imp_sb")&&o("imp_rs"))return!0;
if(a){if(0<=a.toString().indexOf("##n9724##"))return!0;if(0<=a.toString().indexOf("##n3824##"))return n("imp_rs","1"),!0}return!1},Dc=function(a){try{"object"===typeof IMP_HL&&"function"==typeof IMP_HL.exist_handle_inithandler&&IMP_HL.exist_handle_inithandler()&&"function"==typeof IMP_HL.handle_inithandler&&IMP_HL.handle_inithandler(a)}catch(b){}},Ib=function(a,b,c,d,e,j){a||(a="1");b||(b="start");c||(c=E());d||(d="CoTV");e||(e="CS-5000-01-01");j||(j="sv");var g="0";try{g="object"===typeof IMP_HL?
"function"==typeof IMP_HL.exist_handle_runhandler?IMP_HL.exist_handle_runhandler()?"function"==typeof IMP_HL.handle_runhandler?IMP_HL.handle_runhandler(a,b,c,d,e,j):"-1":"-2":"-3":"-4"}catch(f){g="-5"}return g},Ec=function(a){try{"object"===typeof IMP_HL&&"function"==typeof IMP_HL.exist_appendLocalSiteProp&&IMP_HL.exist_appendLocalSiteProp()&&"function"==typeof IMP_HL.appendLocalSiteProp&&(result=IMP_HL.appendLocalSiteProp(a))}catch(b){}},Fc=function(){try{"object"===typeof IMP_HL&&"function"==typeof IMP_HL.exist_appendLocalSitePropPostLog&&
IMP_HL.exist_appendLocalSitePropPostLog()&&"function"==typeof IMP_HL.appendLocalSitePropPostLog&&(result=IMP_HL.appendLocalSitePropPostLog())}catch(a){}},zc=function(){try{if("object"===typeof IMP_HL&&"function"==typeof IMP_HL.allow_extended_datalog&&IMP_HL.allow_extended_datalog())return!0}catch(a){}return!1},Gc=function(){try{if("object"===typeof IMP_HL&&"function"==typeof IMP_HL.allow_protect&&IMP_HL.allow_protect())return!0}catch(a){}return!1},vc=function(){try{if("object"===typeof IMP_HL&&"function"==
typeof IMP_HL.session_length)return Math.round(IMP_HL.session_length())}catch(a){}return 2},Y=function(){try{if("object"===typeof IMP_HL&&"function"==typeof IMP_HL.block_loginiframe&&IMP_HL.block_loginiframe())return!0}catch(a){}return!1},Jb=function(){try{if("object"===typeof IMP_HL&&"function"==typeof IMP_HL.exist_handle_accepttel&&IMP_HL.exist_handle_accepttel()&&"function"==typeof IMP_HL.handle_accepttel)return!0}catch(a){}return!1},Kb=function(a){var b;a:{try{if("object"===typeof IMP_HL&&"function"===
typeof IMP_HL.exist_handle_focus&&IMP_HL.exist_handle_focus()&&"function"===typeof IMP_HL.handle_focus){b=!0;break a}}catch(c){}b=!1}if(b)try{IMP_HL.handle_focus(a)}catch(d){}},id=function(a,b){var c;a:{try{if("object"===typeof IMP_HL&&"function"===typeof IMP_HL.exist_handle_show&&IMP_HL.exist_handle_show()&&"function"===typeof IMP_HL.handle_show){c=!0;break a}}catch(d){}c=!1}if(c)try{IMP_HL.handle_show(a,b)}catch(e){}},jd=function(a){var b;a:{try{if("object"===typeof IMP_HL&&"function"===typeof IMP_HL.exist_handle_close&&
IMP_HL.exist_handle_close()&&"function"===typeof IMP_HL.handle_close){b=!0;break a}}catch(c){}b=!1}if(b)try{IMP_HL.handle_close(a)}catch(d){}},kd=function(a,b,c,d){var e;a:{try{if("object"===typeof IMP_HL&&"function"===typeof IMP_HL.exist_handle_acceptpuff&&IMP_HL.exist_handle_acceptpuff()&&"function"===typeof IMP_HL.handle_acceptpuff){e=!0;break a}}catch(j){}e=!1}if(e)try{IMP_HL.handle_acceptpuff(a,b,c,d)}catch(g){}},ld=function(a,b,c){if(Jb())try{wc(),IMP_HL.handle_accepttel(a,b,c)}catch(d){}},
md=function(a,b){var c;a:{try{if("object"===typeof IMP_HL&&"function"==typeof IMP_HL.exist_handle_acceptchat&&IMP_HL.exist_handle_acceptchat()&&"function"==typeof IMP_HL.handle_acceptchat){c=!0;break a}}catch(d){}c=!1}if(c)try{IMP_HL.handle_acceptchat(a,b)}catch(e){}},nd=function(a){a||(a="1");var b;a:{try{if("object"===typeof IMP_HL&&"function"==typeof IMP_HL.exist_handle_outcome&&IMP_HL.exist_handle_outcome()&&"function"==typeof IMP_HL.handle_outcome){b=!0;break a}}catch(c){}b=!1}if(b)try{var d=
o("imp_oc");d?d.toString()!=a.toString()&&(IMP_HL.handle_outcome(a.toString()),n("imp_oc",a.toString())):(IMP_HL.handle_outcome(a.toString()),n("imp_oc",a.toString()))}catch(e){}},od=function(a,b){var c;a:{try{if("object"===typeof IMP_HL&&"function"===typeof IMP_HL.exist_handle_showcontainer&&IMP_HL.exist_handle_showcontainer()&&"function"===typeof IMP_HL.handle_showcontainer){c=!0;break a}}catch(d){}c=!1}if(c)try{return IMP_HL.handle_showcontainer(a,b),!0}catch(e){}return!1},pd=function(a,b){var c;
a:{try{if("object"===typeof IMP_HL&&"function"===typeof IMP_HL.exist_handle_hidecontainer&&IMP_HL.exist_handle_hidecontainer()&&"function"===typeof IMP_HL.handle_hidecontainer){c=!0;break a}}catch(d){}c=!1}if(c)try{return IMP_HL.handle_hidecontainer(a,b),!0}catch(e){}return!1},qd=function(a,b,c){var d;a:{try{if("object"===typeof IMP_HL&&"function"===typeof IMP_HL.exist_handle_customized_close&&IMP_HL.exist_handle_customized_close()&&"function"===typeof IMP_HL.handle_customized_close){d=!0;break a}}catch(e){}d=
!1}if(d)try{IMP_HL.handle_customized_close(a,b,c)}catch(j){}},Hc=function(a,b,c,d,e){var j;a:{try{if("object"===typeof IMP_HL&&"function"===typeof IMP_HL.exist_handle_customized&&IMP_HL.exist_handle_customized()&&"function"===typeof IMP_HL.handle_customized){j=!0;break a}}catch(g){}j=!1}if(j)try{IMP_HL.handle_customized(a,b,c,d,e)}catch(f){}},rd=function(a,b,c,d,e,j){var g;a:{try{if("object"===typeof IMP_HL&&"function"===typeof IMP_HL.exist_handle_customized_number&&IMP_HL.exist_handle_customized_number()&&
"function"===typeof IMP_HL.handle_customized_number){g=!0;break a}}catch(f){}g=!1}if(g)try{IMP_HL.handle_customized_number(a,b,c,d,e,j)}catch(h){}},sd=function(a,b,c,d,e,j,g){var f;a:{try{if("object"===typeof IMP_HL&&"function"===typeof IMP_HL.exist_handle_customized_number_button&&IMP_HL.exist_handle_customized_number_button()&&"function"===typeof IMP_HL.handle_customized_number_button){f=!0;break a}}catch(h){}f=!1}if(f)try{IMP_HL.handle_customized_number_button(a,b,c,d,e,j,g)}catch(r){}},td=function(a,
b,c,d,e,j){var g;a:{try{if("object"===typeof IMP_HL&&"function"===typeof IMP_HL.exist_handle_customized_number_multi&&IMP_HL.exist_handle_customized_number_multi()&&"function"===typeof IMP_HL.handle_customized_number_multi){g=!0;break a}}catch(f){}g=!1}if(g)try{IMP_HL.handle_customized_number_multi(a,b,c,d,e,j)}catch(h){}},vd=function(a){if(0<=a.origin.indexOf(Cc(cc)))try{if(bc++,20>bc){var b=JSON.parse(a.data);if("1"==b.hasmessage){if(b.message)if("accepttel"==b.message){var c=b.number;c||(c="number");
var d="message",e=0;b.accepttag&&("0"==b.accepttag?(d=U[k[1]],e=Z[k[1]]):"1"==b.accepttag?(d=U[k[2]],e=Z[k[2]]):"2"==b.accepttag&&(d=U[k[3]],e=Z[k[3]]));ld(c,d,e)}else if("failedtel"==b.message){var j;a:{try{if("object"===typeof IMP_HL&&"function"===typeof IMP_HL.exist_handle_failedtel&&IMP_HL.exist_handle_failedtel()&&"function"===typeof IMP_HL.handle_failedtel){j=!0;break a}}catch(g){}j=!1}if(j)try{IMP_HL.handle_failedtel()}catch(f){}}else"acceptchat"==b.message?md(b.code,b.chatoptions):(IMP.appendSiteProp("impevent",
b.message),N(L()))}else if("1"==b.haslogmessage)b.logkey&&b.logvalue&&(IMP.appendSiteProp(b.logkey,b.logvalue),IMP.trackEventInteract());else if("1"==b.hasclosemessage)b.closetag?"0"==b.closetag?IMP.hide_IMPiframe(1,v[k[1]],4):"1"==b.closetag?IMP.hide_IMPiframe(2,v[k[2]],4):("2"!=b.closetag&&(IMP.hide_IMPiframe(1,v[k[1]],4),IMP.hide_IMPiframe(2,v[k[2]],4)),IMP.hide_IMPiframe(3,v[k[3]],4)):(IMP.hide_IMPiframe(1,v[k[1]],4),IMP.hide_IMPiframe(2,v[k[2]],4),IMP.hide_IMPiframe(3,v[k[3]],4));else if("1"==
b.hasstartwinmessage)b.startwinurl&&b.startwindirective&&(b.startwinposition&&b.startwinruletype?ud(b.startwinurl,b.startwindirective,b.startwinruletype):Lb(b.startwinurl,b.startwindirective));else if("1"==b.hassizemessage){d=b.width;e=b.heigth;c="ni_imp_prim";if(b.containerid)c=b.containerid;IMP.appendSiteProp("impsize",c+"_"+d+"_"+e);IMP.trackAppendLog();Ic(c,d,e);Ic(c+"_frame",d,e)}else if("1"==b.hasrunhandler){var h=a.source,c=0,r=b.handlerid;r||(r="1");var l=b.startstop;l||(l="start");c=Ib(b.handlerid,
b.startstop,b.sessionid,b.mode,b.csid,b.language);try{h.postMessage({hasrunhandlerresult:"1",handlerresult:c.toString()},"*")}catch(i){}0==c&&("start"==l?n("imp_lh",r):n("imp_lh",""))}else if("1"==b.haschangepage){var m=b.changepage;setTimeout(function(){try{window.location.href=m}catch(a){}},50)}else"1"==b.hascustomizedclose&&(Fb=!0)}}catch(p){}},Mb=function(){if(!ec)try{var a=window.addEventListener?"addEventListener":"attachEvent";(0,window[a])("attachEvent"==a?"onmessage":"message",vd,!1);ec=
!0}catch(b){}return!0},Jc=function(a){var b=[],b=document.getElementsByTagName("title");if(0<b.length)return b[0].innerHTML;for(var b=document.getElementsByTagName("meta"),c=0;c<b.length;c++){if(b[c].getAttribute("property")==a||b[c].getAttribute("name")==a)return b[c].content;if(25<=c)break}return""},Mc=function(a,b,c){ab||(ab=!0,document.body.addEventListener("mouseenter",function(){qa=!0;bb||(bb=!0,document.body.addEventListener("mouseleave",function(){qa=!1}))}));if(!mc)mc=!0,window.onbeforeunload=
function(){if(!(!0==pa||qa))if(pa=!0,document.getElementById(k[a]))return Kc(a,8,0),c&&Lc(),b||(b=" "),b}},Nb=function(a,b,c,d){if(document.addEventListener){var e=10,j=30;if(b)if(-1!=b.indexOf("{"))try{var g={},g=JSON.parse(b),e=s(g.minX),j=s(g.maxY)}catch(f){}else b=b.split(","),1<b.length&&(e=s(b[0]),j=s(b[1]));lc||(lc=!0,document.body.addEventListener("mousemove",function(a){$a=a.clientX;kc=a.clientY}));ab||(ab=!0,document.body.addEventListener("mouseenter",function(){qa=!0;bb||(bb=!0,document.body.addEventListener("mouseleave",
function(){qa=!1;if(!(!0==pa||$a<e||kc>j))if(pa=!0,c){var b=k[a];ca[b]?v[b]&&IMP.trackDisplay(v[b],8,0):document.getElementById(b)&&(Kc(a,8,0),d&&Lc())}else IMP.appendSiteProp("impevent","zoneleave"),IMP.trackEventInteract()}))}))}},wd=function(a,b){b||(b="15");imprushdialogueany=!0;imprushdialogueparams[a]=b},Kc=function(a,b,c){var d=k[a];da[d]&&(clearTimeout(da[d]),ta(d,lb[a],mb[a],Ja[a],Ka[a],nb[a],v[d],V[a],La[a],b,c))},yd=function(a){if(!A()&&!yb){a=a.split(",");oa=s(a[0]);Wa=s(a[1]);if(2>oa||
60<oa)oa=15;49<Wa&&(Wa=49);xd()}},xd=function(){yb&&Q&&(clearInterval(Q),Q=0);zb=0;0<oa&&(yb=!0,Q=setInterval(function(){zb++;zb>=Wa&&Q&&(clearInterval(Q),Q=0);Xa=Math.round(((new Date).getTime()-Math.round(Eb))/1E3);imprushdialogueany&&(imprushdialogueparams[1]&&Ob(1,imprushdialogueparams[1])&&(imprushdialogueparams[1]=""),imprushdialogueparams[2]&&Ob(2,imprushdialogueparams[2])&&(imprushdialogueparams[2]=""),imprushdialogueparams[3]&&Ob(3,imprushdialogueparams[3])&&(imprushdialogueparams[3]=""))},
1E3*oa))},Ob=function(a,b){var c=s(b);if(0<c&&(15>c&&(c=15),Xa>=c)){var c=Xa,d=k[a];da[d]&&(clearTimeout(da[d]),clearInterval(Q),ta(d,lb[a],mb[a],Ja[a],Ka[a],nb[a],v[d],V[a],La[a],5,c));return!0}return!1},Qb=function(){Pb();fa=H=C="";y("imp_pt");y("imp_lpt");y("imp_plpt");y("imp_lov");y("imp_clpt");y("imp_cov")},Rb=function(){Xa=0;Math.round((new Date).getTime()/1E3);Eb=(new Date).getTime();fa=H=C="";Bb=Cb=Ab=!1;$a=$a=0;qa=!0;Ca()},zd=function(a){if(!A()&&(a=a.split(","),!(5>a.length))){Qa=s(a[3]);
Ra=s(a[4]);if(1==Qa&&!hc)hc=!0,window.onbeforeunload=function(){if(!1==Cb&&1==Qa)try{C&&D("imp_pt",C);sa(1);IMP.appendSiteProp("impunload","1");var a=X();if(B()&&"object"===typeof navigator&&"function"===typeof navigator.sendBeacon){try{navigator.sendBeacon(a,"test")}catch(c){}IMP.clearSiteProp()}Pb();Cb=!0}catch(d){}};if(1==Ra&&!gc)gc=!0,window.onfocus=function(){if(!0==Za)IMP.appendSiteProp("implogtype",3),Db++,IMP.appendSiteProp("impfocus","1"),IMP.trackFocusInteract(),Za=!1;else if(!0==Ab&&!1==
pa&&!1==Bb&&1==Ra&&5>=Db){var a=Math.round(((new Date).getTime()-jc)/1E3),c=o("imp_st");if(c&&(c>Pa||120<=a))c>Pa?IMP.appendSiteProp("implogtype",4):IMP.appendSiteProp("implogtype",5),Db++,IMP.appendSiteProp("impfocus","1"),IMP.trackFocusInteract()}},window.onblur=function(){Ab=!0;jc=(new Date).getTime();if(1==Qa&&!1==pa&&1==Ra){var a;a:{try{if("object"===typeof IMP_HL&&"function"===typeof IMP_HL.exist_handle_blur&&IMP_HL.exist_handle_blur()&&"function"===typeof IMP_HL.handle_blur){a=!0;break a}}catch(c){}a=
!1}if(a)try{IMP_HL.handle_blur()}catch(d){}C&&D("imp_pt",C);sa(1);IMP.appendSiteProp("impblur","1");N(X());Pb()}}}},Ca=function(){Va||1!=vb||(0<T&&(xb=setTimeout(function(){try{Xb()&&(Va=!1,fc++,fc<=Ta?3==Sa?(IMP.appendSiteProp("event",Ua),IMP.appendSiteProp("implogtype",9),IMP.trackTimeInteract()):2==Sa?!0==ea?(IMP.appendSiteProp("event",Ua),IMP.appendSiteProp("implogtype",10),IMP.trackTimeInteract()):Ca():1==Sa?wb=!0:(IMP.appendSiteProp("imptimeappend","1"),IMP.trackAppendLog(!0),Ca()):T=0)}catch(a){}},
1E3*T)),Va=!0,ea=wb=!1)},Pb=function(){xb&&clearTimeout(xb);Va=!1},Nc=function(a,b,c,d,e,j,g,f,h,r,k,i,m,l,n,K,u,o,q,s,v,t,w,y,z,E,A,C,D,B,F,H,I,J,L,S,U,V,M,N,G,O){clearTimeout(da[b]);clearTimeout(Zb[b]);clearTimeout($c[b]);clearTimeout(P[b].close);clearTimeout(P[b]["switch"]);clearTimeout(P[b].accept);clearTimeout(P[b].delaay);clearTimeout(P[b].decline);clearTimeout(pb[b]);clearTimeout($b[b]);clearTimeout(ac[b]);(r=document.getElementById(b))&&r.parentNode.removeChild(r);r="div";M&&-1==N.indexOf("<div>")&&
(r="span");r=document.createElement(r);r.id=b;l=Ad(r,m,l,n,K,u,o,q);if(!l){if(m)return G||IMP.trackError(h,7,m),!0;m=document.getElementsByTagName("body")[0];q?m.insertBefore(r,m.firstChild):m.appendChild(r)}r=document.getElementById(b);Bd(a,r,d,e,j,g,f,l,i);Cd(a,b,r,c,d,e,h,k,B,F,H,I,j,J,S,U,V,M,N,O);Yb[b]=r.style.display;r.style.display="none";0<s?da[b]=setTimeout(function(){ta(b,v,t,w,y,z,h,L,S,0,s)},1E3*s):ta(b,v,t,w,y,z,h,L,S,0,0)},Ic=function(a,b,c){if(a=document.getElementById(a)){if(b&&-1<
b.indexOf("px"))a.style.width=b;if(c&&-1<c.indexOf("px"))a.style.height=c}},Da=function(a,b,c,d){if(0<c){var e=document.getElementById(a+"_"+b);if(e&&0<=Math.round(d)){e.style.display="none";var j=Math.round(c)-Math.round(d);0>j&&(j=0);P[a][b]=setTimeout(function(){e.style.display="block";e.style.opacity=0;setTimeout(function(){e.style.transition="all "+j+"s";e.style.transitionTimingFunction="ease-in";setTimeout(function(){e.style.opacity=1},17)},17)},1E3*d)}}},$=function(a,b){a.style.display=b;return!0},
ta=function(a,b,c,d,e,j,g,f,h,r,l){var i=document.getElementById(a),m=document.getElementById(a+"_frame");document.getElementById(a+"_close");if(i&&"none"==i.style.display&&(a==k[1]?ob?"2"!=Ac():1:a==k[2]?ob?"1"!=Ac():1:1)){g?IMP.trackDisplay(g,r,l):v[a]&&IMP.trackDisplay(v[a],r,l);if(ca[a])return!0;Ha[a]=!1;g="block";"inline"==Yb[a]&&(g="inline");h=!1;if(Oc()){var p,n,K,u,o,q="all "+c+"s";if(0==b)h=$(i,g);else if(1==b)p=i.style.width,u=i.style.height,p&&u&&0>p.toString().indexOf("%")&&0>u.toString().indexOf("%")?
(i.style.width="0px",m.style.width="0px",i.style.height="0px",m.style.height="0px",i.style.display=g,setTimeout(function(){i.style.transition=q;m.style.transition="inherit";i.style.transitionTimingFunction="ease";m.style.transitionTimingFunction="inherit";setTimeout(function(){i.style.width=p;m.style.width=p;i.style.height=u;m.style.height=u},17)},17)):h=$(i,g);else if(2==b)i.style.opacity=0,i.style.display=g,setTimeout(function(){i.style.transition=q;m.style.transition="inherit";i.style.transitionTimingFunction=
"ease";m.style.transitionTimingFunction="inherit";setTimeout(function(){i.style.opacity=1},17)},17);else if(3==b)(p=i.style.width)&&0>p.toString().indexOf("%")?(i.style.opacity=0,i.style.width="0px",m.style.width="0px",i.style.display=g,setTimeout(function(){i.style.transition=q;m.style.transition="inherit";i.style.transitionTimingFunction="ease";m.style.transitionTimingFunction="inherit";setTimeout(function(){i.style.opacity=1;i.style.width=p;m.style.width=p},17)},17)):h=$(i,g);else if(4==b)p=i.style.width,
n=i.style.left,r=parseInt(n,10)+parseInt(p,10)/2+"px",K=i.style.right,l=parseInt(K,10)+parseInt(p,10)/2+"px",p&&0>p.toString().indexOf("%")?(i.style.opacity=0,i.style.width="0px",m.style.width="0px",i.style.display=g,n?(i.style.left=r,setTimeout(function(){i.style.transition=q;m.style.transition="inherit";i.style.transitionTimingFunction="ease";m.style.transitionTimingFunction="inherit";setTimeout(function(){i.style.opacity=1;i.style.width=p;m.style.width=p;i.style.left=n},17)},17)):K?(i.style.right=
l,setTimeout(function(){i.style.transition=q;m.style.transition="inherit";i.style.transitionTimingFunction="ease";m.style.transitionTimingFunction="inherit";setTimeout(function(){i.style.opacity=1;i.style.width=p;m.style.width=p;i.style.right=K},17)},17)):setTimeout(function(){i.style.transition=q;m.style.transition="inherit";i.style.transitionTimingFunction="ease";m.style.transitionTimingFunction="inherit";setTimeout(function(){i.style.opacity=1;i.style.width=p;m.style.width=p},17)},17)):h=$(i,g);
else if(5==b)if(p=i.style.width,u=i.style.height,o=i.style.top,originalBottom=i.style.bottom,n=i.style.left,K=i.style.right,p&&u&&0>p.toString().indexOf("%")&&0>u.toString().indexOf("%")){i.style.width="0px";m.style.width="0px";i.style.height="0px";m.style.height="0px";i.style.opacity=0;i.style.display=g;if(o)i.style.top="0px";else if(originalBottom)i.style.bottom="0px";if(n)i.style.left="0px";else if(K)i.style.right="0px";setTimeout(function(){i.style.transition=q;m.style.transition="inherit";i.style.transitionTimingFunction=
"ease";m.style.transitionTimingFunction="inherit";setTimeout(function(){i.style.opacity=1;i.style.width=p;m.style.width=p;i.style.height=u;m.style.height=u;if(o)i.style.top=o;else if(originalBottom)i.style.bottom=originalBottom;if(n)i.style.left=n;else if(K)i.style.right=K},17)},17)}else h=$(i,g);else if(6==b)if(p=i.style.width,n=i.style.left,K=i.style.right,p&&0>p.toString().indexOf("%")){i.style.opacity=0;i.style.width="0px";m.style.width="0px";i.style.display=g;if(n)i.style.left="0px";else if(K)i.style.right=
"0px";setTimeout(function(){i.style.transition=q;m.style.transition="inherit";i.style.transitionTimingFunction="ease";m.style.transitionTimingFunction="inherit";setTimeout(function(){i.style.opacity=1;i.style.width=p;m.style.width=p;if(n)i.style.left=n;else if(K)i.style.right=K},17)},17)}else h=$(i,g);else if(7==b||8==b)if(u=i.style.height,o=i.style.top,originalBottom=i.style.bottom,u&&0>u.toString().indexOf("%")){i.style.height="0px";m.style.height="0px";i.style.opacity=0;i.style.display=g;if(o)i.style.top=
"0px";else if(originalBottom)i.style.bottom="0px";setTimeout(function(){i.style.transition=q;m.style.transition="inherit";i.style.transitionTimingFunction="ease";m.style.transitionTimingFunction="inherit";setTimeout(function(){i.style.opacity=1;i.style.height=u;m.style.height=u;if(o)i.style.top=o;else if(originalBottom)i.style.bottom=originalBottom},17)},17)}else h=$(i,g);else od(a,b)||(h=$(i,g));if(0==b||!h)Da(a,"close",c,f),Da(a,"switch",c,f),Da(a,"accept",c,f),Da(a,"delay",c,f),Da(a,"decline",
c,f);i.addEventListener("mouseenter",Pc);Zb[a]=setTimeout(function(){0<j&&(pb[a]=setTimeout(function(){Qc(a,d,e)},1E3*j))},1E3*c)}else i.style.display="block";ca[a]||id(U[a],Z[a]);Jb()&&Mb()}},Pc=function(a){Ha[a.target.id]=!0},Oc=function(){return"opacity"in document.body.style&&"transition"in document.body.style?!0:!1},Qc=function(a,b,c){var d=document.getElementById(a);d&&(d.removeEventListener("mouseenter",Pc),Ha[a]?(Ha[a]=!1,pb[a]=setTimeout(function(){Qc(a,b,c)},12E5)):(fb(a,b,c,!0),$b[a]=setTimeout(function(){if(la[a]){var b=
Ia[a],c=-1;l[b][2].LogEvent&&(c=2);l[b][3].LogEvent&&(c=3);l[b][4].LogEvent&&(c=4);0<c&&l[b][c].LogEvent&&(IMP.appendSiteProp("impevent",l[b][c].LogEvent),IMP.appendSiteProp("impeventlogid",v[a]),IMP.appendSiteProp("impeventmessid",ma[b]),W=!0,O=1E4,l[b][c].KeepUrl?IMP.trackSwitchEventInteract():IMP.trackEventInteract(),O=3E3);la[a]=!1}(b=document.getElementById(a))&&b.parentNode.removeChild(b)},1E3*Math.round(c))))},Dd=function(){var a=document.getElementById("imp_over");a&&a.parentNode.removeChild(a)},
Lc=function(){var a=document.createElement("div");a.id="imp_over";a.name="imp_over";a.style="position: absolute; top: 0%; left: 0%; width: 100%; height: 100%; background-color: black; z-index:1001; -moz-opacity: 0.2; opacity:.20; filter: alpha(opacity=20);";var b=document.getElementsByTagName("body")[0];b&&b.appendChild(a)},fb=function(a,b,c){Dd();Bb=!1;var d,e,j,g,f=document.getElementById(a),h=document.getElementById(a+"_frame"),r="all "+c+"s";if(Oc()){if(f)if(0==b)f.style.display="none";else if(1==
b)a=f.style.width,originalHeight=f.style.height,a&&originalHeight?setTimeout(function(){f.style.transition=r;h.style.transition="inherit";f.style.transitionTimingFunction="ease-in";h.style.transitionTimingFunction="inherit";setTimeout(function(){f.style.width="0px";f.style.height="0px";h.style.width="0px";h.style.height="0px"},17)},17):f.style.display="none";else if(2==b)setTimeout(function(){f.style.transition=r;h.style.transition="inherit";f.style.transitionTimingFunction="ease-in";h.style.transitionTimingFunction=
"inherit";setTimeout(function(){f.style.opacity=0},17)},17);else if(3==b)(a=f.style.width)?setTimeout(function(){f.style.transition=r;h.style.transition="inherit";f.style.transitionTimingFunction="ease-in";h.style.transitionTimingFunction="inherit";setTimeout(function(){f.style.opacity=0;f.style.width="0px";h.style.width="0px"},17)},17):f.style.display="none";else if(4==b)a=f.style.width,d=f.style.left,e=parseInt(d,10)+parseInt(a,10)/2+"px",j=f.style.right,g=parseInt(j,10)+parseInt(a,10)/2+"px",a?
d?setTimeout(function(){f.style.transition=r;h.style.transition="inherit";f.style.transitionTimingFunction="ease-in";h.style.transitionTimingFunction="inherit";setTimeout(function(){f.style.opacity=0;f.style.width="0px";h.style.width="0px";f.style.left=e},17)},17):j?setTimeout(function(){f.style.transition=r;h.style.transition="inherit";f.style.transitionTimingFunction="ease-in";h.style.transitionTimingFunction="inherit";setTimeout(function(){f.style.opacity=0;f.style.width="0px";h.style.width="0px";
f.style.right=g},17)},17):f.style.display="none":f.style.display="none";else if(5==b)a=f.style.width,originalHeight=f.style.height,originalBottom=f.style.bottom,originalTop=f.style.top,d=f.style.left,j=f.style.right,a&&originalHeight?setTimeout(function(){f.style.transition=r;h.style.transition="inherit";f.style.transitionTimingFunction="ease-in";h.style.transitionTimingFunction="inherit";setTimeout(function(){f.style.opacity=0;f.style.width="0px";h.style.width="0px";f.style.height="0px";h.style.height=
"0px";if(originalTop)if(f.style.top="0px",d)f.style.left="0px";else{if(j)f.style.right="0px"}else if(originalBottom)if(f.style.bottom="0px",d)f.style.left="0px";else if(j)f.style.right="0px"},17)},17):f.style.display="none";else if(6==b)a=f.style.width,d=f.style.left,j=f.style.right,a?setTimeout(function(){f.style.transition=r;h.style.transition="inherit";f.style.transitionTimingFunction="ease-in";h.style.transitionTimingFunction="inherit";setTimeout(function(){f.style.opacity=0;f.style.width="0px";
h.style.width="0px";if(d)f.style.left="0px";else if(j)f.style.right="0px"},17)},17):f.style.display="none";else if(7==b||8==b)originalHeight=f.style.height,originalTop=f.style.top,originalBottom=f.style.bottom,originalHeight?setTimeout(function(){f.style.transition=r;h.style.transition="inherit";f.style.transitionTimingFunction="ease-in";h.style.transitionTimingFunction="inherit";setTimeout(function(){f.style.opacity=0;f.style.height="0px";h.style.height="0px";if(originalTop)f.style.top="0px";else if(originalBottom)f.style.bottom=
"0px"},17)},17):f.style.display="none";else if(!pd(a,b))f.style.display="none"}else f.style.display="none"},Ad=function(a,b,c,d,e,j,g,f){var h,r=!1;if(b){if(-1<b.toString().indexOf(".")){var k=b.toString().replace(".",""),r="dummy";if(-1<b.toString().indexOf("+")){var i=b.toString().split("+"),k=i[0].toString().replace(".","");0<i.length&&i[1]&&(r=i[1])}if(k=document.getElementsByClassName(k))if(-1<b.toString().indexOf("+"))for(b=0;b<k.length&&!(k[b].innerText&&-1<k[b].innerText.toLowerCase().indexOf(r.toLowerCase())&&
(h=k[b]),10<b);b++);else k[0]&&(h=k[0])}else h=document.getElementById(b);if(h){if("function"===typeof h.getBoundingClientRect&&(b=h.getBoundingClientRect()))na[a]=Math.round(b.left),Math.round(b.top);if(c){if(d)h.style.height=e+"px";if(j)h.style.width=g+"px";h.innerHTML="";h.appendChild(a)}else{if(d)h.style.height=e+"px";if(j)h.style.width=g+"px";f?h.insertBefore(a,h.firstChild):h.appendChild(a)}r=!0}else r=!1}else r=!1;return r},Bd=function(a,b,c,d,e,j,g,f,h){var k="absolute";0<=e.indexOf("fixed")&&
(k="fixed");f&&(k="relative");f="absolute";0<=e.indexOf("relative")&&(f="relative");var l="left";0<=e.indexOf("right")&&(l="right");var i="top";0<=e.indexOf("bottom")&&(i="bottom");var m=g+"px",p=j+"px",n="0px",o="0px",u=c+"px",s=d+"px",q=0;0<=e.indexOf("fullwidth")&&0<=e.indexOf("fullheight")?(o=n=p=m="0px",u=s="100%"):0<=e.indexOf("fullwidth")?(m="0px",p=j+"px",o=n="0px",u="100%"):0<=e.indexOf("fullheight")?(m=g+"px",o=n=p="0px",s="100%"):0<=e.indexOf("center")?(p=m="50%",n="-"+c/2+"px",o="-"+d/
2+"px"):0<=e.indexOf("centric")?(m="50%",p=j+"px",n="-"+c/2+"px",o="0px"):0<=e.indexOf("placeholderfixedrightcent")?(k="fixed",q=Math.round(window.innerWidth)-Math.round(na[b])+Math.round(g),m=q.toString()+"px",p="50%",o="-"+d/2+"px"):0<=e.indexOf("placeholderfixedleftcent")?(k="fixed",q=Math.round(na[b])+Math.round(g),m=q.toString()+"px",p="50%",o="-"+d/2+"px"):"relative"==f&&(m="50%",p=j+"px",n=0>c/2-g?g-c/2+"px":"-"+(c/2-g)+"px",o="0px");h||(h="top"==i&&"right"==l?"position:"+k+"; right: "+m+"; margin-right: "+
n+"; width: "+u+"; top: "+p+"; margin-top: "+o+"; height: "+s+";":"bottom"==i&&"right"==l?"position:"+k+"; right: "+m+"; margin-right: "+n+"; width: "+u+";bottom: "+p+"; margin-bottom: "+o+"; height: "+s+";":"bottom"==i&&"left"==l?"position:"+k+"; left: "+m+"; margin-left: "+n+"; width: "+u+"; bottom: "+p+"; margin-bottom: "+o+"; height: "+s+";":"position:"+k+"; left: "+m+"; margin-left: "+n+"; width: "+u+"; top: "+p+"; margin-top: "+o+"; height: "+s+";");0>h.toString().search(/background/i)&&(h+=
" background: transparent;");0>h.toString().search(/z-index/i)&&(1==a?h+=" z-index:9999;":2==a&&(h+=" z-index:9998;"));b.style.cssText=h},Cd=function(a,b,c,d,e,j,g,f,h,k,l,i,m,n,o,s,u,v,q,t){e="";if(v){e+=q;if(-1<d.indexOf(".js")){q=document.createElement("script");q.type="text/javascript";q.src=d;q.setAttribute("data-imptype",b);j=b+"_script";if(!document.getElementById(j))q.id=j;document.getElementsByTagName("head")[0].appendChild(q);aa=b}if(t&&-1<t.indexOf(".css"))q=document.createElement("link"),
q.rel="stylesheet",q.type="text/css",q.media="all",q.href=t,document.getElementsByTagName("head")[0].appendChild(q)}else j=c.style.width,t=c.style.height,q="",j&&(q="width: "+j+"; "),j="",t&&(j="height: "+t+"; "),e+='<iframe id="'+(b+"_frame")+'"  src="'+d+'"  title="'+b+'"  scrolling="no"  frameborder="no"  style="background: transparent; '+j+q+'"  ALLOWTRANSPARENCY="true"></iframe>';if(!v||-1<d.indexOf(".js"))n?e+=Ea(a,b,c,n,f,"close",u,u,"IMP.hide_IMPiframe",g,4):Mb();h&&h.ImageUrl&&h.PlacementStyle&&
(e+=Ea(a,b,c,h.ImageUrl,h.PlacementStyle,"switch",h.ButtonText,h.ButtonText,"IMP.trackButtonEvent",g,1));k&&k.ImageUrl&&k.PlacementStyle&&(e+=Ea(a,b,c,k.ImageUrl,k.PlacementStyle,"accept",k.ButtonText,k.ButtonText,"IMP.trackButtonEvent",g,2));l&&l.ImageUrl&&l.PlacementStyle&&(e+=Ea(a,b,c,l.ImageUrl,l.PlacementStyle,"delay",l.ButtonText,l.ButtonText,"IMP.trackButtonEvent",g,3));i&&i.ImageUrl&&i.PlacementStyle&&(e+=Ea(a,b,c,i.ImageUrl,i.PlacementStyle,"decline",i.ButtonText,i.ButtonText,"IMP.trackButtonEvent",
g,4));o&&!v&&(a="",s&&(a+='<div style="'+s+'"></div>'),e+=a);c.innerHTML+=e},Ea=function(a,b,c,d,e,j,g,f,h,k,l){c="";e&&(j=b+"_"+j,a=h+"("+a+","+k+","+l+")",b=g.split("|"),1<b.length?(d=b[0],g=b[1],f=b[0],2<b.length&&(f=b[2]),c+='<div style="'+e+'" class="'+f+'" title="'+d+'" alt="" id="'+j+'" onclick="'+a+'">'+g+"</div>"):c+='<div style="'+e+'"><img id="'+j+'" class="'+f+'" title="'+g+'" src="'+d+'" alt="" id="'+j+'" onclick="'+a+'"></div>');return c},Sc=function(){var a;if("object"===typeof JSON&&
"function"===typeof JSON.stringify){if(a=Rc(1))Sb(1,k[1],a),I[1]=a,W=!0;if(a=Rc(2))Sb(2,k[2],a),I[2]=a,W=!0}},Rc=function(a){var b="";try{"object"===typeof JSON&&"function"===typeof JSON.stringify&&(b=z("imp_mess_"+k[a]))&&(b=JSON.parse(b))}catch(c){b=""}return b},gb=function(a,b){if((1==a||2==a)&&I[a]){if(z("imp_mess_"+b)){y("imp_mess_"+b);var c=document.getElementById(b);c&&c.parentNode.removeChild(c)}I[a]=""}},Tc=function(a,b){if(1==a||2==a)if(I[a]&&(I[a]=""),z("imp_mess_"+b)){y("imp_mess_"+b);
var c=document.getElementById(b);c&&c.parentNode.removeChild(c)}},hb=function(a,b){(1==a||2==a)&&I[a]&&S(I[a].isRepeatState)&&gb(a,b)},Tb=function(a,b,c,d){if((3==d||4==d||5==d)&&0!=ma[a]&&ma[a]==c.InteractionMessageId)if((d=document.getElementById(b))&&"none"!=d.style.display){IMP.trackDisplay(c.InteractionLogId,13,0);v[b]=c.InteractionLogId;return}if((1==a||2==a)&&I[a]){if(I[a].InteractionMessageId&&c.InteractionMessageId==I[a].InteractionMessageId)return!0;gb(a,b)}d=S(c.IsRepeatState);(1==a||2==
a)&&d&&"object"===typeof JSON&&"function"===typeof JSON.stringify&&D("imp_mess_"+b,JSON.stringify(c));return Sb(a,b,c)},Sb=function(a,b,c){if(!c)return!0;try{var d;if(d=!0==A()){var e;a:{try{if("object"===typeof IMP_HL&&"function"==typeof IMP_HL.block_showiniframe&&IMP_HL.block_showiniframe()){e=!0;break a}}catch(j){}e=!1}d=!0==e}if(d)return IMP.trackError(c.InteractionLogId,6,"No show in iframe set in script"),!0;if(placeHolderToUse=c.PlaceHolderToUse)if(-1<placeHolderToUse.indexOf(",")){var g=placeHolderToUse.split(",");
0<g.length&&F(a,b,c,g[0],!0);1<g.length&&F(a,b+"2",c,g[1],!0);2<g.length&&F(a,b+"3",c,g[2],!0);3<g.length&&F(a,b+"4",c,g[3],!0);4<g.length&&F(a,b+"5",c,g[4],!0);5<g.length&&F(a,b+"6",c,g[5],!0);6<g.length&&F(a,b+"7",c,g[6],!0);7<g.length&&F(a,b+"8",c,g[7],!0);8<g.length&&F(a,b+"9",c,g[8],!0);9<g.length&&F(a,b+"10",c,g[9],!0)}else F(a,b,c,placeHolderToUse,!1);else F(a,b,c,"",!1)}catch(f){try{IMP.trackError(c.InteractionLogId,6,f.lineNumber+" "+f.message)}catch(h){}}return!0},F=function(a,b,c,d,e){if(!c)return!0;
var j=S(c.OverrideClosedMessage);if(c.BlockMultipleOnSamePage&&document.getElementById(b)){try{IMP.trackError(c.InteractionLogId,6,"BlockMultipleOnSamePage")}catch(g){}return!1}var f,h,k,t,i,m,p;f=c.PositionStyle;if(d){h=S(c.PlaceholderReplaceContent);t=s(c.PlaceholderNewHeight);if((k=S(c.PlaceholderChangeHeight))&&0===t)d="",k=!1;m=s(c.PlaceholderNewWidth);if((i=S(c.PlaceholderChangeWidth))&&0===m)d="",i=!1}p=c.PlaceholderBeforeExistingContent;var w=!0;if(d&&(i||k||h||p))w=!1;var y=s(c.StartEffect);
0>y&&(y=0);var u=s(c.StartEffectTime);if(0>u||120<u)u=0;var z=s(c.CloseEffect);0>z&&(z=0);var q=s(c.CloseEffectTime);if(0>q||120<q)q=0;var E=s(c.HideAfterSek);if(0>E||1200<E)E=0;Ja[a]=z;Ka[a]=q;lb[a]=y;mb[a]=u;nb[a]=E;La[a]=!1;var A=c.ButtonSwitchContext;if(A)1==a&&(ob=!0),l[a][1].LogEvent=A.LogEvent,l[a][1].LocalHandler=A.LocalHandler,l[a][1].LocalHandlerDirective=A.LocalHandlerDirective,l[a][1].ChangePage=A.ChangePage,l[a][1].PageReference=A.PageReference,l[a][1].KeepUrl=A.KeepUrl,l[a][1].CloseEffect=
z,l[a][1].CloseEffectTime=q;var B=c.ButtonYes;if(B)l[a][2].LogEvent=B.LogEvent,l[a][2].LocalHandler=B.LocalHandler,l[a][2].LocalHandlerDirective=B.LocalHandlerDirective,l[a][2].ChangePage=B.ChangePage,l[a][2].PageReference=B.PageReference,l[a][2].KeepUrl=B.KeepUrl,l[a][2].CloseEffect=z,l[a][2].CloseEffectTime=q;var C=c.ButtonLater;if(C)l[a][3].LogEvent=C.LogEvent,l[a][3].LocalHandler=C.LocalHandler,l[a][3].LocalHandlerDirective=C.LocalHandlerDirective,l[a][3].ChangePage=C.ChangePage,l[a][3].PageReference=
C.PageReference,l[a][3].KeepUrl=C.KeepUrl,l[a][3].CloseEffect=z,l[a][3].CloseEffectTime=q;var D=c.ButtonNo;if(D)l[a][4].LogEvent=D.LogEvent,l[a][4].LocalHandler=D.LocalHandler,l[a][4].LocalHandlerDirective=D.LocalHandlerDirective,l[a][4].ChangePage=D.ChangePage,l[a][4].PageReference=D.PageReference,l[a][4].KeepUrl=D.KeepUrl,l[a][4].CloseEffect=z,l[a][4].CloseEffectTime=q;var F,H,I,J,L,M,N,G,O,P,T;F=c.DisplayUrl;H=s(c.Width);I=s(c.Height);J=c.Position;L=s(c.DelaySek);M=s(c.TopPos);N=s(c.LeftPos);(O=
c.BgStyle)||(O="position: absolute; right: 0px; padding:10px; top:0px; cursor: pointer");P=c.BGUrl;P=gd(P,F);T=s(c.BGDelay);V[a]=T;(closeButtonText=c.BGText)||(closeButtonText="Close");G=c.InteractionLogId;v[b]=G;wa[b]=c.ResponseUrl;ma[a]=c.InteractionMessageId;U[b]=c.Caption;Z[b]=c.MessageOfflineType;var Q=c.IsReferenceMessage;Q&&(ca[b]=!0,w=!1);var W=S(c.DisplayAsHTML),R=c.HtmlBody,X=c.CssFile;imprushdialogueparams[a]=rushparamstring="";if(0!=c.SyncWithPartnerDirective)if(5==c.SyncWithPartnerDirective)Mb();
else{if(8==c.SyncWithPartnerDirective){if(Jb())try{o("imp_int")||(wc(),IMP_HL.handle_accepttel())}catch(Y){}return!0}if(9==c.SyncWithPartnerDirective)return w=Ib(),(c=c.SyncWithPartnerUrl)||(c="1"),0==w&&n("imp_lh",c),!0;if(10==c.SyncWithPartnerDirective)return n("imp_lh",""),!0;if(11==c.SyncWithPartnerDirective)return nd(c.SyncWithPartnerUrl),!0;if(12==c.SyncWithPartnerDirective)return Hc(c.SyncWithPartnerUrl,G,12,0,Q),!0;if(13==c.SyncWithPartnerDirective)return rd(c.SyncWithPartnerUrl,R,G,11,0,
Q),!0;if(14==c.SyncWithPartnerDirective)return Lb(F,c.SyncWithPartnerUrl),!0;if(15==c.SyncWithPartnerDirective)wd(a,c.SyncWithPartnerUrl),yd("5,36");else if(16==c.SyncWithPartnerDirective)Mc(a,c.SyncWithPartnerUrl,!1);else if(17==c.SyncWithPartnerDirective)Mc(a,c.SyncWithPartnerUrl,!0);else{if(18==c.SyncWithPartnerDirective)return Nb(a,c.SyncWithPartnerUrl,!1,!1),!0;if(19==c.SyncWithPartnerDirective)Nb(a,c.SyncWithPartnerUrl,!0,!1);else if(20==c.SyncWithPartnerDirective)Nb(a,c.SyncWithPartnerUrl,
!0,!0);else if(21==c.SyncWithPartnerDirective)Fb=!0;else{if(22==c.SyncWithPartnerDirective)return td(c.SyncWithPartnerUrl,R,G,11,0,Q),!0;if(23==c.SyncWithPartnerDirective)la[b]=!0;else if(24==c.SyncWithPartnerDirective)Hc(c.SyncWithPartnerUrl,G,12,0,Q);else return 25==c.SyncWithPartnerDirective?sd(c.SyncWithPartnerUrl,R,G,11,0,Q,b):IMP.trackError(c.InteractionLogId,6,"SyncWithPartnerDirective not supported by script: "+c.SyncWithPartnerDirective),!0}}}cc=F;ba[a]=F;w?Nc(a,b,F,H,I,J,M,N,G,j,O,f,d,h,
k,t,i,m,p,L,y,u,z,q,E,void 0,void 0,void 0,void 0,A,B,C,D,P,T,!1,"",closeButtonText,W,R,e,X):da[b]=setTimeout(function(){Nc(a,b,F,H,I,J,M,N,G,j,O,f,d,h,k,t,i,m,p,0,y,u,z,q,E,void 0,void 0,void 0,void 0,A,B,C,D,P,T,!1,"",closeButtonText,W,R,e,X)},1E3*L);return!0},B=function(){var a=o("imp_no"),b=(new Date).getTime();return a?0<Math.round(a)-Math.round(b)?!1:!0:!0},Uc=function(){if(Gc()){var a=o("imp_to"),a=a?Math.round(a)+1:"1",b=60,c=300;1>=Math.round(a)?(b=60,c=300):2>=Math.round(a)?(b=120,c=900):
3>=Math.round(a)?(b=300,c=900):(Math.round(a),b=900,c=1800);var d=Math.round(b)/60/60/24,c=Math.round(c)/60/60/24,b=(new Date).getTime()+1E3*b;n("imp_no",b,d);n("imp_to",a,c)}},Vc=function(a){try{if(a.LogData){var b=a.LogData;Gb("imp_ld",JSON.stringify(b));var c;a:{try{if("object"===typeof IMP_HL&&"function"==typeof IMP_HL.exist_handlelogdata&&IMP_HL.exist_handlelogdata()&&"function"==typeof IMP_HL.handle_logdata){c=IMP_HL.handle_logdata(b);break a}}catch(d){}c=!1}if(!c)try{var a=0,e;for(e in b){a++;
if(11<a)break;b.hasOwnProperty(e)&&Gb("imp_ld_"+e,b[e])}}catch(j){}}}catch(g){IMP.appendSitePropStatic("implogdataerror",g)}},uc=function(a){try{"object"===typeof IMP_HL&&"function"===typeof IMP_HL.exist_logUserGroup&&IMP_HL.exist_logUserGroup()&&"function"===typeof IMP_HL.logUserGroup&&IMP_HL.logUserGroup(a.toString().substring(0,1))}catch(b){}},tc=function(a){try{"object"===typeof IMP_HL&&"function"===typeof IMP_HL.exist_logSessionGroup&&IMP_HL.exist_logSessionGroup()&&"function"===typeof IMP_HL.logSessionGroup&&
IMP_HL.logSessionGroup(a.toString().substring(0,1))}catch(b){}},ud=function(a,b,c){containerid="0"==c?k[1]:"1"==c?k[2]:"2"==c?k[3]:k[1];var c=document.getElementById(containerid),d="";c&&(c.style.position&&(d=d+"position: "+c.style.position+";"),d=c.style.top?d+"top: "+c.style.top+";":d+"top: auto;",d=c.style.marginTop?d+"margin-top: "+c.style.marginTop+";":d+"margin-top: auto;",d=c.style.bottom?d+"bottom: "+c.style.bottom+";":d+"bottom: auto;",d=c.style.marginBottom?d+"margin-bottom: "+c.style.marginBottom+
";":d+"margin-bottom: auto;",d=c.style.left?d+"left: "+c.style.left+";":d+"left: auto;",d=c.style.marginLeft?d+"margin-left: "+c.style.marginLeft+";":d+"margin-left: auto;",d=c.style.right?d+"right: "+c.style.right+";":d+"right: auto;",d=c.style.marginRight?d+"margin-right: "+c.style.marginRight+";":d+"margin-right: auto;");Lb(a,b,d)},Lb=function(a,b){var c=b.split("|"),d=c[0];if(a&&-1!=d.indexOf(".css")){"http://"!=d.substring(0,7)&&"https://"!=d.substring(0,8)&&(d=ia(a)+d);var e;1<c.length&&(e=
c[1],-1!=e.indexOf(".js")&&"http://"!=e.substring(0,7)&&"https://"!=e.substring(0,8)&&ia(a));2<c.length&&"CB"==c[2]&&n("imp_ih","1");c=d;-1==c.indexOf(".css")&&window.open(a,"Now_VideoWin",c)}},Wc=function(){navigator.language&&IMP.appendSiteProp("implanguage",navigator.language);navigator.platform&&IMP.appendSiteProp("impplatform",navigator.platform);screen.width&&IMP.appendSiteProp("impscreenwidth",screen.width);screen.height&&IMP.appendSiteProp("impscreenheight",screen.height);window.innerWidth&&
IMP.appendSiteProp("impinnerwidth",window.innerWidth);window.innerHeight&&IMP.appendSiteProp("impinnerheight",window.innerHeight);IMP.appendSiteProp("impnavigator",navigator.userAgent.replace(":"," "))},Yc=function(){o("imp_sb")||(n("imp_st",""),n("imp_sl",""),n("imp_nk",Math.floor(1E3*Math.random()+1).toString()),o("imp_oc")&&n("imp_oc",""),o("imp_lh")&&n("imp_lh",""),o("imp_rs")&&n("imp_rs",""));Oa=!1;var a=o("imp_st"),b=o("imp_nk");if(!a&&(Tc(1,k[1]),Tc(2,k[2]),y("imp_pt"),y("imp_lpt"),y("imp_plpt"),
y("imp_lov"),y("imp_clpt"),y("imp_cov"),Xc(),n("imp_st","0"),!o("imp_st"))){var a=document.location.hostname,c=a.toString().substr(a.toString().length-3),d=a.lastIndexOf("."),e=qc(a);-1<d&&!e&&(e=a.lastIndexOf(".",d-1),-1<e?".uk"==c||".in"==c||".id"==c||".il"==c||".za"==c||".cr"==c||".nz"==c||".jp"==c||".kr"==c||".pe"==c||".br"==c||".ck"==c?(c=a.lastIndexOf(".",e-1),-1<c?2<e-c-1&&(a=a.substr(c+1)):2>e-1&&0>a.indexOf("www")&&(a="www."+a)):2<d-e-1&&(a=a.substr(e+1)):2>d-1&&0>a.indexOf("www")&&(a="www."+
a));ra=a;n("imp_st","0");if(!o("imp_st")){var j;a:{try{if("object"===typeof IMP_HL&&"function"==typeof IMP_HL.allow_nocookie&&IMP_HL.allow_nocookie()){j=!0;break a}}catch(g){}j=!1}return j?Oa=!0:!1}}if(-1<w.toString().indexOf("imp_ilogid"))(j=rc(w).imp_ilogid)&&IMP.trackSystemEvent(8,j);if(-1<w.toString().indexOf("imp_uk")&&-1<w.toString().indexOf("imp_sk")&&(j=rc(w),a=j.imp_uk,c=j.imp_sk,a&&c))Hb(a,c),(j=j.imp_lh)&&n("imp_lh",j);a=o("imp_st");a=Math.round(a)+1;n("imp_st",a);Pa=a;if(3>=Math.round(a)){if(1>
Math.round(a))return!1;if(1==Math.round(a))try{"object"===typeof IMP_HL&&"function"==typeof IMP_HL.exist_appendLocalSessionProp&&IMP_HL.exist_appendLocalSessionProp()&&"function"==typeof IMP_HL.appendLocalSessionProp&&(result=IMP_HL.appendLocalSessionProp())}catch(f){}j="0";try{if("object"===typeof window&&("function"===typeof window.webkitRTCPeerConnection||"function"===typeof window.mozRTCPeerConnection))j="1"}catch(h){}IMP.appendSiteProp("imprtc",j);j="desktopstyle";if(navigator.userAgent.match(/Android/i)||
navigator.userAgent.match(/webOS/i)||navigator.userAgent.match(/Phone/i)||navigator.userAgent.match(/iPod/i)||navigator.userAgent.match(/BlackBerry/)||500>screen.width)j="phonestyle";IMP.appendSiteProp("impviewstyle",j);IMP.appendSiteProp("impversion","9.05.19_nojq");IMP.appendSiteProp("impsnum",b);IMP.appendSiteProp("impstart",a);IMP.appendSiteProp("impcheck",a)}Wc();IMP.appendSiteProp("impcnum",Math.floor(1E3*Math.random()+1).toString());o("imp_ve")&&(IMP.appendSiteProp("impvideoexit","1"),n("imp_ve",
""));o("imp_lh")&&IMP.appendSiteProp("imphandler","1");(b=o("cos_mode"))&&IMP.appendSiteProp(b.toString().toLowerCase(),"1");(b=o("imp_to"))&&IMP.appendSiteProp("impprotect",b);A()&&IMP.appendSiteProp("impiframe","1");return!0},ua=function(a,b){if(B())try{if(!window.XMLHttpRequest)return!0;var c=new XMLHttpRequest;c.open("GET",a,!0);c.timeout=O;c.onreadystatechange=function(){if(4===c.readyState&&200===c.status)a:{var a=JSON.parse(c.responseText);if(a){if(1==b){if(a.HasControlMessage){var d=a.LogPause,
g=s(a.LogPauseTime);0>=g&&(g=15);86400<g&&(g=86400);var f=Math.round(g)/60/60/24,g=(new Date).getTime()+1E3*g;d&&n("imp_no",g,f)}if(a.HasClientScriptData){d=a.ClientScriptData;if(d.HandlerFile&&(f=d.HandlerFile,"http://"!=f.substring(0,7)&&"https://"!=f.substring(0,8)&&(f="//"!=f.substring(0,2)?"https://"+f:"https:"+f),g=Cc(G),-1<f.indexOf(".js")&&-1<f.indexOf(g)))g=document.createElement("script"),g.type="text/javascript",g.src=f,document.getElementsByTagName("head")[0].appendChild(g);Vc(d);Ba=tb=
sb=!1;if(d.PageLogDirective&&!A()){g=f=!1;try{var h=RegExp(d.PageLogActiveRegExp);d.PageLogActiveRegExp&&h&&(f=h.test(w));var l=RegExp(d.PageLogDetailRegExp);d.PageLogDetailRegExp&&l&&(g=l.test(w))}catch(t){}try{zd(d.PageLogDirective)}catch(i){IMP.appendSitePropStatic("imperror",i)}h=d.PageLogDirective.split(",");0<h.length&&1==s(h[0])&&(sb=!0);f&&1<h.length&&s(1==h[1])&&(tb=!0);if(g&&(2<h.length&&s(1==h[2])&&(Ba=!0),h=d.PageLogDirective,!A()&&(h=h.split(","),!(10>h.length)&&(vb=s(h[6]),Sa=s(h[7]),
T=s(h[8]),Ta=s(h[9]),1==vb)))){0==Ta&&(Ta=1);if(0<T&&(15>T||60<T))T=30;Ca()}}}if(a.HasCollectMetaDataInstruction&&a.CollectMetaData)try{"object"===typeof IMP_HL&&"function"==typeof IMP_HL.exist_handle_collectmeta&&IMP_HL.exist_handle_collectmeta()&&"function"==typeof IMP_HL.handle_collectmeta&&IMP_HL.handle_collectmeta()}catch(m){}if(h=a.HasChangeKeysMessage)h=a.ChangeKeysMessageUserKey,l=a.ChangeKeysMessageSessionKey,!ub||!h||!l?h=!1:h==E()&&l==M()?h=!1:(Hb(h,l),ub=!1,IMP.appendSiteProp("impdomainswitch",
"1"),IMP.trackInteract(),h=!0),h=!0==h;if(h)break a}else a.HasClientScriptData&&Vc(a.ClientScriptData);a.HasSpecialMessage&&(k[3]="ni_imp_spec",Tb(3,k[3],a.SpecialMessage,b));a.HasNormalMessage?(k[1]="ni_imp_prim",Tb(1,k[1],a,b)):hb(1,k[1]);a.HasTeaserMessage?(k[2]="ni_imp_secd",Tb(2,k[2],a.TeaserMessage,b)):hb(2,k[2]);if(1==b){a=sb;h=tb;l=Ba;try{"object"===typeof IMP_HL&&"function"==typeof IMP_HL.exist_appendLocalSitePropPostReply&&IMP_HL.exist_appendLocalSitePropPostReply()&&"function"==typeof IMP_HL.appendLocalSitePropPostReply&&
(result=IMP_HL.appendLocalSitePropPostReply(a,h,l))}catch(p){}ea=!1}}else hb(1,"ni_imp_prim"),hb(2,"ni_imp_secd");Gc()&&o("imp_to")&&n("imp_to","",(1/60/60/24).toString())}};c.ontimeout=function(){Uc()};c.send(null);IMP.clearSiteProp();W=!1}catch(d){return IMP.appendSitePropStatic("imperror",d),!0}},Ub=function(a){a||(a="logtool");IMP.appendSiteProp("impevent",a);IMP.appendSiteProp("implogtype",6);N(L());IMP.clearSiteProp()},Zc=function(a,b,c){if(B()){var d;try{a||(a="logtool");IMP.appendSiteProp("impevent",
a);IMP.appendSiteProp("implogtype",8);if(!window.XMLHttpRequest)return IMP.appendSiteProp("impajax","jquery"),d=L(),d+="&impajax=jquery",!0;d=L();var e=new XMLHttpRequest;e.open("GET",d,!0);e.timeout=O;e.onreadystatechange=function(){4===e.readyState&&200===e.status&&Ed(JSON.parse(e.responseText),b,c)};e.ontimeout=function(){Uc()};e.send(null);IMP.clearSiteProp()}catch(j){return d||(d=L()),d+="&impajax=errorjquery",!0}}},Vb=function(a,b,c){a=fd(a,b,c);b=new XMLHttpRequest;b.open("GET",a,!0);b.timeout=
1E4;b.onreadystatechange=function(){};b.ontimeout=function(){};b.send(null)},Ed=function(a,b,c){var d;if(a){if(a.HasSpecialMessage&&a.SpecialMessage.InteractionLogId&&!S(a.SpecialMessage.IsRepeatState))d=a.SpecialMessage.InteractionLogId;if(a.HasTeaserMessage&&a.TeaserMessage.InteractionLogId&&!S(a.TeaserMessage.IsRepeatState))d=a.TeaserMessage.InteractionLogId;if(a.HasNormalMessage&&a.InteractionLogId&&!S(a.IsRepeatState))d=a.InteractionLogId}if(d==v[k[1]]||d==v[k[2]]||d==v[k[3]])d=0;d&&(IMP.trackDisplay(d,
0,0),ga=d,b&&c&&setTimeout(function(){Vb(va,ga,c)},500))},N=function(a){if(B()){if(!window.XMLHttpRequest)return!0;try{var b=new XMLHttpRequest;b.open("GET",a,!0);b.timeout=O;b.onreadystatechange=function(){};b.ontimeout=function(){};b.send(null);IMP.clearSiteProp()}catch(c){return!0}}},Fd=function(){if(B()){if(!window.XMLHttpRequest)return!0;try{var a=new XMLHttpRequest,b=dd(),c=ed();a.open("POST",b,!0);a.setRequestHeader("Content-type","application/x-www-form-urlencoded");a.timeout=O;a.onreadystatechange=
function(){};a.ontimeout=function(){};a.send(c);IMP.clearSiteProp()}catch(d){return!0}}},Fa=function(a){a=a.toString().replace(/[\x8C]/g,"OE");a=a.toString().replace(/[\x9C]/g,"oe");a=a.toString().replace(/[\x9E]/g,"z");a=a.toString().replace(/[\x9F]/g,"Y");a=a.toString().replace(/[\xC0-\xC5]/g,"A");a=a.toString().replace(/[\xC6]/g,"AE");a=a.toString().replace(/[\xC7]/g,"C");a=a.toString().replace(/[\xC8-\xCB]/g,"E");a=a.toString().replace(/[\xCC-\xCF]/g,"I");a=a.toString().replace(/[\xD0]/g,"D");
a=a.toString().replace(/[\xD1]/g,"N");a=a.toString().replace(/[\xD2-\xD6]/g,"O");a=a.toString().replace(/[\xD7]/g," ");a=a.toString().replace(/[\xD8]/g,"O");a=a.toString().replace(/[\xD9-\xDC]/g,"U");a=a.toString().replace(/[\xDD]/g,"Y");a=a.toString().replace(/[\xDE-\xDF]/g," ");a=a.toString().replace(/[\xE0-\xE5]/g,"a");a=a.toString().replace(/[\xE6]/g,"ae");a=a.toString().replace(/[\xE7]/g,"c");a=a.toString().replace(/[\xE8-\xEB]/g,"e");a=a.toString().replace(/[\xEC-\xEF]/g,"i");a=a.toString().replace(/[\xF0]/g,
"o");a=a.toString().replace(/[\xF1]/g,"n");a=a.toString().replace(/[\xF2-\xF6]/g,"o");a=a.toString().replace(/[\xF7]/g," ");a=a.toString().replace(/[\xF8]/g,"o");a=a.toString().replace(/[\xF9-\xFC]/g,"u");a=a.toString().replace(/[\xFD]/g,"y");a=a.toString().replace(/[\xFE]/g," ");return a=a.toString().replace(/[\xFF]/g,"y")},Wb=function(a){var b="";a&&(a=a.split("|"),1<a.length&&"scroll"==a[0]&&a[1]&&(b=a[1]));return b},ib=function(a,b){if(!b)return!1;var c=Wb(a);return!c||c==Ma||b==za?!1:!0},Gd=
function(a,b){xa&&ib(a,b)&&(clearTimeout(xa),xa=0);xa=setTimeout(function(){var c;xa=0;ib(a,b)?10>Na&&(Na++,za=b,Ma=Wb(a),c="https://"+document.location.hostname+document.location.pathname,document.location.pathname.toString().endsWith("/")||(c+="/"),c+=b,IMP.appendSiteProp("impscroll",Ma),IMP.trackTabInteract("scroll",c,w)):jb(a,!1,!1)},3E3)},Hd=function(a,b){setTimeout(function(){jb(a,!1,!1)},3E3);var c=ib(a,b);c&&(ya&&(clearTimeout(ya),ya=0),qb&&(clearTimeout(qb),qb=0),c&&(ya=setTimeout(function(){ya=
0;ib(a,b)&&10>Na&&(Na++,za=b,Ma=Wb(a),jb(b,!1,!0))},3E3)))},jb=function(a,b,c){if(a){var d=a,e=(new Date).getTime(),j=(Math.round((e-nc)/1E3)+0).toString();nc=e;e=(Math.round((e-ad)/1E3)+0).toString();IMP.appendSitePropStatic("lasteventtime",e);d=d.toString().replace(/[\x09-\x10]/g," ");d=Fa(d);d=d.toString().replace(/[^\x20-\x7E]/g,"");d=d.toString().replace(/[\/:]/g," ");d=d.toString().replace(/[<>]/g,"");c?500>(Ya+"/"+d).length&&!ic?(Ya=Ya+"/"+d,D("imp_clpt",Ya,!0)):(ic="1",D("imp_cov","1")):b?
(c=IMP.getSitePropStatic("event"),b=IMP.getSitePropStatic("eventtime"),c?(d=c+"/"+d,newSimplePatternTime=b+"/"+j):newSimplePatternTime=j,150>d.length&&(IMP.appendSitePropStatic("event",d),IMP.appendSitePropStatic("eventtime",newSimplePatternTime))):500>(H+"/"+d).length&&!fa?(H=H+"/"+d,D("imp_plpt",document.location.pathname),D("imp_lpt",H,!0)):(fa="1",D("imp_lov","1"));ea=!0;-1<a.toString().indexOf("scroll")&&(j=a.split("|"),2<=j.length&&(a=j[0]+"_"+j[1]),Ua=a);wb&&(IMP.appendSiteProp("event",Ua),
IMP.appendSiteProp("implogtype",11),IMP.trackTimeInteract(),Ca());Math.round((new Date).getTime()/1E3)}},Bc=function(){var a=z("imp_lprp"),b,c;if(a)for(var d=a.split(","),a=0;a<d.length;a++)if(c=d[a],b=z("imp_prp_"+c,!0)){var e;a:{e=void 0;for(e=0;e<ka;e++)if(c==ja[e]){e=!0;break a}e=!1}e||IMP.appendSiteProp(c,b)}},Xc=function(){var a=z("imp_lprp"),b;if(a){for(var c=a.split(","),a=0;a<c.length;a++)b=c[a],y("imp_prp_"+b);y("imp_lprp")}};return IMP={hide_IMPiframe:function(a,b,c){var d=k[a],e=Ka[a];
fb(d,Ja[a],e,!1);ac[d]=setTimeout(function(){var a=document.getElementById(d);a&&a.parentNode.removeChild(a);(a=document.getElementById(d+"2"))&&a.parentNode.removeChild(a);(a=document.getElementById(d+"3"))&&a.parentNode.removeChild(a);(a=document.getElementById(d+"4"))&&a.parentNode.removeChild(a);(a=document.getElementById(d+"5"))&&a.parentNode.removeChild(a);(a=document.getElementById(d+"6"))&&a.parentNode.removeChild(a);(a=document.getElementById(d+"7"))&&a.parentNode.removeChild(a);(a=document.getElementById(d+
"8"))&&a.parentNode.removeChild(a);(a=document.getElementById(d+"9"))&&a.parentNode.removeChild(a);(a=document.getElementById(d+"10"))&&a.parentNode.removeChild(a)},1E3*e);if(1==a||2==a)gb(1,k[1]),gb(2,k[2]);ma[a]=0;IMP.trackCloseBox(b);Fb&&qd(a,b,c);jd(U[d])},initsite:function(a,b){var c=b;ha=a;c?("1"==c?c="imp":"2"==c?c="imp2":"3"==c?c="imp3":"4"==c?c="imp4":"5"==c&&(c="imp5"),G="https://"+c+".nowinteract.com/logserver/ResponseService.ashx?",metadataurl="https://"+c+".nowinteract.com/logserver/PageMetaData.ashx?",
va="https://"+c+".nowinteract.com/logserver/ActionResponse.aspx"):(G="https://imp.nowinteract.com/logserver/ResponseService.ashx?",metadataurl="https://imp.nowinteract.com/logserver/PageMetaData.ashx?",va="https://imp.nowinteract.com/logserver/ActionResponse.aspx")},initSubDomain:function(){o("imp_sb")||(ub=!0,IMP.appendSiteProp("webdomainevent","1"))},isInitsite:function(){return ha?!0:!1},appendSitePatt:function(a,b,c){Eb=(new Date).getTime();var d="";b&&(d=Fa(b),d=d.toLowerCase(),d=d.replace(/[ ]/g,
"-"),d="scroll-"+d);b="";c&&(b=Fa(c),b=b.toLowerCase(),b=b.replace(/[ ]/g,"-"),b="click-"+b);Ba?Gd(a,d,b):Hd(a,d,b)},appendSiteEvent:function(a){jb(a,!0)},clearSiteProp:function(){ja=[];Ga=[];ka=0},appendSiteProp:function(a,b){ja[ka]=a;var c;c=b.toString().replace(/[\x09-\x10]/g," ");c=Fa(c);c=c.toString().replace(/[^\x20-\x7E]/g,"");c=c.toString().replace(/[<>]/g,"");Ga[ka]=c;ka++},appendSitePropStatic:function(a,b){if(b){if(!z("imp_prp_"+a,!0)){var c=z("imp_lprp");D("imp_lprp",c?c+","+a:a)}D("imp_prp_"+
a,b,!0)}},getSitePropStatic:function(a){return z("imp_prp_"+a,!0)},clearAllSitePropStatic:function(){Xc()},appendNamedMetaProp:function(a,b){var c=Jc(a),d=a.toString().replace(/:/g,"");b&&(d=b);c&&IMP.appendSiteProp(d,c)},appendMetaProp:function(a){a=Jc(a);kb++;var b="impmeta";1<kb&&(b+=kb.toString());a&&IMP.appendSiteProp(b,a)},appendEventProp:function(a){a&&IMP.appendSiteProp("impevent",a)},trackButtonEvent:function(a,b,c){b=v[k[a]];IMP.trackFollowLink(b);if(1==c){var d;1==a?(d=2,n("imp_curr_selection",
d),ta(k[d],0,0,0,0,0,0,0,!1,10,0)):2==a?(d=1,n("imp_curr_selection",d),ta(k[d],0,0,0,0,0,0,0,!1,10,0)):d=0}l[a][c].LogEvent&&(IMP.appendSiteProp("impevent",l[a][c].LogEvent),IMP.appendSiteProp("impeventlogid",b),IMP.appendSiteProp("impeventmessid",ma[a]),W=!0,O=1E4,l[a][c].KeepUrl?IMP.trackSwitchEventInteract():IMP.trackEventInteract(),O=3E3);if(l[a][c].LocalHandler)d=l[a][c].LogEvent,l[a][c].LocalHandlerDirective&&(d=l[a][c].LocalHandlerDirective),kd(d,b,E(),M());d=!1;if(l[a][c].ChangePage){var e=
l[a][c].PageReference;if(e){var j=e.split("|");if(1<j.length){var g=j[0],f=j[1];"http://"!=g.substring(0,7)&&"https://"!=g.substring(0,8)&&(g=ia(ba[a])+g);-1!=f.indexOf(".css")&&"http://"!=f.substring(0,7)&&"https://"!=f.substring(0,8)&&(f=ia(ba[a])+f);var h;2<j.length&&(h=j[2],-1!=h.indexOf(".js")&&"http://"!=h.substring(0,7)&&"https://"!=h.substring(0,8)&&(h=ia(ba[a])+h));3<j.length&&"CB"==j[3]&&n("imp_ih","1");var o="?key="+b.toString()+"&uk="+E();5<j.length&&"CT"==j[5]&&(o="/"+E());setTimeout(function(){var b=
g+o,c="Now_ClickWin"+a,d=f;-1==d.indexOf(".css")&&window.open(b,c,d)},250)}else if("http://"==e.substring(0,7)||"https://"==e.substring(0,8))d=!0,setTimeout(function(){window.location.href=e},50)}}d||(2==c||3==c||4==c?fb(k[a],0,0,!1):1==c&&fb(k[a],0,0,!1))},trackLogToolFollow:function(a){Ub(a)},trackLogToolAccept:function(a){Ub(a)},trackLogToolAcceptServer:function(a){Ub(a)},trackLogToolDisplay:function(a){Zc(a)},trackLogToolDisplayClose:function(){var a=ga;a&&IMP.trackCloseBox(a)},trackLogToolClose:function(){var a=
ga;a&&IMP.trackCloseBox(a)},trackLogToolDisplayAccept:function(a,b,c){var d=ga;d&&IMP.trackAcceptTool(d,a,b,c)},trackLogToolDisplayAcceptContact:function(a){ga&&va&&Vb(va,ga,a)},trackLogToolAcceptContact:function(a,b){Zc(a,!0,b)},trackAppendLog:function(a){if(!0==A()&&!0==Y())return!0;w=J.location.href;if(B()){a?IMP.appendSiteProp("webevent",1):IMP.appendSiteProp("webevent",3);C&&IMP.appendSiteProp("webdata",C);if(H)if(a={},a.webdatalog=H,a.activity={},a.activity=yc(H),a.path=document.location.pathname,
a.activity.lastInputField&&IMP.apppendSiteProp("lastinput",a.activity.lastInputField),za&&IMP.apppendSiteProp("lastcontent",za),zc()){if(fa)a.pattoverflow="1";if(1E3<JSON.stringify(a).toString().length)a.webdatalog="",a.sumoverflow="1";IMP.appendSiteProp("webdatalog",JSON.stringify(a))}else IMP.appendSiteProp("webdatalog",H),fa&&IMP.appendSiteProp("implog","pattoverflow");N(X())}},trackAppendLogPost:function(){if(!0==A()&&!0==Y())return!0;B()&&(IMP.appendSiteProp("webevent",3),Fd())},trackInteract:function(a,
b){if(!0==A()&&!0==Y())return!0;w=J.location.href;R=J.referrer;a&&(w=a);b&&(R=b);if(hd(w)){var c;a:{try{if("object"===typeof IMP_HL&&"function"===typeof IMP_HL.exist_handle_testscript&&IMP_HL.exist_handle_testscript()&&"function"===typeof IMP_HL.handle_testscript){c=!0;break a}}catch(d){}c=!1}if(c)try{IMP_HL.handle_testscript()}catch(e){}return!0}if(Yc()&&B()){Sc();sa();M(!0);c=o("imp_lh");var j=o("imp_ih"),g=!1,f;f=w;var h="";if(f)try{"object"===typeof IMP_HL&&"function"==typeof IMP_HL.exist_check_handlerpattern&&
IMP_HL.exist_check_handlerpattern()&&"function"==typeof IMP_HL.check_handlerpattern&&(h=IMP_HL.check_handlerpattern(f))}catch(k){}if(f=h)n("imp_lh",f.toString()),g=!0;c?Dc(c.toString()):g?Dc(f.toString()):j&&(runhandlerresult=Ib(),0==runhandlerresult&&n("imp_lh","1"));Ec();(c=o("imp_sl"))||(c="0");c=Math.round(c)+1;n("imp_sl",c);rb=c;IMP.appendSiteProp("impview",rb);IMP.appendSiteProp("imptab",Aa++);Xb()?(IMP.appendSiteProp("implogtype",0),Za=!1):(IMP.appendSiteProp("implogtype",1),Za=!0);ua(X(!0,
!0),1);db();IMP.clearAllSitePropStatic();dc=M();Fc()}},trackEventInteract:function(a){if(!0==A()&&!0==Y())return!0;a&&IMP.appendSiteProp("impevent",a);B()&&(IMP.appendSiteProp("implogtype",7),IMP.appendSiteProp("imptab",Aa++),ua(L(),2))},trackSwitchEventInteract:function(){if(!0==A()&&!0==Y())return!0;B()&&(IMP.appendSiteProp("implogtype",7),ua(X(),2))},trackItemInteract:function(a,b,c){var a=w,d=R;IMP.trackTabInteract("",b,c,!0);w=a;R=d},trackTabInteract:function(a,b,c,d){if(!0==A()&&!0==Y())return!0;
w=J.location.href;R=J.referrer;b&&(w=b);c&&(R=c);a&&IMP.appendSiteProp("tabevent",a);B()&&(C&&D("imp_pt",C),sa(),Wc(),d?IMP.appendSiteProp("implogtype",14):IMP.appendSiteProp("implogtype",2),IMP.appendSiteProp("imptab",Aa++),ua(X(),4),db(),Qb(),Rb(),Kb("pagetab"),ea=!1)},trackFocusInteract:function(){if(!0==A()&&!0==Y())return!0;B()&&Yc()&&(Sc(),sa(),Ec(!0),IMP.appendSiteProp("imptab",Aa++),ua(X(),5),db(),Qb(),Rb(),Kb(),ea=!1,Fc())},trackTimeInteract:function(){if(!0==A()&&!0==Y())return!0;B()&&(C&&
D("imp_pt",C),sa(),IMP.appendSiteProp("imptab",Aa++),ua(X(),3),db(),Qb(),Rb(),Kb("pagetimer"),ea=!1)},trackMetaData:function(){w=J.location.href;var a=N,b;b="siteid="+ha+"&url="+t(w)+"&rand="+Math.random();b+=eb();a(metadataurl+b);IMP.clearSiteProp()},trackSystemEvent:function(a,b){IMP.clearSiteProp();IMP.appendSiteProp("sysevent",a);IMP.appendSiteProp("interactionlogid",b);N(L());IMP.clearSiteProp()},trackCloseBox:function(a){IMP.trackSystemEvent(2,a)},trackHtmlCloseBox:function(a){var b=0;a?b=v[a]:
aa?(a=aa,b=v[a]):b=0;b&&IMP.trackCloseBox(b)},trackHtmlAccept:function(a){IMP.trackHtmlAcceptTool(a)},trackHtmlAcceptTool:function(a,b,c,d){var e=0;a?e=v[a]:aa?(a=aa,e=v[a]):e=0;e&&IMP.trackAcceptTool(e,b,c,d)},trackDisplay:function(a,b,c){IMP.clearSiteProp();IMP.appendSiteProp("sysevent",5);IMP.appendSiteProp("interactionlogid",a);IMP.appendSiteProp("displayreason",b);IMP.appendSiteProp("displayreasondetail",c);N(L());IMP.clearSiteProp()},trackFollowLink:function(a){IMP.trackSystemEvent(1,a)},trackAccept:function(a){IMP.trackSystemEvent(9,
a)},trackAcceptTool:function(a,b,c,d){IMP.clearSiteProp();IMP.appendSiteProp("sysevent",9);IMP.appendSiteProp("interactionlogid",a);b&&IMP.appendSiteProp("accepttype",b);c&&IMP.appendSiteProp("acceptcode",c);d&&IMP.appendSiteProp("acceptexttype",d);N(L());IMP.clearSiteProp()},trackError:function(a,b,c){IMP.clearSiteProp();IMP.appendSiteProp("sysevent",b);IMP.appendSiteProp("interactionlogid",a);IMP.appendSiteProp("syserrorinfo",c);N(L());IMP.clearSiteProp()},trackSendContact:function(a,b){b||(b=aa?
aa:k[1]);Vb(wa[b],v[b],a);return!0},trackKeep:function(){oc=!0},trackGetKey:function(){return E()},getUKey:function(){return E()},getSKey:function(){return M()},getPKey:function(){return E()+"_"+dc+"_"+Pa+"_"+rb},getJKey:function(){return cb()},getCookie:function(a){return o(a)},getKeyVal:function(a){return o(a)},setKeyVal:function(a,b){return Gb(a,b)},transferKeys:function(a,b){return Hb(a,b)},adjustExtendedAscii:function(a){return Fa(a)}}})();




jQuery(function() {



  if(!nowChatListner)
  {

  $( "body" ).append( "<a id='now-bc-start-service' style=display:none></a>" );

  var nowbcIDservice = "now-bc-start-service";
  window._bcvma = window._bcvma || [];

  _bcvma.push(["setAccountiD","5021647476238876565"]);
  _bcvma.push(["addText",{type:"chat",department:"155923357825052156",window:"950476725422356726",available:"Available",unavailable:"Unavailable",id:nowbcIDservice}]);

   var bcLoadService = function(){
      if(window.bcLoaded) return; window.bcLoaded = true;
      var vms = document.createElement("script"); vms.type = "text/javascript"; vms.async = true;
      vms.src = ('https:'==document.location.protocol?'https://':'http://') + "vmss.boldchat.com/aid/5021647476238876565/bc.vms4/vms.js";
      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(vms, s);
    };
    if(window.pageViewer && pageViewer.load) pageViewer.load();
    else if(document.readyState=="complete") bcLoadService();
    else if(window.addEventListener) window.addEventListener('load', bcLoadService, false);
    else window.attachEvent('onload', bcLoadService);






  $( "body" ).append( "<a id='now-bc-start' style=display:none></a>" );

var nowbcID = "now-bc-start";
window._bcvma = window._bcvma || [];

_bcvma.push(["setAccountiD","5021647476238876565"]);
_bcvma.push(["addText",{type:"chat",department:"3067381618417784909",window:"6499230742373892625",available:"Available",unavailable:"Unavailable",id:nowbcID}]);


 var bcLoad = function(){
    if(window.bcLoaded) return; window.bcLoaded = true;
    var vms = document.createElement("script"); vms.type = "text/javascript"; vms.async = true;
    vms.src = ('https:'==document.location.protocol?'https://':'http://') + "vmss.boldchat.com/aid/5021647476238876565/bc.vms4/vms.js";
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(vms, s);
  };
  if(window.pageViewer && pageViewer.load) pageViewer.load();
  else if(document.readyState=="complete") bcLoad();
  else if(window.addEventListener) window.addEventListener('load', bcLoad, false);
  else window.attachEvent('onload', bcLoad);

  nowChatListner = true;
  }

//Version 1.0.3

setTimeout(function(){
if($("#now-bc-start").text() == "Available")
{
  IMP.appendSiteProp("boldChatActive",1);
}
else
{
  IMP.appendSiteProp("boldChatActive",0);
}

if($("#now-bc-start-service").text() == "Available")
{
  IMP.appendSiteProp("boldChatServiceActive",1);
}
else
{
  IMP.appendSiteProp("boldChatServiceActive",0);
}








IMP.initsite("uk3g130711nowhi","3");
IMP.trackInteract();
}, 2000)
});
});
