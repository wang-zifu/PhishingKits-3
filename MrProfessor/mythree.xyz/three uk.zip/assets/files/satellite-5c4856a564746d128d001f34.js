_satellite.pushAsyncScript(function(event, target, $variables){
  //updated to ensure ; is at end of every row of code. done on 5Aug2019 by RShires

window.ClickTalePIISelector = "#pl-view-name .P40_ViewMyName_w1 .it8para strong";
window.ClickTalePIISelector += ", .P28_manageAddress_w4 .form-fields .floatLeft .width-300";
window.ClickTalePIISelector += ", #EDBContainer .EDBheaderContainer .EDBdetails p span";
window.ClickTalePIISelector += ", .P28_manageAddress_w8 .portlet-form-input-label.alt";
window.ClickTalePIISelector += ", .P28_manageAddress_w8 #searchAddress .form-fields p strong";
window.ClickTalePIISelector += ", .P28_manageAddress_w7 #searchAddress .form-fields p strong";
window.ClickTalePIISelector += ", #my3AuthRegisterForm #confirmEmail";
window.ClickTalePIISelector += ", #emailEditForm #alreadyRegisteredMail";
window.ClickTalePIISelector += ", .P88_ManageEmailAddress_1 #emailLink";
window.ClickTalePIISelector += ", .P28_manageAddress_w7 .form-fields p strong";
window.ClickTalePIISelector += ", .P28_manageAddress_w8 .form-fields p strong";
window.ClickTalePIISelector += ", #emailCaptureForm #emailCaptureMsisdn";
window.ClickTalePIISelector += ", #emailCaptureForm #email, #emailCaptureForm #confirmEmail";
window.ClickTalePIISelector += ", #my3AuthRegisterForm #my3AuthEmail";
window.ClickTalePIISelector += ", #offnetHomeForm #offnetMSISDN";
window.ClickTalePIISelector += ", #my3AuthRegisterForm #my3AuthEmailRe";

//https://www.three.co.uk/New_My3/My_details/Change_address
window.ClickTalePIISelector += ", .P28_manageAddress_w6 .width-300";

// https://www.three.co.uk/New_My3/Top_up?id=My3_TopUpImage
window.ClickTalePIISelector += ", .P93_CustomerTopup .allowenceHeader p span";

// register my details - https://www.three.co.uk/New_My3/Register_my_details
window.ClickTalePIISelector += ", #registerContact selectID";

//https://www.three.co.uk/New_My3/Top_up?id=My3_TopUpImage#TopupByCardTab
window.ClickTalePIISelector += ", .P93_CustomerTopup .addonContainer .firstLeftLabel p";

// https://www.three.co.uk/New_My3/Top_up/Manage_my_cards?id=My3_ManageCardsLink
window.ClickTalePIISelector += ", .P91_ManageCustomerCards #CardsContainer .name";
window.ClickTalePIISelector += ", .P91_ManageCustomerCards #CardsContainer .cardNumber .cardtype";
window.ClickTalePIISelector += ", .P91_ManageCustomerCards #CardsContainer .cardNumber .cardendtxt";
window.ClickTalePIISelector += ", .P91_ManageCustomerCards #CardsContainer .cardNumber .cardno";
window.ClickTalePIISelector += ", .P91_ManageCustomerCards #ManageCustomerCardsContainer #top-upName";

// https://www.three.co.uk/web_top_up
window.ClickTalePIISelector += ", .P94_AnonymousTopUp .topUpNoMargin p span";
window.ClickTalePIISelector += ", #addressListForm #addressListContainer .pciflatNumber";
window.ClickTalePIISelector += ", #addressListForm #addressListContainer .pcihouseNumber";
window.ClickTalePIISelector += ", #addressListForm #addressListContainer .pciChooseAddress";
window.ClickTalePIISelector += ", #addressListForm #addressListContainer .pciChooseTown";
window.ClickTalePIISelector += ", #addressListForm #addressListContainer .pciChoosePostcode";

// https://www.three.co.uk/New_My3/Bill_summary/Manage_my_cards#
window.ClickTalePIISelector += ", #pciCreditCardForm .pciConfirmAddress p";
window.ClickTalePIISelector += ", .P28_manageAddress_w4 .floatLeft .width-300";

// store.three.co.uk //
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_title";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_title option";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_gender";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_gender option";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_maritalStatus";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_maritalStatus option";
window.ClickTalePIISelector += ", #maritalStatus_span";
window.ClickTalePIISelector += ", #sessionInfo";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_yearsAtAddress0";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_yearsAtAddress0 option";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_monthsAtAddress0";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_monthsAtAddress0 option";
window.ClickTalePIISelector += ", #addresses0_ambiguousAddresses";
window.ClickTalePIISelector += ", #addresses0_ambiguousAddresses option";
window.ClickTalePIISelector += ", #addresPopulated0 div";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_residentialStatus"; 
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_residentialStatus option";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_employmentStatus";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_employmentStatus option";
window.ClickTalePIISelector += ", #email-basket-form #email";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_employmentType";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_employmentType option";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_yearsWithEmployer";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_yearsWithEmployer option";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_monthsWithEmployer";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_monthsWithEmployer option";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_maidenname";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_yearsAtAddress1";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_monthsAtAddress1";
window.ClickTalePIISelector += ", #addresPopulated1 div";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_yearsAtAddress2";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponent_monthsAtAddress2";
window.ClickTalePIISelector += ", #addresPopulated2 div";
window.ClickTalePIISelector += ", #three_checkout_direct_debit_durationWithBankInYears";
window.ClickTalePIISelector += ", #three_checkout_direct_debit_durationWithBankInYears option";
window.ClickTalePIISelector += ", #three_checkout_direct_debit_creditCheckOptions";

//  coverage checker  //
window.ClickTalePIISelector += ", .coverage-map-panel #map";
window.ClickTalePIISelector += ", .mapPanel.panel";

// three.co.uk/New_My3/Bill_summary/Pay_an_outstanding_balance
window.ClickTalePIISelector += ", #pciConfirmAddressForm .pciConfirmAddress p";

//support: sim activation
window.ClickTalePIISelector += ", .consistentForm textarea";

// topup - from Shaun
window.ClickTalePIISelector += ", .top-upVoucherAddonInnerDesc span";

// www.three.co.uk/New_My3/Bill_summary/Pay_an_outstanding_balance
window.ClickTalePIISelector += ", #addressListForm #addressListContainer .pciChoosehouseNumber p";	
window.ClickTalePIISelector += ", #addressListForm #addressListContainer .pciChooseflatNumber p";

// hide entire iframe
window.ClickTalePIISelector += ", iframe.bc-frame-content-container";

// https://store.three.co.uk//Personal_Details
window.ClickTalePIISelector += ", #personalDetailsForm #checkoutPersonalDetailsComponentPayg_title";
window.ClickTalePIISelector += ", #personalDetailsForm #checkoutPersonalDetailsComponentPayg_firstname";
window.ClickTalePIISelector += ", #personalDetailsForm #checkoutPersonalDetailsComponentPayg_lastname";
window.ClickTalePIISelector += ", #personalDetailsForm #checkoutPersonalDetailsComponentPayg_phone1";
window.ClickTalePIISelector += ", #personalDetailsForm #checkoutPersonalDetailsComponentPayg_email";
window.ClickTalePIISelector += ", #personalDetailsForm #checkoutPersonalDetailsComponentPayg_confirmEmail";
window.ClickTalePIISelector += ", #personalDetailsForm #checkoutPersonalDetailsComponentPayg_houseNameOrNumber0";
window.ClickTalePIISelector += ", #personalDetailsForm #checkoutPersonalDetailsComponentPayg_postCodeSearch0";

// https://www.three.co.uk/business-contact-us
window.ClickTalePIISelector += ", #businessFormWrapper .custom-select";
window.ClickTalePIISelector += ", .custom-select";
window.ClickTalePIISelector += ", #businessFormWrapper form label span select option";

// https://www.three.co.uk/Support/Free_SIM/Order
window.ClickTalePIISelector += ", #freeSIM .custom-select";
window.ClickTalePIISelector += ", #freeSIM form label.no-optional-copy span select option";
window.ClickTalePIISelector += ", #freeSIM form label.no-optional-copy span select";
window.ClickTalePIISelector += ", select option";

// https://www.three.co.uk/Free_SIM_MBB/Order
window.ClickTalePIISelector += ", .main.lhs.span6 .form.span6 .custom-select select option";

// login page
window.ClickTalePIISelector += ", #username";
window.ClickTalePIISelector += ", #j_password";

// https://store.three.co.uk/checkout/Payment => https://pp.ephapay.net (iframe)
window.ClickTalePIISelector += ", #cardEntryForm #cardholderName";
window.ClickTalePIISelector += ", #cardEntryForm #cardNumber";

// block phone number history
window.ClickTalePIISelector += ", #minutesResults td";

// block phone message history
window.ClickTalePIISelector += ", #messagesResults td";

// block existing card number
window.ClickTalePIISelector += ", #CardsContainer .cardno";

// password on London Wifi
window.ClickTalePIISelector += ", #switchpw";
window.ClickTalePIISelector += ", .Functional-App_LUWifiRegistration.magicpassword form";

// edit card number
window.ClickTalePIISelector += ", #editcardNumber";
window.ClickTalePIISelector += ", #editcardNumber.cardNumber";

// http://bat-store.three.co.uk/view/product/ql_catalog/threecatdevice/20796?referer=carousel
window.ClickTalePIISelector += ", #cmmpcid";

// refer a friend https://www.three.co.uk/refer-a-friend
window.ClickTalePIISelector += ", #login_full_name";
window.ClickTalePIISelector += ", #login_email";
window.ClickTalePIISelector += ", #login_mobile";
window.ClickTalePIISelector += ", #invite_a_friend strong";
window.ClickTalePIISelector += ", #page_show .webmail dd";

//added by rshires 1902 on 6Feb2019
window.ClickTalePIISelector += ", #invite_a_friend div div div div div h3 strong";

// checkout confirmation
window.ClickTalePIISelector += ", #orderConfirmationContainer div div div span";
window.ClickTalePIISelector += ", #orderConfirmationContainer #deliveryDetails div span";
window.ClickTalePIISelector += ", #orderConfirmationContainer #deliveryDetails div div";
window.ClickTalePIISelector += ", #orderConfirmationContainer #addSimDeliveryDetails div";
window.ClickTalePIISelector += ", #addSimDeliveryDetails";

// https://store.three.co.uk/checkout/DeliveryOptions
window.ClickTalePIISelector += ", #selectDeliveryOption_content_billingAddress div.bold";
window.ClickTalePIISelector += ", #selectDeliveryOption_content_billingAddress #billingAddressPostcode";
window.ClickTalePIISelector += ", #checkoutDeliveryOptionsComponent_deliverystore";
window.ClickTalePIISelector += ", #checkoutDeliveryOptionsComponent_phone2";
window.ClickTalePIISelector += ", #checkoutDeliveryOptionsComponent_phone2.touched";

// postcode on bat.store.three.co.uk (network lookup)
window.ClickTalePIISelector += ", #storeLocator";

// bat-store not passed credit check https://bat-store.three.co.uk/checkout/Direct_Debit_Details
window.ClickTalePIISelector += ", .creditCheckDecline div div div #address div";
window.ClickTalePIISelector += ", .creditCheckDecline";
window.ClickTalePIISelector += ", .creditCheckDecline #address";
window.ClickTalePIISelector += ", #creditCheckError_container";
window.ClickTalePIISelector += ", #orderProcessErrorContainer";
window.ClickTalePIISelector += ", #sessionlive div #address div";

// block select elements on checkout
window.ClickTalePIISelector += ", #bd select";

// block all address ids 
window.ClickTalePIISelector += ", #address";
window.ClickTalePIISelector += ", #address div";
window.ClickTalePIISelector += ", div #address div";
	
// http://test-staging-active.three.co.uk/business-mobiles
window.ClickTalePIISelector += ", .no-optional-copy .custom-select";

// http://test-staging-active.three.co.uk/Discover/Network/Coverage postcode
window.ClickTalePIISelector += ", .coverage-for .bodytext";

//personal details https://bat-store.three.co.uk/checkout/Personal_Details
window.ClickTalePIISelector += ", #main.order_mobile .span8.phone-span6";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponentPayg_firstname";
window.ClickTalePIISelector += ", #checkoutPersonalDetailsComponentPayg_lastname";

// password on London Wifi
window.ClickTalePIISelector += ", .PII";
window.ClickTalePIISelector += ", #PL039 #pl-top div.Functional-App_LUWifiRegistration.magicpassword form p";
window.ClickTalePIISelector += ", #UnlockForm .year.date";
window.ClickTalePIISelector += ", #UnlockForm .month.date";
window.ClickTalePIISelector += ", #UnlockForm .day.date";

//missing elements after pushing to Live
window.ClickTalePIISelector += ", #addressListForm .pciCardsWrapper #addressListContainer div .floatLeft div p";

window.ClickTalePIISelector += ", #ifrMiPay";
window.ClickTalePIISelector += ", #confirmCardLabel";
window.ClickTalePIISelector += ", #confirmCardSchemePanel tbody tr td span #confirmCardLabel";
window.ClickTalePIISelector += ", #confirmPaymentDetailsPanel fieldset table tbody tr td span #confirmCardLabel";
window.ClickTalePIISelector += ", #confirmCardExpiryLabel";
window.ClickTalePIISelector += ", #confirmCardSchemePanel tbody tr td span #confirmCardExpiryLabel";
window.ClickTalePIISelector += ", #confirmPaymentDetailsPanel fieldset table tbody tr td span #confirmCardExpiryLabel";

window.ClickTalePIISelector += ", #confirmCardLabelPanel";
window.ClickTalePIISelector += ", #confirmCardLabelPanel span";

window.ClickTalePIISelector += ", #confirmCscSection";
window.ClickTalePIISelector += ", #confirmCscSection span input";
window.ClickTalePIISelector += ", #confirmCscSection span #confirmCsc";

window.ClickTalePIISelector += ", #simReplaceEmail";
window.ClickTalePIISelector += ", div #simReplaceEmail";

window.ClickTalePIISelector += ", #saveCardSection p";
window.ClickTalePIISelector += ", #RegisteredCardsHolder div div.pciChooseAddress p";
window.ClickTalePIISelector += ", #RegisteredCardsHolder div div.pciChooseAddress p strong";
window.ClickTalePIISelector += ", #RegisteredCardsHolder div div.pciChooseTown span";

//added by RShires at 1340 on 07Feb2019
window.ClickTalePIISelector += ", #dialog div.step-two-dialog div div div.box.tiered-rewards-box h3 strong";
window.ClickTalePIISelector += ", #email div.webmail dl dd";
window.ClickTalePIISelector += ", #dialog div.step-two-dialog div div div div.logged-in-as div strong";
window.ClickTalePIISelector += ", #subject";
window.ClickTalePIISelector += ", #dialog div.step-two-dialog div div div.share-bar form div input";

//added by RShires at 1100 on 11Feb2019
window.ClickTalePIISelector += ", #Functional-App_OnlineUpgrades form div div.panelContent div div";
window.ClickTalePIISelector += ", #Functional-App_OnlineUpgrades form div div.panelContent div";

//added by RShires at 1250 on 11Feb2019
window.ClickTalePIISelector += ", #Functional-App_OnlineUpgrades form div div.panelContent div div span";

//added by RShires at 0250 on 13Feb2019
window.ClickTalePIISelector += ", #pl-view-name div.threePortlet.P40_id.P40_ViewMyName_w1 p strong";
window.ClickTalePIISelector += ", #pl-view-name div.threePortlet.P40_id.P40_ViewMyName_w1 p strong a";

//added by RShires at 1055 on 11Apr2019
window.ClickTalePIISelector += ", .ct-mask";

//added by RShires at 1115 on 15Apr2019 
window.ClickTalePIISelector += ", #PL037 div div #pl-top div #findAddress p";

//added by RShires at 1250 on 02Jul2019 for post Single Step TopUp work
window.ClickTalePIISelector += ", #pciCreditCardForm";
window.ClickTalePIISelector += ", #findAddress p";
window.ClickTalePIISelector += ", #findAddress p strong";
window.ClickTalePIISelector += ", #topupLoggedInDetailsContainer div.top-upLoggedIn div";
window.ClickTalePIISelector += ", #topupLoggedInDetailsContainer div div div div.pciOutstandingBalance.pciOutstandingBalanceBrand div.topupSummaryDetailContainer div.topupSummaryPhone";

window.ClickTalePIISelector += ", #topupLoggedInDetailsContainer div div div div.pciAddressSectionBrand";
window.ClickTalePIISelector += ", #successmsisdn";
window.ClickTalePIISelector += ", #successmsisdn div";
window.ClickTalePIISelector += ", #successmsisdn #threenumberValue";
window.ClickTalePIISelector += ", #threenumberValue";

window.ClickTalePIISelector += ", #topupLoggedInDetailsContainer div div.successTemplateContainer div.successTopContainer";
window.ClickTalePIISelector += ", #topupLoggedInDetailsContainer div div.successTemplateContainer div.successTopContainer div";
window.ClickTalePIISelector += ", #topupLoggedInDetailsContainer div div.successTemplateContainer div.successTopContainer div div";
window.ClickTalePIISelector += ", #topupLoggedInDetailsContainer div div.successTemplateContainer div.successTopContainer div div span";
window.ClickTalePIISelector += ", #TopupByCardDetails div.threePortlet div div div div.topupSummaryDetailContainer";

//added by RShires at 1740 on 04Jul2019 for post Single Step TopUp work
window.ClickTalePIISelector += ", #TopupByCardDetails div div.top-up div div div.topupSummaryDetailContainer";
window.ClickTalePIISelector += ", #TopupByCardDetails div div.successTemplateContainer div.successTopContainer div";
window.ClickTalePIISelector += ", #TopupByCardDetails div div div.pciRefreshWrapper div.pciOutstandingBalance div.topupSummaryDetailContainer";
window.ClickTalePIISelector += ", #addressListContainer";
window.ClickTalePIISelector += ", #pciCreditCardForm div.pciSubTextBrand";
window.ClickTalePIISelector += ", #pciCreditCardForm div.pciSubTextBrand p";
window.ClickTalePIISelector += ", #TopupByCardDetails div.top-upLoggedIn.top-upVoucherAddOnContainerLoggedIn div.top-upVoucherAddOnTop";
window.ClickTalePIISelector += ", #TopupByCardDetails div.top-upLoggedIn.top-upVoucherAddOnContainerLoggedIn div.top-upVoucherAddOnTop div.top-upVoucherAddonTopInnerEdgeBrand div";

//added by RShires at 1100 on 08Jul2019 for post Single Step TopUp work
window.ClickTalePIISelector += ", #findAddress div label";
window.ClickTalePIISelector += ", #TopupByVoucherDetails div.top-upLoggedIn.top-upVoucherAddOnContainerLoggedIn div.top-upVoucherAddOnTop div.top-upVoucherAddonTopInnerEdgeBrand div";
window.ClickTalePIISelector += ", #TopupByVoucherDetails div div.successTemplateContainer div.successTopContainer div";
window.ClickTalePIISelector += ", #TopupByCardDetails div.threePortlet div div div div.topupSummaryDetailContainer div.topupSummaryPhone";

//added by RShires at 1100 on 31Jul2019 for post Single Step TopUp work
window.ClickTalePIISelector += ", #pciCreditCardForm div";

//added by RShires at 1100 on 1Aug2019 for post Single Step TopUp work
window.ClickTalePIISelector += ", #TopupByVoucherDetails div div.successTemplateContainer div.successTopContainer div div";
window.ClickTalePIISelector += ", #TopupByVoucherDetails div div.successTemplateContainer div.successTopContainer div div span";

//added by RShires at 1200 on 5Aug2019 for post Single Step TopUp work
window.ClickTalePIISelector += ", #TopupByCardDetails div div.top-up div div.pciOutstandingBalance div.topupSummaryDetailContainer div.topupSummaryPhone";
window.ClickTalePIISelector += ", #addressListContainer div div div div";
window.ClickTalePIISelector += ", #TopupByCardDetails div div.successTemplateContainer div.successTopContainer div div";
window.ClickTalePIISelector += ", #TopupByCardDetails div div.successTemplateContainer div.successTopContainer div div span";
window.ClickTalePIISelector += ", #TopupByCardDetails div div.successTemplateContainer div.successTopContainer div div span span";

window.ClickTalePIISelector += ", #pciCreditCardForm div p";

//window.ClickTalePIISelector += ", ";
//window.ClickTalePIISelector += ", ";
//window.ClickTalePIISelector += ", ";



console.log("Clicktale-PII-DTM-Launched");

});
