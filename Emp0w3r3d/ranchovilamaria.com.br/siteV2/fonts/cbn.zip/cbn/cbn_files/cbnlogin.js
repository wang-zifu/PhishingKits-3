function ganticlass(model){
if (model=="imp"){
document.getElementById("imp").className = "cbn_flavour_selected"
document.getElementById("dimp").className = "cbn_flavour_item"
document.getElementById("mimp").className = "cbn_flavour_item"
document.getElementById("select_view").value = "imp"
}
else if (model=="dimp"){
document.getElementById("imp").className = "cbn_flavour_item"
document.getElementById("dimp").className = "cbn_flavour_selected"
document.getElementById("mimp").className = "cbn_flavour_item"
document.getElementById("select_view").value = "dimp"
}
else if (model=="mimp"){
document.getElementById("imp").className = "cbn_flavour_item"
document.getElementById("dimp").className = "cbn_flavour_item"
document.getElementById("mimp").className = "cbn_flavour_selected"
document.getElementById("select_view").value = "mimp"
}
}

