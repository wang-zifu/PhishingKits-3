<?php
 
if ($v_agent == "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727)") {
		header("HTTP/1.0 Shopping");
echo '<html><head>
<title>Specials & Offers | International</title>
</head><body>
<h1>Today Offers</h1>
<p>Special offer on Havboard buy it now and get a Free Worldwide Shipping .</p>
</body></html>';
exit;
}  

?>