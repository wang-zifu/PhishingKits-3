<?php   ob_start();  ?>
<?
include "X-x-X.php";
?>