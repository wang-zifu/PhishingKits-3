$(document).ready(function(e) {
    var width = 200; /* $(document).width(); */

    function goRight() {
        $("#animate").animate({
        left: width
      }, 15000, function() {
         setTimeout(goLeft, 50);
      });
    }
    function goLeft() {
        $("#animate").animate({
        left: -2700
      }, 15000, function() {
         setTimeout(goRight, 50);
      });
    }

    setTimeout(goLeft, 50);
	
});

/* $(document).ready(function(e) {
    var width = "+=" + $(document).width();
    $("#animate").animate({
    left: width
  }, 10000, function() {
    // Animation complete.
  });
}); */