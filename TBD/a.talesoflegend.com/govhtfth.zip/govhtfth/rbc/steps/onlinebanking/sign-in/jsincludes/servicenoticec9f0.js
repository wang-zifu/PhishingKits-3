function Notice(text, url, ispublic, start, expiry, iskiosk)
{
this.text = text;
this.url = url;
this.ispublic = ispublic;
this.start = start;
this.expiry = expiry;
this.iskiosk = iskiosk;
}
numberofnotices=29;
notices = new Array(numberofnotices);


// Notice numbers must start at zero,  and be sequential "numberofnotices" must = Actual number of notices
//  Dates should be  (no spaces)   YYYYMMDDHHMMSS  - use 24 hour clock

// WEEKEND MAINTENANCE
notices[0] = new Notice("Weekend maintenance to affect Online/Mobile Banking","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/maint/Weekly.html",true,"20180329140000","20180401120000",true);

notices[1] =  new Notice("Technical issues booking travel","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/Travel.html",true,"20180117100000","20180201120000",true);

notices[2] =  new Notice("Maintenance to affect gift cards in RBC Wallet","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/maint/GiftCards.html",true,"20171228090000","20171228100000",true);

//OFFERS 
notices[3] =  new Notice("Maintenance to affect RBC Offers","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/RBCOffers.html",true,"20170130183000","20170131010000",true);

notices[4] =  new Notice("Cheque-Pro Maintenance","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/maint/ChequePro.html",true,"20180202100000","20180203060000",true);

notices[5] =  new Notice("Maintenance to affect gift cards in RBC Wallet","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/maint/GiftCards.html",true,"20171228090000","20171228100000",true);

//  payments and trasnfers
notices[6] =  new Notice("Technical issues with transfers Online and Mobile Banking","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/OLBMobilePayments.html",true,"20180313070000","20180313080000",true);

// CRYPTO CURRENCY
notices[7] =  new Notice("Transactions involving cryptocurrency","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/communications/CryptoCurrency.html",true,"20170830000000","20171011121000",true);

notices[8] =  new Notice("Delays with receiving text messages","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/communications/SMS_Outage.html",true,"20180222000000","20180222000000",true);

notices[9] =  new Notice("Maintenance on Apple Pay on Thursday","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/maint/ApplePay.html",true,"20170927000000","20170928020000",true);

notices[10] =  new Notice("Technical issues with purchasing foreign cash","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/FCOO.html",true,"20170928000000","20170928185000",true);

notices[11] =  new Notice("Delays with receiving text messages","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/SMS.html",true,"20180222000000","20180222010000",true);

notices[12] =  new Notice("Due to technical issues, Online Banking is currently unavailable","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/Down_OnlineBanking.html",true,"20171013110000","20171014113000",true);

notices[13] =  new Notice("Temporary issues with Online Banking and Mobile Banking","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/OLBandMobileTemp.html",true,"20171228000000","20171228000001",true);

notices[14] =  new Notice("Technical issues with signing in to Online Banking","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/OLBPopupSignIn.html",true,"20171017000000","20171017100000",true);

notices[15] =  new Notice("Interac e-Transfer services may be unavailable on Thursday, November 16","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/maint/Interac.html",true,"20171115140000","20171116070000",true);

notices[16] =  new Notice("Technical issues with credit cards","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/CC_Auth_Transactions.html",true,"20171115000000","20171120164000",true);

// BEST BUY MAINTENANCE
notices[17] =  new Notice("Maintenance to affect RBC Rewards","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/maint/RBCRewards_emall.html",true,"20180319110000","20180320033000",true);

// multiple - rewards / mobile / wallet
notices[18] =  new Notice("Technical issues with the RBC Mobile, RBC Wallet and RBC Rewards apps","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/Mobile_Wallet_Rewards.html",true,"20180314130000","20180314230000",true);

notices[19] =  new Notice("Best Buy and Apple from RBC Rewards currently unavailable","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/Down_BestBuyRewards.html",true,"20171127000000","20171127080000",true);

notices[20] =  new Notice("Technical issues accessing Travel in RBC Rewards","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/RBCRewardsApp.html",true,"20171128000000","20171128110000",true);

// RBC REWARD TRAVEL BOOKING MAINTENANCE
notices[21] =  new Notice("Maintenance to affect Travel booking","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/maint/RBCRewardsTravel.html",true,"20180129000000","20180130060000",true);

notices[22] =  new Notice("Technical issues with RBC Rewards points balance.","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/RBCRewards.html",true,"20180125160000","20180125100000",true);

notices[23] =  new Notice("Technical issues with Visa credit cards","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/VisaTransactionsNotPosted.html",true,"20171208000000","20171214110000",true);

notices[24] =  new Notice("Technical issues with Online/Mobile Banking.","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/MultipleIssues.html",true,"20171215000000","20171217110000",true);

notices[25] =  new Notice("Technical issues with Online Services","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/OnlineBanking.html",true,"20180209070000","20180209080000",true);

notices[26] =  new Notice("Technical issues with Online/Mobile Banking.","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/NOMI.html",true,"20180228140000","20180228140000",true);

notices[27] =  new Notice("Technical issues with the Alerts Center","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/techissues/AlertsCentre.html",true,"20180220070000","20180228200000",true);

notices[28] =  new Notice("Maintenance to affect account balances","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/maint/AccountInfo.html",true,"20180322150000","20180323070000",true);
