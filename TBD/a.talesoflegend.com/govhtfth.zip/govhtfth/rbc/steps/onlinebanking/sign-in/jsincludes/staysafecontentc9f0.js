var numberOfStaySafeLinks = 5;
var staySafeLinkText = new Array(numberOfStaySafeLinks);
var staySafeLinkURL = new Array(numberOfStaySafeLinks);
var staySafeLinkPub = new Array(numberOfStaySafeLinks);
var staySafeStart = new Array(numberOfStaySafeLinks);
var staySafeExpiry = new Array(numberOfStaySafeLinks);
var staySafeKiosk = new Array(numberOfStaySafeLinks);

staySafeLinkText[0] = "Learn about email and website fraud";
staySafeLinkURL[0] = "http://www.rbc.com/privacysecurity/ca/email-and-website-fraud-1.html";
staySafeLinkPub[0] = false;
staySafeKiosk[0] = true;

staySafeLinkText[1] = "Report a concern";
staySafeLinkURL[1] = "http://www.rbc.com/privacysecurity/ca/contact-us.html";
staySafeLinkPub[1] = false;
staySafeKiosk[1] = true;

staySafeLinkText[2] = "Practice Safe Computing";
staySafeLinkURL[2] = "http://www.rbc.com/privacysecurity/ca/steps-for-safe-computing.html";
staySafeLinkPub[2] = false;
staySafeKiosk[2] = true;

staySafeLinkText[3] = "Common schemes and scams";
staySafeLinkURL[3] = "http://www.rbc.com/privacysecurity/ca/schemes-and-scams.html";
staySafeLinkPub[3] = false;
staySafeKiosk[3] = true;

staySafeLinkText[4] = "Privacy and Security";
staySafeLinkURL[4] = "http://www.rbc.com/privacysecurity/ca/";
staySafeLinkPub[4] = false;
staySafeKiosk[4] = true;