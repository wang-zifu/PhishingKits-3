function Notice(text, url, ispublic, start, expiry, iskiosk)
{
this.text = text;
this.url = url;
this.ispublic = ispublic;
this.start = start;
this.expiry = expiry;
this.iskiosk = iskiosk;
}
numberofnotices=8;
notices = new Array(numberofnotices);


notices[0] =  new Notice("Support for our clients affected in Fort McMurray","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/Fort_McMurray.html",true,"20151020","20160601",true);

notices[1] =  new Notice("A new look for the RBC Direct Investing online investing site","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/important_notice_di_prelaunch.html",true,"20151102","20160415",true);

notices[2] =  new Notice("Cheque-Pro Online Banking Unavailable","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/chequepro.html",true,"20160120","20160405",true);

notices[3] =  new Notice("Technical issues viewing account transactions","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/tech_transactions.html",true,"20160101","20160330",true);

notices[4] =  new Notice("The Online Banking design has changed","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/important_notice_olblaunch.html",true,"20151020","20160127",true);

notices[5] =  new Notice("Issues with US Dollar Visa Gold online payments","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/important_notice_USVisa.html",true,"20151020","20160207",true);

notices[6] =  new Notice("We've made improvements to the new RBC<sup>&reg;</sup> Online Banking","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/OLB_refreshFeb9.html",true,"20150521","20160219",true);

notices[7] =  new Notice("Online/Mobile Banking currently unavailable","https://www1.royalbank.com/onlinebanking/bankingusertips/notices/Down_OLB_Mobile.html",true,"20151031","20151120",true);

