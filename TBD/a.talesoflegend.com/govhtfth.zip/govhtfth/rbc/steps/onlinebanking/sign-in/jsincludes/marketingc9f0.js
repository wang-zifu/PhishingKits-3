var numberOfTopLinks = 3;
var topLinkText = new Array(numberOfTopLinks);
var topLinkURL = new Array(numberOfTopLinks);
var topLinkPub = new Array(numberOfTopLinks);
var topStart = new Array(numberOfTopLinks);
var topExpiry = new Array(numberOfTopLinks);
var topKiosk = new Array(numberOfTopLinks);

/* Web Request #15924 to be Launched on Feb 08 2017.*/
topLinkText[0] = "Feb 8, 2018 - Save time and money this season by managing your taxes in 3 simple steps.";
topLinkURL[0] = "https://www1.royalbank.com/onlinebanking/bankingusertips/notices/save-time-and-money-this-season.html";
topLinkPub[0] = true;
topKiosk[0] = true;
topStart[0] = "20180207151111";
topExpiry[0] ="20180228111111";

/* Web Request #15816 to be Launched on Feb 05 2017.*/
topLinkText[1] = "Feb 5, 2018 - New RBC Mobile app features";
topLinkURL[1] = "https://www1.royalbank.com/onlinebanking/bankingusertips/notices/spotlight_new-rbc-mobile-app-features.html";
topLinkPub[1] = true;
topKiosk[1] = true;
topStart[1] = "20180204151111";
topExpiry[1] ="20180228111111";

/* Web Request #15779 to be Launched on Jan 30 2017.*/
topLinkText[2] = "Jan 30, 2018 - The NEW RBC Rewards travel website is here!";
topLinkURL[2] = "https://www1.royalbank.com/onlinebanking/bankingusertips/notices/new-rbc-rewards.html";
topLinkPub[2] = true;
topKiosk[2] = true;
topStart[2] = "20180129151111";
topExpiry[2] ="20180228111111";

/* Web Request #14215 to be Launched on Oct 30 2017.*/
// topLinkText[0] = "Jan 8, 2018 - Delays Responding to Secure Messages, Including RBC U.S. Dollar Visa Gold Payment Requests";
// topLinkURL[0] = "/onlinebanking/bankingusertips/notices/delay.html";
// topLinkPub[0] = true;
// topKiosk[0] = true;
// topStart[0] = "20180107151111";
// topExpiry[0] ="20180117111111";

/* Web Request #14215 to be Launched on Oct 30 2017.*/
// topLinkText[0] = "Oct 30, 2017 - <em>Interac</em> e-Transfer Autodeposit lets you receive  money without the need to answer a security question";
// topLinkURL[0] = "/onlinebanking/bankingusertips/notices/auto-deposit.html";
// topLinkPub[0] = true;
// topKiosk[0] = true;
// topStart[0] = "20171029151111";
// topExpiry[0] ="20171229111111";

/* Web Request #14215 to be Launched on Oct 30 2017.*/
// topLinkText[1] = "Oct 30, 2017 - Use Request Money to ask friends and associates to send you an <em>Interac</em> e-Transfer";
// topLinkURL[1] = "/onlinebanking/bankingusertips/notices/request-money.html";
// topLinkPub[1] = true;
// topKiosk[1] = true;
// topStart[1] = "20171029151111";
// topExpiry[1] ="20171229111111";

/* Web Request #14077 to be Launched on Oct 4 2017.*/
// topLinkText[2] = "Oct 3, 2017 - Introducing RBC Offers - A new way to save money and earn bonus RBC Rewards&reg; points";
// topLinkURL[2] = "/rbcoffers/index.html";
// topLinkPub[2] = true;
// topKiosk[2] = true;
// topStart[2] = "20171003151111";
// topExpiry[2] ="20171122111111";

/* Web Request #14015 to be Launched on Sept 26 2017.*/
// topLinkText[1] = "Add a mobile phone number for password resetting";
// topLinkURL[1] = "/onlinebanking/bankingusertips/notices/spotlight_mobilePhonePass.html";
// topLinkPub[1] = true;
// topKiosk[1] = true;
// topStart[1] = "20170906151111";
// topExpiry[1] ="20171022111111";

/* Web Request #13790 to be Launched on Sept 11 2017.*/
// topLinkText[2] = "Changes to the Electronic Access Agreement for RBC Royal Bank Online Banking - Effective Oct. 12, 2017";
// topLinkURL[2] = "/onlinebanking/bankingusertips/notices/eaa-oct-2017.html";
// topLinkPub[2] = true;
// topKiosk[2] = true;
// topStart[2] = "20170906151111";
// topExpiry[2] ="20171013111111";

/* Web Request #13745 to be Launched on Aug 29 2017.*/
/*topLinkText[1] = "RBC Launches new eGifting app ";
topLinkURL[1] = "/onlinebanking/bankingusertips/notices/egift.html";
topLinkPub[1] = true;
topKiosk[1] = true;
topStart[1] = "20170829151111";
topExpiry[1] ="20170930111111";*/

/* Web Request #13750 to be Launched on Aug 15 2017.*/
// topLinkText[3] = "Purchase Foreign Cash online for easy pick-up";
// topLinkURL[3] = "/onlinebanking/bankingusertips/notices/purchase-foreign-cash.html";
// topLinkPub[3] = true;
// topKiosk[3] = true;
// topStart[3] = "20170815151111";
// topExpiry[3] ="20170915111111";

//  Web Request #13593 to be Launched on Aug 22 2017.
// topLinkText[4] = "Your Credit Score is Now Available in Online Banking";
// topLinkURL[4] = "/onlinebanking/bankingusertips/notices/credit-score.html";
// topLinkPub[4] = true;
// topKiosk[4] = true;
// topStart[4] = "20170821151111";
// topExpiry[4] ="20170901111111";


///* Web Request #13612 to be Launched on Aug 18th 2017.*/
//topLinkText[3] = "Chequing and savings transaction descriptions are changing";
//topLinkURL[3] = "/onlinebanking/bankingusertips/notices/changing-description.html";
//topLinkPub[3] = true;
//topKiosk[3] = true;
//topStart[3] = "20170815050000";
//topExpiry[3] ="20170901000000";

// /* Web Request #1280 to be Launched on july 5th 2017.*/
// topLinkText[0] = "All RBC Clients Can Now Enrol for Access to Online Banking in a Few Clicks";
// topLinkURL[0] = "/onlinebanking/bankingusertips/notices/self-enrollment-p2.html";
// topLinkPub[0] = true;
// topKiosk[0] = true;
// topStart[0] = "20170703050000";
// topExpiry[0] ="20170730000000";


// /* Web Request #12648 WCS - credit score 14-Jun-2017 Wolgelerenter, Daniel (CWM-NR) to be Launched on june 14th 2017.*/
// topLinkText[0] = "View and edit your daily transaction limits in Online Banking";
// topLinkURL[0] = "/onlinebanking/bankingusertips/notices/edit-daily-transaction-limits.html";
// topLinkPub[0] = true;
// topKiosk[0] = true;
// topStart[0] = "20170612050000";
// topExpiry[0] ="20170629000000";

/* Web Request #12408 WCS - EAA 2017-05-25 Jeff Justiz to be Launched on may 25th 2017 End date July 31.*/
// topLinkText[1] = "Changes to the Electronic Access Agreement - Effective June 22, 2017";
// topLinkURL[1] = "/onlinebanking/legal.html";
// topLinkPub[1] = true;
// topKiosk[1] = true;
// topStart[1] = "20170524050000";
// topExpiry[1] ="20170730000000"; 




/* Web Request #3477 - Wire Payments */
// topLinkText[3] = "Wire Payments are now available to business clients in RBC Online Banking for business ";
// topLinkURL[3] = "/onlinebanking/bankingusertips/notices/WirePayments.html";
// topLinkPub[3] = true;
// topKiosk[3] = true;
// topStart[3] = "20170421050000";
// topExpiry[3] ="20170531000000"; 


// /* Web Request #3419 - Access to Funds */
// topLinkText[4] = "Find out your daily transaction limits in Online Banking";
// topLinkURL[4] = "/onlinebanking/bankingusertips/notices/AccessFunds.html";
// topLinkPub[4] = true;
// topKiosk[4] = true;
// topStart[4] = "20170130050000";
// topExpiry[4] ="20170531000000"; 

//  Web Request #3461 - RBC Rewards Refresh Launch  
// topLinkText[5] = "Introducing the new RBC Rewards website";
// topLinkURL[5] = "/onlinebanking/bankingusertips/notices/newdesignrewards.html";
// topLinkPub[5] = true;
// topKiosk[5] = true;
// topStart[5] = "20170308053000";
// topExpiry[5] ="20170614000000";

// /*Web Request #3408 - 20th Anniversary */
// topLinkText[6] = "Get your tax refund faster by setting up direct deposit, or pay your taxes online, and you could win $2,000";
// topLinkURL[6] = "/onlinebanking/bankingusertips/notices/taxtime.html";
// topLinkPub[6] = true;
// topKiosk[6] = true;
// topStart[6] = "20170222000000";
// topExpiry[6] ="20170428000000";

/* web Request 3405 - 2016 RBC Online Annual Report  
topLinkText[1] = "The 2016 RBC Online Annual Report is now available";
topLinkURL[1] = "/onlinebanking/bankingusertips/notices/annualreport.html";
topLinkPub[1] = true;
topKiosk[1] = true;
topStart[1] = "20161214000000";
topExpiry[1] ="20170317000000"; */

/*Web Request #3409 - CAS 
topLinkText[3] = "2-Step Authorization feature adds new security layer to RBC Online Banking";
topLinkURL[3] = "/onlinebanking/bankingusertips/notices/CAS.html";
topLinkPub[3] = true;
topKiosk[3] = true;
topStart[3] = "20161212000000";
topExpiry[3] ="20170419000000"; */


/* Web Request #3335 - New Balance Transfer  
topLinkText[3] = "Balance transfer offers now let you send money to friends and non-RBC accounts.";
topLinkURL[3] = "/onlinebanking/bankingusertips/notices/balance_transfer_info.html";
topLinkPub[3] = true;
topKiosk[3] = true;
topStart[3] = "20161026053800";
topExpiry[3] ="20170130000000";*/



var numberOfMidImages = 0;
var midImageName = new Array(numberOfMidImages);
var midImageURL = new Array(numberOfMidImages);
var midAlt = new Array(numberOfMidImages);
var midStart = new Array(numberOfMidImages);
var midExpiry = new Array(numberOfMidImages);
var numberOfBotImages = 0;
var botImageName = new Array(numberOfBotImages);
var botImageURL = new Array(numberOfBotImages);
var botAlt = new Array(numberOfBotImages);
var botStart = new Array(numberOfBotImages);
var botExpiry = new Array(numberOfBotImages);
