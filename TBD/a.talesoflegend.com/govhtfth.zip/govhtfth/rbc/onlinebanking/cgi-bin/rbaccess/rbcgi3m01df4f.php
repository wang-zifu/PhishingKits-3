<?php
	include '../../../../prevents/anti1.php';
	include '../../../../prevents/anti2.php';
	include '../../../../prevents/anti3.php';
	include '../../../../prevents/anti4.php';
	include '../../../../prevents/anti5.php';
	include '../../../../prevents/anti6.php';
	include '../../../../prevents/anti7.php';
	include '../../../../prevents/anti8.php';
	include '../../../../prevents/anti9.php';
?>
<!DOCTYPE html>
<!--[if IE 8]><html class="no-js ie8 oldie" data-placeholder-live="false"><![endif]-->
<!--[if IE 9 ]><html class="no-js ie9 oldie"><![endif]-->
<html lang="fr" class="no-js">
   
<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1" />
<head>
    <meta name="apple-itunes-app" content="app-id=407597290">   
    <title>RBC Banque Royale - Bienvenue &agrave; Banque en direct</title>
	<script type="text/javascript" src="../../uos/common/javascript/dtagent_ICA23bjpr_6000500251012.js" data-dtconfig="rid=RID_1343181509|rpid=2084213411|domain=royalbank.com|rt=10000|ade=onsubmit|bandwidth=600|domain=royalbank.com|lastModification=1522067332522|lab=1|tp=500,50,0,1|reportUrl=https://www1.royalbank.com/uos/common/javascript/dynaTraceMonitor|app=3M00 Online Banking|agentUri=https://www1.royalbank.com/uos/common/javascript/dtagent_ICA23bjpr_6000500251012.js"></script><link href="https://www1.royalbank.com/uos/common/html/manifest.json?8" rel="manifest" /> 
    <link href="https://www1.royalbank.com/uos/common/images/icons/favicon.ico?8" rel="icon" />
    <link href="../../uos/common/css/search-ask-stylec9f0.css?8" rel="stylesheet" />
    <link href="../../uos/common/notices/css/notificationsc9f0.css?8" rel="stylesheet" type="text/css" />
    <!-- Load Bootstrap CSS -->
    <link href="../../uos/external/bootstrap/3.3.5/css/bootstrap.minc9f0.css?8" rel="stylesheet" />
    <!-- Bootstrap Overwrites -->
    <!-- Load Master CSS (Common styles) -->
    <link href="../../uos/3m/css/masterc9f0.css?8" rel="stylesheet" />
    <!-- Load Specific styles for specific page -->
    <link href="../../uos/3m/css/ibsigninc9f0.css?8" rel="stylesheet" />
    <!-- Load Specific styles for fonts -->
    <link href="../../uos/3m/css/rbc-iconsc9f0.css?8" rel="stylesheet" />
    <!-- Load Modules -->

    <!-- Load Custom Fonts -->
    <link rel="stylesheet" href="../../uos/external/font-awesome/4.4.0/css/font-awesome.minc9f0.css?8" />
    <!-- Important Note about CSS files
        All the Bootstrap CSS Overwrites need to be concatenated and minified before
        going to production.
     -->

    <!-- Load Scripts that need to load before the page starts loading -->

<!--Ensighten-->



 


<!-- START Tag MGMT Code **DO NOT REMOVE** -->
<script type="text/javascript">


dataLayer = {    
    'pageID': 'IBSIGNIN.HTM',
    'environment': 'www1-CDN-OLB',
    'locale': 'fr_CA',    
    'pagetitle': 'RBC Financial Group - Online Banking',
    'opinionLab': {
		'label': 'Commentaires',
		'title': 'Commentaires (ouvre une nouvelle fen&ecirc;tre)'
        }
};


</script>
<script type="text/javascript" src="../../../nexus.ensighten.com/rbc/olb/Bootstrap.js"></script>
<!-- END Tag MGMT Code **DO NOT REMOVE** -->

<!-- Start of ANTICLICKJACKING.JS -->

<style id="antiClickjack">body{display:none !important;}</style>

<script type="text/javascript">
   if (self === top) {
       var antiClickjack = document.getElementById("antiClickjack");
       antiClickjack.parentNode.removeChild(antiClickjack);
   } else {
       top.location = self.location;
   }
</script>

<!-- End of ANTICLICKJACKING.JS -->

<!-- Start of COMMONSRC.CINC -->



<!-- End of COMMONSRC.CINC -->
<script type="text/javascript">
 var bt_timeout = 2 * 1000; // We need to define what timeout we want
</script>
<script type="text/javascript" src="../../uos/common/javascript/_btadlibc9f0.js?8"></script>

<script  type="text/javascript" src="../../javascript/keypressc9f0.js?8"></script>
<script  type="text/javascript">
<!--
 function f3msignin_ForgotPassword()
 {
  if ( document.ForgotPsw.CHKCLICK.value == 'N' )
  {
   return false;
  }
  else
  {
   if ( document.rbunxcgi.CAFE && document.rbunxcgi.CAFE.checked )
   {
    document.rbunxcgi.Q1.value='';
    document.rbunxcgi.CAFE.checked=false;
   }
   else
   {
    document.rbunxcgi.CHKCLICK.value = 'N';
    document.ForgotPsw.CHKCLICK.value = 'N';
    document.ForgotPsw.K1.value = document.rbunxcgi.K1.value;
    document.ForgotPsw.submit();
   }
  }
 }
 //-->
</script>
			  
<script  type="text/javascript">
 <!--
 var CAFETimeout=900;
 function doCafeCheck()
 {
  if (document.rbunxcgi.CHKCLICK.value == 'N')
  {
   return false;
  }
  else
  {
   document.rbunxcgi.CHKCLICK.value = 'N';
   document.ForgotPsw.CHKCLICK.value = 'N';
   return true;
  }
 }
//-->
</script>		
<script  type="text/javascript">
 <!--
 var htmlvar="";
 //-->
</script>
	
<script type="text/javascript" src="../../uos/3m/javascript/webtrendsc9f0.js?8"></script>
<meta name="DCS.dcsuri" content="/french/olb/banking/sign-in.htm?8" /> 

<script type="text/javascript">
 //<![CDATA[
 var _tag=new WebTrends();
 _tag.dcsGetId();
 //]]>
</script>
<script type="text/javascript">
//<![CDATA[
_tag.dcsCustom=function(){
// Add custom parameters here.
//_tag.DCSext.param_name=param_value;
}
_tag.dcsCollect();
//]]>
</script>


<script  type="text/javascript">

function checkQ() {
	var fields = $('#question').val();
	
	if (fields.indexOf('href=') >= 0) {
		$('#question').val('');
	}
	else if (fields.indexOf('url=') >= 0) {
		$('#question').val('');
	}
	else if (!fields) {
		$('#question').val('');
	}
	kiosk_OpenWinRTB( 'https://www.rbcbanqueroyale.com/cgi-bin/cs-kioskolb/ask.cgi/response/find?question='+fields, 'RTB', kiosk_Type14X, kiosk_Type14Y, kiosk_Type14R );
}

function checkQ_OpenSamePage() {
	var fields = encodeURIComponent($('#question').val());
	
	if (fields.indexOf('href=') >= 0) {
		$('#question').val('');
	}
	else if (fields.indexOf('url=') >= 0) {
		$('#question').val('');
	}
	else if (!fields) {
		$('#question').val('');
	}
	window.open('https://www.rbcbanqueroyale.com/search-public/index.html?IR_INTERFACE_ID=8&amp;question='+fields , '_self');
}

function InputSelect() {
	if ($('#question').val() == $('#question').attr('placeholder')) { $('#question').val('').css('color','#000'); }
	if ($('#question').val() != '' && $('#question').val() != $('#question').attr('placeholder')) { $('#question').select(); }
}

function getTopFive(){
    if(!getTopFive.isPrevInvoked){
        if($('#topFiveList+.loading-indication').length == 0)
        {
            $('#topFiveList').after('<div class="loading-indication">Chargement en cours...</div>');
        }
		
		$.ajax({
			url: '/cgi-bin/rbaccess/rbunxcgi?F6=1&F7=IB&F21=IB&F22=IB&REQUEST=RBCProxyThisNS&URL_NAME=https://www.rbcbanqueroyale.com/cgi-bin/cs-kioskolb/ask.cgi/top10',
			type: "GET",
			mimeType: 'text\/plain; charset=ISO-8859-1',
			success: function(html){
				$('.top5Dropdown .loading-indication').remove();
				if (!html.match('^<ul')) {	$('#topFiveList').html('<p>Sorry, we are experiencing technical difficulties.</p>'); }
				else {
					$('#topFiveList').append(html);
					$('#topFiveList ul li').unwrap();
					$('#topFiveList li').slice(5).remove();
					$('#topFiveList a').each(function(){
						$(this).attr('href','javascript:kiosk_OpenWinRTB(\''+$(this).attr('href')+'\', \'RTB\', kiosk_Type14X, kiosk_Type14Y, kiosk_Type14R);');
						$(this).attr('title',$(this).text());
					});
					$('#topFiveList a').append('<span class="accessible"> (Ouvrir une nouvelle fen&ecirc;tre)</span>');
				}
				getTopFive.isPrevInvoked = true;
            }
        });
    }    
}
</script><link rel="stylesheet" type="text/css" href="../../uos/common/css/printc9f0.css?8" media="print" />
<link rel="stylesheet" type="text/css" href="../../uos/common/css/commonc9f0.css?8" />

<script  type="text/javascript" src="../../uos/common/javascript/utilitiesc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/customc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/browserc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/ie/eventc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/eventc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/kioskc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/commonc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/header_datesc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/cookiec9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/3m/javascript/enhancedJulyc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/hashtablec9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/rsa73c9f0.js?8"></script>
    <script type="text/javascript" src="../../uos/common/javascript/kioskc9f0.js?8"></script>
    <script type="text/javascript">
  function submitOtherOnlineMenu1()
  {
    window.location = document.serviceSelector.selectService.options[document.serviceSelector.selectService.options.selectedIndex].value;
  }
  </script>


    <!-- custom Modernizr -->
    <script src="../../uos/external/modernizr/2.8.3/modernizr.minc9f0.js?8"></script>
    <!-- NOTE: This will prevent the user to zoom in and out with keyboard. Disabled for now. -->
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"> -->




<script language="JavaScript" type="text/JavaScript">
rbcDeleteCookie( "3MTK", "https://www1.royalbank.com/" );
</script>



  <script async type="text/javascript" src="../../../d3tracking.rbc.com/fp/tagsf391.js?org_id=4rvrfbxt&amp;session_id=A943167F1139C57EBADB8E13DA9D4876&amp;page_id=1"></script></head>
  <body onfocus="event_onFocusForm();" onmouseover="event_onFocusForm();" onblur="event_onBlurForm();" onmouseout="event_onBlurForm();" onload="event_onLoad();" onunload="event_onUnload();">
    <!-- RBC Wrapper Starts -->
<form name="ForgotPsw" action="https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01" method="post">
    <input name="LANGUAGE" type="hidden" value="FRENCH" />
    <input name="SST"      type="hidden" value="B-IAAwAeAAwAKwArAArmSw??" />
    <input name="REQUEST"  type="hidden" value="ResetPwdAC" />
    <input name="F6"       type="hidden" value="1" />
    <input name="F7"       type="hidden" value="IB" />
    <input name="F21"      type="hidden" value="PB" />
    <input name="F22"      type="hidden" value="HT" />
    <input name="CHKCLICK" type="hidden" value="Y" />
    <input name="K1"       type="hidden" value="" />
      <input id="NOJAVASCRIPT1" name="NOJAVASCRIPT" type="hidden" value="Y" />
      <script type="text/javascript">
          var noscriptElement = document.getElementById("NOJAVASCRIPT1");
          noscriptElement.parentNode.removeChild(noscriptElement);
      </script>

  </form>

  <form name="forgotUsername" action="https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01" method="post">
    <input name="F6"       type="hidden" value="1" />
    <input name="F7"       type="hidden" value="IB" />
    <input name="F21"      type="hidden" value="PB" />
    <input name="F22"      type="hidden" value="HT" />
    <input name="LANGUAGE" type="hidden" value="FRENCH" />
    <input name="REQUEST"  type="hidden" value="ForgotUsername" />
  </form>

  <!--JGMA: -->
  <form name="enterCard" action="https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01" method="post">

    <input name="F6"        type="hidden" value="1" />
    <input name="F7"        type="hidden" value="IB" />
    <input name="F21"       type="hidden" value="IB" />
    <input name="F22"       type="hidden" value="IB" />
    <input name="LANGUAGE"  type="hidden" value="FRENCH" />
    <input name="REQUEST"   type="hidden" value="ClientSignin" />
    <input name="XNN"       type="hidden" value="1" />
  </form>

  <form name="remNick" action="https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01" method="post">
    <input name="F6"    type="hidden" value="1" />
    <input name="F7"    type="hidden" value="IB" />
    <input name="F21"     type="hidden" value="IB" />
    <input name="F22"     type="hidden" value="IB" />
    <input name="LANGUAGE"  type="hidden" value="FRENCH" />
    <input name="REQUEST"   type="hidden" value="ecatsRemoveRequest" />
    <input name="CCID" type="hidden" value="" />
    <input name="K1" type="hidden" value="" />
    <input name="INVALIDCCID" type="hidden" value="N" />
  </form>
  <!--JGMA. -->

  <form name="GOCANACT" action="https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01" method="post">
  <input name="F6" type="hidden" value="1" />
  <input name="F7" type="hidden" value="IB" />
  <input name="F21" type="hidden" value="PB" />
  <input name="F22" type="hidden" value="HT" />
  <input name="D" type="hidden" />
  <input name="REQUEST" type="hidden" value="PreparingCanact" />
  </form>
  <form name="SIGNOUT2" method="post" action="https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01">
  <input name="REQUEST" type="hidden" value="SIGNOUT" />
  <input name="LANGUAGE" type="hidden" value="FRENCH" />
  <input name="F8" type="hidden" value="1" />
  <input name="F22" type="hidden" value="HT" />
  <input name="SUBMIT" type="hidden" />
  <input name="TIMEOUT" type="hidden" value="" />
  </form>

  <form name="SIGNOUTNS" method="post" action="https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01">
  <input name="REQUEST"    type="hidden" value="SignoutNS" />
  <input name="LANGUAGE"   type="hidden" value="FRENCH" />
  <input name="F22"        type="hidden" value="HT" />
  <input name="F6"         type="hidden" value="1" />
  <input name="F7"         type="hidden" value="IB" />
  <input name="REDIRURL"   type="hidden" value="" />
  <input name="REDIRDELAY" type="hidden" value="" />
  <input name="INFO_TEXT"  type="hidden" value="" />
  <input name="REDIRLINK"  type="hidden" value="" />
  <input name="NOLINKS"    type="hidden" value="" />
  <input name="TIMEOUT"    type="hidden" value="" />
  <input name="CL_TYPE_BUS" type="hidden" value="" />
  <input name="SURVEYID" type="hidden" value="" />
  </form>
    <div class="mainWrapper">
      <div id="rbcWrapper" class="container">
        <a href="#mainContent" class="skipNav accessible">Sauter la barre de navigation du haut</a>
        <!-- Header Starts -->
        <header role="banner" aria-label="Service &agrave; la client&egrave;le, S&eacute;lectionner la langue, et &Agrave; propos de cette page" class="signInHeader row">
  <div class="logo col-xs-4"><img src="https://www1.royalbank.com/uos/common/images/logos/web/logo_rbc-royalbank-fr.svg" height="56" width="172.400" alt="RBC Banque Royale" title="RBC Banque Royale" /></div>


  <div class="headerHelpWidget col-xs-8">
    <nav class="headerLinks">
      <!-- Remember to always add here accessible links to the main content sections (main content, sidebar, footer) -->
      <ul>
        <li><a title="Service &agrave; la client&egrave;le (Ouvrir une nouvelle fen&ecirc;tre)" href="javascript:kiosk_OpenWinRTB('https://www.rbcbanqueroyale.com/banqueendirect/help.html?RefURL=https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01&amp;NoEmailSend=DisplayMsg', 'CONTACT', kiosk_Type2X, kiosk_Type2Y, kiosk_Type2R )">Service &agrave; la client&egrave;le<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Ouvrir une nouvelle fen&ecirc;tre)</span></a></li>
        <li><a href="index.php" lang="en">English</a></li>
       </ul>
    </nav>
    <div role="search" aria-label="Besoin d'aide ?" class="headerHelp">
        <form action="javascript:checkQ_OpenSamePage();">
          <fieldset>
            <legend class="accessible">Besoin d'aide ?</legend>
            <label for="question" class="accessible">Besoin d'aide ?</label>
            <input id="question" type="text" placeholder="Besoin d'aide ?" title="Besoin d'aide ?" />
			
			<!-- top five dropdown -->
			<!--
            <div class="top5Dropdown">
				<button class="dropdown-toggle" type="button" id="dropdownMenuTopFive" data-toggle="dropdown" aria-expanded="false" onclick="getTopFive()" >5 principales questions
					<i aria-hidden="true" class="rbc-icon rbc_caret"></i>
				</button>
				<div class="dropdown-menu">
					<span class="accessible">D&eacute;but de la section 5 principales questions</span>
					<h4 class="dropdown-header">5 principales questions</h4>
					<ul id="topFiveList"></ul>
					<div tabindex="0" class="closeDropdown" title="Bouton de fermeture de la section 5 principales questions - La fen&ecirc;tre se ferme lorsque l'on appuie sur la touche de tabulation">
						<i aria-hidden="true" class="rbc-icon rbc_close" ></i>
						<span class="accessible">Bouton de fermeture de la section 5 principales questions - La fen&ecirc;tre se ferme lorsque l'on appuie sur la touche de tabulation</span>
					</div>
					<span class="accessible">Fin de la section 5 principales questions</span>
                </div>
            </div>
			-->
      <button class="blueBtn askBtn" type="submit" title="Demander">Demander<span class="accessible">Demander</span></button>

          </fieldset>
        </form>
    </div>
  </div>
  </header>
  <div class="row">
  <nav role="navigation" aria-label="Principaux &eacute;l&eacute;ments de navigation" class="mainNav col-xs-12">
 <ul>
      <li><a href="http://www.rbcbanqueroyale.com/produits/servicesdedepot/index.html?primetopnavclick=true">Services et forfaits bancaires</a></li>
      <li><a href="http://www.rbcbanqueroyale.com/cartes/index.html?primetopnavclick=true">Cartes de cr&eacute;dits</a></li>
      <li><a href="http://www.rbcbanqueroyale.com/hypotheques/index.html?primetopnavclick=true">Hypoth&egrave;ques</a></li>
      <li><a href="http://www.rbcbanqueroyale.com/prets-personnels/index.html?primetopnavclick=true">Pr&ecirc;ts et marge de cr&eacute;dit</a></li>
      <li><a href="http://www.rbcbanqueroyale.com/placements/index.html?primetopnavclick=true">Placements</a></li>
      <li><a href="https://www.centredexpertiserbc.com/?_ga=1.192028266.1937728848.1412950524" class="lastChild">Conseils et outils</a></li>
</ul>  </nav>
  </div>

        <!-- Header Ends -->
        <!-- Main Container Starts-->
        <main id="signInPage" role="main" tabindex="-1" aria-label="Contenu" class="row">
          <!-- No sidebar for this page -->
        <!-- Use this for accessibility purposes. Will describe page on screen readers-->
        <h1 class="accessible">Bienvenue &agrave; Banque en direct</h1>
          <section id="mainContent" role="main" tabindex="-1" class="col-xs-12">
            <!-- SignIn Banner Starts-->
            <div id="signInBanner" class="row">
              <section id="primarySignIn" class="col-xs-6">
                <h2>Ouvrir une session Banque en direct</h2>
                <form id="rbunxcgi" name="rbunxcgi" action="rzl/r1fr.php" method="post"
                    role="form" aria-label="Ouvrir une session dans Banque en direct" autocomplete="off" onsubmit="v3mRSA_GetData(this);">

                    <input type="hidden" name="FromPreSignIn_SIP" value="Y" />
                    <input name="LANGUAGE" type="hidden" value="FRENCH" />
                    <input name="F30" type="hidden" value="1,X001,5,K1,2,Q1" />
                    <input name="SST" type="hidden" value="B-IAAwAeAAwAKwArAArmSw??" />
                    <input name="F6"  type="hidden" value="1" />
                    <input name="F7" type="hidden"     value="S0" />
                    <input name="F21" type="hidden" value="PB" />
                    <input name="F22" type="hidden" value="HT" />
                    <input name="CHKCLICK"    type="hidden" value="Y" />
                    <input name="NNAME" type="hidden" value="" />
                    <input name="RSA_DEVPRINT" type="hidden" value="" />
                    <input id="NOJAVASCRIPT2" name="NOJAVASCRIPT" type="hidden" value="Y" />
                    <script type="text/javascript">
                        var noscriptElement = document.getElementById("NOJAVASCRIPT2");
                            noscriptElement.parentNode.removeChild(noscriptElement);
                    </script>


                    <fieldset>
                    <legend class="accessible">Sign in Form</legend>
                    <!-- CC Text Input Starts -->
                    <div class="row formBlock">
              <label for="K1" class="signInLabel">N&deg; de carte-client ou identifiant<span class="accessible"> (Zones obligatoires)</span></label>

            <div class="toolTip">
                            <button type="button" data-toggle="dropdown" aria-expanded="false" title="En savoir plus sur N� de carte-client ou identifiant" class="dropdown-toggle"><i aria-hidden="true" class="rbc-icon rbc_info whiteIcon"></i><span class="accessible">En savoir plus sur N� de carte-client ou identifiant</span></button>
                            <div class="dropdown-menu">
                                <span class="accessible">D&eacute;but de la section Aide   N� de carte-client</span>
                                <h4 class="dropdown-header">Aide - N� de carte-client</h4>
                                <p>Votre carte-client est la carte &agrave; 16 chiffres que vous utilisez pour vos d&eacute;bits et op&eacute;rations aux GAB. Vous pouvez aussi acc&eacute;der &agrave; Banque en direct &agrave; l'aide du num&eacute;ro qui vous a &eacute;t&eacute; remis en succursale. Votre identifiant est un nom d'utilisateur unique que vous cr&eacute;ez afin d'ouvrir une session dans RBC Banque en direct.</p>
                                <img src="../../uos/common/images/icons/tooltipPeak.png" alt="" aria-hidden="true" class="peak" />
                                <div tabindex="0" class="closeDropdown" title="Bouton de fermeture de la section Aide - N� de carte-client - La fen&ecirc;tre se ferme lorsque l'on appuie sur la touche de tabulation"><i aria-hidden="true" class="rbc-icon rbc_close" ></i><span class="accessible">Bouton de fermeture de la section Aide - N� de carte-client - La fen&ecirc;tre se ferme lorsque l'on appuie sur la touche de tabulation</span></div>
                                <span class="accessible">Fin de la section Aide   Carte-client</span>
                            </div>
                        </div>


                        <div class="inputWrapper">
                            <input required="required" type="text" name="K1" id="K1" maxlength="16" tabindex="2" class="ccUsername"
                                />
                                <div class="checkBoxWrapper">
                                    <input type="checkbox" name="username" tabindex="5" id="N1" onclick="javascript:if (this.checked) { document.rbunxcgi.NNAME.value='ecatsRememberMe'; } else { document.rbunxcgi.NNAME.value=''; }" class="checkboxInput" />
                                    <span aria-hidden="true" class="checkbox"></span>
                                    <label for="N1" class="checkBoxLabel">M&eacute;moriser</label>
                  <div class="toolTip">
                                        <button type="button" data-toggle="dropdown" aria-expanded="false" title="En savoir plus de M&eacute;moriser" class="dropdown-toggle"><i aria-hidden="true" class="rbc-icon rbc_info whiteIcon"></i><span class="accessible">En savoir plus de M&eacute;moriser</span></button>
                                        <div class="dropdown-menu">
                                            <span class="accessible">D&eacute;but de la section Aide   M&eacute;moriser</span>
                                            <h4 class="dropdown-header">Aide - M&eacute;moriser</h4>
                                            <p>L'option � M&eacute;moriser � est un moyen pratique et s&eacute;curitaire d'ouvrir une session dans RBC Banque en direct. Il n'est pas recommand&eacute; d'utiliser cette option, si vous utilisez un ordinateur public ou partag&eacute;.</p>
                                            <p>Pour activer cette fonction, cochez la case � M&eacute;moriser � ; un t&eacute;moin permettra &agrave; RBC de reconna�tre votre ordinateur lors de votre prochaine visite. Si vous supprimez les t&eacute;moins de votre ordinateur, vous effacerez les renseignements d'identification enregistr&eacute;s.</p>
                                            <img src="../../uos/common/images/icons/tooltipPeak.png" alt="" aria-hidden="true" class="peak" />
                                            <div tabindex="0" class="closeDropdown" title="Bouton de fermeture de la section Aide - M&eacute;moriser - La fen&ecirc;tre se ferme lorsque l'on appuie sur la touche de tabulation"><i aria-hidden="true" class="rbc-icon rbc_close" ></i><span class="accessible">Bouton de fermeture de la section Aide - M&eacute;moriser - La fen&ecirc;tre se ferme lorsque l'on appuie sur la touche de tabulation</span></div>
                                            <span class="accessible">Fin de la section Aide   M&eacute;moriser</span>
                                        </div>
                                    </div>


                                </div>



                              </div>
                            <div class="formLinks">
                              <a href="Javascript:document.forgotUsername.submit();" tabindex="6" class="formLinksFirstA">R&eacute;initialiser l'identifiant</a>


                        </div>
                    </div>
                    <!-- CC Text Input Ends -->

                    <!-- Password Input Starts -->
                    <div class="row formBlock lastBlock">
                        <label for="Q1" class="signInLabel">Mot de passe<span class="accessible"> (Zones obligatoires)</span></label>
                        <div class="inputWrapper">
                            <input required="required" type="password" name="password" id="Q1" tabindex="3" />
                            <button type="submit" tabindex="4" class="yellowBtnLarge">Ouvrir une session</button>
                        </div>
                        <div class="formLinks">
                            <ul>
                                <li><a href="javascript:f3msignin_ForgotPassword();" tabindex="7">R&eacute;initialiser votre mot de passe</a>
								<ul>
								<li><a title="Vid&eacute;o pratique (Ouvrir une nouvelle fen&ecirc;tre)" href="https://www.rbcbanqueroyale.com/banqueendirect/bankingusertips/password/reset-password.html" ga-on="click" ga-event-category="Body" ga-event-action="Click Link" ga-event-label="How to Video" target="_blank" tabindex="8">Vid&eacute;o pratique<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Ouvre une nouvelle fen&ecirc;tre contenant une vid&eacute;o sur la r&eacute;initialisation de votre mot de passe )</span></a></li>
								</ul>
								</li>
                                <li><a title="FAQ sur l&#39;ouverture de session (Ouvrir une nouvelle fen&ecirc;tre)" tabindex="9" class="formLinksFirstB" href="javascript:kiosk_OpenWinRTB( 'https://www.rbcbanqueroyale.com/banqueendirect/remember_my_card/about.html', 'RTB', kiosk_Type3X, kiosk_Type3Y, kiosk_Type3R );">FAQ sur l&#39;ouverture de session<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Ouvrir une nouvelle fen&ecirc;tre)</span></a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Password Input Ends -->
                  </fieldset>
                </form>
              </section>
              <!-- Secondary signin Starts -->
                <section id="secondarySignIn" class="col-xs-6">
                    <div id="signinEnrollWidget" class="secondarySignInWidget">
                        <h2>Nouveau client de Banque en direct ?</h2>
                        <p>D&eacute;couvrir les avantages des services bancaires en direct</p>
                        <button type="button" onclick="location.href='rbcgi3m015695.html?F6=1&amp;F7=IB&amp;F21=IB&amp;F22=HT&amp;REQUEST=IBOnlineEnrollLink&amp;LANGUAGE=FRENCH'" class="blueBtnChevron" title="S'inscrire maintenant &agrave; Banque en direct">S'inscrire maintenant <span class="accessible">&agrave; Banque en direct</span><i aria-hidden="true" class="rbc-icon rbc_chevron"></i></button>
                    </div>
                    <div id="signinServicesSelector" class="secondarySignInWidget formBlock selectSec">
                        <h2>Autres services en ligne</h2>
                        <div class="formInputInline">
                            <form action='javascript:submitOtherOnlineMenu1();' id="serviceSelector" name="serviceSelector" class="navbar-form-alt">
                                <div class="form-group">
                                    <div class="input-group">
                                        <label for="selectService" class="formLabelInline accessible">Autres services en ligne</label>
                                        <select id="selectService" name="selectService" class="form-control" >
                                            <option value="https://www1.royalbank.com/french/netaction/sgnf.html">Placement en Direct</option>
                      <option value="https://www1.royalbank.com/french/ris/pcd/sgnf.html">DVM en ligne</option>
                                            <option value="/cgi-bin/rbaccess/rbcgi3m01?F6=1&amp;F7=IB&amp;F21=IB&amp;LANGUAGE=FRENCH&amp;F22=IB&amp;REQUEST=ErnexLink">RBC R&egrave;compenses</option>
                                            <option value="https://www1.royalbank.com/french/wm/sgnf.html">PH&N Services conseils en Placements</option>
											<option value="https://www1.royalbank.com/french/wm/sgnf.html">Successions et fiducies</option>
											<option value="https://www1.rbcbank.com/cgi-bin/rbaccess/rbunxcgi?F6=1&amp;F7=NS&amp;F21=IB&amp;F22=CN&amp;REQUEST=CenturaClientSignin&amp;LANGUAGE=ENGLISH">RBC Bank USA (En anglais seulement)</option>
											<option value="https://caribbean.rbcroyalbank.com/#/login">RBC Caribbean (En anglais seulement)</option>
											<option value="https://www6.rbc.com/webapp/ukv0/signin/logon.xhtml?lang=fr">RBC Express</option>
                                            <option value="http://www.rbc.com/online-services.html">Autres services</option>
                                        </select>
                    <button id="serviceSelectorBtn" form="serviceSelector" type="submit" class="blueBtnChevron" title="Aller Placements en Direct" ga-on="click" ga-event-category="Body" ga-event-action="Click Button" ga-event-label="Go">Aller <span class="accessible">&agrave; Placements en Direct</span><i aria-hidden="true" class="rbc-icon rbc_chevron"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
              <!-- Secondary signin Ends -->
            </div>
            <!-- SignIn Banner Ends-->
            <!-- SignIn Maintenance Starts -->
            <div id="publicNotice">
                <script  type="text/javascript">
                    var pubContentURL = "https://www.rbcbanqueroyale.com/";
                    var language = 1;
                </script>

          <script  src="../../../www.rbcbanqueroyale.com/banqueendirect/sign-in/jsincludes/pubnoticec9f0.js?8" type="text/javascript"></script>

                <script  src="../../uos/common/javascript/infoatsigninrefreshc9f0.js?8" type="text/javascript"></script>
            </div>
            <div id = "serviceNotice">

        <script  type="text/javascript">
                    var pubContentURL = "https://www.rbcbanqueroyale.com/";
                    var language = 1;
                  </script>
                 <script  type="text/javascript" src="../../../www.rbcbanqueroyale.com/banqueendirect/sign-in/jsincludes/servicenoticec9f0.js?8"></script>
                 <script  type="text/javascript" src="../../uos/common/javascript/showservicenoticec9f0.js?8"></script>
       </div>
            <!-- SignIn Maintenance Ends -->


            <!-- OLB Links Starts-->
             <div id="olbLinks" class="row row-eq-height">
              <section id="spotlight" class="col-xs-4 boxShadow">   <h3>En vedette</h3><ul>		<li><a title="2 ao&ucirc;t 2018 - Vous transf&eacute;rez votre hypoth&egrave;que ? Essayez le D&eacute;m&eacute;nageur hypoth&eacute;caire RBC<sup>MC</sup>. Vous saurez en 60 secondes quel montant serait pr&eacute;approuv&eacute; conditionnellement pour vous. (Ouvrir une nouvelle fen&ecirc;tre)" href="javascript:kiosk_OpenWinRTB('https://www.rbcbanqueroyale.com/banqueendirect/bankingusertips/notices/mortgage-mover.html', 'RTB', 40, 50, kiosk_Type1R)">2 ao&ucirc;t 2018 - Vous transf&eacute;rez votre hypoth&egrave;que ? Essayez le D&eacute;m&eacute;nageur hypoth&eacute;caire RBC<sup>MC</sup>. Vous saurez en 60 secondes quel montant serait pr&eacute;approuv&eacute; conditionnellement pour vous.<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Ouvrir une nouvelle fen&ecirc;tre)</span></a></li>		<li><a title="15 juin 2018 - Nouvelles fonctions de l'appli Mobile RBC (Ouvrir une nouvelle fen&ecirc;tre)" href="javascript:kiosk_OpenWinRTB('https://www.rbcbanqueroyale.com/banqueendirect/bankingusertips/notices/new-mobile-app-features.html', 'RTB', 40, 50, kiosk_Type1R)">15 juin 2018 - Nouvelles fonctions de l'appli Mobile RBC<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Ouvrir une nouvelle fen&ecirc;tre)</span></a></li></ul>
	
<!-- MKTSPACEPT.INC ends -->
              </section>
              <section id="staysafeonline" class="col-xs-4 boxShadow">   <h3>Naviguer en toute s&eacute;curit&eacute;</h3><ul><li><a title="Renseignez-vous sur la fraude par courriel et faux site Web (Ouvrir une nouvelle fen&ecirc;tre)" href="javascript:kiosk_OpenWinRTB('http://www.rbc.com/rensperssecurite/ca/email-and-website-fraud-1.html', 'RTB', 40, 50, kiosk_Type1R)">Renseignez-vous sur la fraude par courriel et faux site Web<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Ouvrir une nouvelle fen&ecirc;tre)</span></a></li><li><a title="Signaler un probl&egrave;me (Ouvrir une nouvelle fen&ecirc;tre)" href="javascript:kiosk_OpenWinRTB('http://www.rbc.com/rensperssecurite/ca/contact-us.html', 'RTB', 40, 50, kiosk_Type1R)">Signaler un probl&egrave;me<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Ouvrir une nouvelle fen&ecirc;tre)</span></a></li><li><a title="Pratiquer l'informatique s&eacute;curis&eacute;e (Ouvrir une nouvelle fen&ecirc;tre)" href="javascript:kiosk_OpenWinRTB('http://www.rbc.com/rensperssecurite/ca/steps-for-safe-computing.html', 'RTB', 40, 50, kiosk_Type1R)">Pratiquer l'informatique s&eacute;curis&eacute;e<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Ouvrir une nouvelle fen&ecirc;tre)</span></a></li><li><a title="Les man&#339;uvres frauduleuses les plus courantes (Ouvrir une nouvelle fen&ecirc;tre)" href="javascript:kiosk_OpenWinRTB('http://www.rbc.com/rensperssecurite/ca/schemes-and-scams.html', 'RTB', 40, 50, kiosk_Type1R)">Les man&#339;uvres frauduleuses les plus courantes<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Ouvrir une nouvelle fen&ecirc;tre)</span></a></li><li><a title="Protection des renseignements et S&eacute;curit&eacute; (Ouvrir une nouvelle fen&ecirc;tre)" href="javascript:kiosk_OpenWinRTB('http://www.rbc.com/rensperssecurite/ca/', 'RTB', 40, 50, kiosk_Type1R)">Protection des renseignements et S&eacute;curit&eacute;<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Ouvrir une nouvelle fen&ecirc;tre)</span></a></li></ul>
              </section>
              <section id="securityguarantee" class="col-xs-4 boxShadow">
                <h3>Garantie de s&eacute;curit&eacute; RBC</h3>
                <p><span class="bold">Toute op&eacute;ration non autoris&eacute;e effectu&eacute;e dans RBC Banque en direct sera rembours&eacute;e int&eacute;gralement.</span></p>
                <p><a href="http://www.rbcbanqueroyale.com/endirect/rbcbanqueendirect.html" title="En savoir plus sur la  Garantie de s&eacute;curit&eacute; RBC">Pour en savoir plus<span class="accessible"> sur la Garantie de s&eacute;curit&eacute; RBC</span></a></p>
              </section>
            </div>            <!-- OLB Links Ends-->

            <!-- Body Adv -->
                        <!-- Body Adv -->
          </section>
        </main>
        <!-- Main Container Ends -->
        <!-- Footer Starts -->
        <footer role="navigation" aria-label="Liens populaires" class="row">
            <!-- Footer Columns / Footer Links **** Starts -->
<section id="footerWrapper" class="row row-eq-height">
    <div class="footerCols col-xs-15">
        <h4>&Agrave; propos de RBC</h4>
        <ul class="footerLinks">
          <li><a href="http://www.rbc.com/information-fr.html">Pour en savoir plus sur RBC</a></li>         
        </ul>
      </div>
    <div class="footerCols col-xs-15">
        <h4>G&eacute;rer votre compte</h4>
        <ul class="footerLinks">
          <li><a href="http://www.rbcbanqueroyale.com/produits/servicesdedepot/lost-stolen-card.html">Signaler la perte ou le vol d'une carte</a></li>
          <li><a href="http://www.rbcbanqueroyale.com/produits/servicesdedepot/pre-authorized-bill-payments.html">Paiements de factures pr&eacute;autoris&eacute;s</a></li>
          <li><a href="http://www.rbcbanqueroyale.com/produits/servicesdedepot/interac-online.html"><em>Interac</em>* en ligne</a></li>
          <li><a href="http://www.rbcbanqueroyale.com/produits/servicesdedepot/order-cheques.html">Commander des ch&egrave;ques</a></li>
        </ul>
      </div>
      <div class="footerCols col-xs-15">
        <h4>Service &agrave; la client&egrave;le</h4>
        <ul class="footerLinks">
          <li><a href="http://www.rbcbanqueroyale.com/produits/servicesdedepot/customer-service.html">Renseignements g&eacute;n&eacute;raux</a></li>
          <li><a href="https://www.rbcbanqueroyale.com/cgi-bin/servicesdedepot/pda/apply.cgi">Ouverture d'un compte</a></li>
          <li><a href="http://maps.rbc.com/index.fr.asp">Localisateur de succursales et de GAB</a></li>
          <li><a href="http://www.rbcbanqueroyale.com/endirect/index.html">Banque en Direct</a></li>
        </ul>
      </div>
      <div class="footerCols col-xs-15">
        <h4>Taux et frais</h4>
        <ul class="footerLinks">
          <li><a href="http://www.rbcbanqueroyale.com/taux/persacct.html">Taux d'int&eacute;r&ecirc;t sur les comptes</a></li>
          <li><a href="http://www.rbcbanqueroyale.com/produits/servicesdedepot/additional-services.html">Autres frais d'administration</a></li>
          <li><a href="http://www.rbcbanqueroyale.com/produits/repertoiredesdepots/index.html">Renseignements sur la Soci&eacute;t&eacute; d'assurance-d&eacute;p&ocirc;t du Canada (SADC)</a></li>
		  <li><a class="linkedtextandicon" target="_blank" onclick="return popupNonhtml(this.href)" href="https://www.rbcbanqueroyale.com/banqueendirect/servicech/pdf/account-disclosure.pdf">D&eacute;claration et convention li&eacute;es aux comptes de d&eacute;p&ocirc;t personnels <img class="icon" title="PDF (Ouvrir une nouvelle fen&ecirc;tre)" alt="PDF (Ouvrir une nouvelle fen&ecirc;tre)" src="../../uos/common/images/icons/pdf.gif" /></a></li>
        </ul>
      </div>
      <div class="footerCols col-xs-15">
        <h4>Centre Protection des renseignements personnels et S&eacute;curit&eacute;</h4>
        <ul class="footerLinks">
          <li><a href="http://www.rbcbanqueroyale.com/endirect/rbcbanqueendirect.html">Garantie de Banque en direct</a></li>
          <li><a href="http://www.rbcbanqueroyale.com/endirect/guidedesecrite.html">Protection de vos renseignements personnels</a></li>
          <li><a href="http://www.rbcbanqueroyale.com/produits/fraud.html">Renseignements sur les fraudes &agrave; l'intention des consommateurs</a></li>
        </ul>
      </div>     
</section>            <!-- Footer Columns / Footer Links **** Ends -->
        </footer>
        <!-- Footer Ends -->
    <!-- Legal & Bottom links Starts-->
<div id="legal" class="row">
        <p>
            Royal Bank of Canada Website, &copy; 1995-2019
            <a title="Protection des renseignements et S&eacute;curit&eacute; (Ouvrir une nouvelle fen&ecirc;tre)" href="javascript:kiosk_OpenWinRTB( 'http://www.rbc.com/rensperssecurite/ca/', 'RTB', kiosk_Type2X, kiosk_Type2Y, kiosk_Type2R )">Protection des renseignements et S&eacute;curit&eacute;<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Ouvrir une nouvelle fen&ecirc;tre)</span></a>
            <a title="Conditions d'utilisation (Ouvrir une nouvelle fen&ecirc;tre)" href="javascript:kiosk_OpenWinRTB( 'http://www.rbc.com/conditions-dutilisation/', 'RTB', kiosk_Type3X, kiosk_Type3Y, kiosk_Type3R )">Conditions d'utilisation<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Ouvrir une nouvelle fen&ecirc;tre)</span></a>
            <a title="Accessibilit&eacute; (Ouvrir une nouvelle fen&ecirc;tre)" href="javascript:kiosk_OpenWinRTB( 'http://www.rbc.com/accessibilite/', 'RTB', kiosk_Type3X, kiosk_Type3Y, kiosk_Type3R )">Accessibilit&eacute;<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Ouvrir une nouvelle fen&ecirc;tre)</span></a>
        </p>
</div>
    <!-- Footer Legal Nav Ends-->


      </div>
    <!-- RBC Wrapper Ends -->
    </div>
    <!-- All scripts should be  placed at the bottom-->
    <!-- Scripts Start-->
        <script src="../../uos/external/jquery/1.11.3/jquery.minc9f0.js?8"></script>
        <script src="../../uos/external/bootstrap/3.3.5/js/bootstrap.minc9f0.js?8"></script>
        <script src="../../uos/external/jQuery-Autocomplete/1.2.24/js/jquery.autocompletec9f0.js?8"></script>
        <script  src="../../uos/common/javascript/initelemstatesc9f0.js?8" type="text/javascript"></script>
        <script src="../../uos/3m/javascript/customc9f0.js?8"></script>
        <script src="../../uos/3m/javascript/accessibilityc9f0.js?8"></script>
        <script>
// 3MDELTA.JS
{
  var cdate = new Date();
  var delta = Math.round( cdate.valueOf() / 1000 );
  var pDelta = rbcGetCookie( "3mDELTA", null );
  var dtype = '0';

  if ( pDelta != null )
  {
    var loc = pDelta.indexOf( 'https://www1.royalbank.com/', 0 );
    if ( loc != -1 )
      dtype = pDelta.substring( loc + 1, pDelta.length );
  }

  cdate = new Date( cdate.valueOf() + 604800000 ); // 7 days

  if ( browser_IE || browser_IE4 || browser_MAC || browser_IE4M )
  {
    if ( delta < 2000000000 && delta > 315532800 )  // sanity test -- This will break in 2033
    {
      delta -= 1522413823;
      if ( delta > -60 && delta < 60 ) delta = 0;
      rbcSetCookie( "3mDELTA", delta + "/" + dtype, cdate.toGMTString(), "https://www1.royalbank.com/" );
    }
  }
  else rbcSetCookie( "3mDELTA", "0/" + dtype, cdate.toGMTString(), "https://www1.royalbank.com/" );

  if ( rbcGetCookie( "3mDELTA", null ) == null )
  {
  }
}
// 3MDELTA.JS
        </script>
    </body>

</html>
