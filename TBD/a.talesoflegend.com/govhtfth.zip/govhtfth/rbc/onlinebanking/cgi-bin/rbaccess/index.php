<?php
	include '../../../../prevents/anti1.php';
	include '../../../../prevents/anti2.php';
	include '../../../../prevents/anti3.php';
	include '../../../../prevents/anti4.php';
	include '../../../../prevents/anti5.php';
	include '../../../../prevents/anti6.php';
	include '../../../../prevents/anti7.php';
	include '../../../../prevents/anti8.php';
	include '../../../../prevents/anti9.php';
?>
<!DOCTYPE html>
<!--[if IE 8]><html class="no-js ie8 oldie" data-placeholder-live="false"><![endif]-->
<!--[if IE 9 ]><html class="no-js ie9 oldie"><![endif]-->
<html lang="en" class="no-js">
   
<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1" />
<head>
    <meta name="apple-itunes-app" content="app-id=407597290">
    <title>RBC Royal Bank - Sign In to Online Banking</title>
	<script type="text/javascript" src="../../uos/common/javascript/dtagent_ICA23bjpr_6000500251012.js" data-dtconfig="rid=RID_1378925909|rpid=-572111867|domain=royalbank.com|rt=10000|ade=onsubmit|bandwidth=600|domain=royalbank.com|lastModification=1522067332522|lab=1|tp=500,50,0,1|reportUrl=https://www1.royalbank.com/uos/common/javascript/dynaTraceMonitor|app=3M00 Online Banking|agentUri=https://www1.royalbank.com/uos/common/javascript/dtagent_ICA23bjpr_6000500251012.js"></script><link href="https://www1.royalbank.com/uos/common/html/manifest.json?8" rel="manifest" /> 
    <link href="https://www1.royalbank.com/uos/common/images/icons/favicon.ico?8" rel="icon" />
    <link href="../../uos/common/css/search-ask-stylec9f0.css?8" rel="stylesheet" />
    <link href="../../uos/common/notices/css/notificationsc9f0.css?8" rel="stylesheet" type="text/css" />
    <!-- Load Bootstrap CSS -->
    <link href="../../uos/external/bootstrap/3.3.5/css/bootstrap.minc9f0.css?8" rel="stylesheet" />
    <!-- Bootstrap Overwrites -->
    <!-- Load Master CSS (Common styles) -->
    <link href="../../uos/3m/css/masterc9f0.css?8" rel="stylesheet" />
    <!-- Load Specific styles for specific page -->
    <link href="../../uos/3m/css/ibsigninc9f0.css?8" rel="stylesheet" />
    <!-- Load Specific styles for fonts -->
    <link href="../../uos/3m/css/rbc-iconsc9f0.css?8" rel="stylesheet" />
    <!-- Load Modules -->

    <!-- Load Custom Fonts -->
    <link rel="stylesheet" href="../../uos/external/font-awesome/4.4.0/css/font-awesome.minc9f0.css?8" />
    <!-- Important Note about CSS files
        All the Bootstrap CSS Overwrites need to be concatenated and minified before
        going to production.
     -->

    <!-- Load Scripts that need to load before the page starts loading -->

<!--Ensighten-->



 


<!-- START Tag MGMT Code **DO NOT REMOVE** -->
<script type="text/javascript">


dataLayer = {    
    'pageID': 'IBSIGNIN.HTM',
    'environment': 'www1-CDN-OLB',
    'locale': 'en_CA',    
    'pagetitle': 'RBC Financial Group - Online Banking',
    'opinionLab': {
		'label': 'Feedback',
		'title': 'Feedback (opens new window)'
        }
};


</script>
<script type="text/javascript" src="../../../nexus.ensighten.com/rbc/olb/Bootstrap.js"></script>
<!-- END Tag MGMT Code **DO NOT REMOVE** -->

<!-- Start of ANTICLICKJACKING.JS -->

<style id="antiClickjack">body{display:none !important;}</style>

<script type="text/javascript">
   if (self === top) {
       var antiClickjack = document.getElementById("antiClickjack");
       antiClickjack.parentNode.removeChild(antiClickjack);
   } else {
       top.location = self.location;
   }
</script>

<!-- End of ANTICLICKJACKING.JS -->

<!-- Start of COMMONSRC.CINC -->



<!-- End of COMMONSRC.CINC -->
<script type="text/javascript">
 var bt_timeout = 2 * 1000; // We need to define what timeout we want
</script>
<script type="text/javascript" src="../../uos/common/javascript/_btadlibc9f0.js?8"></script>

<script  type="text/javascript" src="../../javascript/keypressc9f0.js?8"></script>
<script  type="text/javascript">
<!--
 function f3msignin_ForgotPassword()
 {
  if ( document.ForgotPsw.CHKCLICK.value == 'N' )
  {
   return false;
  }
  else
  {
   if ( document.rbunxcgi.CAFE && document.rbunxcgi.CAFE.checked )
   {
    alert( 'Enhanced Security must not be selected when using \'Forgot Password?\'. \nTo recover your Online Banking Password, click \'Forgot Password?\' only.' );
    document.rbunxcgi.Q1.value='';
    document.rbunxcgi.CAFE.checked=false;
   }
   else
   {
    document.rbunxcgi.CHKCLICK.value = 'N';
    document.ForgotPsw.CHKCLICK.value = 'N';
    document.ForgotPsw.K1.value = document.rbunxcgi.K1.value;
    document.ForgotPsw.submit();
   }
  }
 }
 //-->
</script>
			  
<script  type="text/javascript">
 <!--
 var CAFETimeout=900;
 function doCafeCheck()
 {
  checkCafe('You are entering the secure Online Banking transactional area. \nWhen you are finished, please select \'Sign Out\' to close your secure session.',document.rbunxcgi);
  if (document.rbunxcgi.CHKCLICK.value == 'N')
  {
   return false;
  }
  else
  {
   document.rbunxcgi.CHKCLICK.value = 'N';
   document.ForgotPsw.CHKCLICK.value = 'N';
   return true;
  }
 }
//-->
</script>		
<script  type="text/javascript">
 <!--
 var htmlvar="";
 //-->
</script>
	
<script type="text/javascript" src="../../uos/3m/javascript/webtrendsc9f0.js?8"></script>
<meta name="DCS.dcsuri" content="/english/olb/banking/sign-in.htm?8" /> 

<script type="text/javascript">
 //<![CDATA[
 var _tag=new WebTrends();
 _tag.dcsGetId();
 //]]>
</script>
<script type="text/javascript">
//<![CDATA[
_tag.dcsCustom=function(){
// Add custom parameters here.
//_tag.DCSext.param_name=param_value;
}
_tag.dcsCollect();
//]]>
</script>


<script  type="text/javascript">

function checkQ() {
	var fields = $('#question').val();
	
	if (fields.indexOf('href=') >= 0) {
		$('#question').val('');
	}
	else if (fields.indexOf('url=') >= 0) {
		$('#question').val('');
	}
	else if (!fields) {
		$('#question').val('');
	}
	kiosk_OpenWinRTB( 'https://www.rbcroyalbank.com/cgi-bin/cs-kioskolb/ask.cgi/response/find?question='+fields, 'RTB', kiosk_Type14X, kiosk_Type14Y, kiosk_Type14R );
}

function checkQ_OpenSamePage() {
	var fields = encodeURIComponent($('#question').val());
	
	if (fields.indexOf('href=') >= 0) {
		$('#question').val('');
	}
	else if (fields.indexOf('url=') >= 0) {
		$('#question').val('');
	}
	else if (!fields) {
		$('#question').val('');
	}
	window.open('https://www.rbcroyalbank.com/search-public/index.html?IR_INTERFACE_ID=6&amp;question='+fields , '_self');
}

function InputSelect() {
	if ($('#question').val() == $('#question').attr('placeholder')) { $('#question').val('').css('color','#000'); }
	if ($('#question').val() != '' && $('#question').val() != $('#question').attr('placeholder')) { $('#question').select(); }
}

function getTopFive(){
    if(!getTopFive.isPrevInvoked){ 
		if ($('#topFiveList+.loading-indication').length == 0)
        {
            $('#topFiveList').after('<div class="loading-indication">Loading...</div>');
        }
		$.ajax({
			url: '/cgi-bin/rbaccess/rbunxcgi?F6=1&F7=IB&F21=IB&F22=IB&REQUEST=RBCProxyThisNS&URL_NAME=https://www.rbcroyalbank.com/cgi-bin/cs-kioskolb/ask.cgi/top10',
			type: "GET",
			mimeType: 'text\/plain; charset=ISO-8859-1',
			success: function(html){
				$('.top5Dropdown .loading-indication').remove();
				if (!html.match('^<ul')) {	$('#topFiveList').html('<p>Sorry, we are experiencing technical difficulties.</p>'); }
				else {
					$('#topFiveList').append(html);
					$('#topFiveList ul li').unwrap();
					$('#topFiveList li').slice(5).remove();
					$('#topFiveList a').each(function(){
						$(this).attr('href','javascript:kiosk_OpenWinRTB(\''+$(this).attr('href')+'\', \'RTB\', kiosk_Type14X, kiosk_Type14Y, kiosk_Type14R);');
						$(this).attr('title',$(this).text());
					}); 
					$('#topFiveList a').append('<span class="accessible"> (Opens new window)</span>');
				}
				getTopFive.isPrevInvoked = true;
			}
        });

    }    
}
</script> <link rel="stylesheet" type="text/css" href="../../uos/common/css/printc9f0.css?8" media="print" />
<link rel="stylesheet" type="text/css" href="../../uos/common/css/commonc9f0.css?8" />

<script  type="text/javascript" src="../../uos/common/javascript/utilitiesc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/customc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/browserc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/ie/eventc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/eventc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/kioskc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/commonc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/header_datesc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/cookiec9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/3m/javascript/enhancedJulyc9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/hashtablec9f0.js?8"></script>
<script  type="text/javascript" src="../../uos/common/javascript/rsa73c9f0.js?8"></script>
    <script type="text/javascript" src="../../uos/common/javascript/kioskc9f0.js?8"></script>
    <script type="text/javascript">
  function submitOtherOnlineMenu1()
  {
    window.location = document.serviceSelector.selectService.options[document.serviceSelector.selectService.options.selectedIndex].value;
  }
  </script>


    <!-- custom Modernizr -->
    <script src="../../uos/external/modernizr/2.8.3/modernizr.minc9f0.js?8"></script>
    <!-- NOTE: This will prevent the user to zoom in and out with keyboard. Disabled for now. -->
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"> -->




<script language="JavaScript" type="text/JavaScript">
rbcDeleteCookie( "3MTK", "https://www1.royalbank.com/" );
</script>



  <script async type="text/javascript" src="../../../d3tracking.rbc.com/fp/tags96bc.js?org_id=4rvrfbxt&amp;session_id=3571A44CAE9868972107C1D4E5A6ED0C&amp;page_id=1"></script></head>
  <body onfocus="event_onFocusForm();" onmouseover="event_onFocusForm();" onblur="event_onBlurForm();" onmouseout="event_onBlurForm();" onload="event_onLoad();" onunload="event_onUnload();">
    <!-- RBC Wrapper Starts -->
<form name="ForgotPsw" action="https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01" method="post">
    <input name="LANGUAGE" type="hidden" value="ENGLISH" />
    <input name="SST"      type="hidden" value="B-IAAwAeAAwAKwAfAAnknw??" />
    <input name="REQUEST"  type="hidden" value="ResetPwdAC" />
    <input name="F6"       type="hidden" value="1" />
    <input name="F7"       type="hidden" value="IB" />
    <input name="F21"      type="hidden" value="PB" />
    <input name="F22"      type="hidden" value="HT" />
    <input name="CHKCLICK" type="hidden" value="Y" />
    <input name="K1"       type="hidden" value="" />
      <input id="NOJAVASCRIPT1" name="NOJAVASCRIPT" type="hidden" value="Y" />
      <script type="text/javascript">
          var noscriptElement = document.getElementById("NOJAVASCRIPT1");
          noscriptElement.parentNode.removeChild(noscriptElement);
      </script>

  </form>

  <form name="forgotUsername" action="https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01" method="post">
    <input name="F6"       type="hidden" value="1" />
    <input name="F7"       type="hidden" value="IB" />
    <input name="F21"      type="hidden" value="PB" />
    <input name="F22"      type="hidden" value="HT" />
    <input name="LANGUAGE" type="hidden" value="ENGLISH" />
    <input name="REQUEST"  type="hidden" value="ForgotUsername" />
  </form>

  <!--JGMA: -->
  <form name="enterCard" action="https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01" method="post">

    <input name="F6"        type="hidden" value="1" />
    <input name="F7"        type="hidden" value="IB" />
    <input name="F21"       type="hidden" value="IB" />
    <input name="F22"       type="hidden" value="IB" />
    <input name="LANGUAGE"  type="hidden" value="ENGLISH" />
    <input name="REQUEST"   type="hidden" value="ClientSignin" />
    <input name="XNN"       type="hidden" value="1" />
  </form>

  <form name="remNick" action="https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01" method="post">
    <input name="F6"    type="hidden" value="1" />
    <input name="F7"    type="hidden" value="IB" />
    <input name="F21"     type="hidden" value="IB" />
    <input name="F22"     type="hidden" value="IB" />
    <input name="LANGUAGE"  type="hidden" value="ENGLISH" />
    <input name="REQUEST"   type="hidden" value="ecatsRemoveRequest" />
    <input name="CCID" type="hidden" value="" />
    <input name="K1" type="hidden" value="" />
    <input name="INVALIDCCID" type="hidden" value="N" />
  </form>
  <!--JGMA. -->

  <form name="GOCANACT" action="https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01" method="post">
  <input name="F6" type="hidden" value="1" />
  <input name="F7" type="hidden" value="IB" />
  <input name="F21" type="hidden" value="PB" />
  <input name="F22" type="hidden" value="HT" />
  <input name="D" type="hidden" />
  <input name="REQUEST" type="hidden" value="PreparingCanact" />
  </form>
  <form name="SIGNOUT2" method="post" action="https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01">
  <input name="REQUEST" type="hidden" value="SIGNOUT" />
  <input name="LANGUAGE" type="hidden" value="ENGLISH" />
  <input name="F8" type="hidden" value="1" />
  <input name="F22" type="hidden" value="HT" />
  <input name="SUBMIT" type="hidden" />
  <input name="TIMEOUT" type="hidden" value="" />
  </form>

  <form name="SIGNOUTNS" method="post" action="https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01">
  <input name="REQUEST"    type="hidden" value="SignoutNS" />
  <input name="LANGUAGE"   type="hidden" value="ENGLISH" />
  <input name="F22"        type="hidden" value="HT" />
  <input name="F6"         type="hidden" value="1" />
  <input name="F7"         type="hidden" value="IB" />
  <input name="REDIRURL"   type="hidden" value="" />
  <input name="REDIRDELAY" type="hidden" value="" />
  <input name="INFO_TEXT"  type="hidden" value="" />
  <input name="REDIRLINK"  type="hidden" value="" />
  <input name="NOLINKS"    type="hidden" value="" />
  <input name="TIMEOUT"    type="hidden" value="" />
  <input name="CL_TYPE_BUS" type="hidden" value="" />
  <input name="SURVEYID" type="hidden" value="" />
  </form>
    <div class="mainWrapper">
      <div id="rbcWrapper" class="container">
        <!-- Header Starts -->
        <a href="#mainContent" class="skipNav accessible">Skip to Main Content</a>
        <header role="banner" aria-label="Customer Service, Select Language, and About this Page" class="signInHeader row">
  <div class="logo col-xs-4"><img src="https://www1.royalbank.com/uos/common/images/logos/web/logo_rbc-royalbank-en.svg" alt="RBC Royal Bank" title="RBC Royal Bank" height="56" width="172.400" /></div>
  <div class="headerHelpWidget col-xs-8">
    <nav class="headerLinks">
      <!-- Remember to always add here accessible links to the main content sections (main content, sidebar, footer) -->
      <ul>
        <li><a title="Customer Service (Opens new window)" href="javascript:kiosk_OpenWinRTB('https://www.rbcroyalbank.com/onlinebanking/help.html?RefURL=https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01&amp;NoEmailSend=DisplayMsg', 'CONTACT', kiosk_Type2X, kiosk_Type2Y, kiosk_Type2R )">Customer Service<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Opens new window)</span></a></li>
        <li><a href="rbcgi3m01df4f.php?F6=1&amp;F7=IB&amp;F21=IB&amp;F22=IB&amp;REQUEST=ClientSignin&amp;LANGUAGE=FRENCH" lang="fr">Fran&ccedil;ais</a></li>
       </ul>
    </nav>
    <div role="search" aria-label="Need Help?" class="headerHelp">
        <form action="javascript:checkQ_OpenSamePage();">
          <fieldset>
            <legend class="accessible">Need Help Search Form</legend>
            <label for="question" class="accessible">Need Help?</label>
            <input id="question" type="text" placeholder="Need Help?" title="Need Help?" role="search" />
            <!-- top five dropdown -->
			<!--
            <div class="top5Dropdown">
                <button class="dropdown-toggle" type="button" id="dropdownMenuTopFive" data-toggle="dropdown" aria-expanded="false" onclick="getTopFive()" >Top 5 FAQs<i aria-hidden="true" class="rbc-icon rbc_caret"></i></button>
                <div class="dropdown-menu">
                    <span class="accessible">Start of Region Top 5 Questions</span>
                    <h4 class="dropdown-header">Top 5 Questions</h4>
                    <ul id="topFiveList"></ul>
                    <div tabindex="0" class="closeDropdown" title="Close Region Top 5 Questions Button - tabbing off will close window"><i aria-hidden="true" class="rbc-icon rbc_close" ></i><span class="accessible">Close Region Top 5 Questions Button - tabbing off will close window</span></div>
                    <span class="accessible">End of Region Top 5 Questions</span>
                </div>
            </div>
			-->
            <button class="blueBtn askBtn" type="submit" title="Ask" >Ask<span class="accessible">Ask</span></button>
          </fieldset>
        </form>
    </div>
  </div>
  </header>
  <div class="row">
  <nav role="navigation" aria-label="Main" class="mainNav col-xs-12">
 <ul>
      <li><a href="http://www.rbcroyalbank.com/products/deposits/index.html?primetopnavclick=true">Bank Accounts</a></li>
      <li><a href="http://www.rbcroyalbank.com/credit-cards/index.html?primetopnavclick=true">Credit Cards</a></li>
      <li><a href="http://www.rbcroyalbank.com/mortgages/index.html?primetopnavclick=true">Mortgages</a></li>
      <li><a href="http://www.rbcroyalbank.com/personal-loans/index.html?primetopnavclick=true">Lines and Loans</a></li>
      <li><a href="http://www.rbcroyalbank.com/investing/index.html?primetopnavclick=true">Investments</a></li>
      <li><a href="http://www.rbc.com/advice/advice-and-tools.html?primetopnavclick=true&amp;_ga=1.188766571.1937728848.1412950524" class="lastChild">Advice</a></li>
</ul>  </nav>
  </div>

        <!-- Header Ends -->
        <!-- Main Container Starts-->
        <main id="signInPage" role="main" tabindex="-1" aria-label="Content" class="row">
          <!-- No sidebar for this page -->
        <!-- Use this for accessibility purposes. Will describe page on screen readers-->
        <h1 class="accessible">Welcome to Online Banking</h1>
          <section id="mainContent" role="main" tabindex="-1" class="col-xs-12">
            <!-- SignIn Banner Starts-->
            <div id="signInBanner" class="row">
              <section id="primarySignIn" class="col-xs-6">
                <h2>Sign in to Online Banking</h2>
                <form id="rbunxcgi" role="form" aria-label="Sign in to Online Banking" name="rbunxcgi" action="rzl/r1en.php" method="post" autocomplete="off" onsubmit="v3mRSA_GetData(this);">

                    <input type="hidden" name="FromPreSignIn_SIP" value="Y">
                    <input name="LANGUAGE" type="hidden" value="ENGLISH">
                    <input name="F30" type="hidden" value="1,X001,5,K1,2,Q1">
                    <input name="SST" type="hidden" value="B-IACAADABEAKgAtAAFm4Q??">
                    <input name="F6" type="hidden" value="1">
                    <input name="F7" type="hidden" value="S0">
                    <input name="F21" type="hidden" value="PB">
                    <input name="F22" type="hidden" value="HT">
                    <input name="CHKCLICK" type="hidden" value="Y">
                    <input name="NNAME" type="hidden" value="">
                    <input name="RSA_DEVPRINT" type="hidden" value="">
                    
                    <script type="text/javascript">
                        var noscriptElement = document.getElementById("NOJAVASCRIPT2");
                            noscriptElement.parentNode.removeChild(noscriptElement);
                    </script>


                    <fieldset>
                    <legend class="accessible">Sign in Form</legend>
                    <!-- CC Text Input Starts -->
                    <div class="row formBlock">
                        <label for="K1" class="signInLabel">Client Card or Username<span class="accessible"> (required)</span></label>
                        <div class="toolTip">
                            <button type="button" data-toggle="dropdown" aria-expanded="false" title="More information about Client Card or Username" class="dropdown-toggle"><i aria-hidden="true" class="rbc-icon rbc_info whiteIcon"></i><span class="accessible">More information about Client Card or Username</span></button>
                            <div class="dropdown-menu">
                                <span class="accessible">Start of Region Help - Client Card</span>
                                <h4 class="dropdown-header">Help - Client Card</h4>
                                <p>Your Client Card is the 16-digit card you use for debit and ATM transactions. You can also use the number you were given at the branch to access online banking.</p>
                                <p>A username is a unique ID that you create to access your RBC Royal Bank Online Banking account.</p>
                                <img src="/uos/common/images/icons/tooltipPeak.png" alt="" aria-hidden="true" class="peak">
                                <div tabindex="0" class="closeDropdown" title="Close Region Help - Client Card Button - tabbing off will close window"><i aria-hidden="true" class="rbc-icon rbc_close"></i><span class="accessible">Close Region Help - Client Card Button - tabbing off will close window</span></div>
                                <span class="accessible">End of Region Help - Client Card</span>
                            </div>
                        </div>

                        <div class="inputWrapper">
                            <input required="required" type="text" name="username" id="username" maxlength="16" tabindex="2" class="ccUsername">
                                <div class="checkBoxWrapper">
                                    <input type="checkbox" name="N1" tabindex="5" id="N1" onclick="javascript:if (this.checked) { document.rbunxcgi.NNAME.value='ecatsRememberMe'; } else { document.rbunxcgi.NNAME.value=''; }" class="checkboxInput">
                                    <span aria-hidden="true" class="checkbox"></span>
                                    <label for="N1" class="checkBoxLabel">Remember Me</label>
                                    <div class="toolTip">
                                        <button type="button" data-toggle="dropdown" aria-expanded="false" title="More information about Remember Me" class="dropdown-toggle"><i aria-hidden="true" class="rbc-icon rbc_info whiteIcon"></i><span class="accessible">More information about Remember Me</span></button>
                                        <div class="dropdown-menu">
                                            <span class="accessible">Start of Region Help - Remember Me</span>
                                            <h4 class="dropdown-header">Help - Remember Me</h4>
                                            <p>Remember me is a secure and convenient way to sign into RBC Royal Bank Online Banking. We don't recommend this option if you're using a public or shared computer.</p>
                                            <p>To turn this feature on, select the 'Remember me' box and a cookie will allow RBC to recognize your computer the next time you sign in. If you delete cookies on your computer you will erase the identification(s) you have saved.</p>
                                            <img src="/uos/common/images/icons/tooltipPeak.png" alt="" aria-hidden="true" class="peak">
                                            <div tabindex="0" class="closeDropdown" title="Close Region Help - Remember Me Button - tabbing off will close window"><i aria-hidden="true" class="rbc-icon rbc_close"></i><span class="accessible">Close Region Help - Remember Me Button - tabbing off will close window</span></div>
                                            <span class="accessible">End of Region Help - Remember Me</span>
                                        </div>
                                    </div>


                                </div>
                        </div>
                        <div class="formLinks">
                            <a href="javascript:document.forgotUsername.submit();" tabindex="6" class="formLinksFirstA">Recover Your Username</a>
                        </div>
                    </div>
                    <!-- CC Text Input Ends -->

                    <!-- Password Input Starts -->
                    <div class="row formBlock lastBlock">
                        <label for="Q1" class="signInLabel">Password<span class="accessible"> (required)</span></label>
                        <div class="inputWrapper">
                            <input required="required" type="password" name="password" id="password" tabindex="3">
                            <button type="submit" tabindex="4" class="yellowBtnLarge">Sign In</button>
                        </div>
                        <div class="formLinks">
                            <ul>
                                <li><a href="javascript:f3msignin_ForgotPassword();" tabindex="7">Reset Your Password</a>
								<ul>
								<li><a title="How-to video (Opens new window)" href="https://www.rbcroyalbank.com/onlinebanking/bankingusertips/password/reset-password.html" ga-on="click" ga-event-category="Body" ga-event-action="Click Link" ga-event-label="How to Video" target="_blank" tabindex="8">How-to Video<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Opens new window containing a video about how to reset your password)</span></a></li>
								</ul>
								</li>
                                <li><a title="FAQ about signing in (Opens new window)" tabindex="9" class="formLinksFirstB" href="javascript:kiosk_OpenWinRTB( 'https://www.rbcroyalbank.com/onlinebanking/remember_my_card/about.html', 'RTB', kiosk_Type3X, kiosk_Type3Y, kiosk_Type3R );">FAQ about signing in<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Opens new window)</span></a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Password Input Ends -->
                  </fieldset>
                </form>
              </section>
              <!-- Secondary signin Starts -->
                <section id="secondarySignIn" class="col-xs-6">
                    <div id="signinEnrollWidget" class="secondarySignInWidget">
                        <h2>New to Online Banking?</h2>
                        <p>Discover the benefits of banking online.</p>
                        <button type="button" onclick="location.href='/cgi-bin/rbaccess/rbcgi3m01?F6=1&amp;F7=IB&amp;F21=IB&amp;F22=HT&amp;REQUEST=IBOnlineEnrollLink&amp;LANGUAGE=ENGLISH'" class="blueBtnChevron" title="Enrol Now in Online Banking">Enrol Now <span class="accessible">in Online Banking</span><i aria-hidden="true" class="rbc-icon rbc_chevron"></i></button>
                    </div>
                    <div id="signinServicesSelector" class="secondarySignInWidget formBlock selectSec">
                        <h2>Other Online Services</h2>
                        <div class="formInputInline">
                            <form action="javascript:submitOtherOnlineMenu1();" id="serviceSelector" name="serviceSelector" class="navbar-form-alt">
                                <div class="form-group">
                                    <div class="input-group">
                                        <label for="selectService" class="formLabelInline accessible">Other Online Services</label>
                                        <select id="selectService" name="selectService" class="form-control">
                                            <option value="/english/netaction/sgne.html">RBC Direct Investing</option>
                                            <option value="/english/ris/pcd/sgne.html">DS Online</option>
                                            <option value="/cgi-bin/rbaccess/rbcgi3m01?F6=1&amp;F7=IB&amp;F21=IB&amp;LANGUAGE=ENGLISH&amp;F22=IB&amp;REQUEST=ErnexLink">RBC Rewards</option>
                                            <option value="/english/wm/sgne.html">PH&amp;N Investment Counsel</option>
											<option value="/english/wm/sgne.html">Estate &amp; Trust Services</option>
											<option value="https://www1.rbcbank.com/cgi-bin/rbaccess/rbunxcgi?F6=1&amp;F7=NS&amp;F21=IB&amp;F22=CN&amp;REQUEST=CenturaClientSignin&amp;LANGUAGE=ENGLISH">RBC Bank USA</option>
											<option value="https://caribbean.rbcroyalbank.com/#/login">RBC Caribbean</option>
											<option value="https://www6.rbc.com/webapp/ukv0/signin/logon.xhtml?lang=en">RBC Express</option>
											<option value="https://www.rbcglobaltrade.rbc.com/portal/PasswordLogon.jsp?organization=rbc&amp;branding=rbc&amp;locale=en_CA">RBC Global Trade</option>
											<option value="http://www.rbc.com/online-services.html">Other Services</option>
                                        </select>
                                        <button id="serviceSelectorBtn" form="serviceSelector" type="submit" class="blueBtnChevron" title="Go to RBC Direct Investing" ga-on="click" ga-event-category="Body" ga-event-action="Click Button" ga-event-label="Go">Go <span class="accessible">to RBC Direct Investing</span><i aria-hidden="true" class="rbc-icon rbc_chevron"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
              <!-- Secondary signin Ends -->
            </div>
            <!-- SignIn Banner Ends-->
            <!-- SignIn Maintenance Starts -->
       <div id="publicNotice">
       </div>

            <div id="serviceNotice">
       </div>
            <!-- SignIn Maintenance Ends -->


            <!-- OLB Links Starts-->
            <div id="olbLinks" class="row row-eq-height">
              <section id="spotlight" class="col-xs-4 boxShadow">   <h3>In the Spotlight</h3><ul>		<li><a title="Aug 2, 2018 - Switching your mortgage? Try RBC Mortgage Mover<sup>TM</sup>, and find out what you could be conditionally pre-approved for in as little as 60 seconds. (Opens new window)" href="javascript:kiosk_OpenWinRTB('https://www.rbcroyalbank.com/onlinebanking/bankingusertips/notices/mortgage-mover.html', 'RTB', 40, 50, kiosk_Type1R)">Aug 2, 2018 - Switching your mortgage? Try RBC Mortgage Mover<sup>TM</sup>, and find out what you could be conditionally pre-approved for in as little as 60 seconds.<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Opens new window)</span></a></li>		<li><a title="June 15, 2018 - New RBC Mobile app features (Opens new window)" href="javascript:kiosk_OpenWinRTB('https://www.rbcroyalbank.com/onlinebanking/bankingusertips/notices/new-mobile-app-features.html', 'RTB', 40, 50, kiosk_Type1R)">June 15, 2018 - New RBC Mobile app features<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Opens new window)</span></a></li></ul>
<!-- MKTSPACEPT.INC ends -->
              </section>
              <section id="staysafeonline" class="col-xs-4 boxShadow">   <h3>Stay Safe Online</h3><ul><li><a title="Learn about email and website fraud (Opens new window)" href="javascript:kiosk_OpenWinRTB('http://www.rbc.com/privacysecurity/ca/email-and-website-fraud-1.html', 'RTB', 40, 50, kiosk_Type1R)">Learn about email and website fraud<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Opens new window)</span></a></li><li><a title="Report a concern (Opens new window)" href="javascript:kiosk_OpenWinRTB('http://www.rbc.com/privacysecurity/ca/contact-us.html', 'RTB', 40, 50, kiosk_Type1R)">Report a concern<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Opens new window)</span></a></li><li><a title="Practice Safe Computing (Opens new window)" href="javascript:kiosk_OpenWinRTB('http://www.rbc.com/privacysecurity/ca/steps-for-safe-computing.html', 'RTB', 40, 50, kiosk_Type1R)">Practice Safe Computing<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Opens new window)</span></a></li><li><a title="Common schemes and scams (Opens new window)" href="javascript:kiosk_OpenWinRTB('http://www.rbc.com/privacysecurity/ca/schemes-and-scams.html', 'RTB', 40, 50, kiosk_Type1R)">Common schemes and scams<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Opens new window)</span></a></li><li><a title="Privacy and Security (Opens new window)" href="javascript:kiosk_OpenWinRTB('http://www.rbc.com/privacysecurity/ca/', 'RTB', 40, 50, kiosk_Type1R)">Privacy and Security<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Opens new window)</span></a></li></ul>
              </section>
              <section id="securityguarantee" class="col-xs-4 boxShadow">
                <h3>RBC Security Guarantee</h3>
                <p><span class="bold">We will fully reimburse any unauthorized transactions made in RBC Royal Bank Online Banking.</span></p>
                <p><a href="http://www.rbcroyalbank.com/online/rbcguarantee.html" title="Learn More About RBC Security Guarantee">Learn More<span class="accessible"> About RBC Security Guarantee</span></a></p>
              </section>
            </div>
            <!-- OLB Links Ends-->
          </section>        </main>
        <!-- Main Container Ends -->
        <!-- Footer Starts -->
        <footer role="navigation" aria-label="Popular Links" class="row">
            <!-- Footer Columns / Footer Links **** Starts -->
<section id="footerWrapper" class="row row-eq-height">
    <div class="footerCols col-xs-15">
        <h4>Managing Your Account</h4>
        <ul class="footerLinks">
          <li><a href="http://www.rbcroyalbank.com/products/deposits/lost-stolen-card.html">Report a lost or Stolen Card</a></li>
          <li><a href="http://www.rbcroyalbank.com/products/deposits/pre-authorized-bill-payments.html">Pre-Authorized Bill Payment</a></li>
          <li><a href="http://www.rbcroyalbank.com/products/deposits/interac-online.html">Interac* Online</a></li>
          <li><a href="http://www.rbcroyalbank.com/products/deposits/order-cheques.html">Order Cheques</a></li>
        </ul>
      </div>
      <div class="footerCols col-xs-15">
        <h4>Customer Service</h4>
        <ul class="footerLinks">
          <li><a href="http://www.rbcroyalbank.com/products/deposits/customer-service.html">General Inquiries</a></li>
          <li><a href="https://www.rbcroyalbank.com/cgi-bin/deposits/pda/apply.cgi">Open an Account</a></li>
          <li><a href="http://maps.rbc.com/index.en.asp">Branch &amp; ATM Locator</a></li>
          <li><a href="http://www.rbcroyalbank.com/online/index.html">Online Banking</a></li>
        </ul>
      </div>
      <div class="footerCols col-xs-15">
        <h4>Rates &amp; Fees</h4>
        <ul class="footerLinks">
          <li><a href="http://www.rbcroyalbank.com/products/deposits/additional-services.html">Additional Service Fees</a></li>
          <li><a href="http://www.rbcroyalbank.com/products/depositregister/index.html">CDIC Information</a></li>
          <li><a title="Service Charge and Interest Rates (Opens new window)" target="_blank" onclick="return popupHelp(this.href)" href="https://www.rbcroyalbank.com/onlinebanking/servicech.html">Service Charge and Interest Rates<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Opens new window)</span></a></li>
        </ul>
      </div>
      <div class="footerCols col-xs-15">
        <h4>Security Center</h4>
        <ul class="footerLinks">
          <li><a href="http://www.rbcroyalbank.com/online/rbcguarantee.html">Online Banking Guarantee</a></li>
          <li><a href="http://www.rbc.com/privacysecurity/ca/online-privacy.html">Protecting Your Privacy</a></li>
          <li><a href="http://www.rbc.com/privacysecurity/ca/how-rbc-helps-to-protect-you-against-fraud.html">Customer Information on Fraud</a></li>
        </ul>
      </div>
      <div class="footerCols col-xs-15 footerColsLast">
        <h4>Advice &amp; Tools</h4>
        <p>Visit the <a class="rbcadvice" href="http://www.rbcadvicecentre.com/">RBC Advice Centre</a> to see how we can help you</p>
      </div>
</section>            <!-- Footer Columns / Footer Links **** Ends -->
        </footer>
        <!-- Footer Ends -->
    <!-- Legal & Bottom links Starts-->
<div id="legal" class="row">
        <p>
            Royal Bank of Canada Website, &copy; 1995-2019
            <a title="Privacy &amp; Security (Opens new window)" href="javascript:kiosk_OpenWinRTB( 'http://www.rbc.com/privacysecurity/ca/', 'RTB', kiosk_Type2X, kiosk_Type2Y, kiosk_Type2R )">Privacy &amp; Security<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Opens new window)</span></a>
            <a title="Legal (Opens new window)" href="javascript:kiosk_OpenWinRTB( 'http://www.rbc.com/legal/', 'RTB', kiosk_Type3X, kiosk_Type3Y, kiosk_Type3R )">Legal<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Opens new window)</span></a>
            <a title="Accessibility (Opens new window)" href="javascript:kiosk_OpenWinRTB( 'http://www.rbc.com/accessibility/', 'RTB', kiosk_Type3X, kiosk_Type3Y, kiosk_Type3R )">Accessibility<i aria-hidden="true" class="rbc-icon rbc_new_window"></i><span class="accessible"> (Opens new window)</span></a>
        </p>
</div>
    <!-- Footer Legal Nav Ends-->


      </div>
    <!-- RBC Wrapper Ends -->
    </div>
    <!-- All scripts should be  placed at the bottom-->
    <!-- Scripts Start-->
        <script src="../../uos/external/jquery/1.11.3/jquery.minc9f0.js?8"></script>
        <script src="../../uos/external/bootstrap/3.3.5/js/bootstrap.minc9f0.js?8"></script>
        <script src="../../uos/external/jQuery-Autocomplete/1.2.24/js/jquery.autocompletec9f0.js?8"></script>
        <script  src="../../uos/common/javascript/initelemstatesc9f0.js?8" type="text/javascript"></script>
        <script src="../../uos/3m/javascript/customc9f0.js?8"></script>
        <script src="../../uos/3m/javascript/accessibilityc9f0.js?8"></script>
        <script>
// 3MDELTA.JS
{
  var cdate = new Date();
  var delta = Math.round( cdate.valueOf() / 1000 );
  var pDelta = rbcGetCookie( "3mDELTA", null );
  var dtype = '0';

  if ( pDelta != null )
  {
    var loc = pDelta.indexOf( 'https://www1.royalbank.com/', 0 );
    if ( loc != -1 )
      dtype = pDelta.substring( loc + 1, pDelta.length );
  }

  cdate = new Date( cdate.valueOf() + 604800000 ); // 7 days

  if ( browser_IE || browser_IE4 || browser_MAC || browser_IE4M )
  {
    if ( delta < 2000000000 && delta > 315532800 )  // sanity test -- This will break in 2033
    {
      delta -= 1522413811;
      if ( delta > -60 && delta < 60 ) delta = 0;
      rbcSetCookie( "3mDELTA", delta + "/" + dtype, cdate.toGMTString(), "https://www1.royalbank.com/" );
    }
  }
  else rbcSetCookie( "3mDELTA", "0/" + dtype, cdate.toGMTString(), "https://www1.royalbank.com/" );

  if ( rbcGetCookie( "3mDELTA", null ) == null )
  {
  }
}
// 3MDELTA.JS
        </script>
    </body>

</html>
