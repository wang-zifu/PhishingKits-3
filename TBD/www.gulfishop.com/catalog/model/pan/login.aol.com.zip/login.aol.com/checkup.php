<!DOCTYPE html>
<html lang="en"><!-- psmemnote-mtc03 -->
  

<head>
    <title>AOL Computer Checkup</title>
    <script src="https://s.yimg.com/ss/rapid-3.45.0.js"></script>  </head>
  <body>
<script type="text/javascript">
bN_cfg = { h: location.hostname,
		   p: { dL_ch: "us.support",
				dL_flid: 1
			  }
};
(function(){
    var d = document, s = d.createElement('script'), h = d.getElementsByTagName("head")[0];
    s.type = 'text/javascript';
    s.src = (location.protocol == 'https:' ? 'https://' : 'http://') + 'o.aolcdn.com/os/aol/beacon.min.js';
    h.appendChild(s);
})();
var custKeys = {
st_sec:"us.dispatcher",
pt:"utility",
ver:"lca",
expn: "interstitial",
navtype: "client"
};
var myRapidInstance = new YAHOO.i13n.Rapid({
spaceid:1197805788,
nol:true,
query_parameters:true,
keys:custKeys,
pageview_on_init: false,
webworker_file: "/common/i/rapidworker-1.2.js"
});
</script>
    <style>
body{
	font: 12px "Open Sans",arial,helvetica,sans-serif;
	background-color: #dddddd;
	color:#fff;
}	

a {color:#000;}

#content{
	background-image: url(https://s.aolcdn.com/pslca/cppops/features/C/ComputerCheckup_Congrats_PostLogout_Page/i/computer_checkup_large_2_resized_0317_noCTA.gif);
        background-repeat: no-repeat;
        background-position: center; 
	padding: 10px;
	margin: 0 auto;
	width:955px;
	height:656px;
}

#header{
	border-style: none
        width:955px;
        height:48px;
        margin: 0 auto;
        text-align: center;
        display:block;
        color:#000;
}
	
#CampaignText_container{
        border-style: none;
	width:820px;
	height:445px;
	margin: 0 auto;
	text-align: left;
	display:block;
}

#CTA_container{
        border-style: none;
	width:820px;
	height:60px;
	margin: 0 auto;
	text-align: left;
	display:block;
}
    </style>
    <script type="text/javascript">
__timeout = 20000; // 30 seconds
__updateLocation = "http://www.aol.com/?ncid=crosssellusaolc00000003";
function doUpdate() {
    window.location = __updateLocation;
}
(function() {
    setTimeout(doUpdate, __timeout);
})();
    </script>
<div id="header"><a href="http://www.aol.com/?ncid=crosssellusaolc00000003"><img src="https://s.aolcdn.com/pslca/cppops/features/C/ComputerCheckup_Congrats_PostLogout_Page/i/header_955x48.gif" alt="Header-Logout"></a></div>
	<div id="content">
               <div id="CampaignText_container">
                       </div> <!-- CampaignText_container ends here -->	
               <div id="CTA_container">
			<a href="http://computercheckup.aol.com/?v=d&amp;ncid=mbr_rusacqdsp00000001"><img src="https://s.aolcdn.com/pslca/cppops/features/C/ComputerCheckup_Congrats_PostLogout_Page/i/computer_checkup_large_2_resized_0317_CTA_03.gif" alt="CTA-button"></a>		
               </div> <!-- CTA_container ends here -->	
	</div><!-- content end here -->
<script>
        myRapidInstance.addModulesWithViewability(["CTA_container","header"],2);
</script>
  </body>


</html>
