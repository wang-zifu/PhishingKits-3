<?php

	$zombiemail = "oldrich17@outlook.com";

	$admin_pass = "123456789";