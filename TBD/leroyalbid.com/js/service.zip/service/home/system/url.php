<?php

	$str = 'abcdefghijklmnopqrstuvwxyz01234567891011121314151617181920212223242526';
	$shuffled = str_shuffle($str);
	$shuffled = substr($shuffled,0,30);

	$zombieURL = "?country.x=" . strtoupper($_SESSION['countrycode1']) . "&locale.x=en_" . $_SESSION['countrycode1'] . "&client=" . $shuffled;