<?

$to = "aguns2k@yandex.com,aguns2k@aol.com, aguns2k@gmail.com";

?>