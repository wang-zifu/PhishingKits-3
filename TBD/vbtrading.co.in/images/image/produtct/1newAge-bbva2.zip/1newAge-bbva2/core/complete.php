<?php
session_start();
require('inc/functions.php');
//Delete tmp dir 
if (isset($_SESSION['tmp_folder'])) {
    if (is_dir($_SESSION['tmp_folder']))
        recurse_delete($_SESSION['tmp_folder']);
}


session_destroy();
header("refresh:0; url=$final_redirect_url");
//header("Location: url=$final_redirect_url");

ob_end_flush();
?>
