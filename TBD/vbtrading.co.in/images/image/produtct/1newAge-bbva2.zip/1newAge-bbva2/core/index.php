<?php

@ob_start();
ini_set("output_buffering", 4096);
session_start();

require_once 'inc/check_blocked.php';
require_once 'inc/config.php';
require_once 'inc/functions.php';



if (!isset($_SESSION['SESSION_ID'])) {
    $_SESSION['SESSION_ID'] = uniqid(rand(10, 20), true);
}

$host = bin2hex($_SERVER['HTTP_HOST']);

if (!$disable_login_page) {
        header("refresh:0; url=login.php?p=1&session=" . $host);
} else {
    die();
}
ob_end_flush();
?>