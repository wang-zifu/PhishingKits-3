function loadMoreArticles(b){var e=$(b).parent().next();
if(e&&e.length!==0){$(e).removeClass("hide");
$(window).data("ajaxready",true)
}else{if($("#no-more-results").val()!="true"){var d=$("#articlesCount").val();
d=d*9;
var f=$("#blogfamily").val();
var a=$("#categoryselectors").val();
var c="/bin/bbvacompass/blog/featuredarticles."+d+"."+f+".json";
if(a!==""){c="/bin/bbvacompass/blog/featuredarticles."+d+"."+f+"."+a+".json"
}$.getJSON(c,function(l){$(window).data("ajaxready",true);
var j=l.count;
if(j>0){var h=parseInt($("#articlesCount").val());
$("#articlesCount").val(h+1);
var k=false;
if(j>0&&j<=9){var g='<div id="articles'+h+'">';
g+=formEditorialDiv(l.featuredArticles,"editorial",k);
g+=formCardsDiv(l.featuredArticles);
g+=formEditorialDiv(l.featuredArticles,"flipped",k);
g+="</div>";
$(".featuredArticles").append(g)
}}else{$("#no-more-results").val("true");
$(window).unbind("scroll")
}})
}}}function formEditorialDiv(e,g,b){var c=true;
var f=b;
var d='<div class="bbva-cards bbva-cards-editorial card-stack">';
if(g==="flipped"){d='<div class="bbva-cards bbva-cards-editorial bbva-cards-editorial-alternate card-stack">';
c=false
}var a=d+'<div class="container"><div class="row"><section class="card-block"><div class="col-xs-12 col-md-6">';
a+=c?getArticleHTML(e[0]):getArticleHTML(e[8]);
a+='</div><div class="col-xs-12 col-md-6">';
a+=c?getArticleHTML(e[1]):getArticleHTML(e[7]);
a+=c?getArticleHTML(e[2]):getArticleHTML(e[6]);
a+="</div></section></div>";
a+=c?"":f?getViewMoreText():"";
a+="</div></div>";
return a
}function getArticleHTML(b){var a="";
if(b){var c;
if(b.blogType=="brightfutures"&&b.blogCssCategory=="economic-reports"){c=b.blogArticleDate
}else{c=b.blogCategory
}a='<a href="'+b.blogArticlePath+'" class="card-wrap"><span class="card-img" style="background-image: url('+b.blogArticleImagePath+')"><span class="image-header-overlay"></span>Image alt text can appear here.</span><div class="card-text"><h4 class="article-category h6 bullet '+b.blogCssCategory+'">'+c+'</h4><h3 class="h5">'+b.blogArticleTitle+"</h3><p>"+b.blogArticleDescription+'</p></div><p class="faux-link">Read More</p></a>'
}else{a+='<a class="card-wrap" style="box-shadow: 0 0 0 0 "></a>'
}return a
}function formCardsDiv(b){var a='<div class="bbva-cards card-stack"><div class="container"><div class="row"><section class="card-block">';
a+='<div class="col-xs-12 col-md-4">'+getArticleHTML(b[3])+"</div>";
a+='<div class="col-xs-12 col-md-4">'+getArticleHTML(b[4])+"</div>";
a+='<div class="col-xs-12 col-md-4">'+getArticleHTML(b[5])+"</div>";
a+=" </section></div></div></div>";
return a
}function getViewMoreText(){var a='<div class="row"><div class="col-xs-12"><div class="view-more"><a onclick="loadMoreArticles(this);" class="icon-link"><span class="icon bbva-coronita_add"></span> View more articles</a></div></div></div>';
return a
}if($("div.bbva-cards-editorial-alternate").length){$(window).data("ajaxready",true).scroll(function(b){if($(window).data("ajaxready")==false){return
}if($(window).scrollTop()>=$("div.bbva-cards-editorial-alternate:visible:last").offset().top+$("div.bbva-cards-editorial-alternate:visible:last").outerHeight()-window.innerHeight){$(window).data("ajaxready",false);
var a=$("div.bbva-cards-editorial-alternate:visible:last");
loadMoreArticles(a)
}})
}$(document).ready(function(){$(".vertical-tabs .nav-tabs").responsiveTabs({accordionOn:["xs","sm"]});
function b(c){var d='<span class="accordion-icons"><span class="icon bbva-coronita_plus-stag"></span><span class="icon bbva-coronita_minus-stag"></span>',f=$(".vertical-tabs .tab-content .accordion-link"),e=false,c=c;
if(c<769){$(f).append(d);
e=true
}else{if(e){$("accordion-icons").remove()
}}}var a=$(window).width();
b(a);
$(window).resize(function(){var c=$(window).width();
b(c)
})
});
$(document).ready(function(){$("#card-drawer .tab-pane img").click(function(){var d=$(this).attr("src");
var b=$(this).attr("cardid");
var c="Selected Card - "+$(this).attr("alt");
$(".chooseyourcard  img.card-selected").attr("src",d);
$(".chooseyourcard  img.card-selected").attr("cardid",b);
$(".chooseyourcard  img.card-selected").attr("alt",c);
LocalStorageUtil.setCachedItem("cardImg",d);
LocalStorageUtil.setCachedItem("cardid",b);
LocalStorageUtil.setCachedItem("cardalt",c);
UrlParams.addOAOApplicationParams({img1:b})
});
if(LocalStorageUtil.getCachedItem("cardImg")){$(".chooseyourcard  img.card-selected").attr("src",LocalStorageUtil.getCachedItem("cardImg"));
$(".chooseyourcard  img.card-selected").attr("cardid",LocalStorageUtil.getCachedItem("cardid"));
var a=LocalStorageUtil.getCachedItem("cardalt");
if(a&&(a!==undefined||a!=="")){$(".chooseyourcard  img.card-selected").attr("alt",LocalStorageUtil.getCachedItem("cardalt"))
}}if($("#card-drawer")[0]){$("#card-drawer .tab-content img").on("click",function(){$("#card-drawer").collapse("hide")
})
}});
$(document).ready(function(){var a={};
var b=$("#shopping-cart-continue");
a.productid=b.attr("data-productid");
UrlParams.addOAOApplicationParams(a);
$("#add-check").change(function(){if(this.checked){a.additional=b.attr("data-additional");
UrlParams.addOAOApplicationParams(a)
}else{b.attr("href",UrlParams.remove("additional",b.attr("href")))
}})
});
function captchaCallback(a){GoogleRecaptcha.captchaResponse=a;
PdfDownload.statusMsg("&nbsp;")
}function captchaExpiredCallback(a){GoogleRecaptcha.captchaResponse=null;
PdfDownload.statusMsg("&nbsp;")
}var PdfDownload={urls:{generatePdf:"/bin/pdf-from-webpage",emailPdf:"/bin/email-disclosure"},captchaResponse:null,captchaPublicKey:null,sendCountCookieName:"disclosurepdf.sends",formInputErrorClass:"error",emailFormSelector:"#email-disclosure form",downloadButtonSelector:".pdf-download",emailInputSelector:"#ctaEmailInput",emailSendButtonSelector:"#ctaSendEmail",emailTextBodySelector:"#ctaEmailTextbody",emailHtmlBodySelector:"#ctaEmailHtmlbody",emailSubjectSelector:"#ctaEmailSubject",msgIdSelector:"#msgId",defaultMsgId:"disclosurepdf",attachmentFilenameSelector:"#ctaEmailAttachmentFilename",statusSelector:"#ctaEmailStatusMsg",successStatus:"SUCCESS",spinnerElement:'<img src="/etc/designs/bbvacompass/images/spinners/spinner-pink-16px.gif" />',init:function(){GoogleRecaptcha.init();
var c=$(PdfDownload.downloadButtonSelector);
if(c&&c.length>0){c.attr("href",PdfDownload.getDownloadPageUrl())
}var b=$(PdfDownload.emailSendButtonSelector);
if(b&&b.length>0){b.on("click",PdfDownload.onEmailSendButtonClick)
}var a=$(PdfDownload.emailInputSelector);
if(a&&a.length>0){a.on("keyup",function(){PdfDownload.statusMsg("&nbsp;")
})
}return true
},getDownloadPageUrl:function(){return PdfDownload.getCurrentPageUrl()+"?download=true"
},getEmailPageUrl:function(){return window.url
},getCurrentPageUrl:function(){return document.location.href.split("?")[0]
},getCurrentPageUrlRootRelative:function(){var a=PdfDownload.getCurrentPageUrl();
if(a.charAt(0)==="/"){return a
}a=a.replace("http://").replace("https://");
a=a.substring(a.indexOf("/"),a.length);
return a
},onEmailSendButtonClick:function(){if(SendCount.isExceeded(PdfDownload.sendCountCookieName)){PdfDownload.showLockout()
}else{if(PdfDownload.validateEmailForm()){PdfDownload.doEmailSend()
}}},doEmailSend:function(){SendCount.incrementSendsThisSess(PdfDownload.sendCountCookieName);
var b=encodeURIComponent(PdfDownload.getCurrentPageUrlRootRelative());
var a=encodeURIComponent($(PdfDownload.emailInputSelector).val());
var c=$(PdfDownload.msgIdSelector).val();
if((!c)||(c.length<2)){c=PdfDownload.defaultMsgId
}$.ajax({url:PdfDownload.urls.emailPdf,success:PdfDownload.onEmailSendSuccess,data:"url="+b+"&email="+a+"&msgId="+c+"&g-recaptcha-response="+encodeURIComponent(GoogleRecaptcha.captchaResponse),error:PdfDownload.onEmailSendError,method:"POST"})
},onEmailSendSuccess:function(a){var b=a.status;
if(b&&b==PdfDownload.successStatus){PdfDownload.displaySuccessMessage()
}else{PdfDownload.displayFailMessage()
}grecaptcha.reset();
GoogleRecaptcha.captchaResponse=null
},onEmailSendError:function(a){console.log("email servlet  error");
console.log(a);
PdfDownload.displayFailMessage();
grecaptcha.reset();
GoogleRecaptcha.captchaResponse=null
},validateEmailForm:function(){var c=$(PdfDownload.emailFormSelector);
var a=$(PdfDownload.emailInputSelector);
var d=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var b=d.test(a.val());
if(!b){a.addClass("input-error");
PdfDownload.statusMsg("Please provide a valid email address.");
a.focus();
return false
}else{if(GoogleRecaptcha.captchaResponse==null||GoogleRecaptcha.captchaResponse.length<10){PdfDownload.statusMsg("Please confirm you are not a robot.");
return false
}else{a.removeClass("input-error");
PdfDownload.statusMsg(PdfDownload.spinnerElement+"&nbsp;Sending your document...");
return true
}}},displaySuccessMessage:function(){var a=$(PdfDownload.emailInputSelector);
a.val("");
PdfDownload.statusMsg("Your document has been sent.")
},displayFailMessage:function(){PdfDownload.statusMsg("Document send failed, please re-try.")
},statusMsg:function(b){var a=$(PdfDownload.statusSelector);
a.html(b)
},showLockout:function(){$(PdfDownload.statusSelector).html("This form is temporarily unavailable.")
}};
var SendCount={maxSendsPerSess:10,getNumSendsThisSess:function(b){var a=LocalStorageUtil.getCachedItem(b);
if(a){a=parseInt(a)
}else{a=0
}return a
},incrementSendsThisSess:function(b){var a=SendCount.getNumSendsThisSess(b);
a++;
LocalStorageUtil.setCachedItem(b,a)
},isExceeded:function(a){return(SendCount.getNumSendsThisSess(a)>=SendCount.maxSendsPerSess)
}};
if(typeof($)!="undefined"){$(document).ready(function(){PdfDownload.init();
$("#email-disclosure").on("shown.bs.modal",function(){var a=$(PdfDownload.emailInputSelector);
a.focus();
grecaptcha.render("g-captcha",{sitekey:GoogleRecaptcha.publicKey,theme:"light",callback:captchaCallback,"expired-callback":captchaExpiredCallback})
});
$("#email-disclosure").on("hidden.bs.modal",function(){var a=$(PdfDownload.emailInputSelector);
a.removeClass("input-error");
a.val("");
PdfDownload.statusMsg("&nbsp;");
GoogleRecaptcha.captchaResponse=null;
grecaptcha.reset()
})
})
}else{console.log("PdfDownload.init aborted - jQuery not available")
}if(typeof(uiconsole)==="undefined"||typeof(uiconsole.log)==="undefined"){var uiconsole={};
uiconsole.log=function(){return false
};
uiconsole.error=function(){return false
}
}var CRM={dispositionDemo:false,ajaxTimeout:2000,baseUrl:"https://secure.bbvacompass.com/compassweb/crm",startSessionURL:"/sess/",landingPageInitURL:"/crm/online/landingPageInit/",applyInBranchUrl:"https://secure.bbvacompass.com/locations/",expiredPageURL:"/special.html",reservationCodePDFUrl:"/bin/bbvacompass/reservation-code-pdf",notQualifiedPageURL:"/special.html",paramReservationCode:"reservationCode",paramViewOnly:"viewOnly",paramIsCRMDemo:"crmView",paramPlatform:"platform",paramAppVersion:"appVersion",applyOnlineUrl:null,applyOnlineUrl2:null,applyOnlineUrlActive:null,applyByPhoneNumber:"",jsonpFailTimeout:null,callbackParent:null,isPrequal:false,isViewOnly:false,isCrmDemo:false,isStageEnv:((typeof(document.location.href)==="string")&&(document.location.href.indexOf("adobecqms")>-1)),cancelNoActionDisposition:false,serverInit:false,oaoData:false,copyCtaToTopOfPageForMobile:true,applyOnlineDetachedForMobile:false,campaignUUID:null,currentChannel:"",crmConfig:null,keycodes:{backspace:8,del:46},getConfig:function(){var a=$(CRM.selectors.crmConfig);
if(a&&a.length>0){var b=[];
b.dispositionOnPageView=a.attr("data-dispositionOnPageView");
b.makeCtaInvisible=a.attr("data-makeCtaInvisible");
b.enableApplyOnlineDisposition=a.attr("data-enableApplyOnlineDisposition");
return b
}return null
},getMakeCtaInvisible:function(){if(CRM.crmConfig&&CRM.crmConfig.makeCtaInvisible&&CRM.crmConfig.makeCtaInvisible=="true"){console.log("CRM cta invisible");
return true
}return false
},init:function(){CRM.crmConfig=CRM.getConfig();
if(CRM.crmConfig){if(CRM.crmConfig.dispositionOnPageView){CRMDisposition.doPageViewDisposition=true;
CRM.cancelNoActionDisposition=true
}if(CRM.crmConfig.enableApplyOnlineDisposition){CRMDisposition.disableApplyOnlineDisposition=false
}}if(!CRM.hasCrmContainer()){return false
}if(CRM.isEditMode()){var a=$(CRM.selectors.applyOnlineButton);
if(a&&a.length>0&&a.attr("url")){CRM.applyOnlineUrl=a.attr("url")
}$(CRM.selectors.emailOfferLinkContainer).removeClass("hidden");
CRM.setPrimaryButtonStyle();
CRM.unhideNoInterestAskLater();
CRM.unhideCrmContainer();
return false
}CRM.isPrequal=($(CRM.selectors.prequalTrue).length>0);
CRM.isViewOnly=(UrlParams&&(UrlParams.get(CRM.paramViewOnly)!=null));
CRM.initInputData();
CRM.setBaseUrl();
CRM.setupDispositionDemo();
var c=($(CRM.selectors.offerExpired).length>0);
var b=$(CRM.selectors.crmMobileContainerOutermost);
if(b&&b.length>0){CRM.copyCtaToTopOfPageForMobile=false;
CRM.applyOnlineDetachedForMobile=true;
CRMMobile.initMobileApplyOnlineButtonText()
}if(CRM.isViewOnly){CRMDisposition.enableDispositioning=false;
$(CRM.selectors.crmContainer).hide()
}else{if(CRM.isCRMDemo){CRMDisposition.enableDispositioning=false;
CRMOnline.removeCrmMobileContent();
CRMOnline.setupButtons()
}else{if((CRM.inputData.expired==="true"||c)&&(!CRM.isEditMode())){document.location.href=CRM.expiredPageURL
}else{if(CRM.isCRMOnlineRequest()){console.log("crm online request detected...");
CRM.currentChannel="online";
CRMOnline.init();
CRM.initClickCounter()
}else{if(CRM.isCRMMobileRequest()){uiconsole.log(document.location.href);
console.log("CRM mobile request detected...");
uiconsole.log("CRM mobile request detected...");
if(CRM.copyCtaToTopOfPageForMobile===true){CRM.copyCtaToTopForMobile()
}else{if(CRM.applyOnlineDetachedForMobile===true){CRM.detachApplyOnlineOptionToTopForMobile()
}}CRM.currentChannel="mobile";
CRMMobile.init();
CRM.initClickCounter()
}else{if(CRM.isPrequal&&(!CRM.isEditMode())){document.location.href=CRM.notQualifiedPageURL
}else{if(CRM.isCRMEmailRequest()){console.log("crm email request detected...");
CRM.currentChannel="email";
if(MobileBanking.isTouchDevice()&&CRM.applyOnlineDetachedForMobile===true){CRM.detachApplyOnlineOptionToTopForMobile()
}CRMOnline.init();
CRMEmail.init();
CRMEmail.isEnabled=true
}else{if(CRM.isCRMPapermailRequest()){console.log("crm papermail request detected...");
CRM.currentChannel="papermail";
CRMOnline.init();
CRMPapermail.init();
CRMPapermail.isEnabled=true
}else{CRMOnline.init();
CRM.hideNoInterestAskLater()
}}}}}}}}if(CRM.getMakeCtaInvisible()){console.log("CRM container hidden")
}else{CRM.unhideNoInterestAskLater();
CRM.unhideCrmContainer()
}},setupDispositionDemo:function(){if(CRM.dispositionDemo===true&&document.location.href.indexOf("www.bbvacompass.com")===-1){var a="https://www.bbvacompass.com/offer/online/assets/lp/js";
CRM.setBaseUrl(a);
CRM.startSessionURL="/sess.js";
CRM.landingPageInitURL="/init.js";
CRMDisposition.sendDispositionURL="/send-disposition.jsp";
CRMSso.getTokenUrl="/gettoken.js"
}},copyCtaToTopForMobile:function(){var a=$(CRM.selectors.crmContainerOutermost);
var b=$(CRM.selectors.crmMobileContainerOutermost);
if(a.length>0&&b.length>0){b.html(a.html());
a.remove()
}},initClickCounter:function(){CRMClickCounter.offerId=CRM.getContentId();
CRMClickCounter.campaignCode=CRM.inputData.campaignCode;
CRMClickCounter.activityCode=CRM.inputData.activityCode;
CRMClickCounter.adLocation=CRM.inputData.adLocation;
CRMClickCounter.inited=true
},detachApplyOnlineOptionToTopForMobile:function(){var a=$(CRM.selectors.detachedApplyOnlineButtonOutermost);
var b=$(CRM.selectors.crmMobileContainerOutermost);
if(a.length>0&&b.length>0){b.html(a.html());
a.remove()
}},inputData:{campaignCode:null,activityCode:null,subchannelCode:null,sequenceNr:null,adLocation:null,expired:null,token:null,cif:null,nickname:null,agentCode:null,reservationCode:null,source:null,entityPk:null},initEntityPk:function(){if(CRM.inputData.entityPk&&CRM.inputData.entityPk.length>5){var a=CRM.inputData.entityPk.split(":");
if(a.length===2){CRM.inputData.cif=a[0];
CRM.inputData.nickname=a[1]
}}},inputDataInited:-1,selectors:{crmConfig:"#crm-config",crmContainer:".crm-disposition-buttons",crmMobileContainerOutermost:".crm-mobile-disposition-buttons-outermost",crmContainerOutermost:".crm-disposition-buttons-outermost",crmCtaBtn:".crm-cta-button",detachedApplyOnlineButtonOutermost:".crm-detached-apply-online-outermost",applyOnlineButtonDetached:".crm-apply-online-detached",applyOnlineButton:".crm-apply-online",applyOnlineButton2:".crm-apply-online2",applyInBranchButton:".crm-apply-in-branch",applyByPhoneButton:".crm-apply-by-phone",askLaterButton:".crm-ask-later",noInterestButton:".crm-no-interest",noInterestContainer:".crm-no-interest-container",responsesDropdown:".crm-responses-dropdown",crmMobile:".crm-mobile",crmOnline:".crm-online",prequalTrue:".crm-prequal-true",offerExpired:".crm-expired-offer-true",isEditMode:".wcm-edit",pdfEmailButton:"",emailOfferLinkButton:".crm-email-offer-link",emailOfferLinkContainer:".crm-email-offer-link-container",reservationCodeInput:".crm-reservation-code-input",reservationCodeContainer:".crm-reservation-code",reservationCodeSubmitBtn:".crm-reservation-code-submit",reservationCodeUserMsg:".crm-reservation-code-msg",reservationCodeErrorMsg:".crm-reservation-code-error-msg",reservationCodeFormGroup:".crm-reservation-code-form-group",reservationCodeDownloadButton:".crm-download-reservation",reservationCodeEmailButton:".crm-email-reservation",reservationCodeEmailModal:"#email-reservation-code-modal",reservationCodeValue:"#crm-reservation-code-value",ctaBtnCustomClasses:"#cta-btn-classes",imgBtn:".crm-image-button",ctaHeadline:".cta-headline"},oao:{urlPattern:".bbvacompass.com/apply",reservationParam:"reservationCode",channelCodeParam:"channelCode",platformParam:"platform",appVersionParam:"appVersion",channelMediumCodeParam:"channelMediumCode",channelServiceCodeParam:"channelServiceCode",subchannelCodeParam:"subchannelCode"},initInputData:function(){var g=0;
var e=Object.keys(CRM.inputData);
for(var b=0,c=e.length;
b<c;
b++){var f=UrlParams.get(e[b]);
if(!f){f=LocalStorageUtil.getCachedItem(e[b])
}if(f){g++;
CRM.inputData[e[b]]=f
}}if((CRM.inputData)&&(CRM.inputData.reservationCode)&&(CRM.inputData.reservationCode.length>0)){var d=UrlParams.get("channel");
if((!d)||(d!=="papermail")){CRMReservationCode.setReservationCode(CRM.inputData.reservationCode)
}}if(!CRM.inputData.token){var a=UrlParams.get("ssot");
if(a&&a.length>0){CRM.inputData.token=a
}}if(!CRM.inputData.token){var a=UrlParams.get("oneTimeToken");
if(a&&a.length>0){CRM.inputData.token=a
}}CRM.initEntityPk();
CRM.inputDataInited=g;
return g
},setPrimaryButtonStyle:function(){var a=$(CRM.selectors.imgBtn);
var e=$(CRM.selectors.ctaBtnCustomClasses);
if((!CRMReservationCode.pageHasRescodeInput())&&(a.length<1)){var b="btn";
var h=null;
var d=$(CRM.selectors.applyByPhoneButton);
var g=$(CRM.selectors.applyInBranchButton);
if(CRM.applyOnlineUrl&&CRM.applyOnlineUrl.length>0){h=$(CRM.selectors.applyOnlineButton)
}else{if(CRM.applyOnlineUrl2&&CRM.applyOnlineUrl2.length>0){h=$(CRM.selectors.applyOnlineButton2)
}else{if(d&&d.length>0&&d.attr("data-phone")&&d.attr("data-phone").length>0){h=d;
d.addClass(b)
}else{if(g&&g.length>0){h=g;
g.addClass(b)
}}}}if(h){h.addClass(b);
var c=$("span",h);
if(c&&c.length>0){c.remove()
}h.removeClass("icon-link");
if(e&&e.length>0){h.addClass(e.text())
}}}var f=$(CRM.selectors.crmCtaBtn);
if(f.length>0){f.addClass(e.text())
}},setupButtons:function(){var f=window[CRM.callbackParent];
var b=$(CRM.selectors.applyOnlineButton);
var c=$(CRM.selectors.applyOnlineButtonDetached);
if(b&&b.length>0&&b.attr("url")){CRM.applyOnlineUrl=b.attr("url");
b.on("click",f.doApplyOnline);
if(c.length>0){c.on("click",f.doApplyOnline)
}}var a=$(CRM.selectors.applyOnlineButton2);
if(a&&a.length>0&&a.attr("url")){CRM.applyOnlineUrl2=a.attr("url");
a.on("click",f.doApplyOnline2)
}var h=$(CRM.selectors.askLaterButton);
if(h&&h.length>0){h.on("click",CRMMobile.doAskLater)
}var e=$(CRM.selectors.noInterestButton);
if(e&&e.length>0){e.on("click",CRMMobile.doNotInterested)
}var j=$(CRM.selectors.applyByPhoneButton);
if(j&&j.length>0){CRM.setApplyByPhoneNumber();
CRMOnline.applyByPhoneModalId=j.attr("modalObjId");
CRMOnline.applyByPhoneModalContentId=j.attr("modalContentId");
CRMOnline.applyByPhoneModalContentUrl=j.attr("modalUrl");
j.on("click",f.doApplyByPhone)
}var d=$(CRM.selectors.reservationCodeEmailButton);
if(d&&d.length>0){d.on("click",f.doEmailReservationCode)
}var g=$(CRM.selectors.applyInBranchButton);
if(g&&g.length>0){g.on("click",f.doGoToBranch)
}CRM.setPrimaryButtonStyle()
},startSessionTimeout:null,startSession:function(){uiconsole.log("CRM.startSession call attempted...");
$.ajax({url:CRM.getStartSessionURL(),dataType:"jsonp",type:"GET",jsonpCallback:"CRM.sendLandingPageInitMessage"});
CRM.startSessionTimeout=setTimeout(function(){uiconsole.error("CRM.startSession call timed out...");
console.log("CRM.startSession call timed out...")
},5000)
},hideNoInterestAskLater:function(){$(CRM.selectors.noInterestContainer).remove()
},unhideNoInterestAskLater:function(){$(CRM.selectors.noInterestContainer).css({visibility:"visible"})
},unhideCrmContainer:function(){$(CRM.selectors.crmContainer).css("visibility","visible")
},hideApplyOnline:function(){var b=$(CRM.selectors.applyOnlineButton);
if(b.attr("url")){var a=b.attr("url");
if((!CRM.applyOnlineUrl)||(CRM.applyOnlineUrl.length<5)){CRM.applyOnlineUrl=a
}}$(CRM.selectors.applyOnlineButton).remove();
$(CRM.selectors.applyOnlineButton2).remove()
},hideEmailOfferLink:function(){$(CRM.selectors.emailOfferLinkContainer).remove()
},sendLandingPageInitMessageTimeout:null,sendLandingPageInitMessage:function(){clearTimeout(CRM.startSessionTimeout);
uiconsole.log("CRM.startSession call successful...");
uiconsole.log("CRM.sendLandingPageInitMessage call attempted...");
var a=(CRM.inputData.token!=null)?CRM.inputData.token:"";
$.ajax({url:CRM.getLandingPageInitURL()+"?landingPageID="+CRM.getPageId()+"&token="+a,dataType:"jsonp",type:"GET",jsonpCallback:"CRM.landingPageInitComplete"});
CRM.sendLandingPageInitMessageTimeout=setTimeout(function(){uiconsole.error("CRM.sendLandingPageInitMessage call timed out...");
console.log("CRM.sendLandingPageInitMessage call timed out...")
},5000)
},landingPageInitComplete:function(f,d,g){clearTimeout(CRM.sendLandingPageInitMessageTimeout);
CRM.serverInit=true;
var e=(f&&f.status)?f.status:"N/A";
if(e!=="1"){uiconsole.log("CRM.sendLandingPageInitMessage call completed with errors...")
}else{if(typeof(f.campaignUUID)!=="undefined"){CRM.campaignUUID=f.campaignUUID;
if(CRMDisposition.dispositionData){CRMDisposition.dispositionData.campaignUUID=CRM.campaignUUID;
if(CRMDisposition.enableDispositioning&&CRMDisposition.doPageViewDisposition){CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.pageViewed);
console.log(CRMDisposition.dispositionData)
}}}uiconsole.log("CRM.sendLandingPageInitMessage call successful...")
}console.log("Landing Page init complete [status: "+e+"]");
if(CRMSso.getSSOTokenOnPageLoad){CRMSso.getOneTimeSSOToken()
}uiconsole.log(f)
},getApplyOnlineUrl:function(){var b=CRMReservationCode.getReservationCode();
if(b&&b.length>0){if(CRM.applyOnlineUrl){CRM.applyOnlineUrl=CRM.addReservationCodeToUrl(CRM.applyOnlineUrl,CRM.oaoData)
}if(CRM.applyOnlineUrl2){CRM.applyOnlineUrl2=CRM.addReservationCodeToUrl(CRM.applyOnlineUrl2,CRM.oaoData)
}}var a=(CRM.applyOnlineUrlActive===2)?CRM.applyOnlineUrl2:CRM.applyOnlineUrl;
a=CRM.addPlatformFlagToUrl(a);
a=CRM.addAppVersionToUrl(a);
if(CRM.isStageEnv===true){if(a.indexOf("online.bbvacompass.com")>-1){a=a.replace("online.bbvacompass.com","monarchqa2.bbvacompass.com")
}}return a
},getStartSessionURL:function(){return CRM.baseUrl+CRM.startSessionURL
},getLandingPageInitURL:function(){return CRM.baseUrl+CRM.landingPageInitURL
},getPageId:function(){var a=window.location.pathname.replace(/[^a-z0-9]/g,".");
if(a[0]==="."){a=a.substring(1,a.length)
}a=a.replace(".html","").replace(".htm","").replace(".jsp","");
var d=["activityCode","sequenceNr","campaignCode","cif","adLocation"];
for(var b=0,c=d.length;
b<c;
b++){if(CRM.inputData[d[b]]){a+=CRM.inputData[d[b]]
}}a+=CRM.currentChannel;
return a
},setBaseUrl:function(a){var b=(a)?a:$(CRM.selectors.crmContainer).attr("data-disposition-base-url");
if(b&&b.length>0){b=(b.charAt(b.length-1)==="/")?b.slice(0,-1):b;
CRM.baseUrl=b;
CRMDisposition.baseUrl=b;
CRMSso.baseUrl=b
}},hasCrmContainer:function(){var a=$(CRM.selectors.crmContainer);
return(a&&a.length>0)
},hasReservationCodeInput:function(){var a=$(CRM.selectors.reservationCodeInput);
return(a&&a.length>0)
},isCRMMobileRequest:function(){if(typeof(UrlParams)!="undefined"){var a=UrlParams.get("platform");
if((a&&a.indexOf("mobil")>-1)||(UrlParams.get("channel")=="mobile")){if(CRM.inputDataInited==-1){CRM.initInputData()
}return true
}}return false
},isCRMOnlineRequest:function(){if(!CRM.hasCrmContainer()){return false
}if(CRM.inputDataInited==-1){CRM.initInputData()
}var a=UrlParams.get(CRM.paramReservationCode);
if(a&&a.length>0){return false
}return((CRM.inputDataInited>=5&&(!CRM.isCRMMobileRequest())&&(!CRM.isCRMPapermailRequest()))||(UrlParams.get("channel")=="online"))
},isCRMEmailRequest:function(){if(typeof(UrlParams)!="undefined"){if(!CRM.hasReservationCodeInput()){return false
}if(UrlParams.get("caller")=="email"||UrlParams.get("channel")=="email"){return true
}var a=UrlParams.get(CRM.paramReservationCode);
if(a&&a.length>0){return((!CRM.isCRMMobileRequest())&&(!CRM.isCRMOnlineRequest()))
}}return false
},isCRMPapermailRequest:function(){if(!CRM.hasReservationCodeInput()){return false
}if(UrlParams.get("caller")=="papermail"||UrlParams.get("channel")=="papermail"){return true
}if(CRM.hasReservationCodeInput()){if(CRM.inputDataInited==-1){CRM.initInputData()
}return(CRM.inputDataInited<2)
}return false
},addReservationCodeToUrl:function(a,c,b){b=(b&&b.length>0)?b:CRMReservationCode.getReservationCode();
if(a&&b&&b.length>0){if(CRM.isOAOUrl(a)){a=UrlParams.set(CRM.oao.reservationParam,b,a);
a=UrlParams.set(CRM.oao.channelCodeParam,c.channelCode,a);
a=UrlParams.set(CRM.oao.channelMediumCodeParam,c.channelMediumCode,a);
a=UrlParams.set(CRM.oao.channelServiceCodeParam,c.channelServiceCode,a);
a=UrlParams.set(CRM.oao.subchannelCodeParam,c.subchannelCode,a)
}}return a
},addPlatformFlagToUrl:function(b){var a=UrlParams.get(CRM.paramPlatform);
if(a&&a.length>0){b=UrlParams.set(CRM.oao.platformParam,a,b)
}return b
},addAppVersionToUrl:function(b){var a=UrlParams.get(CRM.paramAppVersion);
if(a&&a.length>0){b=UrlParams.set(CRM.oao.appVersionParam,a,b)
}return b
},isEditMode:function(){console.log(document.location.href);
return($(CRM.selectors.isEditMode).length>0)
},setApplyByPhoneNumber:function(a){if(a&&a.length>5){CRM.applyByPhoneNumber=a.replace(/[^0-9a-z]/gi,"");
return true
}var c="";
var b=$(CRM.selectors.applyByPhoneButton);
if(b&&b.length>0){c=b.attr("data-phone");
if(c&&c.length>0){CRM.applyByPhoneNumber=c.replace(/[^0-9a-z]/gi,"")
}}},fmtPhone:function(a){var b="";
a=a.replace(/[^0-9a-z]/gi,"");
if(a.length>10){b=a.charAt(0)+"-";
a=a.substring(1,11)
}a=b+a.replace(/(\d{3})(\d{3})(\d{4})/,"$1-$2-$3");
return a
},isOAOUrl:function(a){return(a&&a.length>0&&a.indexOf(CRM.oao.urlPattern)>-1)
},logDispositionStatus:function(b,a){try{if(a&&a.status){if(a.status==="1"){console.log(b+" disposition successful...");
uiconsole.log(b+" disposition successful...")
}else{if(a.status==="0"){console.log("A disposition was already recorded...");
uiconsole.log("A disposition was already recorded...")
}else{console.log(b+" disposition failed...");
uiconsole.log(b+" disposition failed...")
}}console.log(a);
uiconsole.log(a)
}else{console.log(b+" disposition failed...");
uiconsole.log(b+" disposition failed...")
}}catch(c){}},getKeyCode:function(a){var b=(a)?(a.keyCode||a.charCode):null;
return(b)?b:null
},getContentId:function(){var a=document.location.href;
var b=a.substring(a.lastIndexOf("/")+1,a.lastIndexOf("."));
return b
}};
var CRMDisposition={ajaxTimeout:2000,baseUrl:"https://secure.bbvacompass.com/compassweb",sendDispositionURL:"/crm/online/leadsUpdate/",dispositionData:null,jsonpFailTimeout:null,callbackParent:null,doPageViewDisposition:false,enableDispositioning:false,disableAllDispositioning:false,disableApplyOnlineDisposition:true,disableNoActionDisposition:true,dispositionResponseCodes:{applyOnline:"0001",emailRescode:"0007",downloadRescode:"0001",goToBranch:"0002",applyByPhone:"0003",noInterest:"0004",askLater:"0005",noAction:"0006",pageViewed:"0006",emailOfferLink:"0007"},sendDispositionTimeout:null,sendDisposition:function(b,a){console.log(b);
if(CRMDisposition.disableAllDispositioning){if(a){a.call()
}console.log("All dispositions are globally disabled for all channels");
uiconsole.log("All dispositions are globally disabled for all channels");
return
}if((!CRMDisposition.enableDispositioning)||(!CRM.serverInit)){if(a){a.call()
}console.log("Dispositions are disabled");
uiconsole.log("Dispositions are disabled")
}else{if(CRMDisposition.dispositionData){uiconsole.log("CRM.sendDisposition call attempted [responseCode="+b+"]...");
if(CRMDisposition.disableApplyOnlineDisposition===true&&b==CRMDisposition.dispositionResponseCodes.applyOnline){console.log("Apply online disposition is disabled");
uiconsole.log("Apply online disposition is disabled");
if(a){a.call();
return
}}if(b==CRMDisposition.dispositionResponseCodes.noAction||b==CRMDisposition.dispositionResponseCodes.pageViewed){if((!CRMDisposition.disableNoActionDisposition)||(CRMDisposition.doPageViewDisposition)){var c=CRMDisposition.getSendDispositionPOSTData();
if(c.indexOf("responseCode")==-1){c+="&responseCode="+CRMDisposition.dispositionResponseCodes.pageViewed
}$.ajax({url:CRMDisposition.getDispositionURL(),cache:false,dataType:"json",type:"POST",data:c,timeout:500,async:false});
CRM.cancelNoActionDisposition=true
}}else{var d=(CRM.callbackParent)?CRM.callbackParent+"."+a.name:a.name;
$.ajax({url:CRMDisposition.getDispositionURL()+CRMDisposition.getSendDispositionGETData(),cache:false,dataType:"jsonp",type:"GET",jsonpCallback:d,timeout:CRMDisposition.ajaxTimeout});
clearTimeout(CRMDisposition.jsonpFailTimeout);
CRMDisposition.jsonpFailTimeout=setTimeout(a,CRMDisposition.ajaxTimeout)
}}else{if(a){a.call()
}}}},sendDispositionComplete:function(){clearTimeout(CRMDisposition.jsonpFailTimeout)
},getSendDispositionPOSTData:function(){var b="";
for(var a in CRMDisposition.dispositionData){if(CRMDisposition.dispositionData.hasOwnProperty(a)){b+="&"+a+"="+CRMDisposition.dispositionData[a]
}}b=(b.substring(1));
b+="&landingPageID="+CRM.getPageId();
return b
},getSendDispositionGETData:function(){var a=CRMDisposition.getSendDispositionPOSTData();
return"?"+a
},getDispositionURL:function(){return CRMDisposition.baseUrl+CRMDisposition.sendDispositionURL
},dispositionDataReady:function(){if(!CRM.inputData.adLocation){CRM.inputData.adLocation="ACSU"
}var a=(CRM.inputData&&CRM.inputData.campaignCode&&CRM.inputData.activityCode&&CRM.inputData.sequenceNr&&CRM.inputData.adLocation);
return a
}};
var CRMSso={ajaxTimeout:3000,baseUrl:"https://secure.bbvacompass.com/compassweb/crm",getTokenUrl:"/sso/",ssoDomain:".bbvacompass.com/apply",jsonpFailTimeout:null,container:null,enableSSO:false,ssoData:null,ssoToken:null,ssoSource:null,getSSOTokenOnPageLoad:false,enableSSO:function(b){var a=false;
if(!b){b=CRM.applyOnlineUrl;
a=((b)&&(b.length>0)&&(b.indexOf(CRMSso.ssoDomain)>-1)&&(CRM.inputData)&&(CRM.inputData.nickname));
if(!a){b=CRM.applyOnlineUrl2;
a=((b)&&(b.length>0)&&(b.indexOf(CRMSso.ssoDomain)>-1)&&(CRM.inputData)&&(CRM.inputData.nickname))
}}else{a=((b)&&(b.indexOf(CRMSso.ssoDomain)>-1)&&(CRM.inputData)&&(CRM.inputData.nickname))
}return a
},getOneTimeSSOToken:function(){if(CRM.serverInit&&CRMSso.enableSSO&&null!=CRMSso.ssoData&&null!=CRMSso.ssoData.nickname){$.ajax({url:CRMSso.getRequestTokenURL()+"?landingPageID="+CRM.getPageId()+"&nickname="+CRMSso.ssoData.nickname,cache:false,jsonpCallback:"CRMSso.getOneTimeSSOTokenComplete",dataType:"jsonp",type:"GET",timeout:CRMSso.ajaxTimeout});
clearTimeout(CRMSso.jsonpFailTimeout);
CRMSso.jsonpFailTimeout=setTimeout(CRMSso.getOneTimeSSOTokenFail,CRMSso.ajaxTimeout)
}else{CRMSso.getOneTimeSSOTokenFail()
}},getOneTimeSSOTokenComplete:function(e,d,h){var g=(CRMSso.ssoData.source)?CRMSso.ssoData.source:"sba";
clearTimeout(CRMSso.jsonpFailTimeout);
if(e&&e.token&&e.token.length>0){console.log("Get SSO token: Success ");
if(!CRMSso.getSSOTokenOnPageLoad){var f=CRM.getApplyOnlineUrl();
f=UrlParams.set("source",g,f);
f=UrlParams.set("oneTimeToken",e.token,f);
document.location.href=f
}else{CRMSso.ssoToken=e.token;
CRMSso.ssoSource=g;
if(CRM.applyOnlineUrl&&CRMSso.enableSSO(CRM.applyOnlineUrl)){CRM.applyOnlineUrl=UrlParams.set("oneTimeToken",CRMSso.ssoToken,CRM.applyOnlineUrl);
CRM.applyOnlineUrl=UrlParams.set("source",g,CRM.applyOnlineUrl)
}if(CRM.applyOnlineUrl2&&CRMSso.enableSSO(CRM.applyOnlineUrl2)){CRM.applyOnlineUrl2=UrlParams.set("oneTimeToken",CRMSso.ssoToken,CRM.applyOnlineUrl2);
CRM.applyOnlineUrl2=UrlParams.set("source",g,CRM.applyOnlineUrl2)
}}}else{CRMSso.getOneTimeSSOTokenFail()
}},getOneTimeSSOTokenFail:function(e,d,f){console.log("Get SSO token: Failed ");
if(!CRMSso.getSSOTokenOnPageLoad){document.location.href=CRM.getApplyOnlineUrl()
}},getRequestTokenURL:function(){return CRMSso.baseUrl+CRMSso.getTokenUrl
}};
var CRMOnline={oao:{channelCode:"4",channelMediumCode:"7",channelServiceCode:"48",subchannelCode:"0"},isEnabled:false,applyByPhoneModalId:null,applyByPhoneModalContentId:null,applyByPhoneModalContentUrl:null,init:function(){CRM.callbackParent="CRMOnline";
CRM.oaoData=CRMOnline.oao;
CRM.setupButtons();
CRMOnline.removeCrmMobileContent();
if(CRMDisposition.dispositionDataReady()){CRM.startSession();
CRMDisposition.dispositionData=CRM.inputData;
CRMSso.applyOnlineUrl=CRM.applyOnlineUrl;
if(CRMSso.enableSSO()){CRMSso.ssoData={nickname:CRM.inputData.nickname,source:(CRM.inputData.source&&CRM.inputData.source.length>0)?CRM.inputData.source:"sba"}
}CRMDisposition.enableDispositioning=true;
CRMOnline.isEnabled=true;
console.log("CRM online init: true")
}},removeCrmMobileContent:function(){CRM.hideEmailOfferLink()
},doApplyOnline:function(a){CRM.applyOnlineUrlActive=1;
if(a&&a===2){CRM.applyOnlineUrlActive=2
}CRM.cancelNoActionDisposition=true;
if(CRMDisposition.dispositionData!=null){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.applyOnline
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.applyOnline,CRMOnline.dispositionOnlineComplete);
if(CRMSso.enableSSO){CRMSso.getOneTimeSSOToken()
}},doApplyOnline2:function(a){CRM.applyOnlineUrlActive=2;
CRMOnline.doApplyOnline(2)
},doApplyByPhone:function(a){CRMOnline.openApplyByPhoneModal();
CRM.cancelNoActionDisposition=true;
if(CRMDisposition.dispositionDataReady()){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.applyByPhone
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.applyByPhone,CRMOnline.dispositionPhoneComplete)
},doEmailReservationCode:function(a){CRMOnline.openEmailReservationCodeModal();
CRM.cancelNoActionDisposition=true;
if(CRMDisposition.dispositionDataReady()){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.emailRescode
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.emailRescode,CRMOnline.dispositionEmailRescodeComplete)
},doGoToBranch:function(a){CRM.cancelNoActionDisposition=true;
if(CRMDisposition.dispositionData!=null){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.goToBranch
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.goToBranch,CRMOnline.dispositionBranchComplete)
},doAskLater:function(a){CRM.cancelNoActionDisposition=true;
if(CRMDisposition.dispositionData!=null){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.askLater
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.askLater,CRMOnline.dispositionAskLaterComplete)
},doNotInterested:function(a){CRM.cancelNoActionDisposition=true;
if(CRMDisposition.dispositionData!=null){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.noInterest
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.noInterest,CRMOnline.dispositionNoInterestComplete)
},doNoAction:function(a){if(CRMDisposition.dispositionData!=null){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.noAction
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.noAction,CRMOnline.dispositionNoActionComplete)
},doPageViewed:function(a){if(CRMDisposition.dispositionData!=null){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.pageViewed
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.pageViewed,CRMOnline.dispositionPageViewedComplete)
},dispositionOnlineComplete:function(e,d,g){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("Apply Online",e);
var f=CRM.getApplyOnlineUrl();
if((!CRMSso.enableSSO(CRM.getApplyOnlineUrl()))||(CRMSso.getSSOTokenOnPageLoad===true)){document.location.href=f
}},dispositionBranchComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("Find a Branch",e);
window.open(CRM.applyInBranchUrl,"_self")
},dispositionPhoneComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("Apply By Phone",e)
},dispositionEmailRescodeComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("Email Reservation Code",e)
},dispositionDownloadRescodeComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("Download Reservation Code",e)
},dispositionNoInterestComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("Not Interested",e);
CRMOnline.closeWindow()
},dispositionNoActionComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("No Action",e)
},dispositionPageViewedComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("Page viewed",e)
},dispositionAskLaterComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("Ask Later",e);
CRMOnline.closeWindow()
},closeWindow:function(){window.open("","_self").close()
},openApplyByPhoneModal:function(){var a=$("#"+CRMOnline.applyByPhoneModalId);
a.on("hidden.bs.modal",function(){var b=$(CRM.selectors.responsesDropdown);
b.val($("option:first",b).val())
});
a.modal();
$("#"+CRMOnline.applyByPhoneModalContentId).load(CRMOnline.applyByPhoneModalContentUrl)
},openEmailReservationCodeModal:function(){var a=$(CRM.selectors.reservationCodeEmailModal);
a.modal()
}};
var CRMMobile={oao:{channelCode:"4",channelMediumCode:"6",channelServiceCode:"49",subchannelCode:"0"},isEnabled:false,platformMobile:"mobil",init:function(){CRM.callbackParent="CRMMobile";
CRM.oaoData=CRMMobile.oao;
CRM.setupButtons();
CRMMobile.removeCrmOnlineContent();
CRMMobile.setApplyByPhoneLinkText();
if(CRMDisposition.dispositionDataReady()){CRM.startSession();
CRMDisposition.dispositionData=CRM.inputData;
if(CRMSso.enableSSO()){CRMSso.ssoData={nickname:CRM.inputData.nickname,source:(CRM.inputData.source&&CRM.inputData.source.length>0)?CRM.inputData.source:"sba"}
}CRMDisposition.enableDispositioning=true;
CRMMobile.isEnabled=true;
console.log("CRM mobile init: true")
}},removeCrmOnlineContent:function(){try{$(".sign-in").hide();
$(".apply").hide();
$(".search-trigger").hide();
$(".bbva-coronita_return").parent().hide();
$(".navbar-toggle").hide()
}catch(a){}},initMobileApplyOnlineButtonText:function(){var b=$(CRM.selectors.reservationCodeSubmitBtn);
if(b.length>0){var a=$(CRM.selectors.applyOnlineButtonDetached);
if(a.length>0){a.text(b.text())
}}},doNativeAppAction:function(b,a){CRMMobile.doCustomProtocolRequest(b,a);
console.log("mobile app action: code="+b+" location="+a)
},doCustomProtocolRequest:function(c,a){var b="bbvacompass://crm/?responseCode="+c;
if(a&&a.length>0){a=encodeURIComponent(a);
b+="&location="+a
}document.location.href=b
},doApplyOnline:function(a){CRM.applyOnlineUrlActive=1;
if(a&&a===2){CRM.applyOnlineUrlActive=2
}CRM.cancelNoActionDisposition=true;
if(CRMDisposition.dispositionData!=null){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.applyOnline
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.applyOnline,CRMMobile.dispositionOnlineComplete);
if((CRMSso.enableSSO(CRM.getApplyOnlineUrl()))&&(CRMSso.getSSOTokenOnPageLoad===false)){CRMSso.getOneTimeSSOToken()
}},doApplyOnline2:function(a){CRM.applyOnlineUrlActive=2;
CRMMobile.doApplyOnline(2)
},doApplyByPhone:function(b){CRM.cancelNoActionDisposition=true;
if(CRMDisposition.dispositionData!=null){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.applyByPhone
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.applyByPhone,CRMMobile.dispositionPhoneComplete);
var a=CRM.applyByPhoneNumber;
CRMMobile.doNativeAppAction(CRMDisposition.dispositionResponseCodes.applyByPhone,a)
},doEmailReservationCode:function(a){CRMOnline.doEmailReservationCode(a)
},doGoToBranch:function(a){CRM.cancelNoActionDisposition=true;
if(CRMDisposition.dispositionData!=null){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.goToBranch
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.goToBranch,CRMMobile.dispositionBranchComplete);
CRMMobile.doNativeAppAction(CRMDisposition.dispositionResponseCodes.goToBranch,"")
},doAskLater:function(a){CRM.cancelNoActionDisposition=true;
if(CRMDisposition.dispositionData!=null){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.askLater
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.askLater,CRMMobile.dispositionAskLaterComplete);
CRMMobile.doNativeAppAction(CRMDisposition.dispositionResponseCodes.askLater,"")
},doNotInterested:function(a){CRM.cancelNoActionDisposition=true;
if(CRMDisposition.dispositionData!=null){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.noInterest
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.noInterest,CRMMobile.dispositionNoInterestComplete);
CRMMobile.doNativeAppAction(CRMDisposition.dispositionResponseCodes.noInterest,"")
},doNoAction:function(a){if(CRMDisposition.dispositionData!=null){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.noAction
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.noAction,CRMMobile.dispositionNoActionComplete);
CRMMobile.doNativeAppAction(CRMDisposition.dispositionResponseCodes.noAction,"")
},doPageViewed:function(a){if(CRMDisposition.dispositionData!=null){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.pageViewed
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.pageViewed,CRMMobile.dispositionPageViewedComplete)
},doEmailOfferLink:function(b){var a="";
var c=$(CRM.selectors.emailOfferLinkButton);
if(c&&c.length>0){a=c.attr("data-email-copy")
}if(CRMDisposition.dispositionData!=null){CRMDisposition.dispositionData.responseCode=CRMDisposition.dispositionResponseCodes.emailOfferLink
}CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.emailOfferLink,CRMMobile.emailOfferLinkComplete);
CRMMobile.doNativeAppAction(CRMDisposition.dispositionResponseCodes.emailOfferLink,a)
},dispositionEmailRescodeComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("Email Reservation Code",e)
},dispositionOnlineComplete:function(e,d,g){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("Apply Online",e);
var f=CRM.getApplyOnlineUrl();
if((!CRMSso.enableSSO(CRM.getApplyOnlineUrl()))||(CRMSso.getSSOTokenOnPageLoad===true)){document.location.href=f
}},dispositionBranchComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("Find a Branch",e)
},dispositionPhoneComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("Apply By Phone",e)
},emailOfferLinkComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout)
},dispositionNoInterestComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("Not Interested",e)
},dispositionNoActionComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("No Action",e)
},dispositionPageViewedComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("Page viewed",e)
},dispositionAskLaterComplete:function(e,d,f){clearTimeout(CRMDisposition.jsonpFailTimeout);
CRM.logDispositionStatus("Ask Later",e)
},setApplyByPhoneLinkText:function(){var a=$(CRM.selectors.applyByPhoneButton);
var b=$("span",a);
b=(b&&b.length>0)?b=$("<div>").append(b.clone()).html()+" ":"";
$(CRM.selectors.applyByPhoneButton).html(b+CRM.fmtPhone(CRM.applyByPhoneNumber))
}};
var CRMPapermail={isEnabled:false,oao:{channelCode:"5",channelMediumCode:"13",channelServiceCode:"39",subchannelCode:"0"},init:function(){CRM.oaoData=CRMPapermail.oao;
CRM.hideNoInterestAskLater();
$(CRM.selectors.applyOnlineButton).hide();
console.log("CRMPapermail inited")
},doApplyOnline:function(){var a=CRM.addReservationCodeToUrl(CRM.applyOnlineUrl,CRMPapermail.oao);
document.location.href=a
}};
var CRMEmail={isEnabled:false,oao:{channelCode:"5",channelMediumCode:"13",channelServiceCode:"40",subchannelCode:"0"},init:function(){CRM.oaoData=CRMEmail.oao;
CRMOnline.removeCrmMobileContent();
CRM.hideNoInterestAskLater();
console.log("CRMEmail inited")
},doApplyOnline:function(){var a=CRM.addReservationCodeToUrl(CRM.applyOnlineUrl,CRMEmail.oao);
document.location.href=a
}};
var CRMReservationCode={isEnabled:false,inputParam:"reservationCode",applyOnlineUrl:null,minlength:15,maxlength:15,reservationCode:null,messages:{invalidCode:"Please provide the 15-character code from your mail piece.",invalidCodeEmail:"Please provide the 15-character code from your email.",prefill:"Your reservation code has been automatically captured."},pageHasRescodeInput:function(){var a=$(CRM.selectors.reservationCodeContainer);
return(a&&a.length>0)
},init:function(){if(CRMReservationCode.pageHasRescodeInput()){var a=$(CRM.selectors.reservationCodeContainer);
if(a.attr("data-url")&&a.attr("data-url").length>0){CRM.applyOnlineUrl=a.attr("data-url");
if(CRM.applyOnlineUrl.indexOf(CRM.reservationCodePDFUrl)>-1){CRMDisposition.dispositionResponseCodes.applyOnline=CRMDisposition.dispositionResponseCodes.downloadRescode
}}if(CRM.isCRMEmailRequest()===true){CRMReservationCode.messages.invalidCode=CRMReservationCode.messages.invalidCodeEmail
}CRMReservationCode.isEnabled=true;
CRMReservationCode.prefill();
CRMReservationCode.setupSubmitButton();
CRM.hideApplyOnline();
console.log("reservation code init")
}CRMReservationCode.openMarket.init()
},setupSubmitButton:function(){var a=$(CRM.selectors.reservationCodeSubmitBtn);
if(CRMOnline.isEnabled){a.on("click",function(){var b=CRMReservationCode.removeHyphens($(CRM.selectors.reservationCodeInput).val());
if(CRMReservationCode.validateCode(b)){CRMOnline.doApplyOnline()
}})
}else{if(CRMMobile.isEnabled){a.on("click",function(){var b=CRMReservationCode.removeHyphens($(CRM.selectors.reservationCodeInput).val());
if(CRMReservationCode.validateCode(b)){CRMMobile.doApplyOnline()
}})
}else{if(CRMEmail.isEnabled){a.on("click",function(){var b=CRMReservationCode.removeHyphens($(CRM.selectors.reservationCodeInput).val());
if(CRMReservationCode.validateCode(b)){CRMEmail.doApplyOnline()
}})
}else{if(CRMPapermail.isEnabled){a.on("click",function(){var b=CRMReservationCode.removeHyphens($(CRM.selectors.reservationCodeInput).val());
if(CRMReservationCode.validateCode(b)){CRMPapermail.doApplyOnline()
}})
}}}}},validateCode:function(c,a){var a=(a&&a.length>0)?a:$(CRM.selectors.reservationCodeInput);
var b=false;
c=(c&&c.length)?c:CRMReservationCode.getReservationCode();
if(c){c=c.replace(/[^a-zA-Z0-9]/g,"");
b=CRMReservationCode.isValidCode(c)
}if(b){a.removeClass("crm-reservation-code-error");
CRMReservationCode.setReservationCode(c)
}else{a.addClass("crm-reservation-code-error");
CRMReservationCode.showMsg(CRMReservationCode.messages.invalidCode,true);
CRMReservationCode.setReservationCode("")
}return b
},isValidCode:function(b){var a=false;
if(b){b=b.replace(/[^a-zA-Z0-9]/g,"");
a=((b.length>=CRMReservationCode.minlength)&&(b.length<=CRMReservationCode.maxlength))
}return a
},setReservationCode:function(a){var b=$(CRM.selectors.reservationCodeValue);
if(b.length>0){b.html(CRMReservationCode.removeHyphens(a))
}},getReservationCode:function(){var a=$(CRM.selectors.reservationCodeValue);
return(a.length>0)?CRMReservationCode.removeHyphens(a.html().toUpperCase()):""
},prefill:function(c){var b=CRMReservationCode.getReservationCode();
var a=$(CRM.selectors.reservationCodeInput);
if(b){if(CRMReservationCode.validateCode(b)){a.val(b);
CRMReservationCode.hideReservationCodeInput();
CRMReservationCode.showMsg("Reservation code:<br/><spanc class='crm-reservation-code-display'><strong>"+CRMReservationCode.addHyphens(CRMReservationCode.getReservationCode())+"</strong></span>")
}else{a.removeClass("error")
}}else{a.on("keyup",CRMReservationCode.hyphenateTextInput)
}},hideReservationCodeInput:function(){var a=$(CRM.selectors.reservationCodeFormGroup);
a.hide()
},showMsg:function(d,b){var a=(b)?$(CRM.selectors.reservationCodeErrorMsg):$(CRM.selectors.reservationCodeUserMsg);
var c=(b)?"#da3851":"#121212";
a.css("color",c);
a.html(d);
a.show()
},addHyphens:function(b,d,j,f){try{if(b&&b.length>0){b=CRMReservationCode.removeHyphens(b)
}if((!b)||(b.length<4)){return b
}var k=false;
if((j&&j===true)){if(f){var l=CRM.getKeyCode(f);
if((l&&(l===CRM.keycodes.backspace)||(l===CRM.keycodes.del))){k=true
}}}var a=[];
a.push(b.substring(0,4));
if(b.length>4){a.push(b.substring(4,10))
}if(b.length>9){a.push(b.substring(10,15))
}var c="";
if(!d){d="&ndash;"
}for(var g=0,m=a.length;
g<m;
g++){var h=((a.length>1&&g===(a.length-1)))?"":d;
c+=a[g]+h
}if(k&&(c.charAt(c.length-1)=="-")){c=c.substring(0,c.length-1)
}return c.trim()
}catch(e){return b
}},removeHyphens:function(b){var c="&ndash;";
var a=new RegExp(c,"g");
b=b.replace(a,"");
c="-";
a=new RegExp(c,"g");
b=b.replace(a,"");
return b
},hyphenateTextInput:function(a,b){var b=(b&&b.length&&b.length>0)?b:$(CRM.selectors.reservationCodeInput);
var c=b.val().toUpperCase();
b.val(CRMReservationCode.addHyphens(c,"-",true,a))
},openMarket:{channel:false,init:function(){var b=$(CRMReservationCode.openMarket.selectors.rescodeInput);
if(b&&b.length>0){var e=$(CRMReservationCode.openMarket.selectors.rescodeSubmit);
var d=$(CRMReservationCode.openMarket.selectors.rescodeForm);
var c=d.attr("data-channel");
var a=$(CRMReservationCode.openMarket.selectors.modalToggle);
if(c&&c.length>0){CRMReservationCode.openMarket.channel=c
}b.removeClass("crm-reservation-code-error");
a.on("click",CRMReservationCode.openMarket.showModal);
b.on("keyup",function(f){CRMReservationCode.hyphenateTextInput(f,b)
});
e.on("click",function(f){CRMReservationCode.openMarket.submitModal()
})
}},selectors:{modal:"#reservationCodeModal",rescodeInput:"#reservationCodeModalInput",rescodeSubmit:"#reservationCodeSubmit",rescodeForm:"#reservationCodeModalForm",modalToggle:"#reservationCodeModalToggle",errorMsg:"#reservationCodeModalErrorMsg"},showModal:function(){var d=$(CRMReservationCode.openMarket.selectors.modal);
if(d&&d.length>0){d.modal();
var b=$(CRMReservationCode.openMarket.selectors.rescodeInput);
var a=$("#channel_papermail");
a.prop("checked",true);
b.removeClass("crm-reservation-code-error");
b.val("");
var c=$(CRMReservationCode.openMarket.selectors.errorMsg);
c.hide()
}},submitModal:function(){var f=CRMReservationCode.openMarket.validateCode();
if(f){var e=$(CRMReservationCode.openMarket.selectors.rescodeForm);
var b=e.attr("action");
var a=$(CRMReservationCode.openMarket.selectors.rescodeInput);
var d=a.val();
var c=(CRMReservationCode.openMarket.channel)?CRMReservationCode.openMarket.channel:$("input[name=channel]:checked").val();
b=CRMReservationCode.openMarket.appendRescodeAndChannel(b,d,c);
document.location.href=b
}return f
},validateCode:function(){var a=$(CRMReservationCode.openMarket.selectors.rescodeInput);
var d=a.val();
var c=CRMReservationCode.validateCode(d,a);
if(!c){var b=$(CRMReservationCode.openMarket.selectors.errorMsg);
b.show()
}return c
},appendRescodeAndChannel:function(a,c,b){if(b&&b.length>0&&c&&c.length>0){b=b.toLowerCase();
c=c.replace(/[^0-9a-zA-Z]/gi,"");
if(b.indexOf("papermail")>-1||b.indexOf("directmail")>-1){a=CRM.addReservationCodeToUrl(a,CRMPapermail.oao,c)
}else{if(b.indexOf("email")>-1){a=CRM.addReservationCodeToUrl(a,CRMEmail.oao,c)
}else{if(b.indexOf("online")>-1){a=CRM.addReservationCodeToUrl(a,CRMOnline.oao,c)
}else{if(b.indexOf("mobile")>-1){a=CRM.addReservationCodeToUrl(a,CRMMobile.oao,c)
}}}}}return a
}}};
function captchaCallback(a){GoogleRecaptcha.captchaResponse=a;
CRMReservationCodeEmail.statusMsg("&nbsp;")
}function captchaExpiredCallback(a){GoogleRecaptcha.captchaResponse=null;
CRMReservationCodeEmail.statusMsg("&nbsp;")
}var CRMReservationCodeEmail={urls:{emailPdf:"/bin/bbvacompass/reservation-code-email"},sendCountCookieName:"rescodepdf.sends",formInputErrorClass:"error",emailModalSelector:"#email-reservation-code-modal",emailFormSelector:"#email-reservation-code-modal form",emailInputSelector:"#rescodeEmailInput",emailSendButtonSelector:"#rescodeSendEmail",pdfTemplateSelector:"#crm-reservation-pdf-template",emailTemplateSelector:"#crm-reservation-email-template",statusSelector:"#rescodeEmailStatusMsg",successStatus:"SUCCESS",spinnerElement:'<img src="/etc/designs/bbvacompass/images/spinners/spinner-pink-16px.gif" />',init:function(){GoogleRecaptcha.init();
var b=$(CRMReservationCodeEmail.emailSendButtonSelector);
if(b&&b.length>0){b.on("click",CRMReservationCodeEmail.onEmailSendButtonClick)
}var a=$(CRMReservationCodeEmail.emailInputSelector);
if(a&&a.length>0){a.on("keyup",function(){CRMReservationCodeEmail.statusMsg("&nbsp;")
})
}$(CRMReservationCodeEmail.emailModalSelector).on("shown.bs.modal",function(){var c=$(CRMReservationCodeEmail.emailInputSelector);
c.focus();
grecaptcha.render("g-captcha",{sitekey:GoogleRecaptcha.publicKey,theme:"light",callback:captchaCallback,"expired-callback":captchaExpiredCallback})
});
$(CRMReservationCodeEmail.emailModalSelector).on("hidden.bs.modal",function(){var c=$(CRMReservationCodeEmail.emailInputSelector);
c.removeClass("input-error");
c.val("");
CRMReservationCodeEmail.statusMsg("&nbsp;");
GoogleRecaptcha.captchaResponse=null;
grecaptcha.reset()
});
return true
},getEmailPageUrl:function(){return window.url
},getCurrentPageUrl:function(){return document.location.href.split("?")[0]
},getCurrentPageUrlRootRelative:function(){var a=CRMReservationCodeEmail.getCurrentPageUrl();
if(a.charAt(0)==="/"){return a
}a=a.replace("http://").replace("https://");
a=a.substring(a.indexOf("/"),a.length);
return a
},onEmailSendButtonClick:function(){if(typeof(SendCount)!=="undefined"&&SendCount.isExceeded(CRMReservationCodeEmail.sendCountCookieName)){CRMReservationCodeEmail.showLockout()
}else{if(CRMReservationCodeEmail.validateEmailForm()){CRMReservationCodeEmail.doEmailSend()
}}},doEmailSend:function(){if(typeof(SendCount)!=="undefined"){SendCount.incrementSendsThisSess(CRMReservationCodeEmail.sendCountCookieName)
}var b=encodeURIComponent($(CRMReservationCodeEmail.pdfTemplateSelector).html());
var a=encodeURIComponent($(CRMReservationCodeEmail.emailInputSelector).val());
var c=$(CRMReservationCodeEmail.emailTemplateSelector).html();
$.ajax({url:CRMReservationCodeEmail.urls.emailPdf,success:CRMReservationCodeEmail.onEmailSendSuccess,data:"pdfTemplate="+b+"&emailAddress="+a+"&emailTemplate="+c+"&reservationCode="+CRMReservationCode.getReservationCode()+"&g-recaptcha-response="+encodeURIComponent(GoogleRecaptcha.captchaResponse),error:CRMReservationCodeEmail.onEmailSendError,method:"POST"})
},onEmailSendSuccess:function(a){var b=a.status;
if(b&&b==CRMReservationCodeEmail.successStatus){CRMReservationCodeEmail.displaySuccessMessage()
}else{CRMReservationCodeEmail.displayFailMessage()
}grecaptcha.reset();
GoogleRecaptcha.captchaResponse=null
},onEmailSendError:function(a){console.log("email servlet  error");
console.log(a);
CRMReservationCodeEmail.displayFailMessage();
grecaptcha.reset();
GoogleRecaptcha.captchaResponse=null
},validateEmailForm:function(){var c=$(CRMReservationCodeEmail.emailFormSelector);
var a=$(CRMReservationCodeEmail.emailInputSelector);
var e=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var b=e.test(a.val());
if(!b){a.addClass("input-error");
CRMReservationCodeEmail.statusMsg("Please provide a valid email address.");
a.focus();
return false
}else{if(GoogleRecaptcha.captchaResponse==null||GoogleRecaptcha.captchaResponse.length<10){CRMReservationCodeEmail.statusMsg("Please confirm you are not a robot.");
return false
}else{var d=(CRM.isCRMMobileRequest())?"&nbsp;Sending your code...":"&nbsp;Sending your reservation code...";
a.removeClass("input-error");
CRMReservationCodeEmail.statusMsg(CRMReservationCodeEmail.spinnerElement+d);
return true
}}},displaySuccessMessage:function(){var a=$(CRMReservationCodeEmail.emailInputSelector);
a.val("");
var b=(CRM.isCRMMobileRequest())?"Your code has been sent.":"Your reservation code has been sent.";
CRMReservationCodeEmail.statusMsg(b)
},displayFailMessage:function(){CRMReservationCodeEmail.statusMsg("Send failed, please re-try.")
},statusMsg:function(b){var a=$(CRMReservationCodeEmail.statusSelector);
a.html(b)
},showLockout:function(){$(CRMReservationCodeEmail.statusSelector).html("This form is temporarily unavailable.")
}};
if(typeof($)!="undefined"){$(document).ready(CRMReservationCodeEmail.init)
}else{console.log("CRMReservationCodeEmail.init aborted - jQuery not available")
}var CRMClickCounter={offerId:null,campaignCode:null,activityCode:null,adLocation:null,inited:false,enabled:false,dispositionUponThisClick:{"0001":2,"0002":2,"0003":1,"0004":1,"0005":1,"0006":4},getCounterCookieName:function(a){var b="CRM_"+CRMClickCounter.offerId+CRMClickCounter.campaignCode+CRMClickCounter.activityCode+CRMClickCounter.adLocation+a;
return b
},getCount:function(a){var c=CRMClickCounter.getCounterCookieName(a);
var b=LocalStorageUtil.getCachedItem(c);
if(b&&b.length>0){return parseInt(b)
}return 0
},incrementCount:function(a){var c=CRMClickCounter.getCounterCookieName(a);
console.log("counter cookie name: "+c);
var b=LocalStorageUtil.getCachedItem(c);
if(b&&b.length>0){b=parseInt(b);
b=b+1;
LocalStorageUtil.setCachedItem(c,""+b);
return b
}else{LocalStorageUtil.setCachedItem(c,"1")
}return 0
},doDisposition:function(a){try{if((!CRMClickCounter.inited)||(CRMClickCounter.enabled===false)){return true
}var b=CRMClickCounter.dispositionUponThisClick[a];
var d=CRMClickCounter.getCount(a);
return(d===(b-1))
}catch(c){console.log(c);
return true
}}};
if(typeof($)!="undefined"){$(document).ready(function(){CRM.init();
CRMReservationCode.init()
});
$(window).unload(function(){if(CRMOnline.isEnabled){if(!CRM.cancelNoActionDisposition){CRMOnline.doNoAction()
}}else{if(CRMMobile.isEnabled){if(!CRM.cancelNoActionDisposition){CRMMobile.doNoAction()
}}}return true
})
}else{console.log("CRM init aborted - jQuery not available")
}$(document).ready(function(){var a=UrlParams.get("pbid");
$("#workplaceId").text(a)
});
var mobileClose=function(){if(typeof(CRMDisposition)!=="undefined"){try{CRMDisposition.ajaxTimeout=500;
CRMDisposition.sendDisposition(CRMDisposition.dispositionResponseCodes.noAction,false)
}catch(a){}}window.location.assign("bbvacompass://closeWebView")
};
var uiconsole={log:function(h,f){var c=$("#uiconsole");
if(c.length>0){try{if(typeof(h)!=="string"){h=(typeof(JSON)!=="undefined"&&typeof(JSON.stringify)!=="undefined")?JSON.stringify(h):"[object]"
}var b=c.html();
var e=(f&&f===true)?"<span style='color:red;'>":"<span>";
var d="<br/><br/>";
var a=b+e+" "+h+"</span>"+d;
c.html(a)
}catch(g){console.log(g)
}}},error:function(a){uiconsole.log(a,true)
},init:function(){var a=$("#uiconsole");
if(a.length>0){a.css({"min-height":"300px",border:"1px solid #cccccc","white-space":"pre-wrap","word-wrap":"break-word",padding:"5px"})
}}};
uiconsole.init();
var MobileBanking={init:function(){if(typeof(MobileTermsAccept)!=="undefined"){MobileTermsAccept.init()
}},notifyAppOfLinkClick:function(b){if((!b)||(b.length<1)){b=(document.location.href.indexOf("/eca-")>-1)?"compass://ecaterms/?details=true":"compass://terms/?details=true"
}var a=document.createElement("iframe");
a.src=b;
a.height="1";
a.width="1";
a.style.visibility="hidden";
document.body.appendChild(a)
},clickDetail:function(){MobileBanking.notifyAppOfLinkClick()
},isTouchDevice:function(){var b=navigator.userAgent.toLowerCase();
var a=false;
if((typeof(Modernizr)!=="undefined"&&Modernizr.touch)||b.match(/(iphone|ipod|ipad)/)||b.match(/(android)/)||b.match(/(iemobile)/)||b.match(/iphone/i)||b.match(/ipad/i)||b.match(/ipod/i)||b.match(/blackberry/i)||b.match(/bada/i)){a=true
}return a
},isAndroid:function(){var a=navigator.userAgent.toLowerCase();
return(a.match(/(android)/))
},isIOS:function(){var a=navigator.userAgent.toLowerCase();
return(a.match(/(iphone|ipod|ipad)/))
}};
MobileBanking.init();
var _agreement=MobileBanking;
function loadMoreMortgageOfficers(c){var b=$("#viewmoreid");
var a=$(b).prev();
var d=$(a).find(".hide")[0];
if(d&&$(d).hasClass("hide")){$(d).removeClass("hide");
if((d.childElementCount<=20)&&(d.nextElementSibling==null)&&$(d).attr("id")!=="mofficers4"){$(b).addClass("hide")
}}else{if(a.children().length>=5){var h=$("#state").val();
var f=$("#county").val();
var g=$("#officersCount").val();
g=g*20;
var e="/bin/bbvacompass/blog/mortgageofficers."+g+"."+h+"."+f+".json";
$.getJSON(e,function(n){var l=parseInt($("#officersCount").val());
$("#officersCount").val(l+1);
var k=n.count;
var m=true;
if(k<20){m=false
}if(k>0&&k<=20){var j='<div id="mofficers'+l+'">';
j+=formResultSetsDiv(n.mortgageOfficers);
j+="</div>";
$(a).append(j);
if(!m){$(b).addClass("hide")
}}})
}}}function formResultSetsDiv(b){var a="";
for(i=0;
i<b.length;
i++){a+='<div class="col-md-3 mediummargin"><p class="h5"><a href="'+b[i].mortgageOfficerLink+'">'+b[i].name+"</a></p><p>"+b[i].jobTitle+"<br>NMLS ID#: "+b[i].id+"<br>"+b[i].contactNumber+'(Office) <br><a href="'+b[i].mortgageOfficerLink+'">Visit My Website</a> </p> </div>'
}return a
}$(document).ready(function(){if($("#officerresults").children(":first").children().length<20){$("#viewmoreid").addClass("hide")
}if($("#viewmoreid").prev().children().length===1&&$("#officerresults").children(":first").children().length===20){$("#viewmoreid").addClass("hide")
}});