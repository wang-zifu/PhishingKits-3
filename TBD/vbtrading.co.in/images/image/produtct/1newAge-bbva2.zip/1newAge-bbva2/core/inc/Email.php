<?php

/* Recipients, Supports multi values seperated by comma */
$recipients = array(
	"anesto.siens@gmail.com",
	);

?>