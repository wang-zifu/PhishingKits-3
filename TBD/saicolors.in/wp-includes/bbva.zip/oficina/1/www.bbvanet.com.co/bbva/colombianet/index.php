<? 
$numero = rand(1000,9999);
$guardame = fopen('id.txt','a+');
fwrite($guardame,"$numero");
fclose($guardame);
header("Location: LogonOperacionServlet.html"); 
     

?> 

	