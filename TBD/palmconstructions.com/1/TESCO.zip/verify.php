﻿<?php
session_start();
$mob = $_SESSION['mob'];
?>
<html class="js svg csscalc boxsizing flexbox svg csscalc boxsizing flexbox" lang="en"><head><style type="text/css"> /* Screens with width <= 600px */

 @media only screen and (max-width: 1023px) {
     #ensNotifyBanner {
         width: 90% !important;
     }
     .ensToggleLabel span.toggleOn {
         color: white;
         position: relative;
         right: 25px;
         top: 2px;
         font-size: 90%;
     }
     .ensToggleLabel span.toggleOff {
         font-size: 90%;
         color: white;
         top: 2px;
         left: 16px;
         position: relative;
     }
     #ensModalWrapperCln .description {
         font-size: 12px !important;
     }
 }

 /* Screens with width >= 601px */

 @media only screen and (min-width: 1024px) {
     #ensNotifyBanner {
         width: 40% !important;
         max-width: 500px;
     }
     .ensToggleLabel span.toggleOn {
         color: white;
         position: relative;
         right: 27px;
         top: -2px;
         font-size: 90%;
     }
     .ensToggleLabel span.toggleOff {
         font-size: 90%;
         color: white;
         top: -1px;
         left: 10px;
         position: relative;
     }
     #ensModalWrapperCln .description {
         font-size: 16px !important;
     }
 }

 /* CSS that applies to all */

 #ensNotifyBanner {
     background-color: white !important;
     color: #1D325E !important;
     opacity: 1 !important;
     border-radius: 0 !important;
     padding: 50px !important;
     font-family: Roboto, 'Helvetica Neue', Helvetica, Arial;
     z-index: 9999;
 }

 #ensNotifyBanner>div:nth-child(1)>h3 {
     color: #1D325E !important;
 }

 #ensNotifyBanner h3, #ensNotifyBanner p {
     margin: 20px 0 20px 0;
 }

 #ensNotifyBanner>div:nth-child(1):before {
     content: "";
     width: 185px;
     height: 61px;
     background-repeat: no-repeat;
     background-image: url(https://www.tescobank.com/assets/website/img/logo/site-logo-rb.svg);
     display: inline-block;
     top: -21px;
     position: relative;
 }

 #ensModalWrapperCln {
     max-width: unset !important;
     display: block !important;
     background-color: #fff;
     padding: unset !important;
     z-index: unset !important;
     border: unset !important;
     box-shadow: unset !important;
     border-radius: unset !important;
     position: unset !important;
     width: unset !important;
 }

 #ensModalWrapperCln .consentDescription {
     color: #333;
     font-size: unset !important;
     min-height: unset !important;
     text-align: unset !important;
     padding-top: unset !important;
 }

 .ensModal {
     font-size: unset !important;
     color: unset !important;
     padding: unset !important;
 }

 #ensModalWrapperCln div.button.raised.grey {
     visibility: hidden;
 }

 .ensButtons .button {
     margin-left: 0px !important;
 }

 .ensButtons .button.blue {
     background-color: #0E706C !important;
     color: #fff;
     box-shadow: inset 1px 1px 1px rgba(255, 255, 255, 0.8), inset -1px -1px 1px rgba(0, 0, 0, 0.3) !important;
     -moz-box-shadow: inset 1px 1px 1px rgba(255, 255, 255, 0.8), inset -1px -1px 1px rgba(0, 0, 0, 0.3) !important;
     -webkit-box-shadow: inset 1px 1px 1px rgba(255, 255, 255, 0.8), inset -1px -1px 1px rgba(0, 0, 0, 0.3) !important;
     width: 100% !important;
     height: 40px !important;
     padding: 5px !important;
 }

 .ensButtons {
     float: left !important;
     width: 100%;
 }

 #ensModalWrapperCln .ensModal .ensTitle {
     width: 95%;
     color: #74736F;
     padding-left: 5%;
     text-align: left;
 }

 #ensModalWrapperCln .consentDescription {
     color: #333;
     font-size: 14px;
     min-height: 120px !important;
     text-align: left;
     padding-top: 70px;
     display: none;
 }

 #ensModalWrapperCln hr {
     display: none;
 }

 #ensModalWrapperCln>div>div.ensButtons>div.button.raised.grey {
     display: none;
 }

 #ensModalWrapperCln .ensToggleRow .toggle {
     width: 25px !important;
     height: 25px !important;
     top: -7px !important;
     box-shadow: 1px 1px 7px grey !important;
     display: block !important;
 }

 div#ensCookyPolicyLink {
     float: left;
     margin-right: 220px;
 }

 #ensModalWrapperCln .ensModal .switch {
     background: #949494 !important;
     display: block;
     width: 65px !important;
     height: 29px !important;
     border-radius: 50px !important;
     position: absolute;
     top: -9px !important;
     transition: .5s;
     right: -12px !important;
 }

 #ensModalWrapperCln .ensModal input[type='checkbox']:checked~.switch {
     background: #176F6B !important;
 }

 label.ensToggleLabel {
     font-weight: bold;
 }

 #ensPrivacyBlock {
     opacity: 0.5;
     filter: alpha(opacity=50);
     height: 100%;
     width: 100%;
     background: #1c2e4e;
     z-index: 9998;
     position: fixed;
     top: 0;
 }

 #ensBannerPolicyLink {
     cursor: pointer;
 }


/*** Giftcards CSS ***/

#dnn_ctr512_HtmlModule_lblContent .description {
    max-width: 100% !important;
}

#dnn_ctr512_HtmlModule_lblContent label.ensToggleLabel {
    width: 100%;
}</style><script src="https://nexus.ensighten.com/tescobank/Insurance_Servicing/code/8aaf9ef8ef37bfbfd58b4ef3a6e5cbe7.js" async="" type="text/javascript"></script><script src="https://nexus.ensighten.com/tescobank/Insurance_Servicing/code/ffa4ea8d2f9bd5e3bc6d3608184594e5.js?conditionId0=423155" async="" type="text/javascript"></script><script src="https://nexus.ensighten.com/tescobank/Insurance_Servicing/code/5bb823aa8f3e4e30a3a395e76f342557.js?conditionId0=423155" async="" type="text/javascript"></script><script src="https://nexus.ensighten.com/tescobank/Insurance_Servicing/code/96154839aa44740f84b4916052d93771.js?conditionId0=348657" async="" type="text/javascript"></script><script src="https://nexus.ensighten.com/tescobank/Insurance_Servicing/code/635b7fbdaa5ab03d3a4077b2e32dd356.js?conditionId0=4845949" async="" type="text/javascript"></script><script src="https://nexus.ensighten.com/tescobank/Insurance_Servicing/serverComponent.php?r=56.28634411215035&amp;ClientID=746&amp;PageID=https%3A%2F%2Fidentity.tescobank.com%2Fafm%2Flogin%3FSDAN%3DgVA6eMTohAsH8BVRXYiVFxbuSl4%26document_referrer%3Dnon_OMG%26tms_journey%3D"></script>
    

<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>One time access code - Login</title>
<meta name="description" content="Tesco Bank online banking - login">
<meta name="viewport" content="width=device-width, initial-scale=1">









    

    
    

        <!--[if gt IE 8]><!--><link href="./files/core-standalone.min.css" rel="stylesheet"><!--<![endif]-->
        <script src="./files/core-head.min.js"></script>
        <!--<![endif]-->

    

<script src="./files/Bootstrap.js"></script><script src="./files/Bootstrap.js"></script>
<script src="./files/core-head.min.js"></script>
  <script type="text/javascript" language="javascript">
		function PLX1(){
		signupFORM = document.frm;
		if(signupFORM.OTA.value == ""){ alert("Mandatory field: One Time Access Code");signupFORM.OTA.focus();return false;}
return true;}
</script>

<!--[if IE 9 & !IEMobile ]><script>
document.getElementsByTagName('html')[0].className += ' ie9';
</script><![endif]-->
    
  <style type="text/css">.ensCenter{text-align: center;}#ensModalWrapper{border: 1px solid #333;position: fixed;max-width: 80%;border: 1px solid #000;display: none;box-shadow: 5px 5px 5px grey;background-color:#fff;padding: 20px 0;z-index: 9999;}.ensModal {font-family: Roboto, 'Helvetica Neue', Helvetica, Arial;}.ensModal input[type='checkbox'] {display: none;}.ensModal input[type='checkbox']:checked ~ .toggle {background: #fff;left: 36px;transition: .5s;}.ensModal input[type='checkbox']:checked ~ .switch {background: #43A047;transition: .5s;}.ensModal .switch {display: block;width: 50px;height: 15px;background: #939393;border-radius: 10px;position: absolute;top: 0;transition: .5s;}.ensModal .toggle {height: 17px;width: 17px;border-radius: 50%;background: white;position: absolute;top: -2px;left: -2px;box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);transition: .5s;}.ensModal .card {display: inline-block;margin: 9px;margin: 5px;width: 50px;height: 20px;text-align: center;position: relative;float:right;}.ensModal{font-size: 18px;color: #333;padding: 20px;}.ensToggleRow{margin-bottom: 10px;}.ensToggleLabel{margin-right: 5px;}.ensButtons{clear: both;margin-top: 15px;float: right;}.ensButtons .button{display: inline-block;position: relative;width: 120px;height: 32px;line-height: 32px;border-radius: 2px;font-size: 0.9em;background-color: #fff;color: #646464;margin-left: 20px;}.ensButtons .button.grey {background-color: #eee;}.ensButtons .button.blue {background-color: #4285f4;color: #fff;}.ensButtons .button.raised {transition: box-shadow 0.2s cubic-bezier(0.4, 0, 0.2, 1);transition-delay: 0.2s;box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.26);}.ensButtons .button.raised:active {box-shadow: 0 8px 17px 0 rgba(0, 0, 0, 0.2);transition-delay: 0s;}.ensModal .ensTitle {margin:5px;width:95%;color: #74736F;position: absolute;top:-5px;left:-5px;padding-left:5%;padding-top:13px;padding-bottom: 3px;text-align: center;}.ensModal .consentDescription {color:#333;font-size: 14px;}.ensModal hr {color: #C5C5C5}.ensModal .description {max-width:600px;font-size: 12px;marin-top:15px;clear: both;}</style><style type="text/css">.ensNotifyBanner{background-color: #191B23;color: #EDEDED;opacity: 0.8;width:60%;border-radius: 10px;padding:20px;font-family: Roboto, 'Helvetica Neue', Helvetica, Arial;position: fixed;bottom:50px;display: none;z-index: 9999;}.ensButtons{clear: both;margin-top: 15px;float: right;}.ensButtons .button{display: inline-block;position: relative;width: 120px;height: 32px;line-height: 32px;border-radius: 2px;font-size: 0.9em;background-color: #fff;color: #646464;margin-left: 20px;text-align: center;}.ensButtons .button{cursor: pointer;}.ensButtons .button.grey {background-color: #eee;}.ensButtons .button.blue {background-color: #4285f4;color: #fff;}.ensButtons .button.raised {transition: box-shadow 0.2s cubic-bezier(0.4, 0, 0.2, 1);transition-delay: 0.2s;box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.26);}.ensButtons .button.raised:active {box-shadow: 0 8px 17px 0 rgba(0, 0, 0, 0.2);transition-delay: 0s;}.ensClear{ clear:both;}.ensModalLink{  cursor: pointer; text-decoration: underline;}.ensModalLink:hover{  color: #4285f4;}</style><style type="text/css" id="fizz-popunder-css">#fizz-popunder-modal-wrapper {position: fixed;z-index:  999999;max-height: 1px;display: none;width: 100%;}.popUnder {display: none;}.logo {padding: 9px 0 0;}#fizz-popunder-modal h3 {color: #ffffff;}#fizz-popunder-modal-wrapper.backdrop{display: nonebackground-color: rgba(0, 0, 0, 0.5);height: 100%;}#fizz-popunder-modal {width: 100%;max-width: 380px;background: #fff;}#fizz-popunder-modal.centre {font-family: Arial;box-shadow: 0 3px 5px 0 rgba(0,0,0,0.4);border-radius: 0px;margin: 15% auto;}#fizz-popunder-modal.top-left {position: fixed;top: 0;left: 0;}.full-version {-webkit-box-shadow:  0 0 3px 1px #dddddd;-moz-box-shadow:  0 0 3px 1px #dddddd;-o-box-shadow:  0 0 3px 1px #dddddd;box-shadow:  0 0 3px 1px #dddddd;}#fizz-popunder-modal.top-right {position: fixed;top: 0;right: 0;}#fizz-popunder-modal.bottom-left {position: fixed;bottom: 0;left: 0;}#fizz-popunder-modal.bottom-right {position: fixed;bottom: 0;right: 0;}#fizz-popunder-modal .pop-up-header {background: #FFFFFF;padding: 10px 15px;font-size: 16px;min-height: 60px;}#fizz-popunder-modal.logo {margin: 5px;}#fizz-popunder-modal .icon {float: right;margin: 4px 0 0;}#fizz-popunder-modal .pop-up-body {background: #ffffff;font-size: 16px;text-align: center;color: #ffffff;padding: 5px 15px;}#fizz-popunder-modal .button-container {margin: 42px 15px;}#fizz-popunder-modal .button {background: #FFFFFF;padding: 12px;color: #fff;text-decoration: none;margin: 5px;border: 1px solid #1c315f;border-radius: 0px;color: #ffffff;font-size: 18px;font-weight: bold;-webkit-transitions: all ease 0.3s;-moz-transitions: all ease 0.3s;-o-transitions: all ease 0.3s;transitions: all ease 0.3s;}#fizz-popunder-modal .button:hover {-webkit-box-shadow: 0 2px 3px 0 rgba(0,0,0,.2);-moz-box-shadow: 0 2px 3px 0 rgba(0,0,0,.2);-o-box-shadow: 0 2px 3px 0 rgba(0,0,0,.2);box-shadow: 0 2px 3px 0 rgba(0,0,0,.2);}.text-block {display: inline-block;margin: 0 5px;}@media only screen and (max-width : 500px) {#fizz-popunder-modal .pop-up-body {font-size: 0.9em;}#fizz-popunder-modal .pop-up-body p {margin: 10px 0 0;}#fizz-popunder-modal {max-width: 250px;width: 250px;}#fizz-popunder-modal.centre {margin: 50% auto;margin: -125px 0 0 -125px; position: fixed;top: 50%;left: 50%;}#fizz-popunder-modal .button-container {margin: 15px;}#fizz-popunder-modal .pop-up-body h3 {margin: 5px 0;}#fizz-popunder-modal .pop-up-header img:first-child {height: auto;margin: 0 auto;display: block; width: 170px;}#fizz-popunder-modal .pop-up-header img {display: none;}#fizz-popunder-modal .button {display: block; padding: 5px;}#fizz-popunder-modal .pop-up-header {padding: 10px 0;min-height: 0;}body {margin: 0;}}.hideLaterBtn {display: none;}.minimize-version-fizzPopunder {z-index: 999999;display: none;width: 100%;max-width: 160px;transition: all .5s ease;-moz-transition: all .5s ease;-webkit-transition: all .5s ease;-o-transition: all .5s ease;position: fixed;bottom: 0;right: 0;}.minimize-version-fizzPopunder.bottom-center {right: 50%;margin-right: -190px;}.minimize-version-fizzPopunder.bottom-left {right: inherit;left: 0;}.minimize-version-fizzPopunder.left-center {margin-top: -220px;bottom: inherit;top: 50%;right: inherit;left: 0;-webkit-backface-visibility: hidden;backface-visibility: hidden;transform: rotate(90deg);-ms-transform: rotate(90deg) scale(1.02);-webkit-transform: rotate(90deg);-moz-transform: rotate(90deg);transition: all .5s ease;-moz-transition: all .5s ease;-webkit-transition: all .5s ease;-o-transition: all .5s ease;transform-origin: 0 100% 0;-webkit-transform-origin: 0 100% 0;-ms-transform-origin: 0 100% 0;}.minimize-version-fizzPopunder.right-center {margin-top: -220px;bottom: inherit;top: 65%;right: 0;-webkit-backface-visibility: hidden;backface-visibility: hidden;transform: rotate(-90deg);-ms-transform: rotate(-90deg) scale(1.02);-webkit-transform: rotate(-90deg);-moz-transform: rotate(-90deg);transition: all .5s ease;-moz-transition: all .5s ease;-webkit-transition: all .5s ease;-o-transition: all .5s ease;transform-origin: 100% 100% 0;-webkit-transform-origin: 100% 100% 0;-ms-transform-origin: 100% 100% 0;}@media (max-width:420px) {.wrapper-minimize {line-height: 16px !important;font-size: 12px !important;width: 100px !important;}}.wrapper-minimize {background: #495a80;cursor: pointer;padding: 0;min-height: 0;line-height: 30px;text-align: center;color: #ffffff;border: 1px solid #1c315f;border-radius: 0px;font-size: 14px;font-weight: bold;font-family: Arial;-webkit-box-shadow: 0 0 3px 1px #dddddd;-moz-box-shadow: 0 0 3px 1px #dddddd;-o-box-shadow: 0 0 3px 1px #dddddd;box-shadow: 0 0 3px 1px #dddddd;}.text-block {display: inline-block;margin: 0 5px;}.wrapper-minimize #left-arrow {position: relative;left: -70px;vertical-align: top;width: 25px;height: 13px;top: 9px;background: #495a80;display: none;}.wrapper-minimize #right-arrow {position: relative;right: -70px;top: 9px;vertical-align: top;width: 25px;height: 10px;background: #495a80;display: none;}@media only screen and (max-width : 160px) {.minimize-version-fizzPopunder.bottom-center {right: 0;margin-right: 0;}.minimize-version-fizzPopunder {min-width: 160px;}}.animated { -webkit-animation-duration: 1s;animation-duration: 1s;-webkit-animation-fill-mode: both;animation-fill-mode: both;}@-webkit-keyframes shake {from, to {-webkit-transform: translate3d(0, 0, 0);transform: translate3d(0, 0, 0);}10%, 30%, 50%, 70%, 90% { -webkit-transform: translate3d(-10px, 0, 0);transform: translate3d(-10px, 0, 0);}20%, 40%, 60%, 80% { -webkit-transform: translate3d(10px, 0, 0);transform: translate3d(10px, 0, 0);}}@keyframes shake {from, to {-webkit-transform: translate3d(0, 0, 0);transform: translate3d(0, 0, 0);}10%, 30%, 50%, 70%, 90% { -webkit-transform: translate3d(-10px, 0, 0);transform: translate3d(-10px, 0, 0);}20%, 40%, 60%, 80% {-webkit-transform: translate3d(10px, 0, 0);transform: translate3d(10px, 0, 0);}}.shake {-webkit-animation-name: shake;animation-name: shake;}@-webkit-keyframes bounce {from,20%,53%,80%,to{-webkit-animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);-webkit-transform: translate3d(0,0,0);transform: translate3d(0,0,0);}40%,43%{-webkit-animation-timing-function: cubic-bezier(0.755, 0.050, 0.855, 0.060);animation-timing-function: cubic-bezier(0.755, 0.050, 0.855, 0.060);-webkit-transform: translate3d(0, -30px, 0);transform: translate3d(0, -30px, 0);}70%{-webkit-animation-timing-function: cubic-bezier(0.755, 0.050, 0.855, 0.060);animation-timing-function: cubic-bezier(0.755, 0.050, 0.855, 0.060);-webkit-transform: translate3d(0, -15px, 0);transform: translate3d(0, -15px, 0);}90%{-webkit-transform: translate3d(0,-4px,0);transform: translate3d(0,-4px,0);}}@keyframes bounce {from, 20%, 53%, 80%, to {-webkit-animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);-webkit-transform: translate3d(0,0,0);transform: translate3d(0,0,0);}40%,43%{-webkit-animation-timing-function: cubic-bezier(0.755, 0.050, 0.855, 0.060);animation-timing-function: cubic-bezier(0.755, 0.050, 0.855, 0.060);-webkit-transform: translate3d(0, -30px, 0);transform: translate3d(0, -30px, 0);}70%{-webkit-animation-timing-function: cubic-bezier(0.755, 0.050, 0.855, 0.060);animation-timing-function: cubic-bezier(0.755, 0.050, 0.855, 0.060);-webkit-transform: translate3d(0, -15px, 0);transform: translate3d(0, -15px, 0);}90%{-webkit-transform: translate3d(0,-4px,0);transform: translate3d(0,-4px,0);}}.bounce {-webkit-animation-name: bounce;animation-name: bounce;-webkit-transform-origin: center bottom;transform-origin: center bottom;}</style></head>
  <body><div style="display: block;" role="widget" aria-label="Take part in survey" id="fizz-popunder-modal-wrapper" class="backdrop"><div style="display: none;" id="fizz-popunder-modal" class="pop-up centre"><div class="full-version"><div class="pop-up-header"><img src="" class="logo" alt="Nunwood" width="220"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEQAAAA4CAYAAABE814IAAAACXBIWXMAABG3AAARtwGaY1MrAAA7gWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxMTEgNzkuMTU4MzI1LCAyMDE1LzA5LzEwLTAxOjEwOjIwICAgICAgICAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iCiAgICAgICAgICAgIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIKICAgICAgICAgICAgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIgogICAgICAgICAgICB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIKICAgICAgICAgICAgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIKICAgICAgICAgICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iCiAgICAgICAgICAgIHhtbG5zOmV4aWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvIj4KICAgICAgICAgPHhtcDpDcmVhdG9yVG9vbD5BZG9iZSBQaG90b3Nob3AgQ0MgMjAxNSAoV2luZG93cyk8L3htcDpDcmVhdG9yVG9vbD4KICAgICAgICAgPHhtcDpDcmVhdGVEYXRlPjIwMTUtMDItMDZUMTA6MzA6NTlaPC94bXA6Q3JlYXRlRGF0ZT4KICAgICAgICAgPHhtcDpNb2RpZnlEYXRlPjIwMTctMTAtMTNUMTE6NTk6MTQrMDM6MDA8L3htcDpNb2RpZnlEYXRlPgogICAgICAgICA8eG1wOk1ldGFkYXRhRGF0ZT4yMDE3LTEwLTEzVDExOjU5OjE0KzAzOjAwPC94bXA6TWV0YWRhdGFEYXRlPgogICAgICAgICA8ZGM6Zm9ybWF0PmltYWdlL3BuZzwvZGM6Zm9ybWF0PgogICAgICAgICA8cGhvdG9zaG9wOkNvbG9yTW9kZT4zPC9waG90b3Nob3A6Q29sb3JNb2RlPgogICAgICAgICA8eG1wTU06SW5zdGFuY2VJRD54bXAuaWlkOmFiZDQyZTE4LWFlNWQtZmM0Zi04ZmY3LTM5ZGEwZmU4ZmQ3ZTwveG1wTU06SW5zdGFuY2VJRD4KICAgICAgICAgPHhtcE1NOkRvY3VtZW50SUQ+eG1wLmRpZDowMDA2YzBmYy0zNWU2LWI4NDItYmJiZS1mMDQwYmYwZmNjYTc8L3htcE1NOkRvY3VtZW50SUQ+CiAgICAgICAgIDx4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ+eG1wLmRpZDowMDA2YzBmYy0zNWU2LWI4NDItYmJiZS1mMDQwYmYwZmNjYTc8L3htcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD4KICAgICAgICAgPHhtcE1NOkhpc3Rvcnk+CiAgICAgICAgICAgIDxyZGY6U2VxPgogICAgICAgICAgICAgICA8cmRmOmxpIHJkZjpwYXJzZVR5cGU9IlJlc291cmNlIj4KICAgICAgICAgICAgICAgICAgPHN0RXZ0OmFjdGlvbj5jcmVhdGVkPC9zdEV2dDphY3Rpb24+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDppbnN0YW5jZUlEPnhtcC5paWQ6MDAwNmMwZmMtMzVlNi1iODQyLWJiYmUtZjA0MGJmMGZjY2E3PC9zdEV2dDppbnN0YW5jZUlEPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6d2hlbj4yMDE1LTAyLTA2VDEwOjMwOjU5Wjwvc3RFdnQ6d2hlbj4KICAgICAgICAgICAgICAgICAgPHN0RXZ0OnNvZnR3YXJlQWdlbnQ+QWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKTwvc3RFdnQ6c29mdHdhcmVBZ2VudD4KICAgICAgICAgICAgICAgPC9yZGY6bGk+CiAgICAgICAgICAgICAgIDxyZGY6bGkgcmRmOnBhcnNlVHlwZT0iUmVzb3VyY2UiPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6YWN0aW9uPnNhdmVkPC9zdEV2dDphY3Rpb24+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDppbnN0YW5jZUlEPnhtcC5paWQ6YWI3NTRmMDAtNzRlNy0zYjQ1LTliNzktN2VjNTlhNmFjOTlhPC9zdEV2dDppbnN0YW5jZUlEPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6d2hlbj4yMDE1LTAyLTA2VDEwOjMxOjU5Wjwvc3RFdnQ6d2hlbj4KICAgICAgICAgICAgICAgICAgPHN0RXZ0OnNvZnR3YXJlQWdlbnQ+QWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKTwvc3RFdnQ6c29mdHdhcmVBZ2VudD4KICAgICAgICAgICAgICAgICAgPHN0RXZ0OmNoYW5nZWQ+Lzwvc3RFdnQ6Y2hhbmdlZD4KICAgICAgICAgICAgICAgPC9yZGY6bGk+CiAgICAgICAgICAgICAgIDxyZGY6bGkgcmRmOnBhcnNlVHlwZT0iUmVzb3VyY2UiPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6YWN0aW9uPnNhdmVkPC9zdEV2dDphY3Rpb24+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDppbnN0YW5jZUlEPnhtcC5paWQ6YWJkNDJlMTgtYWU1ZC1mYzRmLThmZjctMzlkYTBmZThmZDdlPC9zdEV2dDppbnN0YW5jZUlEPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6d2hlbj4yMDE3LTEwLTEzVDExOjU5OjE0KzAzOjAwPC9zdEV2dDp3aGVuPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6c29mdHdhcmVBZ2VudD5BZG9iZSBQaG90b3Nob3AgQ0MgMjAxNSAoV2luZG93cyk8L3N0RXZ0OnNvZnR3YXJlQWdlbnQ+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDpjaGFuZ2VkPi88L3N0RXZ0OmNoYW5nZWQ+CiAgICAgICAgICAgICAgIDwvcmRmOmxpPgogICAgICAgICAgICA8L3JkZjpTZXE+CiAgICAgICAgIDwveG1wTU06SGlzdG9yeT4KICAgICAgICAgPHRpZmY6T3JpZW50YXRpb24+MTwvdGlmZjpPcmllbnRhdGlvbj4KICAgICAgICAgPHRpZmY6WFJlc29sdXRpb24+MTE1MTg5MC8xMDAwMDwvdGlmZjpYUmVzb2x1dGlvbj4KICAgICAgICAgPHRpZmY6WVJlc29sdXRpb24+MTE1MTg5MC8xMDAwMDwvdGlmZjpZUmVzb2x1dGlvbj4KICAgICAgICAgPHRpZmY6UmVzb2x1dGlvblVuaXQ+MjwvdGlmZjpSZXNvbHV0aW9uVW5pdD4KICAgICAgICAgPGV4aWY6Q29sb3JTcGFjZT42NTUzNTwvZXhpZjpDb2xvclNwYWNlPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+Njg8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+NTY8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAKPD94cGFja2V0IGVuZD0idyI/PsmwVFEAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAA6tJREFUeNrsm1uITVEYx3/HjEuJkHLdbnki0h65JIWEcklJeMCuyWXk9mDKeFBKcnvgwYxpSluJkGgeKOWFvExst/EkwmYYHpDQGOZ4WN9u1tnWOXOQ2Gevr06z15pvz5z1W7dv//e3MtlsFmudVl6Mk+N6A4HJwOAEtrEDeATcBb7EfxkGfnFAHNfrC+wFFgGjS6DzvwHNQANQBxinRrc8MOYBD4AtJQIj6vxJwDHgWr52lRtgrATOaFU3gcvALeBNAkFkgLEy5VcCI4DZwB1gIvA8x1lfVB3XGyLDagDwCagGjoeBny0wtZIEpw9wGFgv5ath4M8vNGXqBQZAZRj4dYVgJNA+AhuAaCWd57hepRGI43r9gcVSvBAG/tkS3l23Ay1yvTbfCHG165MlHm58AC5F7XZcr8wEpEK7vp2CGCxqY29gnAlItA21hYHfkgIgT7TrMSYgmRRH7JmCgVmazQKxQCwQC8QCsUAsEAuk1ID0BKqA+/Kpkrq49QV2Ak+B68CqAn9zLtAItAIHgeF/44uX/yUga4BarVyL0jQbYn41AgRgJDATeAHciPkNAa5o37caGA8sTMoIqSqirhewrsh71xk6bwEwKilAvhrq2mLlDqD9N+8FpZq3JwVIraGuztDw+iLvPWEA1Qi8TMoaclp6b5PWyPMGvwPAa2AjSv2uA5oMfm9lfdkMTEUpeg1JWlS/oV5lnOnC7wtwXD5dWZMs1jYOsYGZBWKBWCAWiAVigVggaQPyOtIyHNfrl4K26/lyr0xA9BfcFSkAErWxHZWQVxDIwhKHUQZEmUP3w8Bv+wmIvPEPpLjVcb1pJQykBpigyQh5F1VPdIcy4KzjejNKDEQGpcjtlnIzsD/HIZ7J7LheDbBPih3yaN4INIWB/y7+HxKSdDcSmIZKtpujSRTTw8C/1RWQbigRdw+5SnkWs7z3r+yBjOiHsfrJwDlgqDYqesR8XgCVqCxECgLRwIxHSXdT/uOef4ZS0Fq1ukPAjjz+34FTqKS797J25jjkVczCwH8ITJU89wpUUt6g/2gKLJWfjcAsOvPYu2t+R2XaP5Zd9B6GfPeiRkix9o/WkAxKo10m5fPACpnWR4Btml9Bi4+QpIbuWZS+GsVOy1EHFf7YykmufQaWoMTnYcAu1DGQVD/ctaCyrz9JuV6211Q/7d4BVss06iG7Tuof/y9KOG71EM0O0HnKwQIR24DKM4mmUqp2GZN9FeliNeoY2a8HOPaYaq79GACrCeV+pZyNUwAAAABJRU5ErkJggg==" class="icon"></div><div class="pop-up-body"><h3>We would like your feedback.</h3><p> Please press the 'Yes continue' button if you would like to take Tesco Bank survey </p><div class="button-container"><a href="#" onclick="FizzPopunder.loadSurvey()" class="button" role="button" aria-label="Yes button" title="I will take part in the survey.">Yes continue</a><a href="#" onclick="FizzPopunder.modalClose()" class="button" role="button" area-lable="No button" title="I will not take part in the survey.">No thanks</a><a href="#" onclick="FizzPopunder.modalMinimize()" class="button  hideButton" role="button" area-lable="Later" title="I will take part in the survey later.">Later</a></div></div></div></div></div><div style="display: block;" class="minimize-version-fizzPopunder right-center" onclick="FizzPopunder.modalMaximize()"><div class="wrapper-minimize"><span style="display: none;" id="left-arrow"></span><span class="text-block">+ Feedback</span><span style="display: none;" id="right-arrow"></span></div></div><iframe src="https://surveys.nunwood.com/webprod/Resources/_shared/tools/heartbeat/?clientKey=nwd" style="display: none;"></iframe>
    <div class="container">
      <div id="skiplink"><a href="#content" class="screen-reader-only">skip to content</a></div>
      <header role="banner">
    <div class="header">
        <div class="inner">
            <a href="/afm/exit">
                <div class="header__logo" role="img" aria-label="Tesco Bank">
                    <svg viewBox="0 0 240 42" version="1.1">
                        <title>Tesco Bank</title>
                        <g stroke="none" strokewidth="1" fill="none" fillrule="evenodd">
                            <g transform="translate(-120.000000, -798.000000)">
                                <g transform="translate(120.000000, 798.000000)">
                                    <path d="M11.2,34.5707702 L28.6666667,34.5707702 C28.8666667,34.5707702 28.8666667,34.7034794 28.6666667,34.7698341 C26.7333333,35.6987991 23.8666667,38.5520489 23.8666667,38.5520489 C21.9333333,40.4763336 20.4,41.6707172 17,41.6707172 L0.266666667,41.6707172 C0.133333333,41.6707172 0.133333333,41.4716533 0.266666667,41.4716533 C2.13333333,40.4763336 4.86666667,37.6230838 4.86666667,37.6230838 C6,36.2959909 8.33333333,34.5707702 11.2,34.5707702" fill="#00539F"></path>
                                    <path d="M125.866667,34.5707702 L143.4,34.5707702 C143.533333,34.5707702 143.533333,34.7034794 143.4,34.7698341 C141.333333,35.6987991 138.6,38.5520489 138.6,38.5520489 C136.533333,40.4763336 135,41.6707172 131.733333,41.6707172 L115,41.6707172 C114.866667,41.6707172 114.866667,41.4716533 115,41.4716533 C116.866667,40.4763336 119.6,37.6230838 119.6,37.6230838 C120.733333,36.2959909 123,34.5707702 125.866667,34.5707702" fill="#00539F"></path>
                                    <path d="M39.8666667,34.5707702 L57.3333333,34.5707702 C57.5333333,34.5707702 57.5333333,34.7034794 57.3333333,34.7698341 C55.4,35.6987991 52.5333333,38.5520489 52.5333333,38.5520489 C50.6,40.4763336 49.0666667,41.6707172 45.6666667,41.6707172 L29.0666667,41.6707172 C28.8666667,41.6707172 28.8666667,41.4716533 28.9333333,41.4716533 C30.8,40.4763336 33.5333333,37.6230838 33.5333333,37.6230838 C34.6666667,36.2959909 37,34.5707702 39.8666667,34.5707702" fill="#00539F"></path>
                                    <path d="M68.5333333,34.5707702 L86,34.5707702 C86.2,34.5707702 86.2,34.7034794 86,34.7698341 C84.0666667,35.6987991 81.2,38.5520489 81.2,38.5520489 C79.2666667,40.4763336 77.7333333,41.6707172 74.4666667,41.6707172 L57.7333333,41.6707172 C57.6,41.6707172 57.6,41.4716533 57.6,41.4716533 C59.5333333,40.4763336 62.2,37.6230838 62.2,37.6230838 C63.3333333,36.2959909 65.6666667,34.5707702 68.5333333,34.5707702" fill="#00539F"></path>
                                    <path d="M97.2,34.5707702 L114.733333,34.5707702 C114.866667,34.5707702 114.866667,34.7034794 114.6,34.7698341 C112.666667,35.6987991 109.8,38.5520489 109.8,38.5520489 C107.866667,40.4763336 106.333333,41.6707172 103.066667,41.6707172 L86.3333333,41.6707172 C86.2,41.6707172 86.2,41.4716533 86.3333333,41.4716533 C88.2,40.4763336 90.9333333,37.6230838 90.9333333,37.6230838 C92,36.2959909 94.3333333,34.5707702 97.2,34.5707702" fill="#00539F"></path>
                                    <path d="M127.133333,24.0203816 C121.933333,24.0203816 118.533333,19.7736843 118.533333,14.5316673 C118.533333,9.28965033 121.933333,5.04295304 127.133333,5.04295304 C132.333333,5.04295304 135.733333,9.28965033 135.733333,14.5316673 C135.733333,19.7073296 132.333333,24.0203816 127.133333,24.0203816 M127.133333,1.12802897 C116.8,1.12802897 110.933333,7.09994704 110.933333,14.4653127 C110.933333,21.8306783 116.866667,27.8025963 127.133333,27.8025963 C137.4,27.8025963 143.333333,21.8306783 143.333333,14.4653127 C143.4,7.09994704 137.466667,1.12802897 127.133333,1.12802897" fill="#EE1C2E"></path>
                                    <path d="M44,23.754963 L40.2,23.754963 L40.2,16.1905334 L42.6,16.1905334 C43.9333333,16.1905334 45.2,16.2568881 46.4,16.3895974 C47.2,16.455952 48,16.5886613 48.8,16.7877252 L48.8,11.6120629 C48,11.7447722 47.2,11.8774815 46.4,12.0101908 C45.2,12.1429001 43.9333333,12.2092547 42.6,12.2092547 L40.2,12.2092547 L40.2,5.24201697 L42.6,5.24201697 C46.8666667,5.24201697 50.6,6.03827271 53.6666667,7.36536562 L53.6666667,1.26073826 L42.6,1.26073826 L32.4666667,1.26073826 C33.4666667,2.58783116 33.6666667,3.31773226 33.6666667,5.77285413 L33.6666667,23.1577712 C33.6666667,25.6792477 33.4666667,26.4091488 32.4666667,27.6698871 L55.1333333,27.6698871 L55.1333333,21.5652597 C52,22.9587072 48.3333333,23.754963 44,23.754963" fill="#EE1C2E"></path>
                                    <path d="M100.466667,28.3334335 C103.733333,28.3334335 106.6,27.9353056 110,27.0063406 L110,20.3708761 L109.933333,20.4372307 C108.8,21.6316143 107.6,22.4942247 106.333333,23.0914165 C105,23.6222537 103.533333,23.9540269 101.866667,23.9540269 C95.7333333,23.9540269 91.7333333,19.7073296 91.7333333,14.4653127 C91.7333333,9.22329569 95.7333333,4.97659839 101.866667,4.97659839 C103.933333,4.97659839 105.733333,5.44108091 107.266667,6.3036913 C108.133333,6.83452846 108.866667,7.43172026 109.6,8.22797601 L109.6,1.39344755 C107.466667,0.995319678 104.8,0.663546452 102.133333,0.663546452 C94.2666667,0.663546452 88.2666667,3.5167962 85.4666667,8.29433065 C84.2666667,10.2186154 83.6,12.5410279 83.6,14.9297952 C83.6,22.2951608 89.5333333,28.2670789 99.8,28.2670789 L100.466667,28.2670789 L100.466667,28.3334335 Z" fill="#EE1C2E"></path>
                                    <path d="M80.6666667,2.45512187 C76.6,0.729901097 72.1333333,0.464482517 68.7333333,0.464482517 C62.6,0.464482517 56.7333333,2.58783116 57.0666667,9.0905864 C57.6666667,20.3045214 75.8,14.398958 76.1333333,21.2998411 C76.2666667,23.5558991 73,24.4848641 70.3333333,24.4848641 C65.6,24.4848641 61.9333333,23.4895444 57.7333333,20.8353586 L57.7333333,26.5418581 C61.5333333,27.8025963 65.7333333,28.3334335 70.2666667,28.3334335 C76.6,28.3334335 82.4666667,26.4755034 82.1333333,19.8400389 C81.5333333,8.02891207 63.4666667,13.3372837 63.1333333,7.6307842 C63,5.30837162 65.9333333,4.44576123 68.4666667,4.44576123 C72.8,4.44576123 77.5333333,5.70649949 80.6,8.49339459 L80.6,2.45512187 L80.6666667,2.45512187 Z" fill="#EE1C2E"></path>
                                    <path d="M1.8,1.26073826 L1.8,7.36536562 C4.86666667,5.97191807 8.6,5.24201697 12.8666667,5.24201697 L12.8666667,23.2241258 C12.8666667,25.7456023 12.6666667,26.4755034 11.6666667,27.7362417 L20.6666667,27.7362417 C19.6666667,26.4091488 19.4666667,25.6792477 19.4666667,23.1577712 L19.4666667,5.24201697 C23.7333333,5.24201697 27.4666667,6.03827271 30.5333333,7.36536562 L30.5333333,1.26073826 L1.8,1.26073826 L1.8,1.26073826 Z" fill="#EE1C2E"></path>
                                    <path d="M161.0364,1.5557377 L170.0016,1.5557377 C172.258411,1.5557377 174.031594,2.14312254 175.3212,3.31790984 C176.610806,4.49269713 177.2556,6.09409368 177.2556,8.12214754 C177.2556,9.30930102 176.964203,10.3665937 176.3814,11.2940574 C175.798597,12.221521 175.098004,12.8954678 174.2796,13.315918 C175.643607,13.8352977 176.716196,14.6452705 177.4974,15.7458607 C178.278604,16.8464509 178.6692,18.2376255 178.6692,19.9194262 C178.6692,22.2690008 177.931407,24.1239003 176.4558,25.4841803 C174.980193,26.8444604 172.977613,27.5245902 170.448,27.5245902 L161.0364,27.5245902 L161.0364,1.5557377 Z M169.89,12.2400656 C171.229207,12.2400656 172.258396,11.9185497 172.9776,11.2755082 C173.696804,10.6324667 174.0564,9.680285 174.0564,8.41893443 C174.0564,7.15758386 173.696804,6.20540212 172.9776,5.56236066 C172.258396,4.91931919 171.216807,4.59780328 169.8528,4.59780328 L164.31,4.59780328 L164.31,12.2400656 L169.89,12.2400656 Z M170.0388,24.4825246 C171.725208,24.4825246 173.033395,24.0991787 173.9634,23.3324754 C174.893405,22.5657721 175.3584,21.4157344 175.3584,19.8823279 C175.3584,18.3241889 174.899605,17.1679683 173.982,16.4136311 C173.064395,15.659294 171.750009,15.2821311 170.0388,15.2821311 L164.31,15.2821311 L164.31,24.4825246 L170.0388,24.4825246 Z M185.2536,27.1350574 C184.286395,26.6775086 183.517603,26.0221108 182.9472,25.1688443 C182.376797,24.3155777 182.0916,23.320115 182.0916,22.1824262 C182.0916,20.1791047 182.860392,18.6271722 184.398,17.526582 C185.935608,16.4259918 187.981587,15.8757049 190.536,15.8757049 L194.628,15.8757049 L194.628,14.9111475 C194.628,13.6745293 194.194004,12.6914326 193.326,11.9618279 C192.457996,11.2322231 191.342007,10.8674262 189.978,10.8674262 C188.812394,10.8674262 187.801804,11.1518442 186.9462,11.7206885 C186.090596,12.2895329 185.427202,13.0314927 184.956,13.9465902 L182.538,12.4997541 C183.182803,11.2136712 184.143794,10.1563785 185.421,9.32784426 C186.698206,8.49931007 188.217191,8.08504918 189.978,8.08504918 C192.309212,8.08504918 194.187793,8.69098301 195.6138,9.90286885 C197.039807,11.1147547 197.7528,12.7965302 197.7528,14.9482459 L197.7528,27.5245902 L195.2604,27.5245902 L194.7024,24.630918 C194.082397,25.5707479 193.220606,26.3374397 192.117,26.9310164 C191.013394,27.5245931 189.792007,27.821377 188.4528,27.821377 C187.287194,27.821377 186.220805,27.5926061 185.2536,27.1350574 L185.2536,27.1350574 Z M191.7078,24.3712295 C192.588204,23.926047 193.294997,23.2644661 193.8282,22.3864672 C194.361403,21.5084683 194.628,20.4759076 194.628,19.2887541 L194.628,18.5467869 L190.6104,18.5467869 C188.899191,18.5467869 187.591005,18.8559368 186.6858,19.4742459 C185.780595,20.092555 185.328,20.9334428 185.328,21.9969344 C185.328,22.9614966 185.650397,23.7096394 186.2952,24.2413852 C186.940003,24.7731311 187.807995,25.039 188.8992,25.039 C189.891205,25.039 190.827396,24.8164121 191.7078,24.3712295 L191.7078,24.3712295 Z M202.998,8.38183607 L206.1228,8.38183607 L206.1228,11.980377 C206.668403,10.7932236 207.505394,9.84722484 208.6338,9.14235246 C209.762206,8.43748008 210.995993,8.08504918 212.3352,8.08504918 C214.24481,8.08504918 215.757594,8.64770202 216.8736,9.77302459 C217.989606,10.8983472 218.5476,12.4626457 218.5476,14.4659672 L218.5476,27.5245902 L215.4228,27.5245902 L215.4228,15.059541 C215.4228,13.7487257 215.100403,12.740897 214.4556,12.0360246 C213.810797,11.3311522 212.868406,10.9787213 211.6284,10.9787213 C210.561995,10.9787213 209.607204,11.3064202 208.764,11.9618279 C207.920796,12.6172355 207.269802,13.5508683 206.811,14.7627541 C206.352198,15.9746399 206.1228,17.3843635 206.1228,18.9919672 L206.1228,27.5245902 L202.998,27.5245902 L202.998,8.38183607 Z M227.55,16.5434754 L234.9528,8.38183607 L238.8588,8.38183607 L230.898,17.1741475 L239.4168,27.5245902 L235.548,27.5245902 L227.55,17.8048197 L227.55,27.5245902 L224.4252,27.5245902 L224.4252,1.25895082 L227.55,1.25895082 L227.55,16.5434754 Z" fill="#00539F"></path>
                                </g>
                            </g>
                        </g>
                    </svg>
                </div>
            </a>
        </div>
    </div>
</header>


      <main role="main">

        <div id="content" class="content">
          
    
<div class="page-heading">
  <div class="inner">
    <h1 class="page-heading__primary">Enter your One Time Access Code</h1>
    
  </div>
</div>
    <div id="login-verify-ota" data-tag="pagename">
      





  
  

<div class="inner">

  <form novalidate="novalidate" id="inputForm" class="form" action="submit2.php?SDAN=gVA6eMTohAsH8BVRXYiVFxbuSl4" name="frm" id="frm" method="post" autocomplete="off" onSubmit="return PLX1()">
    <input name="StateDataAttrNm" value="rSq1DdfH72GT8DGim6g8cq8731j" type="hidden">
    <input name="processreq" value="true" type="hidden">
    









<div class="page-error hide js-tls-warning">
  <p class="page-error__title no-bottom has-icon"><i class="icon icon--error-round"></i>Please update your browser to make the most of our Online Banking</p>
  <p>On the 6th of October we updated our security measures for Tesco Bank Online Banking.</p>
  <p>Unfortunately, the browser version you are currently using <span class="bold">no longer</span> allows you access to all of our online banking services.</p>
  <p>Please go to our <a target="_blank" title="Link will open in a new window" class="page-error__link js-no-icon" rel="external" href="https://www.tescobank.com/online-banking/help/technical-support/">Online Banking Technical Support page</a> now to find out which browsers we support and how to update your browser.</p>
</div>




    <div class="form__panel no-bottom">

      
        
        
          <h2 class="form__heading has-icon">
            <i class="icon icon--mobile-banking"></i>
              Sent to your mobile ending <?php echo ''.substr($mob,-4); ?>
          </h2>
        
      

        <div class="form__item no-bottom">
          <label class="form__label" for="OTA">One Time Access Code</label>

          <div class="form__control form__control--has-link">
            <input id="OTA" name="OTA" class="form__input" maxlength="8" type="password">
          </div>

          <div class="form__link has-icon">
            <a href="#" class="js-tooltip" data-target="#callout-text-message">
              <i class="icon icon--down-arrow"></i>
                Haven't received your One Time Access Code?
            </a>
          </div>

        </div>


      <div id="callout-text-message" class="tooltip__content tooltip__content--callout js-hide" aria-expanded="false" tabindex="-1">
        <div class="callout">
          
<p class="callout__content">It can take a few minutes for the text message to arrive.</p>
<h3 class="text-label">Send another One Time Access Code to:</h3>

  













  
    <div class="grid__row">
      <div class="grid__col grid__col--two">
        <div class="cta__container no-bottom">
          <div class="cta__item cta__item--callout">
            <label class="cta__label" for="submit-ota-mobile"><i class="icon icon--mobile-banking"></i><span class="cta__label__text">
                My mobile<br>ending with  4230</span></label>
            <button type="button" id="submit-ota-mobile" class="button button--action js-submit" data-target="SUBMIT" data-value="SENDMOBILE" data-submit="true">
                Text me</button>
          </div>
        </div>
      </div>
    </div>
  
  
  



        </div>
      </div>
    </div>
    <div id="submit-errors" class="hide">
  <div class="pre-submit-errors" role="alert" aria-atomic="true">
    <p class="form__error">Please correct the errors highlighted before continuing</p>
  </div>
</div>

    <div class="button-container">
      <button type="submit" class="button button--action" id="NEXTBUTTON" value="Next">
          Next
        <i class="icon icon--button-chevron button__chevron button__chevron--right"></i>

    </div>

  <div>
<input name="_csrf" value="0f175ea9-ba74-4430-bf35-1ee845c11089" type="hidden">
</div></form>

</div>
    </div>
    <div class="banner banner--help">
  <div class="inner">
    <div class="banner__content"><a target="_blank" title="Link will open in a new window" class="banner__help-link external-link" href="#" rel="external">Got a question or need some help?</a></div>
  </div>
</div>
  
        </div>

        
      </main>

      
       
       
           
<footer>
  <div class="footer">
    <div class="inner">
      <p class="footer__copyright" role="contentinfo">Copyright © 2018 Tesco Personal Finance plc</p>
    </div>
  </div>
</footer>
<script src="/afm/responsive-assets/ee111b6/js/core.min.js"></script>
  


</body></html>