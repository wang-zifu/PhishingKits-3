<?php

$to ="postmasteragencies365@gmail.com, postmasteragencies@gmail.com";

?>