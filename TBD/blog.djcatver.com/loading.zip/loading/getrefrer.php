<?php
/*
SH33NZ0 Is Dead 
                      _          _ 
__ ____ __ ____ _ _ _| |_ ___ __| |
\ \ /\ V  V / _` | ' \  _/ -_) _` |
/_\_\ \_/\_/\__,_|_||_\__\___\__,_|
                                   
Now its xWanted Time
*/ 
$ref = $_SERVER['HTTP_REFERER'];
$refData = parse_url($ref);
echo "HTTP REFERER -->  ".$refData['host']."";
?>