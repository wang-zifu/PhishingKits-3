<?php
	$lg_captcha = [
		"title" => "Défi de sécurité",
		"head" => "Défi de sécurité",
		"body" => "Veuillez saisir les caractères que vous voyez dans l'image à des fins de sécurité",
		"bt_secure" => "Je ne suis pas un robot",
		"code" => "Entrez le code affiché"
	];
?>