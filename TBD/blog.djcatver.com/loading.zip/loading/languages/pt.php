<?php
	$lg_captcha = [
		"title" => "Desafio de Segurança",
		"head" => "Desafio de Segurança",
		"body" => "Por favor, digite os caracteres que você vê na imagem para fins de segurança",
		"bt_secure" => "Eu não sou um robô",
		"code" => "Digite o código mostrado"
	];
?>