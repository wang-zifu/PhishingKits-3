<?

$to = "news@authorangeraallen.com, i1ii1i1ii@yandex.com";

?>