<?php
##########
#make predefined changes to a database and report the results
##########

require_once( "./functions/include_all.php" );

##########
#subroutines
##########

#############################################################################
#---modify or add an entry to the database ---###############################
#############################################################################
#---receives: object containing all variables
#---returns: nothing
#---globals: 
#---algorithm: 
function do_modify_or_add(
	$all_vars,
	$requested_changes,
	$parse_errors,
	$update_sql_set,
	$insert_sql_values,
	$insert_sql_columns
){
	$table = $all_vars->table;
	$id = $all_vars->id;
	$id_detail_view_page = $all_vars->pages[ "id_detail" ];
	$add_page = $all_vars->pages[ "add" ];
	
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
		
	if( !$requested_changes ){
		echo"<br>No changes were requested\n";
		echo"<br>\n";
	} else if( $all_vars->action == "modify" ) {
	
		if( $parse_errors ){
			$id_detail_view_page = modify_url_vars( $id_detail_view_page, "id", $id );
			$id_detail_view_page = modify_url_vars( $id_detail_view_page, $assets_name, $table );
			echo"<br>Your requested changes contained errors and have been ignored\n";
			echo"<br>Click your browser's \"back\" button or <a href=\"$id_detail_view_page\">here</a> to try again\n";
			echo"<br>\n";
		} else {
			#remove last character from $update_sql_set, since it is an extra comma
			$update_sql_set = substr( $update_sql_set, 0, -1 );
			$update_sql = 
				"\nUPDATE `" . 
				$table . $table_name_separator . $assets_name . 
				"`\nSET" . 
				$update_sql_set . 
				"\nWHERE `" . 
				$table . $table_name_separator . $assets_name . 
				"`.`id`='$id'\n";
			$update_result = mysql_query( $update_sql );
			echo"<br>Item has been updated.\n";
		}
	
	} else if( $all_vars->action == "add" ){
		if( $parse_errors ){
			$add_page = modify_url_vars( $add_page, $assets_name, $table );
			echo"<br>Your requested addition contained errors and has been ignored\n";
			echo"<br>Click your browser's \"back\" button or <a href=\"$add_page\">here</a> to try again\n";
			echo"<br>\n";
		} else {
			#remove last character from both $insert strings, since they have an extra comma
			$insert_sql_values = substr( $insert_sql_values, 0, -1 );
			$insert_sql_columns = substr( $insert_sql_columns, 0, -1 );
			$insert_sql = 
				"\nINSERT" . 
				"\nINTO `" .
				$table . $table_name_separator . $assets_name . "`(" .
				$insert_sql_columns . 
				"\n)" . 
				"\nVALUES (" . 
				$insert_sql_values . 
				"\n)";
			$insert_result = mysql_query( $insert_sql );
		}
	}
}

#############################################################################
#---modify/add/delete an item in the database ---############################
#############################################################################
#TODO: $parse_errors is not being obeyed
#should spit back error if input wasn't valid
#---receives: object containing all variables
#---returns: nothing
#---globals: 
#---algorithm: 
function do_alterations( $all_vars ){
	$table = $all_vars->table;
	$id = $all_vars->id;
	$id_detail_view_page = $all_vars->pages[ "id_detail" ];
	$add_page = $all_vars->pages[ "add" ];
	
	$database_name = $all_vars->table_structure->database_name;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	$db = $all_vars->table_structure->db;
	
	#initialize sundry variables
	$all_vars = initialize_vars( $all_vars );
	
	#get all column names from database
	$all_vars->column_names = calculate_column_names( $all_vars );
	$column_names = $all_vars->column_names;
	
	#convert passed request url into array $query_vars
	$passed_url_array = parse_url( $all_vars->this_request );
	parse_str( $passed_url_array[ "query" ], $query_vars );
	
	$all_vars->field_info = get_field_info( 
		$database_name, 
		$table . $table_name_separator . $assets_name 
	);
	$field_info = $all_vars->field_info;
	
	#ensure that user's requested action is allowed
	#this will be set to 1 if the user is permitted to do as he requests
	$permitted = 0;
	
	#received request to add or modify a record
	if( $all_vars->action == "modify" || $all_vars->action == "add" ){
		
		#if user input out-of-range or illegal values, this will be set to 1
		#and all requested changes ignored
		$parse_errors = 0;

		#if user wants to modify a record, make sure they have permission
		if( $all_vars->action == "modify" ){
			$sql_permissions_result = verify_acl( 
				$all_vars->connected_user, 
				$all_vars->table_structure->permissions[ "modify" ],
				$table . $table_name_separator . $assets_name
			);
			
			if( mysql_num_rows( $sql_permissions_result ) > 0 ){
				echo"<br>Making changes to record:\n";
				$permitted = 1;
				
				#since user is requesting a modify, make sure the requested id exists
				if( !id_exists( $all_vars ) ){
					echo( "<br>&nbsp\n" );
					echo( "<br>Can't modify non-existent record with id " . $all_vars->id . "\n" );
					$parse_errors = 1;
				}
			}

		#if user wants to add a record, make sure they have permission
		} else if( $all_vars->action == "add" ){
			$sql_permissions_result = verify_acl( 
				$all_vars->connected_user, 
				$all_vars->table_structure->permissions[ "add" ],
				$table . $table_name_separator . $assets_name
			);
			
			if( mysql_num_rows( $sql_permissions_result ) > 0 ){
				echo"<br>Adding new record:\n";
				$permitted = 1;
			}

		}
		
		if( $permitted ){
			echo"<br>\n";
			
			$requested_changes = 0;
			$update_sql_set = "";
			$insert_sql_columns = "";
			$insert_sql_values = "";
			foreach( $column_names as $c_number => $c_name ){
						
				#get type of current column
				$column_type = column_type( $all_vars, $c_name );
				
				#only make modifications on this column if this is one of the "standard" system types
				if( in_array( $column_type, $all_vars->table_structure->column_types ) ){
					
					#only make a change to the field if the "commit" box is checked
					#or if we're adding a new record
					if( array_key_exists( $c_name . "-commit", $query_vars ) ||  
						$all_vars->action == "add"
					){
					
						$first_part = "\n\t`" . $table . $table_name_separator . $assets_name . "`.`$c_name`=";
						$insert_sql_columns .= "\n\t`$c_name`,";
						
					#if the column name is set with suffix "-Null", set value to null
						if( array_key_exists( $c_name . "-Null", $query_vars ) ){
							$requested_changes = 1;
							echo"<br>un-setting $c_name\n";
							echo"<br>\n";
							$update_sql_set .= $first_part . "NULL,";
							$insert_sql_values .= "\n\tNULL,";
						
					#otherwise, if the column name is in the query url
					#check for validity of new value & apply
						} else if( array_key_exists( $c_name, $query_vars ) ){
							$requested_changes = 1;
							
							#validate the input before trying to modify the database
							list( $returned_errors, $tentative_sql_modify, $tentative_sql_insert ) = 
								validate_input_request( $all_vars, $c_name, $query_vars, $first_part );
							if( $returned_errors ){
								$parse_errors = 1;
							}
							if( !$parse_errors ){
								$update_sql_set .= $tentative_sql_modify;
								$insert_sql_values .= $tentative_sql_insert;
							}
							
							echo"<br>\n";
							
					#if the column name isn't in the query url
					#and we're adding a new record, should return an error
					#otherwise our add sql statement will be incorrect
						} else if( 
							!array_key_exists( $c_name, $query_vars ) && 
							$all_vars->action == "add" 
						){
							echo( "<br>error: attempted to add record, but missing field $c_name\n" );
							echo( "<br>&nbsp\n" );
							$parse_errors = 1;
							$requested_changes = 1;
						}
					}
				}
				
				$all_vars = do_hook( $all_vars, "in_modify_after_standard_modify" );
			}
			
			#now we have our modify/add sql code, execute it
			do_modify_or_add( 
				$all_vars, 
				$requested_changes, 
				$parse_errors, 
				$update_sql_set, 
				$insert_sql_values,
				$insert_sql_columns
			);
		}
	
	#received request to delete a record
	} else if( $all_vars->action == "delete" ){
		$sql_permissions_result = verify_acl( 
			$all_vars->connected_user, 
			$all_vars->table_structure->permissions[ "delete" ],
			$table . $table_name_separator . $assets_name
		);
		
		if( mysql_num_rows( $sql_permissions_result ) > 0 ){
			$permitted = 1;
			
			echo"<br>Deleting item with id $id\n";
			echo"<br>\n";
			$delete_sql = 
				"\nDELETE FROM `" . 
				$table . $table_name_separator . $assets_name . 
				"` WHERE `id`='$id'";	
		
			$delete_result = mysql_query( $delete_sql );
		}
	
	#received unkown request
	} else {
		error_message( "Request to alter record in $table not understood" );
	}

	if( !$permitted ){
		error_message( "Permission denied for " . $all_vars->action . 
			" on $table or it doesn't exist" );
	}
}

#############################################################################
#---check that user input follows database's structural rules ---############
#############################################################################
#---receives: object containing all variables
#---returns: 
#---globals: 
#---algorithm: 
function validate_input_request( $all_vars, $c_name, $query_vars, $first_part ){
	$table = $all_vars->table;
	$field_info = $all_vars->field_info;
	
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	$db = $all_vars->table_structure->db;
	
	$parse_errors = 0;
	
	#set a default for the sql fragment for this value
	#we'll override it if the type calls for the value to be interpreted/changed
	$tentative_sql_modify = $first_part . "'" . $query_vars[ $c_name ] . "',";
	$tentative_sql_insert = "\n\t'" . $query_vars[ $c_name ] . "',";
	
	#if this column links to a subtable, need to tell user we're updating
	#should tell the user the *name* of the new subtable value, not the id
	#so here we look up the name and echo it out
	#if there was no subtable entry with the given id, return error
	if( 
		links_to_subtable(
			$table . $table_name_separator . $tabledefs_name,
			$c_name,
			$all_vars
		) 
	){
		$subtable_values_query =
			"\nSELECT `name` " . 
			"FROM `$table" . $table_name_separator . $c_name . "`" .
			"WHERE `id`='" . $query_vars[ $c_name ] . "'";
		$subtable_values_result = mysql_query( $subtable_values_query, $db );
		
		#if there was a name with the given id, return it
		if( mysql_num_rows( $subtable_values_result ) ){
			$subtable_row = mysql_fetch_array( $subtable_values_result );
			echo"<br>setting $c_name to \"" . $subtable_row[ "name" ] . "\"\n";
		
		#otherwise, id was bogus, print error, set $parse_error
		} else {
			echo( "<br>error: can't set $c_name; nonexistent id\n" );
			$parse_errors = 1;
		}
	
	#if it's supposed to be an integer, make sure it is, otherwise echo an error
	} else if( ereg( "^int", $field_info[ $c_name . "-Type" ] ) ){
		echo"<br>setting $c_name to " . $query_vars[ $c_name ] . "\n";
		
		if( !is_numeric( $query_vars[ $c_name ] ) ){
			$parse_errors = 1;
			echo"<br>error: may only contain digits\n";
		}
		
	#if it's supposed to be a date, make sure it is, otherwise echo an error
	#also tell user what date we parsed from his input
	#also interpret the raw input date as a timestamp
	#this allows us to format it back for the sql standard date input "yyyy-mm-dd"
	} else if( ereg( "^date", $field_info[ $c_name . "-Type" ] ) ){
		echo"<br>setting $c_name to ";
		
		#if our input date was unparseable, return an error
		if( ( $time_stamp = strtotime( $query_vars[ $c_name ] ) ) == -1 ){
			$parse_errors = 1;
			echo $query_vars[ $c_name ] . "\n";
			echo"<br>error: date not understood\n";
		
		#if our input date was blank, return an error
		} else if( !$query_vars[ $c_name ] ){
			$parse_errors = 1;
			echo"<br>error: a blank date has been input; this is not valid\n";
		
		#otherwise, go ahead and parse/set the date
		} else {
			echo date( "F j, Y", $time_stamp ) . "\n";
	
			$tentative_sql_modify = $first_part . "'" . date( "Y-m-d", $time_stamp ) . "',";
			$tentative_sql_insert = "\n\t'" . date( "Y-m-d", $time_stamp ) . "',";
		}
		
	#if it's none of the above, just echo it back as text	
	} else {
		echo"<br>setting $c_name to " . $query_vars[ $c_name ] . "\n";
	}
	
	
	#if it's supposed to be unique, make sure it is
	if( 
		check_uniqueness(
			$field_info[ $c_name . "-Key" ],
			$all_vars,
			$c_name,
			$query_vars[ $c_name ]
		) == 2
	){
		$parse_errors = 1;
		echo"<br>error: this value is already in use by another record\n";
	}
	
	return( array( $parse_errors, $tentative_sql_modify, $tentative_sql_insert ) );
}

##########
#driver
##########

$all_vars = new all;

#put _GET variables into $all_vars object
$all_vars = copy_env_vars_to_object( $all_vars );

print_page_header( $all_vars, "asset modified" );

if( $_GET[ 'modify' ] ){
	$all_vars->action = "modify";
} else if( $_GET[ 'add' ] ){
	$all_vars->action = "add";
} else if( $_GET[ 'delete' ] ){
	$all_vars->action = "delete";
}

do_alterations( $all_vars );

print_page_footer( $all_vars );

?>
