<?php
##########
#display page to modify database structure
##########

require_once( "./functions/include_all.php" );

##########
#subroutines
##########

#############################################################################
#---display form or list to enter new data for one field---##################
#############################################################################
#TODO: document this!
#---receives: object containing all data
#name of current column
#---returns: whether the current column pulls its name from a lookup table
#	returns 1 if yes, 0 if no
#---globals: 
#---algorithm: 
function display_data_types( 
	$all_vars, $c_name, $add_permission, $delete_permission, $modify_permission 
){
	$row_height = $all_vars->html_presets->row_height;

	$table = $all_vars->table;
	$field_info = $all_vars->field_info;

	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$database_name = $all_vars->table_structure->database_name;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	$db = $all_vars->table_structure->db;
	$structure_name = $all_vars->table_structure->structure_name;
	
	#get type of current column
	$column_type = column_type( $all_vars, $c_name );
	#add current column name to hook_objects so plugins can see it
	$all_vars->hook_objects[ "current_column" ] = $c_name;	
	
	echo"<tr $row_height " . $all_vars->html_presets->odd_row . ">\n";
	echo"<td>\n";
	echo"<column_header>$c_name</column_header>\n";
	echo"</td>\n";
	echo"<td>\n";
	
	#check if the current column has a subtable to link its values to
	#if so, add a link to the dropdown modify url
	if( $column_type == $all_vars->table_structure->column_types[ "dropdown" ] ){
		
		echo( "drop-down list\n" );
		
		$permissions = array();
		$permissions[ "subtable_add" ] = $add_permission;
		$permissions[ "subtable_delete" ] = $delete_permission;
		$permissions[ "subtable_modify" ] = $modify_permission;
		
		foreach( $permissions as $permission_name => $permission_value ){
			#only show link if modify/add/delete allowed
			if( $permission_value ){
				echo"</td>\n";
				echo"</tr>\n";
				
				#put modify/add/delete structure on next row
				echo( "<tr $row_height>\n" );
				echo( "<td>\n" );
				echo( "&nbsp\n" );
				echo( "</td>\n" );
				echo( "<td>\n" );
				
				$drop_down_modify_url = 
					modify_url_vars(
						$all_vars->pages[ "structure" ],
						"dropdown_modify",
						$c_name
					);
				$base_modify_url = 
					modify_url_vars(
						$drop_down_modify_url,
						$assets_name,
						$table
					);
					
				if( $permission_name == "subtable_modify" ){
					$base_modify_url = 
						modify_url_vars(
							$base_modify_url,
							"subtable_modify",
							"1"
						);
					echo( 
						"<a href=\"$base_modify_url\">modify</a>" . 
						" dropdowns and defaults\n" 
					);
				} else {
					if( $permission_name == "subtable_add" ){
						$action = "add";
						$dropdown_modify_url = 
							modify_url_vars(
								$base_modify_url,
								"subtable_add_dropdown",
								"1"
							);
						$default_modify_url = 
							modify_url_vars(
								$base_modify_url,
								"subtable_add_default",
								"1"
							);
					} else if( $permission_name == "subtable_delete" ){
						$action = "delete";
						$dropdown_modify_url = 
							modify_url_vars(
								$base_modify_url,
								"subtable_delete_dropdown",
								"1"
							);
						$default_modify_url = 
							modify_url_vars(
								$base_modify_url,
								"subtable_delete_default",
								"1"
							);
					}
					
					echo( 
						"$action " .
						"<a href=\"$dropdown_modify_url\">dropdown</a> or " .
						"<a href=\"$default_modify_url\">default</a>\n" 
					);
				}
				
			}
		}

	} else if( $column_type == $all_vars->table_structure->column_types[ "simple" ] ){
		$unique = "";
		if( 
			check_uniqueness(
				$field_info[ $c_name . "-Key" ],
				$all_vars,
				$c_name,
				""
			)
		){
			$unique = "unique ";
		}
		
		$may_be_null = "";
		if( $all_vars->field_info[ $c_name . "-Null" ] ){
			$may_be_null = "; allowed to be null";
		}
		
		$type = "text";
		if( ereg( "^int", $all_vars->field_info[ $c_name . "-Type" ] ) ){
			$type = "number/integer"; 
		} else if( ereg( "^date", $all_vars->field_info[ $c_name . "-Type" ] ) ){
			$notes = "date";
		}
		
		echo( $unique . $type . $may_be_null . "\n" );
	}

	$all_vars = do_hook( $all_vars, "in_structure_after_print_field_criteria" );

	echo"</td>\n";
	echo"</tr>\n";
	
	#do a blank table row
	echo( "<tr $row_height>\n" );
	echo( "<td>\n" );
	echo( "</td>\n" );
	echo( "</tr>\n" );
	
	return( $is_a_subtable );
}

#############################################################################
#---pick table to add to ---#################################################
#############################################################################
#TODO: document this!
#TODO: merge this and "do_list_selection" in list.php; they're almost identical
#---receives: object containing all data
#---returns: nothing
#---globals: 
#---algorithm: 
function do_structure_selection( $all_vars ){
	$database_name = $all_vars->table_structure->database_name;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$structure_name = $all_vars->table_structure->structure_name;
	
	$row_height = $all_vars->html_presets->row_height;
	
	$table = $all_vars->table;
	
	if( isset( $table ) ){
		$sql_permissions_result = verify_acl( 
			$all_vars->connected_user, 
			$all_vars->table_structure->permissions[ "view" ],
			$table . $table_name_separator . $assets_name . $table_name_separator . $structure_name
		);
		
		if( mysql_num_rows( $sql_permissions_result ) > 0 ){
			
			#echo( "<br>viewing $table structure\n" );
			print_structure( $all_vars );

		} else {
			error_message( "User " . $all_vars->connected_user . 
				" is not allowed to modify $table structure or it is not a valid table" );

			#generate html for picking a table to edit structure
			list( $number_of_tables, $widget_html, $permitted_tables ) =
				pick_table( $all_vars, "view", "structure", 0 );
	
			#if no table-structure view allowed, print "not allowed" message
			if( $number_of_tables == 0 ){
				echo( "<br>No view permission for any individual tables' structures\n" );
			
			#if only one table is permitted, show it instead of printing the "select" button
			} else if( $number_of_tables == 1 ){
				$all_vars->table = $permitted_tables[ 0 ];
				print_structure( $all_vars );
			
			#otherwise, proceed normally with selection widget or "not allowed" message
			} else {
				echo( $widget_html );
			}
		}
	} else {
		
		#generate html for picking a table to edit structure
		list( $number_of_tables, $widget_html, $permitted_tables ) =
			pick_table( $all_vars, "view", "structure", 0 );
		
		#if no table-structure view allowed, print "not allowed" message
		if( $number_of_tables == 0 ){
			echo( "<br>No view permission for any individual tables' structures\n" );
		
		#if only one table is permitted, show it instead of printing the "select" button
		} else if( $number_of_tables == 1 ){
			$all_vars->table = $permitted_tables[ 0 ];
			print_structure( $all_vars );
		
		#otherwise, proceed normally with selection widget or "not allowed" message
		} else {
			echo( $widget_html );
		}
	}
}

#############################################################################
#---shows info/edit fields for a dropdown list---############################
#############################################################################
#---receives: 
#object containing all data
#name of current column
#permissions for add/delete/modify structure for this asset list
#---returns: 
#---globals: 
#---algorithm: 
function drop_down( 
	$all_vars, $query_vars, $add_permission, $delete_permission, $modify_permission 
){
	$row_height = $all_vars->html_presets->row_height;

	$table = $all_vars->table;
	$field_info = $all_vars->field_info;

	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$database_name = $all_vars->table_structure->database_name;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	$db = $all_vars->table_structure->db;
	$structure_name = $all_vars->table_structure->structure_name;
	
	$c_name = $query_vars[ "dropdown_modify" ];
	
	#get information about columns 
	$column_info = get_field_info( 
		$database_name, 
		$table . $table_name_separator . $assets_name 
	);

	#start an array to hold any possible additional default columns for this subtable
	#first we'll get every column name from $all_vars
	$new_defaults = $all_vars->column_names;
	#now remove current column from list (can't make a default value column for current!)
	$new_defaults = array_remove_value( $new_defaults, $c_name );
	#remove any columns from list that point to subtables or should be unique
	foreach( $new_defaults as $key => $value ){
		if( 
			links_to_subtable( 
				$table . $table_name_separator . $tabledefs_name, 
				$value,
				$all_vars)
			||
			check_uniqueness(
				$all_vars->field_info[ $value . "-Key" ],
				$all_vars,
				$value,
				#pass a blank value here; we're not checking for a conflicting value
				"")
		){
			#dump_var( $key, $value );
			$new_defaults = array_remove_value( $new_defaults, $value );
		}
	}
	
	#make this contain a space, since no other column name may have a space in it
	#thus, this name won't conflict with any others
	$matrix_values_column = "reserved names";
	$matrix_new_column = "reserved new";
	$matrix_delete_column = "reserved delete";
	
	$defaults_matrix = array();

	#if we have delete permission, add a column for "delete default" checkboxes
	if( $delete_permission && $query_vars[ "subtable_delete_dropdown" ] ){
		$defaults_matrix[ $matrix_delete_column ] = array();
	}

	$defaults_matrix[ $matrix_values_column ] = array();
	
	$column_types = get_field_info( $database_name, $table . $table_name_separator . $c_name );
	#see if we have any default value to assign
	#note that a single subtable can have default values for multiple fields
	#will set this to 1 if we find defaults
	$contains_defaults = 0;
	foreach( $column_types as $field_and_type => $value_of_type ){
		if( preg_match( "/^(default-)(.*)-Type$/", $field_and_type, $matches ) ){
			$defaults_matrix[ $matches[ 2 ] ] = array();
			
			#so now we know we have a default value to assign
			#make an array: key is id of the subtable row, value is the default
			$subtable_defaults_query = 
				"\nSELECT\t`id`," .
				"\n\t`" . $matches[ 1 ] . $matches[ 2 ] . "`" . 
				"\n\tAS `default`" .
				"\nFROM `" . $table . $table_name_separator . $c_name . "`";
			$subtable_defaults_result = mysql_query( $subtable_defaults_query, $db );
			while( $defaults_row = mysql_fetch_array( $subtable_defaults_result ) ){
				$defaults_matrix[ $matches[ 2 ] ][ $defaults_row[ "id" ] ] = 
					$defaults_row[ "default" ];
			}
			
			#remove this value from the list of possible new defaults columns
			$new_defaults = array_remove_value( $new_defaults, $matches[ 2 ] );
			
			$contains_defaults = 1;
		}
	}
	
	#if we have add permission, add a blank column so we can add values to the end
	#only display this column if there is at least one possible new default column
	if( $add_permission && count( $new_defaults ) > 1 && $query_vars[ "subtable_add_default" ] ){
		$defaults_matrix[ $matrix_new_column ] = array();
	}

	$subtable_values_query =
		"\nSELECT `name`, `id` FROM `$table$table_name_separator$c_name` ORDER BY `name`";
	$subtable_values_result = mysql_query( $subtable_values_query, $db );
	while( $subtable_row = mysql_fetch_array( $subtable_values_result ) ){
		
		$defaults_matrix[ $matrix_values_column ][ $subtable_row[ "id" ] ] = 
			$subtable_row[ "name" ];
		
	}
	
	#we don't know how wide the table will need to be until we've looked at all columns
	#so hold the columns html in a variable and print it out after we know the total width
	$table_html = "";
	$table_width = 0;
	
	$is_odd = 0;
	$pixel_height = $all_vars->html_presets->pixel_height;
	if( $modify_permission || $add_permission ){
		$pixel_height += 5;
	}
	$double_height = $pixel_height * 2;

	#print column headers first line
	$table_html .= "<tr height=$double_height rowspan=2>\n";
	#do alternating row colors
	if( !$is_odd ){
		$bgcolor = $all_vars->html_presets->odd_row;
	} else {
		$bgcolor = $all_vars->html_presets->even_row;
	}

	foreach( $defaults_matrix as $column => $defaults ){
		#if it's the delete column, make it narrower
		if( $column == $matrix_delete_column ){
			$column_width = $all_vars->html_presets->pixel_width / 4;
		} else {
			$column_width = $all_vars->html_presets->pixel_width;
		}
		$table_width += $column_width;
		$table_html .= "<td width=\"$column_width\" $bgcolor>\n";

		if( $column == $matrix_values_column ){
			$table_html .= "<column_header>$c_name</column_header>\n";
			$table_html .= "<br>\n";
			if( $modify_permission && $query_vars[ "subtable_modify" ] ){
				$table_html .= "<column_notes>edit drop-downs:</column_notes>\n";
			} else {
				$table_html .= "<column_notes>drop-downs:</column_notes>\n";
			}
		} else if( $column == $matrix_new_column ){
			$table_html .= "<column_notes>Add default for:</column_notes>\n";
			#make an html select list with allowable new defaults columns
			$table_html .= "<br>\n";
			$table_html .= 
				"<select name=\"" . 
				$c_name . 
				$table_name_separator . 
				$all_vars->filter_query->structure_new_default . 
				"\">\n";
			$table_html .= "<option value=\"\">----Pick one----\n";
			foreach( $new_defaults as $key => $column_name ){
				$table_html .= "<option value=\"$column_name\">$column_name\n";
			}
			$table_html .= "</select>\n";
		} else if( $column == $matrix_delete_column ){
			$table_html .= "<column_notes>Delete\n";
			$table_html .= "<br>drop-\n";
			$table_html .= "<br>down:</column_notes>\n";
		} else {
			$table_html .= "<b>$column</b>\n";
			$table_html .= "<br>\n";
			if( $modify_permission && $query_vars[ "subtable_modify" ] ){
				$table_html .= "<column_notes>edit defaults:</column_notes>\n";
			} else {
				$table_html .= "<column_notes>defaults:</column_notes>\n";
			}
		}
		$table_html .= "</td>\n";
	}
	$table_html .= "</tr>\n";

	#"delete defaults column" line
	if( $delete_permission && $contains_defaults && $query_vars[ "subtable_delete_default" ] ){
		$table_html .= "<tr height=$pixel_height>\n";
		#do alternating row colors
		$is_odd = !$is_odd;
		if( !$is_odd ){
			$bgcolor = $all_vars->html_presets->odd_row;
		} else {
			$bgcolor = $all_vars->html_presets->even_row;
		}

		foreach( $defaults_matrix as $column => $defaults ){
			$table_html .= "<td $bgcolor>\n";
			
			if( $column == $matrix_values_column ){
				$table_html .= "&nbsp\n";
			} else if( $column == $matrix_new_column ){
				$table_html .= "&nbsp\n";
			} else if( $column == $matrix_delete_column ){
				$table_html .= "&nbsp\n";
			} else {
				$table_html .= 
					"<input type=checkbox name=\"" . 
					$c_name . 
					$table_name_separator . 
					$column .
					$table_name_separator . 
					$all_vars->filter_query->structure_delete_defaults .
					"\"><column_notes> Delete these defaults\n</column_notes>";
			}
			$table_html .= "</td>\n";
		}
		$table_html .= "</tr>\n";
		
		$calculated_column_widths = 1;
	}
	
	#print columns & rows
	$column_ids = $defaults_matrix[ $matrix_values_column ];
	foreach( $column_ids as $column_id => $ignored_val ){
		#if we have a table full of text input areas, increase height of table rows
		$table_html .= "<tr height=$pixel_height>\n";
		
		#do alternating row colors
		$is_odd = !$is_odd; #reverse $is_odd: non-zero becomes zero, zero becomes 1
		if( !$is_odd ){
			$bgcolor = $all_vars->html_presets->odd_row;
		} else {
			$bgcolor = $all_vars->html_presets->even_row;
		}

		foreach( $defaults_matrix as $column => $defaults ){
			$table_html .= "<td $bgcolor>\n";
			
			#if it's the column to add new defaults
			if( $column == $matrix_new_column ){
				$table_html .=  
					"<input type=text name=\"" . 
					$c_name . 
					$table_name_separator . 
					$all_vars->filter_query->structure_new_default_array . 
					"[" . 
					$column_id . 
					"]\">\n";
			
			#if it's the column to delete values
			} else if( $column == $matrix_delete_column ){
				$table_html .= 
					"<input type=checkbox name=\"" . 
					$c_name .
					$table_name_separator .
					$all_vars->filter_query->structure_delete_dropdown . 
					"[" .
					$column_id .
					"]\">\n";
			
			#otherwise it's the dropdown column or a column of existing defaults
			} else {
			
				#if we have permission to modify the subtable structure
				#show current values in a form "text" box
				if( $modify_permission && $query_vars[ "subtable_modify" ] ){
					if( $column == $matrix_values_column ){
						$table_html .=  
							"<input type=text name=\"" . 
							$c_name . 
							$table_name_separator . 
							$all_vars->filter_query->structure_current_dropdowns_array . 
							"[" .
							$column_id .
							"]\" value=\"" . 
							$defaults_matrix[ $column ][ $column_id ] .
							"\">\n";
					} else {
						$table_html .=  
							"<input type=text name=\"" . 
							$c_name . 
							$table_name_separator . 
							$column .
							$table_name_separator .
							$all_vars->filter_query->structure_current_defaults_array . 
							"[" .
							$column_id .
							"]\" value=\"" . 
							$defaults_matrix[ $column ][ $column_id ] .
							"\">\n";
					}
				
				#if no permission to modify the subtable structure
				#show current values (no text input box)
				} else {
					$table_html .= $defaults_matrix[ $column ][ $column_id ];
				}
			}
			
			$table_html .= "</td>\n";
		}
		$table_html .= "</tr>\n";
	}
	
	#print "add" lines
	if( $add_permission && $query_vars[ "subtable_add_dropdown" ] ){
		#text input area
		$table_html .= "<tr height=$double_height>\n";

		#do alternating row colors
		$is_odd = !$is_odd; #reverse $is_odd: non-zero becomes zero, zero becomes 1
		if( !$is_odd ){
			$bgcolor = $all_vars->html_presets->odd_row;
		} else {
			$bgcolor = $all_vars->html_presets->even_row;
		}

		foreach( $defaults_matrix as $column => $defaults ){
			$table_html .= "<td $bgcolor>\n";
			if( $column == $matrix_values_column ){
				$table_html .= "<column_notes>Add drop-down:</column_notes>";
				$table_html .= "<br>\n";
				$table_html .=  
					"<input type=text name=\"" . 
					$c_name . 
					$table_name_separator . 
					$all_vars->filter_query->structure_new_dropdown .
					"\">\n";
			} else if( $column == $matrix_new_column ){
				$table_html .= "&nbsp\n";
			} else if( $column == $matrix_delete_column ){
				$table_html .= "&nbsp\n";
			} else {
				#$table_html .= "new default here\n";
				$table_html .= "<column_notes><- and add default:\n</column_notes>";
				$table_html .= "<br>\n";
				$table_html .=  
					"<input type=text name=\"" . 
					$c_name . 
					$table_name_separator . 
					$column .
					$table_name_separator . 
					$all_vars->filter_query->structure_new_default .
					"\">\n";
			}
			$table_html .= "</td>\n";
		}
		$table_html .= "</tr>\n";
		
	}
	
	#now we can print out our table
	echo( "<table border=0 cellspacing=1 cellpadding=3 width=\"$table_width\">\n" );
	echo( $table_html );
	echo( "</table>\n" );
	echo( "<br> &nbsp\n" );
}

#############################################################################
#---display current structure and defaults of a table---#####################
#############################################################################
#TODO: document this!
#---receives: object containing all data
#---returns: nothing
#---globals: 
#---algorithm: 
function print_structure( $all_vars ){
	$database_name = $all_vars->table_structure->database_name;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$structure_name = $all_vars->table_structure->structure_name;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	
	$row_height = $all_vars->html_presets->row_height;
	
	$structure_page = $all_vars->pages[ "structure" ];
	$table = $all_vars->table;
		
	#from sql_functions.php
	$all_vars->field_info = get_field_info( 
		$database_name, 
		$table . $table_name_separator . $assets_name 
	);
	
	#initialize sundry variables
	$all_vars = initialize_vars( $all_vars );
	
	#get all column names from database
	#TODO: make this automatic; maybe as part of the constructor?
	$all_vars->column_names = calculate_column_names( $all_vars );
	
	$sql_permissions_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "add" ],
		$table . $table_name_separator . $assets_name . $table_name_separator . $structure_name
	);
	$add_permission = mysql_num_rows( $sql_permissions_result );

	$sql_permissions_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "delete" ],
		$table . $table_name_separator . $assets_name . $table_name_separator . $structure_name
	);
	$delete_permission = mysql_num_rows( $sql_permissions_result );

	$sql_permissions_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "modify" ],
		$table . $table_name_separator . $assets_name . $table_name_separator . $structure_name
	);
	$modify_permission = mysql_num_rows( $sql_permissions_result );
	
	#pull any queries from url into array $query_vars
	$query_vars = url_to_array( $all_vars->this_request );
	
	$show_modify_button = 
		( $add_permission || $delete_permission || $modify_permission ) &&
		isset( $query_vars[ "dropdown_modify" ] );

	if( $show_modify_button ){
		echo( '<form action="' . $all_vars->pages[ "structure_modify" ] . "\">\n" );
		echo( "<input type=hidden name=\"$assets_name\" value=\"$table\">\n" );
		echo( "<br><input type=\"Submit\" name=\"modify\" value=\"Modify\">\n" );
		echo( "<br>\n" );
	}
	
	#if "dropdown_modify" is set, show modify form for the specified drop-down list
	if( isset( $query_vars[ "dropdown_modify" ] ) ){
		echo( "<br>Editing table " . $query_vars[ "dropdown_modify" ] . "\n" );
		
		$valid_edit_request = 0;
		
		foreach( $all_vars->column_names as $c_number => $c_name ){
			
			#make sure the passed column name is actually a valid column
			if( $c_name == $query_vars[ "dropdown_modify" ] ){
				
				#if it's a valid column and links to a subtable, proceed with form print
				if( 
					links_to_subtable( 
						$table . $table_name_separator . $tabledefs_name, 
						$c_name,
						$all_vars
					) 
				){
					$valid_edit_request = 1;
				}

			}
		}
		
		if( $valid_edit_request ){
			
			#print GET url to return to main structure page, leaving dropdown untouched
			$return_url = 
				modify_url_vars(
					$all_vars->pages[ "structure" ],
					$assets_name,
					$table
				);
			echo( "<br> &nbsp\n" );
			echo( 
				"<br>click <a href=\"" . 
				$return_url . 
				"\">here</a>" . 
				" to return to the main structure page without making changes\n" 
			);
			echo( "<br> &nbsp\n" );
			
			#include an html hidden value so our processing url knows which column to modify
			echo( 
				"<input type=hidden name=\"modifying_dropdown\" value=\"" . 
				$query_vars[ "dropdown_modify" ] .
				"\">" 
			);
			
			#do our dropdown form
			drop_down( 
				$all_vars, 
				$query_vars, 
				$add_permission, 
				$delete_permission, 
				$modify_permission 
			);
			
		} else {
			echo( "<br> &nbsp\n" );
			error_message( $query_vars[ "dropdown_modify" ] . " is not a valid edit request" );
			echo( 
				"<br>Return to <a href=\"" . 
				$all_vars->pages[ "structure" ] . 
				"\">structure page</a>\n"
			);
			echo( "<br> &nbsp\n" );
		}
		
	#if it's not set, show all columns
	} else {

		open_40_60_table( $all_vars );
		
		foreach( $all_vars->column_names as $c_number => $c_name ){
		
			$is_a_subtable = display_data_types( 
				$all_vars, $c_name, $add_permission, $delete_permission, $modify_permission
			);
			
		}
		
		echo( "</table>\n" );
	}
	
	if( $show_modify_button ){
		echo( "<input type=hidden name=$assets_name value=$table>\n" );
		echo'<br><input type="Submit" name="modify" value="Modify">' . "\n";
		echo"<br>\n";
	
		echo'</form>' . "\n";
	}
}

##########
#driver
##########

$all_vars = new all;

#put _GET variables into $all_vars object
$all_vars = copy_env_vars_to_object( $all_vars );

print_page_header( $all_vars, "modify table structure" );

do_structure_selection( $all_vars );

print_page_footer( $all_vars );

?>
