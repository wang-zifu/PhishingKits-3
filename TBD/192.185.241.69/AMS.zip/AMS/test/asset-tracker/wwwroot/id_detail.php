<?php
##########
#display all fields from an id and allow user to change the field values
##########

require_once( "./functions/include_all.php" );

##########
#subroutines
##########

#############################################################################
#---displays page with id information ---####################################
#############################################################################
#---receives: object containing all variables
#---returns: nothing
#---globals: none
#---algorithm: this is mostly here to help break down the code
#main purpose is to act as the "driver"
function display_id( $all_vars ){
	$table = $all_vars->table;
	$modify_page = $all_vars->pages[ "modify" ];
	
	$database_name = $all_vars->table_structure->database_name;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	$db = $all_vars->table_structure->db;
	$sub_tables_key = $all_vars->table_structure->sub_tables_key;
	$id = $all_vars->id;
	
	$row_height = $all_vars->html_presets->row_height;
	
	if( isset( $table ) ){
		$sql_permissions_result = verify_acl( 
			$all_vars->connected_user, 
			$all_vars->table_structure->permissions[ "view" ],
			$table . $table_name_separator . $assets_name
		);
		
		if( mysql_num_rows( $sql_permissions_result ) > 0 ){
			
			#initialize sundry variables
			$all_vars = initialize_vars( $all_vars );
			
			#allow asset to be retrieved by any unique value, not just by id
			#we'll check for the first primary/unique value that was passed
			#if this is the id, no further processing is done
			#if it's a different column, get the id of that asset and put in $all_vars
			$query_vars = url_to_array( $all_vars->this_request );
			if( !isset( $query_vars[ $all_vars->table_structure->id ] ) ){
				foreach( $all_vars->column_names as $column_key => $column_name ){
					if( isset( $query_vars[ $column_name ] ) ){
						if( 
							check_uniqueness( 
								$all_vars->field_info[ $column_name . "-Key" ],
								$all_vars,
								$column_name,
								""
							) 
						){
							$equivalent_id_sql =
								"\nSELECT `" . 
								$all_vars->table_structure->id . 
								"` FROM `" .
								$table . 
								$table_name_separator .
								$assets_name .
								"` WHERE `" .
								$column_name .
								"`='" .
								$query_vars[ $column_name ] .
								"'";
							$equivalent_id_result = mysql_query( $equivalent_id_sql );
							$first_result = mysql_fetch_array( $equivalent_id_result );
							$all_vars->id = $first_result[ $all_vars->table_structure->id ];
							
							break;
						}
					}
				}
			}
			
			if ( $all_vars->id && id_exists( $all_vars ) ) {
				#get information from database about this id
				$sql_parts = 
					create_sql_SELECT_FROM_JOIN_strings( $all_vars, $all_vars->column_names );
				$result = mysql_query(
					$sql_parts[ "SELECT" ] . " " .
						$sql_parts[ "FROM" ] . " " .
						$sql_parts[ "JOIN" ] . " " .
						"\nWHERE `$table" . 
							"$table_name_separator" . 
							"$assets_name`.`id`='" .
							$all_vars->id .
							"'" .
						$sql_parts[ "GROUP_BY" ],
					$db
				);
				$myrow = mysql_fetch_array( $result );
				
				#check for modify permission to table
				$sql_permissions_result = verify_acl( 
					$all_vars->connected_user, 
					$all_vars->table_structure->permissions[ "modify" ],
					$all_vars->table . 
						$all_vars->table_structure->table_name_separator . 
						$all_vars->table_structure->assets_name
				);
				#set "$modify_allowed" to the number of rows of the permissions check
				#if permissions are allowed, $modify_allowed will be greater than 0
				$modify_allowed = mysql_num_rows( $sql_permissions_result );
				#if modify is not permitted, print message saying only view is allowed
				if( !$modify_allowed ){
					echo( "<br>Viewing record from " . $all_vars->table . "\n" );
				} else {
					echo( "<br>Modifying record from " . $all_vars->table . "\n" );
					echo"<br>\n";
					echo( "<br>Check the box next to the original value to make a change to that field.\n" );
				}
				echo( "<br>&nbsp\n" );
				
				if( $modify_allowed ){
					echo"<form action=\"$modify_page\">\n";
					echo'<br><input type="Submit" name="modify" value="Modify">' . "\n";
					echo"<br>\n";
					
					echo"<br><input type=hidden name=\"id\" value=\"$id\">\n";			
				}
				
				open_40_60_table( $all_vars );
				
				iterate_through_fields( $all_vars, $myrow, $modify_allowed );
			
				echo"</table>";
				
				if( $modify_allowed ){
					echo( "<input type=hidden name=$assets_name value=$table>\n" );
					echo'<br><input type="Submit" name="modify" value="Modify">' . "\n";
					echo'</form>' . "\n";
				}
				
				echo"<br>\n";

				#check for permission to delete entries from table
				$sql_permissions_result = verify_acl( 
					$all_vars->connected_user, 
					$all_vars->table_structure->permissions[ "delete" ],
					$table . $table_name_separator . $assets_name
				);

				#and show a delete button if we're allowed
				if( mysql_num_rows( $sql_permissions_result ) ){
					echo"<form action=\"$modify_page\">\n";
					echo"<br>\n";
					echo( "<input type=hidden name=\"id\" value=\"$id\">\n" );			
					echo( "<input type=hidden name=$assets_name value=$table>\n" );
					
					echo"<br><b>CAUTION</b> clicking the delete button will ";
					echo"<b>irrevocably</b> remove this record: ";
					
					echo"<input type=\"Submit\" name=\"delete\" value=\"Delete\">\n";
					echo"<br>\n";
					echo'</form>' . "\n";
				}
			
			} else {
				error_message( "No id selected, or the id is not valid" );
			}
		} else {
			error_message( "No permission to view $table or it is not a valid table" );
		}
	} else {
		error_message( "No table selected" );
	}
}

#############################################################################
#---display an edit field and what is expected to be entered ---#############
#############################################################################
#---receives: object containing all variables
#data in current record
#modify permission for current user
#---returns: nothing
#---globals: none
#---algorithm: 
function iterate_through_fields( $all_vars, $myrow, $modify_allowed ){
	$column_names = $all_vars->column_names;
	$field_info = $all_vars->field_info;

	$row_height = $all_vars->html_presets->row_height;
	$null_set_symbol = $all_vars->html_presets->null_set_symbol;
	
	foreach( $column_names as $c_number => $c_name ){
		
		$column_type = column_type( $all_vars, $c_name );
		#add current column name to hook_objects so plugins can see it
		$all_vars->hook_objects[ "current_column" ] = $c_name;	
		#add current values to hook_objects so plugins can see it
		$all_vars->hook_objects[ "current_values" ] = $myrow;	

		#print current value
		echo"<tr $row_height " . $all_vars->html_presets->odd_row . ">\n";
		echo"<td>\n";
		echo"<column_header>Current $c_name:</column_header>\n";
		echo"</td>\n";
		echo"<td>\n";
		
		#"ignore" checkbox
		#if left unchecked, any changes to this field will be ignored
		#TODO: fill in the submission area according to current value
		#then get rid of the "ignore" checkbox, etc
		if( $modify_allowed && in_array( $column_type, $all_vars->table_structure->column_types ) ){
			echo"<input type=\"checkbox\" name=\"" . $c_name . "-commit\"> ";
		}
		
		$all_vars = do_hook( $all_vars, "after_id_detail_ignore_checkbox" );
	
		$output = $myrow[ $c_name ];
		if( !isset( $output ) ){
			$output = $null_set_symbol;
		}
		echo "$output\n";
		echo"</td>\n";
		echo"</tr>\n";
		
		if( $modify_allowed && in_array( $column_type, $all_vars->table_structure->column_types ) ){
			#print line requesting to pick a new value
			pick_new_value_line( $all_vars, $c_name, $column_type );
		}
			
		$all_vars = do_hook( $all_vars, "after_id_detail_new_value" );
	
		#print any parameters/criteria the user should know about
		print_field_criteria( $all_vars, $column_type, $c_name );
			
		$all_vars = do_hook( $all_vars, "after_id_detail_print_field_criteria" );
	
		#if field can be null show a check box to set it to null
		if( $field_info[ $c_name . "-Null" ] ){
			echo"<tr $row_height>\n";
			if( $modify_allowed ){
				echo"<td>\n";
				echo"Or check this box to make $c_name blank: \n";
				echo"</td>\n";
				
				echo"<td>\n";
				echo"<input type=\"checkbox\" name=\"$c_name-Null\">\n";
				echo"</td>\n";
			} else {
				echo"<td colspan=2>\n";
				echo"&nbsp " . "&nbsp " . "&nbsp " . "<b>Can be null</b>";
				echo"</td>\n";				
			}
			echo"</tr>\n";
		}
		
		$all_vars = do_hook( $all_vars, "after_id_detail_null_checkbox" );
	
		#print a blank line
		echo"<tr $row_height>\n";
		echo"<td colspan=2>\n";
		echo"&nbsp\n";
		echo"</td>\n";
		echo"</tr>\n";
	}
}

#############################################################################
#---displays either a text box or html select list to assign a new value ---#
#############################################################################
#---receives: object containing all variables, current column
#---returns: 1 if we displayed a list of items from a subtable
#0 if we displayed a text box
#---globals: 
#---algorithm: 
function pick_new_value_line( $all_vars, $c_name, $column_type ){
	$table = $all_vars->table;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	$db = $all_vars->table_structure->db;
	
	echo"<tr $row_height>\n";
	echo"<td>\n";
	echo"New Value for $c_name:\n";
	echo"</td>\n";
	echo"<td>\n";
	
	if( $column_type == $all_vars->table_structure->column_types[ "dropdown" ] ){
		$subtable_values_query =
			"\nSELECT `name`, `id` FROM `$table$table_name_separator$c_name` ORDER BY `name`";
		$subtable_values_result = mysql_query( $subtable_values_query, $db );
		echo"<select name=\"$c_name\" default=\"\">\n";
		echo"<option value=\"\">--no update--\n";
		while( $subtable_row = mysql_fetch_array( $subtable_values_result ) ){
			echo"<option value=\"" . 
				$subtable_row[ "id" ] . 
				"\">" . 
				$subtable_row[ "name" ] .
				"\n";
		}
		echo"</select>\n";
	} else if( $column_type == $all_vars->table_structure->column_types[ "simple" ] ) {
		echo"<input type=\"Text\" name=\"$c_name\" value=\"\" size=\"" . 
			text_input_size( $all_vars->field_info[ $c_name . "-Type" ] ) . 
			"\">\n";
	}

	echo"</td>\n";
	echo"</tr>\n";
}

##########
#driver
##########

$all_vars = new all;

#put _GET variables into $all_vars object
$all_vars = copy_env_vars_to_object( $all_vars );

print_page_header( $all_vars, "asset detail view" );

display_id( $all_vars );

print_page_footer( $all_vars );

?>
