<?php
##########
#external rt link functionality for asset tracker
#shows an extra column in list view telling how many links to this id are in rt
##########

#############################################################################
#---check for plugins to load---#############################################
#############################################################################
#---receives: array of arrays to allow plugin to register itself with asset tracker system
#---returns: modified array of arrays, should be registered
#---globals: 
#---algorithm: 
function asset_tracker_init_rt_external_linked( $plugin_function_register ){
	$plugin_function_register[ "after_create_SELECT_FROM_JOIN_strings" ][ "rt_external_linked" ] =
		'rt_external_linked_modify_SELECT_JOIN';
	$plugin_function_register[ "after_id_detail_null_checkbox" ][ "rt_external_linked" ] =
		'rt_external_linked_show_rt_tickets';
	$plugin_function_register[ "in_add_after_print_field_criteria" ][ "rt_external_linked" ] =
		'rt_external_linked_print_add_notice';
	$plugin_function_register[ "in_structure_after_print_field_criteria" ][ "rt_external_linked" ] =
		'rt_external_linked_print_structure_notice';
	$plugin_function_register[ "after_validate_filter_checks" ][ "rt_external_linked" ] =
		'rt_external_linked_after_validate_filter_checks';
	return( $plugin_function_register );
}

#############################################################################
#---add object with variables for this plugin---#############################
#############################################################################
#---receives: array of variables for all plugins, so it can add itself into it
#---returns: modified array of variables
#---globals: 
#---algorithm: 
function asset_tracker_init_vars_rt_external_linked( $hook_info ){
	class rt_external_linked_vars{
		var $type_id;
		var $rt_url;
		var $ticket_path;
		
		function rt_external_linked_vars(){
			$this->type_id = 100;
			$this->rt_url = "http://rt.shcorp.com";
			$this->ticket_path = "/Ticket/Display.html?id=";
		}
	}
	
	$hook_info[ "rt_external_linked" ] = new rt_external_linked_vars;
	return( $hook_info );
}


#############################################################################
#---allow number of rt links to be filtered by "greater than", etc---########
#############################################################################
#---receives: object containing all variables
#---returns: modified object
#if this is an rt link filter criteria that should be allowed
#$all_vars->hook_objects[ "filter_logic_ok" ] will be set to 1
#---globals: 
#---algorithm: 
function rt_external_linked_after_validate_filter_checks( $all_vars ){
	$filter_index = $all_vars->hook_objects[ "index" ];
	$table_definitions = $all_vars->table_structure->table_definitions;
	$condition_filters = $all_vars->hook_objects[ "condition_filters" ];
	
	foreach( $table_definitions as $index => $table ){
		if( 
			$table[ "Type" ] == 
			$all_vars->hook_info[ "rt_external_linked" ]->type_id 
		){
			if( 
				$condition_filters[ $filter_index ] == 'less_than' ||
				$condition_filters[ $filter_index ] == 'greater_than' 
			){
				$all_vars->hook_objects[ "filter_logic_ok" ] = 1;
			}
		}
	}
	return( $all_vars );
}

#############################################################################
#---modifies select, join strings to add rt external link column---##########
#############################################################################
#---receives: 
#object containing all variables
#---returns: modified object (select and join strings are passed inside it)
#---globals: 
#---algorithm: 
function rt_external_linked_modify_SELECT_JOIN( $all_vars ){
	$table = $all_vars->table;
	
	#get link prefix and rt database name out of tabledefs information
	list( $rt_uri, $rt_database, $totals_column_name, $valid_rt_columns, $asset_tracker_link ) = 
		rt_external_linked_tabledefs_info( $all_vars );
	
	if( $valid_rt_columns ){
		#modify SELECT string
		$all_vars->hook_objects[ "SELECT_string" ] .= 
			"\tCOUNT(`" . 
			$rt_database .
			"`.`Links`.`LocalBase`)\n" . 
			"\t\tAS `" . 
			$totals_column_name .
			"`\n";
		
		#now modify JOIN STRING
		$asset_tracker_database = $all_vars->table_structure->database_name;
		$current_assets = 
			$table .
			$all_vars->table_structure->table_name_separator .
			$all_vars->table_structure->assets_name;
		$asset_tracker_id = $all_vars->table_structure->id;
		
		$all_vars->hook_objects[ "JOIN_string" ] .= 
			"LEFT JOIN `" .
			$rt_database . 
			"`.`Links` ON" .
			"\n\t`" . 
			$rt_database .
			"`.`Links`.`Target` =" .
			"\n\tCONCAT('" . 
			$rt_uri .
			"://'," .
			"\n\t\t`" . 
			$asset_tracker_database .
			"`.`" . 
			$current_assets .
			"`.`" . 
			$asset_tracker_link .
			"`)";
			
		#not appending in this case, can only have one "GROUP BY"
		$all_vars->hook_objects[ "GROUP_BY_string" ] =
			"\nGROUP BY `" . 
			$asset_tracker_database .
			"`.`" . 
			$current_assets .
			"`.`" . 
			$asset_tracker_id .
			"`\n";
		
	}
	
	return( $all_vars );
}

#############################################################################
#---print notice saying external links can't be set on add---################
#############################################################################
#---receives: 
#object containing all variables
#---returns: object (no changes made)
#---globals: 
#---algorithm: 
function rt_external_linked_print_add_notice( $all_vars ){
	$row_height = $all_vars->html_presets->row_height;
	$current_column = $all_vars->hook_objects[ "current_column" ];
	
	#get link prefix and rt database name out of tabledefs information
	list( $rt_uri, $rt_database, $totals_column_name, $valid_rt_columns, $asset_tracker_link ) = 
		rt_external_linked_tabledefs_info( $all_vars );
	
	if( 
		$valid_rt_columns && 
		( $totals_column_name == $current_column ) 
	){
		echo( "<tr $row_height>\n" );
		echo( "<td colspan=2>\n" );
		echo( 
			"<b>This number is automatically set by adding links to or removing links from " . 
			"the new asset in the <a href=\"" . 
			$all_vars->hook_info[ "rt_external_linked" ]->rt_url .
			"\">RT system</a></b>\n" 
		);
		echo( "</td>\n" );				
		echo( "</tr>\n" );
	}
	
	return( $all_vars );
}

#############################################################################
#---print notice saying this column points to external link on structure---##
#############################################################################
#---receives: 
#object containing all variables
#---returns: object (no changes made)
#---globals: 
#---algorithm: 
function rt_external_linked_print_structure_notice( $all_vars ){
	$row_height = $all_vars->html_presets->row_height;
	$current_column = $all_vars->hook_objects[ "current_column" ];
	
	#get link prefix and rt database name out of tabledefs information
	list( $rt_uri, $rt_database, $totals_column_name, $valid_rt_columns, $asset_tracker_link ) = 
		rt_external_linked_tabledefs_info( $all_vars );
	
	if( 
		$valid_rt_columns && 
		( $totals_column_name == $current_column ) 
	){
		echo( 
			"External link to <a href=\"" . 
			$all_vars->hook_info[ "rt_external_linked" ]->rt_url .
			"\">RT system</a>\n" 
		);
	}
	
	return( $all_vars );
}

#############################################################################
#---show rt tickets pointing to this asset in id detail view---##############
#############################################################################
#---receives: 
#object containing all variables
#---returns: object (no changes made)
#---globals: 
#---algorithm: 
function rt_external_linked_show_rt_tickets( $all_vars ){
	$row_height = $all_vars->html_presets->row_height;
	$current_column = $all_vars->hook_objects[ "current_column" ];
	
	#get link prefix and rt database name out of tabledefs information
	list( $rt_uri, $rt_database, $totals_column_name, $valid_rt_columns, $asset_tracker_link ) = 
		rt_external_linked_tabledefs_info( $all_vars );
	
	if( 
		$valid_rt_columns && 
		( $totals_column_name == $current_column ) 
	){
		echo( "<tr $row_height>\n" );
		echo( "<td colspan=2>\n" );
		echo( 
			"<b>This number can only be changed by adding links to or removing links from " . 
			"this asset in the <a href=\"" . 
			$all_vars->hook_info[ "rt_external_linked" ]->rt_url .
			"\">RT system</a></b>\n" 
		);
		echo( "</td>\n" );				
		echo( "</tr>\n" );
		
		$rt_query = 
			"\nSELECT `LocalBase` FROM `" . 
			$rt_database .
			"`.`Links` WHERE `Target`='" . 
			$rt_uri . 
			"://" .
			$all_vars->hook_objects[ "current_values" ][ $asset_tracker_link ] .
			"'";
		$rt_results = mysql_query( $rt_query, $all_vars->table_structure->db );
		if( mysql_num_rows( $rt_results ) ){
		
			echo( "<tr $row_height>\n" );
			echo( "<td>\n" );
			echo( "RT ticket id's linking to this asset:\n" );
			echo( "</td>\n" );
			echo( "<td>\n" );
			$rt_tickets = "";
			
			#print each id with a link to the rt system
			while ( $rt_row = mysql_fetch_array( $rt_results ) ){
				$rt_tickets .= 
					"<a href=\"" .
					$all_vars->hook_info[ "rt_external_linked" ]->rt_url .
					$all_vars->hook_info[ "rt_external_linked" ]->ticket_path .
					$rt_row[ "LocalBase" ] . 
					"\">" .
					$rt_row[ "LocalBase" ] . 
					"</a>, ";
			}
			$rt_tickets = rtrim( $rt_tickets, ", " );
			echo( $rt_tickets . "\n" );
			echo( "</td>\n" );
			echo( "</tr>\n" );
		}

	}
	
	return( $all_vars );
}

#############################################################################
#---look in tabledefs for this table, see if we're one of the columns---#####
#############################################################################
#---receives: 
#object containing all variables
#---returns: array
#0: the rt uri prefix for our linked tickets
#1: the name of the external rt database
#2: the name of the column
#3: whether to do this query: 0 for no, non-zero for yes
#4: the column name to link the rt ticket to
#---globals: 
#---algorithm: 
function rt_external_linked_tabledefs_info( $all_vars ){
	$table_definitions = $all_vars->table_structure->table_definitions;
	$uri_prefix = "";
	$rt_database = "";
	$name_of_column = "";
	$valid_query = 0;
	$local_link = "";
	
	#right now we can only handle one external RT link
	#TODO: handle multiple external RT links
	#look for tabledefs entry matching "rt_external_linked" type_id defined in our hook info
	foreach( $table_definitions as $key => $column_name ){
		if( 
			$column_name[ "Type" ] == 
			$all_vars->hook_info[ "rt_external_linked" ]->type_id
		){
			#get parameters
			$parameters = $column_name[ "Parameters" ];
			#first split the parameters field on newlines
			$params_array = split( "\n", $parameters );
			#then look for parameters with the values we need
			foreach( $params_array as $params_key => $params_value ){
				#remove whitespace from end of parameter values
				$params_value = rtrim( $params_value );
				if( preg_match( "/^link_prefix=(.+)$/", $params_value, $matches ) ){
					$uri_prefix = $matches[ 1 ];
				} else if( preg_match( "/^rt_database=(.+)$/", $params_value, $matches ) ){
					$rt_database = $matches[ 1 ];
				} else if( preg_match( "/^local_link=(.+)$/", $params_value, $matches ) ){
					$local_link = $matches[ 1 ];
				}
			}
			
			#assign column name
			$name_of_column = $column_name[ "Name" ];
			
			#if we have all necessary values, we can use this column
			if( $uri_prefix && $rt_database && $name_of_column && $local_link ){
				$valid_query++;
			}
			
			break;
		}
	}
	
	return(
		array(
			0 => $uri_prefix,
			1 => $rt_database,
			2 => $name_of_column,
			3 => $valid_query,
			4 => $local_link
		)
	);
}

?>
