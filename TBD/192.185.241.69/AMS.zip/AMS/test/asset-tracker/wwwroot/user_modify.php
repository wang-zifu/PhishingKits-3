<?php
##########
#update a user's information and/or permissions
##########

require_once( "./functions/include_all.php" );

##########
#variables to use throughout the script
##########

##########
#subroutines
##########

#############################################################################
#---delete a single acl ---##################################################
#############################################################################
#---receives: 
#object containing all variables
#name of table that acl will apply to
#name of acl to apply to the table
#---returns: variable with 1 if successful, 0 if not
#---globals: 
#---algorithm: 
function delete_one_acl( $all_vars, $value, $perm_value ){
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$permissions_table = $all_vars->table_structure->permissions_table;
	$db = $all_vars->table_structure->db;
	$id = $all_vars->id;

	$current_acl = $value . $table_name_separator . $perm_value;
	
	$made_changes = 0;
	
	#see if in the database so we don't try to remove a non-existent entry
	$user_permission_query_result =
		get_permission_for_user( $all_vars, $value, $perm_value );
	if( mysql_num_rows( $user_permission_query_result ) ){
		echo( "<br>\n" );
		echo( "<br>deleting $perm_value permission from table $value: " );
		
		$permissions_delete_query = 
			"\nDELETE FROM `$permissions_table`" . 
			"\nWHERE\t`user`='$id' AND" .
			"\n\t`table`='$value' AND" .
			"\n\t`permission`='$perm_value'";
		
		$delete_result = mysql_query( $permissions_delete_query, $db );
		if( isset( $delete_result ) ){
			echo( "succeeded\n" );
			$made_changes = 1;

		} else {
			echo( "failed\n" );
		}
	}
	
	return( $made_changes );
}

#############################################################################
#---delete a user from the database ---######################################
#############################################################################
#---receives: 
#object containing all variables
#array containing variables/arrays from query url
#array containing the information of the id/user being modified
#---returns: variable with 1 if changes were made, 0 if not
#---globals: 
#---algorithm: make sure we also delete the user's acl's
#so we don't leave orphaned acl's
function delete_user( $all_vars, $url_values, $user_array ){
	$permissions = $all_vars->table_structure->permissions;
	$all_vars = get_valid_acls( $all_vars );
	$acl_targets = $all_vars->acl_structure->acl_targets;
	
	$made_changes = 0;
	
	#delete all user's acl's
	echo( "<br>&nbsp\n" );
	echo( "<br>Deleting acl's\n" );
	
	foreach ( $acl_targets as $key => $value ){
		foreach( $permissions as $perm_key => $perm_value ){
			$acl_deleted = delete_one_acl( $all_vars, $value, $perm_value );
			if( $acl_deleted ){
				$made_changes = 1;
			}
		}
	}
	
	echo( "<br>&nbsp\n" );
	echo( "<br>Done deleting acl's\n" );
	
	#delete user
	echo( "<br>&nbsp\n" );
	echo( "<br>Deleting user: " );
	
	$user_delete_query = 
		"\nDELETE FROM `" . $all_vars->table_structure->users_table . "`" . 
		"\nWHERE `id`='" . $all_vars->id . "'";
	$user_delete_result = mysql_query( $user_delete_query, $all_vars->table_structure->db );
	if( $user_delete_result ){
		echo( "succeeded\n" );
		$made_changes = 1;
	} else {
		echo( "failed\n" );
	}
	
	return( $made_changes );
	
}

#############################################################################
#---make modifications to acl's for a user ---###############################
#############################################################################
#---receives: 
#object containing all variables
#array containing variables/arrays from query url
#---returns: variable with 1 if changes were made, 0 if not
#---globals: 
#---algorithm: 
function do_acl_changes( $all_vars, $url_values ){
	$users_table = $all_vars->table_structure->users_table;
	$permissions_table = $all_vars->table_structure->permissions_table;
	$db = $all_vars->table_structure->db;
	$permissions = $all_vars->table_structure->permissions;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$id = $all_vars->id;
	
	$all_vars = get_valid_acls( $all_vars );
	$acl_targets = $all_vars->acl_structure->acl_targets;
	
	$made_changes = 0;
	
	#go through each valid acl and check against the query url we were passed
	#if the acl matches an acl passed in the query, add it, otherwise delete it
	foreach ( $acl_targets as $key => $value ){
		foreach( $permissions as $perm_key => $perm_value ){
	
			$current_acl = $value . $table_name_separator . $perm_value;
			
			#if we got a "May-" + acl name for this acle, do changes
			#otherwise the acl simply wasn't enabled for this user
			if( array_key_exists( "May-" . $current_acl, $url_values ) ){
			
				#if we got received "on" value for this acl, add entry to the permissions table
				if( array_key_exists( $current_acl, $url_values ) ){
	
					#see if it's already in the database so we don't add duplicates
					$user_permission_query_result =
						get_permission_for_user( $all_vars, $value, $perm_value );
					if( !mysql_num_rows( $user_permission_query_result ) ){
						echo( "<br>\n" );
						echo( "<br>adding $perm_value permission to table $value: " );
	
						$permissions_insert_query = 
							"\nINSERT" . 
							"\nINTO `$permissions_table`(";
						
						$permissions_insert_query .= "\n\t`user`,";
						$permissions_insert_query .= "\n\t`table`,";
						$permissions_insert_query .= "\n\t`permission`";
						
						$permissions_insert_query .= 
							"\n)" .
							"\nVALUES (";
						
						$permissions_insert_query .= "\n\t'$id',";
						$permissions_insert_query .= "\n\t'$value',";
						$permissions_insert_query .= "\n\t'$perm_value'";
						
						$permissions_insert_query .= "\n)";
	
						$insert_result = mysql_query( $permissions_insert_query, $db );
						if( isset( $insert_result ) ){
							echo( "succeeded\n" );
							$made_changes = 1;
		
						} else {
							echo( "failed\n" );
						}
						
					}
				
				#if we didn't receive a value for this acl, remove permissions for this user
				} else {
	
					$acl_deleted = delete_one_acl( $all_vars, $value, $perm_value );
					if( $acl_deleted ){
						$made_changes = 1;
					}

				}
			}
		}
	}
	
	return( $made_changes );
}

#############################################################################
#---make modifications user information ---##################################
#############################################################################
#---receives: 
#object containing all variables
#array containing variables/arrays from query url
#array containing the information of the id/user being modified
#---returns: variable with 1 if changes were made, 0 if not
#---globals: 
#---algorithm: 
function do_user_changes( $all_vars, $url_values, $user_array ){
	$made_changes = 0;
	$requested_changes = 0;
	
	$info = array(
		"fname" => "users_first_name",
		"lname" => "users_last_name",
		"uid" => "users_uid"
	);
	
	$column_names = array(
		"fname" => "first_name",
		"lname" => "last_name",
		"uid" => "uid"
	);
	
	$update_sql = "\nUPDATE `" . $all_vars->table_structure->users_table . "`" .
		"\nSET";
	
	foreach( $info as $pass_name => $struc_name ){
		#if current value of the field is the same as the passed value, no change is made
		#so if it's not equal, we know to change it
		if( $url_values[ $pass_name ] != 
			$user_array[ $all_vars->table_structure->$struc_name ] )
		{
			$update_sql .= "\n\t`" . $column_names[ $pass_name ] . 
				"`='" . $url_values[ $pass_name ] . "',";
			$requested_changes = 1;
			
			echo( "<br>&nbsp\n" );
			echo( "<br>Updating " . $info[ $pass_name ] . " to " . 
				$url_values[ $pass_name ] . "\n" );
		}
	}
	
	#trim any trailing commas off of $update_sql
	$update_sql = rtrim( $update_sql, "," );
	
	$update_sql .= "\nWHERE `id`='" . $url_values[ "id" ] . "'";
	
	if( $requested_changes ){
		$update_results = mysql_query( $update_sql, $all_vars->table_structure->db );
		if( $update_results ){
			echo( "<br>&nbsp\n" );
			echo( "<br>User information update succeeded\n" );
			$made_changes = 1;
		} else {
			echo( "<br>&nbsp\n" );
			echo( "<br>User information update failed\n" );
		}
	}

	return( $made_changes );
}

#############################################################################
#---do setup/acl checks for modify/delete users and permissions ---##########
#############################################################################
#---receives: object containing all variables
#---returns: 
#---globals: 
#---algorithm: 
function user_modify( $all_vars ){
	$users_table = $all_vars->table_structure->users_table;
	$permissions_table = $all_vars->table_structure->permissions_table;
	$db = $all_vars->table_structure->db;
	$permissions = $all_vars->table_structure->permissions;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	
	#check if connected user is allowed to delete users
	$user_delete_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "delete" ],
		"users"
	);
	$user_delete_permission = mysql_num_rows( $user_delete_result );

	#get "modify" permission for "users"
	$user_modify_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "modify" ],
		"users"
	);
	$user_modify_permission = mysql_num_rows( $user_modify_result );

	#check if connected user is allowed to modify the acl system
	$permissions_modify_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "modify" ],
		"acl"
	);
	$permissions_modify_permission = mysql_num_rows( $permissions_modify_result );
	
	#if user is allowed to delete users, modify users, or modify acl's continue
	if( $user_delete_permission || $user_modify_permission || $permissions_modify_permission ){
			
		#get "view" permission for "users"
		$user_view_result = verify_acl( 
			$all_vars->connected_user, 
			$all_vars->table_structure->permissions[ "view" ],
			"users"
		);
		$user_view_permission = mysql_num_rows( $user_view_result );
	
		$id = $all_vars->id;
	
		$url_values = url_to_array( $all_vars->this_request );
		
		#process a change only if "update" is set
		if( array_key_exists( "update", $url_values ) ){
			
			$user_name_query =
				"\nSELECT *" .
				"\nFROM `$users_table`" .
				"\nWHERE `$users_table`.`id`='$id'";
			$user_name_result = mysql_query( $user_name_query, $db );
			
			#check if a user exists with this id before attempting to modify him/her
			if( mysql_num_rows( $user_name_result ) > 0 ){
				$user_row = mysql_fetch_array( $user_name_result );
				$user_name = $user_row[ "uid" ];
				
				$made_changes = 0;
				
				if( array_key_exists( "delete", $url_values ) ){
					if( $user_delete_permission ){
						echo( "<br>Deleting $user_name\n" );
						$deleted = delete_user( $all_vars, $url_values, $user_row );
						if( $deleted ){
							$made_changes = 1;
						}
					} else {
						echo( "<br>You have no permission to delete users\n" );
					}
				
				} else {
					echo( "<br>For user $user_name:\n" );
					
					if( $user_modify_permission ){
						$user_changes = do_user_changes( $all_vars, $url_values, $user_row );
						if( $user_changes ){
							$made_changes = 1;
						}
					} else {
						echo( "<br>You have no permission to modify users\n" );
					}
					
					if( $permissions_modify_permission ){
						$acl_changes = do_acl_changes( $all_vars, $url_values );
						if( $acl_changes ){
							$made_changes = 1;
						}
					} else {
						echo( "<br>You have no permission to modify user permissions\n" );
					}
				}
				
				if( !$made_changes ){
					echo( "<br>\n" );
					echo( "<br>No changes made\n" );
				}
	
			} else {
				echo( "No user in the user table with id $id\n" );
			}

			echo( "<br>&nbsp\n" );
		}
	} else {
		error_message( "You are not allowed to delete or modify users or permissions" );
	}
}

##########
#driver
##########

$all_vars = new all;

#put _GET variables into $all_vars object
$all_vars = copy_env_vars_to_object( $all_vars );

print_page_header( $all_vars, "update a user" );

user_modify( $all_vars );

print_page_footer( $all_vars );

?>
