<?php
##########
#display page to add entries to a database
##########

require_once( "./functions/include_all.php" );

##########
#subroutines
##########

#############################################################################
#---display form or list to enter new data for one field---##################
#############################################################################
#TODO: document this!
#---receives: object containing all data
#name of current column
#---returns: whether the current column pulls its name from a lookup table
#	returns 1 if yes, 0 if no
#---globals: 
#---algorithm: 
function display_data_entry_area( $all_vars, $c_name ){
	$row_height = $all_vars->html_presets->row_height;

	$table = $all_vars->table;
	$field_info = $all_vars->field_info;

	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$database_name = $all_vars->table_structure->database_name;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	$db = $all_vars->table_structure->db;
	
	#get type of current column
	$column_type = column_type( $all_vars, $c_name );
	#add current column name to hook_objects so plugins can see it
	$all_vars->hook_objects[ "current_column" ] = $c_name;	
	
	#use this value to name our javascript function for setting defaults in other fields
	$javascript_set_function = "SetFields";
	
	echo"<tr $row_height " . $all_vars->html_presets->odd_row . ">\n";
	echo"<td>\n";
	echo"<column_header>$c_name</column_header>\n";
	echo"</td>\n";
	echo"<td>\n";
	
	$contains_defaults_for_fields = array();
	
	#initialize a string to hold our javascript
	#will only print this code on the page if this field contains defaults for another field
	$javascript_code = "<script language =\"JavaScript\">\n";
	$javascript_code .= "<!-- hide me\n";
	
	#if we find any defaults this will be set to 1 so we know to print our javascript code
	$found_default = 0;
	#set a holder for any arrays of defaults to be put in the master javascript array
	$javascript_array_of_defaults = array();
	
	#check if the current column has a subtable to link its values to
	#if so, we will print an html select list
	if( $column_type == $all_vars->table_structure->column_types[ "dropdown" ] ){
		
		#see if we have any default value to assign
		#note that a single subtable can have default values for multiple fields
		$column_types = get_field_info( $database_name, $table . $table_name_separator . $c_name );
		foreach( $column_types as $field_and_type => $value_of_type ){
			if( preg_match( "/^(default-)(.*)-Type$/", $field_and_type, $matches ) ){
				array_push( $contains_defaults_for_fields, $matches[ 2 ] );
				
				#initialize a line to hold the javascript array containing our default values
				#its first value should be blank, since our first html select option is "Pick value:"
				$javascript_array_line = '["' . $matches[ 2 ] . '"] = new Array( "",';
				#so now we know we have a default value to assign
				#make an array: key is id of the subtable row, value is the default
				$subtable_defaults_query = 
					"\nSELECT\t`id`," .
					"\n\t`" . $matches[ 1 ] . $matches[ 2 ] . "`" . 
					"\n\tAS `default`" .
					"\nFROM `" . $table . $table_name_separator . $c_name . "`";
				$subtable_defaults_result = mysql_query( $subtable_defaults_query, $db );
				while( $defaults_row = mysql_fetch_array( $subtable_defaults_result ) ){
				
					$javascript_array_line .= 
						' "' . 
						$defaults_row[ "default" ] .
						'",';
					
					$found_default = 1;
				}
				#trim trailing comma
				$javascript_array_line = rtrim( $javascript_array_line, "," );
				$javascript_array_line .= " );\n";
				
				$javascript_array_of_defaults[ $matches[ 2 ] ] = $javascript_array_line;
			}
		}
		
		#create javascript action for html select list *if* we found defaults
		$select_javascript = "";
		if( $found_default ){
			$java_whole_function = sanitize_jscript_token(
				$table . 
				$table_name_separator . 
				$c_name . 
				$javascript_set_function
			);
			
			$select_javascript .=
				"\nonChange=" . 
					$java_whole_function . 
					"(" .
				"window." . 
				"document." . 
				$all_vars->current_form . "." .
				"$c_name." . 
				"options[selectedIndex]." . 
				"index);" 
			;
		}
		
		#create our html select list and then echo it to the page
		$subtable_values_query =
			"\nSELECT `name`, `id` FROM `$table$table_name_separator$c_name` ORDER BY `name`";
		$subtable_values_result = mysql_query( $subtable_values_query, $db );
		$html_select_string = "<select name=\"$c_name\"$select_javascript>\n" . 
			#automatically add an option with text "pick one:"
			"<option value=\"0\">----Pick one----\n";
		while( $subtable_row = mysql_fetch_array( $subtable_values_result ) ){
			$html_select_string .= "<option value=\"" . 
				$subtable_row[ "id" ] . 
				"\">" . 
				$subtable_row[ "name" ] .
				"\n";
			
		}
		$html_select_string .= "</select>\n";
		echo"$html_select_string";
		
		$is_a_subtable = 1;

	} else if( $column_type == $all_vars->table_structure->column_types[ "simple" ] ) {
		$default_value = "";
		
		#if this column may only have unique values and is an int
		#we'll assign a default value of the current maximum plus 1
		if( 
			check_uniqueness(
				$field_info[ $c_name . "-Key" ],
				$all_vars,
				$c_name,
				""
			)
		){
			if( ereg( "^int", $field_info[ $c_name . "-Type" ] ) ){
				$select_next_int_sql = 
					"\nSELECT MAX(`" . $c_name . "`)+1 AS `Next`" .
					"\nFROM `" . $table . $table_name_separator . $assets_name . "`";
				$select_next_int_result = mysql_query( $select_next_int_sql );
				$first_row = mysql_fetch_array( $select_next_int_result );
				$default_value = $first_row[ "Next" ];
				
				#handle special case where no values are in yet, so first needs to be "1"
				if( !$default_value ){
					$default_value = 1;
				}
			}
		}
		
		#TODO: also assign defaults for dates; maybe today?

		echo"<input type=\"Text\" name=\"$c_name\" value=\"$default_value\" size=\"" . 
			text_input_size( $field_info[ $c_name . "-Type" ] ) .
			"\">\n";
	}
	
	$all_vars = do_hook( $all_vars, "in_add_after_print_field_criteria" );

	echo"</td>\n";
	echo"</tr>\n";
	
	if( $found_default ){
		do_final_javascript( 
			$all_vars, 
			$javascript_code, 
			$c_name,
			$contains_defaults_for_fields,
			$javascript_array_of_defaults,
			$javascript_set_function
		);
	}
			
	return( $is_a_subtable );
}

#############################################################################
#---pick table to add to ---#################################################
#############################################################################
#TODO: document this!
#TODO: merge this and "do_list_selection" in list.php; they're almost identical
#---receives: object containing all data
#---returns: nothing
#---globals: 
#---algorithm: 
function do_add_selection( $all_vars ){
	$database_name = $all_vars->table_structure->database_name;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	
	$row_height = $all_vars->html_presets->row_height;
	
	$modify_page = $all_vars->pages[ "modify" ];
	$table = $all_vars->table;
	
	if( isset( $table ) ){
		$sql_permissions_result = verify_acl( 
			$all_vars->connected_user, 
			$all_vars->table_structure->permissions[ "add" ],
			$table . $table_name_separator . $assets_name
		);
		
		if( mysql_num_rows( $sql_permissions_result ) > 0 ){
			
			print_add_form( $all_vars );

		} else {
			error_message( "User " . $all_vars->connected_user . 
				" is not allowed to add to $table or it is not a valid table" );

			#display option for adding assets
			list( $number_of_tables, $widget_html, $permitted_tables ) =
				pick_table( $all_vars, "add", "add", 0 );

			#if only one table is permitted, show it instead of printing the "select" button
			if( $number_of_tables == 1 ){
				$all_vars->table = $permitted_tables[ 0 ];
				print_add_form( $all_vars );
			
			#otherwise, proceed normally with selection widget or "not allowed" message
			} else {
				echo( $widget_html );
			}
		}
	} else {

		#find out which tables the user has permissions in
		list( $number_of_tables, $widget_html, $permitted_tables ) = 
			pick_table( $all_vars, "add", "add", 0 );
			
		#if only one table is permitted, show it; don't print the "select" button
		if( $number_of_tables == 1 ){
			$all_vars->table = $permitted_tables[ 0 ];
			print_add_form( $all_vars );

		#if more than one table is permitted, show selection widget and "none selected" error
		} else if( $number_of_tables > 1 ) {
			error_message( "No asset list selected for adding" );
			echo( $widget_html );
		
		#otherwise, no tables are permitted, so just echo the error message
		} else {
			echo( $widget_html );
		}
	}
}

#############################################################################
#---echo javascript functions to page ---####################################
#############################################################################
#---receives: 
#object containing all data
#javascript code that has been generated so far
#current column name
#array containing names of all other columns we have defaults for
#array containing javascript arrays where all defaults are held
#the fragment of text that defines the final part of our javascript function
#---returns: nothing
#---globals: 
#---algorithm: 
function do_final_javascript( 
	$all_vars, 
	$javascript_code, 
	$c_name,
	$contains_defaults_for_fields,
	$javascript_array_of_defaults,
	$javascript_set_function
){
	$row_height = $all_vars->html_presets->row_height;
	$table = $all_vars->table;
	$table_name_separator = $all_vars->table_structure->table_name_separator;

	$javascript_code .= sanitize_jscript_token(
		#"var " . 
		$table . 
		$table_name_separator . 
		$c_name . " = " .
		"new Array();\n"
	);
	
	#create a string to hold the javascript function lines
	#will use this below to make the page set a default value
	#to every field listed in this string
	$javascript_function_lines = "";
	
	foreach( $contains_defaults_for_fields as $array_number => $default_name ){
		echo"<tr $row_height>\n";
		echo"<td colspan=2>\n";
		echo"&nbsp &nbsp &nbsp <b>note:</b> contains default values for " . 
			$default_name . "\n";
		echo"</td>\n";
		echo"</tr>\n";
		
		#add to master javascript array for this field name
		#key is the name of the modified field name ($default_name)
		#value is the array we generated above containing all the default values
		$javascript_code .= sanitize_jscript_token(
			$table . 
			$table_name_separator . 
			$c_name
		);
		$javascript_code .= $javascript_array_of_defaults[ $default_name ];
			
		$javascript_function_lines .= 
			"\nwindow." . 
			"document." . 
			$all_vars->current_form . "." . 
			$default_name . "." . 
			"value=" .
				sanitize_jscript_token( $table . $table_name_separator . $c_name ) .
				"[\"" . $default_name . "\"]" . 
				"[the_array_id]" .
			";";
	}
	
	#generate our javascript function to change values in other fields
	#TODO default values should also support checkboxes and select names?
	#right now they only support text values

	$java_whole_function = sanitize_jscript_token(
		$table . 
		$table_name_separator . 
		$c_name . 
		$javascript_set_function
	);
			
	$javascript_code .= 
		"\nfunction " . 
			$java_whole_function . 
			"( the_array_id )" .
		"\n{" . 
		$javascript_function_lines . 
		"\n}\n";

	$javascript_code .= "// show me -->\n";
	$javascript_code .= "</script>\n";
	echo( $javascript_code );
}

#############################################################################
#---display all fields with data entry areas and parameters---###############
#############################################################################
#TODO: document this!
#---receives: object containing all data
#---returns: nothing
#---globals: 
#---algorithm: 
function print_add_form( $all_vars ){
	$database_name = $all_vars->table_structure->database_name;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	
	$row_height = $all_vars->html_presets->row_height;
	
	$modify_page = $all_vars->pages[ "modify" ];
	$table = $all_vars->table;
		
	#from sql_functions.php
	$all_vars->field_info = get_field_info( 
		$database_name, 
		$table . $table_name_separator . $assets_name 
	);
	
	#initialize sundry variables
	$all_vars = initialize_vars( $all_vars );
	
	#get all column names from database
	#TODO: make this automatic; maybe as part of the constructor?
	$all_vars->column_names = calculate_column_names( $all_vars );
	
	#set a form name so we can refer to it with javascript
	$all_vars->current_form = "modify_form";
	
	echo( "<br>Adding assets to $table:\n" );
	echo( "<br>&nbsp\n" );
	
	echo'<form name="' . $all_vars->current_form . '" action="' . "$modify_page\">\n";
	echo'<br><input type="Submit" name="add" value="Add">' . "\n";
	echo"<br>\n";
	
	open_40_60_table( $all_vars );
	
	foreach( $all_vars->column_names as $c_number => $c_name ){
	
		$is_a_subtable = display_data_entry_area( $all_vars, $c_name );

		$column_type = column_type( $all_vars, $c_name );
		
		print_field_criteria( $all_vars, $column_type, $c_name );
	
		if( $all_vars->field_info[ $c_name . "-Null" ] ){
			echo"<tr $row_height>\n";
			echo"<td>\n";
			echo"Or check this box to leave $c_name with no value: \n";
			echo"</td>\n";
			
			echo"<td>\n";
			echo"<input type=\"checkbox\" name=\"$c_name-Null\" default=0>\n";
			echo"</td>\n";
			echo"</tr>\n";
		}
	
	
		echo"<tr $row_height>\n";
		echo"<td colspan=2>\n";
		echo"&nbsp\n";
		echo"</td>\n";
		echo"</tr>\n";
	}
	
	echo"</table>";
	echo( "<input type=hidden name=$assets_name value=$table>\n" );
	echo'<br><input type="Submit" name="add" value="Add">' . "\n";
	echo"<br>\n";
	
	echo'</form>' . "\n";
}

##########
#driver
##########

$all_vars = new all;

#put _GET variables into $all_vars object
$all_vars = copy_env_vars_to_object( $all_vars );

print_page_header( $all_vars, "add asset" );

do_add_selection( $all_vars );

print_page_footer( $all_vars );

?>
