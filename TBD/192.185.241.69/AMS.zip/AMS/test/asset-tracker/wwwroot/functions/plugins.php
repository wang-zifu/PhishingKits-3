<?php
##########
#functions to manage plugin functionality
##########

#############################################################################
#---check for plugins to load---#############################################
#############################################################################
#---receives: 
#object containing all variables
#string containing the name of the hook that was called
#variable to contain whatever object/string/array is appropriate for this hook
#---returns: altered hook object, presumably changed from the value it had when passed
#---globals: 
#---algorithm: 
function do_hook( $all_vars, $current_hook ){
	$current_hook_register = $all_vars->plugin_function_register[ $current_hook ];
	
	foreach( $current_hook_register as $plugin_name => $plugin_function ){
		$all_vars = $plugin_function( $all_vars );
	}
	
	return( $all_vars );
}

#############################################################################
#---include all plugin functions---##########################################
#############################################################################
#---receives: 
#array of names of active plugins
#directory to find plugins in
#array of hook names
#---returns: 
#---globals: 
#---algorithm: mostly copied from squirrelmail
function register_plugin_functions( $plugin_name_register, $plugins_directory, $hook_names ){
	$plugin_function_register = array();
	
	foreach( $hook_names as $key => $hook_name ){
		$plugin_function_register[ $hook_name ] = array();
	}
	
	foreach( $plugin_name_register as $key => $plugin_name ){
		if( file_exists( $plugins_directory . $plugin_name . "/setup.php" ) ){
			include_once( $plugins_directory . $plugin_name . "/setup.php" );
			$init_function = "asset_tracker_init_" . $plugin_name;
			if( function_exists( $init_function ) ){
				$plugin_function_register = $init_function( $plugin_function_register );
			}
		}
	}
	
	return( $plugin_function_register );
}

#############################################################################
#---include all plugin variables---##########################################
#############################################################################
#---receives: 
#array of names of active plugins
#directory to find plugins in
#array of hook names
#---returns: 
#---globals: 
#---algorithm: mostly copied from squirrelmail
function register_plugin_variables( $plugin_name_register, $plugins_directory, $hook_names ){
	$hook_info = array();
	
	foreach( $plugin_name_register as $key => $plugin_name ){
		if( file_exists( $plugins_directory . $plugin_name . "/setup.php" ) ){
			include_once( $plugins_directory . $plugin_name . "/setup.php" );
			$init_function = "asset_tracker_init_vars_" . $plugin_name;
			if( function_exists( $init_function ) ){
				$hook_info = $init_function( $hook_info );
			}
		}
	}
	
	return( $hook_info );
}

?>
