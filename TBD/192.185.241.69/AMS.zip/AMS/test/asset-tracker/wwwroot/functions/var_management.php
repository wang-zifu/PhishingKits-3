<?php
##########
#functions for managing and validating variables
##########

#############################################################################
#---remove a value from an array---##########################################
#############################################################################
#---receives: 
#array to remove value from
#value to remove from array
#---returns: array with value removed
#---globals: 
#---algorithm: create temporary array, iterate through passed array
#if element of passed array doesn't match value to be removed, add to temporary array
#return temporary array; NOTE: this will remove *all* of these values from the array
function array_remove_value( $the_array, $value_to_remove ){
	$temp = array();
	
	foreach( $the_array as $key => $value ){
		if( $value != $value_to_remove ){
			array_push( $temp, $value );
		}
	}
	
	return( $temp );
}

#############################################################################
#---find all column names for our current asset list---######################
#############################################################################
#---receives: name of table we will be getting the columns from
#---returns: the name of the columns
#---globals: 
#---algorithm: 
function calculate_column_names( $all_vars ){
	$column_names = array();
	
	$sql_query = 
		"\nSELECT `Name` FROM `" . 
		$all_vars->table . 
		$all_vars->table_structure->table_name_separator .
		$all_vars->table_structure->tabledefs_name .
		"` ORDER BY `" . 
		$all_vars->table_structure->id .
		"`";
	
	$sql_results = mysql_query( $sql_query );
	
	while( $row = mysql_fetch_row( $sql_results ) ){
		array_push( $column_names, $row[ 0 ] );
	}
	
	return( $column_names );
}

#############################################################################
#---populate an object's variables with the values PHP passed---#############
#############################################################################
#---receives: object to assign values to
#---returns: modified object
#---globals: 
#---algorithm: 
function copy_env_vars_to_object( $all_vars ){
	global $_GET;
	
	#name of the asset list to view
	if( isset( $_GET[ $all_vars->table_structure->assets_name ] ) ){
		$all_vars->table = $_GET[ $all_vars->table_structure->assets_name ];
	}
	
	#column to sort on
	if( isset( $_GET[ "column_sort" ] ) ){
		$all_vars->column_sort = $_GET[ "column_sort" ];
	}
	
	#order of sort
	if( isset( $_GET[ "order" ] ) ){
		$all_vars->order = $_GET[ "order" ];
	}
	
	#id of current record
	if( isset( $_GET[ "id" ] ) ){
		$all_vars->id = $_GET[ "id" ];
	}
	
	return( $all_vars );
}

#############################################################################
#---find out what type of column we are---###################################
#############################################################################
#---receives: 
#object containing all variables
#column name to look for
#---returns: the type of the column
#---globals: 
#---algorithm: 
function column_type( $all_vars, $column_name ){
	$current_index = -1;
	foreach( $all_vars->table_structure->table_definitions as $key => $value ){
		$current_index++;
		if( $all_vars->table_structure->table_definitions[ $key ][ "Name" ] == $column_name ){
			break;
		}
	}
	
	return( $all_vars->table_structure->table_definitions[ $current_index ][ "Type" ] );
}

#############################################################################
#---populate all object's variables---#######################################
#############################################################################
#---receives: object to assign values to
#---returns: modified object
#---globals: 
#---algorithm: 
#TODO: move as many other variable initialization calls into here (column names would be good)
function initialize_vars( $all_vars ){
	#put field information in $all_vars
	$all_vars->field_info = get_field_info( 
		$all_vars->table_structure->database_name, 
		$all_vars->table . 
			$all_vars->table_structure->table_name_separator . 
			$all_vars->table_structure->assets_name 
	);

	$all_vars = pull_table_definitions( $all_vars );
	
	#get all column names from database
	$all_vars->column_names = calculate_column_names( $all_vars );
	
	return( $all_vars );
}

#############################################################################
#---change a key/value pair in a url---######################################
#############################################################################
#---receives: 
#url to be examined/modified
#key whose value is to be modified
#new value of the key; if this is a blank space, key will be removed from query
#---returns: modified url
#---globals: none
#---algorithm: if there's a url such as http://somaddress?a=1&b=2&c=3
#this function modifies a user-specified value within it
#first occurence of key has its value replaced, the rest are removed
#NOTE: if you only pass the query string, make sure it starts with "?"
#otherwise php's parse_url function interprets the string as the path!
function modify_url_vars( $passed_url, $passed_key, $new_value ){
	$returned_url = "";
	
	$passed_url_array = parse_url( $passed_url );
	$passed_url_query = $passed_url_array[ "query" ];
	
	#make all variable names strings, including the array components
	if( $passed_url_query ){
		$exploded = explode( "&", $passed_url_query );
	} else {
		$exploded = array();
	}
	
	$temp_array = array();
	$key_already_in_array = 0;
	
	foreach( $exploded as $key => $value ){
		preg_match( "/^(.*?)=(.*)$/", $value, $matches );

		if( $matches[ 1 ] == $passed_key && !$key_already_in_array ){
			#if this is not 0, $new_value is not blank and we can assign new value
			if( strcmp( $new_value, " " ) != 0 ){
				$temp_array[ $key ] = $passed_key . "=" . $new_value;
			}
			
			$key_already_in_array = 1;
			
		} else {
			$temp_array[ $key ] = $matches[ 1 ] . "=" . $matches[ 2 ];
		}
	}
	
	#if we haven't found our passed key and our passed value isn't blank, add it
	if( !$key_already_in_array && strcmp( $new_value, " " ) != 0 ){
		array_push( $temp_array, $passed_key . "=" . $new_value );
	}
	
	$processed_url_query = implode( "&", $temp_array );

	#now regenerate our complete url
	$returned_url = $passed_url_array[ "scheme" ];
	if( $passed_url_array[ "scheme" ] ){
		$returned_url .= "//";
	}
	
	$returned_url .= $passed_url_array[ "user" ];
	if( $passed_url_array[ "pass" ] && $passed_url_array[ "user" ] ){
		$returned_url .= ":";
	}
	
	$returned_url .= $passed_url_array[ "pass" ];
	if( $passed_url_array[ "user" ] ){
		$returned_url .= "@";
	}

	$returned_url .= $passed_url_array[ "host" ];
	
	if( $passed_url_array[ "port" ] ){
		$returned_url .= ":";
	}
	$returned_url .= $passed_url_array[ "port" ];

	$returned_url .= $passed_url_array[ "path" ];
	
	if( $processed_url_query ){
		$returned_url .= "?";
	}
	$returned_url .= $processed_url_query;
	
	if( $passed_url_array[ "fragment" ] ){
		$returned_url .= "#";
	}
	$returned_url .= $passed_url_array[ "fragment" ];
		
	return( $returned_url );
}

#############################################################################
#---dump array to page; for testing purposes---##############################
#############################################################################
#---receives: 
#something to print so we see it even if the array is empty
#array to dump
#---returns: nada
#---globals: zero
#---algorithm: print contents
function dump_var( $test_validator, $test_variable ){
	echo( "<br>in dump_var: $test_validator\n" );
	if( is_array( $test_variable ) ){
		echo( "<br>is an array:\n" );
		foreach( $test_variable as $key => $val ){
			echo( "<br>$key $val\n" );
		}
	} else if( is_string( $test_variable ) ){
		echo( "<br>is a string: $test_variable\n" );
	} else if( is_integer( $test_variable ) ){
		echo( "<br>is an integer: $test_variable\n" );
	} else {
		echo( "<br>I don't know how to diplay this variable's values\n" );
	}
}

#############################################################################
#---generate html "hidden" lines from passed url---##########################
#############################################################################
#---receives: query to generate the hiddens from
#---returns: nothing
#---globals: none
#---algorithm: remove everything up to first question mark (TODO: is this right?)
#split on &; from resulting array entries regex match everything before and after =
#NOTE: php doesn't seem to like an array key whose name is made up of items with brackets
#so I can't return an array, I have to print it instead
function hidden_input_from_url( $url_query ){
	#split current url query up into key/value pairs so we can make a "hidden" 
	#input for each
	#can't use $query_vars, since it represents arrays in the query as "Array"
	preg_match( '/^.*?\?(.*)/', $url_query, $matches );
	$query_only = $matches[ 1 ];
	$query_entries_temp = split( '&', $query_only );
	$query_entries = array();
	foreach( $query_entries_temp as $key => $query ){
		preg_match( '/(.*)=(.*)/', $query, $matches );
		$new_key = $matches[ 1 ];
		$new_value = $matches[ 2 ];
		echo( "<input type=hidden name=\"$new_key\" value=\"$new_value\">\n" );
	}
	
}

#############################################################################
#---convert a request url to an array ---####################################
#############################################################################
#---receives: string containing url
#---returns: array containing variable names and values
#---globals:
#---algorithm: just use php's built in functions
function url_to_array( $url_query ){
	$passed_url_array = parse_url( $url_query );
	parse_str( $passed_url_array[ "query" ], $query_vars );
	
	return( $query_vars );
}

#############################################################################
#---ensure the sort variables we were passed are valid---####################
#############################################################################
#---receives: 
#names of the columns being displayed
#object containing all of our variables
#---returns: modified object containing all of our variables
#---globals: none
#---algorithm: look at the sort variables passed to this script in $order and $column_sort
#if $column_sort is set, we'll first put its original value in $all_vars->highlight
#$all_vars->highlight is needed later to compare the current column name against the 
#"to-sort" name
#then check if $column_sort is one of the column names; if not, it's set to blank
#if $order is set, check if it's either "asc" or "desc"; if not, it's set to blank
function validate_sort_type( $column_names, $all_vars ){

	$all_vars->highlight = $all_vars->column_sort;
	$order_by = array_search( $all_vars->column_sort, $column_names );
	if( isset( $all_vars->column_sort ) && isset( $order_by ) ){
		$all_vars->column_sort = 
			"ORDER BY `" . 
			$column_names[ $order_by ] . 
			"`";
	} else {
		$all_vars->column_sort = "";
		$all_vars->highlight = "";
	}

	if( 
		!isset( $order_by ) || 
		( 	
			isset( $all_vars->order ) && 
			$all_vars->order != "asc" && 
			$all_vars->order != "desc" 
		) 
	){
		$all_vars->order = "";
	}
	
	return( $all_vars );
}

?>