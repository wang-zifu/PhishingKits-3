<?php
##########
#functions that are used to manage display structures
##########

#############################################################################
#---print standardized error message---######################################
#############################################################################
#---receives: error message to print
#---returns: 
#---globals: 
#---algorithm: 
function error_message( $message ){
	echo( "<br><strong>Error:</strong> $message\n" );
	echo( "<br>\n" );
	echo( "<br>\n" );
}

#############################################################################
#---echo table html for a 40-60 left/right split table---####################
#############################################################################
#---receives: object containing all variables
#---returns: nothing
#---globals: none
#---algorithm: this sets up a 2-column table
#left column is approximately 40% page width; right is approximately 60% width
function open_40_60_table( $all_vars ){

	echo"<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" " . 
		$all_vars->html_presets->page_width .
		">\n";
					
	echo"<tr " . $all_vars->html_presets->row_height . ">\n";
	echo"<td width=\"350\">\n";
	echo"</td>\n";
	echo"<td width=\"450\">\n";
	echo"</td>\n";
	echo"</tr>\n";
	
}

#############################################################################
#---print standardized beginning of html page---#############################
#############################################################################
#---receives: 
#object containing all variables
#title of page to print
#---returns: 
#---globals: 
#---algorithm: 
function print_page_header( $all_vars, $title ){
	
	#we'll keep output buffered so we can set cookies
	#ob_start();

	echo( "<html>\n" );
	echo( "\n" );
	echo( "<head>\n" );
	echo( "\n" );
	echo( "<title>$title</title>\n" );
	echo( "\n" );

	echo( "<style type=\"text/css\">\n" );
	echo( "<!--\n" );
	echo( "strong\n" );
	echo( "{\n" );
	echo( "color:red;\n" );
	echo( "font-weight:900;\n" );
	echo( "}\n" );
	echo( ".end_page\n" );
	echo( "{\n" );
	echo( "font-size:10pt;\n" );
	echo( "}\n" );
	echo( "column_header\n" );
	echo( "{\n" );
	echo( "color:blue;\n" );
	echo( "font-weight:900;\n" );
	echo( "}\n" );
	echo( "column_notes\n" );
	echo( "{\n" );
	echo( "font-size:12;\n" );
	echo( "}\n" );
	echo( ".end_page\n" );
	echo( "{\n" );
	echo( "font-size:10pt;\n" );
	echo( "}\n" );
	echo( "-->\n" );
	echo( "</style>\n" );
	echo( "\n" );
	echo( "</head>\n" );
	echo( "\n" );
	echo( "<body>\n" );
	echo( "\n" );

	#TODO: add a standardized header section with navigator
	#navigator will allow quick add/list
	#also will display which table we are viewing
	#also will have "configuration" link to acl/table setup
	#also will have a section to display errors
	
	$pages = $all_vars->pages;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$structure_name = $all_vars->table_structure->structure_name;
	
	#get "view" permission for "users"
	$user_view_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "view" ],
		"users"
	);
	$user_view_permission = mysql_num_rows( $user_view_result );
	
	#and get "view" permission for the acl system
	$permissions_view_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "view" ],
		"acl"
	);
	$permissions_view_permission = mysql_num_rows( $permissions_view_result );
	
	#and get "add" permission for assets
	$assets_add_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "add" ],
		"%" . $table_name_separator . $assets_name
	);
	$assets_add_permission = mysql_num_rows( $assets_add_result );
	
	#and get "view" permission for assets
	$assets_view_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "view" ],
		"%" . $table_name_separator . $assets_name
	);
	$assets_view_permission = mysql_num_rows( $assets_view_result );
	
	#and get "view" permission for "structure" of any asset list
	$structure_view_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "view" ],
		"%" . $table_name_separator . $assets_name . $table_name_separator . $structure_name
	);
	$structure_view_permission = mysql_num_rows( $structure_view_result );
	
	#and get "view" permission for "structure" of whole system
	$system_structure_view_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "view" ],
		"structure"
	);
	$system_structure_view_permission = mysql_num_rows( $system_structure_view_result );
	
	$display_pages = array(
		"main" => $pages[ "main" ],
	);
	
	#if user has view permission on assets, show link to list page
	if ( $assets_view_permission ){
		$display_pages[ "list" ] = $pages[ "list" ];
	}
	
	#if user has add permission on assets, show link to add page
	if ( $assets_add_permission ){
		$display_pages[ "add" ] = $pages[ "add" ];
	}
	
	#if user has view permission on acl or users, show link to users
	if( $user_view_permission || $permissions_view_permission ){
		$display_pages[ "users" ] = $pages[ "users" ];
	}
	
	#if user has view permission on structure, show link to structure page
	if( $structure_view_permission ){
		$display_pages[ "structure" ] = $pages[ "structure" ];
	}
	
	#if user has view permission on system structure, show link to system structure page
	if( $system_structure_view_permission ){
		#disabling this for now, since we don't have this page yet
		#TODO: create this page and enable it
		#$display_pages[ "setup" ] = $pages[ "system_structure" ];
	}

	#echo( "\n" );
	#echo( "<div class=end_page>\n" );
	echo( 
		"<table " . 
		$all_vars->html_presets->odd_row . 
		" border=0 cellspacing=1 cellpadding=3 width=\"100%\">\n" 
	);
	echo( "<tr " . $all_vars->html_presets->row_height . ">\n" );
	echo( "<td width=\"50%\">\n" );
	
	$first_element = 1;
	foreach( $display_pages as $display_name => $page_name ){
		
		$page_plus_query = $page_name;
		if( isset( $all_vars->table ) ){
			$page_plus_query = modify_url_vars( 
				$page_plus_query,
				$all_vars->table_structure->assets_name,
				$all_vars->table
			);
		}
		
		if( $first_element ){
			$first_element = 0;
			echo( "go to page: " );
		} else {
			echo( " | " );
		}
		
		echo( "<b>" );
		if( ltrim( $all_vars->this_page, "/" ) != $page_name ){
			echo( "<a href=\"$page_plus_query\">$display_name</a>" );
		} else {
			echo( "$display_name" );
		}
		echo( "</b>" );
	}
	echo( "\n" );
	
	echo( "</td>\n" );
	echo( "<td width=\"50%\" align=right>\n" );
	echo( "logged in as: <b>" . $all_vars->connected_user . "</b>\n" );
	echo( "</td>\n" );
	echo( "</tr>\n" );
	
	echo( "</table>\n" );
	#echo( "\n" );
	#echo( "</div>\n" );
	echo( "<br>\n" );
}

#############################################################################
#---print standardized bottom of html page---################################
#############################################################################
#---receives: object containing all variables (so we can default to same table on other pages)
#---returns: 
#---globals: 
#---algorithm: 
function print_page_footer( $all_vars ){
	
	#phpinfo( INFO_VARIABLES );
	#phpinfo();
	#global $_SERVER;
	#echo( "<br>" . $_SERVER[ "REMOTE_USER" ] . "\n" );
	echo( "\n" );
	echo"</body>\n";
	echo( "\n" );
	echo"</html>\n";
	
	#now print all our output
	#ob_end_flush();

}

#############################################################################
#---return size of form's text box based on data type---#####################
#############################################################################
#---receives: string containing type
#---returns: string containing width of input text box
#---globals: none
#---algorithm: set size based on some arbitrary numbers
#match the type using regex
function text_input_size( $type ){
	#default size if no types are matched
	$size = "55";
	
	#all ints have their input text area set to 20; dates to 30
	if( ereg( "^int", $type ) ){
		$size = "15";
	} else if( ereg( "^date", $type ) ){
		$size = "20";
	} else if( ereg( "^smallint", $type ) ){
		$size = "5";
	}
	
	return( $size );
}

?>
