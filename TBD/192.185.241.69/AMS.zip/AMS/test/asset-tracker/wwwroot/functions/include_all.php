<?php
##########
#call this to include all .php files in the functions directory
##########

#object information stored here, plus some obsolete globals which will eventually be deleted
require_once( "./functions/variables.php" );

#functions which do mostly sql queries go here
require_once( "./functions/sql.php" );

#functions which show standardized parts of a page go here (like header & footer templates)
#this may need to be folded into widget
require_once( "./functions/display.php" );

#pieces of the application with display code and logic
require_once( "./functions/widget.php" );

#logic only, such as testing variables, etc
require_once( "./functions/var_management.php" );

#javascript functions
require_once( "./functions/javascript.php" );

#plugin functions
require_once( "./functions/plugins.php" );

?>
