<?php
##########
#functions related to javascript
##########

#############################################################################
#---remove bad javascript characters ---#####################################
#############################################################################
#---receives: a javascript token such as a function name or variable name
#---returns: the name with characters removed that javascript doesn't like (like '-')
#---globals: none
#---algorithm: use strtr with translation array
function sanitize_jscript_token( $the_token ){

	$javascript_translate = array( "-" => "" );
	$translated_token = strtr( $the_token, $javascript_translate );

	return( $translated_token );	
}

?>