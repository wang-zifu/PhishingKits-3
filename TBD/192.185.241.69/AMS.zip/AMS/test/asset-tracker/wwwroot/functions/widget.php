<?php
##########
#the various controls, selection areas, etc that are common to the whole site
##########

#############################################################################
#---allow user to add new parameters/filters ---#############################
#############################################################################
#---receives: 
#object containing all variables
#cleaned/verified url query
#---returns: nothing
#---globals: none
#---algorithm: ?
function add_parameters( $all_vars, $url_query ){
	$filter_url_name = $all_vars->filter_query->filter_url_name;
	$filter_is_isnt_name = $all_vars->filter_query->filter_is_isnt_name;
	$filter_condition_name = $all_vars->filter_query->filter_condition_name;
	$filter_text_name = $all_vars->filter_query->filter_text_name;
	$filter_and_or_name = $all_vars->filter_query->filter_and_or_name;
	
	echo( "<form name=\"add_criteria\" action=\"" . $all_vars->pages[ "list" ] . "\">\n" );
	echo( "<br>\n" );
	echo( "<input type=submit value=\"Add filter:\">\n" );
	echo( "<br>\n" );
	
	#generate "hidden" entries to maintain our current query
	hidden_input_from_url( $url_query );
		
	#get current filter sequence number and add one to it
	$url_vars = url_to_array( $url_query );
	if( 
		array_key_exists( $filter_url_name, $url_vars ) && 
		is_array( $url_vars[ $filter_url_name ] ) 
	){
		$index = count( $url_vars[ $filter_url_name ] );
		echo( "<br><input type=radio name=\"$filter_and_or_name" . 
			"[$index]\" value = \"and\" checked>and &nbsp &nbsp &nbsp &nbsp &nbsp\n" );
		echo( "<input type=radio name=\"$filter_and_or_name" . 
			"[$index]\" value = \"or\">or\n" );
		echo( "<br>\n" );
	} else {
		$index = 0;
	}
	
	#show list of columns that can be filtered on
	echo( "<br><select name=\"$filter_url_name" . "[$index]\"\n" );
	foreach( $all_vars->column_names as $key => $c_name ){
		echo( "<option value=\"$c_name\">$c_name\n" );
	}
	echo( "</select>\n" );
	
	#show "is" and "is not" radio buttons
	echo( "<br>\n" );
	echo( "<br>\n" );
	echo( "<input type=radio name=\"$filter_is_isnt_name" . 
		"[$index]\" value=\"does\" checked>is/does &nbsp &nbsp\n" );
	echo( "<input type=radio name=\"$filter_is_isnt_name" . 
		"[$index]\" value=\"does_not\">is not/does not\n" );
	
	#show condition html select list ("greater than", "contains", "equal to", etc)
	echo( "<br>\n" );
	echo( "<br><select name=\"$filter_condition_name" . "[$index]\">\n" );
	echo( "<option value=\"equal_to\">equal to\n" );
	echo( "<option value=\"null\">null\n" );
	echo( "<option>\n" );
	echo( "<option>can only apply to numbers:\n" );
	echo( "<option value=\"less_than\">less than\n" );
	echo( "<option value=\"greater_than\">greater than\n" );
	echo( "<option>\n" );
	echo( "<option>can only apply to dates:\n" );
	echo( "<option value=\"before\">before\n" );
	echo( "<option value=\"after\">after\n" );
	echo( "<option>\n" );
	echo( "<option>can only apply to text/drop-downs:\n" );
	echo( "<option value=\"start_with\">start with\n" );
	echo( "<option value=\"contain\">contain\n" );
	echo( "<option value=\"end_with\">end with\n" );
	echo( "</select>\n" );
	
	echo( "<br>\n" );
	echo( "<br><input type=text name=\"$filter_text_name" . "[$index]\" size=30>\n" );
	echo( "</form>\n" );
	
}

#############################################################################
#---show current parameters, allow user to delete each of them ---###########
#############################################################################
#---receives: 
#object containing all variables
#cleaned/verified url query
#---returns: nothing
#---globals: none
#---algorithm: show current parameters with checkboxes and a button
function current_parameters( $all_vars, $url_query ){
	$filter_url_name = $all_vars->filter_query->filter_url_name;
	$filter_is_isnt_name = $all_vars->filter_query->filter_is_isnt_name;
	$filter_condition_name = $all_vars->filter_query->filter_condition_name;
	$filter_text_name = $all_vars->filter_query->filter_text_name;
	$filter_and_or_name = $all_vars->filter_query->filter_and_or_name;
	
	$filters = array( 
		$filter_url_name, 
		$filter_is_isnt_name, 
		$filter_condition_name,
		$filter_text_name,
		$filter_and_or_name
	);

	$query_vars = url_to_array( $url_query );
	
	#we will only add valid filters to this array, invalid will be excluded
	$valid_filters = array();
	
	#so now get all valid filters
	#make sure we have a filter array in our query url
	if( 
		array_key_exists( $filter_url_name, $query_vars ) && 
		is_array( $query_vars[ $filter_url_name ] ) 
	){
		$url_filters = $query_vars[ $filter_url_name ];
		$is_isnt_filters = $query_vars[ $filter_is_isnt_name ];
		$condition_filters = $query_vars[ $filter_condition_name ];
		$text_filters = $query_vars[ $filter_text_name ];
		$and_or_filters = $query_vars[ $filter_and_or_name ];
		
		#first filter does not contain 'and/or' rule, so this variable will keep track
		#of whether we are in the first filter or not
		#TODO: remove this; we already know the filters are valid at this point
		foreach( $url_filters as $index => $filter ){
			array_push( $valid_filters, $index );
		}
	
	#TODO: otherwise, purge all filters
	}
	
	#if we have any query variables, show them with delete button
	if( count( $valid_filters ) ){
		echo( "<form action=\"" . $all_vars->pages[ "list" ] . "\">\n" );
		echo( "<br>\n" );
		
		#generate "hidden" entries to maintain our current query
		hidden_input_from_url( $url_query );
		
		echo( "<input type=submit value=\"Remove selected filters:\">\n" );
		echo( "<br>\n" );
		
		#give checkboxes for each applied filter so user can delete them
		foreach( $valid_filters as $index => $value ){
			echo( "<br><input type=checkbox name=\"remove_filter" . "[$index]\">\n" );
			if( $query_vars[ $filter_and_or_name ][ $index ] ){
				echo( $query_vars[ $filter_and_or_name ][ $index ] . " " );
			}
			echo( $query_vars[ $filter_url_name ][ $index ] . " " );
			if( $query_vars[ $filter_is_isnt_name ][ $index ] != 'does' ){
				echo( "not\n" );
			}
			echo( "<br>&nbsp &nbsp &nbsp &nbsp " . 
				$query_vars[ $filter_condition_name ][ $index ] . " " );
			echo( "'" . $query_vars[ $filter_text_name ][ $index ] . "'\n" );
			echo( "<br>&nbsp\n" );
		}
		
		#show "delete all" button if we have a bunch of filters/queries
		if( count( $valid_filters ) > 5 ){
			echo( "<br><input type=submit name=\"remove_all_filters\" value=\"Remove all filters\">\n" );
			echo( "<br>&nbsp\n" );
		}
		
		echo( "</form>\n" );
	
	#otherwise print "no query" message
	} else {
		echo( "<br>No filters applied\n" );
	}
}

#############################################################################
#---display list of checkboxes to select/deselect columns for viewing ---####
#############################################################################
#---receives: object containing all variables
#---returns: 
#---globals: 
#---algorithm: 
function display_column_selector( $all_vars, $new_query ){
	
	#remove all "column" values from the url query string
	$passed_url_array = parse_url( $new_query );
	parse_str( $passed_url_array[ "query" ], $query_vars );
	$temp_array = array();
	if( array_key_exists( "column", $query_vars ) ){
		$temp_array = $query_vars[ "column" ];
	}
	
	#remove columns from url so we can add them as necessary with the checkboxes below
	foreach( $temp_array as $c_name => $c_value ){
			$new_query = modify_url_vars( $new_query, "column[$c_name]", " " );
	}
	$remaining_columns = array();
	foreach( $all_vars->column_names as $c_name => $c_value ){
		if( !in_array( "$c_value", $temp_array ) ){
			array_push( $remaining_columns, $c_value );
		}
	}
	
	if( array_key_exists( $all_vars->table_structure->assets_name, $query_vars ) ){
		echo( "<form action=\"" . $all_vars->this_page . "\">\n" );
		echo( "<br><input type=submit value=\"Show these columns:\">\n" );
		
		#generate "hidden" entries to maintain our current query
		hidden_input_from_url( $new_query );
		
		#echo( "<input type=hidden name=\"" . $all_vars->table_structure->assets_name . "\" " . 
		#	"value=\"" . $query_vars[ $all_vars->table_structure->assets_name ] . "\">\n" );	

		$current_position = 0;

		#now echo a checkbox for every currently-displayed column with default value checked
		foreach( $temp_array as $c_name => $c_value ){
			#only show a checkbox if the column name actually exists
			if( in_array( "$c_value", $all_vars->column_names ) ){
				echo( "<br><input type=checkbox name=column[" . $current_position . "] " . 
					"value=\"$c_value\" checked>" .  "$c_value\n" );
			}
			$current_position++;
		}

		#now echo a checkbox for every column not displayed with default value unchecked
		foreach( $remaining_columns as $c_name => $c_value ){
			echo( "<br><input type=checkbox name=column[" . $current_position . "] " . 
				"value=\"$c_value\">" .  "$c_value\n" );
			$current_position++;
		}
		echo( "<br>\n" );
		echo( "</form>\n" );
	}
}

#############################################################################
#---display widget to modify a query/display ---#############################
#############################################################################
#---receives: object containing all variables
#---returns: 
#---globals: 
#---algorithm: 
function display_query_editor( $all_vars, $url_query ){
	$bgcolor = $all_vars->html_presets->odd_row;
	
	#TODO: replace this with a template
	echo( "<br>\n" );
	echo( "<table border=0 cellspacing=1 cellpadding=3 width=\"100%\">\n" );
	echo( "<tr>\n" );

	echo( "<td width=\"32%\" valign=top align=center $bgcolor>\n" );
	echo( "<table border=0 cellspacing=0 cellpadding=0>\n" );
	echo( "<tr>\n" );
	echo( "<td>\n" );
	#show current parameters plus modifier
	current_parameters( $all_vars, $url_query );
	echo( "</td>\n" );
	echo( "</tr>\n" );
	echo( "</table>\n" );
	echo( "</td>\n" );

	echo( "<td width=\"32%\" valign=top align=center $bgcolor>\n" );
	echo( "<table border=0 cellspacing=0 cellpadding=0>\n" );
	echo( "<tr>\n" );
	echo( "<td>\n" );
	#add parameters/filters
	add_parameters( $all_vars, $url_query );
	echo( "</td>\n" );
	echo( "</tr>\n" );
	echo( "</table>\n" );
	echo( "</td>\n" );

	echo( "<td width=\"32%\" valign=top align=center $bgcolor>\n" );
	echo( "<table border=0 cellspacing=0 cellpadding=0>\n" );
	echo( "<tr>\n" );
	echo( "<td>\n" );
	#show our column selector
	display_column_selector( $all_vars, $url_query );
	echo( "<br>&nbsp\n" );
	echo( "</td>\n" );
	echo( "</tr>\n" );
	echo( "</table>\n" );
	echo( "</td>\n" );

	echo( "</tr>\n" );
	echo( "</table>\n" );
}

#############################################################################
#---pick a table to display data from ---####################################
#############################################################################
#---receives: 
#object containing all variables
#permission that will be checked to determine what tables user has access to
#	this has to be one of the types in $all_vars->pages
#page to take the user to if they submit the form
#whether to print the message in this function: 1 for yes, 0 for no
#---returns: 
#array:
#	1: is number of tables user was permitted to access
#	2: is the complete html code of the widget 
#		this is returned regardless of whether or not the widget was echoed
#	3: array containing the names of the permitted tables
#---globals: 
#---algorithm: 
function pick_table( $all_vars, $the_permission, $the_page, $should_print ){
	$permissions = $all_vars->table_structure->permissions;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	
	$connected_user = $all_vars->connected_user;
	$this_page = $all_vars->pages[ $the_page ];
	
	list( $number_matches, $html_fragment, $permitted_tables ) = 
		derive_html_fragment_from_permission( $all_vars, $the_permission, "", $the_page );
	
	$widget_html = "";
	
	$form_button_text = "$the_permission assets";
	#if we're showing the structure list selector, make a custom form button string
	if( $the_page == "structure" ){
		$form_button_text = "modify assets structure";
	}
	
	#if user is permitted in more than one list, show a drop down list to pick one
	if( $number_matches > 1 ){
		$widget_html = "<form action=\"" . $this_page . "\">\n";
		$widget_html .= "<br><input type=\"submit\" value=\"" . $form_button_text . "\">\n";
		$widget_html .= "<select name=\"" . $assets_name . "\">\n";
		
		#html_fragment is gotten from the "derive_tables_from_permission" function
		#contains each line that will be displayed as part of the html select
		$widget_html .= $html_fragment;
		
		$widget_html .= "</select>\n";
		$widget_html .= "</form>";
		
	#if user is permitted in only one list, show a button with that list's name
	} else if( $number_matches == 1 ){
		$widget_html = "<form action=\"" . $this_page . "\">\n";
		
		$widget_html .= $html_fragment;
		
		$widget_html .= "</form>";
	
	#if user is not permitted in any lists, print an error message	
	} else {
		$widget_html = "<br>No \"$form_button_text\" permission allowed\n";
		$widget_html .= "<br> &nbsp\n";
	}
	
	if( $should_print ){
		echo( $widget_html );
	}
	
	return( array( $number_matches, $widget_html, $permitted_tables ) );
}

#############################################################################
#---displays parameters about the current field ---##########################
#############################################################################
#---receives: object containing all variables
#type of column
#current field
#---returns: nothing
#---globals: none
#---algorithm: find out what kind of data the field holds
#	if it holds integers, say we need an integer
#	if a date, say we hold a date
#also check if field is supposed to be unique
function print_field_criteria( $all_vars, $column_type, $c_name ){
	$row_height = $all_vars->html_presets->row_height;
	$table = $all_vars->table;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	
	if( $column_type == $all_vars->table_structure->column_types[ "simple" ] ){
		$notes = "";
		if( ereg( "^int", $all_vars->field_info[ $c_name . "-Type" ] ) ){
			$notes = "&nbsp " . "&nbsp " . "&nbsp " . "<b>must be a number</b>"; 
		} else if( ereg( "^date", $all_vars->field_info[ $c_name . "-Type" ] ) ){
			$notes = "&nbsp " . "&nbsp " . "&nbsp " . "<b>must be a date</b>; " . 
				"suggested format is yyyy-mm-dd";
		}
		#$notes .= "<br>" . $column_type;
		#$notes .= "<br>" . $all_vars->field_info[ $c_name . "-Type" ];
		
		if( $notes ){
			echo"<tr $row_height>\n";
			echo"<td colspan=2>\n";
			echo"$notes\n";
			echo"</td>\n";
			echo"</tr>\n";
		}
	}
	
	if( 
		check_uniqueness(
			$all_vars->field_info[ $c_name . "-Key" ],
			$all_vars,
			$c_name,
			#pass a blank value here; we're not checking for a conflicting value
			""
		)
	){
		echo"<tr $row_height>\n";
		echo"<td colspan=2>\n";
		echo"&nbsp; " . "&nbsp; " . "&nbsp; " . "<b>must be unique</b>; " . 
			"may not share a value with any other record\n";
		echo"</td>\n";
		echo"</tr>\n";
	}
	
}

?>
