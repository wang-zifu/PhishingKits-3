<?php
##########
#a collection of common sql-related functions
##########

#############################################################################
#---check if a value is supposed to be unique and if so whether it is---#####
#############################################################################
#---receives: 
#$key_column_value: value in "Key" column from SHOW FIELDS ("UNI" if must be unique)
#$all_vars: object containing all values
#$column_name: check for uniqueness of the value in this column
#$unique_value: value in the variable will be check for uniqueness in $table.$column_name
#---returns: 0 if this particular value doesn't need to be unique
#1 if this value should be unique and is
#2 if this value should be unique but is not
#---globals: none referenced or modified
#---algorithm: look for "UNI" in the column's value; if we find it the values should be unique
#if this is the case, look for other values in the current column with the same value
#$return_value of 2 is transitive: it automatically means $return_value was first 1
#so we can use this function to check whether uniqueness is needed as well as checking
#for actual uniqueness
#TODO: first parameter is redundant? remove it?
function check_uniqueness( $key_column_value, $all_vars, $column_name, $column_value ){
	$table = 
		$all_vars->table . 
		$all_vars->table_structure->table_name_separator . 
		$all_vars->table_structure->assets_name;
	$return_value = 0;
	
	#dump_var( "1", $key_column_value );
	#dump_var( "2", $table );
	#dump_var( "3", $column_name );
	#echo( "<br>\n" );
	
	if( preg_match( "/^(UNI|PRI)/", $key_column_value ) ){
		$return_value = 1;
		
		$check_uniqueness_sql =
			"\nSELECT `" . 
			$all_vars->table_structure->id . 
			"` FROM `" .
			$table . 
			"` WHERE `" .
			$column_name .
			"`='" .
			$column_value .
			"'";
		$check_uniqueness_result = mysql_query( $check_uniqueness_sql );
		if( mysql_num_rows( $check_uniqueness_result ) > 0 ){
			$return_value = 2;
		}
	}
	
	return( $return_value );
}

#############################################################################
#---create parts of sql statement (not all are created here)---##############
#############################################################################
#---receives: 
#object containing all values
#array containing column names to add to sql (may be a subset of all columns in this table)
#---returns: array containing the sql statement parts
#---globals: 
#---algorithm: iterate through all columns that we were passed
#for each column, add parts to sql appropriate to the column type
function create_sql_SELECT_FROM_JOIN_strings( $all_vars, $column_names ){
	$table = $all_vars->table;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	$db = $all_vars->table_structure->db;
	$sub_tables_key = $all_vars->table_structure->sub_tables_key;
	$id = $all_vars->table_structure->id;
	$database_name = $all_vars->table_structure->database_name;

	$SELECT_string = 
		"\nSELECT\t`" . 
		$database_name .
		"`.`" . 
		$table . 
		$table_name_separator .
		$assets_name .
		"`.`" .
		$id .
		"`,\n";
	$JOIN_string = "\n";
	
	foreach( $column_names as $c_number => $c_name ){
		$column_type = column_type( $all_vars, $c_name );
		
		if( $column_type == $all_vars->table_structure->column_types[ "dropdown" ] ){
			$SELECT_string .= 
				"\t`" . 
				$database_name .
				"`.`" . 
				$table . 
				$table_name_separator . 
				$c_name . 
				"`.`Name`\n\t\tAS `" . 
				$c_name . 
				"`,\n";

			#section to append to $JOIN_string
			#example for what this *should* look like:
			#LEFT JOIN `fitequip-Asset_Type` ON
			#	`fitequip-assets`.`Asset_Type`=
			#	`fitequip-Asset_Type`.`id`
			$JOIN_string .= 
				"LEFT JOIN `" . 
					$database_name .
					"`.`" . 
					$table . $table_name_separator . $c_name . 
					"` ON\n" . 
				"\t`" . 
					$database_name .
					"`.`" . 
					$table . $table_name_separator . $assets_name .
						"`.`" . $c_name . 
					"`=\n" . 
				"\t`" .
					$database_name .
					"`.`" . 
					$table . $table_name_separator . $c_name .
						"`.`" . $sub_tables_key .
					"`\n";
		} else if( $column_type == $all_vars->table_structure->column_types[ "simple" ] ) {
			$SELECT_string .= 
				"\t`" . 
				$database_name .
				"`.`" . 
				$table . 
				$table_name_separator . 
				$assets_name . 
				"`.`" . 
				$c_name . 
				"`,\n";
		}
	}
	$all_vars->hook_objects[ "SELECT_string" ] = $SELECT_string;
	$all_vars->hook_objects[ "JOIN_string" ] = $JOIN_string;
	$all_vars->hook_objects[ "FROM_string" ] = 
		"\nFROM `" . 
		$database_name .
		"`.`" . 
		$table . 
		$table_name_separator . 
		$assets_name . 
		"`";
	$all_vars->hook_objects[ "GROUP_BY_string" ] = "";

	$all_vars = do_hook( $all_vars, "after_create_SELECT_FROM_JOIN_strings" );
	$all_vars->hook_objects[ "SELECT_string" ] = 
		rtrim( $all_vars->hook_objects[ "SELECT_string" ], ",\n" );
	
	return(
		array(
			"SELECT" => $all_vars->hook_objects[ "SELECT_string" ],
			"FROM" => $all_vars->hook_objects[ "FROM_string" ],
			"JOIN" => $all_vars->hook_objects[ "JOIN_string" ],
			"GROUP_BY" => $all_vars->hook_objects[ "GROUP_BY_string" ]
		)
	);
}

#############################################################################
#---create html select list or button from user's permission ---#############
#############################################################################
#---receives: 
#object containing all variables
#permission to check for
#default value of the drop-down list; only useful if more than one item
#page that's being referred to (use this to modify our verify_acl call to fit context)
#---returns:
#array
#	1: number of matches
#	2: action string, be it an html table, status message, etc
#	3: array containing the names of the permitted tables
#---globals: a bunch read, none modified
#---algorithm: check all tables for which the current user has the provided permission
#if they have multiple permissions, create an html select list displaying all
#if they have one permission, create an html button displaying it
function derive_html_fragment_from_permission( 
	$all_vars, $the_permission, $default_asset_list, $the_page 
){
	$pages = $all_vars->pages;
	$connected_user = $all_vars->connected_user;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$permission_item = $all_vars->table_structure->permission_item;
	
	#have to change the permission name if we're looking for structure acl
	$permission_target = $table_name_separator . $assets_name;
	#also have to change the text displayed in front of the button if a single structure
	#modify is allowed
	$single_permitted_description = $the_permission;
	if( $the_page == "structure" ){
		$permission_target .= $table_name_separator . $all_vars->table_structure->structure_name;
		$single_permitted_description = "change structure of";
	}
	
	$sql_permissions_result = verify_acl( 
		$connected_user, 
		$the_permission,
		"%" . $permission_target
	);
	
	$number_matches = mysql_num_rows( $sql_permissions_result );
	$html_fragment = "";
	$permitted_tables = array();
	
	#if we have several permitted asset lists, create entries for a drop down list to pick one
	if( $number_matches > 1 ){

		while( $sql_permissions_row = mysql_fetch_array( $sql_permissions_result ) ){
			$matched = preg_match( 
				'/(.*)' . $permission_target . '$/',
				$sql_permissions_row[ $permission_item ],
				$matches
			);
			$html_fragment .= "<option value=\"" . $matches[ 1 ] . "\"";
			if( $matches[ 1 ] == $default_asset_list ){
				$html_fragment .= ( " SELECTED " );
			}
			$html_fragment .= ">" . $matches[ 1 ] . "\n";
			
			array_push( $permitted_tables, $matches[ 1 ] );
		}
		
	#if we only have one permitted asset list, only create a button to pick it
	} else if( $number_matches == 1 ){
		$sql_permissions_row = mysql_fetch_array( $sql_permissions_result );
		$matched = preg_match( 
			'/(.*)' . $permission_target . '$/',
			$sql_permissions_row[ $permission_item ],
			$matches
		);

		$html_fragment .= 
			"<br>$single_permitted_description " . 
			"<input type=\"submit\" " . 
			"value=\"   " . $matches[ 1 ] . "   \">\n";
		#make the actual submitted value hidden so we can make the text button pretty
		$html_fragment .= 
			"<input type=\"hidden\" name=\"$assets_name\" " . 
			"value=\"" . $matches[ 1 ] . "\">\n";
	
		array_push( $permitted_tables, $matches[ 1 ] );
	}
	
	return( array( $number_matches, $html_fragment, $permitted_tables ) );
	
}

#############################################################################
#---gets table information---################################################
#############################################################################
#---receives: database the table is in
#the table name
#---returns: array containing all the column names and their definitions
#---globals: ?
#---algorithm: ?
function get_field_info( $database, $table ){
	$column_info = mysql_query( 
		"\nSHOW FIELDS FROM `$database`.`$table`"
	);
	
	array( $column_types );
	while( $column_info_row = mysql_fetch_array( $column_info ) ){
		$column_types[ $column_info_row[ "Field" ] . "-Field" ] = $column_info_row[ "Field" ];
		$column_types[ $column_info_row[ "Field" ] . "-Type" ] = $column_info_row[ "Type" ];
		$column_types[ $column_info_row[ "Field" ] . "-Null" ] = $column_info_row[ "Null" ];
		$column_types[ $column_info_row[ "Field" ] . "-Key" ] = $column_info_row[ "Key" ];
	}
	
	return( $column_types );
}

#############################################################################
#---check a user's permission on a table ---#################################
#############################################################################
#TODO: this is very similar to functions/sql.php:verify_acl
#clean the other up, then merge this into it?
#---receives: 
#object containing all vars
#table name to check on
#permission name to check for
#---returns: completed sql query
#---globals: 
#---algorithm: 
function get_permission_for_user( $all_vars, $table_name, $permission_name ){
	$permissions_table = $all_vars->table_structure->permissions_table;
	$id = $all_vars->id;
	$db = $all_vars->table_structure->db;
	
	$user_permission_query = 
		"\nSELECT *" .
		"\nFROM `$permissions_table`" .
		"\nWHERE `$permissions_table`.`user`='$id'" .
		"\n\tAND `$permissions_table`.`table`='$table_name'" .
		"\n\tAND `$permissions_table`.`permission`='$permission_name'";
	$user_permission_query_result = mysql_query( $user_permission_query, $db );
	
	return( $user_permission_query_result );
}

#############################################################################
#---find all valid acl targets ---###########################################
#############################################################################
#---receives: object containing all variables
#---returns: 
#---globals: 
#---algorithm: 
function get_valid_acls( $all_vars ){
	$database_name = $all_vars->table_structure->database_name;
	$db = $all_vars->table_structure->db;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;

	#initialize the acl targets with system targets
	#then add all the asset tables
	$acl_targets = $all_vars->acl_structure->system_targets;

	#not sure if we need to know assets tables here
	#$assets_tables = array();
	
	$table_status_query = "\nSHOW TABLE STATUS FROM `$database_name`";
	$table_status_query_result = mysql_query( $table_status_query, $db );
	$status_number_rows = mysql_num_rows( $table_status_query_result );
	if( $status_number_rows > 0 ){
		while( $status_row = mysql_fetch_array( $table_status_query_result ) ){
			if( 
				preg_match( 
					'/(.*' . $table_name_separator . $assets_name . ')$/', 
					$status_row[ "Name" ],
					$matches
				) 
			){
				array_push( $acl_targets, $status_row[ "Name" ] );
				array_push( $acl_targets, $status_row[ "Name" ] . "-structure" );
				array_push( $acl_targets, $status_row[ "Name" ] . "-acl" );
			}
		}
	}
	
	$all_vars->acl_structure->acl_targets = $acl_targets;
	return( $all_vars );
}

#############################################################################
#---make sure an id exists in the database ---###############################
#############################################################################
#---receives: object containing all variables
#---returns: 1 if exists, 0 if not
#---globals: none
#---algorithm: sql query database for all with passed id, return number of rows
#NOTE: the table must be defined for this to work properly, otherwise answer will always be 0
function id_exists( $all_vars ){
	
	$check_exists_sql = 
		"\nSELECT * FROM `" .
		$all_vars->table .
		$all_vars->table_structure->table_name_separator .
		$assets_name = $all_vars->table_structure->assets_name . "` ".
		"WHERE `id`='" . 
		$all_vars->id .
		"'"
	;
	
	$check_exists_result = mysql_query( $check_exists_sql );
	
	return( mysql_num_rows( $check_exists_result ) );
}

#############################################################################
#---check if a table links to a sub-table---#################################
#############################################################################
#---receives: $table_defs_name: table containing table definitions
#$table_name: table to be looked for
#$db: opened database connection to use
#---returns: 1 if $table_name is a sub-table, otherwise 0
#---globals: ?
#---algorithm: ?
function links_to_subtable( $table_defs_name, $table_name, $all_vars ){
	#see if this particular column name is in $tabledefs_name table
	#if it is, $result will be greater than zero
	$query = 
		"\nSELECT * FROM `" . 
		$table_defs_name . 
		"` WHERE `name` = '" . 
		$table_name . 
		"' AND `Type` = '" . 
		$all_vars->table_structure->column_types[ "dropdown" ] .
		"'";
	$result = mysql_query( $query, $all_vars->table_structure->db );
	
	if( mysql_num_rows( $result ) > 0 ){
		return( 1 );
	} else {
		return( 0 );
	}
}

#############################################################################
#---pull tabledefs info from database---#####################################
#############################################################################
#---receives: object containing all variables
#---returns: modified object; table definitions are now in it
#---globals: 
#---algorithm: 
function pull_table_definitions( $all_vars ){
	$query = 
		"\nSELECT * FROM `" . 
		$all_vars->table .
		$all_vars->table_structure->table_name_separator .
		$all_vars->table_structure->tabledefs_name . 
		"`";
	$result = mysql_query( $query, $all_vars->table_structure->db );
	
	$table_definitions = array();
	while( $row = mysql_fetch_array( $result ) ){
		array_push( $table_definitions, $row );
	}
	$all_vars->table_structure->table_definitions = $table_definitions;
	
	return( $all_vars );
}

#############################################################################
#---see if some acl criteria are met to allow access to a table---###########
#############################################################################
#TODO: clean this up; get rid of globals
#maybe also generalize it more so the pattern can be specified as LIKE *or* =
#---receives: 
#user we're verifying access for
#
#---returns: an sql query containing results of check
#---globals: acl table criteria are read but not modified
#---algorithm: ?
function verify_acl( $connected_user, $verify_permission, $desired_item_pattern ){
	global $table_name_separator, $assets_name, $dbase_key;
	global $permissions_table, $permission_column, $permission_user, $permission_item;
	global $users_table, $users_last_name, $users_first_name, $users_uid;

	$sql_permissions_query = 
		"\nSELECT\t`$permissions_table`.`$permission_column` AS `permission`," .
		"\n\t`$permissions_table`.`$permission_item`," . 
		"\n\t`$users_table`.`$users_last_name` AS `last_name`," .
		"\n\t`$users_table`.`$users_first_name` AS `first_name`," .
		"\n\t`$users_table`.`$users_uid` AS `uid`" .
		"\nFROM `$permissions_table`" .
		"\nLEFT JOIN `$users_table` ON" .
		"\n\t`$permissions_table`.`$permission_user`=" .
		"\n\t`$users_table`.`$dbase_key`" .
		"\nWHERE\t`permission`='$verify_permission' AND" .
		"\n\t`uid`='$connected_user' AND" .
		"\n\t`$permission_item` LIKE '$desired_item_pattern'" .
		"\nORDER BY `$permission_item`";
	return( mysql_query( $sql_permissions_query ) );
	
}

?>
