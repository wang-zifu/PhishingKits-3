<?php

class acl_structure{
	var $user_columns;
	var $permission_columns;
	#this will be used to hold the names of predefined system acl types
	var $system_targets;
	
	#this is not initialized by the constructor
	#it will hold all the valid acl targets, including tables, etc
	var $acl_targets;
	
	function acl_structure(){
		$this->user_columns = array(
			"id",
			"first_name",
			"last_name",
			"uid"
		);
		#WARNING: these values are referred to by some hardcoded values later
		#if you change this array, things may break
		$this->permission_columns = array(
			"id",
			"user",
			"table",
			"permission"
		);
		
		$this->system_targets = array(
			"acl",
			"users"
			#disabling this for now
			#TODO: re-enable this once system structure page is up
			#"structure"
		);
	}
}

#holds variables relating to list page query names
#for consistency and flexibility of GET query variable names
class filter_query{
	var $filter_url_name;
	var $filter_is_isnt_name;
	var $filter_condition_name;
	var $filter_text_name;
	var $filter_and_or_name;
	
	var $list_first_result;
	var $list_results_per_page;
	
	var $structure_current_defaults_array;
	var $structure_current_dropdowns_array;
	var $structure_delete_defaults;
	var $structure_delete_dropdown;
	var $structure_new_default;
	var $structure_new_default_array;
	var $structure_new_dropdown;
	
	#constructor
	function filter_query(){
		$this->filter_url_name = 'filter';
		$this->filter_is_isnt_name = 'filter_does_doesnt';
		$this->filter_condition_name = 'filter_condition';
		$this->filter_text_name = 'filter_text';
		$this->filter_and_or_name = 'filter_and_or';
		
		$this->list_first_result = 'first_result';
		$this->list_results_per_page = 'results_per_page';
		
		$this->structure_current_defaults_array = 'current_defaults_array';
		$this->structure_current_dropdowns_array = 'current_dropdowns_array';
		$this->structure_delete_defaults = 'delete_defaults';
		$this->structure_delete_dropdown = 'delete_dropdown';
		$this->structure_new_default = 'new_default';
		$this->structure_new_default_array = 'new_default_array';
		$this->structure_new_dropdown = 'new_dropdown';
	}
}

#this will hold any variables, etc specific to plugins 
class hook_info{
	#holds information that plugins want to store
	var $plugin_objects;
	
	function hook_info(){
		$this->plugin_objects = 
			register_plugin_objects();
	}
}

class html_presets{
	var $pixel_height;
	var $pixel_width;
	var $row_height;
	var $column_width;
	var $id_width;
	var $page_width;
	
	var $selected_cell;
	var $even_row;
	var $odd_row;
	
	var $image_dir;
	
	var $drill_down_symbol;
	var $null_set_symbol;
	var $ascending_sort_symbol;
	var $descending_sort_symbol;
	var $ascending_sort_symbol_selected;
	var $descending_sort_symbol_selected;
	var $remove_column_symbol;
	var $first_page_symbol;
	var $previous_page_symbol;
	var $next_page_symbol;
	var $last_page_symbol;
	
	#here's our constructor to initialize all the values
	function html_presets(){
		$image_dir = './images';
		
		$this->pixel_height = 30;
		$this->pixel_width = 200;
		$this->row_height = 'height=' . $this->pixel_height;
		$this->column_width = 'width=' . $this->pixel_width;
		$this->id_width = 'width=20';
		$this->page_width = 'width=800';
		
		$this->selected_cell = 'bgcolor=6699cc';
		$this->even_row = 'bgcolor=ffffff';
		$this->odd_row = 'bgcolor=cceeff';
		
		$this->image_dir = $image_dir;
		
		$this->drill_down_symbol = '<img src="' . $image_dir . '/mag.jpeg" border=0>';
		$this->null_set_symbol = '&oslash';
		$this->ascending_sort_symbol = '<img src="' . $image_dir . '/up_pointer.png" border=0>';
		$this->descending_sort_symbol = '<img src="' . $image_dir . '/down_pointer.png" border=0>';
		$this->ascending_sort_symbol_selected = '<img src="' . $image_dir . '/up_pointer.png" border=2>';
		$this->descending_sort_symbol_selected = '<img src="' . $image_dir . '/down_pointer.png" border=2>';
		$this->remove_column_symbol = '<img src="' . $image_dir . '/s_hide.gif" border=0>';
		$this->first_page_symbol = '<b>&lt&lt</b>';
		$this->previous_page_symbol = '<b>&lt</b>';
		$this->next_page_symbol = '<b>&gt</b>';
		$this->last_page_symbol = '<b>&gt&gt</b>';
	}
}

class table_structure{
	var $database_name;
	var $db;
	
	var $table_name_separator;
	var $assets_name;
	var $tabledefs_name;
	var $structure_name;
	var $sub_tables_key;

	var $dbase_key;
	var $id;
	
	var $permissions_table;
	var $permission_column;
	var $permission_user;
	var $permission_item;
	var $permissions;
	
	#not assigned by constructor
	#will pull information on this when we have more info about asset list, etc
	var $table_definitions;

	#associate a "Type" in tabledefs with an integer
	var $column_types;
	
	#these needed? phase out; should use the ones in acl_structure instead
	var $users_table;
	var $users_uid;
	var $users_last_name;
	var $users_first_name;

	#here's our constructor to initialize all the values
	function table_structure(){
		#get database connection parameters from config file
		require_once( "../settings/database_settings.conf" );
		$db = mysql_connect( $database_server, $database_user, $database_password );
		mysql_select_db( $database_name, $db );

		$this->database_name = $database_name;
		$this->db = $db;
		
		$this->table_name_separator = "-";
		$this->assets_name = "assets";
		$this->tabledefs_name = "tabledefs";
		$this->structure_name = "structure";
		$this->sub_tables_key = "id";

		$this->dbase_key = $this->sub_tables_key;
		$this->id = $this->sub_tables_key;
		
		$this->permissions_table = "permissions";
		$this->permission_column = "permission";
		$this->permission_user = "user";
		$this->permission_item = "table";
		$this->permissions = 
			array(
				"view" => "view",
				"add" => "add",
				"delete" => "delete",
				"modify" => "modify"
			);
		
		$this->column_types = 
			array(
				"simple" => 1,
				"dropdown" => 2
			);
		
		$this->users_table = "users";
		$this->users_uid = "uid";
		$this->users_last_name = "last_name";
		$this->users_first_name = "first_name";
	}
}

class all{
	var $connected_user;
	var $this_page;
	var $this_request;
	
	var $html_presets;
	var $pages;
	var $table_structure;
	var $acl_structure;
	var $filter_query;
	var $results_per_page;
	var $first_result;
	
	var $hook_names;
	var $plugins_directory;
	var $plugin_name_register;
	var $plugin_function_register;
	
	var $hook_info;
	#holds information from code blocks that we want to make available to plugins
	var $hook_objects;

	#following values aren't assigned values by the constructor
	#they should be "high up" in the class to be easily changeable
	#values associated with the current search
	var $table;
	var $column_sort;
	var $order;
	var $highlight;
	var $number_sql_results;
	var $sql_query_timestamp;
	var $id;
	#descriptors of current table's structure
	var $column_names;
	var $field_info;
	#descriptor of current action (for modify page)
	var $action;
	#the current html form name
	var $current_form;
	
	#here's our constructor to initialize all the values
	function all(){
		global $_SERVER;
		$this->connected_user = $_SERVER[ 'REMOTE_USER' ];
		$this->this_page = $_SERVER[ 'PHP_SELF' ];
		$this->this_request = $_SERVER[ 'REQUEST_URI' ];
		
		$this->html_presets = new html_presets;
		$this->pages = array(
			"main" => "index.php",
			"list" => "list.php",
			"id_detail" => "id_detail.php",
			"modify" => "modify.php",
			"add" => "add.php",
			"users" => "users.php",
			"user_detail" => "user_detail.php",
			"user_modify" => "user_modify.php",
			"structure" => "structure.php",
			"structure_modify" => "structure_modify.php",
			"system_structure" => "system_structure.php"
		);
		$this->table_structure = new table_structure;
		$this->acl_structure = new acl_structure;
		$this->filter_query = new filter_query;
		$this->results_per_page = 50;
		$this->first_result = 1;
		
		$this->hook_names = array(
			"after_create_SELECT_FROM_JOIN_strings",
			"after_id_detail_ignore_checkbox",
			"after_id_detail_new_value",
			"after_id_detail_print_field_criteria",
			"after_id_detail_null_checkbox",
			"in_add_after_print_field_criteria",
			"in_modify_after_standard_modify",
			"in_structure_after_print_field_criteria",
			"after_validate_filter_checks"
		);

		#get active plugins from config file
		require_once( "../settings/plugins.conf" );
		$this->plugin_name_register = $plugin_name_register;
		$this->plugins_directory = "./plugins/";
		$this->plugin_function_register = 
			register_plugin_functions( 
				$this->plugin_name_register, $this->plugins_directory, $this->hook_names
			);
		
		$this->hook_info = 
			register_plugin_variables( 
				$this->plugin_name_register, $this->plugins_directory, $this->hook_names
			);
		
		$this->hook_objects = array();
	}
}

#TODO: obsolete: phase these out
$table = "fitequip";
$table_name_separator = "-";
$assets_name = "assets";
$tabledefs_name = "tabledefs";
$sub_tables_key = "id";
$dbase_key = $sub_tables_key;
$permissions_table = "permissions";
$permission_column = "permission";
$permission_user = "user";
$permission_item = "table";
$permissions = array(
	"view" => "view",
	"add" => "add",
	"delete" => "delete",
	"modify" => "modify"
);
$users_table = "users";
$users_uid = "uid";
$users_last_name = "last_name";
$users_first_name = "first_name";


?>
