<?php
##########
#display a user and their permissions from the permissions table "users"
##########

require_once( "./functions/include_all.php" );

##########
#variables to use throughout the script
##########

##########
#subroutines
##########

#############################################################################
#---show change form to modify a user's details ---##########################
#############################################################################
#---receives: 
#object containing all variables
#array containing mysql results for this id; can extract fname, lname, uid from it
#whether we can modify the fields; 0 if no, non-zero if yes
#---returns: 
#---globals: 
#---algorithm: 
function modify_user_details( $all_vars, $user_info, $user_modify_permission ){

	echo( "<br>&nbsp\n" );
	
	echo( "<br>User information\n" );
	echo( "<br>&nbsp\n" );
	
	echo( "<table width=500>\n" );
	
	$info = array(
		"fname" => "users_first_name",
		"lname" => "users_last_name",
		"uid" => "users_uid"
	);
	
	$info_names = array(
		"fname" => "first name",
		"lname" => "last name",
		"uid" => "user id"
	);
	
	foreach( $info as $key => $value ){
	
		echo( "<tr height=30>\n" );
		echo( "<td width=150>\n" );
		echo( $info_names[ $key ] . ":" );
		echo( "</td>\n" );
		echo( "<td width=350>\n" );
		if( $user_modify_permission ){
			echo( "<input type=text size=30 name=\"$key\" value=\"" . 
				$user_info[ $all_vars->table_structure->$value ] . "\">\n" );
		} else {
			echo( $user_info[ $all_vars->table_structure->$value ] . "\n" );
		}
		echo( "</td>\n" );
		echo( "</tr>\n" );
	}
	
	echo( "</table>\n" );

}

#############################################################################
#---see what permissions user has & show appropriate modify forms ---########
#############################################################################
#---receives: object containing all variables
#---returns: 
#---globals: 
#---algorithm: 
function print_modify_form( $all_vars ){

	#first get "view" permission for "users"
	$user_view_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "view" ],
		"users"
	);
	$user_view_permission = mysql_num_rows( $user_view_result );

	#check if connected user is allowed to view the acl system
	$permissions_view_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "view" ],
		"acl"
	);
	$permissions_view_permission = mysql_num_rows( $permissions_view_result );

	#check if connected user is allowed to delete users
	$user_delete_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "delete" ],
		"users"
	);
	$user_delete_permission = mysql_num_rows( $user_delete_result );

	#if we have view permission for users or permissions, continue
	if( $user_view_permission || $permissions_view_permission || $user_delete_permission ){
		
		#make sure the id we were passed is valid
		$user_id_query = "\nSELECT *" .
			"\nFROM `" . $all_vars->table_structure->users_table . "`" .
			"\nWHERE `" . $all_vars->table_structure->users_table . 
			"`.`id`='" . $all_vars->id . "'";
		$user_id_result = mysql_query( $user_id_query, $all_vars->table_structure->db );
		if( mysql_num_rows( $user_id_result ) > 0 ){

			#get "modify" permission for "users"
			$user_modify_result = verify_acl( 
				$all_vars->connected_user, 
				$all_vars->table_structure->permissions[ "modify" ],
				"users"
			);
			$user_modify_permission = mysql_num_rows( $user_modify_result );
		
			#check if connected user is allowed to modify the acl system
			$permissions_modify_result = verify_acl( 
				$all_vars->connected_user, 
				$all_vars->table_structure->permissions[ "modify" ],
				"acl"
			);
			$permissions_modify_permission = mysql_num_rows( $permissions_modify_result );
			
			$user_row = mysql_fetch_array( $user_id_result );
			if( $user_view_permission ){
				$user_name = $user_row[ "uid" ];
			} else {
				$user_name = "ID " . $all_vars->id;
			}
			
			#if we can modify the user's info or acl, start a form with submit button
			if( 
				$user_modify_permission || 
				$permissions_modify_permission || 
				$user_delete_permission 
			){
				echo( "<form action=\"" . $all_vars->pages[ "user_modify" ] . "\">\n" );
				
				#don't show "modify user" button if we can only delete
				if( $user_modify_permission || $permissions_modify_permission ){
					echo( "<input type=submit value=\"Modify $user_name:\">\n" );
				}
				
				echo( "<input type=hidden name=\"update\" value=\"change\">\n" );
				echo( "<input type=hidden name=\"id\" value=\"" . $all_vars->id . "\">\n" );
			}
		
			if( $user_view_permission ){
				modify_user_details( $all_vars, $user_row, $user_modify_permission );
			}
			if( $permissions_view_permission ){
				show_user_permissions( $all_vars, $permissions_modify_permission );
			}
			#show bottom "modify" button
			if( $user_modify_permission || $permissions_modify_permission ){
				echo( "<input type=submit value=\"Modify $user_name:\">\n" );
				echo( "<br>&nbsp\n" );
			}
				
			if( $user_delete_permission ){
				echo( "<br><b>Warning:</b> clicking this button will <b>irrevocably</b>" . 
					" delete this user &nbsp <input type=submit name=\"delete\"" . 
					" value=\"Delete $user_name\">" );
			}
		
			#now end the form
			if( 
				$user_modify_permission || 
				$permissions_modify_permission || 
				$user_delete_permission 
			){
				echo( "</form>\n" );
			}
		
		#if the id doesn't exist, echo error message
		} else {
			error_message( "Id " . $all_vars->id . " is not in the users table" );
		}
	
	#otherwise, echo error message
	} else {
		error_message( "You are not allowed to view information about users or their access permissions" );
	}
}

#############################################################################
#---show permissions for a user---###########################################
#############################################################################
#---receives: object containing all variables
#---returns: 
#---globals: 
#---algorithm: 
function show_user_permissions( $all_vars, $modify_permission ){
	$users_table = $all_vars->table_structure->users_table;
	$permissions_table = $all_vars->table_structure->permissions_table;
	$db = $all_vars->table_structure->db;
	$id = $all_vars->id;
	$database_name = $all_vars->table_structure->database_name;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$permissions = $all_vars->table_structure->permissions;
	$row_height = $all_vars->html_presets->row_height;
	
	$user_permission_query = 
		"\nSELECT *" .
		"\nFROM `$permissions_table`" .
		"\nWHERE `$permissions_table`.`user`='$id'";
	$user_permission_query_result = mysql_query( $user_permission_query, $db );
	
	$all_vars = get_valid_acls( $all_vars );
	$acl_targets = $all_vars->acl_structure->acl_targets;
	
	echo( "<br>&nbsp\n" );
	echo( "<br>User permissions\n" );
	
	echo( "<table border=0 cellspacing=1 cellpadding=3 width=500>\n" );
	
	#show the column headers
	echo( "<tr $row_height>\n" );
	echo( "<td width=200>\n" );
	echo( "&nbsp\n" );
	echo( "</td>\n" );
	foreach( $permissions as $perm_key => $perm_value ){
		echo( "<td width=75>\n" );
		echo( "<column_header>$perm_value</column_header>\n" );
		echo( "</td>\n" );
	}
	echo( "</tr>\n" );
	
	#now show all the row names and values in each row
	$row_number = 1;
	foreach ( $acl_targets as $key => $value ){
		echo( "<tr $row_height>\n" );
		if( $row_number % 2 ){
			$background = $all_vars->html_presets->odd_row;
		} else {
			$background = $all_vars->html_presets->even_row;
		}
		$row_number++;
		
		echo( "<td width=200 $background>\n" );
		echo( "$value\n" );
		echo( "</td>\n" );
		foreach( $permissions as $perm_key => $perm_value ){
			echo( "<td width=75 $background>\n" );
			
			#if it's an add or delete acl and "*acl" permission-name, print space only
			#this is because add or delete don't make sense in this context
			if( preg_match( '/acl$/', $value ) && 
				( $perm_value == "add" || $perm_value == "delete" ) 
			){
				echo( "&nbsp\n" );
			} else {

				$user_permission_query_result =
					get_permission_for_user( $all_vars, $value, $perm_value );
				$perm_number_rows = mysql_num_rows( $user_permission_query_result );
				
				#if we're allowed to modify, include a hidden value for this permission
				if( $modify_permission ){
					echo( "<input type=hidden name=\"". 
						"May-" .
						$value . 
						$table_name_separator .
						$perm_value .
						"\">\n" );
				}
	
				#if this item is allowed, show marked check box or "yes"
				if( $perm_number_rows ){
					if( $modify_permission ){
						echo( "<input type=checkbox name=\"" .
							$value . 
							$table_name_separator .
							$perm_value .
							"\" CHECKED>\n" );
					} else {
						echo( "yes\n" );
					}
				
				#if it's not allowed, show empty check box or "no"
				} else {
					if( $modify_permission ){
						echo( "<input type=checkbox name=\"" .
							$value . 
							$table_name_separator .
							$perm_value .
							"\">\n" );
					} else {
						echo( "no\n" );
					}
				}
			}
			
			echo( "</td>\n" );
		}
		echo( "</tr>\n" );
	}
	echo( "</table>\n" );
	
	echo( "<br>\n" );
	
}

##########
#driver
##########

$all_vars = new all;

#put _GET variables into $all_vars object
$all_vars = copy_env_vars_to_object( $all_vars );

print_page_header( $all_vars, "view and edit a user" );

print_modify_form( $all_vars );

print_page_footer( $all_vars );

?>
