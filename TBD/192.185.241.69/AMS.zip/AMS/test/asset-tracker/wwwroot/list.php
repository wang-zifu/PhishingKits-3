<?php
##########
#display entries in a database
##########

require_once( "./functions/include_all.php" );

##########
#subroutines
##########

#############################################################################
#---create HAVING part of sql statement---###################################
#############################################################################
#---receives: 
#object containing all our variables
#the query that was passed to the page
#---returns: string containing HAVING part of sql query
#---globals:
#---algorithm: 
function create_sql_HAVING_string( $all_vars, $url_query ){
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	$db = $all_vars->table_structure->db;
	$table = $all_vars->table;
	
	$url_name = $all_vars->filter_query->filter_url_name;
	$is_isnt_name = $all_vars->filter_query->filter_is_isnt_name;
	$condition_name = $all_vars->filter_query->filter_condition_name;
	$text_name = $all_vars->filter_query->filter_text_name;
	$and_or_name = $all_vars->filter_query->filter_and_or_name;

	#now create the HAVING part of our sql statement
	$sql_having = '';
	$query_vars = url_to_array( $url_query );
	if( isset( $query_vars[ $url_name ] ) && is_array( $query_vars[ $url_name ] ) ){
		#TODO: replace these literals; maybe a separate global object?
		$sql_having = "\nHAVING";
		foreach( $query_vars[ $url_name ] as $index => $name ){
			
			$url = $query_vars[ $url_name ][ $index ];
			
			$is_isnt = $query_vars[ $is_isnt_name ][ $index ];
			$condition = $query_vars[ $condition_name ][ $index ];
			$text = $query_vars[ $text_name ][ $index ];

			if( isset( $query_vars[ $and_or_name ][ $index ] ) ){
				if( $query_vars[ $and_or_name ][ $index ] == 'and' ){
					$sql_having .= "\n\tAND ";
				} else {
					$sql_having .= "\n\tOR ";
				}
				
			} else {
				$sql_having .= "\t";
			}
			
			$sql_having .= '(`' . $url . '` ';
			
			#if looking for is/isn't null
			if( $condition == 'null' ){
				$sql_having .= 'IS ';
				if( $is_isnt == 'does_not' ){
					$sql_having .= 'NOT ';
				}
				$sql_having .= "NULL)\n";
			
			#otherwise match/don't match conditions, and append query text
			} else {
			
				#need a "match null" fragment in case we want to include null results
				$null_fragment = '';
				
				if( $condition == 'equal_to' ){
					if( $is_isnt == 'does_not' ){
						$sql_having .= '<> ';
						$null_fragment = "\n\t\tOR `$url` IS NULL";
					} else {
						$sql_having .= '= ';
					}
				} else if( 
					$condition == 'less_than' || 
					$condition == 'greater_than' ||
					$condition == 'before' || 
					$condition == 'after'
				){
					if( $is_isnt == 'does_not' ){
						if( $condition == 'less_than' || $condition == 'before' ){
							$sql_having .= '>= ';
							$null_fragment = "\n\t\tOR `$url` IS NULL";
						} else {
							$sql_having .= '<= ';
							$null_fragment = "\n\t\tOR `$url` IS NULL";
						}
					} else {
						if( $condition == 'less_than' || $condition == 'before' ){
							$sql_having .= '< ';
						} else {
							$sql_having .= '> ';
						}
					}
				} else {
					if( $is_isnt == 'does_not' ){
						$sql_having .= 'NOT ';
						$null_fragment = "\n\t\tOR `$url` IS NULL";
					}
					$sql_having .= 'LIKE ';
					
					if( $condition == 'start_with' ){
						$text = $text . '%';
					} else if( $condition == 'contain' ){
						$text = '%' . $text . '%';
					} else if( $condition == 'end_with' ){
						$text = '%' . $text;
					}
				}
				
				$sql_having .= "'" . $text . "'" . $null_fragment . ")";
			}
		}
	}
	
	return( $sql_having );
}

#############################################################################
#---display all column names with sort buttons---############################
#############################################################################
#---receives: 
#the query that was passed to the page (needed to determine new sort urls)
#object containing all our variables
#---returns: nothing
#---globals: none modified
#---algorithm: 
#print each column name, followed by ascending/descending sort buttons
#if current column name matches the sort variable we received, we'll highlight a button
#sort variable is stored in variable $all_vars->highlight
#which button to highlight depends on the variable $all_vars->order
#url assigned to each button calls this script again with variables $all_vars->order and
#$all_vars->highlight set to whatever the user clicked
#url assigned to currently-selected button simply calls this script with no variables
#this "undoes" the sort
function display_column_headers( $original_query, $column_names, $all_vars ){
	$row_height = $all_vars->html_presets->row_height;
	$column_width = $all_vars->html_presets->column_width;
	$id_width = $all_vars->html_presets->id_width;
	$remove_column_symbol = $all_vars->html_presets->remove_column_symbol;
	
	#print column names
	echo( "<tr>\n" );
	echo( "<td $id_width>\n" );
	echo( "&nbsp\n" );
	echo( "</td>\n" );
	
	foreach( $column_names as $c_number => $c_name ){
		echo( "<td $column_width>\n" );
		echo( "<column_header>$c_name</column_header>\n" );
		echo( "</td>\n" );
	}
	echo( "</tr>\n" );
	
	echo( "<tr $row_height>\n" );
	
	echo( "<td $id_width>\n" );
	echo( "$id\n" );
	echo( "</td>\n" );
	
	#setcookie( "blah", "val1" );

	#print column symbols (sort, de-select)
	foreach( $column_names as $c_number => $c_name ){

		$new_query = modify_url_vars( $original_query, "column_sort", $c_name );
		
		$ref_url_up = modify_url_vars( $new_query, "order", "asc" );
		$ref_url_down = modify_url_vars( $new_query, "order", "desc" );
		
		$ascending_sort_symbol = $all_vars->html_presets->ascending_sort_symbol;
		$descending_sort_symbol = $all_vars->html_presets->descending_sort_symbol;
		$ascending_selected = "";
		$descending_selected = "";
		if( $c_name == $all_vars->highlight ){
			if( $all_vars->order == "asc" ){
				$ascending_selected = $all_vars->html_presets->selected_cell;
				#$ascending_sort_symbol = $all_vars->html_presets->ascending_sort_symbol_selected;
				$new_query = modify_url_vars( $original_query, "column_sort", " " );
				$new_query = modify_url_vars( $new_query, "order", " " );
				$ref_url_up = $new_query;
			} else if( $all_vars->order == "desc" ){
				$descending_selected = $all_vars->html_presets->selected_cell;
				#$descending_sort_symbol = $all_vars->html_presets->descending_sort_symbol_selected;
				$new_query = modify_url_vars( $original_query, "column_sort", " " );
				$new_query = modify_url_vars( $new_query, "order", " " );
				$ref_url_down = $new_query;
			}
		}
		
		$remove_column_url = modify_url_vars( $original_query, "column[$c_number]", " " );
		
		#TODO: replace this with a template
		echo( "<td $column_width>\n" );
		echo( "<table border=0 cellspacing=0 cellpadding=0>\n" );
		echo( "<tr>\n" );

		echo( "<td valign=center $id_width>\n" );
		echo( "<a href=\"$remove_column_url\">$remove_column_symbol</a>&nbsp\n" );
		echo( "</td>\n" );

		echo( "<td align=center valign=center $id_width $ascending_selected>\n" );
		echo( "<a href=\"$ref_url_up\">$ascending_sort_symbol</a>\n" );
		echo( "</td>\n" );

		echo( "<td align=center valign=center $id_width $descending_selected>\n" );
		echo( "<a href=\"$ref_url_down\">$descending_sort_symbol</a>\n" );
		echo( "</td>\n" );

		echo( "</tr>\n" );
		echo( "</table>\n" );
		echo( "</td>\n" );
	}
	
	echo( "</tr>\n" );
}

#############################################################################
#---display our table containing rows and column headers ---#################
#############################################################################
#---receives: 
#---returns: 
#---globals: 
#---algorithm: 
function display_list( $all_vars ){
	$table_name = $all_vars->table;
	$url_query = $all_vars->this_request;
	$row_height = $all_vars->html_presets->row_height;
	
	#pull any queries from url into array $query_vars
	#TODO: shouldn't this be moved down to after our url has been sanitized?
	$query_vars = url_to_array( $url_query );
	
	#make sure our query contains the name of the table we're viewing
	$url_query = modify_url_vars( $url_query, $all_vars->table_structure->assets_name, $all_vars->table );
	
	#initialize sundry variables
	$all_vars = initialize_vars( $all_vars );
	
	#get all column names from database
	$all_vars->column_names = calculate_column_names( $all_vars );
	
	#TODO: remove all unknown variables from the query url
	
	#see if we were passed a valid number as number of results to show per page
	#if it's valid, change the number of results per page to this value
	if( 
		isset( $query_vars[ $all_vars->filter_query->list_results_per_page ] ) &&
		is_numeric( $query_vars[ $all_vars->filter_query->list_results_per_page ] ) &&
		$query_vars[ $all_vars->filter_query->list_results_per_page ] > 0
	){
		$url_query = 
			modify_url_vars( 
				$url_query, 
				$all_vars->filter_query->list_results_per_page, 
				$query_vars[ $all_vars->filter_query->list_results_per_page ]
			);
		$all_vars->results_per_page = 
			$query_vars[ $all_vars->filter_query->list_results_per_page ];
	#otherwise, take this value out of the url
	} else {
		$url_query = 
			modify_url_vars( $url_query, $all_vars->filter_query->list_results_per_page, ' ' );
	}
	#see if we were passed a valid number as the first page of results to show
	#if it's valid, change the first page of results to this value
	if( 
		isset( $query_vars[ $all_vars->filter_query->list_first_result ] ) &&
		is_numeric( $query_vars[ $all_vars->filter_query->list_first_result ] ) &&
		$query_vars[ $all_vars->filter_query->list_first_result ] > 0
	){
		$url_query = 
			modify_url_vars( 
				$url_query, 
				$all_vars->filter_query->list_first_result, 
				$query_vars[ $all_vars->filter_query->list_first_result ]
			);
		$all_vars->first_result = 
			$query_vars[ $all_vars->filter_query->list_first_result ];
	#otherwise, take this value out of the url
	} else {
		$url_query = 
			modify_url_vars( $url_query, $all_vars->filter_query->list_first_result, ' ' );
	}

	#translate all "%5B" to "[" and "%5D" to "]"
	#not using php's "url-decode" here because it might interfere
	#with non-query parts of the url
	#TODO: switch this to use "url-decode" to catch any other weird instances
	$translation_table = array(
		'%5B' => '[',
		'%5D' => ']',
		'%5b' => '[',
		'%5d' => ']'
	);
	$url_query = strtr( $url_query, $translation_table );
	
	#remove any filters the user has specified
	$url_query = user_removed_filters( $all_vars, $url_query );
	
	#remove any non-valid filters from the url
	#this also re-numbers all filters from 0 up
	$url_query = validate_filters( $all_vars, $url_query );
	
	#see which columns are being displayed; pull this information from the url
	list( $url_query, $displayed_columns, $number_of_columns ) = 
		verify_url_columns( $url_query, $all_vars );

	#find out how many rows are returned when filtering using sql's HAVING
	$sql_parts = create_sql_SELECT_FROM_JOIN_strings( $all_vars, $displayed_columns );
	$sql_having = create_sql_HAVING_string( $all_vars, $url_query );
	
	$first_sql_part = 
		$sql_parts[ "SELECT" ] . " " .
		$sql_parts[ "FROM" ] . " " .
		$sql_parts[ "JOIN" ] . 
		$sql_parts[ "GROUP_BY" ] .
		$sql_having;
	$result = mysql_query( $first_sql_part, $all_vars->table_structure->db );
	#TODO: figure out how to count rows in mysql instead of in php
	$all_vars->number_sql_results = mysql_num_rows( $result );
	
	#if first result is greater than total number of results, set it to 1
	if( $all_vars->first_result > $all_vars->number_sql_results ){
		$all_vars->first_result = 1;
		$url_query = 
			modify_url_vars( 
				$url_query,
				$all_vars->filter_query->list_first_result, 
				'1'
			);
	}
	
	#verify that the sort variables we were passed are valid
	$all_vars = validate_sort_type( $displayed_columns, $all_vars );
	
	$table_width = " width=";
	$table_width .= ( 150 * $number_of_columns ) + 20;
	
	echo( "<table border=0 cellspacing=1 cellpadding=3 $table_width>\n" );
	
	#show our column headers with sort buttons
	display_column_headers( $url_query, $displayed_columns, $all_vars );
	
	#show our rows, returning the number of results, time of query
	$all_vars = display_rows( $displayed_columns, $all_vars, $url_query, $first_sql_part );
	
	echo( "</table>\n" );
	echo( "<br>\n" );
	
	#summarize results, show paginator
	paginator( $all_vars, $url_query );
	
	#display column selector, $query selector, $query display
	display_query_editor( $all_vars, $url_query );
	
	#TODO: set all parameters in a cookie
	#this way, when we return to list view, parameters will be intact

}

#############################################################################
#---display all the data in our rows ---#####################################
#############################################################################
#---receives: 
#array containing column names to display
#object containing all our other variables
#cleaned/validated query url
#sql text query without limits or sorting in place
#---returns: 
#modified object with our other variables:
#number of sql results is returned
#time of sql query is returned
#---globals: none modified
#---algorithm: loop through all rows
#in each row, loop through all columns and print the data from the column
function display_rows( $column_names, $all_vars, $url_query, $first_sql_part ){
	$assets_name = $all_vars->table_structure->assets_name;
	$db = $all_vars->table_structure->db;
	$id = $all_vars->table_structure->id;
	
	$row_height = $all_vars->html_presets->row_height;
	$drill_down_symbol = $all_vars->html_presets->drill_down_symbol;

	$id_detail_view_page = $all_vars->pages[ "id_detail" ];
	$table = $all_vars->table;
	
	#create LIMIT part of sql statement
	$sql_limit = '';
	if( isset( $all_vars->first_result ) && isset( $all_vars->results_per_page ) ){
		$first_result = $all_vars->first_result - 1;
		$sql_limit .= "\nLIMIT $first_result, " . $all_vars->results_per_page;
	}
	
	$complete_sql_query = $first_sql_part;
	$complete_sql_query .= "\n" . $all_vars->column_sort . " " . $all_vars->order;
	$complete_sql_query = rtrim( $complete_sql_query );
	$complete_sql_query .= $sql_limit;
	
	#return all results with optional limits, filtering, and sorting in place
	#$all_vars->column_sort *may* contain "SORT BY <something>"
	#$all_vars->order *may* contain "asc" or "desc"
	$result = mysql_query( $complete_sql_query, $db );
	
	$all_vars->sql_query_timestamp = time();
	
	$results_num = 0;
	while ( $myrow = mysql_fetch_array( $result ) ) {
		$is_odd = $results_num % 2;
		if( !$is_odd ){
			$bgcolor = $all_vars->html_presets->odd_row;
		} else {
			$bgcolor = $all_vars->html_presets->even_row;
		}
		echo"<tr $row_height>\n";
		
		echo"<td $bgcolor>\n";
		echo"<a href=\"$id_detail_view_page?$assets_name=$table&$id=" . $myrow[ $id ] . 
			"\">$drill_down_symbol</a>\n";
		echo"</td>\n";
		
		foreach( $column_names as $c_number => $c_name ){
			$output = $myrow[ $c_name ];
			if( !isset( $output ) ){
				$output = $all_vars->html_presets->null_set_symbol;
			}
			echo"<td $bgcolor>\n";
			echo"$output\n";
			echo"</td>\n";
		}
		
		echo"</tr>\n";
		$results_num++;
	}
	
	return( $all_vars );
}

#############################################################################
#---pick list to display ---#################################################
#############################################################################
#---receives: object containing all our variables
#---returns: nothing
#---globals: none
#---algorithm: 
function do_list_selection( $all_vars ){
	$view_permission = $all_vars->table_structure->permissions[ "view" ];
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	
	$connected_user = $all_vars->connected_user;
	$table_name = $all_vars->table;
	
	if( isset( $table_name ) ){
		$sql_permissions_result = verify_acl( 
			$connected_user, 
			$view_permission,
			$table_name . $table_name_separator . $assets_name
		);
		
		if( mysql_num_rows( $sql_permissions_result ) > 0 ){
	
			display_list( $all_vars );	
			
		} else {
			error_message( "$connected_user is not allowed to view assets from list " . 
				"\"$table_name\" or it is not a valid table" );
			
			list( $number_of_tables, $widget_html, $permitted_tables ) = 
				pick_table( $all_vars, "view", "list", 0 );
			
			#if only one table is permitted, show it instead of printing the "select" button
			if( $number_of_tables == 1 ){
				$all_vars->table = $permitted_tables[ 0 ];
				display_list( $all_vars );
			
			#otherwise, proceed normally with selection widget or "not allowed" message
			} else {
				echo( $widget_html );
			}
		}
	} else {
		
		#find out which tables the user has permissions in
		list( $number_of_tables, $widget_html, $permitted_tables ) = 
			pick_table( $all_vars, "view", "list", 0 );
			
		#if only one table is permitted, show it; don't print the "select" button
		if( $number_of_tables == 1 ){
			$all_vars->table = $permitted_tables[ 0 ];
			display_list( $all_vars );

		#if more than one table is permitted, show selection widget and "none selected" error
		} else if( $number_of_tables > 1 ) {
			error_message( "No asset list selected for viewing" );
			echo( $widget_html );
		
		#otherwise, no tables are permitted, so just echo the error message
		} else {
			echo( $widget_html );
		}
	}
}

#############################################################################
#---show search results summary and paginator ---############################
#############################################################################
#---receives: 
#object containing all variables
#url that has been passed and verified for correctness
#---returns: 
#---globals: 
#---algorithm: 
function paginator( $all_vars, $url_query ){
	$row_height = $all_vars->html_presets->row_height;
	$first_page = $all_vars->html_presets->first_page_symbol;
	$previous_page = $all_vars->html_presets->previous_page_symbol;
	$next_page = $all_vars->html_presets->next_page_symbol;
	$last_page = $all_vars->html_presets->last_page_symbol;
	
	$total_results = $all_vars->number_sql_results;
	$first_result_number = $all_vars->first_result;
	$last_result_number = $first_result_number + $all_vars->results_per_page - 1;
	$blank = '&nbsp';
	$navigator_note = 'turn page';
	
	#if we're already on the first page, don't need previous/first page buttons
	if( $first_result_number == 1 ){
		$first_page = $blank;
		$previous_page = $blank;
	#otherwise, add a url to the navigator elements
	} else {
		$temp_url_query = 
			modify_url_vars(
				$url_query,
				$all_vars->filter_query->list_first_result, 
				' '
			);
			
		$first_page_query =
			modify_url_vars(
				$temp_url_query,
				$all_vars->filter_query->list_first_result, 
				'1'
			);
		$first_page = "<a href=\"$first_page_query\">$first_page</a>";
		
		$previous_page_first_number = $first_result_number - $all_vars->results_per_page;
		if( $previous_page_first_number < 1 ){
			$previous_page_first_number = 1;
		}
		$previous_page_query =
			modify_url_vars(
				$temp_url_query,
				$all_vars->filter_query->list_first_result, 
				$previous_page_first_number
			);
		$previous_page = "<a href=\"$previous_page_query\">$previous_page</a>";
	}

	#if we're already on the last page, don't need next/last page buttons
	#also adjust last result number
	if( ( $first_result_number + $all_vars->results_per_page - 1 ) >= $total_results ){
		$next_page = $blank;
		$last_page = $blank;
		$last_result_number = $total_results;
	#otherwise, add a url to the navigator elements
	} else {
		$temp_url_query = 
			modify_url_vars(
				$url_query,
				$all_vars->filter_query->list_first_result, 
				' '
			);
		
		$number_of_pages = ceil( $total_results / $all_vars->results_per_page );
		$last_page_number = $number_of_pages - 1;
		$last_page_first_result = ( $last_page_number * $all_vars->results_per_page ) + 1;
		$last_page_query =
			modify_url_vars(
				$temp_url_query,
				$all_vars->filter_query->list_first_result, 
				$last_page_first_result
			);
		$last_page = "<a href=\"$last_page_query\">$last_page</a>";
		
		$next_page_first_result = $first_result_number + $all_vars->results_per_page;
		if( $next_page_first_result > $last_page_first_result ){
			$next_page_first_result = $last_page_first_result;
		}
		$next_page_query =
			modify_url_vars(
				$temp_url_query,
				$all_vars->filter_query->list_first_result, 
				$next_page_first_result
			);
		$next_page = "<a href=\"$next_page_query\">$next_page</a>";
	}
	
	#don't need page navigator note if all navigator elements have been removed
	if( 
		$first_page == $blank &&
		$previous_page == $blank &&
		$next_page == $blank &&
		$last_page == $blank 
	){
		$navigator_note = $blank;
	}
	
	#shows note "showing results <first> to <last>" or "showing all results"
	if( $navigator_note == $blank ){
		$numbers_note = "Showing <b>all</b> results";
	} else {
		$numbers_note = "Showing results <b>$first_result_number</b> to <b>$last_result_number</b>";
	}
	
	#need an "s" appended for all non-1 numbers of total results
	$result_string = 'results were';
	if( $total_results == 1 ){
		$result_string = 'result was';
	}
	
	$query_timestamp = date( "r", $all_vars->sql_query_timestamp ) . ".";
	
	#use this to generate hidden values to maintain current query when submitting a form
	#this query is for modifying the number of results per page
	$url_query_minus_number_of_pages = 
		modify_url_vars( 
			$url_query, 
			$all_vars->filter_query->list_results_per_page, 
			' '
		);
		
	$small_input_size = text_input_size( "smallint" );
	
	#doing "weird" indenting to show table positions
	#start our display table here
	echo( "<table width=\"100%\">\n" );
		echo( "<tr>\n" );
			echo( "<td width=\"25%\">\n" );
				echo( "<table border=0 cellspacing=1 cellpadding=3>\n" );
					echo( "<tr>\n" );
						echo( "<td>\n" );
							echo( "$numbers_note\n" );
						echo( "</td>\n" );
					echo( "</tr>\n" );
					echo( "<tr>\n" );
						echo( "<td>\n" );
							echo( "<table width=180>" );
								echo( "<tr>\n" );
									echo( "<td width=20 align=center>\n" );
										echo( "$first_page\n" );
									echo( "</td>\n" );
									echo( "<td width=20 align=center>\n" );
										echo( "$previous_page\n" );
									echo( "</td>\n" );
									echo( "<td width=100 align=center>\n" );
										echo( "$navigator_note\n" );
									echo( "</td>\n" );
									echo( "<td width=20 align=center>\n" );
										echo( "$next_page\n" );
									echo( "</td>\n" );
									echo( "<td width=20 align=center>\n" );
										echo( "$last_page\n" );
									echo( "</td>\n" );
								echo( "</tr>\n" );
							echo( "</table>\n" );
						echo( "</td>\n" );
					echo( "</tr>\n" );
				echo( "</table>\n" );
			echo( "</td>\n" );
			echo( "<td width=\"50%\" align=center>\n" );
				echo( "<table border=0 cellspacing=1 cellpadding=3>\n" );
					echo( "<tr>\n" );
						echo( "<td align=center>\n" );
							echo( "<b>$total_results</b> total $result_string returned\n" );
						echo( "</td>\n" );
					echo( "</tr>\n" );
					echo( "<tr>\n" );
						echo( "<td align=center>\n" );
							echo( "Query date/time: $query_timestamp\n" );
						echo( "</td>\n" );
					echo( "</tr>\n" );
				echo( "</table>\n" );
			echo( "</td>\n" );
			echo( "<td width=\"25%\" align=right>\n" );
				echo( "<table border=0 cellspacing=1 cellpadding=3>\n" );
					echo( "<form action=\"" . $all_vars->pages[ "list" ] . "\">\n" );
					hidden_input_from_url( $url_query_minus_number_of_pages );
					echo( "<tr>\n" );
						echo( "<td align=right>\n" );
							echo( 
								"Results per page <input type=text name=\"results_per_page\" value=\"" . 
								$all_vars->results_per_page .
								"\" size=\"" . 
								$small_input_size . 
								"\">\n" 
							);
						echo( "</td>\n" );
					echo( "</tr>\n" );
					echo( "<tr>\n" );
						echo( "<td align=right>\n" );
							echo( "<input type=submit value=\"Re-display\">\n" );
						echo( "</td>\n" );
					echo( "</tr>\n" );
					echo( "</form>\n" );
				echo( "</table>\n" );
			echo( "</td>\n" );
		echo( "</tr>\n" );
	echo( "</table>\n" );
}

#############################################################################
#---remove any filters the user has requested be removed ---#################
#############################################################################
#---receives: 
#object containing all variables
#url to be modified
#---returns: modified url
#---globals: none
#---algorithm: look for all filters marked with "remove_filter" and remove them
#then remove all "remove_filter" variables from the url
function user_removed_filters( $all_vars, $url_query ){
	$query_vars = url_to_array( $url_query );
	
	$filters = array( 
		$all_vars->filter_query->filter_url_name, 
		$all_vars->filter_query->filter_is_isnt_name, 
		$all_vars->filter_query->filter_condition_name,
		$all_vars->filter_query->filter_text_name,
		$all_vars->filter_query->filter_and_or_name,
		'remove_filter'
	);
	
	#if user wants us to remove all filters, remove them from url
	if( isset( $query_vars[ 'remove_all_filters' ] ) ){
		
		foreach( $filters as $filter_key => $filter_name ){
			#dump_var( "1", $query_vars[ 'remove_filter' ] );
			if( isset( $query_vars[ $filter_name ] ) ){
				foreach( $query_vars[ $filter_name ] as $query_key => $query_value ){
					$url_query = modify_url_vars( 
						$url_query, 
						$filter_name . '[' . $query_key . ']',
						" "
					);
				}
			}
		}
		
		#also remove the "remove all filters" variable
		$url_query = modify_url_vars( $url_query, 'remove_all_filters', ' ' );
	
	#otherwise, if user wants some removed, remove only the selected filters
	} else if( 
		isset( $query_vars[ 'remove_filter' ] ) && 
		is_array( $query_vars[ 'remove_filter' ] )
	){
		foreach( $query_vars[ 'remove_filter' ] as $query_key => $query_value ){
			foreach( $filters as $filter_key => $filter_name ){
				$url_query = modify_url_vars( 
					$url_query, 
					$filter_name . '[' . $query_key . ']',
					" "
				);
			}
		}
	}
	
	return( $url_query );
}

#############################################################################
#---make sure any filters passed in the url query are valid ---##############
#############################################################################
#---receives: 
#---returns: 
#---globals: none
#---algorithm: pull all filter variables out of the url
#check them for correctness
#write only the valid ones back into the url, and return it
function validate_filters( $all_vars, $url_query ){
	$filter_url_name = $all_vars->filter_query->filter_url_name;
	$filter_is_isnt_name = $all_vars->filter_query->filter_is_isnt_name;
	$filter_condition_name = $all_vars->filter_query->filter_condition_name;
	$filter_text_name = $all_vars->filter_query->filter_text_name;
	$filter_and_or_name = $all_vars->filter_query->filter_and_or_name;
	
	$filters = array( 
		$filter_url_name, 
		$filter_is_isnt_name, 
		$filter_condition_name,
		$filter_text_name,
		$filter_and_or_name
	);
	
	#valid values for is_isnt filter
	$valid_is_isnt = array( 'does', 'does_not' );
	#valid values for condition filter
	$valid_condition = array(
		'equal_to',
		'null',
		'less_than',
		'greater_than',
		'before',
		'after',
		'start_with',
		'contain',
		'end_with'
	);
	#valid values for and_or filter
	$valid_and_or = array( 'and', 'or' );

	$query_vars = url_to_array( $url_query );
	
	#we will only add valid filters to this array, invalid will be excluded
	$valid_filters = array();
	
	#so now get all valid filters
	#make sure we have a filter array in our query url
	if( 
		array_key_exists( $filter_url_name, $query_vars ) && 
		is_array( $query_vars[ $filter_url_name ] ) 
	){
		$url_filters = $query_vars[ $filter_url_name ];
		$is_isnt_filters = $query_vars[ $filter_is_isnt_name ];
		$condition_filters = $query_vars[ $filter_condition_name ];
		$text_filters = $query_vars[ $filter_text_name ];
		$and_or_filters = $query_vars[ $filter_and_or_name ];
		
		#get information about columns 
		#so we can check whether filters make sense for the column type
		$column_info = get_field_info( 
			$all_vars->table_structure->database_name, 
			$all_vars->table . 
				$all_vars->table_structure->table_name_separator . 
				$all_vars->table_structure->assets_name 
		);
	
		#first filter does not contain 'and/or' rule, so this variable will keep track
		#of whether we are in the first filter or not
		$first_filter = 1;
		foreach( $url_filters as $index => $filter ){
			
			#make sure each of the filters for this index has a value
			#and that the value is a valid choice
			if(
				isset( $url_filters[ $index ] ) &&
					in_array( $url_filters[ $index ], $all_vars->column_names ) &&
				isset( $is_isnt_filters[ $index ] ) &&
					in_array( $is_isnt_filters[ $index ], $valid_is_isnt ) &&
				isset( $condition_filters[ $index ] ) &&
					in_array( $condition_filters[ $index ], $valid_condition ) &&
				isset( $text_filters[ $index ] )
			){
				
				#-----now do some logic/validity checks
				#like "less than" only works with integers, etc
				#we'll test if our filter logic has already failed for all tests after the first
				#this way we potentially save processing time for complex queries
				$filter_logic_ok = 1;
				
				#if it's not an int, but has filter "less_than" or "greater than"
				#then it's invalid
				if( 
					!preg_match( 
						"/^int/", 
						$column_info[ $url_filters[ $index ] . "-Type" ] 
					) &&
						( $condition_filters[ $index ] == 'less_than' ||
						$condition_filters[ $index ] == 'greater_than' )
				){
					$filter_logic_ok = 0;
				}
				
				#if it's not a date, but has filter "before" or "after"
				#then it's invalid
				if( $filter_logic_ok &&
					!preg_match( 
						"/^date/", 
						$column_info[ $url_filters[ $index ] . "-Type" ] 
					) &&
						( $condition_filters[ $index ] == 'after' ||
						$condition_filters[ $index ] == 'before' )
				){
					$filter_logic_ok = 0;
				}
				
				#if it's supposed to be a date but doesn't parse as one
				#then it's invalid
				if( $filter_logic_ok &&
					preg_match( 
						"/^date/", 
						$column_info[ $url_filters[ $index ] . "-Type" ] 
					) 
				){
					$parsed_time = strtotime( $text_filters[ $index ] );

					#couldn't parse date, so return invalid
					if( $parsed_time == -1 ){
						$filter_logic_ok = 0;
					
					#otherwise parse the date and change it in $query_vars to mysql date
					} else {
						$query_vars[ $filter_text_name ][ $index ] = 
							date( "Y-m-d", $parsed_time );
					}
				}

				#if it doesn't link to a subtable or isn't text, 
				#but has filter "start_with", "contain" or "end_with"
				#then it's invalid
				if( $filter_logic_ok &&
					!links_to_subtable(
						$all_vars->table . 
							$all_vars->table_structure->table_name_separator .
							$all_vars->table_structure->tabledefs_name,
						$url_filters[ $index ],
						$all_vars
					) &&
					!preg_match( 
						"/^text/", 
						$column_info[ $url_filters[ $index ] . "-Type" ] 
					) &&
						( $condition_filters[ $index ] == 'start_with' ||
						$condition_filters[ $index ] == 'contain' ||
						$condition_filters[ $index ] == 'end_with' )
				){
					$filter_logic_ok = 0;
				}
				
				#if it can't be null but the filter is "null"
				#then it's invalid
				if( $filter_logic_ok &&
					$column_info[ $url_filters[ $index ] . "-Null" ] != "YES" &&
					$condition_filters[ $index ] == 'null'
				){
					$filter_logic_ok = 0;
				}
				
				#allow plugins to do any logic checks they want to do
				$all_vars->hook_objects[ "filter_logic_ok" ] = $filter_logic_ok;
				$all_vars->hook_objects[ "url_filters" ] = $url_filters;
				$all_vars->hook_objects[ "is_isnt_filters" ] = $is_isnt_filters;
				$all_vars->hook_objects[ "condition_filters" ] = $condition_filters;
				$all_vars->hook_objects[ "text_filters" ] = $text_filters;
				$all_vars->hook_objects[ "and_or_filters" ] = $and_or_filters;
				$all_vars->hook_objects[ "index" ] = $index;
				$all_vars->hook_objects[ "filter" ] = $filter;
				$all_vars = do_hook( $all_vars, "after_validate_filter_checks" );
				
				#-----end of logic checks
				
				if( $all_vars->hook_objects[ "filter_logic_ok" ] ){
					#if we're null, clear out any criteria the user set in "text"/last box
					if( $condition_filters[ $index ] == 'null' ){
						$query_vars[ $filter_text_name ][ $index ] = "";
					}
				
					#if at first filter rule, trip $first_filter
					if( $first_filter ){
						$first_filter = 0;
						array_push( $valid_filters, $index );
						
						#note that we don't need to make sure the $and_or filter 
						#for this index is un-set, since if it's the first filter
						#any possible and_or filter won't be read
						#when the url is regenerated from $valid_filters and $query_vars
						
					#if not at first filter rule, also check for and_or
					} else {
						if( 
							isset( $and_or_filters[ $index ] ) && 
							in_array( $and_or_filters[ $index ], $valid_and_or )
						){
							array_push( $valid_filters, $index );
						}
					}
				}
			}
		}
	}
	
	#now remove all filters from the url
	foreach( $filters as $filter_key => $filter_name ){
		if( isset( $query_vars[ $filter_name ] ) ){
			foreach( $query_vars[ $filter_name ] as $query_key => $query_name ){
				$url_query = modify_url_vars( 
					$url_query, 
					$filter_name . '[' . $query_key . ']',
					" "
				);
			}
		}
	}

	#and re-add the valid ones which are in $valid_filters
	#the values in $valid_filters are indexes pointing to the valid filters in $query_vars
	foreach( $valid_filters as $index => $value ){
		#if this is not the first index, add the and/or
		if( $index != 0 ){
			$url_query = modify_url_vars(
				$url_query,
				$filter_and_or_name . '[' . $index . ']',
				$query_vars[ $filter_and_or_name ][ $value ]
			);
		}

		#add filter column, is_isnt, condition, text
		$url_query = modify_url_vars(
			$url_query,
			$filter_url_name . '[' . $index . ']',
			$query_vars[ $filter_url_name ][ $value ]
		);
		$url_query = modify_url_vars(
			$url_query,
			$filter_is_isnt_name . '[' . $index . ']',
			$query_vars[ $filter_is_isnt_name ][ $value ]
		);
		$url_query = modify_url_vars(
			$url_query,
			$filter_condition_name . '[' . $index . ']',
			$query_vars[ $filter_condition_name ][ $value ]
		);
		$url_query = modify_url_vars(
			$url_query,
			$filter_text_name . '[' . $index . ']',
			$query_vars[ $filter_text_name ][ $value ]
		);
	}
	
	return( $url_query );
}

#############################################################################
#---verify/modify the columns passed in our url ---##########################
#############################################################################
#---receives: 
#---returns: 
#---globals: none
#---algorithm: 
function verify_url_columns( $url_query, $all_vars ){

	$displayed_columns = array();
	$temp_array = array();
	$passed_url_array = parse_url( $url_query );
	parse_str( $passed_url_array[ "query" ], $query_vars );
	if( array_key_exists( "column", $query_vars ) ){
		$temp_array = $query_vars[ "column" ];
	}
	$column_position = 0;
	foreach( $temp_array as $c_name => $c_value ){
	
		#make sure the key values in "columns[]" are sequential integers
		#this is necessary to ensure that column deletes work properly
		#it is also "cleaner"
		#do this by deleting every "column[]" entry from the url
		#then re-add it with correct sequence number if it's valid
		$url_query = modify_url_vars( $url_query, "column[" . $c_name . "]", " " );

		if( in_array( $c_value, $all_vars->column_names ) && 
			!in_array( $c_value, $displayed_columns 
		) ){
			array_push( $displayed_columns, $c_value );
			$url_query = modify_url_vars( 
				$url_query, 
				"column[" . $column_position . "]", 
				$c_value 
			);
			$column_position++;
		}
	}
	
	#if no columns are specified, display all columns
	if( count( $displayed_columns ) == 0 ){
		#error_message( "No columns selected to display; displaying all" );
		$displayed_columns = $all_vars->column_names;
	
		#update url to include all columns
		foreach ( $displayed_columns as $c_name => $c_value ){
			#TODO: change this literal "column" to whatever it's supposed to be
			$url_query = modify_url_vars( $url_query, "column[" . $c_name . "]", $c_value );
		}
	}
	$number_of_columns = count( $displayed_columns );
	
	return( array( $url_query, $displayed_columns, $number_of_columns ) );
}

##########
#driver
##########

$all_vars = new all;

#put _GET variables into $all_vars object
$all_vars = copy_env_vars_to_object( $all_vars );

print_page_header( $all_vars, "asset list" );

#display the table containing all the asset information
do_list_selection( $all_vars );

#TODO: write current variable values to a cookie
#this allows us to return to the same column/sort view we were at when we left

print_page_footer( $all_vars );

?>
