<?php
##########
#display users in the permissions table "users"
##########

require_once( "./functions/include_all.php" );

##########
#variables to use throughout the script
##########

##########
#subroutines
##########

#############################################################################
#---show option to add a user ---############################################
#############################################################################
#---receives: object containing all variables
#---returns: 
#---globals: 
#---algorithm: 
function add_user( $all_vars ){
	$query_vars = url_to_array( $all_vars->this_request );

	#check if connected user is allowed to add users
	$sql_permissions_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "add" ],
		"users"
	);
	#if so, proceed
	if( mysql_num_rows( $sql_permissions_result ) > 0 ){

		#if we were passed "add_user" in query, try to add the user with supplied information
		if( isset( $query_vars[ "add_user" ] ) ){
			
			#check for set first name, last name, and user id
			#only first name may be blank, rest must contain data
			if( 
				isset( $query_vars[ "fname" ] ) &&
				isset( $query_vars[ "lname" ] ) &&
				$query_vars[ "lname" ] != "" &&
				isset( $query_vars[ "uid" ] ) &&
				$query_vars[ "uid" ] != ""
			){
				#check whether uid is duplicate; if so print error
				$uid_query = "\nSELECT * FROM `" . 
					$all_vars->table_structure->users_table . "` WHERE `" . 
					$all_vars->table_structure->users_uid . "`='" . 
					$query_vars[ "uid" ] . "'";
				$uid_results = mysql_query( $uid_query, $all_vars->table_structure->db );
				if( mysql_num_rows( $uid_results ) ){
					error_message( 
						"Could not add user: user id " . 
						$query_vars[ "uid" ] .
						" already exists" 
					);
				
				#otherwise, not duplicate, so add it
				} else {
					$insert_sql = "\nINSERT" . 
						"\nINTO `" . $all_vars->table_structure->users_table . "`(" . 
						"\n\t`" . $all_vars->table_structure->users_first_name . '`,' .
						"\n\t`" . $all_vars->table_structure->users_last_name . '`,' .
						"\n\t`" . $all_vars->table_structure->users_uid . '`' .
						"\n)" . 
						"\nVALUES (" .
						"\n\t'" . $query_vars[ "fname" ] . "'," .
						"\n\t'" . $query_vars[ "lname" ] . "'," .
						"\n\t'" . $query_vars[ "uid" ] . "'" .
						"\n)";
					$insert_result = mysql_query( $insert_sql );
					
					if( $insert_result ){
						echo( "<br>Added " . $query_vars[ "uid" ] . ".\n" );
					} else {
						error_message( "Could not add user: unknown error" );
					}
				}
			
			#if not found, complain
			} else {
				error_message( "Could not add user: information incomplete" );
			}
		}

		echo( "<form action=\"" . $all_vars->pages[ "users" ] .  "\">\n" );
		echo( "<input type=submit name=\"add_user\" value=\"Add user\">\n" );
		echo( "<br>&nbsp\n" );
		
		echo( "<table width=500>\n" );
		
		echo( "<tr height=30>\n" );
		echo( "<td width=150>\n" );
		echo( "first name:" );
		echo( "</td>\n" );
		echo( "<td width=350>\n" );
		echo( "<input type=text size=30 name=\"fname\">\n" );
		echo( "</td>\n" );
		echo( "</tr>\n" );
		
		echo( "<tr height=30>\n" );
		echo( "<td width=150>\n" );
		echo( "last name:" );
		echo( "</td>\n" );
		echo( "<td width=350>\n" );
		echo( "<input type=text size=30 name=\"lname\">\n" );
		echo( "</td>\n" );
		echo( "</tr>\n" );
		
		echo( "<tr height=30>\n" );
		echo( "<td width=150>\n" );
		echo( "user id:\n" );
		echo( "</td>\n" );
		echo( "<td width=350>\n" );
		echo( "<input type=text size=30 name=\"uid\">\n" );
		echo( "</td>\n" );
		echo( "</tr>\n" );
		
		echo( "</table>\n" );
		echo( "</form>\n" );
	} else {
		echo( "<br>You are not allowed to add any users.\n" );
	}
}

#############################################################################
#---show all active users ---################################################
#############################################################################
#---receives: object containing all variables
#---returns: 
#---globals: 
#---algorithm: 
function show_users( $all_vars ){
	$users_table = $all_vars->table_structure->users_table;
	$permissions_table = $all_vars->table_structure->permissions_table;
	$db = $all_vars->table_structure->db;
	$row_height = $all_vars->html_presets->row_height;
	
	$user_columns = $all_vars->acl_structure->user_columns;
	
	#see if user is allowed to view user information
	$user_view_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "view" ],
		"users"
	);
	$user_view_permission = mysql_num_rows( $user_view_result );

	#check if connected user is allowed to view the acl system
	$sql_permissions_result = verify_acl( 
		$all_vars->connected_user, 
		$all_vars->table_structure->permissions[ "view" ],
		"acl"
	);
	#if so, proceed
	if( mysql_num_rows( $sql_permissions_result ) > 0 || $user_view_permission ){

		#query the users table and see if anyone's in it
		$users_sql_query = 
			"\nSELECT *" .
			"\nFROM `$users_table`" .
			"\nORDER BY `last_name`";
		$users_sql_query_result = mysql_query( $users_sql_query, $db );
		#if so, can display them	
		if( mysql_num_rows( $users_sql_query_result ) > 0 ){
			
			echo( "<table border=0 cellspacing=1 cellpadding=3 width=620>\n" );
	
			echo( "<tr $row_height>\n" );
			echo( "<td width=20>\n" );
			echo( "&nbsp\n" );
			echo( "</td>\n" );
			echo( "<td width=200>\n" );
			echo( "<column_header>first name</column_header>\n" );
			echo( "</td>\n" );
			echo( "<td width=200>\n" );
			echo( "<column_header>last name</column_header>\n" );
			echo( "</td>\n" );
			echo( "<td width=200>\n" );
			echo( "<column_header>user id</column_header>\n" );
			echo( "</td>\n" );
			echo( "</tr>\n" );
			
			$row_number = 1;
			while( $users_row = mysql_fetch_array( $users_sql_query_result ) ){
				echo( "<tr $row_height>\n" );
				if( $row_number % 2 ){
					$background = $all_vars->html_presets->odd_row;
				} else {
					$background = $all_vars->html_presets->even_row;
				}
				$row_number++;
				
				foreach( $user_columns as $key => $value ){
					echo( "<td $background>\n" );
					if( $value == "id" ){
						echo( 
							"<a href=" . 
							$all_vars->pages[ "user_detail" ] . 
							"?id=" .
							$users_row[ $value ] .
							">" . 
							$all_vars->html_presets->drill_down_symbol . 
							"</a>" .
							"\n" );
					} else {
						if( $user_view_permission ){
							echo( $users_row[ $value ] . "\n" );
						} else {
							echo( "N/A\n" );
						}
					}
					echo( "</td>\n" );
				}
				
				echo( "</tr>\n" );
			}
			
			echo( "</table>\n" );
		} else {
			echo( "<br>No users in the system\n" );
		}
	
	#otherwise, not allowed to view the acl list; print an error
	} else {
		echo( "<br>You are not allowed to view the acl list.\n" );
	}
}

##########
#driver
##########

$all_vars = new all;

#put _GET variables into $all_vars object
$all_vars = copy_env_vars_to_object( $all_vars );

print_page_header( $all_vars, "edit users and permissions" );

add_user( $all_vars );

show_users( $all_vars );

print_page_footer( $all_vars );

?>
