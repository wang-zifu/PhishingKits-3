<?php
##########
#verify and commit changes to database structure
##########

require_once( "./functions/include_all.php" );

##########
#subroutines
##########

#############################################################################
#---delete one or more defaults columns---###################################
#############################################################################
#---receives: 
#object containing all data
#array containing names of defaults columns to be deleted
#name of dropdown we're modifing
#---returns: nothing
#---globals: 
#---algorithm: 
function delete_defaults( $all_vars, $delete_defaults_array, $modifying_dropdown ){
	$delete_message =  "<br>Deleting ";
	$mysql_query = 
		"\nALTER TABLE `" .
		$all_vars->table .
		$all_vars->table_structure->table_name_separator .
		$modifying_dropdown .
		"`";
	
	foreach( $delete_defaults_array as $id => $name ){
		$delete_message .= "\"$name\", ";
		$mysql_query .=
			"\n\tDROP COLUMN `default-" . 
			$name .
			"`,";
	}
	
	$plural = "";
	if( count( $delete_defaults_array ) > 1 ){
		$plural = "s";
	}
	$delete_message = rtrim( $delete_message, ", " );
	$delete_message .= 
		" column" . 
		$plural . 
		" from $modifying_dropdown in " .
		$all_vars->table .
		"\n";
	
	$mysql_query = rtrim( $mysql_query, "," );
	
	echo( $delete_message );
	
	$mysql_result = mysql_query( $mysql_query ) or $returned_error = 1;
	
	if( isset( $returned_error ) ){
		error_message( mysql_error() );
	} else {
		echo( "<br>Succeeded\n" );
	}
}

#############################################################################
#---delete one or more dropdown lines---#####################################
#############################################################################
#---receives: 
#object containing all data
#array containing ids and names of dropdown lines to delete
#name of dropdown we're modifing
#---returns: nothing
#---globals: 
#---algorithm: 
function delete_dropdowns( $all_vars, $delete_dropdowns_array, $modifying_dropdown ){
	$delete_message = "<br>Deleting ";
	$mysql_query = 
		"\nDELETE FROM `" .
		$all_vars->table .
		$all_vars->table_structure->table_name_separator .
		$modifying_dropdown .
		"`" . 
		"\nWHERE\t";
	
	foreach( $delete_dropdowns_array as $id => $name ){
		$delete_message .= "\"$name\", ";
		$mysql_query .= 
			"`" . 
			$all_vars->table_structure->id .
			"` = '" . 
			"$id' OR\n\t";
	}
	
	$plural = "";
	if( count( $delete_dropdowns_array ) > 1 ){
		$plural = "s";
	}
	$delete_message = rtrim( $delete_message, ", " );
	$delete_message .= 
		" dropdown line" . 
		$plural . 
		" from $modifying_dropdown in " . 
		$all_vars->table .
		"\n";
	
	$mysql_query = rtrim( $mysql_query, " OR\n\t" );
	
	echo( $delete_message );
	
	$mysql_result = mysql_query( $mysql_query ) or $returned_error = 1;
	
	if( isset( $returned_error ) ){
		error_message( mysql_error() );
	} else {
		echo( "<br>Succeeded\n" );
	}
}

#############################################################################
#---get column names that have default values for a dropdown---##############
#############################################################################
#---receives: 
#object containing all data
#dropdown subtable to look in
#---returns: 
#array containing the names of all column names with defaults in that subtable
#---globals: 
#---algorithm: use sql "SHOW FIELDS" to show all fields in dropdown table
#exclude id and name, remaining names should be defaults for columns
function get_dropdown_defaults( $all_vars, $modifying_dropdown ){
	#see what columns/defaults should be included as part of the new dropdown
	$mysql_fields_query = 
		"\nSHOW FIELDS FROM `" . 
		$all_vars->table .
		$all_vars->table_structure->table_name_separator .
		$modifying_dropdown .
		"`";
	$mysql_fields_result = mysql_query( $mysql_fields_query );
	$defaults_for_dropdown = array();
	
	#get all field names that aren't "id" or "name" and cut off the leading "default-"
	while( $fields_info = mysql_fetch_array( $mysql_fields_result ) ){
		if( $fields_info[ "Field" ] != "id" && $fields_info[ "Field" ] != "name" ){
			preg_match( '/^default-(.*)/', $fields_info[ "Field" ], $matches );
			array_push( $defaults_for_dropdown, $matches[ 1 ] );
		}
	}
	
	return( $defaults_for_dropdown );
}
		
#############################################################################
#---modify current defaults and dropdowns---#################################
#############################################################################
#---receives: 
#object containing all data
#array of dropdowns
#array of arrays containing default column names and default column values
#dropdown subtable to look in
#---returns: 
#---globals: 
#---algorithm: 
function modify_current_values( 
	$all_vars, $modify_current_dropdown, $modify_current_defaults, $modifying_dropdown
){
	$sql_error = 0;
	if( !$modify_current_dropdown ){
		$modify_current_dropdown = array();
	}
	foreach( $modify_current_dropdown as $row_id => $new_value ){
		echo( "<br>\n" );
		echo( "<br>Changing drop-down to " . $new_value . "\n" );
		
		$modify_sql = 
			"\nUPDATE `" . 
			$all_vars->table .
			$all_vars->table_structure->table_name_separator .
			$modifying_dropdown .
			"`\nSET `name` = '" . 
			$new_value .
			"' WHERE `" . 
			$all_vars->table_structure->id .
			"` = '" . 
			$row_id .
			"'";
		$modify_sql_result = mysql_query( $modify_sql ) or $returned_error = 1;
		if( isset( $returned_error ) ){
			error_message( mysql_error() );
			$sql_error = 1;
			break;
		} else {
			echo( "<br>Succeeded\n" );
		}
	}
	
	if( !$modify_current_defaults ){
		$modify_current_defaults = array();
	}
	if( !$sql_error ){
		foreach( $modify_current_defaults as $defaults_column_name => $current_defaults ){
			foreach( $current_defaults as $row_id => $new_value ){
				echo( "<br>\n" );
				echo( 
					"<br>Changing default in $defaults_column_name to " . $new_value . "\n" 
				);
				
				$modify_sql = 
					"\nUPDATE `" . 
					$all_vars->table .
					$all_vars->table_structure->table_name_separator .
					$modifying_dropdown .
					"`\nSET `default-" . 
					$defaults_column_name .
					"` = '" . 
					$new_value .
					"' WHERE `" . 
					$all_vars->table_structure->id .
					"` = '" . 
					$row_id .
					"'";
				$modify_sql_result = mysql_query( $modify_sql ) or $returned_error = 1;
				if( isset( $returned_error ) ){
					error_message( mysql_error() );
					$sql_error = 1;
					break( 2 );
				} else {
					echo( "<br>Succeeded\n" );
				}
			}
		}
	}
	
	if( $sql_error ){
		echo( "<br>Aborting; please verify the values in \"$modifying_dropdown\"" );
	}
}

#############################################################################
#---add a new defaults column---#############################################
#############################################################################
#---receives: 
#object containing all data
#string containing new default column name
#array containing all new default values
#name of dropdown we're modifing
#---returns: nothing
#---globals: 
#---algorithm: 
function new_default( $all_vars, $new_default, $new_default_array, $modifying_dropdown ){
	$new_default_type = $all_vars->field_info[ $new_default . "-Type" ];
	$new_default_type = strtoupper( $new_default_type );
	
	$add_column_sql = 
		"\nALTER TABLE `" . 
		$all_vars->table .
		$all_vars->table_structure->table_name_separator .
		$modifying_dropdown .
		"`\nADD `default-" . 
		$new_default .
		"` " . 
		$new_default_type .
		" NOT NULL";
	
	$add_column_result = mysql_query( $add_column_sql ) or $returned_error = 1;
	
	if( isset( $returned_error ) ){
		error_message( mysql_error() );
	} else {
		echo( 
			"<br>Successfully added defaults column \"$new_default\"" . 
			" to \"$modifying_dropdown\" in \"" .
			$all_vars->table .
			"\"\n"
		);
		
		#now we've added the column, we can add the default values
		foreach( $new_default_array as $row_id => $new_default_value ){
			$update_sql = 
				"\nUPDATE `" . 
				$all_vars->table .
				$all_vars->table_structure->table_name_separator .
				$modifying_dropdown .
				"`\nSET `default-" . 
				$new_default .
				"` = '" . 
				$new_default_value .
				"' WHERE `" . 
				$all_vars->table_structure->id .
				"` = '" . 
				$row_id .
				"'";
			
			$update_sql_result = mysql_query( $update_sql ) or $returned_error = 1;
			if( isset( $returned_error ) ){
				error_message( mysql_error() );
				echo( "<br>Aborting; please verify the values in \"$new_default\"" );
				break;
			} else {
				echo( "<br>Added default value: \"$new_default_value\"\n" );
			}
		}
	}
}

#############################################################################
#---add a new dropdown line---###############################################
#############################################################################
#---receives: 
#object containing all data
#string containing new dropdown value
#array containing any new default values in the new row
#name of dropdown we're modifing
#---returns: nothing
#---globals: 
#---algorithm: 
function new_dropdown( $all_vars, $new_dropdown, $new_dropdown_array, $modifying_dropdown ){
	$add_message = 
		"<br>Adding new dropdown value $new_dropdown to $modifying_dropdown in " . 
		$all_vars->table;
		"\n";
	$insert_sql =
		"\nINSERT INTO `" .
		$all_vars->table .
		$all_vars->table_structure->table_name_separator .
		$modifying_dropdown .
		"` (\n\t`" . 
		$all_vars->table_structure->id .
		"`,\n\t`name`,";
	$values_sql = "\nVALUES (\n\t'',\n\t'$new_dropdown',";
	
	foreach( $new_dropdown_array as $column_name => $new_default_value ){
		$add_message .= "<br>Additional default for \"$column_name\": \"$new_default_value\"\n";
		$insert_sql .= "\n\t`default-$column_name`,";
		$values_sql .= "\n\t'$new_default_value',";
	}
	
	$insert_sql = rtrim( $insert_sql, "," );
	$insert_sql .= "\n)";
	
	$values_sql = rtrim( $values_sql, "," );
	$values_sql .= "\n)";
	
	echo( $add_message );
	
	$mysql_result = mysql_query( $insert_sql . $values_sql ) or $returned_error = 1;
	
	if( isset( $returned_error ) ){
		error_message( mysql_error() );
	} else {
		echo( "<br>Succeeded\n" );
	}
}

#############################################################################
#---validate any requested defaults column deletes---########################
#############################################################################
#---receives: 
#object containing all data
#array containing query variables
#name of dropdown that we're modifying
#permission to make this modification (zero for no, non-zero for yes)
#---returns: 
#undefined if passed variable failed validation or no changes requested
#if any valid changes were requested
#	returns array containing defaults columns to delete
#---globals: 
#---algorithm: go through each non-id and non-name field from dropdown table
#if there's a matching "on" for this field in our passed variables
#add this field name to our array of fields marked for deletion
function validate_delete_defaults( $all_vars, $query_vars, $modifying_dropdown, $permission ){
	$table = $all_vars->table;
	$field_info = $all_vars->field_info;

	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	$db = $all_vars->table_structure->db;
	
	$delete_defaults_array = array();
	
	if( $permission ){
		#get all "default" column names in this subtable
		$defaults_for_dropdown = get_dropdown_defaults( $all_vars, $modifying_dropdown );
		
		foreach( $defaults_for_dropdown as $key => $defaults_name ){
			$variable_fragment = 
				$modifying_dropdown . 
				$table_name_separator . 
				$defaults_name .
				$table_name_separator .
				$all_vars->filter_query->structure_delete_defaults;
			if( 
				array_key_exists( $variable_fragment, $query_vars ) 
				&&
				$query_vars[ $variable_fragment ] == "on"
			){
				array_push( $delete_defaults_array, $defaults_name );
			}
		}
	} else {
		error_message( "No permission to delete defaults" );
	}
	
	if( count( $delete_defaults_array ) ){
		return( $delete_defaults_array );
	} else {
		return( NULL );
	}
}

#############################################################################
#---validate any requested dropdown row deletes---###########################
#############################################################################
#---receives: 
#object containing all data
#array containing query variables
#name of dropdown that we're modifying
#permission to make this modification (zero for no, non-zero for yes)
#---returns: 
#undefined if passed variable failed validation or no changes requested
#if any valid changes were requested
#	returns array containing dropdown row to delete
#---globals: 
#---algorithm: go through each name row from dropdown table
#if there's a matching "on" for this field in our passed variables
#*AND* there are no assets in our asset list that match this name
#add this field name to our array of fields marked for deletion
function validate_delete_dropdowns( $all_vars, $query_vars, $modifying_dropdown, $permission ){
	$table = $all_vars->table;
	$field_info = $all_vars->field_info;

	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	$db = $all_vars->table_structure->db;
	
	$delete_dropdowns_array = array();
	
	if( $permission ){
		#get all current ids and names from subtable
		$subtable_dropdowns_query =
			"\nSELECT `id`, `name` FROM `" . 
			$table . 
			$table_name_separator . 
			$modifying_dropdown . 
			"`";
		$subtable_dropdowns_result = mysql_query( $subtable_dropdowns_query, $db );
		
		#use this to keep track of errors; if there are errors, we will abort request
		#and return null
		$delete_contains_errors = 0;
		
		#go through each name/id
		while( $subtable_dropdowns_row = mysql_fetch_array( $subtable_dropdowns_result ) ){
			$current_id = $subtable_dropdowns_row[ "id" ];
			$current_name = $subtable_dropdowns_row[ "name" ];
			
			#see if passed url requested deletion for this dropdown
			if( 
				$query_vars[ 
					$modifying_dropdown . 
					$table_name_separator . 
					$all_vars->filter_query->structure_delete_dropdown
				][ $current_id ]
				==
				"on"
			){
				
				#look for any rows in the main asset table that have this id as a dropdown
				$dropdown_id_query = 
					"\nSELECT `id` FROM`" . 
					$table . 
					$table_name_separator . 
					$assets_name . 
					"` WHERE `$modifying_dropdown`='$current_id'";
				$dropdown_id_result = mysql_query( $dropdown_id_query, $db );
				$id_matches = mysql_num_rows( $dropdown_id_result );
				
				#if we have no id matches, can add to array marked for deletion
				if( !$id_matches ){
					$delete_dropdowns_array[ $current_id ] = $current_name;
				
				#otherwise, print error, break out of loop, unset $delete_dropdowns_array
				#since we'll abort on any errors
				} else {
					#make sure our grammar for the error message is correct!
					if( $id_matches == 1 ){
						$are_still_x_records = "is still 1 record";
						$these_records = "this record";
					} else {
						$are_still_x_records = "are still $id_matches records";
						$these_records = "these records";
					}
					
					error_message( 
						"You requested to delete $current_name from $modifying_dropdown " .
						"but there $are_still_x_records with this value. " .
						"Please re-assign $these_records to another dropdown value and try again"
					);
					unset( $delete_dropdowns_array );
					break;
				}
			}
		}
	} else {
		error_message( "No permission to delete dropdowns" );
	}
	
	if( count( $delete_dropdowns_array ) ){
		return( $delete_dropdowns_array );
	} else {
		return( NULL );
	}
}

#############################################################################
#---validate any requested modifications to existing dropdowns/defaults---###
#############################################################################
#---receives: 
#object containing all data
#array containing query variables
#name of dropdown that we're modifying
#permission to make this modification (zero for no, non-zero for yes)
#---returns: 
#undefined if passed variable failed validation or no changes requested
#if any valid changes were requested
#	1st returned element is an array of changes to the dropdown
#	2nd returned element is an array of arrays containing any changes to defaults
#	keys of 2nd returned are defaults column name, values are array of requested changes
#---globals: 
#---algorithm: 
function validate_modify_current( $all_vars, $query_vars, $modifying_dropdown, $permission ){
	$table = $all_vars->table;
	$field_info = $all_vars->field_info;

	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	$db = $all_vars->table_structure->db;
	
	$modify_current_dropdown = array();
	$modify_current_defaults = array();
	$modify_request_contains_errors = 0;

	if( $permission ){
		#get all "default" column names in this subtable
		$defaults_for_dropdown = get_dropdown_defaults( $all_vars, $modifying_dropdown );
		
		#get all values from this subtable
		#hold them in $subtable_info
		$subtable_info = array();
		$subtable_values_query =
			"\nSELECT * FROM `" . $table . $table_name_separator . $modifying_dropdown . "`";
		$subtable_values = mysql_query( $subtable_values_query, $db );
		while( $subtable_values_row = mysql_fetch_array( $subtable_values ) ){
			array_push( $subtable_info, $subtable_values_row );
		}
		
		$current_dropdowns_fragment = 
			$modifying_dropdown . 
			$table_name_separator . 
			$all_vars->filter_query->structure_current_dropdowns_array;
		
		#array to hold the passed dropdowns variable name and any defaults variable names
		$passed_fragments = array();
		#dropdowns variable name is automatically added
		$passed_fragments[ "dropdown" ] = $current_dropdowns_fragment;
		#now add any defaults variable names
		foreach( $defaults_for_dropdown as $key => $defaults_name ){
			$passed_fragments[ $defaults_name ] =  
				$modifying_dropdown . 
					$table_name_separator . 
					$defaults_name .
					$table_name_separator . 
					$all_vars->filter_query->structure_current_defaults_array;
		}
		
		foreach( $passed_fragments as $fragment_key => $current_fragment ){
			#if any of these fragments don't exist or have no assigned values
			#we'll return null for them
			if(
				array_key_exists( $current_fragment, $query_vars ) &&
				is_array( $query_vars[ $current_fragment ] ) &&
				count( $query_vars[ $current_fragment ] )
			){	
				$should_be_numeric = 0;
				$should_be_date = 0;
				
				#need to handle lookups, etc differently for dropdown vs all defaults columns
				if( $current_fragment == $current_dropdowns_fragment ){
					#use this to pick out the column in the subtable
					$column_header_name = "name";
				} else {
					#see if the dropdown's field type is numeric or a date
					#only do this if we're not looking at the dropdown values
					#since dropdown values are their own unique type
					if( ereg( "^int", $all_vars->field_info[ $fragment_key . "-Type" ] ) ){
						$should_be_numeric = 1;
					} else if( ereg( "^date", $all_vars->field_info[ $fragment_key . "-Type" ] ) ){
						$should_be_date = 1;
					}
					
					#use this to pick out the column in the subtable
					$column_header_name = "default-$fragment_key";
				}
				
				#check if a value different than the existing value in our subtable
				#has been passed
				
				#go through all values in the subtable for this column
				foreach( $subtable_info as $subtable_key => $subtable_row ){
					$subtable_id = $subtable_row[ "id" ];
					$subtable_value = $subtable_row[ $column_header_name ];
					
					#check if the given subtable column/id exists in the passed values
					if( 
						array_key_exists( 
							$subtable_id, 
							$query_vars[ $current_fragment ] 
						) 
					){
						$passed_value = 
							$query_vars[ $current_fragment ][ $subtable_id ];
						
						#check if the given subtable column/id is different than passed value
						if( $passed_value != $subtable_value ){
						
							#do type checks if we weren't passed a blank value
							#(we want to always allow blank for default values)
							#and we're not checking a dropdown
							#(dropdowns can have any value, since they're their own type)
							if( 
								$passed_value 
								&& 
								( $current_fragment != $current_dropdowns_fragment )
							){
								if( $should_be_numeric &! is_numeric( $passed_value ) ){
									error_message( 
										"You supplied a non-numeric default where only integers are allowed" 
									);
									$modify_request_contains_errors = 1;
									break( 2 );
								} else if( $should_be_date ){
									$parsed_date = strtotime( $passed_value );
									if( $parsed_date == -1 ){
										error_message( 
											"You supplied a non-date default where only dates are allowed" 
										);
										$modify_request_contains_errors = 1;
										break( 2 );
									
									#if the date parsed and is non-blank
									#convert it to canonical sql format
									} else {
										
										if( $passed_value ){
											$query_vars[ $current_fragment ][ $subtable_id ] = 
												date( "Y-m-d", $parsed_date );
										}
									}
								}
							}
							
							#if we got to this point, can add to the change array
							#the break statements above will ensure that we won't get
							#to this point unless everything is ok
							#if it's a dropdown, add to $modify_current_dropdown
							if( $current_fragment == $current_dropdowns_fragment ){
								$modify_current_dropdown[ $subtable_id ] = 
									$passed_value;
							
							#otherwise it's a default, so add to $modify_current_defaults
							} else {
								#if we don't already have this array in the modify array
								#add it
								if( 
									!array_key_exists( $fragment_key, $modify_current_defaults ) 
								){
									$modify_current_defaults[ $fragment_key ] = array();
								}
								$modify_current_defaults[ $fragment_key ][ $subtable_id ] =
									$passed_value;
							}
						}
					}
				}
			}
		}
	} else {
		error_message( "No permission to modify dropdowns or defaults" );
	}
	
	if( !count( $modify_current_dropdown ) || $modify_request_contains_errors ){
		$modify_current_dropdown = NULL;
	}
	if( !count( $modify_current_defaults ) || $modify_request_contains_errors ){
		$modify_current_defaults = NULL;
	}
	return( array( $modify_current_dropdown, $modify_current_defaults ) );
}
	
#############################################################################
#---validate any "new default" variable we were passed---####################
#############################################################################
#---receives: 
#object containing all data
#array containing query variables
#name of dropdown that we're modifying
#permission to make this modification (zero for no, non-zero for yes)
#---returns: 
#undefined if passed variable failed validation or no changes requested
#the passed "new default" variable plus "new defaults array" if it passed validation
#---globals: 
#---algorithm: 
function validate_new_default( $all_vars, $query_vars, $modifying_dropdown, $permission ){
	$table = $all_vars->table;
	$field_info = $all_vars->field_info;

	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	$db = $all_vars->table_structure->db;
	
	if( $permission ){
		$new_default_fragment = 
			$modifying_dropdown . 
			$table_name_separator . 
			$all_vars->filter_query->structure_new_default;
		
		$new_default_array_fragment = 
			$modifying_dropdown . 
			$table_name_separator . 
			$all_vars->filter_query->structure_new_default_array;
		
		#we'll return null if the "New_default" part of the submitted variables doesn't exist
		#or contains no value
		if( 
			array_key_exists( $new_default_fragment, $query_vars ) &&
			isset( $query_vars[ $new_default_fragment ] )
		){
			$new_default = $query_vars[ $new_default_fragment ];
			
			#check that the "New_Default" value is actually a column
			if( in_array( $new_default, $all_vars->column_names ) ){
				
				#check that the "New_Default" value is not a dropdown or unique value
				if( 
					!links_to_subtable( 
						$table . $table_name_separator . $tabledefs_name, 
						$new_default,
						$all_vars)
					&&
					!check_uniqueness(
						$all_vars->field_info[ $new_default . "-Key" ],
						$all_vars,
						$new_default,
						#pass a blank value here; we're not checking for a conflicting value
						"")
				){
				#TODO: verify that the defaults column isn't already present
				
					#checking that fields that are supposed to be dates or integers really are
					#also making sure that there's at least one default in the default vals array
					
					#first see if the default's field type is numeric or a date
					if( ereg( "^int", $all_vars->field_info[ $new_default . "-Type" ] ) ){
						$should_be_numeric = 1;
					} else if( ereg( "^date", $all_vars->field_info[ $new_default . "-Type" ] ) ){
						$should_be_date = 1;
					}
					
					#set some flags
					$default_array_contains_errors = 0;
					$default_array_is_empty = 1;
		
					foreach( $query_vars[ $new_default_array_fragment ] as $key => $value ){
						if( $value ){
							$default_array_is_empty = 0;
						}
						
						if( $should_be_numeric &! is_numeric( $value ) ){
							error_message( 
								"You supplied a non-numeric value where only integers are allowed" 
							);
							unset( $new_default );
							$default_array_contains_errors = 1;
							break;
						} else if( $should_be_date ){
							
							$parsed_date = strtotime( $value );
							
							if( $parsed_date == -1 ){
								error_message( 
									"You supplied a non-date where only dates are allowed" 
								);
								unset( $new_default );
								$default_array_contains_errors = 1;
								break;
								
							#if date parses ok, canonify it to standard sql date format
							} else {
								if( $value ){
									$query_vars[ $new_default_array_fragment ][ $key ] =
										date( "Y-m-d", $parsed_date);
								}
							}
						}
						#dump_var( "current_values", $query_vars[ $new_default_array_fragment ][ $key ] );
					}
					
					#make sure that our array of default values contains at least one value
					if( $default_array_is_empty &! $default_array_contains_errors ){
						error_message( "At least one default must be provided" );
						unset( $new_default );
					} else {
						$new_default_array = $query_vars[ $new_default_array_fragment ];
					}
				
				} else {
					error_message( "$new_default is a drop-down or unique field type; cannot use" );
					unset( $new_default );
				}
			
			} else {
				#sometimes a blank default will be passed; if so it is probably the html
				#select form providing it, so don't echo an error
				if( $new_default ){
					error_message( "$new_default is not a valid column name" );
				}
				
				#if $new_default_array has values but $new_default is not set
				#print an error, since we can't add new defaults without knowing the new column
				foreach( $query_vars[ $new_default_array_fragment ] as $key => $value ){
					if( $value ){
						error_message( "Can't specify new default values without specifying a new default column name" );
						break;
					}
				}
				
				unset( $new_default );
			}
		}
	} else {
		error_message( "No permission to add new defaults" );
	}
	
	if( isset( $new_default ) ){
		return( array( $new_default, $new_default_array ) );
	} else {
		return( NULL );
	}
}

#############################################################################
#---validate any "new dropdown" variable we were passed---###################
#############################################################################
#---receives: 
#object containing all data
#array containing query variables
#name of dropdown that we're modifying
#permission to make this modification (zero for no, non-zero for yes)
#---returns: 
#undefined if passed variable failed validation or no changes requested
#the passed "new dropdown" variable plus "new dropdowns" variables if it passed validation
#---globals: 
#---algorithm: 
function validate_new_dropdown( $all_vars, $query_vars, $modifying_dropdown, $permission ){
	$table = $all_vars->table;
	$field_info = $all_vars->field_info;

	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	$db = $all_vars->table_structure->db;
	
	if( $permission ){
		$new_dropdown_fragment = 
			$modifying_dropdown . 
			$table_name_separator . 
			$all_vars->filter_query->structure_new_dropdown;
		$defaults_for_dropdown = get_dropdown_defaults( $all_vars, $modifying_dropdown );
		
		#we'll return null if the "New_dropdown" part of the submitted variables doesn't exist
		#or contains no value
		if( 
			array_key_exists( $new_dropdown_fragment, $query_vars ) &&
			$query_vars[ $new_dropdown_fragment ] != ''
		){
			$new_dropdown = $query_vars[ $new_dropdown_fragment ];
			$parse_errors = 0;
			
			#use this to hold any defaults that come with the new dropdown
			$new_dropdown_array = array();
			
			#now go through each new possible default
			#if the default exists in our query url, verify that its values are acceptable
			foreach( $defaults_for_dropdown as $key => $default_name ){
				$new_default_fragment = 
					$modifying_dropdown . 
					$table_name_separator .
					$default_name .
					$table_name_separator .
					$all_vars->filter_query->structure_new_default;
				if( 
					array_key_exists( $new_default_fragment, $query_vars ) &&
					isset( $query_vars[ $new_default_fragment ] )
				){
					#dump_var( "$default_name", $query_vars[ $new_default_fragment ] );
					#see if the default's field type is numeric or a date
					if( 
						ereg( "^int", $all_vars->field_info[ $default_name . "-Type" ] ) 
					){
					
						#if supposed to be numeric but isn't, give error
						if( 
							!is_numeric( $query_vars[ $new_default_fragment ] ) &&
							( $query_vars[ $new_default_fragment ] )
						){
							error_message( 
								"Expecting numeric value for new default $default_name" 
							);
							$parse_errors = 1;
							break;
						}
					} else if( 
						ereg( "^date", $all_vars->field_info[ $default_name . "-Type" ] ) 
					){
					
						#if supposed to be a date but isn't, give error
						if( 
							strtotime( $query_vars[ $new_default_fragment ] ) == -1 &&
							( $query_vars[ $new_default_fragment ] )
						){
							error_message( 
								"Expecting a date for new default $default_name" 
							);
							$parse_errors = 1;
							break;
						
						#if date parses ok, canonify it to standard sql date format
						} else {
							$query_vars[ $new_default_fragment ] = 
								date( 
									"Y-m-d",
									strtotime( $query_vars[ $new_default_fragment ] )
								);
						}
					}
					
					#if no parse errors up to this point, can add to $new_dropdown_array
					if( !$parse_errors ){
						$new_dropdown_array[ $default_name ] = 
							$query_vars[ $new_default_fragment ];
					}
				}
			}
			
			
			if( $parse_errors ){
				unset( $new_dropdown );
			}
		
		#if the new dropdown name is empty but we were given new dropdown default values
		#give error, since we can't add a dropdown default without a parent dropdown
		} else {
			foreach( $defaults_for_dropdown as $key => $default_name ){
				$new_default_fragment = 
					$modifying_dropdown . 
					$table_name_separator .
					$default_name .
					$table_name_separator .
					$all_vars->filter_query->structure_new_default;
				if( 
					array_key_exists( $new_default_fragment, $query_vars ) &&
					$query_vars[ $new_default_fragment ] != ''
				){
					error_message( "Can't specify new default values for a dropdown without specifying a new dropdown" );
					break;
				}
			}
		}
	} else {
		error_message( "No permission to add a new dropdown" );
	}
	
	if( isset( $new_dropdown ) ){
		return( array( $new_dropdown, $new_dropdown_array ) );
	} else {
		return( NULL );
	}
}

#############################################################################
#---verify that the change commands we received are logical, etc---##########
#############################################################################
#---receives: object containing all data
#---returns: 
#---globals: 
#---algorithm: 
function verify_passed_vars( $all_vars ){
	$table = $all_vars->table;
	$table_name_separator = $all_vars->table_structure->table_name_separator;
	$assets_name = $all_vars->table_structure->assets_name;
	$structure_name = $all_vars->table_structure->structure_name;
	$tabledefs_name = $all_vars->table_structure->tabledefs_name;
	
	#pull any queries from url into array $query_vars
	$query_vars = url_to_array( $all_vars->this_request );
	
	#first make sure our table is valid
	if( isset( $table ) ){
	
		#then get all permissions for the connected user on this table's structure
		$sql_modify_result = verify_acl( 
			$all_vars->connected_user, 
			$all_vars->table_structure->permissions[ "modify" ],
			$table . $table_name_separator . $assets_name . $table_name_separator . $structure_name
		);
		$modify_permission = mysql_num_rows( $sql_modify_result );

		$sql_add_result = verify_acl( 
			$all_vars->connected_user, 
			$all_vars->table_structure->permissions[ "add" ],
			$table . $table_name_separator . $assets_name . $table_name_separator . $structure_name
		);
		$add_permission = mysql_num_rows( $sql_add_result );

		$sql_delete_result = verify_acl( 
			$all_vars->connected_user, 
			$all_vars->table_structure->permissions[ "delete" ],
			$table . $table_name_separator . $assets_name . $table_name_separator . $structure_name
		);
		$delete_permission = mysql_num_rows( $sql_delete_result );
		
		#and only proceed if the user has one or more permissions
		if( $add_permission || $modify_permission || $delete_permission ){
			
			#get all column names from database
			#TODO: make this automatic; maybe as part of the constructor?
			$all_vars->column_names = calculate_column_names( $all_vars );
			
			#get field info
			#TODO: make this part of constructor?
			$all_vars->field_info = get_field_info( 
				$all_vars->table_structure->database_name, 
				$table . $table_name_separator . $assets_name 
			);
			
			#make sure we know which dropdown we're supposed to be modifying
			if( isset( $query_vars[ "modifying_dropdown" ] ) ){
				
				$modifying_dropdown = $query_vars[ "modifying_dropdown" ];
				
				#if it's a valid dropdown, proceed
				if( 
					links_to_subtable( 
						$table . $table_name_separator . $tabledefs_name, 
						$modifying_dropdown,
						$all_vars
					) 
				){
					
					#generate arrays/variables containing all proposed changes
					#if a requested change contains an error or is not allowed
					#it will not be put into any of these variables
					list( $modify_current_dropdown, $modify_current_defaults ) = 
						validate_modify_current( 
							$all_vars, $query_vars, $modifying_dropdown, $modify_permission
						);
					list( $new_default, $new_default_array ) = 
						validate_new_default( 
							$all_vars, $query_vars, $modifying_dropdown, $add_permission
						);
					list( $new_dropdown, $new_dropdown_array ) = 
						validate_new_dropdown( 
							$all_vars, $query_vars, $modifying_dropdown, $add_permission
						);
					$delete_dropdowns_array = 
						validate_delete_dropdowns( 
							$all_vars, $query_vars, $modifying_dropdown, $delete_permission
						);
					$delete_defaults_array = 
						validate_delete_defaults( 
							$all_vars, $query_vars, $modifying_dropdown, $delete_permission
						);
					
					#in case all modify attempts failed, we will set this
					$unknown_action = 0;
					
					$continue_phrase = "";
					$continue_url = 
						modify_url_vars( 
							$all_vars->pages[ "structure" ], 
							"dropdown_modify",
							$modifying_dropdown
						);
					$continue_url =
						modify_url_vars(
							$continue_url,
							$assets_name,
							$table
						);
					
					#make sure we don't have request overlap
					#for example, if we're modifying dropdowns/defaults
					#we shouldn't be able to simultaneoulsy add/delete structure
					#precedence is: 
					#	modify existing values
					#	add new defaults column
					#	add new dropdown
					#	delete dropdown
					#	delete defaults column
					#TODO: make this more elegant!
					#maybe some kind of hash for walking down the current + set list
					#--------handling:---------
					#first: modify existing values
					if( isset( $modify_current_dropdown ) || isset( $modify_current_defaults ) ){
						if( isset( $new_default ) ){
							error_message( "Ignoring requested new default because we are already modifying" );
						}
						if( isset( $new_dropdown ) ){
							error_message( "Ignoring requested new dropdown because we are already modifying" );
						}
						if( isset( $delete_dropdowns_array ) ){
							error_message( "Ignoring requested delete of dropdowns array because we are already modifying" );
						}
						if( isset( $delete_defaults_array ) ){
							error_message( "Ignoring requested delete of defaults array because we are already modifying" );
						}
						modify_current_values(
							$all_vars,
							$modify_current_dropdown,
							$modify_current_defaults,
							$modifying_dropdown
						);
						
						$continue_phrase = "editing existing values";
						$continue_url =
							modify_url_vars(
								$continue_url,
								"subtable_modify",
								"1"
							);
					#second: add new defaults column
					} else if( isset( $new_default ) ){
						if( isset( $new_dropdown ) ){
							error_message( "Ignoring requested new dropdown because we are already adding a default" );
						}
						if( isset( $delete_dropdowns_array ) ){
							error_message( "Ignoring requested delete of dropdowns array because we are already adding a default" );
						}
						if( isset( $delete_defaults_array ) ){
							error_message( "Ignoring requested delete of defaults array because we are already adding a default" );
						}
						new_default(
							$all_vars,
							$new_default,
							$new_default_array,
							$modifying_dropdown
						);
						
						$continue_phrase = "adding new defaults";
						$continue_url =
							modify_url_vars(
								$continue_url,
								"subtable_add_default",
								"1"
							);
					#third: add new dropdown
					} else if( isset( $new_dropdown ) ){
						if( isset( $delete_dropdowns_array ) ){
							error_message( "Ignoring requested delete of dropdowns array because we are already adding a new dropdown" );
						}
						if( isset( $delete_defaults_array ) ){
							error_message( "Ignoring requested delete of defaults array because we are already adding a new dropdown" );
						}
						new_dropdown(
							$all_vars, 
							$new_dropdown, 
							$new_dropdown_array, 
							$modifying_dropdown 
						);
						
						$continue_phrase = "adding new dropdowns";
						$continue_url =
							modify_url_vars(
								$continue_url,
								"subtable_add_dropdown",
								"1"
							);
					#fourth: delete dropdown
					} else if( isset( $delete_dropdowns_array ) ){
						if( isset( $delete_defaults_array ) ){
							error_message( "Ignoring requested delete of defaults array because we are already deleting a dropdown" );
						}
						delete_dropdowns( 
							$all_vars, $delete_dropdowns_array, $modifying_dropdown 
						);
						
						$continue_phrase = "deleting dropdowns";
						$continue_url =
							modify_url_vars(
								$continue_url,
								"subtable_delete_dropdown",
								"1"
							);
					#fifth: delete defaults column
					} else if( isset( $delete_defaults_array ) ){
						delete_defaults( 
							$all_vars, $delete_defaults_array, $modifying_dropdown 
						);
						
						$continue_phrase = "deleting defaults";
						$continue_url =
							modify_url_vars(
								$continue_url,
								"subtable_delete_default",
								"1"
							);
					#if none of these occurred, will set error flag
					} else {
						$unknown_action = 1;
					}
					
					echo( "<br>&nbsp\n" );
					if( $unknown_action ){
						error_message( "Unknown, blank, or invalid input" );
						echo(
							"<br>Please hit your browser's \"back\" button and try again.\n" 
						);
					} else {
						echo( 
							"<br>You may click <a href=\"" . 
							$continue_url .
							"\">here</a> to continue $continue_phrase.\n" 
						);
					}
					echo( "<br>&nbsp\n" );
					
				} else {
					error_message( "Selected dropdown does not exist" );
				}
			
			} else {
				error_message( "No dropdown selected" );
			}
			
		} else {
			error_message( "No permissions on $table or it is not a valid table" );
		}
	} else {
		error_message( "No table selected" );
	}
}

##########
#driver
##########

$all_vars = new all;

#put _GET variables into $all_vars object
$all_vars = copy_env_vars_to_object( $all_vars );

print_page_header( $all_vars, "modifying table structure" );

verify_passed_vars( $all_vars );

print_page_footer( $all_vars );

?>
