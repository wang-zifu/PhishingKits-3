<?php
##########
#display entries in a database
##########

require_once( "./functions/include_all.php" );

##########
#variables to use throughout the script
##########

##########
#subroutines
##########

##########
#driver
##########

$all_vars = new all;

print_page_header( $all_vars, "main page" );

#display widget for listing assets
pick_table( $all_vars, "view", "list", 1 );

#display option for adding assets
pick_table( $all_vars, "add", "add", 1 );

#display option for modifying asset structure
pick_table( $all_vars, "view", "structure", 1 );

print_page_footer( $all_vars );

?>
