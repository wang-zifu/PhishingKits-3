-- phpMyAdmin SQL Dump
-- version 2.6.0-pl2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Server version: 4.0.15
-- PHP Version: 4.3.9
-- 
-- Database: `inventory`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `site_notes`
-- 

CREATE TABLE `site_notes` (
  `note_id` int(11) NOT NULL auto_increment,
  `note_title` varchar(200) NOT NULL default '',
  `note_body` text NOT NULL,
  `note_relation` int(11) NOT NULL default '0',
  `note_type` int(1) NOT NULL default '0',
  `note_post_date` int(11) NOT NULL default '0',
  `note_post_ip` varchar(20) NOT NULL default '',
  `note_post_user` int(11) NOT NULL default '0',
  PRIMARY KEY  (`note_id`)
) TYPE=MyISAM AUTO_INCREMENT=11 ;

-- 
-- Dumping data for table `site_notes`
-- 

INSERT INTO `site_notes` VALUES (8, 'Service Improved', 'The service has improved.', 1, 1, 1106769888, '172.20.100.3', 1);
INSERT INTO `site_notes` VALUES (9, 'Another Note', 'This supplier has become somewhat less reliable, move to B list.\r\n', 1, 1, 1106769957, '172.20.100.3', 1);
INSERT INTO `site_notes` VALUES (10, 'Product Note', 'This is the first note for this product.', 1, 2, 1106773231, '172.20.100.3', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `site_products`
-- 

CREATE TABLE `site_products` (
  `product_id` int(11) NOT NULL auto_increment,
  `product_name` varchar(200) NOT NULL default '',
  `product_number` varchar(20) NOT NULL default '',
  `product_count` varchar(10) NOT NULL default '',
  `product_description` text NOT NULL,
  `product_vendor` int(11) NOT NULL default '0',
  PRIMARY KEY  (`product_id`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `site_products`
-- 

INSERT INTO `site_products` VALUES (1, 'Product 1', '1132-3C', '934', 'Here is the description.', 1);
INSERT INTO `site_products` VALUES (2, 'Widget C', '55-8556', '10', 'Widgets from XYZ', 3);

-- --------------------------------------------------------

-- 
-- Table structure for table `site_suppliers`
-- 

CREATE TABLE `site_suppliers` (
  `sup_id` int(11) NOT NULL auto_increment,
  `sup_name` varchar(100) NOT NULL default '',
  `sup_contact_name` varchar(100) NOT NULL default '',
  `sup_contact_phone` varchar(50) NOT NULL default '',
  `sup_contact_phone2` varchar(50) NOT NULL default '',
  `sup_web` varchar(200) NOT NULL default '',
  `sup_email` varchar(200) NOT NULL default '',
  `sup_other` text NOT NULL,
  PRIMARY KEY  (`sup_id`)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `site_suppliers`
-- 

INSERT INTO `site_suppliers` VALUES (1, 'Test Supplier', 'Jon Doe', '174283740132', '432509348', 'http://google.com', 'email@nowhere.com', 'Here will be other details regarding this supplier');

-- --------------------------------------------------------

-- 
-- Table structure for table `site_trans`
-- 

CREATE TABLE `site_trans` (
  `trans_id` int(11) NOT NULL auto_increment,
  `trans_product` int(11) NOT NULL default '0',
  `trans_user` int(11) NOT NULL default '0',
  `trans_date` int(11) NOT NULL default '0',
  `trans_date2` int(11) NOT NULL default '0',
  `trans_description` text NOT NULL,
  `trans_inventory` int(11) NOT NULL default '0',
  PRIMARY KEY  (`trans_id`)
) TYPE=MyISAM AUTO_INCREMENT=9 ;

-- 
-- Dumping data for table `site_trans`
-- 

INSERT INTO `site_trans` VALUES (1, 1, 1, 1106776186, 1106690400, 'test', -12);
INSERT INTO `site_trans` VALUES (2, 1, 1, 1106776548, 1106690400, 'asdf asdf asdf', 23);
INSERT INTO `site_trans` VALUES (3, 1, 1, 1106854220, 1106802000, 'returned item.', 1);
INSERT INTO `site_trans` VALUES (4, 1, 1, 1106854258, 1106802000, 'sold to xyz', -34);
INSERT INTO `site_trans` VALUES (5, 2, 1, 1106854555, 1106802000, 'first order arrived.', 100);
INSERT INTO `site_trans` VALUES (6, 2, 1, 1106863344, 1106802000, 'test', 50);
INSERT INTO `site_trans` VALUES (7, 1, 1, 1106863358, 1106802000, 'New shipment arrived.', 50);
INSERT INTO `site_trans` VALUES (8, 1, 1, 1107876456, 1107838800, 'shipment from Egypt', 10);

-- --------------------------------------------------------

-- 
-- Table structure for table `site_users`
-- 

CREATE TABLE `site_users` (
  `user_id` int(11) NOT NULL auto_increment,
  `user_login` varchar(30) NOT NULL default '',
  `user_password` varchar(30) NOT NULL default '',
  `user_name` varchar(200) NOT NULL default '',
  `user_address` varchar(200) NOT NULL default '',
  `user_city` varchar(100) NOT NULL default '',
  `user_state` char(3) NOT NULL default '',
  `user_zip` varchar(20) NOT NULL default '',
  `user_country` char(3) NOT NULL default '',
  `user_phone` varchar(39) NOT NULL default '',
  `user_email` varchar(200) NOT NULL default '',
  `user_email2` varchar(200) NOT NULL default '',
  `user_im_aol` varchar(100) NOT NULL default '',
  `user_im_icq` varchar(100) NOT NULL default '',
  `user_im_msn` varchar(100) NOT NULL default '',
  `user_im_yahoo` varchar(100) NOT NULL default '',
  `user_im_other` varchar(200) NOT NULL default '',
  `user_status` int(1) NOT NULL default '0',
  `user_level` int(1) NOT NULL default '0',
  `user_pending` int(11) NOT NULL default '0',
  `user_date` int(11) NOT NULL default '0',
  PRIMARY KEY  (`user_id`)
) TYPE=MyISAM PACK_KEYS=0 AUTO_INCREMENT=1004 ;

-- 
-- Dumping data for table `site_users`
-- 

INSERT INTO `site_users` VALUES (1, 'admin', 'test', 'Site Admin', '', '', '', '', '', '', 'admin@example.com', '', '', '', '', '', '', 0, 0, 0, 0);
INSERT INTO `site_users` VALUES (1003, 'John', 'test', 'John Doe', '2557 S Dennison Court', 'Denver', 'CO', '80222', 'US', '313-757-5555', 'jdoe@example.com', 'jdoe@example.com', 'aol', 'icq', 'msn', 'yahoo', 'other', 0, 1, 0, 1106772292);

-- --------------------------------------------------------

-- 
-- Table structure for table `site_vars`
-- 

CREATE TABLE `site_vars` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(200) NOT NULL default '',
  `value` text NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=36 ;

-- 
-- Dumping data for table `site_vars`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `site_vendors`
-- 

CREATE TABLE `site_vendors` (
  `vendor_id` int(11) NOT NULL auto_increment,
  `vendor_name` varchar(200) NOT NULL default '',
  PRIMARY KEY  (`vendor_id`)
) TYPE=MyISAM AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `site_vendors`
-- 

INSERT INTO `site_vendors` VALUES (1, 'Vendor 1');
INSERT INTO `site_vendors` VALUES (3, 'Vendor 2');
