<?php
function DoEvents($that) {
	global $_CONF , $_TSM , $base;

	$_TSM["MENU"] = "";

	//checking if user is logged in
	if (!$_SESSION["minibase"]["user"]) {
		if ($_SERVER["REQUEST_METHOD"] == "POST") {

			//autentificate
			$user = $that->db->QFetchArray("select * from {$that->tables[users]} where `user_login` = '{$_POST[user]}' AND `user_password` = '{$_POST[pass]}'");

			if (is_array($user)) {
				$_SESSION["minibase"]["user"] = 1;
				$_SESSION["minibase"]["raw"] = $user;

				//redirecting to view sites
				header("Location: $_CONF[default_location]");
				exit;
			} else
				return $that->templates["login"]->blocks["Login"]->output;

		} else
			return $that->templates["login"]->blocks["Login"]->output;
	}
	if ($_SESSION["minibase"]["raw"]["user_level"] == 0) {
		$_TSM["MENU"] = $that->templates["login"]->blocks["MenuAdmin"]->output;
	} else {
		$_TSM["MENU"] = $that->templates["login"]->blocks["MenuUser"]->output;
	}

	if (!$_POST["task_user"])
		$_POST["task_user"] = $_SESSION["minibase"]["user"];

	if($_SESSION["minibase"]["raw"]["user_level"] == 1) {
		$_CONF["forms"]["adminpath"] = $_CONF["forms"]["userpath"];
	}

	switch ($_GET["sub"]) {
		case "logout":
			unset($_SESSION["minibase"]["user"]);
			header("Location: index.php");

			return $that->templates["login"]->EmptyVars();
		break;

		case "notes":
		case "transactions":
		case "products":
		case "vendors":
		case "suppliers":
		case "workers":
		case "users":

			if ($_GET["sub"] == "workers") {
				if ((!$_GET["action"])&&($_SESSION["minibase"]["raw"]["user_level"] != 0 )) {
					$_GET["action"] = "details";				
				}

				if ($_SESSION["minibase"]["raw"]["user_level"] == 1) {
					$_GET["user_id"] = $_SESSION["minibase"]["raw"]["user_id"]; 
					$_POST["user_id"] = $_SESSION["minibase"]["raw"]["user_id"];
				}
			}
			


		
			if (is_subaction("suppliers" , "details") || (is_subaction("products" , "details") && !$_GET["section"])) {
				$notes = new CSQLAdmin("notes",  $_CONF["forms"]["admintemplate"],$that->db,$that->tables , $extra);
				$extra["details"]["after"] .= $notes->DoEvents();				
			}

			if (is_subaction("products" , "details") && $_GET["section"]) {
				$notes = new CSQLAdmin("transactions",  $_CONF["forms"]["admintemplate"],$that->db,$that->tables , $extra);
				$extra["details"]["after"] .= $notes->DoEvents();				
			}

			
			$data = new CSQLAdmin($_GET["sub"],  $_CONF["forms"]["admintemplate"],$that->db,$that->tables , $extra);

			if (is_subaction("products" , "details") && $_GET["section"]) {
				//remove some details
				unset($data->forms["forms"]["details"]["fields"]["product_description"]);
			}			
	
			return $data->DoEvents();
		break;

		case "export":


			switch ($_GET["action"]) {
				case "products":

					header("Content-Type: text/x-csv");
					header("Content-Disposition: inline; filename=products.csv");
					header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
					header("Pragma: public");

					echo putcsv(array("Name","Part Number","Count"));

					$products = $that->db->QFetchRowArray("SELECT * FROM {$that->tables[products]}");

					if (is_array($products)) {
						foreach ($products as $key => $val) {
							echo putcsv(array($val["product_name"] , $val["product_number"] , $val["product_count"]),',');
						}						
					}

					die();
					
				break;

				case "transactions":

					header("Content-Type: text/x-csv");
					header("Content-Disposition: inline; filename=transactions.csv");
					header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
					header("Pragma: public");

					echo putcsv(array("Date of Transaction",	"Description",	"UserName", "Transaction ID",	"Change"));

					$transactions = $that->db->QFetchRowArray("SELECT * FROM {$that->tables[transactions]} WHERE trans_product='{$_GET[product_id]}'");

					if (is_array($transactions)) {
						foreach ($transactions as $key => $val) {
							//read the user
							$tmp = $that->db->QFetchArray("SELECT * FROM {$that->tables[users]} WHERE user_id='{$val[trans_user]}'");
							$val["user"] = $tmp["user_name"];

							echo putcsv(array(date("m/d/Y" , $val["trans_date2"]),
											str_replace("\n",'',$val["trans_description"]),
											$val["user"],
											$val["trans_id"],
											$val["trans_inventory"] > 0 ? ("+" . $val["trans_inventory"] ) : $val["trans_inventory"] )
								);
						}						
					}					
					die;
				break;

				default:
					header("Location: ../index.php");
					exit;
				break;
			}
			
//Name	Part Number	Count					
		break;

		default:
			return "Welcome to Products Inventory!";
		break;
	}
}

?>