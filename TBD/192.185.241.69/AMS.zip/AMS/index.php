<?php

define("_LIBPATH","./lib/");
require_once _LIBPATH . "site.php";

$site = new CSite("./site.xml",true);
$site->Run();

?>
