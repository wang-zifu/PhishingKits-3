<?php
$h='localhost'; //// specify host, i.e. 'localhost'
$u='techzone_hr'; //// specify username
$p='J6g%cnq9pOnT'; //// specify password
$da='techzone_emp'; //// specify database name
$con= mysql_connect("$h" , "$u" , "$p") or die ("Can't connect to MySQL");
$db= mysql_select_db($da, $con) or die ("Can't select database.");
?>