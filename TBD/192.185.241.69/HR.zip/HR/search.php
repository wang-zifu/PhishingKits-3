<html><head><style>
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Tangerine">

 body {
        font-family: 'Tangerine', serif;
        font-size: 48px;
      }
      </style></head><body>
<?php
//include("data.php");
//DATE_FORMAT(NOW(),'%d/%m/%Y');
//CONCAT(sign,'\n',NOW())
// Required Libraries
include("connect.php");
require_once("ip.codehelper.io.php");
require_once("php_fast_cache.php");

// New Class for location
$_ip = new ip_codehelper();

//Detect Real IP Address & Location
$real_client_ip_address = $_ip->getRealIP();
$visitor_location       = $_ip->getLocation($real_client_ip_address);

//Output result, capture and prepare vars...
$x= $visitor_location['CityLatitude'].",".$visitor_location['CityLongitude'];
$loc= $visitor_location['CityName'].",".$visitor_location['CountryName'];
$ip= $real_client_ip_address;

date_default_timezone_set('Asia/Dubai');
$n = $_GET['n'];
if(strlen($n)<20)
{header("Location: https://www.google.com"); die();}
else{
$n = strrev(preg_replace("/[^a-z]+/", "", $n));
$m= date("m");
$d= date("d");
$t = date("Y-m-d H:i:s");
}
//connecting to server and creating link to database
$link = mysqli_connect($h, $u, $p, $da);

//mysqli select statement
$in= "INSERT INTO att (`name`, `month`, `day`, `checkin`, `location`, `country`, `ip` ) VALUES('$n',$m,$d,'$t','$x','$loc','$ip')";
$inc= "UPDATE att SET c=if(c<3,c+1,3) where name='$n' and month=$m and day=$d";
$out= "UPDATE att SET checkout='$t' where `checkin`<>'0000-00-00 00:00:00' and name='$n' and month=$m and day=$d and c=1";
$c= "SELECT * FROM att where name='$n' and month=$m and day=$d and c=1";
//$indo = mysqli_query($link, $in) or die(mysqli_error($link));
//$inco= mysqli_query($link, $inc) or die(mysqli_error($link));
//$outdo = mysqli_query($link, $out) or die(mysqli_error($link));
$check= mysqli_query($link, $c) or die(mysqli_error($link));
//$testo= mysqli_query($link, $test) or die(mysqli_error($link));


if (mysqli_num_rows($check)==1){
$outdo = mysqli_query($link, $out) or die(mysqli_error("outdo"));
$inco= mysqli_query($link, $inc) or die(mysqli_error("inco"));
echo "<center><img src='1.jpg'></center>";
echo "<center>Copyright &copy; 2014 TechZone</center>";
echo "</br>";
echo "</br>";
echo "</br>";
echo "</br>";
echo "<center><p>Dear ".$n.", you've logged out successfully, have fun :) .</p></center>";
			}
	else{
$indo = mysqli_query($link, $in) or die(mysqli_error($link));
$inco= mysqli_query($link, $inc) or die(mysqli_error($link));
echo "<center><img src='1.jpg'></center>";
echo "<center>Copyright &copy; 2014 TechZone</center>";
echo "</br>";
echo "</br>";
echo "</br>";
echo "</br>";
echo "<center><p>Dear ".$n.", you've logged in successfully, TechZone wishes you a productive day</p></center>";
	}

/*switch (mysqli_num_rows($testo)) {
    case 1: //logout
        {$outdo = mysqli_query($link, $out) or die(mysqli_error("outdo"));
        echo "<center><img src='../SLP/1.jpg'></center>";
echo "<center>Copyright &copy; 2014 TechZone</center>";
echo "</br>";
echo "</br>";
echo "</br>";
echo "</br>";
   	echo "<center><h2>.لقد تم تسجيل المغادرة بنجاح</h2></center>";}
        break;
    case 0: //login
   	{$indo = mysqli_query($link, $in) or die(mysqli_error("indo"));
	$inco= mysqli_query($link, $inc) or die(mysqli_error("inco"));
   	echo "<center><img src='../SLP/1.jpg'></center>";
echo "<center>Copyright &copy; 2014 TechZone</center>";
echo "</br>";
echo "</br>";
echo "</br>";
echo "</br>";
   	echo "<center><h2>.لقد تم تسجيل الحضور بنجاح</h2></center>";}
        break;
        default:
           	{echo "<center><h2>.حدث خطأ في الإدخال</h2></center>";}
}
}*/



//echo "error";}
//$name= "SELECT name FROM trainees WHERE id=$t";
//$qname= mysqli_query($link, $name);
//$row = mysqli_fetch_row($qname);*/
?></body></html>