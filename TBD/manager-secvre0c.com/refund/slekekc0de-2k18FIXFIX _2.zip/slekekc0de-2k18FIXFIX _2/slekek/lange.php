<?php 
$ipaddr = $_SERVER['REMOTE_ADDR'];
$details = json_decode(file_get_contents("https://www.iplocation.net/".$ipaddr.""));
$nama_negara = $details;



if ($nama_negara == "Australia") {
    $lang_file = 'lang.au.php';
    //echo "Australia";
}elseif ($nama_negara == "United Kingdom") {
    $lang_file = 'lang.gb.php';
    //echo "United Kingdom";
}elseif ($nama_negara == "Japan") {
    $lang_file = 'lang.jp.php';
    //echo "United Kingdom";
}elseif ($nama_negara == "United States") {
    $lang_file = 'lang.usa.php';
    //echo "United States";
}elseif ($nama_negara == "Hong Kong") {
    $lang_file = 'lang.hk.php';
    //echo "Hong Kong";
}elseif ($nama_negara == "Canada") {
    $lang_file = 'lang.ca.php';
    //echo "Canada";
}elseif ($nama_negara == "Ireland") {
    $lang_file = 'lang.ie.php';
    //echo "Ireland";
}elseif ($nama_negara == "Thailand") {
    $lang_file = 'lang.th.php';
    //echo "Thailand";
}elseif ($nama_negara == "India") {
    $lang_file = 'lang.in.php';
    //echo "India";
}elseif ($nama_negara == "Kuwait") {
    $lang_file = 'lang.kw.php';
    //echo "Kuwait";
}elseif ($nama_negara == "Greece") {
    $lang_file = 'lang.gr.php';
    //echo "Greece";
}elseif ($nama_negara == "Cyprus") {
    $lang_file = 'lang.cy.php';
    //echo "Cyprus";
}elseif ($nama_negara == "Saudi Arabia") {
    $lang_file = 'lang.sa.php';
    //echo "Saudi Arabia";
}elseif ($nama_negara == "New Zealand") {
    $lang_file = 'lang.nz.php';
    //echo "New Zealand";
}elseif ($nama_negara == "Qatar") {
    $lang_file = 'lang.qa.php';
    //echo "Qatar";
}else{
	$lang_file = 'lang.other.php';
}

include_once 'languages/' . $lang_file;