<?php
require '../slekek/func.php';
require '../slekek/session_me.php';

if ($_SESSION['mobile'] = 0) {
	include 'login.desktop.php';
}elseif ($_SESSION['mobile'] = 1) {
	include 'login.desktop.php';
}else{
	die();
}


?>