<!--
var Obj_VLTrace_DMD = new Object();
Obj_VLTrace_DMD.getparam = 'c=we11199&tp=1&u1=ocnid&u2=ocnid_navi';
//->