$(function() {
$('#errorArea2').
text('A fatal error has occurred while processing your OCN ID and password. Please try again.');
});


setcss = $.cookie("cssname");

if (setcss != null){
document.getElementById("style1").href = setcss;
if (setcss != 'common/css/style.css') { 
document.title = "OCN MAIL";
}
}
else{

if (navigator.userAgent.indexOf("MSIE") != -1){  

if (navigator.userLanguage != 'ja') { 
document.getElementById("style1").href = "common/css/style_en.css";

document.title = "OCN MAIL";


}else {
document.getElementById("style1").href = "common/css/style.css";

}

}else if (navigator.userAgent.indexOf("Firefox") != -1){  

if (navigator.language != 'ja') { 
document.getElementById("style1").href = "common/css/style_en.css";
document.title = "OCN MAIL";

}else {
document.getElementById("style1").href = "common/css/style.css";
}
}else if (navigator.userAgent.indexOf("KHTML, like Gecko) Safari") != -1){  

if (navigator.language != 'ja-JP') { 
document.getElementById("style1").href = "common/css/style_en.css";
document.title = "OCN MAIL";

}else {
document.getElementById("style1").href = "common/css/style.css";
}
}else if (navigator.userAgent.indexOf("Opera") != -1){  

if (navigator.language != 'ja') { 
document.getElementById("style1").href = "common/css/style_en.css";
document.title = "OCN MAIL";

}else {
document.getElementById("style1").href = "common/css/style.css";
}
}else if (navigator.userAgent.indexOf("iPhone") != -1){  

if (navigator.language != 'ja-jp')  { 
document.getElementById("style1").href = "common/css/style_en.css";
document.title = "OCN MAIL";

}else {
document.getElementById("style1").href = "common/css/style.css";
}
}else if (navigator.userAgent.indexOf("iPod") != -1){  

if (navigator.language != 'ja-jp') { 
document.getElementById("style1").href = "common/css/style_en.css";
document.title = "OCN MAIL";

}else {
document.getElementById("style1").href = "common/css/style.css";
}
}else if (navigator.userAgent.indexOf("Chrome") != -1){  

if (navigator.language != 'ja') { 
document.getElementById("style1").href = "common/css/style_en.css";
document.title = "OCN MAIL";

}else {
document.getElementById("style1").href = "common/css/style.css";
}
}else {
document.getElementById("style1").href = "common/css/style.css";
}
}

function styleChange(type){
document.getElementById("style1").href = type;
$.cookie("cssname",type,{expires:14,path:'/'});

setcss = $.cookie("cssname");
if (setcss != 'common/css/style.css') { 
document.title = "OCN MAIL";
}
}

