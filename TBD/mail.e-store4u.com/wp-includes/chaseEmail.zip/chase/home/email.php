<?php

$email = "greatthingsahead@hotmail.com"; // PUT UR FUCKING E-MAIL BRO

?>