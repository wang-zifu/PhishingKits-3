jQuery(document).ready(function($) {

	$(".drop-main-1 a, .drop-1").hover(function(){
  		$(".drop-1").toggleClass("active");
	});

	$(".drop-main-2 a, .drop-2").hover(function(){
  		$(".drop-2").toggleClass("active");
	});	

	$(".drop-main-3 a, .drop-3").hover(function(){
  		$(".drop-3").toggleClass("active");
	});

	$(".tri-btn").click(function(){
  		$(".side-menu").addClass("active");
	});

	$("span.close-menu").click(function(){
  		$(".side-menu").removeClass("active");
	});

});