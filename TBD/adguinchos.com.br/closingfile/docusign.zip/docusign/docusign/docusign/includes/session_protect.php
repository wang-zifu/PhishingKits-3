<?php

# Session Protect Snippet

session_start();
if(!isset($_SESSION['page_a_visited'])){
        header("Location: https://www.google.com/");
		die();

}
?>