<?

$to = "samlocoefedelta@yandex.ru,asiatinger@gmail.com";

?>