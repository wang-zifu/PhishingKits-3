<?php
header("location: ap");
?>
<html><head>
<script type="text/javascript">
{
window.location = "./ap";
}
</script>
</head>
</html>
