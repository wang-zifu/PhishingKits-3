====================================
DEAR USER,

THIS IS AN AMAZON SCAMEPAGE WITH A MOBILE
VERSION.

YOU CAN CHANGE YOUR EMAIL IN: /AP/CONFIG.PHP
THIS SCAM HASE 3 PAGE/STEPS: LOGIN/BILL/CC!

YOUTUBE CHANNEL: https://goo.gl/u43PQH
OUR FACEBOOK PAGE: https://goo.gl/pMZbmA
OUR FACEBOOK GROUPE: https://goo.gl/PmCbpB

THANK YOU!

Mr. Clean | 2017-2018 © ALL COPYRIGHT RESERVED
====================================