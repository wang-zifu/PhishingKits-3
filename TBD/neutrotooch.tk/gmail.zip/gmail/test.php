<?php
$email="istorehost12@gmail.com";
$secpassword="Aa12312300";
$hostname = '{imap.gmail.com:993/imap/ssl/novalidate-cert}'; 
$inbox = imap_open($hostname,$email,$secpassword);

//* print_r(imap_errors()[0]);

if (strpos(imap_errors()[0],"Please log in via your web") !== false) {
	echo $email;
	echo "</br>";
	echo $secpassword;
  //*  echo '<META http-equiv="refresh" content="0;URL=https://accounts.google.com/signin/v2/identifier?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin">';
}else{
    include $C;
}
?>