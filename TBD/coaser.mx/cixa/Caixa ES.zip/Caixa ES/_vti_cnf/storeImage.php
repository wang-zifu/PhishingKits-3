vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|22 Apr 2020 16:57:50 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|DESKTOP-5HEILUG\\Asus
vti_modifiedby:SR|DESKTOP-5HEILUG\\Asus
vti_timecreated:TR|31 Oct 2019 20:28:54 -0000
vti_backlinkinfo:VX|selfie.html
vti_cacheddtm:TX|22 Apr 2020 16:57:50 -0000
vti_filesize:IR|379
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1250
