<br />
<br />

<link rel="shortcut icon"
              href="images/favicon.ico"/>			  
<br /><center><img  src="error.png"></center>

<meta http-equiv="refresh" content="5; url=index.php" />