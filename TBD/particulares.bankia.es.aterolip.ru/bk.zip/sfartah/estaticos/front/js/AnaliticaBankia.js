function resetLandingPlayVideo() {
	digitalData.nombrePagina = "subhome",
	digitalData.tipoPagina = "normal",
	digitalData.paginaBajoModal = "",
	_satellite.track("view")
}
var google_conversion_id, google_custom_params, google_remarketing_only, adperftrackobj;
$(document).ready(function () {
	
	var a = $("link[hreflang='es']").attr("href"),
	b = $("link[hreflang='en']").attr("href"),
	c = $("link[hreflang='ca-es']").attr("href"),
	d = $("link[hreflang='ca-es-vc']").attr("href");
	
				if(digitalData.subseccion1=="vida y accidentes"){
                               $('#id_acc_dia_nac_p2').parent().find('.dropdown-toggle').on('click', function(e) {
                                               $('#id_acc_dia_nac_p2').parent().find('.dropdown-menu').css('max-height','150px');
                               });
                               $('#id_acc_mes_nac_p2').parent().find('.dropdown-toggle').on('click', function(e) {
                                               $('#id_acc_mes_nac_p2').parent().find('.dropdown-menu').css('max-height','150px');
                                               $('#id_acc_mes_nac_p2').parent().find('.dropdown-menu').css('overflow', 'hidden');
                                               $('#id_acc_mes_nac_p2').parent().find('.dropdown-menu.inner').css('overflow-y', 'auto');
                               });
                               $('#id_acc_anio_nac_p2').parent().find('.dropdown-toggle').on('click', function(e) {
                                               $('#id_acc_anio_nac_p2').parent().find('.dropdown-menu').css('max-height','150px');
                               });
                }
	
	
	if (a = a.replace("https://www.bankia.es", ""), b = b.replace("https://www.bankia.es", ""), c = c.replace("https://www.bankia.es", ""), d = d.replace("https://www.bankia.es", ""), $("option[data-value='ES']").attr("value", a), $("option[data-value='EN']").attr("value", b), $("option[data-value='CA']").attr("value", c), $("option[data-value='VA']").attr("value", d), "www.bankia.es" == _satellite.getVar("server") && "yes" == _satellite.readCookie("cc_analytics")) {
		if ("web publica" == digitalData.canal && "particulares" == digitalData.segmento && "cuenta_on" == digitalData.producto && "cuentas y tarjetas" == digitalData.seccion && "cuentas" == digitalData.subseccion1 && (google_conversion_id = 970006428, google_custom_params = window.google_tag_params, google_remarketing_only = !0, function () {
				var a = document.createElement("script");
				a.type = "text/javascript",
				a.async = !0,
				a.src = ("https:" == document.location.protocol ? "https://" : "http://") + "www.googleadservices.com/pagead/conversion.js";
				var b = document.getElementsByTagName("script")[0];
				b.parentNode.insertBefore(a, b.nextSibling);
				var c = document.createElement("div");
				jQuery(c).attr("style", "display:none;"),
				c.innerHTML = '<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/970006428/?guid=ON&amp;script=0"/>',
				document.body.insertBefore(c, document.body.childNodes[0])
			}
				(), document.referrer && (null !== document.referrer.match(/microsites\/cuentas\/gmail\/cuenta-on.html/gi) || null !== document.referrer.match(/microsites\/cuentas\/rtb\/cuenta-on.html/gi) || null !== document.referrer.match(/microsites\/cuentas\/branding\/cuenta-on.html/gi)))) {
			var e = document.createElement("script");
			e.type = "text/javascript",
			e.async = !0,
			e.src = "http" + ("https:" == document.location.protocol ? "s" : "") + "://cstatic.weborama.fr/js/advertiserv2/adperf_conversion.js";
			var f = document.getElementsByTagName("script")[0];
			f.parentNode.insertBefore(e, f.nextSibling),
			adperftrackobj = {
				client: "" + _satellite.getVar("GET_MID"),
				amount: "0.0",
				invoice_id: "",
				quantity: 0,
				is_client: 0,
				optional_parameters: {
					N1: "0",
					N2: "0",
					N3: "0"
				},
				fullhost: "bankiaes.solution.weborama.fr",
				site: 2905,
				conversion_page: 43
			}
		}
		if ("web publica" == digitalData.canal && "particulares" == digitalData.segmento && "hazte cliente" == digitalData.seccion) {
			var e = document.createElement("script");
			e.type = "text/javascript",
			e.async = !0,
			e.src = "http" + ("https:" == document.location.protocol ? "s" : "") + "://cstatic.weborama.fr/js/advertiserv2/adperf_conversion.js";
			var f = document.getElementsByTagName("script")[0];
			f.parentNode.insertBefore(e, f.nextSibling),
			adperftrackobj = {
				client: "" + _satellite.getVar("GET_MID"),
				amount: "0.0",
				invoice_id: "",
				quantity: 0,
				is_client: 0,
				optional_parameters: {
					N1: "0",
					N2: "0",
					N3: "0"
				},
				fullhost: "bankiaes.solution.weborama.fr",
				site: 2905,
				conversion_page: 44
			},
			$("#HazteCliente").click(function () {
				try {
					window.adperfTracker.track(adperftrackobj)
				} catch (a) {
					_satellite.notify("Error llamada weborama: " + a)
				}
			})
		}
		"conecta con tu experto" == digitalData.producto && ($(".ctc-tel").text("916 346 968"), $(".ctn-link").each(function (a) {
				0 == a && $(this).text("916 346 968")
			}));

	}

	var c = location.search;
	if ("" != c && c.match(/campaign/gi) && c.match(/origin/gi)) {
		var d = new Date,
		e = 2592e6;
		d.setTime(d.getTime() + e),
		document.cookie = "LNDPRMS=" + c + "; expires=" + d.toGMTString() + "; path=/"
	} else
		c = Cookies.get("LNDPRMS");

	if (void 0 != c && $("#Empezar").size() > 0) {
		$("#Empezar")[0].href;
		$("#Empezar").attr("href", $("#Empezar")[0].href.split("?")[0] + c)
	}
	if (void 0 != c && $("#Empezar1").size() > 0) {
		$("#Empezar1").attr("href", $("#Empezar1")[0].href + c + location.search.replace("?", "&"))
	}
	if (void 0 != c && $("#Empezar2").size() > 0) {
		$("#Empezar2").attr("href", $("#Empezar2")[0].href + c + location.search.replace("?", "&"))
	}

	if (digitalData.seccion && digitalData.seccion == "hazte cliente 2 titulares") {
		$("#Empezar1").attr("onclick", "_satellite.track('enlacedeinteres',digitalData.clickEnlaceInteres='empezar 1 titular')");
		$("#Empezar2").attr("onclick", "_satellite.track('enlacedeinteres',digitalData.clickEnlaceInteres='empezar 2 titular')");
		$("#haztecliente1titular").attr("onclick", "_satellite.track('enlacedeinteres',digitalData.clickEnlaceInteres='hazte cliente 1 titular')");
		$("#haztecliente2titulares").attr("onclick", "_satellite.track('enlacedeinteres',digitalData.clickEnlaceInteres='hazte cliente 2 titular'); return true;");
	}

	"www.bankia.es" != _satellite.getVar("server") && "www.bankiafondos.es" != _satellite.getVar("server") && "www.bankiapensiones.es" != _satellite.getVar("server") || jQuery("a").click(function () {
		jQuery("#cc-notification").remove();
		if (typeof Cookiebot !== 'undefined' && Cookiebot.consent.statistics) {escrCookie("cc_analytics", "yes", 30)}
		escrCookie("cc_necessary", "yes", 30);
	})
	
	// Para renderizar correctamente los valores del multidioma en la página de /es/particulares/acceso-clientes
	
	var URL = window.location.href; 
	var contenidoEN=URL.indexOf("/en/");
	var contenidoES=URL.indexOf("/es/");
	var contenidoVA=URL.indexOf("/va/");
	var contenidoCA=URL.indexOf("/ca/");
	var contenido="";

	if(contenidoEN > -1){
		contenido="/en/";
		$('span.ui-valText').text("EN");
	}
	else if(contenidoES > -1)
	{
		contenido="/es/";
		$('span.ui-valText').text("ES");
	}
	else if(contenidoVA > -1)
	{
		contenido="/va/";
		$('span.ui-valText').text("VA");
	}
	else if(contenidoCA > -1)
	{
		contenido="/ca/";
		$('span.ui-valText').text("CA");
	}
	
	//Tratamiento Cookies para language de la oi
	var listaCookies = document.cookie.split(";");
	var micookie = "";
	for (i in listaCookies) {
        var busca = listaCookies[i].search("language");
        if (busca > -1) {
			micookie=listaCookies[i]
		}
    }
	var igual = micookie.indexOf("=");
    var valor = micookie.substring(igual+1);
	
	if (digitalData.idioma == "es"){
		if (valor!="es"){
			document.cookie = "language=es; max-age=31536000; path=/";
		}
	}
	if (digitalData.idioma == "en"){
		if (valor!="en"){
			document.cookie = "language=en; max-age=31536000; path=/";
		}
	}
	if (digitalData.idioma == "ca"){
		if (valor!="ca"){
			document.cookie = "language=ca; max-age=31536000; path=/";
		}
	}
	if (digitalData.idioma == "va"){
		if (valor!="va"){
			document.cookie = "language=va; max-age=31536000; path=/";
		}
	}
			
	//Inserta en la URL el parámetro ?text="ValorBusqueda" en función a la búsqueda realizada, cuando se clicka sobre el botón de BUSCAR
	$('#inbenta').load(function(){
				$('#inbenta').contents().find('.search-btn').click(function() { 
					var search_value = $('#inbenta').contents().find('.question-input').val();
					var url_arr="";
					var url="";
					if(window.location.href.indexOf('?')!=-1){
						url_arr = window.location.href.split("?");
						url = url_arr[0] + '?text='+ $('#inbenta').contents().find('.question-input').val();
					}
					else{
						url = window.location.href + '?text='+ $('#inbenta').contents().find('.question-input').val(); 
					}
					window.location.href=url;
		});
	});

});