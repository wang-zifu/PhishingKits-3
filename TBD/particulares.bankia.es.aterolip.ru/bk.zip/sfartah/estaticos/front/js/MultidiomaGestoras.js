$( window ).load(function() {
	if(location.href.match("(gestoras-internacionales|international-managers|gestors-internacionals|gestores-internacionals)")){ 
             for(var i =0; i< 4 ; i++){
                    var hreff = $("link.noTraducibleMultidioma").eq(i).attr('href') + "/" + location.href.match("/(gestoras-internacionales|international-managers|gestors-internacionals|gestores-internacionals)/(.*)")[2];
                    var hrefVar = $("link.noTraducibleMultidioma").eq(i).attr('href');
                    if(hrefVar.indexOf(location.href.match("/(gestoras-internacionales|international-managers|gestors-internacionals|gestores-internacionals)/(.*)")[2])==-1){
                           $("link.noTraducibleMultidioma").eq(i).attr('href', hreff);               
                    }
             }
             
             $("#language-switcher option").each(function(){
                      var hreff = $(this).attr('value') + "/" + location.href.match("/(gestoras-internacionales|international-managers|gestors-internacionals|gestores-internacionals)/(.*)")[2];
                      var hrefVar = $(this).attr('value');
                      if(hrefVar.indexOf(location.href.match("/(gestoras-internacionales|international-managers|gestors-internacionals|gestores-internacionals)/(.*)")[2])==-1){
                           $(this).val(hreff);              
                      }
                    });
	}
});