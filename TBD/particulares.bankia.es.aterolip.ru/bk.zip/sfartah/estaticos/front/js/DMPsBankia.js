var _BCaq = _BCaq || [];
$( document ).ready(function() {
	if (_satellite.getVar('server')=='www.bankia.es'){	
		
		if (_satellite.readCookie("cc_analytics")=="yes"){
				
			if ((digitalData.canal == 'web publica') && 
				(digitalData.seccion!= 'onboarding') && 
				(digitalData.seccion!= 'enrollment'))
			{
				/*
				_BCaq.push(['setAccount', 'M-l6iJql3Ux6']);
				_BCaq.push(['crumb']);

				
				//DMP brandcrumb
				(function () {
					var bca = document.createElement('script');
					bca.type = 'text/javascript';
					bca.async = true;
					bca.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + "static.brandcrumb.com/bc.js";
					var ultimo = document.getElementsByTagName('script').length -1;
					var script_Brandcrumb = document.getElementsByTagName('script')[ultimo];
					script_Brandcrumb.parentNode.insertBefore(bca, script_Brandcrumb.nextSibling);
				})();
				 
				//DMP weborama
				if (digitalData.nombrePagina == 'home'){
					(function() {					
						var wsc = document.createElement('script');
						wsc.type = 'text/javascript';
						wsc.onload = function() {		
							try {
								wex.account('1641');
								wex.push('Particulares', 1, 'Particulares');
								wex.send();							
							} catch (err) {}		
						};
						wsc.src = ('https:' == document.location.protocol ?'https://':'http://') + 'cstatic.weborama.fr/wam/wfpd.min.js';
						var ultimo = document.getElementsByTagName('script').length -1;
						var script_weborama = document.getElementsByTagName('script')[ultimo];
						script_weborama.parentNode.insertBefore(wsc, script_weborama.nextSibling);						
					})();
									
				}	
				*/					
			}	 
		}		
	}
});