$(document).ready (function(){
	
	window.dataLayer = window.dataLayer || [];
	
	gtag('js', new Date());
	gtag('config', 'AW-970006428');
	
});

function gtag(){
	dataLayer.push(arguments);
}

function gtag_report_conversion(url){
	var callback = function(){
		if(typeof(url) != 'undefined'){
			window.location = url;
		}
	};
	
	gtag('event', 'conversion', {
								'send_to': 'AW-970006428/Olg6CLuGj3wQnL_EzgM', 
								'event_callback': callback
								} );
}