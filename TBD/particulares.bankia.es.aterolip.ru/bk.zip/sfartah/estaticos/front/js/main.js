//To apply correct funcionality over language selector on "/va/particulars/financament/Hipoteques-nou/valorar-vivienda"
window.onload = function() {
	$("#language-switcher").selectmenu({
		change : function(event, ui) {
			$('div.mod_select.slt-simple').keydown(function(e) {
				if (e.which == 13){
					window.location.replace(ui.item.value);
				}						
			});
		}		
	});
	$("#language-switcher").selectmenu({
		select : function(event, ui) {	
			$('div.ui-selectmenu-menu.ui-front.ui-selectmenu-menu-head.ui-selectmenu-open').click(function() {
				window.location.replace(ui.item.value);						
			});
		}	
	});
};

$(document)
.ready(
		function() {


			initModalWindow();
			
			try {
				if($(".contentCompany").length > 0){
					$(".contentCompany").find("a").first().attr("href","https://oficinaempresas.bankia.es/bole/es/emision-clave-bloqueada.html");
				}
			}catch(err) {
			}

//			$(".fc-closeMensajeCookies").click(function() {
//			setCookie(globalCookieName, 'true', 1, "");
//			return false;
//			});
//			if (getCookie(globalCookieName) == null) {
//			$(".mod_mensajeCookies").toggleClass('hide');
//			}
//			$("#language-switcher").selectmenu({
//			change : function(event, ui) {
//			window.location.replace(ui.item.value);
//			}
//			});
			$("#language-switcher").selectmenu({
				change : function(event, ui) {
					$('div.mod_select.slt-simple').keydown(function(e) {
						if (e.which == 13){
							window.location.replace(ui.item.value);
						}						
					});
				}		
			});
			$("#language-switcher").selectmenu({
				select : function(event, ui) {	
					$('div.ui-selectmenu-menu.ui-front.ui-selectmenu-menu-head.ui-selectmenu-open').click(function() {
						window.location.replace(ui.item.value);						
					});
				}	
			});
			$("#language-switcher-mobile").selectmenu({
				change : function(event, ui) {
					window.location.replace(ui.item.value);
				}
			});
			$(".slt-select-cabecera").selectmenu({
				select : function(event, ui) {
					window.location.replace(ui.item.value);
				}
			});
			$("#channel-mobile").selectmenu({
				select : function(event, ui) {
					window.location.replace(ui.item.value);
				}
			});
			$('.tab-rent-anual').on("click", function() {
//				visualizarRentabilidad('.tab-rent-anual')

				$('.tab-rent-anual').removeClass('active');
				$('.tab-rent-mensual').removeClass('active');
				$('.tab-calc-rent').removeClass('active');

				$('.tab-rent-anual').addClass('active');

				$('.graficoRentabilidadAnual').removeClass('hide');
				$('.graficoRentabilidadMensual').removeClass('hide');
				$('.calculadoraRentabilidades').removeClass('hide');

				$('.graficoRentabilidadMensual').addClass('hide');
				$('.calculadoraRentabilidades').addClass('hide');
			});
			$('.tab-rent-mensual').on("click", function() {
//				visualizarRentabilidad('.tab-rent-mensual')

				$('.tab-rent-anual').removeClass('active');
				$('.tab-rent-mensual').removeClass('active');
				$('.tab-calc-rent').removeClass('active');

				$('.tab-rent-mensual').addClass('active');

				$('.graficoRentabilidadAnual').removeClass('hide');
				$('.graficoRentabilidadMensual').removeClass('hide');
				$('.calculadoraRentabilidades').removeClass('hide');

				$('.graficoRentabilidadAnual').addClass('hide');
				$('.calculadoraRentabilidades').addClass('hide');
			});
			$('.tab-calc-rent').on("click", function() {
//				visualizarRentabilidad('.tab-calc-rent')

				$('.tab-rent-anual').removeClass('active');
				$('.tab-rent-mensual').removeClass('active');
				$('.tab-calc-rent').removeClass('active');

				$('.tab-calc-rent').addClass('active');

				$('.graficoRentabilidadAnual').removeClass('hide');
				$('.graficoRentabilidadMensual').removeClass('hide');
				$('.calculadoraRentabilidades').removeClass('hide');

				$('.graficoRentabilidadAnual').addClass('hide');
				$('.graficoRentabilidadMensual').addClass('hide');

			});
			$('.mostrar-rentabilidad').on("click", function() {
				jQuery('.rentAnual-oculto').toggleClass('hide');
				jQuery('.ocultar-rentabilidad').toggleClass('hide');
			});
			$('.mostrar-rentabilidad2').on("click", function() {
				jQuery('.rentMensual-oculto').toggleClass('hide');
				jQuery('.ocultar-rentabilidad2').toggleClass('hide');
			});
			$('#id-radio1').on("click", function() {
				if (jQuery('.vlpRango').hasClass('hide')) {
					jQuery('.vlpRango').toggleClass('hide');
					jQuery('.vlpDia').toggleClass('hide');
					jQuery('.valVLP').toggleClass('hide');
				}
			});

			$('#id-radio2').on("click", function() {
				if (jQuery('.vlpDia').hasClass('hide')) {
					jQuery('.vlpDia').toggleClass('hide');
					jQuery('.vlpRango').toggleClass('hide');
					jQuery('.valVLP').toggleClass('hide');
				}
			});

			$("#id-nombreFondo").parents(".mod_autocompleteSelect").find(".custom-combobox-input").autocomplete({
				select: function(event,ui){
					if (jQuery('.mod_search').hasClass(
					'exclusivoBP')) {

						if (jQuery('.exclusivos').hasClass(
						'selected')) {
							jQuery('.buscador1').removeClass(
							'hide');
							jQuery('.buscadorTodos').addClass(
							'hide');
						} else {
							jQuery('.buscadorTodos')
							.removeClass('hide');
							jQuery('.buscador1').addClass(
							'hide');
						}
					} else {
						jQuery('.buscador1 ').removeClass(
						'hide');
					}

					sessionStorage.setItem('ultimoFiltroNombre', 'mig');


					//IE9
					buscadorFondos(event.currentTarget.textContent);

					//buscadorFondos(event.toElement.textContent);
				}
			});
			$("#id-categoria,#id-level").selectmenu(
					{
						change : function(event, ui) {

							if (jQuery('.mod_search').hasClass(
							'exclusivoBP')) {

								if (jQuery('.exclusivos').hasClass(
								'selected')) {
									jQuery('.buscador1').removeClass(
									'hide');
									jQuery('.buscadorTodos').addClass(
									'hide');
								} else {
									jQuery('.buscadorTodos')
									.removeClass('hide');
									jQuery('.buscador1').addClass(
									'hide');
								}
							} else {
								jQuery('.buscador1 ').removeClass(
								'hide');
							}

							buscadorFondos('');
						}
					});
			$(
			"#id-checkbox1,#id-checkbox2,#id-checkbox3,#id-checkbox4,#id-checkbox5,#id-checkbox6,#id-checkbox7,#id-todos")
			.click(
					function() {

						if (jQuery('.mod_search').hasClass(
						'exclusivoBP')) {

							if (jQuery('.exclusivos').hasClass(
							'selected')) {
								jQuery('.buscador1')
								.removeClass('hide');
								jQuery('.buscadorTodos')
								.addClass('hide');
							} else {
								jQuery('.buscadorTodos')
								.removeClass('hide');
								jQuery('.buscador1').addClass(
								'hide');

							}
						} else {
							jQuery('.buscador1 ').removeClass(
							'hide');
						}
						buscadorFondos('');
					});

			$(".exclusivos").click(function() {
				if (jQuery('.exclusivos').hasClass('selected')) {
					jQuery('.buscadorTodos').removeClass('hide');
					jQuery('.buscador1').addClass('hide');
				} else {
					jQuery('.buscador1').removeClass('hide');
					jQuery('.buscadorTodos').addClass('hide');
				}
				jQuery('.exclusivos').toggleClass('selected');
				buscadorFondos('');

			});



			if (($("#tabla").length > 0) || ($("#cuadro").length > 0) )   {
				buscadorFondos('');
				var busqueda = $('#id-nombreFondo-input');
				var table = $("#tabla").find("tBody");
				var evento = "";

				function buscaTabla() {
					var contFondosTabla = 0;
					var valorExclusivoBP = document.getElementById("id_customer_ctf");
					var codigoMig = $("#id-nombreFondo option:selected").val();

					texto = busqueda.val().toLowerCase();
					//Evento = 0 --> onBlur

					sessionStorage.setItem('ultimoFiltroNombre', 'esc');
					//buscadorFondos('');


//					if (evento != '0' && texto.length == '0'){
//					$("#id-nombreFondo option:selected").val("");
//					}

					var r = 0;

					//identificarfiltros
					var categselect = $('#id-categoria-button').find('.ui-selectmenu-text').text();

					var riesgosel=[];
					var cont=0;

					for (var i = 1; i < 8; i++) {
						if ($("#id-checkbox" + i).is(':checked')) {
							riesgosel[cont] = i;
							cont++;
						}
					}
					if(codigoMig != 'sel' || texto != 'Selecciona'){
						if ($('#listaTabla').hasClass('rpl-active')) {
							table.find("[role='row']").each(function(){
								var titulo = $(this).text().toLowerCase();

								var clases = $(this).attr('class');

								var categoriaCoincide = true;
								if(categselect.indexOf('Selecciona')==-1 && categselect.indexOf('Select')==-1){
									categoriaCoincide = false;
									if(clases.indexOf($("#id-categoria option:selected").val() + " search") > -1){
										categoriaCoincide = true;
									}
								}

								var riesgoCoincide=true;

								if(riesgosel.length>0){
									riesgoCoincide=false;
									for (var i = 0 ; i < riesgosel.length ; i++) {
										if(clases.indexOf("NR" + riesgosel[i]) > -1){

											riesgoCoincide=true;
											i = riesgosel.length;
										}
									}
								}

								if(texto != null && (texto == "" || (texto != "" && titulo.indexOf(texto) > -1)) ){
									if(categoriaCoincide){
										if(riesgoCoincide){
											$(this).show();
										}else{
											$(this).hide();
										}
									}else{
										$(this).hide();
									}
								}else{
									$(this).hide();
								}
							});

							if(digitalData.exclusivosBancaPrivada != ''){
								digitalData.proceso = digitalData.proceso + ":Exclusivos de Banca Privada:"+digitalData.exclusivosBancaPrivada;
							}

							if(sessionStorage.buscaTablaAnterior != busqueda.val()){
								digitalData.nombreFondo = normalizeString(busqueda.val());
								_satellite.track('buscador de fondos');
							}


							sessionStorage.setItem('buscaTablaAnterior', busqueda.val());
						} else {
							$('.buscador2').each(function() {
								titulo = $('.rpl-title',$(this)).text().toLowerCase();

								var clases = $(this).attr('class');

								var categoriaCoincide = true;
								if(categselect.indexOf('Selecciona')==-1 && categselect.indexOf('Select')==-1){
									categoriaCoincide = false;
									if(clases.indexOf($("#id-categoria option:selected").val() + " search") > -1){
										categoriaCoincide = true;
									}
								}

								var riesgoCoincide=true;

								if(riesgosel.length>0){
									riesgoCoincide=false;
									for (var i = 0 ; i < riesgosel.length ; i++) {
										if(clases.indexOf("NR" + riesgosel[i]) > -1){

											riesgoCoincide=true;
											i = riesgosel.length;
										}
									}
								}

								if (titulo.indexOf(texto) !== -1 && categoriaCoincide && riesgoCoincide) {
									//if($(this).is(":visible")) 
									$(this).show();
									if (valorExclusivoBP != null) {

										if (valorExclusivoBP.checked) {

											if($(this).hasClass("analiticaBuscadorCheckBP")){
												contFondosTabla++;
											}

										} else {
											if($(this).hasClass("analiticaBuscadorCheckTodos")){
												contFondosTabla++;
											}

										}

									}else{
										contFondosTabla++;

									}

								} else {
									if($(this).is(":visible")) 
										$(this).hide();
								}
							});

							digitalData.nResultadosFondos = contFondosTabla;



							// eliminado por una incidencia abierta se deja comentado por si se quiere recuperar en el futuro

							/*if(busqueda.val() != ''){
						digitalData.proceso = digitalData.proceso + ":Por nombre del fondo:"+normalizeString(busqueda.val());
					}
					if(categoriaFondoTabla != ' '){
						digitalData.proceso = digitalData.proceso + ":Por categoria:"+normalizeString($("#id-categoria option:selected").html().trim());
					}
					if(sessionStorage.nivelRiesgoBuscadorAnterior != ''){
						digitalData.proceso = digitalData.proceso + ":Por nivel de riesgo:"+digitalData.nivelDelRiesgo;
					} */




							if(digitalData.exclusivosBancaPrivada != ''){
								digitalData.proceso = digitalData.proceso + ":Exclusivos de Banca Privada:"+digitalData.exclusivosBancaPrivada;
							}

							var idCodigoMig = "#"+$("#id-nombreFondo").val();
							var nombreBuscadoCombo = $(idCodigoMig).html();
							if(undefined ==  nombreBuscadoCombo){
								nombreBuscadoCombo = "No se ha seleccionado el combo";
							}
							var nombreBuscadoComboReplace = nombreBuscadoCombo.replace("&nbsp;"," ");

							if(sessionStorage.buscaTablaAnterior != busqueda.val()){
								digitalData.nombreFondo = normalizeString(busqueda.val());
								digitalData.idCampana = "";
								digitalData.localizacion = "";
								if(nombreBuscadoComboReplace != busqueda.val()){
									if(document.getElementById("buscadorTituloPensiones") != null)	{
										digitalData.proceso = "buscador de planes"
											_satellite.track('buscador de planes');
									}else if(document.getElementById("buscadorTituloEPSV") != null){
										digitalData.proceso = "buscador de epsv"
											_satellite.track('buscador de epsv');
									}else{	


										_satellite.track('buscador de fondos');
									}
								}

							}
//							if(busqueda.val() != ""){
//							digitalData.nombreFondo = normalizeString(busqueda.val());
//							digitalData.idCampana = "";
//							digitalData.localizacion = "";
//							_satellite.track('buscador de fondos');
//							}

							sessionStorage.setItem('buscaTablaAnterior', busqueda.val());

							//sessionStorage.setItem('buscaTablaAnterior', busqueda.val());		

						}
					}
					if(document.getElementById("buscadorTituloPensiones") != null)	{
						digitalData.proceso = "buscador de planes"
					}else if(document.getElementById("buscadorTituloEPSV") != null){
						digitalData.proceso = "buscador de epsv"
					}else{
						digitalData.proceso = "buscador de fondos";
					}	

				}
				//busqueda.on('keyup','blur', buscaTabla);
				busqueda.on({
					keyup: function (event){
						evento = event.which;
						buscaTabla();

					},blur: function (event){
						evento = event.which;
						//buscaTabla();

					}
				});
			}




			jQuery('.botonCalcFechas').click(function(event) {
				event.preventDefault();
				var diadsd = jQuery('#id-text1').val();
				var mesdsd = jQuery('#id-text2').val();
				var annodsd = jQuery('#id-text3').val();
				var diahst = jQuery('#id-text4').val();
				var meshst = jQuery('#id-text5').val();
				var annohst = jQuery('#id-text6').val();
				var fechadsd = diadsd.concat('\/', mesdsd, '\/', annodsd);
				var fechahst = diahst.concat('\/', meshst, '\/', annohst);
				var codMig = jQuery('#codMig').val();
				var valFechadsd = validarFecha(fechadsd);
				var valFechahst = validarFecha(fechahst);
				var f1 = new Date(annodsd, mesdsd -1, diadsd);
				var f2 = new Date(annohst, meshst -1, diahst);
				var literalDescargarCsv = $("#literalDescargarCsv").val();
				var re = new RegExp(' ', 'g');
				literalDescargarCsv = literalDescargarCsv.replace(re, '_');
				if (valFechadsd && valFechahst) {
					if (f2 >= f1	) {
						jQuery('.fechinc').addClass(
						'hide');

						jQuery(".calculadoraVLP")
						.load(
								'/portalunico/portalunico/displayviews/planesDePensiones/fichaPlanes/calculadoraVLP.jsp'
								+ "?fechadsd="
								+ fechadsd
								+ "&fechahst="
								+ fechahst
								+ "&codMig="
								+ codMig
								+ "&literalDescargarCsv="
								+ literalDescargarCsv,
								function(
										response,
										status,
										xhr) {
									if (status == "error") {
										console
										.log('status'
												+ status);
									} else {
										mostrarGraf();
									}
								});
						jQuery('.calculadoraVLP').removeClass(
						'hide');
					} else {
						jQuery('.fechinc').removeClass(
						'hide');
						jQuery(".calculadoraVLP").addClass(
						'hide');



					}
					jQuery('.frm-fecha1')
					.removeClass(
					'mod_form frm-message-error');
					jQuery('.fecha1VLP-errtxt')
					.addClass('hide');
					jQuery('.frm-fecha2')
					.removeClass(
					'mod_form frm-message-error');
					jQuery('.fecha2VLP-errtxt')
					.addClass('hide');
				} else {
					jQuery('calcContainer').empty();
					if (!valFechadsd) {
						jQuery('.frm-fecha1')
						.addClass(
						'mod_form frm-message-error');
						jQuery('.fecha1VLP-errtxt')
						.removeClass('hide');
					} else {
						jQuery('.frm-fecha1')
						.removeClass(
						'mod_form frm-message-error');
						jQuery('.fecha1VLP-errtxt')
						.addClass('hide');
					}
					if (!valFechahst) {
						jQuery('.frm-fecha2')
						.addClass(
						'mod_form frm-message-error');
						jQuery('.fecha2VLP-errtxt')
						.removeClass('hide');
					} else {
						jQuery('.frm-fecha2')
						.removeClass(
						'mod_form frm-message-error');
						jQuery('.fecha2VLP-errtxt')
						.addClass('hide');
					}
				}
			});

			jQuery('.botonCalcVLP')
			.click(
					function(event) {
						event.preventDefault();
						var diadsd = jQuery('#id-text7').val();
						var mesdsd = jQuery('#id-text8').val();
						var annodsd = jQuery('#id-text9').val();
						var fechadsd = diadsd.concat('\/',
								mesdsd, '\/', annodsd);
						var codMig = jQuery('#codMig').val();

						if (validarFecha(fechadsd)) {
							jQuery(".valVLP")
							.load(
									'/portalunico/portalunico/displayviews/planesDePensiones/fichaPlanes/valorVLP.jsp'
									+ "?fechadsd="
									+ fechadsd
									+ "&codMig="
									+ codMig,
									function(response,
											status, xhr) {

										if (status == "error") {
											console
											.log('status'
													+ status);
										} else {
											jQuery(
													'.frm-fechadsd')
													.removeClass(
													'mod_form frm-message-error');
											jQuery(
											'.fechaVLPVal-errtxt')
											.addClass(
											'hide');
										}
									});
							jQuery('.valVLP').removeClass(
							'hide');
						} else {
							jQuery('.frm-fechadsd')
							.addClass(
							'mod_form frm-message-error');
							jQuery('.fechaVLPVal-errtxt')
							.removeClass('hide');
							jQuery(".valVLP").addClass(
							'hide');
						}
					});
			jQuery('.botonCalcFechasFondo')
			.click(
					function(event) {
						event.preventDefault();
						var diadsd = jQuery('#id-text1').val();
						var mesdsd = jQuery('#id-text2').val();
						var annodsd = jQuery('#id-text3').val();
						var diahst = jQuery('#id-text4').val();
						var meshst = jQuery('#id-text5').val();
						var annohst = jQuery('#id-text6').val();
						var fechadsd = diadsd.concat('\/',
								mesdsd, '\/', annodsd);
						var fechahst = diahst.concat('\/',
								meshst, '\/', annohst);
						var codMig = jQuery('#codMig').val();
						var formato = $("#formato").val();
						var valFechadsd = validarFecha(fechadsd);
						var valFechahst = validarFecha(fechahst);
						var f1 = new Date(annodsd, mesdsd -1, diadsd);
						var f2 = new Date(annohst, meshst -1, diahst);
						if (valFechadsd && valFechahst) {
							if (f2 >= f1) {
								jQuery('.fechinc').addClass(
								'hide');
								jQuery(".calculadoraVLP")
								.load(
										'/portalunico/portalunico/displayviews/fondosInversion/fichaFondos/calculadoraVLPFondo.jsp'
										+ "?fechadsd="
										+ fechadsd
										+ "&fechahst="
										+ fechahst
										+ "&codMig="
										+ codMig
										+ "&formato="
										+ formato,
										function(
												response,
												status,
												xhr) {
											if (status == "error") {
												console
												.log('status'
														+ status);
											} else {
												mostrarGraf();
											}
										});
								jQuery('.calculadoraVLP').removeClass(
								'hide');
							} else {
								jQuery('.fechinc').removeClass(
								'hide');
								jQuery(".calculadoraVLP").addClass(
								'hide');
							}
							jQuery('.frm-fecha1')
							.removeClass(
							'mod_form frm-message-error');
							jQuery('.fecha1VLP-errtxt')
							.addClass('hide');
							jQuery('.frm-fecha2')
							.removeClass(
							'mod_form frm-message-error');
							jQuery('.fecha2VLP-errtxt')
							.addClass('hide');
						} else {
							jQuery('calcContainer').empty();
							if (!valFechadsd) {
								jQuery('.frm-fecha1')
								.addClass(
								'mod_form frm-message-error');
								jQuery('.fecha1VLP-errtxt')
								.removeClass('hide');
							} else {
								jQuery('.frm-fecha1')
								.removeClass(
								'mod_form frm-message-error');
								jQuery('.fecha1VLP-errtxt')
								.addClass('hide');
							}
							if (!valFechahst) {
								jQuery('.frm-fecha2')
								.addClass(
								'mod_form frm-message-error');
								jQuery('.fecha2VLP-errtxt')
								.removeClass('hide');
							} else {
								jQuery('.frm-fecha2')
								.removeClass(
								'mod_form frm-message-error');
								jQuery('.fecha2VLP-errtxt')
								.addClass('hide');
							}
						}
					});

			jQuery('.botonCalcFechasRentFondo')
			.click(
					function(event) {
						event.preventDefault();
						var diadsd = jQuery('#id-textRent1').val();
						var mesdsd = jQuery('#id-textRent2').val();
						var annodsd = jQuery('#id-textRent3').val();
						var diahst = jQuery('#id-textRent4').val();
						var meshst = jQuery('#id-textRent5').val();
						var annohst = jQuery('#id-textRent6').val();
						var fechadsd = diadsd.concat('\/',
								mesdsd, '\/', annodsd);
						var fechahst = diahst.concat('\/',
								meshst, '\/', annohst);
						var codMig = jQuery('#codMig').val();
						var valFechadsd = validarFecha(fechadsd);
						var valFechahst = validarFecha(fechahst);
						var f1 = new Date(annodsd, mesdsd -1, diadsd);
						var f2 = new Date(annohst, meshst -1, diahst);
						if (valFechadsd && valFechahst) {
							if (f2 >= f1) {
								jQuery('.fechinc').addClass(
								'hide');
								jQuery(".calculadoraRent")
								.load(
										'/portalunico/portalunico/displayviews/fondosInversion/fichaFondos/calculadoraRentabilidadFondo.jsp'
										+ "?codMig="
										+ codMig
										+ "&fRentDesde="
										+ fechadsd
										+ "&fRentHasta="
										+ fechahst,
										function(
												response,
												status,
												xhr) {
											if (status == "error") {
												console
												.log('status'
														+ status);
											} else {
												mostrarGrafCalcRentFondo();
											}
										});
								jQuery('.calculadoraVLP').removeClass(
								'hide');
							} else {
								jQuery('.fechinc').removeClass(
								'hide');
								jQuery(".calculadoraVLP").addClass(
								'hide');
							}
							jQuery('.frm-fechaRent1')
							.removeClass(
							'mod_form frm-message-error');
							jQuery('.fecha1Rent-errtxt')
							.addClass('hide');
							jQuery('.frm-fechaRent2')
							.removeClass(
							'mod_form frm-message-error');
							jQuery('.fecha2Rent-errtxt')
							.addClass('hide');
						} else {
							jQuery('calcContainer').empty();
							if (!valFechadsd) {
								jQuery('.frm-fechaRent1')
								.addClass(
								'mod_form frm-message-error');
								jQuery('.fecha1Rent-errtxt')
								.removeClass('hide');
							} else {
								jQuery('.frm-fechaRent1')
								.removeClass(
								'mod_form frm-message-error');
								jQuery('.fecha1Rent-errtxt')
								.addClass('hide');
							}
							if (!valFechahst) {
								jQuery('.frm-fechaRent2')
								.addClass(
								'mod_form frm-message-error');
								jQuery('.fecha2Rent-errtxt')
								.removeClass('hide');
							} else {
								jQuery('.frm-fechaRent2')
								.removeClass(
								'mod_form frm-message-error');
								jQuery('.fecha2Rent-errtxt')
								.addClass('hide');
							}
						}
					});
			jQuery('.botonCalcFechasRentPlan')
			.click(
					function(event) {
						event.preventDefault();
						var diadsd = jQuery('#id-textRent1').val();
						var mesdsd = jQuery('#id-textRent2').val();
						var annodsd = jQuery('#id-textRent3').val();
						var diahst = jQuery('#id-textRent4').val();
						var meshst = jQuery('#id-textRent5').val();
						var annohst = jQuery('#id-textRent6').val();
						var fechadsd = diadsd.concat('\/',
								mesdsd, '\/', annodsd);
						var fechahst = diahst.concat('\/',
								meshst, '\/', annohst);
						var codMig = jQuery('#codMig').val();
						var valFechadsd = validarFecha(fechadsd);
						var valFechahst = validarFecha(fechahst);
						var f1 = new Date(annodsd, mesdsd -1, diadsd);
						var f2 = new Date(annohst, meshst -1, diahst);
						if (valFechadsd && valFechahst) {
							if (f2 >= f1) {
								jQuery('.fechinc').addClass(
								'hide');
								jQuery(".calculadoraRent")
								.load(
										'/portalunico/portalunico/displayviews/planesDePensiones/fichaPlanes/calculadoraRentabilidadPlan.jsp'
										+ "?codMig="
										+ codMig
										+ "&fRentDesde="
										+ fechadsd
										+ "&fRentHasta="
										+ fechahst,
										function(
												response,
												status,
												xhr) {
											if (status == "error") {
												console
												.log('status'
														+ status);
											} else {
												mostrarGrafCalcRentPlan();
											}
										});
								jQuery('.calculadoraVLP').removeClass(
								'hide');
							} else {
								jQuery('.fechinc').removeClass(
								'hide');
								jQuery(".calculadoraVLP").addClass(
								'hide');
							}
							jQuery('.frm-fechaRent1')
							.removeClass(
							'mod_form frm-message-error');
							jQuery('.fecha1Rent-errtxt')
							.addClass('hide');
							jQuery('.frm-fechaRent2')
							.removeClass(
							'mod_form frm-message-error');
							jQuery('.fecha2Rent-errtxt')
							.addClass('hide');
						} else {
							jQuery('calcContainer').empty();
							if (!valFechadsd) {
								jQuery('.frm-fechaRent1')
								.addClass(
								'mod_form frm-message-error');
								jQuery('.fecha1Rent-errtxt')
								.removeClass('hide');
							} else {
								jQuery('.frm-fechaRent1')
								.removeClass(
								'mod_form frm-message-error');
								jQuery('.fecha1Rent-errtxt')
								.addClass('hide');
							}
							if (!valFechahst) {
								jQuery('.frm-fechaRent2')
								.addClass(
								'mod_form frm-message-error');
								jQuery('.fecha2Rent-errtxt')
								.removeClass('hide');
							} else {
								jQuery('.frm-fechaRent2')
								.removeClass(
								'mod_form frm-message-error');
								jQuery('.fecha2Rent-errtxt')
								.addClass('hide');
							}
						}
					});

			jQuery('.botonCalcVLPFondo')
			.click(
					function(event) {
						event.preventDefault();
						var diadsd = jQuery('#id-text7').val();
						var mesdsd = jQuery('#id-text8').val();
						var annodsd = jQuery('#id-text9').val();
						var fechadsd = diadsd.concat('\/',
								mesdsd, '\/', annodsd);
						var codMig = jQuery('#codMig').val();

						if (validarFecha(fechadsd)) {
							jQuery(".valVLP")
							.load(
									'/portalunico/portalunico/displayviews/fondosInversion/fichaFondos/valorVLPFondo.jsp'
									+ "?fechadsd="
									+ fechadsd
									+ "&codMig="
									+ codMig,
									function(response,
											status, xhr) {

										if (status == "error") {
											console
											.log('status'
													+ status);
										} else {
											jQuery(
													'.frm-fechadsd')
													.removeClass(
													'mod_form frm-message-error');
											jQuery(
											'.fechaVLPVal-errtxt')
											.addClass(
											'hide');
										}
									});
							jQuery('.valVLP').removeClass(
							'hide');
						} else {
							jQuery('.frm-fechadsd')
							.addClass(
							'mod_form frm-message-error');
							jQuery('.fechaVLPVal-errtxt')
							.removeClass('hide');
							jQuery(".valVLP").addClass(
							'hide');
						}
					});


			//Properties
			//Prestamos

			var simPrestamosCuotaMensual = $("#simPrestamosCuotaMensual").val();
			var simPrestamosEuros = $("#simPrestamosEuros").val();
			var simPrestamosPlazo = $("#simPrestamosPlazo").val();
			var simPrestamosMeses = $("#simPrestamosMeses").val();
			var simPrestamosSolicitar = $("#simPrestamosSolicitar").val();
			var simPrestamosVerDetalles = $("#simPrestamosVerDetalles").val();
			var simPrestamosVerCondiciones = $("#simPrestamosVerCondiciones").val();
			var simPrestamosImporte = $("#simPrestamosImporte").val();
			var simPrestamosTipoInteres = $("#simPrestamosTipoInteres").val();
			var simPrestamosPorCiento = $("#simPrestamosPorCiento").val();
			var simPrestamosComisionApertura = $("#simPrestamosComisionApertura").val();
			var calculadoraInfoLegal = $("#calculadoraInfoLegal").val();
			var simPrestamosNoEncontradoPrestamo = $("#simPrestamosNoEncontradoPrestamo").val();

			var sitiositeLog = $("#sitiositeLog").val();


			//PlanesPensiones
			var simPlanesPensionesNoEncontradoPlanPension = $("#simPlanesPensionesNoEncontradoPlanPension").val();
			var simPlanesPensionesImagenPensiones = $("#simPlanesPensionesImagenPensiones").val();
			var simPlanesPensionesCapitalAcumulado = $("#simPlanesPensionesCapitalAcumulado").val();
			var simPlanesPensionesCapitalAcumuladoJubilacion = $("#simPlanesPensionesCapitalAcumuladoJubilacion").val();
			var simPlanesPensionesImporteRecibir1 = $("#simPlanesPensionesImporteRecibir1").val();
			var simPlanesPensionesDurante = $("#simPlanesPensionesDurante").val();
			var simPlanesPensionesAnios = $("#simPlanesPensionesAnios").val();
			var simPlanesPensionesImporteRecibir2 = $("#simPlanesPensionesImporteRecibir2").val();

			var simPlanesPensionesAhorroFiscal1anio = $("#simPlanesPensionesAhorroFiscal1anio").val();
			var simPlanesPensionesSolicitar = $("#simPlanesPensionesSolicitar").val();
			var simPlanesPensionesVerDetalles = $("#simPlanesPensionesVerDetalles").val();
			var simPlanesPensionesVerCondiciones = $("#simPlanesPensionesVerCondiciones").val();
			var simPlanesPensionesMostrarMasInformacion = $("#simPlanesPensionesMostrarMasInformacion").val();
			var simPlanesPensionesComparalas = $("#simPlanesPensionesComparalas").val();
			var simPlanesPensionesComparadorPlanesPensiones = $("#simPlanesPensionesComparadorPlanesPensiones").val();
			var simPlanesPensionesEscalaNivelRiesgo = $("#simPlanesPensionesEscalaNivelRiesgo").val();
			var simPlanesPensionesMenorRiesgo = $("#simPlanesPensionesMenorRiesgo").val();
			var simPlanesPensionesMayorRiesgo = $("#simPlanesPensionesMayorRiesgo").val();

			var simPlanesPensionesEuros = $("#simPlanesPensionesEuros").val();
			var simPlanesPensionesCategoriaInverco = $("#simPlanesPensionesCategoriaInverco").val();
			var simPlanesPensionesUltimoValorLiquidativo = $("#simPlanesPensionesUltimoValorLiquidativo").val();
			var simPlanesPensionesDiaUltimoValorLiquidativo = $("#simPlanesPensionesDiaUltimoValorLiquidativo").val();
			var simPlanesPensionesInversionMinimaInicial = $("#simPlanesPensionesInversionMinimaInicial").val();
			var simPlanesPensionesInversionMinimaMantener = $("#simPlanesPensionesInversionMinimaMantener").val();
			var simPlanesPensionesRentabilidadYTD = $("#simPlanesPensionesRentabilidadYTD").val();
			var simPlanesPensionesRentabilidadesAcumuladas = $("#simPlanesPensionesRentabilidadesAcumuladas").val();
			var simPlanesPensionesVolatilidad = $("#simPlanesPensionesVolatilidad").val();
			var simPlanesPensionesCerrar = $("#simPlanesPensionesCerrar").val();

			////Simuladores y calculadoras

			var valorSegmentoSolicitar = $(".segmentoSolicitar").val();
			var valorFamiliaSolicitar = $(".familiaSolicitar").val();
			var valorColectivoSolicitar = $(".colectivoSolicitar").val();
			var valorPaginaSolicitar = $(".paginaSolicitar").val();
			var valorEspacioSolicitar = $(".espacioSolicitar").val();
			var hreflang = $(".hreflang").val(); 
			var webPrivada = $("#webPrivada").val();
			var edadPrivada = $("#edadPrivada").val();


			var valorCantidadPrestamos = 0;
			if($("#cantidad").val() != undefined){
				valorCantidadPrestamos = dFrontJs.parseoNumber($("#cantidad").val().toString());
			}
			var valorPlazoPrestamos = 0;
			if($("#plazo").val() != undefined){
				valorPlazoPrestamos = dFrontJs.parseoNumber($("#plazo").val().toString());
			}
			var valorIDLista = $("#IDListaPrestamos").val();
			var valorTipoPrestamo = $("#tipoPrestamo").val();
			
			//Calculos coche
			var esCocheEcologico = false;
			if(document.getElementById("id_cocheEcologico") != null) {
				if(document.getElementById("id_cocheEcologico").checked){
					esCocheEcologico = true;
				}
			}
			var valorIDListaCoche = $("#iDListaPrestamosCoche").val(); 
			
			$( "#cantidad" ).blur(function() {
				if(valorCantidadPrestamos != $("#plazo").val()){
					var esCocheEcologico = false;
					valorCantidadPrestamos = $("#cantidad").val();
					valorPlazoPrestamos = $("#plazo").val();
					var formato = $("#formato").val();
					var canalActual = $("#canalActual").val();
					var URLFormatear = "/portalunico/nuevaSimulacionPrestamos.jsp" + "?cantidad=" + valorCantidadPrestamos + "&plazo=" + valorPlazoPrestamos + "&IDLista=" + valorIDLista + "&tipoPrestamo=" + valorTipoPrestamo + "&segmento=" + valorSegmentoSolicitar + "&familia=" + valorFamiliaSolicitar + "&colectivo=" + valorColectivoSolicitar + "&pagina=" + valorPaginaSolicitar + "&espacio=" + valorEspacioSolicitar + "&formato=" +formato;
					var uri = window.location.href;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {'simPrestamosCuotaMensual': simPrestamosCuotaMensual,'simPrestamosEuros': simPrestamosEuros,'simPrestamosPlazo': simPrestamosPlazo,'simPrestamosMeses': simPrestamosMeses,'simPrestamosSolicitar': simPrestamosSolicitar	,'simPrestamosVerDetalles': simPrestamosVerDetalles,'simPrestamosVerCondiciones': simPrestamosVerCondiciones,'simPrestamosImporte': simPrestamosImporte,'simPrestamosTipoInteres': simPrestamosTipoInteres ,'simPrestamosPorCiento': simPrestamosPorCiento,'simPrestamosComisionApertura': simPrestamosComisionApertura	,'calculadoraInfoLegal': calculadoraInfoLegal,'simPrestamosNoEncontradoPrestamo': simPrestamosNoEncontradoPrestamo, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog, 'webPrivada': webPrivada, 'edadPrivada': edadPrivada, 'IDListaCoche': valorIDListaCoche, 'esCocheEcologico': esCocheEcologico, 'canalActual': canalActual
						},
						success: function(data, textStatus )     
						{	
							if (!jQuery('#div_ajaxSimPrestamo').hasClass('hide'))
							{
								jQuery('#div_ajaxSimPrestamo').css('display','none');
								jQuery('#div_ajaxSimPrestamo').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevaSimulacion').html(data);
//							pintarTextoLegal();
							pintarDonut();	
							/** INIT ANITICA NO BORRAR*/
							digitalData.importe = valorCantidadPrestamos;
							digitalData.plazo = valorPlazoPrestamos;
							/*$("button.but-oranje.but-wAuto").click(function(e){
    							digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
    							digitalData.estado = "solicitado";
    							digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
    							_satellite.track('view');
    						    });*/
							/** END ANALITICA NO BORRAR*/
						},
						complete: function(){
							if(uri.indexOf("Mobile") > 0){
								$(".but-oranje.but-wAuto.solicitarDonut").addClass("mobile");
							}
						},
						error: function(xhr, textStatus, errorThrown){						
						}
					});
				}
			});
			$( "#cantidadCS" ).blur(function() {
				if(valorCantidadPrestamos != $("#plazoCS").val()){
					valorCantidadPrestamos = $("#cantidadCS").val();
					valorPlazoPrestamos = $("#plazoCS").val();
					var formato = $("#formato").val();
					var esCocheEcologico = true;
					var canalActual = $("#canalActual").val();
					var URLFormatear = "/portalunico/nuevaSimulacionPrestamos.jsp" + "?cantidad=" + valorCantidadPrestamos + "&plazo=" + valorPlazoPrestamos + "&IDLista=" + valorIDLista + "&tipoPrestamo=" + valorTipoPrestamo + "&segmento=" + valorSegmentoSolicitar + "&familia=" + valorFamiliaSolicitar + "&colectivo=" + valorColectivoSolicitar + "&pagina=" + valorPaginaSolicitar + "&espacio=" + valorEspacioSolicitar + "&formato=" +formato;
					var uri = window.location.href;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {'simPrestamosCuotaMensual': simPrestamosCuotaMensual,'simPrestamosEuros': simPrestamosEuros,'simPrestamosPlazo': simPrestamosPlazo,'simPrestamosMeses': simPrestamosMeses,'simPrestamosSolicitar': simPrestamosSolicitar	,'simPrestamosVerDetalles': simPrestamosVerDetalles,'simPrestamosVerCondiciones': simPrestamosVerCondiciones,'simPrestamosImporte': simPrestamosImporte,'simPrestamosTipoInteres': simPrestamosTipoInteres ,'simPrestamosPorCiento': simPrestamosPorCiento,'simPrestamosComisionApertura': simPrestamosComisionApertura	,'calculadoraInfoLegal': calculadoraInfoLegal,'simPrestamosNoEncontradoPrestamo': simPrestamosNoEncontradoPrestamo, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog, 'webPrivada': webPrivada, 'edadPrivada': edadPrivada, 'IDListaCoche': valorIDListaCoche, 'esCocheEcologico': esCocheEcologico, 'canalActual': canalActual
						},
						success: function(data, textStatus )     
						{	
							if (!jQuery('#div_ajaxSimPrestamo').hasClass('hide'))
							{
								jQuery('#div_ajaxSimPrestamo').css('display','none');
								jQuery('#div_ajaxSimPrestamo').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevaSimulacion').html(data);
//							pintarTextoLegal();
							pintarDonut();	
							/** INIT ANITICA NO BORRAR*/
							digitalData.importe = valorCantidadPrestamos;
							digitalData.plazo = valorPlazoPrestamos;
							/*$("button.but-oranje.but-wAuto").click(function(e){
    							digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
    							digitalData.estado = "solicitado";
    							digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
    							_satellite.track('view');
    						    });*/
							/** END ANALITICA NO BORRAR*/
						},
						complete: function(){
							if(uri.indexOf("Mobile") > 0){
								$(".but-oranje.but-wAuto.solicitarDonut").addClass("mobile");
							}
						},
						error: function(xhr, textStatus, errorThrown){						
						}
					});
				}
			});

			$( "#plazo" ).blur(function() {
				if(valorPlazoPrestamos != $("#plazo").val()){		  
					var esCocheEcologico = false;
					valorCantidadPrestamos = $("#cantidad").val();
					valorPlazoPrestamos = $("#plazo").val();
					var formato = $("#formato").val();
					var canalActual = $("#canalActual").val();
					var URLFormatear = "/portalunico/nuevaSimulacionPrestamos.jsp" + "?cantidad=" + valorCantidadPrestamos + "&plazo=" + valorPlazoPrestamos + "&IDLista=" + valorIDLista + "&tipoPrestamo=" + valorTipoPrestamo + "&segmento=" + valorSegmentoSolicitar + "&familia=" + valorFamiliaSolicitar + "&colectivo=" + valorColectivoSolicitar + "&pagina=" + valorPaginaSolicitar + "&espacio=" + valorEspacioSolicitar + "&formato=" +formato;
					var uri = window.location.href;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {'simPrestamosCuotaMensual': simPrestamosCuotaMensual,'simPrestamosEuros': simPrestamosEuros,'simPrestamosPlazo': simPrestamosPlazo,'simPrestamosMeses': simPrestamosMeses,'simPrestamosSolicitar': simPrestamosSolicitar	,'simPrestamosVerDetalles': simPrestamosVerDetalles,'simPrestamosVerCondiciones': simPrestamosVerCondiciones,'simPrestamosImporte': simPrestamosImporte,'simPrestamosTipoInteres': simPrestamosTipoInteres ,'simPrestamosPorCiento': simPrestamosPorCiento,'simPrestamosComisionApertura': simPrestamosComisionApertura	,'calculadoraInfoLegal': calculadoraInfoLegal,'simPrestamosNoEncontradoPrestamo': simPrestamosNoEncontradoPrestamo, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog, 'webPrivada': webPrivada, 'edadPrivada': edadPrivada, 'IDListaCoche': valorIDListaCoche, 'esCocheEcologico': esCocheEcologico,'canalActual': canalActual
						},
						success: function(data, textStatus )     
						{		
							if (!jQuery('#div_ajaxSimPrestamo').hasClass('hide'))
							{
								jQuery('#div_ajaxSimPrestamo').css('display','none');
								jQuery('#div_ajaxSimPrestamo').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevaSimulacion').html(data);
//							pintarTextoLegal();
							pintarDonut();
							/** INIT ANITICA NO BORRAR*/
							digitalData.importe = valorCantidadPrestamos;
							digitalData.plazo = valorPlazoPrestamos;
							/*$("button.but-oranje.but-wAuto").click(function(e){
    								digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
    								digitalData.estado = "solicitado";
    								digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
    								_satellite.track('view');
    							    });*/
							/** END ANALITICA NO BORRAR*/
						},
						complete: function(){
							if(uri.indexOf("Mobile") > 0){
								$(".but-oranje.but-wAuto.solicitarDonut").addClass("mobile");
							}
						},
						error: function(xhr, textStatus, errorThrown){						
						}
					});
				}
			});
			$( "#plazoCS" ).blur(function() {
				if(valorPlazoPrestamos != $("#plazoCS").val()){		  
					valorCantidadPrestamos = $("#cantidadCS").val();
					valorPlazoPrestamos = $("#plazoCS").val();
					var formato = $("#formato").val();
					var esCocheEcologico = true;
					var canalActual = $("#canalActual").val();
					var URLFormatear = "/portalunico/nuevaSimulacionPrestamos.jsp" + "?cantidad=" + valorCantidadPrestamos + "&plazo=" + valorPlazoPrestamos + "&IDLista=" + valorIDLista + "&tipoPrestamo=" + valorTipoPrestamo + "&segmento=" + valorSegmentoSolicitar + "&familia=" + valorFamiliaSolicitar + "&colectivo=" + valorColectivoSolicitar + "&pagina=" + valorPaginaSolicitar + "&espacio=" + valorEspacioSolicitar + "&formato=" +formato;
					var uri = window.location.href;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {'simPrestamosCuotaMensual': simPrestamosCuotaMensual,'simPrestamosEuros': simPrestamosEuros,'simPrestamosPlazo': simPrestamosPlazo,'simPrestamosMeses': simPrestamosMeses,'simPrestamosSolicitar': simPrestamosSolicitar	,'simPrestamosVerDetalles': simPrestamosVerDetalles,'simPrestamosVerCondiciones': simPrestamosVerCondiciones,'simPrestamosImporte': simPrestamosImporte,'simPrestamosTipoInteres': simPrestamosTipoInteres ,'simPrestamosPorCiento': simPrestamosPorCiento,'simPrestamosComisionApertura': simPrestamosComisionApertura	,'calculadoraInfoLegal': calculadoraInfoLegal,'simPrestamosNoEncontradoPrestamo': simPrestamosNoEncontradoPrestamo, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog, 'webPrivada': webPrivada, 'edadPrivada': edadPrivada, 'IDListaCoche': valorIDListaCoche, 'esCocheEcologico': esCocheEcologico, 'canalActual': canalActual
						},
						success: function(data, textStatus )     
						{		
							if (!jQuery('#div_ajaxSimPrestamo').hasClass('hide'))
							{
								jQuery('#div_ajaxSimPrestamo').css('display','none');
								jQuery('#div_ajaxSimPrestamo').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevaSimulacion').html(data);
//							pintarTextoLegal();
							pintarDonut();
							/** INIT ANITICA NO BORRAR*/
							digitalData.importe = valorCantidadPrestamos;
							digitalData.plazo = valorPlazoPrestamos;
							/*$("button.but-oranje.but-wAuto").click(function(e){
    								digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
    								digitalData.estado = "solicitado";
    								digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
    								_satellite.track('view');
    							    });*/
							/** END ANALITICA NO BORRAR*/
						},
						complete: function(){
							if(uri.indexOf("Mobile") > 0){
								$(".but-oranje.but-wAuto.solicitarDonut").addClass("mobile");
							}
						},
						error: function(xhr, textStatus, errorThrown){						
						}
					});
				}
			});

			//Funcion slider euribor sube CRIS
			var valorCuotaSubeEuribor = $("#cuotaSubeEuribor").val();
			var valorIngNetoMensual = $("#ingNetoMensual").val();
			var valorTitulo = $("#titulo").val();
			var valorFinalidad = $("#finalidad").val();
			var valorPrecioActualVivienda = $("#precioActualVivienda").val();
			var valorSliderEuriborSube = $("#euriborSubeSlider").val();
			var valorCapitalNew = $("#importe-hipotecaNecesitas").val();
			var valorPlazoNew = $("#anios-hipoteca").val();
			var valorMinimoCapitalNew = $("#minimoCapital").val();
			var valorMinimoPlazoNew = $("#minimoPlazo").val();
			var valorEuriborSubeSlider = $("#euriborSubeSlider").val();
			var valorPlazoUsuarioE = $("#plazoUsuarioE").val();
			var valorh1Plazotramo2numE = $("#h1Plazotramo2numE").val();
			var idHipoteca1 = $("#idHipoteca1").val();
			var valorEuriborNormalE = $("#euriborNormal").val();
			var valorEuriborSube = $("#euriborSubeSlider").val();

			var nuevaContactabilidadCerrar = $("#nuevaContactabilidadCerrar").val();
			var simHipotecasTuCuotaMensual = $("#simHipotecasTuCuotaMensual").val();
			var simHipotecasUnidadEuro = $("#simHipotecasUnidadEuro").val();
			var simHipotecasAnyos = $("#simHipotecasAnyos").val();
			var simHipotecasTextoTuCuota3 = $("#simHipotecasTextoTuCuota3").val();
			var simHipotecasTextoTuCuota2 = $("#simHipotecasTextoTuCuota2").val();
			var simHipotecasTextoTuCuota1 = $("#simHipotecasTextoTuCuota1").val();
			var simHipotecasTae = $("#simHipotecasTae").val();
			var simHipotecasQuePasaria = $("#simHipotecasQuePasaria").val();
			var simHipotecasEuriborSubeUn = $("#simHipotecasEuriborSubeUn").val();
			var simHipotecasTuCuotaMensual1 = $("#simHipotecasTuCuotaMensual1").val();
			var simHipotecasTextoHipoteca1 = $("#simHipotecasTextoHipoteca1").val();
			var simHipotecasTextoHipoteca2 = $("#simHipotecasTextoHipoteca2").val();
			var simHipotecasTextoHipoteca3 = $("#simHipotecasTextoHipoteca3").val();
			var simHipotecasTusIngresosBajan = $("#simHipotecasTusIngresosBajan").val();
			var botonSolicitar = $("#botonSolicitar").val();
			var simuladorHipotecasVerDetalle = $("#simuladorHipotecasVerDetalle").val();
			var simuladorHipotecasVerCondiciones = $("#simuladorHipotecasVerCondiciones").val();
			var calculadoraInfoLegal = $("#calculadoraInfoLegal").val();
			var simuladorHipotecasEuribor = $("#simuladorHipotecasEuribor").val();

			var maximoCapitalASE = $("#maximoCapitalASE").val();
			var maximoPlazoASE = $("#maximoPlazoASE").val();
			var gastosAsociadosTAEh1ASE = $("#gastosAsociadosTAEh1ASE").val();
			var gastosAsociadosTAEh2ASE = $("#gastosAsociadosTAEh2ASE").val();
			var gastosAsociadosTAEh3ASE = $("#gastosAsociadosTAEh3ASE").val();
			var nominaDomiciliada = $("#nominaDomiciliada").val();

			var ubicacionQP = $("#ubicacion").val();
			var primeraViviendaQP = $("#primeraVivienda").val();

			$("#sliderSubeEuribor").slider({
				value: valorEuriborSube,
				stop: function( event, ui ) {						
					idHipoteca1 = $("#idHipoteca1").val();
					valorEuriborSube = $("#euriborSubeSlider").val();	
					var URLFormatear = 	"/portalunico/nuevaSimulacionHipotecaQuePasaria.jsp" + "?euribor=1"  + "&cuota=" + valorCuotaSubeEuribor + "&ingresos=" + valorIngNetoMensual + "&titulo=" + valorTitulo + "&finalidad=" + valorFinalidad + "&precioActualVivienda=" + valorPrecioActualVivienda + "&euriborSube=" + valorEuriborSube + "&idHipoteca1=" + idHipoteca1 + "&euriborNormal=" + valorEuriborNormalE + "&capital=" + valorCapitalNew + "&plazo=" + valorPlazoNew + "&minimoCapital=" + valorMinimoCapitalNew + "&minimoPlazo=" + valorMinimoPlazoNew + "&euriborSubeSlider=" + valorEuriborSubeSlider + "&plazoUsuarioE=" + valorPlazoUsuarioE + "&h1Plazotramo2numE=" + valorh1Plazotramo2numE + "&maximoCapitalASE=" + maximoCapitalASE + "&maximoPlazoASE=" + maximoPlazoASE + "&gastosAsociadosTAE=" + gastosAsociadosTAEh1ASE + "&nominaDomiciliada=" +nominaDomiciliada  + "&ubicacion=" +ubicacionQP  + "&primeraVivienda=" +primeraViviendaQP;				
					jQuery.ajax({
						url: encodeURI(URLFormatear),  
						context: document.body,
						data: {'simHipotecasTuCuotaMensual1':simHipotecasTuCuotaMensual1, 'simHipotecasUnidadEuro':simHipotecasUnidadEuro, 'simHipotecasTextoHipoteca1':simHipotecasTextoHipoteca1, 'simHipotecasTextoHipoteca2':simHipotecasTextoHipoteca2, 'simHipotecasTextoHipoteca3':simHipotecasTextoHipoteca3, 'simHipotecasAnyos':simHipotecasAnyos, 'simHipotecasTae':simHipotecasTae, 'simuladorHipotecasEuribor':simuladorHipotecasEuribor, 'sitiositeLog': sitiositeLog},
						success: function (data, textStatus)
						{

							if (jQuery('#subeEuribor').length>0)
							{
								jQuery('#subeEuribor').remove();

							}
							jQuery("#nuevaSimulacionEuribor").html(data);
						},
						error: function (xhr, textStatus, errorThrown){

						}
					});
				}

			});

			$( "#euriborSubeSlider" ).blur(function() {
				valorEuriborSube = $("#euriborSubeSlider").val();
				var URLFormatear = "/portalunico/nuevaSimulacionHipotecaQuePasaria.jsp" + "?euribor=1"  + "&cuota=" + valorCuotaSubeEuribor + "&ingresos=" + valorIngNetoMensual + "&titulo=" + valorTitulo + "&finalidad=" + valorFinalidad + "&precioActualVivienda=" + valorPrecioActualVivienda + "&euriborSube=" + valorEuriborSube + "&idHipoteca1=" + idHipoteca1 + "&euriborNormal=" + valorEuriborNormalE + "&capital=" + valorCapitalNew + "&plazo=" + valorPlazoNew + "&minimoCapital=" + valorMinimoCapitalNew + "&minimoPlazo=" + valorMinimoPlazoNew + "&euriborSubeSlider=" + valorEuriborSubeSlider + "&plazoUsuarioE=" + valorPlazoUsuarioE + "&h1Plazotramo2numE=" + valorh1Plazotramo2numE + "&maximoCapitalASE=" + maximoCapitalASE + "&maximoPlazoASE=" + maximoPlazoASE + "&gastosAsociadosTAE=" + gastosAsociadosTAEh1ASE + "&nominaDomiciliada=" +nominaDomiciliada  + "&ubicacion=" +ubicacionQP  + "&primeraVivienda=" +primeraViviendaQP;
				jQuery.ajax({
					url: encodeURI(URLFormatear), 
					context: document.body,
					data: {'simHipotecasTuCuotaMensual1':simHipotecasTuCuotaMensual1, 'simHipotecasUnidadEuro':simHipotecasUnidadEuro, 'simHipotecasTextoHipoteca1':simHipotecasTextoHipoteca1, 'simHipotecasTextoHipoteca2':simHipotecasTextoHipoteca2, 'simHipotecasTextoHipoteca3':simHipotecasTextoHipoteca3, 'simHipotecasAnyos':simHipotecasAnyos, 'simHipotecasTae':simHipotecasTae, 'simuladorHipotecasEuribor':simuladorHipotecasEuribor, 'sitiositeLog': sitiositeLog},
					success: function (data, textStatus)
					{
						if (jQuery('#subeEuribor').length>0)
						{
							jQuery('#subeEuribor').remove();

						}
						jQuery("#nuevaSimulacionEuribor").html(data);
					},
					error: function (xhr, textStatus, errorThrown){

					}
				});
			});

			//Euribor para la segunda hipoteca
			var valorh2Plazotramo2numE = $("#h2Plazotramo2numE").val();
			var idHipoteca2 = $("#idHipoteca2").val();
			var valorCuotaSubeEuribor2 = $("#cuotaSubeEuribor2").val();
			var valorEuriborSube2 = $("#euriborSubeSliderh2").val();

			$("#sliderSubeEuribor_h2").slider({
				value: valorEuriborSube2,
				stop: function( event, ui ) {				
					valorEuriborSube2 = $("#euriborSubeSliderh2").val();
					var URLFormatear = "/portalunico/nuevaSimulacionHipotecaQuePasaria.jsp" + "?euribor=1"  + "&cuota=" + valorCuotaSubeEuribor2 + "&ingresos=" + valorIngNetoMensual + "&titulo=" + valorTitulo + "&finalidad=" + valorFinalidad + "&precioActualVivienda=" + valorPrecioActualVivienda + "&euriborSube=" + valorEuriborSube2 + "&idHipoteca1=" + idHipoteca2 + "&euriborNormal=" + valorEuriborNormalE + "&capital=" + valorCapitalNew + "&plazo=" + valorPlazoNew + "&minimoCapital=" + valorMinimoCapitalNew + "&minimoPlazo=" + valorMinimoPlazoNew + "&euriborSubeSlider=" + valorEuriborSubeSlider + "&plazoUsuarioE=" + valorPlazoUsuarioE + "&h1Plazotramo2numE=" + valorh2Plazotramo2numE + "&maximoCapitalASE=" + maximoCapitalASE + "&maximoPlazoASE=" + maximoPlazoASE + "&gastosAsociadosTAE=" + gastosAsociadosTAEh2ASE + "&nominaDomiciliada=" +nominaDomiciliada  + "&ubicacion=" +ubicacionQP  + "&primeraVivienda=" +primeraViviendaQP;
					jQuery.ajax({
						url: encodeURI(URLFormatear),  
						context: document.body,
						data: {'simHipotecasTuCuotaMensual1':simHipotecasTuCuotaMensual1, 'simHipotecasUnidadEuro':simHipotecasUnidadEuro, 'simHipotecasTextoHipoteca1':simHipotecasTextoHipoteca1, 'simHipotecasTextoHipoteca2':simHipotecasTextoHipoteca2, 'simHipotecasTextoHipoteca3':simHipotecasTextoHipoteca3, 'simHipotecasAnyos':simHipotecasAnyos, 'simHipotecasTae':simHipotecasTae, 'simuladorHipotecasEuribor':simuladorHipotecasEuribor, 'sitiositeLog': sitiositeLog},
						success: function (data, textStatus)
						{

							if (jQuery('.clase_ajaxEuriborh2').length>0)
							{
								jQuery('.clase_ajaxEuriborh2').remove();

							}
							jQuery("#nuevaSimulacionEuriborh2").html(data);
						},
						error: function (xhr, textStatus, errorThrown){

						}
					});
				}

			});

			$( "#euriborSubeSliderh2" ).blur(function() {
				valorEuriborSube2 = $("#euriborSubeSliderh2").val();
				var URLFormatear = "/portalunico/nuevaSimulacionHipotecaQuePasaria.jsp" + "?euribor=1"  + "&cuota=" + valorCuotaSubeEuribor2 + "&ingresos=" + valorIngNetoMensual + "&titulo=" + valorTitulo + "&finalidad=" + valorFinalidad + "&precioActualVivienda=" + valorPrecioActualVivienda + "&euriborSube=" + valorEuriborSube2 + "&idHipoteca1=" + idHipoteca2 + "&euriborNormal=" + valorEuriborNormalE + "&capital=" + valorCapitalNew + "&plazo=" + valorPlazoNew + "&minimoCapital=" + valorMinimoCapitalNew + "&minimoPlazo=" + valorMinimoPlazoNew + "&euriborSubeSlider=" + valorEuriborSubeSlider + "&plazoUsuarioE=" + valorPlazoUsuarioE + "&h1Plazotramo2numE=" + valorh2Plazotramo2numE + "&maximoCapitalASE=" + maximoCapitalASE + "&maximoPlazoASE=" + maximoPlazoASE + "&gastosAsociadosTAE=" + gastosAsociadosTAEh2ASE + "&nominaDomiciliada=" +nominaDomiciliada  + "&ubicacion=" +ubicacionQP  + "&primeraVivienda=" +primeraViviendaQP;
				jQuery.ajax({
					url: encodeURI(URLFormatear),  
					context: document.body,
					data: {'simHipotecasTuCuotaMensual1':simHipotecasTuCuotaMensual1, 'simHipotecasUnidadEuro':simHipotecasUnidadEuro, 'simHipotecasTextoHipoteca1':simHipotecasTextoHipoteca1, 'simHipotecasTextoHipoteca2':simHipotecasTextoHipoteca2, 'simHipotecasTextoHipoteca3':simHipotecasTextoHipoteca3, 'simHipotecasAnyos':simHipotecasAnyos, 'simHipotecasTae':simHipotecasTae, 'simuladorHipotecasEuribor':simuladorHipotecasEuribor, 'sitiositeLog': sitiositeLog},
					success: function (data, textStatus)
					{
						if (jQuery('.clase_ajaxEuriborh2').length>0)
						{
							jQuery('.clase_ajaxEuriborh2').remove();

						}
						jQuery("#nuevaSimulacionEuriborh2").html(data);
					},
					error: function (xhr, textStatus, errorThrown){

					}
				});
			});

			//Euribor para la tercera hipoteca
			var valorh3Plazotramo2numE = $("#h3Plazotramo2numE").val();
			var idHipoteca3 = $("#idHipoteca3").val();
			var valorCuotaSubeEuribor3 = $("#cuotaSubeEuribor3").val();
			var valorEuriborSube3 = $("#euriborSubeSliderh3").val();

			$("#sliderSubeEuribor_h3").slider({
				value: valorEuriborSube3,
				stop: function( event, ui ) {				
					valorEuriborSube3 = $("#euriborSubeSliderh3").val();
					var URLFormatear = "/portalunico/nuevaSimulacionHipotecaQuePasaria.jsp" + "?euribor=1"  + "&cuota=" + valorCuotaSubeEuribor3 + "&ingresos=" + valorIngNetoMensual + "&titulo=" + valorTitulo + "&finalidad=" + valorFinalidad + "&precioActualVivienda=" + valorPrecioActualVivienda + "&euriborSube=" + valorEuriborSube3 + "&idHipoteca1=" + idHipoteca3 + "&euriborNormal=" + valorEuriborNormalE + "&capital=" + valorCapitalNew + "&plazo=" + valorPlazoNew + "&minimoCapital=" + valorMinimoCapitalNew + "&minimoPlazo=" + valorMinimoPlazoNew + "&euriborSubeSlider=" + valorEuriborSubeSlider + "&plazoUsuarioE=" + valorPlazoUsuarioE + "&h1Plazotramo2numE=" + valorh3Plazotramo2numE + "&maximoCapitalASE=" + maximoCapitalASE + "&maximoPlazoASE=" + maximoPlazoASE + "&gastosAsociadosTAE=" + gastosAsociadosTAEh3ASE + "&nominaDomiciliada=" +nominaDomiciliada  + "&ubicacion=" +ubicacionQP  + "&primeraVivienda=" +primeraViviendaQP;
					jQuery.ajax({
						url: encodeURI(URLFormatear),  
						context: document.body,
						data: {'simHipotecasTuCuotaMensual1':simHipotecasTuCuotaMensual1, 'simHipotecasUnidadEuro':simHipotecasUnidadEuro, 'simHipotecasTextoHipoteca1':simHipotecasTextoHipoteca1, 'simHipotecasTextoHipoteca2':simHipotecasTextoHipoteca2, 'simHipotecasTextoHipoteca3':simHipotecasTextoHipoteca3, 'simHipotecasAnyos':simHipotecasAnyos, 'simHipotecasTae':simHipotecasTae, 'simuladorHipotecasEuribor':simuladorHipotecasEuribor, 'sitiositeLog': sitiositeLog},
						success: function (data, textStatus)
						{

							if (jQuery('.clase_ajaxEuriborh3').length>0)
							{
								jQuery('.clase_ajaxEuriborh3').remove();

							}
							jQuery("#nuevaSimulacionEuriborh3").html(data);
						},
						error: function (xhr, textStatus, errorThrown){

						}
					});
				}

			});

			$( "#euriborSubeSliderh3" ).blur(function() {
				valorEuriborSube3 = $("#euriborSubeSliderh3").val();
				var URLFormatear = "/portalunico/nuevaSimulacionHipotecaQuePasaria.jsp" + "?euribor=1"  + "&cuota=" + valorCuotaSubeEuribor3 + "&ingresos=" + valorIngNetoMensual + "&titulo=" + valorTitulo + "&finalidad=" + valorFinalidad + "&precioActualVivienda=" + valorPrecioActualVivienda + "&euriborSube=" + valorEuriborSube3 + "&idHipoteca1=" + idHipoteca3 + "&euriborNormal=" + valorEuriborNormalE + "&capital=" + valorCapitalNew + "&plazo=" + valorPlazoNew + "&minimoCapital=" + valorMinimoCapitalNew + "&minimoPlazo=" + valorMinimoPlazoNew + "&euriborSubeSlider=" + valorEuriborSubeSlider + "&plazoUsuarioE=" + valorPlazoUsuarioE + "&h1Plazotramo2numE=" + valorh3Plazotramo2numE + "&maximoCapitalASE=" + maximoCapitalASE + "&maximoPlazoASE=" + maximoPlazoASE + "&gastosAsociadosTAE=" + gastosAsociadosTAEh3ASE + "&nominaDomiciliada=" +nominaDomiciliada  + "&ubicacion=" +ubicacionQP  + "&primeraVivienda=" +primeraViviendaQP;
				jQuery.ajax({
					url: encodeURI(URLFormatear),  
					context: document.body,
					data: {'simHipotecasTuCuotaMensual1':simHipotecasTuCuotaMensual1, 'simHipotecasUnidadEuro':simHipotecasUnidadEuro, 'simHipotecasTextoHipoteca1':simHipotecasTextoHipoteca1, 'simHipotecasTextoHipoteca2':simHipotecasTextoHipoteca2, 'simHipotecasTextoHipoteca3':simHipotecasTextoHipoteca3, 'simHipotecasAnyos':simHipotecasAnyos, 'simHipotecasTae':simHipotecasTae, 'simuladorHipotecasEuribor':simuladorHipotecasEuribor, 'sitiositeLog': sitiositeLog},
					success: function (data, textStatus)
					{
						if (jQuery('.clase_ajaxEuriborh3').length>0)
						{
							jQuery('.clase_ajaxEuriborh3').remove();

						}
						jQuery("#nuevaSimulacionEuriborh3").html(data);
					},
					error: function (xhr, textStatus, errorThrown){

					}
				});
			});



			$("#sliderCantidad").slider({ 
				value: valorCantidadPrestamos,
				stop: function( event, ui ) {
					var uri = window.location.href;
					var esCocheEcologico = false;
					valorCantidadPrestamos = $("#cantidad").val();
					valorPlazoPrestamos = $("#plazo").val();
					var formato = $("#formato").val();
					var canalActual = $("#canalActual").val();
					var URLFormatear = "/portalunico/nuevaSimulacionPrestamos.jsp" + "?cantidad=" + valorCantidadPrestamos + "&plazo=" + valorPlazoPrestamos + "&IDLista=" + valorIDLista + "&tipoPrestamo=" + valorTipoPrestamo + "&segmento=" + valorSegmentoSolicitar + "&familia=" + valorFamiliaSolicitar + "&colectivo=" + valorColectivoSolicitar + "&pagina=" + valorPaginaSolicitar + "&espacio=" + valorEspacioSolicitar + "&formato=" +formato;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {'simPrestamosCuotaMensual': simPrestamosCuotaMensual,'simPrestamosEuros': simPrestamosEuros,'simPrestamosPlazo': simPrestamosPlazo,'simPrestamosMeses': simPrestamosMeses,'simPrestamosSolicitar': simPrestamosSolicitar	,'simPrestamosVerDetalles': simPrestamosVerDetalles,'simPrestamosVerCondiciones': simPrestamosVerCondiciones,'simPrestamosImporte': simPrestamosImporte,'simPrestamosTipoInteres': simPrestamosTipoInteres ,'simPrestamosPorCiento': simPrestamosPorCiento,'simPrestamosComisionApertura': simPrestamosComisionApertura	,'calculadoraInfoLegal': calculadoraInfoLegal,'simPrestamosNoEncontradoPrestamo': simPrestamosNoEncontradoPrestamo, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog, 'webPrivada': webPrivada, 'edadPrivada': edadPrivada, 'IDListaCoche': valorIDListaCoche, 'esCocheEcologico': esCocheEcologico, 'canalActual': canalActual
						},
						success: function(data, textStatus )     
						{         
							if (!jQuery('#div_ajaxSimPrestamo').hasClass('hide'))
							{
								jQuery('#div_ajaxSimPrestamo').css('display','none');
								jQuery('#div_ajaxSimPrestamo').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevaSimulacion').html(data);
//							pintarTextoLegal();
							pintarDonut();
							//Formateo del valor nuemrico con miles
							var dateName = $("#cantidad").attr('name');
							if($("#cantidad").val().indexOf('.') < 0 ){	
								if($("#cantidad").val() != undefined){
									var valueParse = dFrontJs.parseoNumberDec($("#cantidad").val().toString());
									var elem = document.getElementById(dateName);
									elem.value = valueParse;
								}
								if($("#cantidadPrestamoMovil").html().indexOf('.') < 0 ){
									if($("#cantidadPrestamoMovil").html() != undefined){
										var valueParse = dFrontJs.parseoNumberDec($("#cantidadPrestamoMovil").html().toString())
										var elem = document.getElementById("cantidadPrestamoMovil");
										$(elem).text(valueParse);
									}
								}
							}	

							/** INIT ANITICA NO BORRAR*/
							digitalData.importe = valorCantidadPrestamos;
							digitalData.plazo = valorPlazoPrestamos;
							/*$("button.but-oranje.but-wAuto").click(function(e){
    							digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
    							digitalData.estado = "solicitado";
    							digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
    							_satellite.track('view');
    						    });*/
							/** END ANALITICA NO BORRAR*/

						},
						complete: function(){
							if(uri.indexOf("Mobile") > 0){
								$(".but-oranje.but-wAuto.solicitarDonut").addClass("mobile");
							}
						},
						error: function(xhr, textStatus, errorThrown){         
						}
					});

				}
			});	
			$("#sliderCantidadCS").slider({
				value: valorCantidadPrestamos,
				stop: function( event, ui ) {
					var uri = window.location.href;
					valorCantidadPrestamos = $("#cantidadCS").val();
					valorPlazoPrestamos = $("#plazoCS").val();
					var formato = $("#formato").val();
					var esCocheEcologico = true;
					var canalActual = $("#canalActual").val();	
					var URLFormatear = "/portalunico/nuevaSimulacionPrestamos.jsp" + "?cantidad=" + valorCantidadPrestamos + "&plazo=" + valorPlazoPrestamos + "&IDLista=" + valorIDLista + "&tipoPrestamo=" + valorTipoPrestamo + "&segmento=" + valorSegmentoSolicitar + "&familia=" + valorFamiliaSolicitar + "&colectivo=" + valorColectivoSolicitar + "&pagina=" + valorPaginaSolicitar + "&espacio=" + valorEspacioSolicitar + "&formato=" +formato;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {'simPrestamosCuotaMensual': simPrestamosCuotaMensual,'simPrestamosEuros': simPrestamosEuros,'simPrestamosPlazo': simPrestamosPlazo,'simPrestamosMeses': simPrestamosMeses,'simPrestamosSolicitar': simPrestamosSolicitar	,'simPrestamosVerDetalles': simPrestamosVerDetalles,'simPrestamosVerCondiciones': simPrestamosVerCondiciones,'simPrestamosImporte': simPrestamosImporte,'simPrestamosTipoInteres': simPrestamosTipoInteres ,'simPrestamosPorCiento': simPrestamosPorCiento,'simPrestamosComisionApertura': simPrestamosComisionApertura	,'calculadoraInfoLegal': calculadoraInfoLegal,'simPrestamosNoEncontradoPrestamo': simPrestamosNoEncontradoPrestamo, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog, 'webPrivada': webPrivada, 'edadPrivada': edadPrivada, 'IDListaCoche': valorIDListaCoche, 'esCocheEcologico': esCocheEcologico
						},
						success: function(data, textStatus )     
						{         
							if (!jQuery('#div_ajaxSimPrestamo').hasClass('hide'))
							{
								jQuery('#div_ajaxSimPrestamo').css('display','none');
								jQuery('#div_ajaxSimPrestamo').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevaSimulacion').html(data);
//							pintarTextoLegal();
							pintarDonut();
							//Formateo del valor nuemrico con miles
							var dateName = $("#cantidadCS").attr('name');
							if($("#cantidadCS").val().indexOf('.') < 0 ){	
								if($("#cantidadCS").val() != undefined){
									var valueParse = dFrontJs.parseoNumberDec($("#cantidadCS").val().toString());
									var elem = document.getElementById(dateName);
									elem.value = valueParse;
								}
								if($("#cantidadPrestamoMovilCS").html().indexOf('.') < 0 ){
									if($("#cantidadPrestamoMovilCS").html() != undefined){
										var valueParse = dFrontJs.parseoNumberDec($("#cantidadPrestamoMovilCS").html().toString())
										var elem = document.getElementById("cantidadPrestamoMovilCS");
										$(elem).text(valueParse);
									}
								}
							}	

							/** INIT ANITICA NO BORRAR*/
							digitalData.importe = valorCantidadPrestamos;
							digitalData.plazo = valorPlazoPrestamos;
							/*$("button.but-oranje.but-wAuto").click(function(e){
    							digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
    							digitalData.estado = "solicitado";
    							digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
    							_satellite.track('view');
    						    });*/
							/** END ANALITICA NO BORRAR*/

						},
						complete: function(){
							if(uri.indexOf("Mobile") > 0){
								$(".but-oranje.but-wAuto.solicitarDonut").addClass("mobile");
							}
						},
						error: function(xhr, textStatus, errorThrown){         
						}
					});

				}
			});	
			$("#sliderPlazo").slider({ 

				value: valorPlazoPrestamos,
				stop: function( event, ui ) {
					var uri = window.location.href;

					valorCantidadPrestamos = $("#cantidad").val();
					valorPlazoPrestamos = $("#plazo").val();
					var formato = $("#formato").val();
					var esCocheEcologico = false;
					var canalActual = $("#canalActual").val();
					var URLFormatear = "/portalunico/nuevaSimulacionPrestamos.jsp" + "?cantidad=" + valorCantidadPrestamos + "&plazo=" + valorPlazoPrestamos + "&IDLista=" + valorIDLista + "&tipoPrestamo=" + valorTipoPrestamo + "&segmento=" + valorSegmentoSolicitar + "&familia=" + valorFamiliaSolicitar + "&colectivo=" + valorColectivoSolicitar + "&pagina=" + valorPaginaSolicitar + "&espacio=" + valorEspacioSolicitar + "&formato=" +formato;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {'simPrestamosCuotaMensual': simPrestamosCuotaMensual,'simPrestamosEuros': simPrestamosEuros,'simPrestamosPlazo': simPrestamosPlazo,'simPrestamosMeses': simPrestamosMeses,'simPrestamosSolicitar': simPrestamosSolicitar	,'simPrestamosVerDetalles': simPrestamosVerDetalles,'simPrestamosVerCondiciones': simPrestamosVerCondiciones,'simPrestamosImporte': simPrestamosImporte,'simPrestamosTipoInteres': simPrestamosTipoInteres ,'simPrestamosPorCiento': simPrestamosPorCiento,'simPrestamosComisionApertura': simPrestamosComisionApertura	,'calculadoraInfoLegal': calculadoraInfoLegal,'simPrestamosNoEncontradoPrestamo': simPrestamosNoEncontradoPrestamo, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog, 'webPrivada': webPrivada, 'edadPrivada': edadPrivada, 'IDListaCoche': valorIDListaCoche, 'esCocheEcologico': esCocheEcologico, 'canalActual': canalActual
						},
						success: function(data, textStatus )     
						{
							if (!jQuery('#div_ajaxSimPrestamo').hasClass('hide'))
							{
								jQuery('#div_ajaxSimPrestamo').css('display','none');
								jQuery('#div_ajaxSimPrestamo').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevaSimulacion').html(data);
//							pintarTextoLegal();
							pintarDonut();
							/** INIT ANITICA NO BORRAR*/
							digitalData.importe = valorCantidadPrestamos;
							digitalData.plazo = valorPlazoPrestamos;
							/*$("button.but-oranje.but-wAuto").click(function(e){
    							digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
    							digitalData.estado = "solicitado";
    							digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
    							_satellite.track('view');
    						    });*/
							/** END ANALITICA NO BORRAR*/
						},
						complete: function(){
							if(uri.indexOf("Mobile") > 0){
								$(".but-oranje.but-wAuto.solicitarDonut").addClass("mobile");
							}
						},
						error: function(xhr, textStatus, errorThrown){
						}
					});

				}
			});
			$("#sliderPlazoCS").slider({ 

				value: valorPlazoPrestamos,
				stop: function( event, ui ) {
					var uri = window.location.href;

					valorCantidadPrestamos = $("#cantidadCS").val();
					valorPlazoPrestamos = $("#plazoCS").val();
					var formato = $("#formato").val();
					var esCocheEcologico = true;
					var canalActual = $("#canalActual").val();
					var URLFormatear = "/portalunico/nuevaSimulacionPrestamos.jsp" + "?cantidad=" + valorCantidadPrestamos + "&plazo=" + valorPlazoPrestamos + "&IDLista=" + valorIDLista + "&tipoPrestamo=" + valorTipoPrestamo + "&segmento=" + valorSegmentoSolicitar + "&familia=" + valorFamiliaSolicitar + "&colectivo=" + valorColectivoSolicitar + "&pagina=" + valorPaginaSolicitar + "&espacio=" + valorEspacioSolicitar + "&formato=" +formato;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {'simPrestamosCuotaMensual': simPrestamosCuotaMensual,'simPrestamosEuros': simPrestamosEuros,'simPrestamosPlazo': simPrestamosPlazo,'simPrestamosMeses': simPrestamosMeses,'simPrestamosSolicitar': simPrestamosSolicitar	,'simPrestamosVerDetalles': simPrestamosVerDetalles,'simPrestamosVerCondiciones': simPrestamosVerCondiciones,'simPrestamosImporte': simPrestamosImporte,'simPrestamosTipoInteres': simPrestamosTipoInteres ,'simPrestamosPorCiento': simPrestamosPorCiento,'simPrestamosComisionApertura': simPrestamosComisionApertura	,'calculadoraInfoLegal': calculadoraInfoLegal,'simPrestamosNoEncontradoPrestamo': simPrestamosNoEncontradoPrestamo, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog, 'webPrivada': webPrivada, 'edadPrivada': edadPrivada, 'IDListaCoche': valorIDListaCoche, 'esCocheEcologico': esCocheEcologico, 'canalActual': canalActual
						},
						success: function(data, textStatus )     
						{
							if (!jQuery('#div_ajaxSimPrestamo').hasClass('hide'))
							{
								jQuery('#div_ajaxSimPrestamo').css('display','none');
								jQuery('#div_ajaxSimPrestamo').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevaSimulacion').html(data);
//							pintarTextoLegal();
							pintarDonut();
							/** INIT ANITICA NO BORRAR*/
							digitalData.importe = valorCantidadPrestamos;
							digitalData.plazo = valorPlazoPrestamos;
							/*$("button.but-oranje.but-wAuto").click(function(e){
    							digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
    							digitalData.estado = "solicitado";
    							digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
    							_satellite.track('view');
    						    });*/
							/** END ANALITICA NO BORRAR*/
						},
						complete: function(){
							if(uri.indexOf("Mobile") > 0){
								$(".but-oranje.but-wAuto.solicitarDonut").addClass("mobile");
							}
						},
						error: function(xhr, textStatus, errorThrown){
						}
					});

				}
			});


			//Simulador Hipotecas

			$("#botonComparadorHip").click(function() {
				if($("#gastosAsociadosHipoteca").length){
					$("#botonComparadorHip").css('display','none');
					$(".calc-comparador").slideToggle("slow");
				}else{
					$("#botonComparadorHip").css('display','none');
					$(".calc-open-close").toggleClass("open");
					$(".calc-comparador").slideToggle("slow");
				}  
			});

			$("#cerrarComparadorHip").click(function() {
				if($("#gastosAsociadosHipoteca").length){
					$("#botonComparadorHip").css('display','');
					$(".calc-comparador").slideToggle("slow");
				}else{
					$("#botonComparadorHip").css('display','');
					$(".calc-open-close").toggleClass("open");
					$(".calc-comparador").slideToggle("slow");
				}  
			});

			$("#botonGastosHip").click(function() {
				if($("#gastosAsociadosHipoteca").length){
					$("#botonGastosHip").css('display','none');
					$(".calc-open-close").toggleClass("open");
					$("#gastosAsociadosHipoteca").slideToggle("slow");
				}  
			});

			$("#cerrarGastosHip").click(function() {
				if($("#gastosAsociadosHipoteca").length){
					$("#botonGastosHip").css('display','');
					$(".calc-open-close").toggleClass("open");
					$("#gastosAsociadosHipoteca").slideToggle("slow");
				}  
			});


			if($("#vivienda").val() != undefined){
				var valorVivienda = dFrontJs.parseoNumber($("#vivienda").val().toString());
				$("#sliderVivienda").slider({ value: valorVivienda});
			}


			var valorAnios = $("#anios").val();

			$("#sliderAnios").slider({ 
				value: valorAnios
			});

			if($("#hipoteca").val() != undefined){
				var valorIngresos = dFrontJs.parseoNumber($("#hipoteca").val().toString());
				$("#sliderHipoteca").slider({ value: valorIngresos});
			}



			if($("#prestamos").val() != undefined){
				var valorGastos = dFrontJs.parseoNumber($("#prestamos").val().toString());
				$("#sliderGastos").slider({ value: valorGastos});
			}


			$("#id_acc_provincias").selectmenu({
				change: function(event, ui){
					mod_progressbar.changeValueForm($("#id_acc_provincias"), true);
				}
			});

			//variables de properties
			var simuladorHipotecasMensajeHipotecaEncontrada1 = $("#simuladorHipotecasMensajeHipotecaEncontrada1").val();
			var simuladorHipotecasTaeHipoteca = $("#simuladorHipotecasTaeHipoteca").val();
			var simuladorHipotecasConPrimerTramo1 = $("#simuladorHipotecasConPrimerTramo1").val();
			var simuladorHipotecasConPrimerTramo2 = $("#simuladorHipotecasConPrimerTramo2").val();
			var simuladorHipotecasConPrimerTramo3 = $("#simuladorHipotecasConPrimerTramo3").val();
			var simuladorHipotecasConPrimerTramo4 = $("#simuladorHipotecasConPrimerTramo4").val();
			var botonSolicitar = $("#botonSolicitar").val();
			var simuladorHipotecasVerDetalle = $("#simuladorHipotecasVerDetalle").val();
			var simuladorHipotecasVerCondiciones = $("#simuladorHipotecasVerCondiciones").val();
			var calculadoraInfoLegal = $("#calculadoraInfoLegal").val();
			var simuladorHipotecasMensajeHipotecaEncontrada2 = $("#simuladorHipotecasMensajeHipotecaEncontrada2").val();
			var simuladorHipotecasComparalas = $("#simuladorHipotecasComparalas").val();
			var simuladorHipotecasTituloComResultados = $("#simuladorHipotecasTituloComResultados").val();
			var simuladorHipotecasPlazoComparador = $("#simuladorHipotecasPlazoComparador").val();
			var simuladorHipotecasFinanciacionComparador = $("#simuladorHipotecasFinanciacionComparador").val();
			var simuladorHipotecasInteresComparador = $("#simuladorHipotecasInteresComparador").val();
			var simuladorHipotecasRevisionComparador = $("#simuladorHipotecasRevisionComparador").val();
			var simuladorHipotecasCuotasComparador = $("#simuladorHipotecasCuotasComparador").val();
			var simuladorHipotecasCerrarComparador = $("#simuladorHipotecasCerrarComparador").val();
			var simuladorHipotecasVerGastosAsociados = $("#simuladorHipotecasVerGastosAsociados").val();
			var simuladorHipotecasGastosCompraVentaCG = $("#simuladorHipotecasGastosCompraVentaCG").val();
			var simuladorHipotecasGastosCompraVentaMovilCG = $("#simuladorHipotecasGastosCompraVentaMovilCG").val();
			var simuladorHipotecasGastosHipotecaCG = $("#simuladorHipotecasGastosHipotecaCG").val();
			var simuladorHipotecasIvaTransCG = $("#simuladorHipotecasIvaTransCG").val();
			var simuladorHipotecasImpTasacionCG = $("#simuladorHipotecasImpTasacionCG").val();
			var simuladorHipotecasNotarioCG = $("#simuladorHipotecasNotarioCG").val();
			var simuladorHipotecasRegistroCG = $("#simuladorHipotecasRegistroCG").val();
			var simuladorHipotecasAjdCG = $("#simuladorHipotecasAjdCG").val();
			var simuladorHipotecasGestoriaCG = $("#simuladorHipotecasGestoriaCG").val();
			var simuladorHipotecasTotalCG = $("#simuladorHipotecasTotalCG").val();
			var simuladorHipotecasGastosTotalesCG = $("#simuladorHipotecasGastosTotalesCG").val();
			var simuladorHipotecasCerrarGastosAsociados = $("#simuladorHipotecasCerrarGastosAsociados").val();
			var simuladorHipotecasSinPrimerTramo = $("#simuladorHipotecasSinPrimerTramo").val();
			var simuladorHipotecasCompVerMasInformacion = $("#simuladorHipotecasCompVerMasInformacion").val();
			var simuladorHipotecasCalculadoraGastos = $("#simuladorHipotecasCalculadoraGastos").val();
			var simuladorHipotecasHipotecasNoEncontradas = $("#simuladorHipotecasHipotecasNoEncontradas").val();


			var valorPriVivienda = $("").val();	


			var valorCapital = 0;
			if($("#vivienda").val() != undefined){
				valorCapital = dFrontJs.parseoNumber($("#vivienda").val().toString());
			}

			var valorPlazoHipoteca = 0;
			if($("#hipoteca").val() != undefined){
				valorPlazoHipoteca = dFrontJs.parseoNumber($("#hipoteca").val().toString());
			}

			var idListaHipotecasSimH = $("#IDListaHipotecas").val();
			var priviviendaSimH = $("#privivienda").val();
			var valorviviendaSimH = $("#valorvivienda").val();


			var ingresosSimH = 0;
			if($("#ingresos").val() != undefined){
				ingresosSimH = dFrontJs.parseoNumber($("#ingresos").val().toString());
			}

			var gastosSimH = 0;
			if($("#gastos").val() != undefined){
				gastosSimH = dFrontJs.parseoNumber($("#gastos").val().toString());
			}


			var minimoCapitalSimH = $("#minimoCapital").val();
			var plazoMinimoSimH = $("#plazoMinimo").val();
			var euriborNormalSimH = $("#euriborNormal").val();
			var tituloHipotecaCalc = $("#tituloHipotecaCalc").val();

			var tipoInmuebleSimH = $("#tipoInmueble").val();
			var ubicacionSimH = $("#ubicacion").val();

			$( "#vivienda" ).blur(function() {

				if(valorCapital != $("#vivienda").val()){

					valorCapital = $("#vivienda").val();
					valorPlazoHipoteca = $("#hipoteca").val();
					var URLFormatear = "/portalunico/nuevaSimulacionHipoteca.jsp" + "?capital=" + valorCapital + "&plazo=" + valorPlazoHipoteca + "&IDListaHipotecas=" + idListaHipotecasSimH + "&privivienda=" + priviviendaSimH +"&valorvivienda=" + valorviviendaSimH + "&ingresos=" +ingresosSimH+"&gastos=" + gastosSimH + "&tipoInmueble=" + tipoInmuebleSimH +"&ubicacion=" + ubicacionSimH + "&minimoCapital=" +minimoCapitalSimH+"&plazoMinimo=" +plazoMinimoSimH+ "&euriborNormal=" +euriborNormalSimH +"&titulo=" +tituloHipotecaCalc;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {'paramsSeguir':'1',
							'simuladorHipotecasMensajeHipotecaEncontrada1':simuladorHipotecasMensajeHipotecaEncontrada1,
							'simuladorHipotecasTaeHipoteca':simuladorHipotecasTaeHipoteca,
							'simuladorHipotecasConPrimerTramo1':simuladorHipotecasConPrimerTramo1,
							'simuladorHipotecasConPrimerTramo2':simuladorHipotecasConPrimerTramo2,
							'simuladorHipotecasConPrimerTramo3':simuladorHipotecasConPrimerTramo3,
							'simuladorHipotecasConPrimerTramo4':simuladorHipotecasConPrimerTramo4,
							'botonSolicitar':botonSolicitar,
							'simuladorHipotecasVerDetalle':simuladorHipotecasVerDetalle,
							'simuladorHipotecasVerCondiciones':simuladorHipotecasVerCondiciones,
							'calculadoraInfoLegal':calculadoraInfoLegal,
							'simuladorHipotecasMensajeHipotecaEncontrada2':simuladorHipotecasMensajeHipotecaEncontrada2,
							'simuladorHipotecasComparalas':simuladorHipotecasComparalas,
							'simuladorHipotecasTituloComResultados':simuladorHipotecasTituloComResultados,
							'simuladorHipotecasPlazoComparador':simuladorHipotecasPlazoComparador,
							'simuladorHipotecasFinanciacionComparador':simuladorHipotecasFinanciacionComparador,
							'simuladorHipotecasInteresComparador':simuladorHipotecasInteresComparador,
							'simuladorHipotecasRevisionComparador':simuladorHipotecasRevisionComparador,
							'simuladorHipotecasCuotasComparador':simuladorHipotecasCuotasComparador,
							'simuladorHipotecasCerrarComparador':simuladorHipotecasCerrarComparador,
							'simuladorHipotecasVerGastosAsociados':simuladorHipotecasVerGastosAsociados ,
							'simuladorHipotecasGastosCompraVentaCG':simuladorHipotecasGastosCompraVentaCG,
							'simuladorHipotecasGastosCompraVentaMovilCG':simuladorHipotecasGastosCompraVentaMovilCG,
							'simuladorHipotecasGastosHipotecaCG':simuladorHipotecasGastosHipotecaCG,
							'simuladorHipotecasIvaTransCG':simuladorHipotecasIvaTransCG,
							'simuladorHipotecasImpTasacionCG':simuladorHipotecasImpTasacionCG,
							'simuladorHipotecasNotarioCG':simuladorHipotecasNotarioCG,
							'simuladorHipotecasRegistroCG':simuladorHipotecasRegistroCG,
							'simuladorHipotecasAjdCG':simuladorHipotecasAjdCG,
							'simuladorHipotecasGestoriaCG':simuladorHipotecasGestoriaCG,
							'simuladorHipotecasTotalCG':simuladorHipotecasTotalCG,
							'simuladorHipotecasGastosTotalesCG':simuladorHipotecasGastosTotalesCG,
							'simuladorHipotecasCerrarGastosAsociados':simuladorHipotecasCerrarGastosAsociados,
							'simuladorHipotecasSinPrimerTramo':simuladorHipotecasSinPrimerTramo,
							'simuladorHipotecasCompVerMasInformacion':simuladorHipotecasCompVerMasInformacion,
							'simuladorHipotecasCalculadoraGastos':simuladorHipotecasCalculadoraGastos,
							'simuladorHipotecasHipotecasNoEncontradas':simuladorHipotecasHipotecasNoEncontradas,
							'hreflang': hreflang
						},
						success: function(data, textStatus )    
						{
							if (!jQuery('.clase_ajax').hasClass('hide'))
							{
								jQuery('.clase_ajax').css('display','none');
								jQuery('.clase_ajax').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevaSimulacion').html(data);
//							pintarTextoLegal();
							pintarDonut();


							initOpenClose.init(".botonComparadorHip",".cerrarComparadorHip", ".calc-comparador", "");
							initOpenClose.init(".botonGastosHip",".cerrarGastosHip", ".gastosAsociadosHipoteca", ".calc-open-close");
							/** INIT ANITICA NO BORRAR*/
							digitalData.importe = valorCapital;
							digitalData.plazo = valorPlazoHipoteca;
							/*$("button.but-oranje.but-wAuto").click(function(e){
    						digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
    						digitalData.estado = "solicitado";
    						digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
    						_satellite.track('view');
    					    });*/
							/** END ANALITICA NO BORRAR*/

						},
						error: function(xhr, textStatus, errorThrown){

						}
					});
				}

			});

			$( "#hipoteca" ).blur(function() {

				if(valorPlazoHipoteca != $("#hipoteca").val()){

					valorCapital = $("#vivienda").val();
					valorPlazoHipoteca = $("#hipoteca").val();
					var URLFormatear = "/portalunico/nuevaSimulacionHipoteca.jsp" + "?capital=" + valorCapital + "&plazo=" +valorPlazoHipoteca+ "&IDListaHipotecas=" + idListaHipotecasSimH + "&privivienda=" + priviviendaSimH +"&valorvivienda=" + valorviviendaSimH + "&ingresos=" +ingresosSimH+"&gastos=" + gastosSimH + "&tipoInmueble=" + tipoInmuebleSimH +"&ubicacion=" + ubicacionSimH + "&minimoCapital=" +minimoCapitalSimH+"&plazoMinimo=" +plazoMinimoSimH+ "&euriborNormal=" +euriborNormalSimH+"&titulo=" +tituloHipotecaCalc;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {'paramsSeguir':'1',
							'simuladorHipotecasMensajeHipotecaEncontrada1':simuladorHipotecasMensajeHipotecaEncontrada1,
							'simuladorHipotecasTaeHipoteca':simuladorHipotecasTaeHipoteca,
							'simuladorHipotecasConPrimerTramo1':simuladorHipotecasConPrimerTramo1,
							'simuladorHipotecasConPrimerTramo2':simuladorHipotecasConPrimerTramo2,
							'simuladorHipotecasConPrimerTramo3':simuladorHipotecasConPrimerTramo3,
							'simuladorHipotecasConPrimerTramo4':simuladorHipotecasConPrimerTramo4,
							'botonSolicitar':botonSolicitar,
							'simuladorHipotecasVerDetalle':simuladorHipotecasVerDetalle,
							'simuladorHipotecasVerCondiciones':simuladorHipotecasVerCondiciones,
							'calculadoraInfoLegal':calculadoraInfoLegal,
							'simuladorHipotecasMensajeHipotecaEncontrada2':simuladorHipotecasMensajeHipotecaEncontrada2,
							'simuladorHipotecasComparalas':simuladorHipotecasComparalas,
							'simuladorHipotecasTituloComResultados':simuladorHipotecasTituloComResultados,
							'simuladorHipotecasPlazoComparador':simuladorHipotecasPlazoComparador,
							'simuladorHipotecasFinanciacionComparador':simuladorHipotecasFinanciacionComparador,
							'simuladorHipotecasInteresComparador':simuladorHipotecasInteresComparador,
							'simuladorHipotecasRevisionComparador':simuladorHipotecasRevisionComparador,
							'simuladorHipotecasCuotasComparador':simuladorHipotecasCuotasComparador,
							'simuladorHipotecasCerrarComparador':simuladorHipotecasCerrarComparador,
							'simuladorHipotecasVerGastosAsociados':simuladorHipotecasVerGastosAsociados ,
							'simuladorHipotecasGastosCompraVentaCG':simuladorHipotecasGastosCompraVentaCG,
							'simuladorHipotecasGastosCompraVentaMovilCG':simuladorHipotecasGastosCompraVentaMovilCG,
							'simuladorHipotecasGastosHipotecaCG':simuladorHipotecasGastosHipotecaCG,
							'simuladorHipotecasIvaTransCG':simuladorHipotecasIvaTransCG,
							'simuladorHipotecasImpTasacionCG':simuladorHipotecasImpTasacionCG,
							'simuladorHipotecasNotarioCG':simuladorHipotecasNotarioCG,
							'simuladorHipotecasRegistroCG':simuladorHipotecasRegistroCG,
							'simuladorHipotecasAjdCG':simuladorHipotecasAjdCG,
							'simuladorHipotecasGestoriaCG':simuladorHipotecasGestoriaCG,
							'simuladorHipotecasTotalCG':simuladorHipotecasTotalCG,
							'simuladorHipotecasGastosTotalesCG':simuladorHipotecasGastosTotalesCG,
							'simuladorHipotecasCerrarGastosAsociados':simuladorHipotecasCerrarGastosAsociados,
							'simuladorHipotecasSinPrimerTramo':simuladorHipotecasSinPrimerTramo,
							'simuladorHipotecasCompVerMasInformacion':simuladorHipotecasCompVerMasInformacion,
							'simuladorHipotecasCalculadoraGastos':simuladorHipotecasCalculadoraGastos,
							'simuladorHipotecasHipotecasNoEncontradas':simuladorHipotecasHipotecasNoEncontradas,
							'hreflang': hreflang
						},
						success: function(data, textStatus )     
						{
							if (!jQuery('.clase_ajax').hasClass('hide'))
							{
								jQuery('.clase_ajax').css('display','none');
								jQuery('.clase_ajax').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}

							jQuery('#nuevaSimulacion').html(data);
//							pintarTextoLegal();
							pintarDonut();

							initOpenClose.init(".botonComparadorHip",".cerrarComparadorHip", ".calc-comparador", "");
							initOpenClose.init(".botonGastosHip",".cerrarGastosHip", ".gastosAsociadosHipoteca", ".calc-open-close");
							/** INIT ANITICA NO BORRAR*/
							digitalData.importe = valorCapital;
							digitalData.plazo = valorPlazoHipoteca;
							/*$("button.but-oranje.but-wAuto").click(function(e){
    						digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
    						digitalData.estado = "solicitado";
    						digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
    						_satellite.track('view');
    					    });*/
							/** END ANALITICA NO BORRAR*/
						},
						error: function(xhr, textStatus, errorThrown){

						}
					});
				}

			});

			$("#sliderCapital").slider({ 

				value: valorCapital,
				stop: function( event, ui ) {

					valorCapital = $("#vivienda").val();
					valorPlazoHipoteca = $("#hipoteca").val();
					var URLFormatear = "/portalunico/nuevaSimulacionHipoteca.jsp" + "?capital=" + valorCapital + "&plazo=" + valorPlazoHipoteca+"&IDListaHipotecas=" + idListaHipotecasSimH + "&privivienda=" + priviviendaSimH +"&valorvivienda=" + valorviviendaSimH + "&ingresos=" +ingresosSimH+"&gastos=" + gastosSimH + "&tipoInmueble=" + tipoInmuebleSimH +"&ubicacion=" + ubicacionSimH + "&minimoCapital=" +minimoCapitalSimH+"&plazoMinimo=" +plazoMinimoSimH+ "&euriborNormal=" +euriborNormalSimH+"&titulo=" +tituloHipotecaCalc;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {'paramsSeguir':'1',
							'simuladorHipotecasMensajeHipotecaEncontrada1':simuladorHipotecasMensajeHipotecaEncontrada1,
							'simuladorHipotecasTaeHipoteca':simuladorHipotecasTaeHipoteca,
							'simuladorHipotecasConPrimerTramo1':simuladorHipotecasConPrimerTramo1,
							'simuladorHipotecasConPrimerTramo2':simuladorHipotecasConPrimerTramo2,
							'simuladorHipotecasConPrimerTramo3':simuladorHipotecasConPrimerTramo3,
							'simuladorHipotecasConPrimerTramo4':simuladorHipotecasConPrimerTramo4,
							'botonSolicitar':botonSolicitar,
							'simuladorHipotecasVerDetalle':simuladorHipotecasVerDetalle,
							'simuladorHipotecasVerCondiciones':simuladorHipotecasVerCondiciones,
							'calculadoraInfoLegal':calculadoraInfoLegal,
							'simuladorHipotecasMensajeHipotecaEncontrada2':simuladorHipotecasMensajeHipotecaEncontrada2,
							'simuladorHipotecasComparalas':simuladorHipotecasComparalas,
							'simuladorHipotecasTituloComResultados':simuladorHipotecasTituloComResultados,
							'simuladorHipotecasPlazoComparador':simuladorHipotecasPlazoComparador,
							'simuladorHipotecasFinanciacionComparador':simuladorHipotecasFinanciacionComparador,
							'simuladorHipotecasInteresComparador':simuladorHipotecasInteresComparador,
							'simuladorHipotecasRevisionComparador':simuladorHipotecasRevisionComparador,
							'simuladorHipotecasCuotasComparador':simuladorHipotecasCuotasComparador,
							'simuladorHipotecasCerrarComparador':simuladorHipotecasCerrarComparador,
							'simuladorHipotecasVerGastosAsociados':simuladorHipotecasVerGastosAsociados ,
							'simuladorHipotecasGastosCompraVentaCG':simuladorHipotecasGastosCompraVentaCG,
							'simuladorHipotecasGastosCompraVentaMovilCG':simuladorHipotecasGastosCompraVentaMovilCG,
							'simuladorHipotecasGastosHipotecaCG':simuladorHipotecasGastosHipotecaCG,
							'simuladorHipotecasIvaTransCG':simuladorHipotecasIvaTransCG,
							'simuladorHipotecasImpTasacionCG':simuladorHipotecasImpTasacionCG,
							'simuladorHipotecasNotarioCG':simuladorHipotecasNotarioCG,
							'simuladorHipotecasRegistroCG':simuladorHipotecasRegistroCG,
							'simuladorHipotecasAjdCG':simuladorHipotecasAjdCG,
							'simuladorHipotecasGestoriaCG':simuladorHipotecasGestoriaCG,
							'simuladorHipotecasTotalCG':simuladorHipotecasTotalCG,
							'simuladorHipotecasGastosTotalesCG':simuladorHipotecasGastosTotalesCG,
							'simuladorHipotecasCerrarGastosAsociados':simuladorHipotecasCerrarGastosAsociados,
							'simuladorHipotecasSinPrimerTramo':simuladorHipotecasSinPrimerTramo,
							'simuladorHipotecasCompVerMasInformacion':simuladorHipotecasCompVerMasInformacion,
							'simuladorHipotecasCalculadoraGastos':simuladorHipotecasCalculadoraGastos,
							'simuladorHipotecasHipotecasNoEncontradas':simuladorHipotecasHipotecasNoEncontradas,
							'hreflang': hreflang
						},
						success: function(data, textStatus )     
						{
							if (!jQuery('.clase_ajax').hasClass('hide'))
							{
								jQuery('.clase_ajax').css('display','none');
								jQuery('.clase_ajax').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}

							jQuery('#nuevaSimulacion').html(data);
//							pintarTextoLegal();
							pintarDonut();
							//Formateo del valor nuemrico con miles
							var dataName = $("#vivienda").attr('name');
							if($("#vivienda").val().indexOf('.') < 0 ){
								if($("#vivienda").val() != undefined){
									var valueParse = dFrontJs.parseoNumberDec($("#vivienda").val().toString());
									var elem = document.getElementById(dataName);
									elem.value = valueParse;
								}
							}
							initOpenClose.init(".botonComparadorHip",".cerrarComparadorHip", ".calc-comparador", "");
							initOpenClose.init(".botonGastosHip",".cerrarGastosHip", ".gastosAsociadosHipoteca", ".calc-open-close");
							/** INIT ANITICA NO BORRAR*/
							digitalData.importe = valorCapital;
							digitalData.plazo = valorPlazoHipoteca;
							/*$("button.but-oranje.but-wAuto").click(function(e){
    						digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
    						digitalData.estado = "solicitado";
    						digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
    						_satellite.track('view');
    					    });*/
							/** END ANALITICA NO BORRAR*/
						},
						error: function(xhr, textStatus, errorThrown){

						}
					});
				}
			});

			$("#sliderPlazoHipoteca").slider({ 
				value: valorPlazoHipoteca,
				stop: function( event, ui ) {
					valorCapital = $("#vivienda").val();
					valorPlazoHipoteca = $("#hipoteca").val();  
					var URLFormatear = 	"/portalunico/nuevaSimulacionHipoteca.jsp" + "?capital=" + valorCapital + "&plazo=" + valorPlazoHipoteca+ "&IDListaHipotecas=" + idListaHipotecasSimH + "&privivienda=" + priviviendaSimH +"&valorvivienda=" + valorviviendaSimH + "&ingresos=" +ingresosSimH+"&gastos=" + gastosSimH + "&tipoInmueble=" + tipoInmuebleSimH +"&ubicacion=" + ubicacionSimH + "&minimoCapital=" +minimoCapitalSimH+"&plazoMinimo=" +plazoMinimoSimH+ "&euriborNormal=" +euriborNormalSimH+"&titulo=" +tituloHipotecaCalc;				
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {'paramsSeguir':'1',
							'simuladorHipotecasMensajeHipotecaEncontrada1':simuladorHipotecasMensajeHipotecaEncontrada1,
							'simuladorHipotecasTaeHipoteca':simuladorHipotecasTaeHipoteca,
							'simuladorHipotecasConPrimerTramo1':simuladorHipotecasConPrimerTramo1,
							'simuladorHipotecasConPrimerTramo2':simuladorHipotecasConPrimerTramo2,
							'simuladorHipotecasConPrimerTramo3':simuladorHipotecasConPrimerTramo3,
							'simuladorHipotecasConPrimerTramo4':simuladorHipotecasConPrimerTramo4,
							'botonSolicitar':botonSolicitar,
							'simuladorHipotecasVerDetalle':simuladorHipotecasVerDetalle,
							'simuladorHipotecasVerCondiciones':simuladorHipotecasVerCondiciones,
							'calculadoraInfoLegal':calculadoraInfoLegal,
							'simuladorHipotecasMensajeHipotecaEncontrada2':simuladorHipotecasMensajeHipotecaEncontrada2,
							'simuladorHipotecasComparalas':simuladorHipotecasComparalas,
							'simuladorHipotecasTituloComResultados':simuladorHipotecasTituloComResultados,
							'simuladorHipotecasPlazoComparador':simuladorHipotecasPlazoComparador,
							'simuladorHipotecasFinanciacionComparador':simuladorHipotecasFinanciacionComparador,
							'simuladorHipotecasInteresComparador':simuladorHipotecasInteresComparador,
							'simuladorHipotecasRevisionComparador':simuladorHipotecasRevisionComparador,
							'simuladorHipotecasCuotasComparador':simuladorHipotecasCuotasComparador,
							'simuladorHipotecasCerrarComparador':simuladorHipotecasCerrarComparador,
							'simuladorHipotecasVerGastosAsociados':simuladorHipotecasVerGastosAsociados ,
							'simuladorHipotecasGastosCompraVentaCG':simuladorHipotecasGastosCompraVentaCG,
							'simuladorHipotecasGastosCompraVentaMovilCG':simuladorHipotecasGastosCompraVentaMovilCG,
							'simuladorHipotecasGastosHipotecaCG':simuladorHipotecasGastosHipotecaCG,
							'simuladorHipotecasIvaTransCG':simuladorHipotecasIvaTransCG,
							'simuladorHipotecasImpTasacionCG':simuladorHipotecasImpTasacionCG,
							'simuladorHipotecasNotarioCG':simuladorHipotecasNotarioCG,
							'simuladorHipotecasRegistroCG':simuladorHipotecasRegistroCG,
							'simuladorHipotecasAjdCG':simuladorHipotecasAjdCG,
							'simuladorHipotecasGestoriaCG':simuladorHipotecasGestoriaCG,
							'simuladorHipotecasTotalCG':simuladorHipotecasTotalCG,
							'simuladorHipotecasGastosTotalesCG':simuladorHipotecasGastosTotalesCG,
							'simuladorHipotecasCerrarGastosAsociados':simuladorHipotecasCerrarGastosAsociados,
							'simuladorHipotecasSinPrimerTramo':simuladorHipotecasSinPrimerTramo,
							'simuladorHipotecasCompVerMasInformacion':simuladorHipotecasCompVerMasInformacion,
							'simuladorHipotecasCalculadoraGastos':simuladorHipotecasCalculadoraGastos,
							'simuladorHipotecasHipotecasNoEncontradas':simuladorHipotecasHipotecasNoEncontradas,
							'hreflang': hreflang
						},
						success: function(data, textStatus)     
						{
							if (!jQuery('.clase_ajax').hasClass('hide'))
							{
								jQuery('.clase_ajax').css('display','none');
								jQuery('.clase_ajax').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevaSimulacion').html(data);
//							pintarTextoLegal();
							pintarDonut();


							initOpenClose.init(".botonComparadorHip",".cerrarComparadorHip", ".calc-comparador", "");
							initOpenClose.init(".botonGastosHip",".cerrarGastosHip", ".gastosAsociadosHipoteca", ".calc-open-close");
							/** INIT ANITICA NO BORRAR*/
							digitalData.importe = valorCapital;
							digitalData.plazo = valorPlazoHipoteca;

							/*$("button.but-oranje.but-wAuto").click(function(e){
    						digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
    						digitalData.estado = "solicitado";
    						digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
    						_satellite.track('view');
    					    });*/
							/** END ANALITICA NO BORRAR*/
						},
						error: function(xhr, textStatus, errorThrown){

						}
					});  
				}
			});
			//simulador de hipoteca paso a paso
//			var valorVivienda = $("#val-vivienda").val();

//			$("#sliderVivienda").slider({ 
//			value: valorVivienda
//			});


//			var valorIngresos = $("#hipoteca").val();

//			$("#sliderHipoteca").slider({ 
//			value: valorIngresos
//			});

//			var valorGastos = $("#prestamos").val();

//			$("#sliderGastos").slider({ 
//			value: valorGastos
//			});

			var valorPriVivienda = $("").val();	
			var valorCapital = $("#cantidad").val();
			var valorPlazoHipotecaPasos = $("#anios").val();

			var idListaHipotecasSimH = $("#IDListaHipotecas").val();
			var priviviendaSimH = $("#privivienda").val();
			var valorviviendaSimH = $("#valorvivienda").val();
			var ingresosSimH = $("#ingresos").val();
			var gastosSimH = $("#gastos").val();
			var minimoCapitalSimH = $("#minimoCapital").val();
			var plazoMinimoSimH = $("#plazoMinimo").val();
			var euriborNormalSimH = $("#euriborNormal").val();
			var tituloHipotecaCalc = $("#tituloHipotecaCalc").val();



			$("#sliderCapitalPasos").slider({ 
				value: valorCapital,
				stop: function( event, ui ) {

					valorCapital = $("#cantidad").val();
					valorPlazoHipotecaPasos = $("#anios").val();
					var URLFormatear = "/portalunico/nuevaSimulacionHipotecaPasos.jsp" + "?capital=" + valorCapital + "&plazo=" + valorPlazoHipotecaPasos+"&IDListaHipotecas=" + idListaHipotecasSimH + "&privivienda=" + priviviendaSimH +"&valorvivienda=" + valorviviendaSimH + "&ingresos=" +ingresosSimH+"&gastos=" + gastosSimH + "&minimoCapital=" +minimoCapitalSimH+"&plazoMinimo=" +plazoMinimoSimH+ "&euriborNormal=" +euriborNormalSimH+"&titulo=" +tituloHipotecaCalc;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {'paramsSeguir':'1'},
						success: function(data, textStatus )     
						{
							if (!jQuery('.clase_ajax').hasClass('hide'))
							{
								jQuery('.clase_ajax').css('display','none');
								jQuery('.clase_ajax').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevaSimulacionPasos').html(data);
//							pintarTextoLegal();

						},
						error: function(xhr, textStatus, errorThrown){

						}
					});

				}

			});

			$("#sliderPlazoHipotecaPasos").slider({ 
				value: valorPlazoHipotecaPasos,
				stop: function( event, ui ) {
					valorCapital = $("#cantidad").val();
					valorPlazoHipotecaPasos = $("#anios").val();  
					var URLFormatear = 	"/portalunico/nuevaSimulacionHipotecaPasos.jsp" + "?capital=" + valorCapital + "&plazo=" + valorPlazoHipotecaPasos+ "&IDListaHipotecas=" + idListaHipotecasSimH + "&privivienda=" + priviviendaSimH +"&valorvivienda=" + valorviviendaSimH + "&ingresos=" +ingresosSimH+"&gastos=" + gastosSimH + "&minimoCapital=" +minimoCapitalSimH+"&plazoMinimo=" +plazoMinimoSimH+ "&euriborNormal=" +euriborNormalSimH+"&titulo=" +tituloHipotecaCalc;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {'paramsSeguir':'1'},
						success: function(data, textStatus)     
						{
							if (!jQuery('.clase_ajax').hasClass('hide'))
							{
								jQuery('.clase_ajax').css('display','none');
								jQuery('.clase_ajax').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevaSimulacionPasos').html(data);
//							pintarTextoLegal();

						},
						error: function(xhr, textStatus, errorThrown){

						}
					});  

				}
			});

			//simulador Planes pensiones
			var valorAhorroMes = 0;
			if($("#vivienda").val() != undefined){
				valorAhorroMes = dFrontJs.parseoNumber($("#vivienda").val().toString());
			}
			var valorEdadJubilacion = 0;
			if($("#hipoteca").val() != undefined){
				valorEdadJubilacion = dFrontJs.parseoNumber($("#hipoteca").val().toString());
			}
			var valorAhorrarCA = 0;
			if($("#viviendaAhorro").val() != undefined){
				valorAhorrarCA = dFrontJs.parseoNumber($("#viviendaAhorro").val().toString());
			}
			var valorAhorradoJubilacion = 0;
			if($("#viviendaAhorro").val() != undefined){
				valorAhorradoJubilacion = dFrontJs.parseoNumber($("#viviendaAhorro").val().toString());
			}
			var valorEdadJubilacionCA = 0;
			if($("#hipotecaAhorro").val() != undefined){
				valorEdadJubilacionCA = dFrontJs.parseoNumber($("#hipotecaAhorro").val().toString());
			}
			var valorIDListaPensiones = $("#IDListaPensiones").val();
			var valorIDDatosSimuladores = $("#IDDatosSimuladores").val();
			var valorEdadAjax = 0;
			if($("#edadAjax").val() != undefined){
				valorEdadAjax = dFrontJs.parseoNumber($("#edadAjax").val().toString());
			}
			var valorIngresosBrutosAjax = 0;
			if($("#ingresosBrutosAjax").val() != undefined){
				valorIngresosBrutosAjax = dFrontJs.parseoNumber($("#ingresosBrutosAjax").val().toString());
			}
			var valorOtrosAhorrosAjax = 0;
			if($("#otrosAhorrosAjax").val() != undefined){
				valorOtrosAhorrosAjax = dFrontJs.parseoNumber($("#otrosAhorrosAjax").val().toString());
			}
			var valorIDImagenEdadAjax = $("#iDImagenEdadAjax").val();
			var valorTipoEnvioAjax = $("#tipoEnvioAjax").val();


			$( "#ahorrado" ).keydown(function (e) {
				if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
						// Ctrl+A
						(e.keyCode == 65 && e.ctrlKey === true) ||
						// Ctrl+C
						(e.keyCode == 67 && e.ctrlKey === true) ||
						// Ctrl+X
						(e.keyCode == 88 && e.ctrlKey === true) ||
						// home, end, left, right
						(e.keyCode >= 35 && e.keyCode <= 39)) {
					// No hace nada
					return;
				}
				// Asegura que es un nÃƒÆ’Ã‚Âºmero y previene
				if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
					e.preventDefault();
				}
			});

			$( "#ahorrado" ).blur(function() {
				//alert("1 blur ahorrado");
				var otrAhorradoVal = $("#ahorrado").val();
				var otrAhorrosMin = parseInt($("#otrosAhorrosMin").val());
				var otrAhorrosMax = parseInt($("#otrosAhorrosMax").val());
				//alert("2 blur ahorrado. El mayor es: "+otrAhorrosMax+" y el valor en el input es: "+otrAhorradoVal);
				if(otrAhorradoVal == null ||otrAhorradoVal == ''){
					//alert("21 blur ahorrado. Valor nulo");
					$("#ahorrado").val($("#otrosAhorrosMin").val());
					$("#ahorrado").css('border', '1px solid #AAAAAA');
					$("#id_error_otrAhorros1").addClass("hide");
					$("#id_etiquetaOtrAhorros1").css('color', '#000000');
				}else{
					//alert("22 blur ahorrado. Valor correcto");
					var otrAhorradoValInt = parseInt($('#ahorrado').val());
					if(otrAhorrosMin > otrAhorradoValInt || otrAhorradoValInt > otrAhorrosMax){
						//alert("22 blur ahorrado. Valor incorrecto por max y min");
						$("#ahorrado").css('border', '1px solid #D63F3F');
						$("#id_error_otrAhorros1").removeClass("hide");
						$("#id_etiquetaOtrAhorros1").css('color', '#D63F3F');
					}else{
						$("#ahorrado").css('border', '1px solid #AAAAAA');
						$("#id_error_otrAhorros1").addClass("hide");
						$("#id_etiquetaOtrAhorros1").css('color', '#000000');
					}
				}

			});

			$( "#ahorrado" ).change(function(){
				mod_progressbar.changeValueForm($("#ahorrado"), true);
			});

			$( "#ahorradoCA" ).keydown(function (e) {
				//Comprobamos que solo se introduzca nÃƒÆ’Ã‚Âºmeros.
				if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
						// Ctrl+A
						(e.keyCode == 65 && e.ctrlKey === true) ||
						// Ctrl+C
						(e.keyCode == 67 && e.ctrlKey === true) ||
						// Ctrl+X
						(e.keyCode == 88 && e.ctrlKey === true) ||
						// home, end, left, right
						(e.keyCode >= 35 && e.keyCode <= 39)) {
					// No hace nada
					return;
				}
				// Asegura que es un nÃƒÆ’Ã‚Âºmero y previene
				if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
					e.preventDefault();
				}
			});

			$( "#ahorradoCA" ).blur(function() {
				var otrAhorradoCAVal = $("#ahorradoCA").val();
				var otrAhorrosMin = parseInt($("#otrosAhorrosMin").val());
				var otrAhorrosMax = parseInt($("#otrosAhorrosMax").val());
				if(otrAhorradoCAVal == null ||otrAhorradoCAVal == ''){
					$("#ahorradoCA").val($("#otrosAhorrosMin").val());
					$("#ahorradoCA").css('border', '1px solid #AAAAAA');
					$("#id_error_otrAhorros2").addClass("hide");
					$("#id_etiquetaOtrAhorros2").css('color', '#000000');
				}else{
					var otrAhorradoCAValInt = parseInt($('#ahorradoCA').val());
					if(otrAhorrosMin > otrAhorradoCAValInt || otrAhorradoCAValInt > otrAhorrosMax){
						$("#ahorradoCA").css('border', '1px solid #D63F3F');
						$("#id_error_otrAhorros2").removeClass("hide");
						$("#id_etiquetaOtrAhorros2").css('color', '#D63F3F');
					}else{
						$("#ahorradoCA").css('border', '1px solid #AAAAAA');
						$("#id_error_otrAhorros2").addClass("hide");
						$("#id_etiquetaOtrAhorros2").css('color', '#000000');
					}
				}

			});

			var valorEdadSimPensiones = $("#edad").val();
			$("#sliderEdadPensiones").slider({ value: valorEdadSimPensiones});

			if($("#ahorrar").val() != undefined){
				var valorCantAhorroMesSimPensiones = dFrontJs.parseoNumber($("#ahorrar").val().toString());
				$("#sliderCantAhorroMesPensiones").slider({ value: valorCantAhorroMesSimPensiones});
			}

			var valorJubilacionSimPensiones = $("#jubilacion").val();
			$("#sliderJubilacionPensiones").slider({ value: valorJubilacionSimPensiones});

			if($("#ingresos").val() != undefined){
				var valorIngresosSimPensiones = dFrontJs.parseoNumber($("#ingresos").val().toString());
				$("#sliderIngresosPensiones").slider({ value: valorIngresosSimPensiones});
			}

			$( "#vivienda" ).blur(function() {


				if(valorAhorroMes != $("#vivienda").val()){


					valorAhorroMes = $("#vivienda").val(); 
					valorEdadJubilacion = $("#hipoteca").val();
					var URLFormatear = "/portalunico/nuevaSimulacionPensiones.jsp" + "?ahorroMes=" + valorAhorroMes + "&edadJubilacion=" + valorEdadJubilacion + "&listaPensiones=" + valorIDListaPensiones + "&datosSimuladores="+ valorIDDatosSimuladores + "&edadAjax=" + valorEdadAjax + "&ingresosBrutosAjax=" + valorIngresosBrutosAjax + "&otrosAhorrosAjax=" + valorOtrosAhorrosAjax + "&imagenEdad=" + valorIDImagenEdadAjax + "&tipoEnvioAjax=" + valorTipoEnvioAjax;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {
							'simPlanesPensionesNoEncontradoPlanPension': simPlanesPensionesNoEncontradoPlanPension, 'simPlanesPensionesImagenPensiones': simPlanesPensionesImagenPensiones, 'simPlanesPensionesCapitalAcumulado': simPlanesPensionesCapitalAcumulado, 'simPlanesPensionesCapitalAcumuladoJubilacion': simPlanesPensionesCapitalAcumuladoJubilacion, 'simPlanesPensionesImporteRecibir1': simPlanesPensionesImporteRecibir1, 'simPlanesPensionesDurante': simPlanesPensionesDurante, 'simPlanesPensionesAnios': simPlanesPensionesAnios, 'simPlanesPensionesImporteRecibir2': simPlanesPensionesImporteRecibir2, 
							'simPlanesPensionesAhorroFiscal1anio': simPlanesPensionesAhorroFiscal1anio, 'simPlanesPensionesSolicitar': simPlanesPensionesSolicitar, 'simPlanesPensionesVerDetalles': simPlanesPensionesVerDetalles, 'simPlanesPensionesVerCondiciones': simPlanesPensionesVerCondiciones, 'simPlanesPensionesMostrarMasInformacion': simPlanesPensionesMostrarMasInformacion, 'simPlanesPensionesComparalas': simPlanesPensionesComparalas, 'simPlanesPensionesComparadorPlanesPensiones': simPlanesPensionesComparadorPlanesPensiones, 'simPlanesPensionesEscalaNivelRiesgo': simPlanesPensionesEscalaNivelRiesgo, 'simPlanesPensionesMenorRiesgo': simPlanesPensionesMenorRiesgo, 'simPlanesPensionesMayorRiesgo': simPlanesPensionesMayorRiesgo, 
							'simPlanesPensionesEuros': simPlanesPensionesEuros, 'simPlanesPensionesCategoriaInverco': simPlanesPensionesCategoriaInverco, 'simPlanesPensionesUltimoValorLiquidativo': simPlanesPensionesUltimoValorLiquidativo, 'simPlanesPensionesDiaUltimoValorLiquidativo': simPlanesPensionesDiaUltimoValorLiquidativo, 'simPlanesPensionesInversionMinimaInicial': simPlanesPensionesInversionMinimaInicial, 'simPlanesPensionesInversionMinimaMantener': simPlanesPensionesInversionMinimaMantener, 'simPlanesPensionesRentabilidadYTD': simPlanesPensionesRentabilidadYTD, 'simPlanesPensionesRentabilidadesAcumuladas': simPlanesPensionesRentabilidadesAcumuladas, 'simPlanesPensionesVolatilidad': simPlanesPensionesVolatilidad, 'simPlanesPensionesCerrar': simPlanesPensionesCerrar,'calculadoraInfoLegal': calculadoraInfoLegal, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog
						},	
						success: function(data, textStatus )     
						{
							if (!jQuery('.resultadoPensiones').hasClass('hide'))
							{
								jQuery('.resultadoPensiones').css('display','none');
								jQuery('.resultadoPensiones').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevasPensiones').html(data);  
//							pintarTextoLegal();
							initOpenClose.init("[data-functioncal='fc-calcShow_init']","[data-functioncal='fc-calcClose_init']", ".calc-comparador", ".calc-open-close"); 
							if ($("[data-function='fc-chart_init_1']").length > 0) {
								mod_chart1.initChart1("[data-function='fc-chart_init_1']");
							}
							if ($("[data-function='fc-chart_init_2']").length > 0) {
								mod_chart2.initChart2("[data-function='fc-chart_init_2']");
							}

							if ($("[data-function='fc-chart_init_3']").length > 0) {
								mod_chart3.initChart3("[data-function='fc-chart_init_3']");
							}

							/** INIT ANITICA NO BORRAR*/
							digitalData.edadJubilacion = valorEdadJubilacion;
							digitalData.ahorroMensual = valorAhorroMes;
							/*$("button.but-oranje.but-wAuto").click(function(e){
            								digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
            								digitalData.estado = "solicitado";
            								digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
            								_satellite.track('view');
            							    });*/
							/** END ANALITICA NO BORRAR*/

						},
						error: function(xhr, textStatus, errorThrown){

						}
					});

				}
			});

			$( "#hipoteca" ).blur(function() { 

				if(valorEdadJubilacion != $("#hipoteca").val()){

					valorAhorroMes = $("#vivienda").val(); 
					valorEdadJubilacion = $("#hipoteca").val();
					var URLFormatear = "/portalunico/nuevaSimulacionPensiones.jsp" + "?ahorroMes=" + valorAhorroMes + "&edadJubilacion=" + valorEdadJubilacion + "&listaPensiones=" + valorIDListaPensiones + "&datosSimuladores="+ valorIDDatosSimuladores + "&edadAjax=" + valorEdadAjax + "&ingresosBrutosAjax=" + valorIngresosBrutosAjax + "&otrosAhorrosAjax=" + valorOtrosAhorrosAjax + "&imagenEdad=" + valorIDImagenEdadAjax + "&tipoEnvioAjax=" + valorTipoEnvioAjax;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {
							'simPlanesPensionesNoEncontradoPlanPension': simPlanesPensionesNoEncontradoPlanPension, 'simPlanesPensionesImagenPensiones': simPlanesPensionesImagenPensiones, 'simPlanesPensionesCapitalAcumulado': simPlanesPensionesCapitalAcumulado, 'simPlanesPensionesCapitalAcumuladoJubilacion': simPlanesPensionesCapitalAcumuladoJubilacion, 'simPlanesPensionesImporteRecibir1': simPlanesPensionesImporteRecibir1, 'simPlanesPensionesDurante': simPlanesPensionesDurante, 'simPlanesPensionesAnios': simPlanesPensionesAnios, 'simPlanesPensionesImporteRecibir2': simPlanesPensionesImporteRecibir2, 
							'simPlanesPensionesAhorroFiscal1anio': simPlanesPensionesAhorroFiscal1anio, 'simPlanesPensionesSolicitar': simPlanesPensionesSolicitar, 'simPlanesPensionesVerDetalles': simPlanesPensionesVerDetalles, 'simPlanesPensionesVerCondiciones': simPlanesPensionesVerCondiciones, 'simPlanesPensionesMostrarMasInformacion': simPlanesPensionesMostrarMasInformacion, 'simPlanesPensionesComparalas': simPlanesPensionesComparalas, 'simPlanesPensionesComparadorPlanesPensiones': simPlanesPensionesComparadorPlanesPensiones, 'simPlanesPensionesEscalaNivelRiesgo': simPlanesPensionesEscalaNivelRiesgo, 'simPlanesPensionesMenorRiesgo': simPlanesPensionesMenorRiesgo, 'simPlanesPensionesMayorRiesgo': simPlanesPensionesMayorRiesgo, 
							'simPlanesPensionesEuros': simPlanesPensionesEuros, 'simPlanesPensionesCategoriaInverco': simPlanesPensionesCategoriaInverco, 'simPlanesPensionesUltimoValorLiquidativo': simPlanesPensionesUltimoValorLiquidativo, 'simPlanesPensionesDiaUltimoValorLiquidativo': simPlanesPensionesDiaUltimoValorLiquidativo, 'simPlanesPensionesInversionMinimaInicial': simPlanesPensionesInversionMinimaInicial, 'simPlanesPensionesInversionMinimaMantener': simPlanesPensionesInversionMinimaMantener, 'simPlanesPensionesRentabilidadYTD': simPlanesPensionesRentabilidadYTD, 'simPlanesPensionesRentabilidadesAcumuladas': simPlanesPensionesRentabilidadesAcumuladas, 'simPlanesPensionesVolatilidad': simPlanesPensionesVolatilidad, 'simPlanesPensionesCerrar': simPlanesPensionesCerrar,'calculadoraInfoLegal': calculadoraInfoLegal, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog
						},
						success: function(data, textStatus )     
						{
							if (!jQuery('.resultadoPensiones').hasClass('hide'))
							{
								jQuery('.resultadoPensiones').css('display','none');
								jQuery('.resultadoPensiones').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevasPensiones').html(data); 
//							pintarTextoLegal();
							initOpenClose.init("[data-functioncal='fc-calcShow_init']","[data-functioncal='fc-calcClose_init']", ".calc-comparador", ".calc-open-close"); 
							if ($("[data-function='fc-chart_init_1']").length > 0) {
								mod_chart1.initChart1("[data-function='fc-chart_init_1']");
							}
							if ($("[data-function='fc-chart_init_2']").length > 0) {
								mod_chart2.initChart2("[data-function='fc-chart_init_2']");
							}

							if ($("[data-function='fc-chart_init_3']").length > 0) {
								mod_chart3.initChart3("[data-function='fc-chart_init_3']");
							}

							/** INIT ANITICA NO BORRAR*/
							digitalData.edadJubilacion = valorEdadJubilacion;
							digitalData.ahorroMensual = valorAhorroMes;
							/*$("button.but-oranje.but-wAuto").click(function(e){
    								digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
    								digitalData.estado = "solicitado";
    								digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
    								_satellite.track('view');
    							    });*/
							/** END ANALITICA NO BORRAR*/

						},
						error: function(xhr, textStatus, errorThrown){

						}
					});	

				}
			});

			$( "#viviendaAhorro" ).blur(function() { 

				if(valorAhorradoJubilacion != $("#viviendaAhorro").val()){

					valorAhorradoJubilacion = $("#viviendaAhorro").val(); 
					valorEdadJubilacion = $("#hipotecaAhorro").val();
					var URLFormatear = "/portalunico/nuevaSimulacionPensiones.jsp" + "?ahorroMes=" + valorAhorradoJubilacion + "&edadJubilacion=" + valorEdadJubilacion + "&listaPensiones=" + valorIDListaPensiones + "&datosSimuladores="+ valorIDDatosSimuladores + "&edadAjax=" + valorEdadAjax + "&ingresosBrutosAjax=" + valorIngresosBrutosAjax + "&otrosAhorrosAjax=" + valorOtrosAhorrosAjax + "&imagenEdad=" + valorIDImagenEdadAjax + "&tipoEnvioAjax=" + valorTipoEnvioAjax;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {
							'simPlanesPensionesNoEncontradoPlanPension': simPlanesPensionesNoEncontradoPlanPension, 'simPlanesPensionesImagenPensiones': simPlanesPensionesImagenPensiones, 'simPlanesPensionesCapitalAcumulado': simPlanesPensionesCapitalAcumulado, 'simPlanesPensionesCapitalAcumuladoJubilacion': simPlanesPensionesCapitalAcumuladoJubilacion, 'simPlanesPensionesImporteRecibir1': simPlanesPensionesImporteRecibir1, 'simPlanesPensionesDurante': simPlanesPensionesDurante, 'simPlanesPensionesAnios': simPlanesPensionesAnios, 'simPlanesPensionesImporteRecibir2': simPlanesPensionesImporteRecibir2, 
							'simPlanesPensionesAhorroFiscal1anio': simPlanesPensionesAhorroFiscal1anio, 'simPlanesPensionesSolicitar': simPlanesPensionesSolicitar, 'simPlanesPensionesVerDetalles': simPlanesPensionesVerDetalles, 'simPlanesPensionesVerCondiciones': simPlanesPensionesVerCondiciones, 'simPlanesPensionesMostrarMasInformacion': simPlanesPensionesMostrarMasInformacion, 'simPlanesPensionesComparalas': simPlanesPensionesComparalas, 'simPlanesPensionesComparadorPlanesPensiones': simPlanesPensionesComparadorPlanesPensiones, 'simPlanesPensionesEscalaNivelRiesgo': simPlanesPensionesEscalaNivelRiesgo, 'simPlanesPensionesMenorRiesgo': simPlanesPensionesMenorRiesgo, 'simPlanesPensionesMayorRiesgo': simPlanesPensionesMayorRiesgo, 
							'simPlanesPensionesEuros': simPlanesPensionesEuros, 'simPlanesPensionesCategoriaInverco': simPlanesPensionesCategoriaInverco, 'simPlanesPensionesUltimoValorLiquidativo': simPlanesPensionesUltimoValorLiquidativo, 'simPlanesPensionesDiaUltimoValorLiquidativo': simPlanesPensionesDiaUltimoValorLiquidativo, 'simPlanesPensionesInversionMinimaInicial': simPlanesPensionesInversionMinimaInicial, 'simPlanesPensionesInversionMinimaMantener': simPlanesPensionesInversionMinimaMantener, 'simPlanesPensionesRentabilidadYTD': simPlanesPensionesRentabilidadYTD, 'simPlanesPensionesRentabilidadesAcumuladas': simPlanesPensionesRentabilidadesAcumuladas, 'simPlanesPensionesVolatilidad': simPlanesPensionesVolatilidad, 'simPlanesPensionesCerrar': simPlanesPensionesCerrar,'calculadoraInfoLegal': calculadoraInfoLegal, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog
						},
						success: function(data, textStatus )     
						{
							if (!jQuery('.resultadoPensionesCA').hasClass('hide'))
							{
								jQuery('.resultadoPensionesCA').css('display','none');
								jQuery('.resultadoPensionesCA').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevasPensionesCA').html(data);
//							pintarTextoLegal();
							initOpenClose.init("[data-functioncal='fc-calcShowAhorro_init']","[data-functioncal='fc-calcCloseAhorro_init']", ".calc-comparador", ".calc-open-close");  
							if ($("[data-function='fc-chart_init_1']").length > 0) {
								mod_chart1.initChart1("[data-function='fc-chart_init_1']");
							}
							if ($("[data-function='fc-chart_init_2']").length > 0) {
								mod_chart2.initChart2("[data-function='fc-chart_init_2']");
							}

							if ($("[data-function='fc-chart_init_3']").length > 0) {
								mod_chart3.initChart3("[data-function='fc-chart_init_3']");
							}

							/** INIT ANITICA NO BORRAR*/
							digitalData.edadJubilacion = valorEdadJubilacion;
							digitalData.ahorroMensual = valorAhorroMes;
							/*$("button.but-oranje.but-wAuto").click(function(e){
    								digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
    								digitalData.estado = "solicitado";
    								digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
    								_satellite.track('view');
    							    });*/
							/** END ANALITICA NO BORRAR*/

						},
						error: function(xhr, textStatus, errorThrown){

						}
					});	

				}
			});

			$( "#hipotecaAhorro" ).blur(function() { 

				if(valorEdadJubilacion != $("#hipotecaAhorro").val()){

					valorAhorradoJubilacion = $("#viviendaAhorro").val(); 
					valorEdadJubilacion = $("#hipotecaAhorro").val();

					var URLFormatear = "/portalunico/nuevaSimulacionPensiones.jsp" + "?ahorroMes=" + valorAhorradoJubilacion + "&edadJubilacion=" + valorEdadJubilacion + "&listaPensiones=" + valorIDListaPensiones + "&datosSimuladores="+ valorIDDatosSimuladores + "&edadAjax=" + valorEdadAjax + "&ingresosBrutosAjax=" + valorIngresosBrutosAjax + "&otrosAhorrosAjax=" + valorOtrosAhorrosAjax + "&imagenEdad=" + valorIDImagenEdadAjax + "&tipoEnvioAjax=" + valorTipoEnvioAjax;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {
							'simPlanesPensionesNoEncontradoPlanPension': simPlanesPensionesNoEncontradoPlanPension, 'simPlanesPensionesImagenPensiones': simPlanesPensionesImagenPensiones, 'simPlanesPensionesCapitalAcumulado': simPlanesPensionesCapitalAcumulado, 'simPlanesPensionesCapitalAcumuladoJubilacion': simPlanesPensionesCapitalAcumuladoJubilacion, 'simPlanesPensionesImporteRecibir1': simPlanesPensionesImporteRecibir1, 'simPlanesPensionesDurante': simPlanesPensionesDurante, 'simPlanesPensionesAnios': simPlanesPensionesAnios, 'simPlanesPensionesImporteRecibir2': simPlanesPensionesImporteRecibir2, 
							'simPlanesPensionesAhorroFiscal1anio': simPlanesPensionesAhorroFiscal1anio, 'simPlanesPensionesSolicitar': simPlanesPensionesSolicitar, 'simPlanesPensionesVerDetalles': simPlanesPensionesVerDetalles, 'simPlanesPensionesVerCondiciones': simPlanesPensionesVerCondiciones, 'simPlanesPensionesMostrarMasInformacion': simPlanesPensionesMostrarMasInformacion, 'simPlanesPensionesComparalas': simPlanesPensionesComparalas, 'simPlanesPensionesComparadorPlanesPensiones': simPlanesPensionesComparadorPlanesPensiones, 'simPlanesPensionesEscalaNivelRiesgo': simPlanesPensionesEscalaNivelRiesgo, 'simPlanesPensionesMenorRiesgo': simPlanesPensionesMenorRiesgo, 'simPlanesPensionesMayorRiesgo': simPlanesPensionesMayorRiesgo, 
							'simPlanesPensionesEuros': simPlanesPensionesEuros, 'simPlanesPensionesCategoriaInverco': simPlanesPensionesCategoriaInverco, 'simPlanesPensionesUltimoValorLiquidativo': simPlanesPensionesUltimoValorLiquidativo, 'simPlanesPensionesDiaUltimoValorLiquidativo': simPlanesPensionesDiaUltimoValorLiquidativo, 'simPlanesPensionesInversionMinimaInicial': simPlanesPensionesInversionMinimaInicial, 'simPlanesPensionesInversionMinimaMantener': simPlanesPensionesInversionMinimaMantener, 'simPlanesPensionesRentabilidadYTD': simPlanesPensionesRentabilidadYTD, 'simPlanesPensionesRentabilidadesAcumuladas': simPlanesPensionesRentabilidadesAcumuladas, 'simPlanesPensionesVolatilidad': simPlanesPensionesVolatilidad, 'simPlanesPensionesCerrar': simPlanesPensionesCerrar,'calculadoraInfoLegal': calculadoraInfoLegal, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog
						},
						success: function(data, textStatus )     
						{
							if (!jQuery('.resultadoPensionesCA').hasClass('hide'))
							{
								jQuery('.resultadoPensionesCA').css('display','none');
								jQuery('.resultadoPensionesCA').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevasPensionesCA').html(data);
//							pintarTextoLegal();
							initOpenClose.init("[data-functioncal='fc-calcShowAhorro_init']","[data-functioncal='fc-calcCloseAhorro_init']", ".calc-comparador", ".calc-open-close"); 
							if ($("[data-function='fc-chart_init_1']").length > 0) {
								mod_chart1.initChart1("[data-function='fc-chart_init_1']");
							}
							if ($("[data-function='fc-chart_init_2']").length > 0) {
								mod_chart2.initChart2("[data-function='fc-chart_init_2']");
							}

							if ($("[data-function='fc-chart_init_3']").length > 0) {
								mod_chart3.initChart3("[data-function='fc-chart_init_3']");
							}

							/** INIT ANITICA NO BORRAR*/
							digitalData.edadJubilacion = valorEdadJubilacion;
							digitalData.ahorroMensual = valorAhorroMes;
							/*$("button.but-oranje.but-wAuto").click(function(e){
        							digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
        							digitalData.estado = "solicitado";
        							digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
        							_satellite.track('view');
        						    });*/
							/** END ANALITICA NO BORRAR*/

						},
						error: function(xhr, textStatus, errorThrown){

						}
					});	

				}
			});

			$("#sliderAhorroMes").slider({ 

				value: valorAhorroMes,
				stop: function( event, ui ) {

					valorAhorroMes = $("#vivienda").val(); 
					valorEdadJubilacion = $("#hipoteca").val();
					var URLFormatear = "/portalunico/nuevaSimulacionPensiones.jsp" + "?ahorroMes=" + valorAhorroMes + "&edadJubilacion=" + valorEdadJubilacion + "&listaPensiones=" + valorIDListaPensiones + "&datosSimuladores="+ valorIDDatosSimuladores + "&edadAjax=" + valorEdadAjax + "&ingresosBrutosAjax=" + valorIngresosBrutosAjax + "&otrosAhorrosAjax=" + valorOtrosAhorrosAjax + "&imagenEdad=" + valorIDImagenEdadAjax + "&tipoEnvioAjax=" + valorTipoEnvioAjax;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {
							'simPlanesPensionesNoEncontradoPlanPension': simPlanesPensionesNoEncontradoPlanPension, 'simPlanesPensionesImagenPensiones': simPlanesPensionesImagenPensiones, 'simPlanesPensionesCapitalAcumulado': simPlanesPensionesCapitalAcumulado, 'simPlanesPensionesCapitalAcumuladoJubilacion': simPlanesPensionesCapitalAcumuladoJubilacion, 'simPlanesPensionesImporteRecibir1': simPlanesPensionesImporteRecibir1, 'simPlanesPensionesDurante': simPlanesPensionesDurante, 'simPlanesPensionesAnios': simPlanesPensionesAnios, 'simPlanesPensionesImporteRecibir2': simPlanesPensionesImporteRecibir2, 
							'simPlanesPensionesAhorroFiscal1anio': simPlanesPensionesAhorroFiscal1anio, 'simPlanesPensionesSolicitar': simPlanesPensionesSolicitar, 'simPlanesPensionesVerDetalles': simPlanesPensionesVerDetalles, 'simPlanesPensionesVerCondiciones': simPlanesPensionesVerCondiciones, 'simPlanesPensionesMostrarMasInformacion': simPlanesPensionesMostrarMasInformacion, 'simPlanesPensionesComparalas': simPlanesPensionesComparalas, 'simPlanesPensionesComparadorPlanesPensiones': simPlanesPensionesComparadorPlanesPensiones, 'simPlanesPensionesEscalaNivelRiesgo': simPlanesPensionesEscalaNivelRiesgo, 'simPlanesPensionesMenorRiesgo': simPlanesPensionesMenorRiesgo, 'simPlanesPensionesMayorRiesgo': simPlanesPensionesMayorRiesgo, 
							'simPlanesPensionesEuros': simPlanesPensionesEuros, 'simPlanesPensionesCategoriaInverco': simPlanesPensionesCategoriaInverco, 'simPlanesPensionesUltimoValorLiquidativo': simPlanesPensionesUltimoValorLiquidativo, 'simPlanesPensionesDiaUltimoValorLiquidativo': simPlanesPensionesDiaUltimoValorLiquidativo, 'simPlanesPensionesInversionMinimaInicial': simPlanesPensionesInversionMinimaInicial, 'simPlanesPensionesInversionMinimaMantener': simPlanesPensionesInversionMinimaMantener, 'simPlanesPensionesRentabilidadYTD': simPlanesPensionesRentabilidadYTD, 'simPlanesPensionesRentabilidadesAcumuladas': simPlanesPensionesRentabilidadesAcumuladas, 'simPlanesPensionesVolatilidad': simPlanesPensionesVolatilidad, 'simPlanesPensionesCerrar': simPlanesPensionesCerrar,'calculadoraInfoLegal': calculadoraInfoLegal, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog
						},
						success: function(data, textStatus )     
						{
							if (!jQuery('.resultadoPensiones').hasClass('hide'))
							{
								jQuery('.resultadoPensiones').css('display','none');
								jQuery('.resultadoPensiones').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevasPensiones').html(data);  
							//pintarTextoLegal();
							//formateo del valor numerico con miles
							var dataName = $("#vivienda").attr('name');
							if($("#vivienda").val().indexOf('.') < 0 ){
								if($("#vivienda").val() != undefined){
									var valueParse = dFrontJs.parseoNumberDec($("#vivienda").val().toString())
									var elem = document.getElementById(dataName);
									elem.value = valueParse;
								}
							}
							initOpenClose.init("[data-functioncal='fc-calcShow_init']","[data-functioncal='fc-calcClose_init']", ".calc-comparador", ".calc-open-close"); 
							if ($("[data-function='fc-chart_init_1']").length > 0) {
								mod_chart1.initChart1("[data-function='fc-chart_init_1']");
							}
							if ($("[data-function='fc-chart_init_2']").length > 0) {
								mod_chart2.initChart2("[data-function='fc-chart_init_2']");
							}

							if ($("[data-function='fc-chart_init_3']").length > 0) {
								mod_chart3.initChart3("[data-function='fc-chart_init_3']");
							}

							/** INIT ANITICA NO BORRAR*/
							digitalData.edadJubilacion = valorEdadJubilacion;
							digitalData.ahorroMensual = valorAhorroMes;
							/*$("button.but-oranje.but-wAuto").click(function(e){
        							digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
        							digitalData.estado = "solicitado";
        							digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
        							_satellite.track('view');
        						    });*/
							/** END ANALITICA NO BORRAR*/

						},
						error: function(xhr, textStatus, errorThrown){

						}
					});

				}
			});

			$("#sliderEdadJubilacion").slider({ 

				value: valorEdadJubilacion,
				stop: function( event, ui ) {

					valorAhorroMes = $("#vivienda").val(); 
					valorEdadJubilacion = $("#hipoteca").val();
					var URLFormatear = "/portalunico/nuevaSimulacionPensiones.jsp" + "?ahorroMes=" + valorAhorroMes + "&edadJubilacion=" + valorEdadJubilacion + "&listaPensiones=" + valorIDListaPensiones + "&datosSimuladores="+ valorIDDatosSimuladores + "&edadAjax=" + valorEdadAjax + "&ingresosBrutosAjax=" + valorIngresosBrutosAjax + "&otrosAhorrosAjax=" + valorOtrosAhorrosAjax + "&imagenEdad=" + valorIDImagenEdadAjax + "&tipoEnvioAjax=" + valorTipoEnvioAjax;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {
							'simPlanesPensionesNoEncontradoPlanPension': simPlanesPensionesNoEncontradoPlanPension, 'simPlanesPensionesImagenPensiones': simPlanesPensionesImagenPensiones, 'simPlanesPensionesCapitalAcumulado': simPlanesPensionesCapitalAcumulado, 'simPlanesPensionesCapitalAcumuladoJubilacion': simPlanesPensionesCapitalAcumuladoJubilacion, 'simPlanesPensionesImporteRecibir1': simPlanesPensionesImporteRecibir1, 'simPlanesPensionesDurante': simPlanesPensionesDurante, 'simPlanesPensionesAnios': simPlanesPensionesAnios, 'simPlanesPensionesImporteRecibir2': simPlanesPensionesImporteRecibir2, 
							'simPlanesPensionesAhorroFiscal1anio': simPlanesPensionesAhorroFiscal1anio, 'simPlanesPensionesSolicitar': simPlanesPensionesSolicitar, 'simPlanesPensionesVerDetalles': simPlanesPensionesVerDetalles, 'simPlanesPensionesVerCondiciones': simPlanesPensionesVerCondiciones, 'simPlanesPensionesMostrarMasInformacion': simPlanesPensionesMostrarMasInformacion, 'simPlanesPensionesComparalas': simPlanesPensionesComparalas, 'simPlanesPensionesComparadorPlanesPensiones': simPlanesPensionesComparadorPlanesPensiones, 'simPlanesPensionesEscalaNivelRiesgo': simPlanesPensionesEscalaNivelRiesgo, 'simPlanesPensionesMenorRiesgo': simPlanesPensionesMenorRiesgo, 'simPlanesPensionesMayorRiesgo': simPlanesPensionesMayorRiesgo, 
							'simPlanesPensionesEuros': simPlanesPensionesEuros, 'simPlanesPensionesCategoriaInverco': simPlanesPensionesCategoriaInverco, 'simPlanesPensionesUltimoValorLiquidativo': simPlanesPensionesUltimoValorLiquidativo, 'simPlanesPensionesDiaUltimoValorLiquidativo': simPlanesPensionesDiaUltimoValorLiquidativo, 'simPlanesPensionesInversionMinimaInicial': simPlanesPensionesInversionMinimaInicial, 'simPlanesPensionesInversionMinimaMantener': simPlanesPensionesInversionMinimaMantener, 'simPlanesPensionesRentabilidadYTD': simPlanesPensionesRentabilidadYTD, 'simPlanesPensionesRentabilidadesAcumuladas': simPlanesPensionesRentabilidadesAcumuladas, 'simPlanesPensionesVolatilidad': simPlanesPensionesVolatilidad, 'simPlanesPensionesCerrar': simPlanesPensionesCerrar,'calculadoraInfoLegal': calculadoraInfoLegal, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog
						},
						success: function(data, textStatus )     
						{
							if (!jQuery('.resultadoPensiones').hasClass('hide'))
							{
								jQuery('.resultadoPensiones').css('display','none');
								jQuery('.resultadoPensiones').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevasPensiones').html(data);
//							pintarTextoLegal();
							initOpenClose.init("[data-functioncal='fc-calcShow_init']","[data-functioncal='fc-calcClose_init']", ".calc-comparador", ".calc-open-close"); 
							if ($("[data-function='fc-chart_init_1']").length > 0) {
								mod_chart1.initChart1("[data-function='fc-chart_init_1']");
							}
							if ($("[data-function='fc-chart_init_2']").length > 0) {
								mod_chart2.initChart2("[data-function='fc-chart_init_2']");
							}

							if ($("[data-function='fc-chart_init_3']").length > 0) {
								mod_chart3.initChart3("[data-function='fc-chart_init_3']");
							}

							/** INIT ANITICA NO BORRAR*/
							digitalData.edadJubilacion = valorEdadJubilacion;
							digitalData.ahorroMensual = valorAhorroMes;
							/*$("button.but-oranje.but-wAuto").click(function(e){
        							digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
        							digitalData.estado = "solicitado";
        							digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
        							_satellite.track('view');
        						    });*/
							/** END ANALITICA NO BORRAR*/

						},
						error: function(xhr, textStatus, errorThrown){

						}
					});	


				}
			});

			$("#sliderCantAhorro").slider({ 

				value: valorAhorrarCA,
				stop: function( event, ui ) {

					valorAhorradoJubilacion = $("#viviendaAhorro").val(); 
					valorEdadJubilacion = $("#hipotecaAhorro").val();
					var URLFormatear = "/portalunico/nuevaSimulacionPensiones.jsp" + "?ahorroMes=" + valorAhorradoJubilacion + "&edadJubilacion=" + valorEdadJubilacion + "&listaPensiones=" + valorIDListaPensiones + "&datosSimuladores="+ valorIDDatosSimuladores + "&edadAjax=" + valorEdadAjax + "&ingresosBrutosAjax=" + valorIngresosBrutosAjax + "&otrosAhorrosAjax=" + valorOtrosAhorrosAjax + "&imagenEdad=" + valorIDImagenEdadAjax + "&tipoEnvioAjax=" + valorTipoEnvioAjax;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {
							'simPlanesPensionesNoEncontradoPlanPension': simPlanesPensionesNoEncontradoPlanPension, 'simPlanesPensionesImagenPensiones': simPlanesPensionesImagenPensiones, 'simPlanesPensionesCapitalAcumulado': simPlanesPensionesCapitalAcumulado, 'simPlanesPensionesCapitalAcumuladoJubilacion': simPlanesPensionesCapitalAcumuladoJubilacion, 'simPlanesPensionesImporteRecibir1': simPlanesPensionesImporteRecibir1, 'simPlanesPensionesDurante': simPlanesPensionesDurante, 'simPlanesPensionesAnios': simPlanesPensionesAnios, 'simPlanesPensionesImporteRecibir2': simPlanesPensionesImporteRecibir2, 
							'simPlanesPensionesAhorroFiscal1anio': simPlanesPensionesAhorroFiscal1anio, 'simPlanesPensionesSolicitar': simPlanesPensionesSolicitar, 'simPlanesPensionesVerDetalles': simPlanesPensionesVerDetalles, 'simPlanesPensionesVerCondiciones': simPlanesPensionesVerCondiciones, 'simPlanesPensionesMostrarMasInformacion': simPlanesPensionesMostrarMasInformacion, 'simPlanesPensionesComparalas': simPlanesPensionesComparalas, 'simPlanesPensionesComparadorPlanesPensiones': simPlanesPensionesComparadorPlanesPensiones, 'simPlanesPensionesEscalaNivelRiesgo': simPlanesPensionesEscalaNivelRiesgo, 'simPlanesPensionesMenorRiesgo': simPlanesPensionesMenorRiesgo, 'simPlanesPensionesMayorRiesgo': simPlanesPensionesMayorRiesgo, 
							'simPlanesPensionesEuros': simPlanesPensionesEuros, 'simPlanesPensionesCategoriaInverco': simPlanesPensionesCategoriaInverco, 'simPlanesPensionesUltimoValorLiquidativo': simPlanesPensionesUltimoValorLiquidativo, 'simPlanesPensionesDiaUltimoValorLiquidativo': simPlanesPensionesDiaUltimoValorLiquidativo, 'simPlanesPensionesInversionMinimaInicial': simPlanesPensionesInversionMinimaInicial, 'simPlanesPensionesInversionMinimaMantener': simPlanesPensionesInversionMinimaMantener, 'simPlanesPensionesRentabilidadYTD': simPlanesPensionesRentabilidadYTD, 'simPlanesPensionesRentabilidadesAcumuladas': simPlanesPensionesRentabilidadesAcumuladas, 'simPlanesPensionesVolatilidad': simPlanesPensionesVolatilidad, 'simPlanesPensionesCerrar': simPlanesPensionesCerrar,'calculadoraInfoLegal': calculadoraInfoLegal, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog
						},
						success: function(data, textStatus )     
						{
							if (!jQuery('.resultadoPensionesCA').hasClass('hide'))
							{
								jQuery('.resultadoPensionesCA').css('display','none');
								jQuery('.resultadoPensionesCA').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}
							jQuery('#nuevasPensionesCA').html(data);
//							pintarTextoLegal();
							initOpenClose.init("[data-functioncal='fc-calcShowAhorro_init']","[data-functioncal='fc-calcCloseAhorro_init']", ".calc-comparador", ".calc-open-close");  
							if ($("[data-function='fc-chart_init_1']").length > 0) {
								mod_chart1.initChart1("[data-function='fc-chart_init_1']");
							}
							if ($("[data-function='fc-chart_init_2']").length > 0) {
								mod_chart2.initChart2("[data-function='fc-chart_init_2']");
							}

							if ($("[data-function='fc-chart_init_3']").length > 0) {
								mod_chart3.initChart3("[data-function='fc-chart_init_3']");
							}

							/** INIT ANITICA NO BORRAR*/
							digitalData.edadJubilacion = valorEdadJubilacion;
							digitalData.ahorroMensual = valorAhorroMes;
							/*$("button.but-oranje.but-wAuto").click(function(e){
        							digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
        							digitalData.estado = "solicitado";
        							digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
        							_satellite.track('view');
        						    });*/
							/** END ANALITICA NO BORRAR*/

						},
						error: function(xhr, textStatus, errorThrown){

						}
					});			
				}
			});

			$("#sliderJubilacionCA").slider({ 

				value: valorEdadJubilacionCA,
				stop: function( event, ui ) {

					valorAhorradoJubilacion = $("#viviendaAhorro").val(); 
					valorEdadJubilacion = $("#hipotecaAhorro").val();

					var URLFormatear = "/portalunico/nuevaSimulacionPensiones.jsp" + "?ahorroMes=" + valorAhorradoJubilacion + "&edadJubilacion=" + valorEdadJubilacion + "&listaPensiones=" + valorIDListaPensiones + "&datosSimuladores="+ valorIDDatosSimuladores + "&edadAjax=" + valorEdadAjax + "&ingresosBrutosAjax=" + valorIngresosBrutosAjax + "&otrosAhorrosAjax=" + valorOtrosAhorrosAjax + "&imagenEdad=" + valorIDImagenEdadAjax + "&tipoEnvioAjax=" + valorTipoEnvioAjax;
					jQuery.ajax({
						url: encodeURI(URLFormatear),
						context: document.body,
						data: {
							'simPlanesPensionesNoEncontradoPlanPension': simPlanesPensionesNoEncontradoPlanPension, 'simPlanesPensionesImagenPensiones': simPlanesPensionesImagenPensiones, 'simPlanesPensionesCapitalAcumulado': simPlanesPensionesCapitalAcumulado, 'simPlanesPensionesCapitalAcumuladoJubilacion': simPlanesPensionesCapitalAcumuladoJubilacion, 'simPlanesPensionesImporteRecibir1': simPlanesPensionesImporteRecibir1, 'simPlanesPensionesDurante': simPlanesPensionesDurante, 'simPlanesPensionesAnios': simPlanesPensionesAnios, 'simPlanesPensionesImporteRecibir2': simPlanesPensionesImporteRecibir2, 
							'simPlanesPensionesAhorroFiscal1anio': simPlanesPensionesAhorroFiscal1anio, 'simPlanesPensionesSolicitar': simPlanesPensionesSolicitar, 'simPlanesPensionesVerDetalles': simPlanesPensionesVerDetalles, 'simPlanesPensionesVerCondiciones': simPlanesPensionesVerCondiciones, 'simPlanesPensionesMostrarMasInformacion': simPlanesPensionesMostrarMasInformacion, 'simPlanesPensionesComparalas': simPlanesPensionesComparalas, 'simPlanesPensionesComparadorPlanesPensiones': simPlanesPensionesComparadorPlanesPensiones, 'simPlanesPensionesEscalaNivelRiesgo': simPlanesPensionesEscalaNivelRiesgo, 'simPlanesPensionesMenorRiesgo': simPlanesPensionesMenorRiesgo, 'simPlanesPensionesMayorRiesgo': simPlanesPensionesMayorRiesgo, 
							'simPlanesPensionesEuros': simPlanesPensionesEuros, 'simPlanesPensionesCategoriaInverco': simPlanesPensionesCategoriaInverco, 'simPlanesPensionesUltimoValorLiquidativo': simPlanesPensionesUltimoValorLiquidativo, 'simPlanesPensionesDiaUltimoValorLiquidativo': simPlanesPensionesDiaUltimoValorLiquidativo, 'simPlanesPensionesInversionMinimaInicial': simPlanesPensionesInversionMinimaInicial, 'simPlanesPensionesInversionMinimaMantener': simPlanesPensionesInversionMinimaMantener, 'simPlanesPensionesRentabilidadYTD': simPlanesPensionesRentabilidadYTD, 'simPlanesPensionesRentabilidadesAcumuladas': simPlanesPensionesRentabilidadesAcumuladas, 'simPlanesPensionesVolatilidad': simPlanesPensionesVolatilidad, 'simPlanesPensionesCerrar': simPlanesPensionesCerrar,'calculadoraInfoLegal': calculadoraInfoLegal, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog
						},
						success: function(data, textStatus )     
						{
							if (!jQuery('.resultadoPensionesCA').hasClass('hide'))
							{
								jQuery('.resultadoPensionesCA').css('display','none');
								jQuery('.resultadoPensionesCA').toggleClass('hide');
							}
							if (!jQuery('.mod_TextoLegal').hasClass('hide'))
							{
								jQuery('.mod_TextoLegal').css('display','none');
								jQuery('.mod_TextoLegal').toggleClass('hide');
							}

							jQuery('#nuevasPensionesCA').html(data);
//							pintarTextoLegal();
							initOpenClose.init("[data-functioncal='fc-calcShowAhorro_init']","[data-functioncal='fc-calcCloseAhorro_init']", ".calc-comparador", ".calc-open-close"); 
							if ($("[data-function='fc-chart_init_1']").length > 0) {
								mod_chart1.initChart1("[data-function='fc-chart_init_1']");
							}
							if ($("[data-function='fc-chart_init_2']").length > 0) {
								mod_chart2.initChart2("[data-function='fc-chart_init_2']");
							}

							if ($("[data-function='fc-chart_init_3']").length > 0) {
								mod_chart3.initChart3("[data-function='fc-chart_init_3']");
							}

							/** INIT ANITICA NO BORRAR*/
							digitalData.edadJubilacion = valorEdadJubilacion;
							digitalData.ahorroMensual = valorAhorroMes;
							/*$("button.but-oranje.but-wAuto").click(function(e){
    								digitalData.nombrePagina = digitalData.nombrePagina + " solicitar";
    								digitalData.estado = "solicitado";
    								digitalData.funnel= "paso3:contactabilidad " + digitalData.proceso;
    								_satellite.track('view');
    							    });*/
							/** END ANALITICA NO BORRAR*/



						},
						error: function(xhr, textStatus, errorThrown){

						}
					});	

				}
			});



//			function pintarTextoLegal(){ 						
//			var valorTextoLegal = $("#textoLegal").val();
//			var valorTipoTextoLegal = $("#tipoTextoLegal").val();
//			jQuery.ajax({
//			url: "/portalunico/nuevaSimulacionTextoLegal.jsp" + "?textLegal=" + valorTextoLegal + "&tipoTextoLegal=" + valorTipoTextoLegal,
//			context: document.body,
//			data: {'paramsSeguir':'1'},
//			success: function(data, textStatus )     
//			{        
//			var widthPage =window.innerWidth;
//			//alert("La widthPage es: "+widthPage);
//			if (widthPage < 768 && $(".fc-accordionLegalInfo").hasClass("ui-accordion")){
//			//alert("AJAX Menor de 768 y hay acordeÃƒÆ’Ã‚Â³n");
//			$(".fc-accordionLegalInfo").accordion("destroy"); 
//			}
//			jQuery('#nuevaSimulacionTextoLegal').html(data);
//			mod_accordion.initAccordion(".fc-accordionLegalInfo",{collapsible:true, heightStyle:"content", active: false});

//			},
//			error: function(xhr, textStatus, errorThrown){         

//			}
//			});

//			}	



			/*LOADING BUTTON SUSCRIPCION BOLETINES*/
			if($("[data-function='fc-buttonLoadingS']").length > 0){
				initLoadingS.initLoadingButtonS("[data-function='fc-buttonLoadingS']")
			}
			/*LOADING BUTTON SUSCRIPCION INFORMES*/
			if($("[data-function='fc-buttonLoadingSInf']").length > 0){
				initLoadingS.initLoadingButtonSInf("[data-function='fc-buttonLoadingSInf']")
			}

			// Boletines: seleccionamos el primer boletin por defecto
			if ($("#id_customer_bol_0").length > 0) {
				$("#id_customer_bol_0").prop('checked', true);
			}

		});

function setScrollModalIframe(modalId){
	var webPrivada = $("#webPrivada").val()
	if(webPrivada=='true'){
		if($(window.parent.document).scrollTop()==0){
			var scroll = $(window.parent.document).scrollTop();
		}else{
			var scroll = $(window.parent.document).scrollTop()-100;
		}
		$(modalId).css('top', scroll);
	}
}


function setScrollModalIframeInicial(modalId){
	var webPrivada = $("#webPrivada").val()
	if(webPrivada=='true'){
		var scroll = $(window.parent.document).scrollTop();
		$(modalId).css('top', scroll);
	}
}

function sendHeight(entorno) {
	var provider = new ChannelProvider();
	var altura = $(".contenedor_general").height();
	if(entorno==''){
		entorno = $("#entornoOiPM").val();
	}
	var channel = provider.$get(window);
	var SCOPE_ALTURA =  'altura';
	var messageHeight = { height: altura };  
	channel.transmit(window.parent, SCOPE_ALTURA, messageHeight);
}
function sendHeightVermas(entorno) {
	var provider = new ChannelProvider();
	var altura = $(".contenedor_general").height();
	if(entorno==''){
		entorno = $("#entornoOiPM").val();
	}
	var channel = provider.$get(window);
	var SCOPE_ALTURA =  'altura';
	var messageHeight = { height: altura };  
	channel.transmit(window.parent, SCOPE_ALTURA, messageHeight);
}
function formatoPorcentaje(e, idCampo){
	key = e.keyCode || e.which;
	tecla = String.fromCharCode(key).toLocaleLowerCase();
	numeros = "0123456789";
	especiales = [8, 37, 39, 44];

	var campo = "#"+idCampo;

	tecla_especial = false;
	for(var i in especiales){
		if(key == especiales[i]){
			tecla_especial = true;
			break;
		}
	}

	if(numeros.indexOf(tecla) == -1 && !tecla_especial){
		return false;
	}
	if((key == especiales[3]) && ($(campo).get(0).value.indexOf(',') != -1)){
		return false;
	}
}

function blurEnter(e, idCampo){
	key = e.keyCode || e.which
	var campo = "#"+idCampo;

	if(key == "13"){
		$(campo).blur();
		return false;
	}
}

function subcripcion(){

	var value = '';
	$(".bol-checkbox:checked").each(function(){
		var titulo = $(this).attr("name");
		var valor = $(this).attr("value");

		value = value + valor +',';

	});

	var regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/;

	if (($('#id_customer_scr').is(':checked')) && ($('#suscripcion-boletines').attr('data-valid') == 'true') && value != "" && regex.test($('#scr-input').val())) {


		$("#suscripcion").attr("value",value.substring(0,value.length-1));

		var formObj =  $("#suscripcion-boletines");
		var formURL = formObj.attr("action");
		var formData = new FormData(this);
		$.ajax({
			url: formURL,
			type: 'GET',
			data: formObj.serialize(),
			contentType: false,
			cache: false,
			processData:false,
			success: function(data, textStatus, jqXHR)
			{
//				alert("validacion ajax")
if (jQuery("#messageBoletinesSus:not(.hide)")) {
	$("#messageBoletinesSus").addClass('hide');
}
$('#form').hide();
$('#error').hide();
$('#success').show();
			},
			error: function(jqXHR, textStatus, errorThrown) 
			{


				jQuery("#messageBoletinesSus").removeClass('hide');
				$('#form').hide();
				$('#success').hide();
				$('#error').show();
//				alert("no valida ajax")
//				initLoading.initOpenLoading("[data-function='fc-openLoading']");

			}          
		});
		if (jQuery("#messageBoletinesSus:not(.hide)")) {
			$("#messageBoletinesSus").addClass('hide');
		}
		return true;

	}else{
//		alert("ValidaciÃƒÆ’Ã‚Â³n no valida");
		$("#messageBoletinesSus").removeClass('hide');
		return false;
	}



}
function suscripcionInf() {
	var regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/;


	if (($('#id_condiInf').is(':checked')) && ($('#suscripcion-informes').attr('data-valid') == 'true') && regex.test($('#id_emailInf').val())) {


		var formObj =  $("#suscripcion-informes");
		var formURL = formObj.attr("action");
		var formData = new FormData(this);
		$.ajax({
			url: formURL,
			type: 'GET',
			data: formObj.serialize(),
			contentType: false,
			cache: false,
			processData:false,
			success: function(data, textStatus, jqXHR)

			{
//				alert("validacion ajax informes")
if (jQuery("#messageInfSus:not(.hide)")) {
	$("#messageInfSus").addClass('hide');
}
$('#form').hide();
$('#error').hide();
$('#success').show();

			},
			error: function(jqXHR, textStatus, errorThrown) 
			{
//				alert("no valida ajax informes")
				jQuery("#messageInfSus").removeClass('hide');
				$('#form').hide();
				$('#success').hide();
				$('#error').show();

			}          
		});
		if (jQuery("#messageInfSus:not(.hide)")) {
			$("#messageInfSus").addClass('hide');
		}
		return true;

	}else{
//		alert("ValidaciÃƒÆ’Ã‚Â³n no valida informes");
		$("#messageInfSus").removeClass('hide');
		return false;

	}


}
var initLoadingS  = (function () {

	var initLoadingButtonS = (function(selector,params){

		var l = $(selector).ladda();

		$(selector).click(function(i){

			thisItem = $(this);
			thisItem.ladda( 'start' );
			var btnTextSelector = thisItem.parents("#suscripcion-boletines").find('.ladda-label');
			btnTextSelector.text("Enviando..");
			if(subcripcion()){
				setTimeout(function(){
					thisItem.ladda( 'stop' );
					btnTextSelector.text("Suscríbeme");
				},2000)
			}else{
				setTimeout(function(){
					thisItem.ladda( 'stop' );
					btnTextSelector.text("Suscríbeme");
				})

			}


		});


	});

	var initLoadingButtonSInf = (function(selector,params){

		var l = $(selector).ladda();

		$(selector).click(function(i){

			thisItem = $(this);
			thisItem.ladda( 'start' );
			var btnTextSelector = thisItem.parents("#suscripcion-informes").find('.ladda-label');
			btnTextSelector.text("Enviando..");
			if(suscripcionInf()){
				setTimeout(function(){
					thisItem.ladda( 'stop' );
					btnTextSelector.text("Suscríbeme");
				},2000)
			}else{
				setTimeout(function(){
					thisItem.ladda( 'stop' );
					btnTextSelector.text("Suscríbeme");
				})
			}
		});
	});

	return {
		initLoadingButtonS: initLoadingButtonS,
		initLoadingButtonSInf: initLoadingButtonSInf
	}

})();

function seleccionarLetra(letra) {

	if(letra != document.getElementById("hddLetra").value){
		if (jQuery('.letra-' + letra).hasClass('hide')) {
			jQuery('.letra-' + letra).removeClass('hide');
			if (document.getElementById("hddLetra").value != "") {
				jQuery('.letra-' + document.getElementById("hddLetra").value)
				.addClass('hide');
			}
		} else {
			jQuery('.letra-' + letra).addClass('hide');

		}
	}

	document.getElementById("hddLetra").value = letra;
}
function buscadorFondos(nombreFondo) {
	var categoria = $("#id-categoria option:selected").val();
	var codigoMig = $("#id-nombreFondo option:selected").val();
	var busqueda = $('#id-nombreFondo-input').val();

	var ultFiltroNombre = sessionStorage.ultimoFiltroNombre;

	if(nombreFondo != ''){
		busqueda = nombreFondo;
	}

	if (busqueda == undefined) {
		busqueda = '';
	}

	if (codigoMig == undefined) {
		codigoMig = '';
	}

	if (categoria == undefined) {
		categoria = ' ';
	}

	var nivelRiesgo = '';

	for (var i = 1; i < 8; i++) {
		if ($("#id-checkbox" + i).is(':checked')) {
			nivelRiesgo = nivelRiesgo + ',' + i
		}
	}

	if(ultFiltroNombre != undefined){
		if(ultFiltroNombre == 'mig'){
			//Lo ultimo que se ha usado del filtro nombre es una seleccion del desplegable
			busqueda = '';

			if(codigoMig == 'sel'){
				codigoMig='';
				busqueda='';

			}

		}else if(ultFiltroNombre == 'esc'){
			//Lo ultimo que se ha usado del filtro nombre es una escritura
			codigoMig = '';
		}
	}

	/****INICIO Analitica******/

	digitalData.nombreFondo = "";
	digitalData.categoria = "";
	digitalData.nivelDelRiesgo = "";
	digitalData.nResultadosFondos = "";
	digitalData.gestora = "";
	digitalData.categoriaMorningstar = "";
	digitalData.zonaGeografica = "";
	digitalData.divisa = "";
	digitalData.acDistribucionFondos = "";
	digitalData.ISIN = "";
	digitalData.proceso = "";
	digitalData.tipoBusquedaFondo = "";

	var valorSegmentoBuscador = $(".segmentoSolicitar").val();
	var valorPaginaBuscador = $(".paginaSolicitar").val();

	if (valorPaginaBuscador.toLowerCase().trim() == "buscador fondos"){
		digitalData.localizacionBuscadorFondos = "particulares:buscador fondos de inversion"
	}

	if (valorPaginaBuscador.toLowerCase().trim() == "fondos de inversión" || valorPaginaBuscador.toLowerCase().trim() == "fondos de inversion"){
		digitalData.localizacionBuscadorFondos = "particulares:subhome fondos de inversion"
	}

	if (valorSegmentoBuscador.toLowerCase().trim() == "banca privada"){
		digitalData.localizacionBuscadorFondos = "banca privada:buscador fondos de inversion"
	}


	var valorTipoBusqueda= document.getElementById("id-radio1");

	if(valorTipoBusqueda != null){
		if (valorTipoBusqueda.checked) {
			digitalData.tipoBusquedaFondo = "por nombre de fondo"
		}
	}

	var valorExclusivoBP = document.getElementById("id_customer_ctf");

	if (valorExclusivoBP != null) {
		if (valorExclusivoBP.checked) {
			digitalData.exclusivosBancaPrivada = "si"
		} else {
			digitalData.exclusivosBancaPrivada = "no"
		}
	}else{
		digitalData.exclusivosBancaPrivada = ""
	}

	var categoriaAnalitica = "";
	var codigoMigAnalitica = "";

	if($("#id-categoria option:selected").html() != undefined){
		categoriaAnalitica = $("#id-categoria option:selected").html().trim();
		digitalData.categoria = normalizeString(categoriaAnalitica);
	}
	if($("#id-nombreFondo option:selected").html() != undefined){
		codigoMigAnalitica = $("#id-nombreFondo option:selected").html().trim();
		digitalData.nombreFondo = normalizeString(codigoMigAnalitica);
	}

	digitalData.nivelDelRiesgo = nivelRiesgo.replace(",","");

	/**** FIN Analitica******/

	var nivelRiesgoMovil = $("#id-level option:selected").val();

	if (nivelRiesgoMovil != '' && nivelRiesgoMovil !=undefined) {
		nivelRiesgo = "," + nivelRiesgoMovil;
	}


	if (codigoMig != '' && categoria != ' ' && nivelRiesgo != '') {

		var nivelRiesgoSelected = nivelRiesgo.split(',');
		var selector = '';

		for (var i = 1; i < nivelRiesgoSelected.length; i++) {
			if (i == 1) {
				selector = ".search-Cat" + categoria + ".search-Mig" + codigoMig + ".search-NR" + nivelRiesgoSelected[i];

			} else {
				selector = selector + ",.search-Cat" + categoria + ".search-Mig" + codigoMig + ".search-NR"	+ nivelRiesgoSelected[i];
			}
		}

		$("li.buscador2").hide();
		$(".filafondos").hide();

		$(selector).show();

		/****INICIO ANALATICA*****/
		if(document.getElementById("buscadorBankiaPensiones") != null){
			digitalData.nResultadosFondos = ($(selector).size())
		}else if(document.getElementById("buscadorFondosBF") != null){
			digitalData.nResultadosFondos = ($(selector).size());
		}else{
			digitalData.nResultadosFondos = ($(selector).size())/2;	
		}
		/****FIN ANALAÂTICA*****/

	} else if (codigoMig != '' && categoria != ' ') {
		$("li.buscador2").hide();
		$(".filafondos").hide();
		$(".search-Cat" + categoria + ".search-Mig" + codigoMig).show();

		/****INICIO ANALITICA*****/
		if(document.getElementById("buscadorBankiaPensiones") != null){
			digitalData.nResultadosFondos = ($(".search-Cat" + categoria + ".search-Mig" + codigoMig).size());
		}else if(document.getElementById("buscadorFondosBF") != null){
			digitalData.nResultadosFondos = ($(selector).size());
		}else{
			digitalData.nResultadosFondos = ($(".search-Cat" + categoria + ".search-Mig" + codigoMig).size())/2;
		}

		/****FIN ANALITICA*****/

	} else if (codigoMig != '' && nivelRiesgo != '') {
		var nivelRiesgoSelected = nivelRiesgo.split(',');
		var selector = '';

		for (var i = 1; i < nivelRiesgoSelected.length; i++) {
			if (i == 1) {
				selector = ".search-Mig" + codigoMig + ".search-NR"	+ nivelRiesgoSelected[i];
			} else {
				selector = selector + ",.search-Mig" + codigoMig + ".search-NR"	+ nivelRiesgoSelected[i];
			}
		}

		$("li.buscador2").hide();
		$(".filafondos").hide();


		if ($(".minibuscador").length != 0) {
			// Buscador Movil
			if($(".mod_relatedPlanNew.rpl-relatedView .rpl-list").length > 0){
				$(".mod_relatedPlanNew.rpl-relatedView .rpl-list").show();
			}

			// Para el minibuscador solo se muestran 3	    
			$(selector).eq(0).show();
			$(selector).eq(1).show();
			$(selector).eq(2).show();

			/****INICIO ANALATICA*****/
			if($(selector).size() > 3){
				digitalData.nResultadosFondos = "3";
			}else{
				digitalData.nResultadosFondos = $(selector).size();
			}
			/****FIN ANALATICA*****/

		} else {
			$(selector).show();

			/****INICIO ANALATICA*****/
			if(document.getElementById("buscadorBankiaPensiones") != null){
				digitalData.nResultadosFondos = ($(selector).size());
			}else if(document.getElementById("buscadorFondosBF") != null){
				digitalData.nResultadosFondos = ($(selector).size());
			}else{
				digitalData.nResultadosFondos = ($(selector).size())/2;
			}
			/****FIN ANALATICA*****/
		}

		//$(selector).show();

	} else if(busqueda != "" && ultFiltroNombre == 'esc'){

		var contFondosTabla = 0;
		var valorExclusivoBP = document.getElementById("id_customer_ctf");

		texto = busqueda.toLowerCase();

		var r = 0;

		//identificarfiltros
		var categselect = $('#id-categoria-button').find('.ui-selectmenu-text').text();

		var riesgosel=[];
		var cont=0;

		for (var i = 1; i < 8; i++) {
			if ($("#id-checkbox" + i).is(':checked')) {
				riesgosel[cont] = i;
				cont++;
			}
		}
		if(codigoMig != 'sel' || texto != 'Selecciona'){
			if ($('#listaTabla').hasClass('rpl-active')) {
				var table = $("#tabla").find("tBody");

				table.find("[role='row']").each(function(){
					var titulo = $(this).text().toLowerCase();

					var clases = $(this).attr('class');

					var categoriaCoincide = true;
					if(categselect.indexOf('Selecciona')==-1 && categselect.indexOf('Select')==-1){
						categoriaCoincide = false;
						if(clases.indexOf($("#id-categoria option:selected").val() + " search") > -1){
							categoriaCoincide = true;
						}
					}

					var riesgoCoincide=true;

					if(riesgosel.length>0){
						riesgoCoincide=false;
						for (var i = 0 ; i < riesgosel.length ; i++) {
							if(clases.indexOf("NR" + riesgosel[i]) > -1){

								riesgoCoincide=true;
								i = riesgosel.length;
							}
						}
					}

					if (titulo.indexOf(texto) !== -1 && categoriaCoincide && riesgoCoincide) {
						//if($(this).is(":visible")) 
						$(this).show();
						if (valorExclusivoBP != null) {

							if (valorExclusivoBP.checked) {

								if($(this).hasClass("analiticaBuscadorCheckBP")){
									contFondosTabla++;
								}

							} else {
								if($(this).hasClass("analiticaBuscadorCheckTodos")){
									contFondosTabla++;
								}

							}

						}else{
							contFondosTabla++;

						}

					} else {
						if($(this).is(":visible")) 
							$(this).hide();
					}
				});


			} else {
				$('.buscador2').each(function() {
					titulo = $('.rpl-title',$(this)).text().toLowerCase();

					var clases = $(this).attr('class');

					var categoriaCoincide = true;
					if(categselect.indexOf('Selecciona')==-1 && categselect.indexOf('Select')==-1){
						categoriaCoincide = false;
						if(clases.indexOf($("#id-categoria option:selected").val() + " search") > -1){
							categoriaCoincide = true;
						}
					}

					var riesgoCoincide=true;

					if(riesgosel.length>0){
						riesgoCoincide=false;
						for (var i = 0 ; i < riesgosel.length ; i++) {
							if(clases.indexOf("NR" + riesgosel[i]) > -1){

								riesgoCoincide=true;
								i = riesgosel.length;
							}
						}
					}

					if (titulo.indexOf(texto) !== -1 && categoriaCoincide && riesgoCoincide) {
						//if($(this).is(":visible")) 
						$(this).show();
						if (valorExclusivoBP != null) {

							if (valorExclusivoBP.checked) {

								if($(this).hasClass("analiticaBuscadorCheckBP")){
									contFondosTabla++;
								}

							} else {
								if($(this).hasClass("analiticaBuscadorCheckTodos")){
									contFondosTabla++;
								}

							}

						}else{
							contFondosTabla++;

						}

					} else {
						if($(this).is(":visible")) 
							$(this).hide();
					}
				});

				digitalData.nResultadosFondos = contFondosTabla;

			}
		}	


	} else if (nivelRiesgo != '' && categoria != ' ') {

		var nivelRiesgoSelected = nivelRiesgo.split(',');
		var selector = '';
		for (var i = 1; i < nivelRiesgoSelected.length; i++) {
			if (i == 1) {
				selector = ".search-Cat" + categoria + ".search-NR"	+ nivelRiesgoSelected[i];
			} else {
				selector = selector + ",.search-Cat" + categoria + ".search-NR"	+ nivelRiesgoSelected[i];
			}
		}

		$("li.buscador2").hide();
		$(".filafondos").hide();

		if ($(".minibuscador").length != 0) {
			// Buscador Movil
			if($(".mod_relatedPlanNew.rpl-relatedView .rpl-list").length > 0){
				$(".mod_relatedPlanNew.rpl-relatedView .rpl-list").show();
			}

			// Para el minibuscador solo se muestran 3	    
			$(selector).eq(0).show();
			$(selector).eq(1).show();
			$(selector).eq(2).show();

			/****INICIO ANALATICA*****/
			if($(selector).size() > 3){
				digitalData.nResultadosFondos = "3";
			}else{
				digitalData.nResultadosFondos = $(selector).size();
			}
			/****FIN ANALATICA*****/

		} else {
			$(selector).show();

			/****INICIO ANALITICA*****/
			/**Con esto comprobamos si es banca privada o no y tiene check**/
			if (valorExclusivoBP != null) {
				var aux = 0;
				var contadorFondos = 0;

				if (valorExclusivoBP.checked) {
					while(aux< $(selector).size()){
						if($(selector).eq(aux).hasClass("analiticaBuscadorCheckBP")){
							contadorFondos = contadorFondos + 1;
						}
						aux = aux + 1;
					}
				} else {
					while(aux< $(selector).size()){
						if($(selector).eq(aux).hasClass("analiticaBuscadorCheckTodos")){
							contadorFondos = contadorFondos + 1;
						}
						aux = aux + 1;
					}
				}

				digitalData.nResultadosFondos = contadorFondos;

			}else{
				if(document.getElementById("buscadorBankiaPensiones") != null){
					digitalData.nResultadosFondos = ($(selector).size());
				}else if(document.getElementById("buscadorFondosBF") != null){
					digitalData.nResultadosFondos = ($(selector).size());
				}else{
					digitalData.nResultadosFondos = ($(selector).size())/2;
				}
			}
			/****FIN ANALITICA*****/
		}

		//$(selector).show();


	} else if (codigoMig != '') {

		$("li.buscador2").hide();
		$(".filafondos").hide();
		$(".search-Mig" + codigoMig).show();

		/****INICIO ANALITICA*****/
		/**Con esto comprobamos si es banca privada o no y tiene check**/
		if (valorExclusivoBP != null) {
			var aux = 0;
			var contadorFondos = 0;

			if (valorExclusivoBP.checked) {
				while(aux< $(".search-Mig" + codigoMig).size()){
					if($(".search-Mig" + codigoMig).eq(aux).hasClass("analiticaBuscadorCheckBP")){
						contadorFondos = contadorFondos + 1;
					}
					aux = aux + 1;
				}

			} else {
				while(aux< $(".search-Mig" + codigoMig).size()){
					if($(".search-Mig" + codigoMig).eq(aux).hasClass("analiticaBuscadorCheckTodos")){
						contadorFondos = contadorFondos + 1;
					}
					aux = aux + 1;
				}
			}

			digitalData.nResultadosFondos = contadorFondos;	

		}else{

			if(document.getElementById("buscadorBankiaPensiones") != null){
				digitalData.nResultadosFondos = ($(".search-Mig" + codigoMig).size());
			}else if(document.getElementById("buscadorFondosBF") != null){
				digitalData.nResultadosFondos = ($(selector).size());
			}else{
				digitalData.nResultadosFondos = ($(".search-Mig" + codigoMig).size())/2;
			}

		}
		/****FIN ANALITICA*****/


		// } else if (busqueda != '' && ultFiltroNombre == 'esc') {

		//buscaTabla();
		if(document.getElementById("buscadorTituloPensiones") != null){
			digitalData.proceso = "buscador de planes"
				digitalData.puntoAcceso = "buscador de planes";
		}else if(document.getElementById("buscadorTituloEPSV") != null){
			digitalData.proceso = "buscador de epsv"
				digitalData.puntoAcceso = "buscador de epsv";
		}else{
			digitalData.proceso = "buscador de fondos";
			digitalData.puntoAcceso = "buscador de fondos";
		}

	} else if (categoria != ' ') {

		$(".buscador2").hide();
		$(".filafondos").hide();

		if ($(".minibuscador").length != 0) {
			// Buscador Movil
			if($(".mod_relatedPlanNew.rpl-relatedView .rpl-list").length > 0){
				$(".mod_relatedPlanNew.rpl-relatedView .rpl-list").show();
			}

			// Para el minibuscador solo se muestran 3
			$(".search-Cat" + categoria).eq(0).show();
			$(".search-Cat" + categoria).eq(1).show();
			$(".search-Cat" + categoria).eq(2).show();


			/****INICIO ANALATICA*****/
			if($(".search-Cat" + categoria).size() > 3){
				digitalData.nResultadosFondos = "3";
			}else{
				digitalData.nResultadosFondos = $(".search-Cat" + categoria).size();
			}
			/****FIN ANALATICA*****/

		} else {

			$(".search-Cat" + categoria).show();
			/****INICIO ANALITICA*****/
			/**Con esto comprobamos si es banca privada o no y tiene check**/
			if (valorExclusivoBP != null) {

				var aux = 0;
				var contadorFondos = 0;

				if (valorExclusivoBP.checked) {
					while(aux< $(".search-Cat" + categoria).size()){
						if($(".search-Cat" + categoria).eq(aux).hasClass("analiticaBuscadorCheckBP")){
							contadorFondos = contadorFondos + 1;
						}
						aux = aux + 1;
					}
				} else {
					while(aux< $(".search-Cat" + categoria).size()){
						if($(".search-Cat" + categoria).eq(aux).hasClass("analiticaBuscadorCheckTodos")){
							contadorFondos = contadorFondos + 1;
						}
						aux = aux + 1;
					}
				}

				digitalData.nResultadosFondos = contadorFondos;

			}else{
				if(document.getElementById("buscadorBankiaPensiones") != null){
					digitalData.nResultadosFondos = ($(".search-Cat" + categoria).size());
				}else if(document.getElementById("buscadorFondosBF") != null){
					digitalData.nResultadosFondos = ($(selector).size());
				}else{
					digitalData.nResultadosFondos = ($(".search-Cat" + categoria).size())/2;
				}
			}
			/****FIN ANALITICA*****/
		}

	} else if (nivelRiesgo != '') {

		var nivelRiesgoSelected = nivelRiesgo.split(',');
		var selector = '';

		for (var i = 1; i < nivelRiesgoSelected.length; i++) {

			if (i == 1) {
				selector = ".search-NR" + nivelRiesgoSelected[i];
			} else {
				selector = selector + ",.search-NR" + nivelRiesgoSelected[i];
			}
		}

		$("li.buscador2").hide();
		$(".filafondos").hide();

		if ($(".minibuscador").length != 0) {
			// Buscador Movil
			if($(".mod_relatedPlanNew.rpl-relatedView .rpl-list").length > 0){
				$(".mod_relatedPlanNew.rpl-relatedView .rpl-list").show();
			}

			// Para el minibuscador solo se muestran 3	    
			$(selector).eq(0).show();
			$(selector).eq(1).show();
			$(selector).eq(2).show();

			/****INICIO ANALATICA*****/
			if($(selector).size() > 3){
				digitalData.nResultadosFondos = "3";
			}else{
				digitalData.nResultadosFondos = $(selector).size();
			}
			/****FIN ANALATICA*****/

		} else {

			$(selector).show();

			/****INICIO ANALITICA*****/
			/**Con esto comprobamos si es banca privada o no y tiene check**/
			if (valorExclusivoBP != null) {
				var aux = 0;
				var contadorFondos = 0;

				if (valorExclusivoBP.checked) {
					while(aux< $(selector).size()){
						if($(selector).eq(aux).hasClass("analiticaBuscadorCheckBP")){
							contadorFondos = contadorFondos + 1;
						}
						aux = aux + 1;
					}
				} else {
					while(aux< $(selector).size()){
						if($(selector).eq(aux).hasClass("analiticaBuscadorCheckTodos")){
							contadorFondos = contadorFondos + 1;
						}
						aux = aux + 1;
					}
				}

				digitalData.nResultadosFondos = contadorFondos;	

			}else{

				if(document.getElementById("buscadorBankiaPensiones") != null){
					digitalData.nResultadosFondos = ($(selector).size());
				}else if(document.getElementById("buscadorFondosBF") != null){
					digitalData.nResultadosFondos = ($(selector).size());
				}else{
					digitalData.nResultadosFondos = ($(selector).size())/2;
				}

			}
			/****FIN ANALITICA*****/
		}

	} else {
		$("li.buscador2").hide();
		$(".filafondos").hide();
		if ($(".minibuscador").length != 0) {
			// Buscador Movil
			if($(".mod_relatedPlanNew.rpl-relatedView .rpl-list").length > 0){
				$(".mod_relatedPlanNew.rpl-relatedView .rpl-list").show();
			}

			// Para el minibuscador solo se muestran 3
			$("li.buscador2").eq(0).show();
			$("li.buscador2").eq(1).show();
			$("li.buscador2").eq(2).show();

			/****INICIO ANALATICA*****/
			if($("li.buscador2").size() > 3){
				digitalData.nResultadosFondos = "3";
			}else{
				digitalData.nResultadosFondos = $("li.buscador2").size();
			}
			/****FIN ANALATICA*****/

		} else {
			$(".filafondos").show();
			$("li.buscador2").show();
			/****INICIO ANALITICA*****/
			/**Con esto comprobamos si es banca privada o no y tiene check**/
			if (valorExclusivoBP != null) {
				var aux = 0;
				var contadorFondos = 0;

				if (valorExclusivoBP.checked) {
					while(aux< $(selector).size()){
						if($(selector).eq(aux).hasClass("analiticaBuscadorCheckBP")){
							contadorFondos = contadorFondos + 1;
						}
						aux = aux + 1;
					}
				} else {
					while(aux< $(selector).size()){
						if($(selector).eq(aux).hasClass("analiticaBuscadorCheckTodos")){
							contadorFondos = contadorFondos + 1;
						}
						aux = aux + 1;
					}
				}
				digitalData.nResultadosFondos = contadorFondos;	
			}else{

				if(document.getElementById("buscadorBankiaPensiones") != null){
					digitalData.nResultadosFondos = ($(selector).size());
				}else if(document.getElementById("buscadorFondosBF") != null){
					digitalData.nResultadosFondos = ($(selector).size());
				}
				else{
					digitalData.nResultadosFondos = ($(selector).size())/2;	
				}
			}
			/****FIN ANALITICA*****/
		}

		//$("li.buscador2").show();
		//$(".filafondos").show();

	}


	if((sessionStorage.categoriaBuscadorAnterior != categoria) || (sessionStorage.nivelRiesgoBuscadorAnterior != nivelRiesgo) || (sessionStorage.exclusivoBancaPrivadaAnterior != digitalData.exclusivosBancaPrivada)){

		if(document.getElementById("buscadorTituloPensiones") != null){
			digitalData.proceso = "buscador de planes"
				digitalData.puntoAcceso = "buscador de planes";
		}else if(document.getElementById("buscadorTituloEPSV") != null){
			digitalData.proceso = "buscador de epsv"
				digitalData.puntoAcceso = "buscador de epsv";
		}else{
			digitalData.proceso = "buscador de fondos";
			digitalData.puntoAcceso = "buscador de fondos";
		}
		/*if(busqueda != ''){
			digitalData.proceso = digitalData.proceso + ":Por nombre del fondo:"+normalizeString(busqueda);
		}
		if(categoria != ' '){
			digitalData.proceso = digitalData.proceso + ":Por categoria:"+normalizeString(categoriaAnalitica);
		}
		if(nivelRiesgo != ''){
			digitalData.proceso = digitalData.proceso + ":Por nivel de riesgo:"+digitalData.nivelDelRiesgo
		}*/
		if(digitalData.exclusivosBancaPrivada != ''){
			digitalData.proceso = "buscador de fondos";
			digitalData.puntoAcceso = "buscador de fondos banca privada";
		}

		digitalData.idCampana = "";
		digitalData.localizacion = "";
		if($("#id-nombreFondo-input").val() != 'Selecciona'){

			digitalData.nombreFondo = $("#id-nombreFondo-input").val();
		}

		_satellite.track('buscador de fondos');
	}
	sessionStorage.setItem('exclusivoBancaPrivadaAnterior', digitalData.exclusivosBancaPrivada);
	sessionStorage.setItem('nombreBuscadorAnterior', busqueda);
	sessionStorage.setItem('codigoMIGBuscadorAnterior', codigoMig);
	sessionStorage.setItem('categoriaBuscadorAnterior', categoria);
	sessionStorage.setItem('nivelRiesgoBuscadorAnterior', nivelRiesgo);

}

function setCookie(cName, cookieValue, expireDays, domain) {
	if (expireDays) {
		var date = new Date();
		date.setTime(date.getTime() + (expireDays * 24 * 60 * 60 * 1000));
		var expires = "expires=" + date.toUTCString();
	} else
		var expires = "";
	if(domain != ""){
		document.cookie = cName + "=" + cookieValue + "; " + expires + "; path=/; domain=" + domain;
	}else{
		document.cookie = cName + "=" + cookieValue + "; " + expires + "; path=/";
	}
}
function getCookie(cName) {
	var name = cName + "=";
	var ca = document.cookie.split(';');
	for (var i = 0; i < ca.length; i++) {
		var c = ca[i];
		while (c.charAt(0) == ' ')
			c = c.substring(1);
		if (c.indexOf(name) == 0)
			return c.substring(name.length, c.length);
	}
	return null;
}



function changeHeight(h) {
    var iframe1 = $("#login-iframe");
    iframe1.height(h);
       
    var iframe2 = $("#login-iframeG");
    iframe2.height(h);
}

function changeHeightBole(h) {
    var iframe1 = $("#login-iframe-bole");
    iframe1.height(h);
}

function changeHeightTabs(h) {
	var iframe2 = $("#id_loginDuplicadoTabsIframe");
	iframe2.height(h);
}


function goOI2(url) {
	if (url != "") {
		location.href = url;
	} else {
		location.href = "posicion-global";
	}
}


function postOI (parametrosEnvioPU){
	var form = document.createElement("form");
	form.action = parametrosEnvioPU.accion;
	form.method = "POST";
	var input = document.createElement("input");
	input.name = "_flowExecutionKey";
	input.value = parametrosEnvioPU.flowExecutionKey;
	input.type = "hidden";
	form.appendChild(input);
	input = document.createElement("input");
	input.name = "_eventId";
	input.value = parametrosEnvioPU.evento;
	input.type = "hidden";
	form.appendChild(input);
	document.body.appendChild(form);
	form.submit();
};

function clickToCall(nombre, telefono, cliente) {
//	alert('ClickToCall');
}
function ocultarCampo(campo) {
	error = document.getElementById(campo);
	error.className = "mod_message msg-error hide";
}
function validacionTelefono() {
	valor = document.getElementById("id_tel").value;
	etiqueta = document.getElementById("id_tel_lab");
	entrada = document.getElementById("id_tel");
	descrError = document.getElementById("id_desc_err_tel");
	correcto = 0;
	segmentoActual = document.getElementById("segmentoActual").value;


	if(segmentoActual=="particulares" || segmentoActual=="banca privada" || segmentoActual=="banca personal"){

		nombreValor = document.getElementById("id_nom1").value;
		etiquetaNombre = document.getElementById("id_nom1_lab");
		entradaNombre = document.getElementById("id_nom1");
		descrErrorNombre = document.getElementById("id_desc_err_nombre");

		if(nombreValor==""){
			etiquetaNombre.className = "frm-label frm-message-error";
			entradaNombre.className = "frm-input input-has-error";
			descrErrorNombre.className = "frm-txt-message";
			correcto = 1
		}else{
			etiquetaNombre.className = "frm-label";
			entradaNombre.className = "frm-input";
			descrErrorNombre.className = "frm-txt-message hide";
		}
	}
	if(segmentoActual=="empresas" || segmentoActual=="pymes y autonomos" ){


		nombreEmpleadoValor = document.getElementById("id_nomemp").value;
		etiquetaNombreEmpleado = document.getElementById("id_nomemp_lab");
		entradaNombreEmpleado = document.getElementById("id_nomemp");
		descrErrorNombreEmpleado = document.getElementById("id_desc_err_nombemp");

		if(nombreEmpleadoValor==""){

			etiquetaNombreEmpleado.className = "frm-label frm-message-error";
			entradaNombreEmpleado.className = "frm-input input-has-error";
			descrErrorNombreEmpleado.className = "frm-txt-message";
			correcto = 1
		}else{
			etiquetaNombreEmpleado.className = "frm-label";
			entradaNombreEmpleado.className = "frm-input";
			descrErrorNombreEmpleado.className = "frm-txt-message hide";
		}
		perContacValor = document.getElementById("id_nomper").value;
		etiquetaPerContac = document.getElementById("id_nomper_lab");
		entradaPerContac = document.getElementById("id_nomper");
		descrErrorPerContac = document.getElementById("id_desc_err_nomper");

		if(perContacValor==""){

			etiquetaPerContac.className = "frm-label frm-message-error";
			entradaPerContac.className = "frm-input input-has-error";
			descrErrorPerContac.className = "frm-txt-message";
			correcto = 1
		}else{
			etiquetaPerContac.className = "frm-label";
			entradaPerContac.className = "frm-input";
			descrErrorPerContac.className = "frm-txt-message hide";
		}

		if(segmentoActual=="empresas"){
			cifValor = document.getElementById("id_cif").value;
			etiquetaCif = document.getElementById("id_cif_lab");
			entradaCif = document.getElementById("id_cif");
			descrErrorCif = document.getElementById("id_desc_err_cif");

			if(cifValor==""){

				etiquetaCif.className = "frm-label frm-message-error";
				entradaCif.className = "frm-input input-has-error";
				descrErrorCif.className = "frm-txt-message";
				correcto = 1
			}else{
				etiquetaCif.className = "frm-label";
				entradaCif.className = "frm-input";
				descrErrorCif.className = "frm-txt-message hide";
			}


		}


	} 



//	if (!(/^\+\d{2,3}\s\d{3}\s\d{3}\s\d{3}$/.test(valor))) {
	if (!(/(6|7|8|9)[0-9]{8}$/.test(valor))) {
		etiqueta.className = "frm-label frm-message-error";
		entrada.className = "frm-input input-has-error";
		descrError.className = "frm-txt-message";
		correcto = 1
	} else {
		etiqueta.className = "frm-label";
		entrada.className = "frm-input";
		descrError.className = "frm-txt-message hide";
	}
	descrErrorCon = document.getElementById("id_desc_err_tel_con");
	elemento = document.getElementById("id_condi");
	etiquetaCondi = document.getElementById("id_condi_lab");
	if (!elemento.checked) {
		etiquetaCondi.className = "frm-labelError";
		descrErrorCon.className = "frm-label frm-message-error";
		correcto = 1
	} else {
		descrErrorCon.className = "frm-label frm-message-error hide";
		etiquetaCondi.className = "frm-label";
	}

	if ($('#telefonoContactabilidad').attr('data-valid') == 'false') {
		$(".mod_captchaTel").addClass('frm-message-error');
		correcto = 1;
	}
	error = document.getElementById("id_error_tel");
	enviadoTel = document.getElementById("enviado_tel");
	if (correcto == 0) {
		if(error !== null){
			error.className = "mod_message msg-error hide";
		}
		enviadoTel.value = "true";

		return true;
	} else {
		if(error !== null){
			error.className = "mod_message msg-error";
		}
		return false;
	}
}

function validacionTelefonoLanding() {
	valor = document.getElementById("id_tel").value;
	etiqueta = document.getElementById("id_tel_lab");
	entrada = document.getElementById("id_tel");
	descrError = document.getElementById("id_desc_err_tel");
	correcto = 0;


	nombreValor = document.getElementById("id_nom1").value;
	etiquetaNombre = document.getElementById("id_nom1_lab");
	entradaNombre = document.getElementById("id_nom1");
	descrErrorNombre = document.getElementById("id_desc_err_nomSol");

	if(nombreValor==""){
		etiquetaNombre.className = "frm-label frm-message-error";
		entradaNombre.className = "frm-input input-has-error";
		descrErrorNombre.className = "frm-txt-message";
		correcto = 1
	}else{
		etiquetaNombre.className = "frm-label";
		entradaNombre.className = "frm-input";
		descrErrorNombre.className = "frm-txt-message hide";
	}
//	if (!(/^\+\d{2,3}\s\d{3}\s\d{3}\s\d{3}$/.test(valor))) {
	if (!(/(6|7|8|9)[0-9]{8}$/.test(valor))) {
		etiqueta.className = "frm-label frm-message-error";
		entrada.className = "frm-input input-has-error";
		descrError.className = "frm-txt-message";
		correcto = 1
	} else {
		etiqueta.className = "frm-label";
		entrada.className = "frm-input";
		descrError.className = "frm-txt-message hide";
	}
	descrErrorCon = document.getElementById("id_desc_err_tel_con");
	elemento = document.getElementById("id_condi");
	etiquetaCondi = document.getElementById("id_condi_lab");
	if (!elemento.checked) {
		etiquetaCondi.className = "frm-labelError";
		descrErrorCon.className = "frm-label frm-message-error";
		correcto = 1
	} else {
		descrErrorCon.className = "frm-label frm-message-error hide";
		etiquetaCondi.className = "frm-label";
	}


	if ($('#telefonoContactabilidad').attr('data-valid') == 'false') {
		$(".mod_captcha").addClass('frm-message-error');
		correcto = 1;
	}
	error = document.getElementById("id_error_tel");
	enviadoTel = document.getElementById("enviado_tel");
	if (correcto == 0) {
		if(error !== null){
			error.className = "mod_message msg-error hide";
		}
		enviadoTel.value = "true";

		return true;
	} else {
		if(error !== null){
			error.className = "mod_message msg-error";
		}
		return false;
	}
}

function validacionTelefonoTablet() {
	valor = document.getElementById("id_tel_tablet").value;
	etiqueta = document.getElementById("id_tel_lab_tablet");

	entrada = document.getElementById("id_tel_tablet");
	descrError = document.getElementById("id_desc_err_tel_tablet");
	correcto = 0;
	segmentoActual = document.getElementById("segmentoActual").value;


	if(segmentoActual=="particulares" || segmentoActual=="banca privada" || segmentoActual=="banca personal"){

		nombreValor = document.getElementById("id_nom1_tablet").value;
		etiquetaNombre = document.getElementById("id_nom1_lab_tablet");
		entradaNombre = document.getElementById("id_nom1_tablet");
		descrErrorNombre = document.getElementById("id_desc_err_nombre_tablet");

		if(nombreValor==""){
			etiquetaNombre.className = "frm-label frm-message-error";
			entradaNombre.className = "frm-input input-has-error";
			descrErrorNombre.className = "frm-txt-message";
			correcto = 1
		}else{
			etiquetaNombre.className = "frm-label";
			entradaNombre.className = "frm-input";
			descrErrorNombre.className = "frm-txt-message hide";
		}
	}
	if(segmentoActual=="empresas" || segmentoActual=="pymes y autonomos" ){


		nombreEmpleadoValor = document.getElementById("id_nomemp_tablet").value;
		etiquetaNombreEmpleado = document.getElementById("id_nomemp_lab_tablet");
		entradaNombreEmpleado = document.getElementById("id_nomemp_tablet");
		descrErrorNombreEmpleado = document.getElementById("id_desc_err_nombemp_tablet");

		if(nombreEmpleadoValor==""){

			etiquetaNombreEmpleado.className = "frm-label frm-message-error";
			entradaNombreEmpleado.className = "frm-input input-has-error";
			descrErrorNombreEmpleado.className = "frm-txt-message";
			correcto = 1
		}else{
			etiquetaNombreEmpleado.className = "frm-label";
			entradaNombreEmpleado.className = "frm-input";
			descrErrorNombreEmpleado.className = "frm-txt-message hide";
		}
		perContacValor = document.getElementById("id_nomper_tablet").value;
		etiquetaPerContac = document.getElementById("id_nomper_lab_tablet");
		entradaPerContac = document.getElementById("id_nomper_tablet");
		descrErrorPerContac = document.getElementById("id_desc_err_nomper_tablet");

		if(perContacValor==""){

			etiquetaPerContac.className = "frm-label frm-message-error";
			entradaPerContac.className = "frm-input input-has-error";
			descrErrorPerContac.className = "frm-txt-message";
			correcto = 1
		}else{
			etiquetaPerContac.className = "frm-label";
			entradaPerContac.className = "frm-input";
			descrErrorPerContac.className = "frm-txt-message hide";
		}

		if(segmentoActual=="empresas"){
			cifValor = document.getElementById("id_cif_tablet").value;
			etiquetaCif = document.getElementById("id_cif_lab_tablet");
			entradaCif = document.getElementById("id_cif_tablet");
			descrErrorCif = document.getElementById("id_desc_err_cif_tablet");

			if(cifValor==""){

				etiquetaCif.className = "frm-label frm-message-error";
				entradaCif.className = "frm-input input-has-error";
				descrErrorCif.className = "frm-txt-message";
				correcto = 1
			}else{
				etiquetaCif.className = "frm-label";
				entradaCif.className = "frm-input";
				descrErrorCif.className = "frm-txt-message hide";
			}


		}


	} 

//	if (!(/^\+\d{2,3}\s\d{3}\s\d{3}\s\d{3}$/.test(valor))) {
	if (!(/(6|7|8|9)[0-9]{8}$/.test(valor))) {
		etiqueta.className = "frm-label frm-message-error";
		entrada.className = "frm-input input-has-error";
		descrError.className = "frm-txt-message";
		correcto = 1
	} else {
		etiqueta.className = "frm-label";
		entrada.className = "frm-input";
		descrError.className = "frm-txt-message hide";
	}
	descrErrorCon = document.getElementById("id_desc_err_tel_con_tablet");
	elemento = document.getElementById("id_condi_tablet");
	etiquetaCondi = document.getElementById("id_condi_lab_tablet");
	if (!elemento.checked) {
		etiquetaCondi.className = "frm-labelError";
		descrErrorCon.className = "frm-label frm-message-error";
		correcto = 1
	} else {
		descrErrorCon.className = "frm-label frm-message-error hide";
		etiquetaCondi.className = "frm-label";
	}

	if ($('#telefonoContactabilidad_tablet').attr('data-valid') == 'false') {
		$(".captcha_tablet_tlf").addClass('frm-message-error');
		correcto = 1;
	}
	error = document.getElementById("id_error_tel_tablet");
	enviadoTel = document.getElementById("enviado_tel_tablet");
	if (correcto == 0) {
		if(error !== null){
			error.className = "mod_message msg-error hide";
		}
		enviado.value = "true";

		return true;
	} else {
		if(error !== null){
			error.className = "mod_message msg-error";
		}
		return false;
	}
}

function validacionTelefonoContSubHome() {
	valor = document.getElementById("id_phone_ctc_call").value;
	etiqueta = document.getElementById("id_phone_ctc_lab");
	entrada = document.getElementById("id_phone_ctc_call");
	descrError = document.getElementById("id_desc_err_tel_SH");
	correcto = 0;
//	if (!(/^\+\d{2,3}\s\d{3}\s\d{3}\s\d{3}$/.test(valor))) {
	if (!(/(6|7|8|9)[0-9]{8}$/.test(valor))) {
		etiqueta.className = "frm-label frm-message-error";
		entrada.className = "frm-input input-has-error";
		descrError.className = "frm-txt-message";
		correcto = 1
	} else {
		etiqueta.className = "frm-label";
		entrada.className = "frm-input";
		descrError.className = "frm-txt-message hide";
	}
	nombreValor = document.getElementById("id_nom1_Sol").value;
	etiquetaNombre = document.getElementById("id_nom1_lab_Sol");
	entradaNombre = document.getElementById("id_nom1_Sol");
	descrErrorNombre = document.getElementById("id_desc_err_nom1_Sol");

	if(nombreValor==""){

		etiquetaNombre.className = "frm-label frm-message-error";
		entradaNombre.className = "frm-input input-has-error";
		descrErrorNombre.className = "frm-txt-message";
		correcto = 1
	}else{
		etiquetaNombre.className = "frm-label";
		entradaNombre.className = "frm-input";
		descrErrorNombre.className = "frm-txt-message hide";
	}
	descrErrorCon = document.getElementById("id_desc_err_tel_cond");
	elemento = document.getElementById("id_conditions_ctc");
	etiquetaCondi = document.getElementById("id_conditions_ctc_lab");
	if (!elemento.checked) {
		etiquetaCondi.className = "frm-labelError";
		descrErrorCon.className = "frm-label frm-message-error";
		correcto = 1
	} else {
		descrErrorCon.className = "frm-label frm-message-error hide";
		etiquetaCondi.className = "frm-label";
	}

	if (typeof($('#telefonoContactabilidad_Sol').attr('data-valid')) == "undefined" || $('#telefonoContactabilidad_Sol').attr('data-valid') == 'false') {
		$("#mod_captchaTel_Sol").addClass('frm-message-error');
		correcto = 1;
	}
	error = document.getElementById("id_error_tel_SH");
	enviadoTel = document.getElementById("enviado_tel_SH");
	if (correcto == 0) {
		if(error !== null){
			error.className = "mod_message msg-error hide";
		}
		enviadoTel.value = "true";

		return true;
	} else {
		if(error !== null){
			error.className = "mod_message msg-error";
		}
		return false;
	}
}

function validacionTelefonoContTelef(){
	valor = document.getElementById("id_tel_sim").value;
	etiqueta = document.getElementById("id_tel_labSim");
	entrada = document.getElementById("id_tel_sim");
	descrError = document.getElementById("id_tel_labSim_error");
	correcto = 0;
//	if (!(/^\+\d{2,3}\s\d{3}\s\d{3}\s\d{3}$/.test(valor))) {
	if (!(/(6|7|8|9)[0-9]{8}$/.test(valor))) {
		etiqueta.className = "frm-label frm-message-error";
		entrada.className = "frm-input input-has-error";
		descrError.className = "frm-txt-message";
		correcto = 1
	} else {
		etiqueta.className = "frm-label";
		entrada.className = "frm-input";
		descrError.className = "frm-txt-message hide";
	}
	nombreValor = document.getElementById("id_nom_sim").value;
	etiquetaNombre = document.getElementById("id_nom_sim_lab");
	entradaNombre = document.getElementById("id_nom_sim");
	descrErrorNombre = document.getElementById("id_nom_sim_error");

	if(nombreValor==""){

		etiquetaNombre.className = "frm-label frm-message-error";
		entradaNombre.className = "frm-input input-has-error";
		descrErrorNombre.className = "frm-txt-message";
		correcto = 1
	}else{
		etiquetaNombre.className = "frm-label";
		entradaNombre.className = "frm-input";
		descrErrorNombre.className = "frm-txt-message hide";
	}
	descrErrorCon = document.getElementById("id_desc_err_condSim");
	elemento = document.getElementById("id_cond_Sim");
	etiquetaCondi = document.getElementById("id_cond_Sim_lab");
	if (!elemento.checked) {
		etiquetaCondi.className = "frm-labelError";
		descrErrorCon.className = "frm-label frm-message-error";
		correcto = 1
	} else {
		descrErrorCon.className = "frm-label frm-message-error hide";
		etiquetaCondi.className = "frm-label";
	}

	if (typeof($('#telefonoContactabilidadSim').attr('data-valid')) == "undefined" || $('#telefonoContactabilidadSim').attr('data-valid') == 'false') {
		$(".mod_captchaTelSim").addClass('frm-message-error');
		correcto = 1;
	}
	error = document.getElementById("id_error_Sim");
	//enviadoTel = document.getElementById("enviado_tel_Sim");
	if (correcto == 0) {
		if(error !== null){
			error.className = "mod_message msg-error hide";
		}
		//enviadoTel.value = "true";

		return true;
	} else {
		if(error !== null){
			error.className = "mod_message msg-error";
		}
		return false;
	}
}



function validacionCorreo() {

	valor = document.getElementById("id_cor").value;
	etiqueta = document.getElementById("id_cor_lab");
	entrada = document.getElementById("id_cor");
	descrError = document.getElementById("id_desc_err_cor");

	correcto = 0;
	segmentoActual = document.getElementById("segmentoActual").value;


	if(segmentoActual=="particulares" || segmentoActual=="banca privada" || segmentoActual=="banca personal"){

		nombreValor = document.getElementById("id_nom2").value;
		etiquetaNombre = document.getElementById("id_nom2_lab");
		entradaNombre = document.getElementById("id_nom2");
		descrErrorNombre = document.getElementById("id_desc_err_nombre2");

		if(nombreValor==""){
			etiquetaNombre.className = "frm-label frm-message-error";
			entradaNombre.className = "frm-input input-has-error";
			descrErrorNombre.className = "frm-txt-message";
			correcto = 1
		}else{
			etiquetaNombre.className = "frm-label";
			entradaNombre.className = "frm-input";
			descrErrorNombre.className = "frm-txt-message hide";
		}
	}if(segmentoActual=="empresas" || segmentoActual=="pymes y autonomos" ){


		nombreEmpleadoValor = document.getElementById("id_nomemp2").value;
		etiquetaNombreEmpleado = document.getElementById("id_nomemp2_lab");
		entradaNombreEmpleado = document.getElementById("id_nomemp2");
		descrErrorNombreEmpleado = document.getElementById("id_desc_err_nombemp2");

		if(nombreEmpleadoValor==""){

			etiquetaNombreEmpleado.className = "frm-label frm-message-error";
			entradaNombreEmpleado.className = "frm-input input-has-error";
			descrErrorNombreEmpleado.className = "frm-txt-message";
			correcto = 1
		}else{
			etiquetaNombreEmpleado.className = "frm-label";
			entradaNombreEmpleado.className = "frm-input";
			descrErrorNombreEmpleado.className = "frm-txt-message hide";
		}
		perContacValor = document.getElementById("id_nomper2").value;
		etiquetaPerContac = document.getElementById("id_nomper2_lab");
		entradaPerContac = document.getElementById("id_nomper2");
		descrErrorPerContac = document.getElementById("id_desc_err_perContac2");

		if(perContacValor==""){

			etiquetaPerContac.className = "frm-label frm-message-error";
			entradaPerContac.className = "frm-input input-has-error";
			descrErrorPerContac.className = "frm-txt-message";
			correcto = 1
		}else{
			etiquetaPerContac.className = "frm-label";
			entradaPerContac.className = "frm-input";
			descrErrorPerContac.className = "frm-txt-message hide";
		}

		if(segmentoActual=="empresas"){
			cifValor = document.getElementById("id_cif2").value;
			etiquetaCif = document.getElementById("id_cif2_lab");
			entradaCif = document.getElementById("id_cif2");
			descrErrorCif = document.getElementById("id_desc_err_cif2");

			if(cifValor==""){

				etiquetaCif.className = "frm-label frm-message-error";
				entradaCif.className = "frm-input input-has-error";
				descrErrorCif.className = "frm-txt-message";
				correcto = 1
			}else{
				etiquetaCif.className = "frm-label";
				entradaCif.className = "frm-input";
				descrErrorCif.className = "frm-txt-message hide";
			}


		}


	} 


	if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/.test(valor))) {
		etiqueta.className = "frm-label frm-message-error";
		entrada.className = "frm-input input-has-error";
		descrError.className = "frm-txt-message";
		correcto = 1
	} else {
		etiqueta.className = "frm-label";
		entrada.className = "frm-input";
		descrError.className = "frm-txt-message hide";
	}
	consultaValor = document.getElementById("id_con").value;
	etiquetaConsulta = document.getElementById("id_con_lab");
	entradaConsulta = document.getElementById("id_con");
	descrErrorConsulta = document.getElementById("id_desc_err_consulta");

	if(consultaValor==""){

		etiquetaConsulta.className = "frm-label frm-message-error";

		entradaConsulta.className = "frm-textarea textarea-has-error";

		descrErrorConsulta.className = "frm-txt-message";

		correcto = 1
	}else{
		etiquetaConsulta.className = "frm-label";
		entradaConsulta.className = "frm-textarea";
		descrErrorConsulta.className = "frm-txt-message hide";
	}

	etiquetaCondi = document.getElementById("id_condi2_lab");
	descrErrorCon = document.getElementById("id_desc_err_cor_con");
	elemento = document.getElementById("id_condi2");
	if (!elemento.checked) {
		etiquetaCondi.className = "frm-labelError";
		descrErrorCon.className = "frm-label frm-message-error";
		correcto = 1
	} else {
		descrErrorCon.className = "frm-label frm-message-error hide";
		etiquetaCondi.className = "frm-label";
	}

	if ($('#coreoContactabilidad').attr('data-valid') == 'false') {
		$(".mod_captchaCorr").addClass('frm-message-error');
		correcto = 1;
	}


	error = document.getElementById("id_error_cor");
	enviado = document.getElementById("enviado");
	if (correcto == 0) {
		if(error !== null){
			error.className = "mod_message msg-error hide";
		}
		enviado.value = "true";

		return true;
	} else {
		if(error !== null){
			error.className = "mod_message msg-error";
		}
		return false;
	}
}

function validacionCorreoTablet() {

	valor = document.getElementById("id_cor_tablet").value;
	etiqueta = document.getElementById("id_cor_lab_tablet");
	entrada = document.getElementById("id_cor_tablet");
	descrError = document.getElementById("id_desc_err_cor_tablet");
	correcto = 0;
	segmentoActual = document.getElementById("segmentoActual").value;


	if(segmentoActual=="particulares" || segmentoActual=="banca privada" || segmentoActual=="banca personal"){

		nombreValor = document.getElementById("id_nom2_tablet").value;
		etiquetaNombre = document.getElementById("id_nom2_lab_tablet");
		entradaNombre = document.getElementById("id_nom2_tablet");
		descrErrorNombre = document.getElementById("id_desc_err_nombre2_tablet");

		if(nombreValor==""){

			etiquetaNombre.className = "frm-label frm-message-error";
			entradaNombre.className = "frm-input input-has-error";
			descrErrorNombre.className = "frm-txt-message";
			correcto = 1

		}else{
			etiquetaNombre.className = "frm-label";
			entradaNombre.className = "frm-input";
			descrErrorNombre.className = "frm-txt-message hide";
		}
	}if(segmentoActual=="empresas" || segmentoActual=="pymes y autonomos" ){


		nombreEmpleadoValor = document.getElementById("id_nomemp2_tablet").value;
		etiquetaNombreEmpleado = document.getElementById("id_nomemp2_lab_tablet");
		entradaNombreEmpleado = document.getElementById("id_nomemp2_tablet");
		descrErrorNombreEmpleado = document.getElementById("id_desc_err_nombemp2_tablet");

		if(nombreEmpleadoValor==""){

			etiquetaNombreEmpleado.className = "frm-label frm-message-error";
			entradaNombreEmpleado.className = "frm-input input-has-error";
			descrErrorNombreEmpleado.className = "frm-txt-message";
			correcto = 1
		}else{
			etiquetaNombreEmpleado.className = "frm-label";
			entradaNombreEmpleado.className = "frm-input";
			descrErrorNombreEmpleado.className = "frm-txt-message hide";
		}
		perContacValor = document.getElementById("id_nomper2_tablet").value;
		etiquetaPerContac = document.getElementById("id_nomper2_lab_tablet");
		entradaPerContac = document.getElementById("id_nomper2_tablet");
		descrErrorPerContac = document.getElementById("id_desc_err_perContac2_tablet");

		if(perContacValor==""){

			etiquetaPerContac.className = "frm-label frm-message-error";
			entradaPerContac.className = "frm-input input-has-error";
			descrErrorPerContac.className = "frm-txt-message";
			correcto = 1
		}else{
			etiquetaPerContac.className = "frm-label";
			entradaPerContac.className = "frm-input";
			descrErrorPerContac.className = "frm-txt-message hide";
		}

		if(segmentoActual=="empresas"){
			cifValor = document.getElementById("id_cif2_tablet").value;
			etiquetaCif = document.getElementById("id_cif2_lab_tablet");
			entradaCif = document.getElementById("id_cif2_tablet");
			descrErrorCif = document.getElementById("id_desc_err_cif2_tablet");

			if(cifValor==""){

				etiquetaCif.className = "frm-label frm-message-error";
				entradaCif.className = "frm-input input-has-error";
				descrErrorCif.className = "frm-txt-message";
				correcto = 1
			}else{
				etiquetaCif.className = "frm-label";
				entradaCif.className = "frm-input";
				descrErrorCif.className = "frm-txt-message hide";
			}


		}


	} 
	if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/.test(valor))) {
		etiqueta.className = "frm-label frm-message-error";
		entrada.className = "frm-input input-has-error";
		descrError.className = "frm-txt-message";
		correcto = 1
	} else {
		etiqueta.className = "frm-label";
		entrada.className = "frm-input";
		descrError.className = "frm-txt-message hide";
	}

	consultaValor = document.getElementById("id_con_tablet").value;
	etiquetaConsulta = document.getElementById("id_con_lab_tablet");
	entradaConsulta = document.getElementById("id_con_tablet");
	descrErrorConsulta = document.getElementById("id_desc_err_consulta_tablet");

	if(consultaValor==""){

		etiquetaConsulta.className = "frm-label frm-message-error";

		entradaConsulta.className = "frm-textarea textarea-has-error";

		descrErrorConsulta.className = "frm-txt-message";

		correcto = 1
	}else{
		etiquetaConsulta.className = "frm-label";
		entradaConsulta.className = "frm-textarea";
		descrErrorConsulta.className = "frm-txt-message hide";
	}
	etiquetaCondi = document.getElementById("id_condi2_lab_tablet");
	descrErrorCon = document.getElementById("id_desc_err_cor_con_tablet");
	elemento = document.getElementById("id_condi2_tablet");
	if (!elemento.checked) {
		etiquetaCondi.className = "frm-labelError";
		descrErrorCon.className = "frm-label frm-message-error";
		correcto = 1
	} else {
		descrErrorCon.className = "frm-label frm-message-error hide";
		etiquetaCondi.className = "frm-label";
	}

	if ($('#coreoContactabilidad_tablet').attr('data-valid') == 'false') {
		$(".captcha_tablet_corr").addClass('frm-message-error');
		correcto = 1;
	}


	error = document.getElementById("id_error_cor_tablet");
	enviado = document.getElementById("enviado_tablet");
	if (correcto == 0) {
		if(error !== null){
			error.className = "mod_message msg-error hide";
		}
		enviado.value = "true";

		return true;
	} else {
		if(error !== null){
			error.className = "mod_message msg-error";
		}
		return false;
	}
}

function validacionCorreoSubHome() {
	valor = document.getElementById("id_email_ctc_call").value;
	etiqueta = document.getElementById("id_email_ctc_email_lab");
	entrada = document.getElementById("id_email_ctc_call");
	descrError = document.getElementById("id_desc_err_corr");
	correcto = 0;
	if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/.test(valor))) {
		etiqueta.className = "frm-label frm-message-error";
		entrada.className = "frm-input input-has-error";
		descrError.className = "frm-txt-message";
		correcto = 1
	} else {
		etiqueta.className = "frm-label";
		entrada.className = "frm-input";
		descrError.className = "frm-txt-message hide";
	}
	consultaValor = document.getElementById("id_con").value;
	etiquetaConsulta = document.getElementById("id_con_lab");
	entradaConsulta = document.getElementById("id_con");
	descrErrorConsulta = document.getElementById("id_desc_err_con");

	if(consultaValor==""){

		etiquetaConsulta.className = "frm-label frm-message-error";
		entradaConsulta.className = "frm-input input-has-error";
		descrErrorConsulta.className = "frm-txt-message";
		correcto = 1
	}else{
		etiquetaConsulta.className = "frm-label";
		entradaConsulta.className = "frm-input";
		descrErrorConsulta.className = "frm-txt-message hide";
	}
	etiquetaCondi = document.getElementById("id_conditions_ctc_email_lab");
	descrErrorCon = document.getElementById("id_desc_err_corr_con");
	elemento = document.getElementById("id_conditions_ctc_email");
	if (!elemento.checked) {
		etiquetaCondi.className = "frm-labelError";
		descrErrorCon.className = "frm-label frm-message-error";
		correcto = 1
	} else {
		descrErrorCon.className = "frm-label frm-message-error hide";
		etiquetaCondi.className = "frm-label";
	}

	if (typeof($('#coreoContactabilidad').attr('data-valid')) == "undefined" || $('#coreoContactabilidad').attr('data-valid') == 'false') {
		$("#mod_captchaCorr").addClass('frm-message-error');
		correcto = 1;
	}

	error = document.getElementById("id_error_corr");
	enviado = document.getElementById("enviado_Corr");
	if (correcto == 0) {
		if(error !== null){
			error.className = "mod_message msg-error hide";
		}
		enviado.value = "true";

		return true;
	} else {
		if(error !== null){
			error.className = "mod_message msg-error";
		}
		return false;
	}
}

function validacionCorreoSolicitar() {
	valor = document.getElementById("id_corSol").value;
	etiqueta = document.getElementById("id_corSol_lab");
	entrada = document.getElementById("id_corSol");
	descrError = document.getElementById("id_desc_err_corSol");
	correcto = 0;
	segmentoActual = document.getElementById("segmentoActual").value;


	if(segmentoActual=="particulares" || segmentoActual=="banca privada" || segmentoActual=="banca personal"){

		nombreValor = document.getElementById("id_nomSol").value;
		etiquetaNombre = document.getElementById("id_nomSol_lab");
		entradaNombre = document.getElementById("id_nomSol");
		descrErrorNombre = document.getElementById("id_desc_err_nomSol");

		if(nombreValor==""){
			etiquetaNombre.className = "frm-label frm-message-error";
			entradaNombre.className = "frm-input input-has-error";
			descrErrorNombre.className = "frm-txt-message";
			correcto = 1
		}else{
			etiquetaNombre.className = "frm-label";
			entradaNombre.className = "frm-input";
			descrErrorNombre.className = "frm-txt-message hide";
		}
	}if(segmentoActual=="empresas" || segmentoActual=="pymes y autonomos" ){


		nombreEmpleadoValor = document.getElementById("id_nomempSol").value;
		etiquetaNombreEmpleado = document.getElementById("id_nomempSol_lab");
		entradaNombreEmpleado = document.getElementById("id_nomempSol");
		descrErrorNombreEmpleado = document.getElementById("id_desc_err_nomempSol");

		if(nombreEmpleadoValor==""){

			etiquetaNombreEmpleado.className = "frm-label frm-message-error";
			entradaNombreEmpleado.className = "frm-input input-has-error";
			descrErrorNombreEmpleado.className = "frm-txt-message";
			correcto = 1
		}else{
			etiquetaNombreEmpleado.className = "frm-label";
			entradaNombreEmpleado.className = "frm-input";
			descrErrorNombreEmpleado.className = "frm-txt-message hide";
		}
		perContacValor = document.getElementById("id_nomSol").value;
		etiquetaPerContac = document.getElementById("id_nomSol_lab");
		entradaPerContac = document.getElementById("id_nomSol");
		descrErrorPerContac = document.getElementById("id_desc_err_nomSol");

		if(perContacValor==""){

			etiquetaPerContac.className = "frm-label frm-message-error";
			entradaPerContac.className = "frm-input input-has-error";
			descrErrorPerContac.className = "frm-txt-message";
			correcto = 1
		}else{
			etiquetaPerContac.className = "frm-label";
			entradaPerContac.className = "frm-input";
			descrErrorPerContac.className = "frm-txt-message hide";
		}

		if(segmentoActual=="empresas"){
			cifValor = document.getElementById("id_cifSol").value;
			etiquetaCif = document.getElementById("id_cifSol_lab");
			entradaCif = document.getElementById("id_cifSol");
			descrErrorCif = document.getElementById("id_desc_err_cifSol");

			if(cifValor==""){

				etiquetaCif.className = "frm-label frm-message-error";
				entradaCif.className = "frm-input input-has-error";
				descrErrorCif.className = "frm-txt-message";
				correcto = 1
			}else{
				etiquetaCif.className = "frm-label";
				entradaCif.className = "frm-input";
				descrErrorCif.className = "frm-txt-message hide";
			}


		}


	} 

	if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/.test(valor))) {
		etiqueta.className = "frm-label frm-message-error";
		entrada.className = "frm-input input-has-error";
		descrError.className = "frm-txt-message";
		correcto = 1
	} else {
		etiqueta.className = "frm-label";
		entrada.className = "frm-input";
		descrError.className = "frm-txt-message hide";
	}
	consultaValor = document.getElementById("id_consultaSol").value;
	etiquetaConsulta = document.getElementById("id_consultaSol_lab");
	entradaConsulta = document.getElementById("id_consultaSol");
	descrErrorConsulta = document.getElementById("id_desc_err_consultaSol");

	if(consultaValor==""){

		etiquetaConsulta.className = "frm-label frm-message-error";

		entradaConsulta.className = "frm-textarea textarea-has-error";

		descrErrorConsulta.className = "frm-txt-message";

		correcto = 1
	}else{
		etiquetaConsulta.className = "frm-label";
		entradaConsulta.className = "frm-textarea";
		descrErrorConsulta.className = "frm-txt-message hide";
	}
	etiquetaCondi = document.getElementById("id_condiSol2_lab");
	descrErrorCon = document.getElementById("id_desc_err_corSol_con");
	elemento = document.getElementById("id_condiSol2");
	if (!elemento.checked) {
		etiquetaCondi.className = "frm-labelError";
		descrErrorCon.className = "frm-label frm-message-error";
		correcto = 1
	} else {
		descrErrorCon.className = "frm-label frm-message-error hide";
		etiquetaCondi.className = "frm-label";
	}


	if (typeof($('#correoContactabilidadSol').attr('data-valid')) == "undefined" || $('#correoContactabilidadSol').attr('data-valid') == 'false') {
		$("#captchaSol").addClass('frm-message-error');
		correcto = 1;
	}


	error = document.getElementById("id_error_corSol");
	enviado = document.getElementById("enviadoSol");
	if (correcto == 0) {
		if(error !== null){
			error.className = "mod_message msg-error hide";
		}
		enviado.value = "true";

		return true;
	} else {
		if(error !== null){
			error.className = "mod_message msg-error";
		}
		return false;
	}
}



function validarFormatoFecha(campo) {
	var RegExPattern = /^\d{1,2}\/\d{1,2}\/\d{2,4}$/;
	if ((campo.match(RegExPattern)) && (campo != '')) {
		return true;
	} else {
		return false;
	}
}

function existeFecha(fecha) {
	var fechaf = fecha.split("/");
	var d = fechaf[0];
	var m = fechaf[1];
	var y = fechaf[2];
	return m > 0 && m < 13 && y > 0 && y < 32768 && d > 0
	&& d <= (new Date(y, m, 0)).getDate();
}

function validarFecha(fecha) {
	if (validarFormatoFecha(fecha)) {
		if (existeFecha(fecha)) {
			return true;
		} else {
			return false;
		}
	} else {
		return false;
	}
}

function visualizarRentabilidad(clase) {
	if (!jQuery(clase).hasClass('active')) {
		jQuery('.graficoRentabilidadAnual').toggleClass('hide');
		jQuery('.graficoRentabilidadMensual').toggleClass('hide');
		jQuery('.tab-rent-anual').toggleClass('active');
		jQuery('.tab-rent-mensual').toggleClass('active');
	}
}
function ocultarRentabilidad(clase) {
	jQuery(clase).toggleClass('hide');
}
function ocultarRentabilidad2(clase) {
	jQuery('.ocultar-rentabilidad2').toggleClass('hide');
}
function buscadorOficinas() {
	document.getElementById("frmBuscador").submit();
}

function ocultarCargando() {
	saveMessage = document.getElementById("hddEntrar").value;
	return saveMessage;
};

function mostrarCargando(mensaje) {
	saveMessage = mensaje || "Validando datos...";
	return saveMessage;
};

function pulsarBotonLogin() {
	initLoadingLogin.initLoginButton("[data-function='fc-buttonLogin']")
}

function showErrorField(etiqueta, entrada, descrError) {
	etiqueta.className = "frm-label frm-message-error";
	entrada.className = "frm-input input-has-error";
	descrError.className = "frm-txt-message";
}

function showErrorFieldPass(etiqueta, entrada, descrError) {
	etiqueta.className = "frm-label frm-message-error";
	entrada.className = "frm-input fc-openTecladoVirtualIframe input-has-error";
	descrError.className = "frm-txt-message";
}

function hideErrorField(etiqueta, entrada, descrError) {
	etiqueta.className = "frm-label";
	entrada.className = "frm-input";
	descrError.className = "frm-txt-message hide";
}

function hideErrorFieldPass(etiqueta, entrada, descrError) {
	etiqueta.className = "frm-label";
	entrada.className = "frm-input fc-openTecladoVirtualIframe";
	descrError.className = "frm-txt-message hide";
}

function valCampo(valor, etiqueta, entrada, descrError, isPass) {
	correcto = 0;
	if ($.trim(valor) == "") {
		if (isPass) {
			showErrorFieldPass(etiqueta, entrada, descrError);
		} else {
			showErrorField(etiqueta, entrada, descrError);
		}
		correcto = 1
	} else {
		if (isPass) {
			hideErrorFieldPass(etiqueta, entrada, descrError);
		} else {
			hideErrorField(etiqueta, entrada, descrError);
		}
	}
	return correcto;
}

function validarCampos(from) {

	if(from == "cabecera"){
		valor = document.getElementById("txtlogin").value;
		etiqueta = document.getElementById("id_usu_login");
		entrada = document.getElementById("txtlogin");
		descrError = document.getElementById("id_desc_err_usu");
	}else{
		valor = document.getElementById("txtloginG").value;
		etiqueta = document.getElementById("id_usu_loginG");
		entrada = document.getElementById("txtloginG");
		descrError = document.getElementById("id_desc_err_usuG");
	}

	valor = valor.replace(/[^0-9]/g, '');

	if(from == "cabecera"){
		document.getElementById("txtlogin").value = valor;
	}else{
		document.getElementById("txtloginG").value = valor;
	}

	var valUsu = valCampo(valor, etiqueta, entrada, descrError, false);

	if(from == "cabecera"){
		valor = document.getElementById("password").value;
		etiqueta = document.getElementById("id_acc_login");
		entrada = document.getElementById("password");
		descrError = document.getElementById("id_desc_err_pass");
	}else{
		valor = document.getElementById("passwordG").value;
		etiqueta = document.getElementById("id_acc_loginG");
		entrada = document.getElementById("passwordG");
		descrError = document.getElementById("id_desc_err_passG");
	}

	var valPass = valCampo(valor, etiqueta, entrada, descrError, true);

	if (valPass == 0 && $.trim(valor).length < 4) {
		showErrorField(etiqueta, entrada, descrError);
		valPass = 1;
	}

	if (valUsu == 0 && valPass == 0) {
		return true;
	} else {
		return false;
	}
}

function showErrorMessajeValidando(from) {
	if(from == "cabecera"){
		document.getElementById("messageValidando").className = "mod_message msg-error";
		$("#messageValidando").show();
	}else{
		document.getElementById("messageValidandoG").className = "mod_message msg-error";
		$("#messageValidandoG").show();
	}

	// Calcula el alto de la parte del formulario login para darselo al iframe.
	if ($(".mod_loginPage").length > 0) {
		var heightIframe = $(".mod_loginPage").parents("html").innerHeight();

		if (typeof (top.changeHeightTabs) != "undefined") {
			top.changeHeightTabs(heightIframe + 2);
		}
	} else {
		var heightIframe = $(".mod_login").innerHeight();

		if (typeof (top.changeHeight) != "undefined") {
			top.changeHeight(heightIframe + 2);
		}
	}
}

function ocultarError(from) {
	if(from == "cabecera"){
		document.getElementById("messageValidando").className = "mod_message msg-error hide";
	}else{
		document.getElementById("messageValidandoG").className = "mod_message msg-error hide";
	}
}

function getIdentificador() {
	return document.getElementById("txtlogin").value;
}

function getClave() {
	return document.getElementById("password").value;
}

function srcIframeLoginG(lenguaje, urlIframe){

	if (lenguaje != 'es'){
		urlIframe = urlIframe.replace("/es/", "/" + lenguaje + "/");
	}
	var urlParameters = location.search.toString();
	if (urlParameters.indexOf("?") >= 0){
		var arrParams = urlParameters.split("?");

		if (urlIframe.indexOf("?") >= 0){
			document.getElementById("login-iframeG").src = urlIframe + "&" + arrParams[1];
		}else{
			document.getElementById("login-iframeG").src = urlIframe + "?" + arrParams[1];
		}

	}else{
		document.getElementById("login-iframeG").src = urlIframe;
	}	
}

function pintarDonut()
{
	var groupDonut = $("[data-function='fc-sliderDonut']");
	groupDonut.each(function(){
		var num = parseInt($(this).attr("data-slider"));
		var nameFirst = $(this).attr("data-sliderfirst");
		var nameSecond = $(this).attr("data-slidersecond");
		var sliderFirst = $("#"+nameFirst);
		var sliderSecond = $("#"+nameSecond);
		var meses = $(this).attr("data-count");
		if(num==1){
			initSliderDonut.calculateCircleSpinner(minimo,maximo, sliderFirst);
		}else if(num==2){
			initSliderDonut.cuenta(sliderFirst,sliderSecond,meses);
		}
	});
}

function modalVideoLanding(){
	var contentId = $("#contentId").val();
	var URLFormatear = "/portalunico/portalunico/displayviews/banner/videoLanding.jsp" + "?contentId=" + contentId;
	jQuery.ajax({
		url: encodeURI(URLFormatear),
		context: document.body,
		data: {},
		success: function(data, textStatus )     
		{        
			jQuery('#bannerVideoLanding').html(data);

			$(".landingPlayVideo").on('hide.bs.modal', function(e) {
				resetLandingPlayVideo();
			});
		},
		error: function(xhr, textStatus, errorThrown){         

		}

	});
	return false;
}

function contactLanding(){

	//nuevaContactabilidad

	var nuevaContactabilidadCerrar = $("#nuevaContactabilidadCerrar").val();
	var nuevaContactabilidadTeAyudamos = $("#nuevaContactabilidadTeAyudamos").val();
	var nuevaContactabilidadNumeroTelefonoParticulares = $("#nuevaContactabilidadNumeroTelefonoPrestamo").val();
	var nuevaContactabilidadNumeroTelefonoPymes = $("#nuevaContactabilidadNumeroTelefonoPension").val();
	var nuevaContactabilidadNumeroTelefonoPersonal = $("#nuevaContactabilidadNumeroTelefonoHipoteca").val();
	var nuevaContactabilidadAtencionTelefonica = $("#nuevaContactabilidadAtencionTelefonica").val();
	var nuevaContactabilidadTeLlamamos = $("#nuevaContactabilidadTeLlamamos").val();
	var nuevaContactabilidadErrorFormulario = $("#nuevaContactabilidadErrorFormulario").val();
	var nuevaContactabilidadAcceso = $("#nuevaContactabilidadAcceso").val();
	var nuevaContactabilidadNombre = $("#nuevaContactabilidadNombre").val();


	var nuevaContactabilidadTelefono = $("#nuevaContactabilidadTelefono").val();
	var nuevaContactabilidadFormatoTelefono = $("#nuevaContactabilidadFormatoTelefono").val();
	var nuevaContactabilidadTelefonoIncorrecto = $("#nuevaContactabilidadTelefonoIncorrecto").val();
	var nuevaContactabilidadSoyCliente = $("#nuevaContactabilidadSoyCliente").val();
	var nuevaContactabilidadHeLeido = $("#nuevaContactabilidadHeLeido").val();
	var nuevaContactabilidadErrorCondiciones = $("#nuevaContactabilidadErrorCondiciones").val();
	var captchaMover = $(".captchaMover").val();
	var captchaValidado = $(".captchaValidado").val();
	var nuevaContactabilidadSolicitarLlamada = $("#nuevaContactabilidadSolicitarLlamada").val();
	var nuevaContactabilidadEscribirMensaje = $("#nuevaContactabilidadEscribirMensaje").val();
	var nuevaContactabilidadRecibidaPeticion = $("#nuevaContactabilidadRecibidaPeticion").val();
	var nuevaContactabilidadNosPondremosEnContacto = $("#nuevaContactabilidadNosPondremosEnContacto").val();

	var contactabilidadNombreErrorVacio = $(".contactabilidadNombreErrorVacio").val();

	var landingTextoCondiciones = $("#landingTextoCondiciones").val();
	var landingRutaCondiciones = $("#landingRutaCondiciones").val();

	var segmentoLanding = $("#segmentoLanding").val();
	var familiaLanding = $("#familiaLanding").val();
	var subfamiliaLanding = $("#subfamiliaLanding").val();
	var paginaLanding = $("#paginaLanding").val();
	var espacioLanding = $("#espacioLanding").val();

	var inputPrioridad = $("#inputPrioridad").val();

	var hreflang = $(".hreflang").val();
	var URLFormatear = "/portalunico/contactabilidadLanding.jsp" + "?segmento=" + segmentoLanding + "&familia=" + familiaLanding + "&colectivo=" + subfamiliaLanding + "&pagina=" + paginaLanding + "&espacio=" + espacioLanding + "&nuevaContactabilidadNumeroTelefonoParticulares=" + nuevaContactabilidadNumeroTelefonoParticulares + "&nuevaContactabilidadNumeroTelefonoPymes=" + nuevaContactabilidadNumeroTelefonoPymes + "&nuevaContactabilidadNumeroTelefonoPersonal=" + nuevaContactabilidadNumeroTelefonoPersonal+ "&nuevaContactabilidadTeLlamamos=" + nuevaContactabilidadTeLlamamos + "&nuevaContactabilidadErrorFormulario=" + nuevaContactabilidadErrorFormulario + "&nuevaContactabilidadAcceso=" + nuevaContactabilidadAcceso + "&nuevaContactabilidadNombre=" + nuevaContactabilidadNombre + "&nuevaContactabilidadTelefono=" + nuevaContactabilidadTelefono + "&nuevaContactabilidadTelefonoIncorrecto=" + nuevaContactabilidadTelefonoIncorrecto + "&nuevaContactabilidadTelefonoIncorrecto=" + nuevaContactabilidadTelefonoIncorrecto + "&nuevaContactabilidadSolicitarLlamada=" + nuevaContactabilidadSolicitarLlamada + "&nuevaContactabilidadRecibidaPeticion=" + nuevaContactabilidadRecibidaPeticion + "&nuevaContactabilidadNosPondremosEnContacto=" + nuevaContactabilidadNosPondremosEnContacto + "&hreflang=" + hreflang;
	jQuery.ajax({
		url: encodeURI(URLFormatear), 
		context: document.body,
		data: {'nuevaContactabilidadCerrar':nuevaContactabilidadCerrar,'nuevaContactabilidadTeAyudamos':nuevaContactabilidadTeAyudamos, 'nuevaContactabilidadErrorCondiciones':nuevaContactabilidadErrorCondiciones, 'nuevaContactabilidadHeLeido':nuevaContactabilidadHeLeido, 'nuevaContactabilidadAtencionTelefonica':nuevaContactabilidadAtencionTelefonica, 'captchaValidado':captchaValidado, 'captchaMover':captchaMover, 'landingTextoCondiciones':landingTextoCondiciones, 'landingRutaCondiciones':landingRutaCondiciones, 'contactabilidadNombreErrorVacio':contactabilidadNombreErrorVacio, 'inputPrioridad' : inputPrioridad},
		success: function(data, textStatus)     
		{        
			jQuery('#contactLanding').html(data);
			modCaptcha.initCaptcha("[data-function='fc-captcha']");
			mod_focus.initEliminarFocus("a");
			mod_focus.initEliminarFocus(".ui-accordion-header");
			mod_focus.initEliminarFocus(".frm-checkbox");
			mod_focus.initEliminarFocus(".mod_buttons input.but-green[type='submit']");	

		},
		error: function(xhr, textStatus, errorThrown){         

		}

	});


	return false;
}

function contactLandingSimuladorHipotecas(){

	//nuevaContactabilidad

	var nuevaContactabilidadCerrar = $("#nuevaContactabilidadCerrar").val();
	var nuevaContactabilidadTeAyudamos = $("#nuevaContactabilidadTeAyudamos").val();
	var nuevaContactabilidadNumeroTelefonoParticulares = $("#nuevaContactabilidadNumeroTelefonoPrestamo").val();
	var nuevaContactabilidadNumeroTelefonoPymes = $("#nuevaContactabilidadNumeroTelefonoPension").val();
	var nuevaContactabilidadNumeroTelefonoPersonal = $("#nuevaContactabilidadNumeroTelefonoHipoteca").val();
	var nuevaContactabilidadAtencionTelefonica = $("#nuevaContactabilidadAtencionTelefonica").val();
	var nuevaContactabilidadTeLlamamos = $("#nuevaContactabilidadTeLlamamos").val();
	var nuevaContactabilidadErrorFormulario = $("#nuevaContactabilidadErrorFormulario").val();
	var nuevaContactabilidadAcceso = $("#nuevaContactabilidadAcceso").val();
	var nuevaContactabilidadNombre = $("#nuevaContactabilidadNombre").val();


	var nuevaContactabilidadTelefono = $("#nuevaContactabilidadTelefono").val();
	var nuevaContactabilidadFormatoTelefono = $("#nuevaContactabilidadFormatoTelefono").val();
	var nuevaContactabilidadTelefonoIncorrecto = $("#nuevaContactabilidadTelefonoIncorrecto").val();
	var nuevaContactabilidadSoyCliente = $("#nuevaContactabilidadSoyCliente").val();
	var nuevaContactabilidadHeLeido = $("#nuevaContactabilidadHeLeido").val();
	var nuevaContactabilidadErrorCondiciones = $("#nuevaContactabilidadErrorCondiciones").val();
	var captchaMover = $(".captchaMover").val();
	var captchaValidado = $(".captchaValidado").val();
	var nuevaContactabilidadSolicitarLlamada = $("#nuevaContactabilidadSolicitarLlamada").val();
	var nuevaContactabilidadEscribirMensaje = $("#nuevaContactabilidadEscribirMensaje").val();
	var nuevaContactabilidadRecibidaPeticion = $("#nuevaContactabilidadRecibidaPeticion").val();
	var nuevaContactabilidadNosPondremosEnContacto = $("#nuevaContactabilidadNosPondremosEnContacto").val();

	var contactabilidadNombreErrorVacio = $(".contactabilidadNombreErrorVacio").val();

	var landingTextoCondiciones = $("#landingTextoCondiciones").val();
	var landingRutaCondiciones = $("#landingRutaCondiciones").val();

	var segmentoLanding = $("#segmento").val();
	var familiaLanding = $("#familia").val();
	var subfamiliaLanding = $("#colectivo").val();
	var paginaLanding = $("#pagina").val();
	var espacioLanding = $("#espacio").val();

	var inputPrioridad = $("#inputPrioridad").val();

	var hreflang = $(".hreflang").val();
	var URLFormatear = "/portalunico/contactabilidadLanding.jsp" + "?segmento=" + segmentoLanding + "&familia=" + familiaLanding + "&colectivo=" + subfamiliaLanding + "&pagina=" + paginaLanding + "&espacio=" + espacioLanding + "&nuevaContactabilidadNumeroTelefonoParticulares=" + nuevaContactabilidadNumeroTelefonoParticulares + "&nuevaContactabilidadNumeroTelefonoPymes=" + nuevaContactabilidadNumeroTelefonoPymes + "&nuevaContactabilidadNumeroTelefonoPersonal=" + nuevaContactabilidadNumeroTelefonoPersonal+ "&nuevaContactabilidadTeLlamamos=" + nuevaContactabilidadTeLlamamos + "&nuevaContactabilidadErrorFormulario=" + nuevaContactabilidadErrorFormulario + "&nuevaContactabilidadAcceso=" + nuevaContactabilidadAcceso + "&nuevaContactabilidadNombre=" + nuevaContactabilidadNombre + "&nuevaContactabilidadTelefono=" + nuevaContactabilidadTelefono + "&nuevaContactabilidadTelefonoIncorrecto=" + nuevaContactabilidadTelefonoIncorrecto + "&nuevaContactabilidadTelefonoIncorrecto=" + nuevaContactabilidadTelefonoIncorrecto + "&nuevaContactabilidadSolicitarLlamada=" + nuevaContactabilidadSolicitarLlamada + "&nuevaContactabilidadRecibidaPeticion=" + nuevaContactabilidadRecibidaPeticion + "&nuevaContactabilidadNosPondremosEnContacto=" + nuevaContactabilidadNosPondremosEnContacto + "&hreflang=" + hreflang;
	jQuery.ajax({
		url: encodeURI(URLFormatear), 
		context: document.body,
		data: {'nuevaContactabilidadCerrar':nuevaContactabilidadCerrar,'nuevaContactabilidadTeAyudamos':nuevaContactabilidadTeAyudamos, 'nuevaContactabilidadErrorCondiciones':nuevaContactabilidadErrorCondiciones, 'nuevaContactabilidadHeLeido':nuevaContactabilidadHeLeido, 'nuevaContactabilidadAtencionTelefonica':nuevaContactabilidadAtencionTelefonica, 'captchaValidado':captchaValidado, 'captchaMover':captchaMover, 'landingTextoCondiciones':landingTextoCondiciones, 'landingRutaCondiciones':landingRutaCondiciones, 'contactabilidadNombreErrorVacio':contactabilidadNombreErrorVacio, 'inputPrioridad' : inputPrioridad},
		success: function(data, textStatus)     
		{        
			jQuery('#contactLanding').html(data);
			modCaptcha.initCaptcha("[data-function='fc-captcha']");
			mod_focus.initEliminarFocus("a");
			mod_focus.initEliminarFocus(".ui-accordion-header");
			mod_focus.initEliminarFocus(".frm-checkbox");
			mod_focus.initEliminarFocus(".mod_buttons input.but-green[type='submit']");	

		},
		error: function(xhr, textStatus, errorThrown){         

		}

	});


	return false;
}

function solicitarPrestamo(){

	var valorTipoPrestamoCont = $("#tipoPrestamo").val();
	var valorCantidadPrestamoCont = $("#cantidad").val();
	var valorPlazoPrestamoCont = $("#plazo").val();
	var valorTituloPrestamoCont = $("#tituloPrestamo").val();
	var valorSegmentoPrestamoCont = $("#segmentoPrestamos").val();
	var valorFamiliaPrestamoCont = $("#familiaPrestamo").val();
	var valorColectivoPrestamoCont = $("#colectivoPrestamo").val();
	var valorIdTeAyudamos = $("#idTeAyudamos").val();
	var webPrivada = $("#webPrivada").val()
	//nuevaContactabilidad
	if(webPrivada=='true'){
		sendSolicitarPrestamo('simulador prestamo', 'Simulador', valorTipoPrestamoCont, valorCantidadPrestamoCont, valorPlazoPrestamoCont, valorTituloPrestamoCont, valorFamiliaPrestamoCont, valorColectivoPrestamoCont);
	}else{

		var nuevaContactabilidadCerrar = $("#nuevaContactabilidadCerrar").val();
		var nuevaContactabilidadTeAyudamos = $("#nuevaContactabilidadTeAyudamos").val();
		var nuevaContactabilidadNumeroTelefonoPrestamo = $("#nuevaContactabilidadNumeroTelefonoPrestamo").val();
		var nuevaContactabilidadNumeroTelefonoPension = $("#nuevaContactabilidadNumeroTelefonoPension").val();
		var nuevaContactabilidadNumeroTelefonoHipoteca = $("#nuevaContactabilidadNumeroTelefonoHipoteca").val();
		var nuevaContactabilidadAtencionTelefonica = $("#nuevaContactabilidadAtencionTelefonica").val();
		var nuevaContactabilidadTeLlamamos = $("#nuevaContactabilidadTeLlamamos").val();
		var nuevaContactabilidadErrorFormulario = $("#nuevaContactabilidadErrorFormulario").val();
		var nuevaContactabilidadAcceso = $("#nuevaContactabilidadAcceso").val();
		var nuevaContactabilidadNombre = $("#nuevaContactabilidadNombre").val();


		var nuevaContactabilidadTelefono = $("#nuevaContactabilidadTelefono").val();
		var nuevaContactabilidadFormatoTelefono = $("#nuevaContactabilidadFormatoTelefono").val();
		var nuevaContactabilidadTelefonoIncorrecto = $("#nuevaContactabilidadTelefonoIncorrecto").val();
		var nuevaContactabilidadSoyCliente = $("#nuevaContactabilidadSoyCliente").val();
		var nuevaContactabilidadHeLeido = $("#nuevaContactabilidadHeLeido").val();
		var nuevaContactabilidadErrorCondiciones = $("#nuevaContactabilidadErrorCondiciones").val();
		var captchaMover = $(".captchaMover").val();
		var captchaValidado = $(".captchaValidado").val();
		var nuevaContactabilidadSolicitarLlamada = $("#nuevaContactabilidadSolicitarLlamada").val();
		var nuevaContactabilidadEscribirMensaje = $("#nuevaContactabilidadEscribirMensaje").val();

		var nuevaContactabilidadCorreo = $("#nuevaContactabilidadCorreo").val();
		var nuevaContactabilidadFormatoCorreo = $("#nuevaContactabilidadFormatoCorreo").val();
		var nuevaContactabilidadErrorCorreo = $("#nuevaContactabilidadErrorCorreo").val();
		var nuevaContactabilidadMensaje = $("#nuevaContactabilidadMensaje").val();
		var nuevaContactabilidadEnviarMensaje = $("#nuevaContactabilidadEnviarMensaje").val();
		var nuevaContactabilidadRecibidaPeticion = $("#nuevaContactabilidadRecibidaPeticion").val();
		var nuevaContactabilidadNosPondremosEnContacto = $("#nuevaContactabilidadNosPondremosEnContacto").val();

		var contactabilidadNombreErrorVacio = $(".contactabilidadNombreErrorVacio").val();
		var contactabilidadConsultaErrorVacio = $(".contactabilidadConsultaErrorVacio").val();

		var hreflang = $(".hreflang").val();
		var prioridadPrestamo = $("#prioridadPrestamo").val();
		if($("#prioridadPrestamoAjax").val() != undefined){
			prioridadPrestamo = $("#prioridadPrestamoAjax").val();
		}
		var URLFormatear = "/portalunico/nuevaContactabilidad.jsp" + "?tipoContactabilidad=" + "p" + "&tipoPrestamo=" + valorTipoPrestamoCont + "&cantidad=" + valorCantidadPrestamoCont + "&plazo=" + valorPlazoPrestamoCont + "&tituloPrestamo=" + valorTituloPrestamoCont + "&segmentoPrestamo=" + valorSegmentoPrestamoCont + "&familiaPrestamo=" + valorFamiliaPrestamoCont  + "&colectivoPrestamo=" + valorColectivoPrestamoCont + "&idTeAyudamos=" + valorIdTeAyudamos;
		jQuery.ajax({
			url: encodeURI(URLFormatear),
			context: document.body,
			data: {'nuevaContactabilidadCerrar':nuevaContactabilidadCerrar, 'nuevaContactabilidadTeAyudamos':nuevaContactabilidadTeAyudamos, 'nuevaContactabilidadNumeroTelefonoPrestamo':nuevaContactabilidadNumeroTelefonoPrestamo, 'nuevaContactabilidadNumeroTelefonoPension':nuevaContactabilidadNumeroTelefonoPension, 'nuevaContactabilidadNumeroTelefonoHipoteca':nuevaContactabilidadNumeroTelefonoHipoteca, 'nuevaContactabilidadAtencionTelefonica':nuevaContactabilidadAtencionTelefonica, 'nuevaContactabilidadTeLlamamos':nuevaContactabilidadTeLlamamos, 'nuevaContactabilidadErrorFormulario':nuevaContactabilidadErrorFormulario, 'nuevaContactabilidadAcceso':nuevaContactabilidadAcceso, 'nuevaContactabilidadNombre':nuevaContactabilidadNombre,
				'nuevaContactabilidadTelefono':nuevaContactabilidadTelefono, 'nuevaContactabilidadFormatoTelefono':nuevaContactabilidadFormatoTelefono, 'nuevaContactabilidadTelefonoIncorrecto':nuevaContactabilidadTelefonoIncorrecto, 'nuevaContactabilidadSoyCliente':nuevaContactabilidadSoyCliente, 'nuevaContactabilidadHeLeido':nuevaContactabilidadHeLeido, 'nuevaContactabilidadErrorCondiciones':nuevaContactabilidadErrorCondiciones, 'captchaMover':captchaMover, 'captchaValidado':captchaValidado, 'nuevaContactabilidadSolicitarLlamada':nuevaContactabilidadSolicitarLlamada, 'nuevaContactabilidadEscribirMensaje':nuevaContactabilidadEscribirMensaje,
				'nuevaContactabilidadCorreo':nuevaContactabilidadCorreo, 'nuevaContactabilidadFormatoCorreo':nuevaContactabilidadFormatoCorreo, 'nuevaContactabilidadErrorCorreo':nuevaContactabilidadErrorCorreo, 'nuevaContactabilidadMensaje':nuevaContactabilidadMensaje, 'nuevaContactabilidadEnviarMensaje':nuevaContactabilidadEnviarMensaje, 'nuevaContactabilidadRecibidaPeticion':nuevaContactabilidadRecibidaPeticion, 'nuevaContactabilidadNosPondremosEnContacto':nuevaContactabilidadNosPondremosEnContacto,'hreflang': hreflang,
				'contactabilidadNombreErrorVacio':contactabilidadNombreErrorVacio,'contactabilidadConsultaErrorVacio':contactabilidadConsultaErrorVacio, 'prioridadPrestamo':prioridadPrestamo 
			},
			success: function(data, textStatus)     
			{        
				jQuery('#nuevaContactabilidad').html(data);
				modCaptcha.initCaptcha("[data-function='fc-captcha']");
				mod_focus.initEliminarFocus("a");
				mod_focus.initEliminarFocus(".ui-accordion-header");
				mod_focus.initEliminarFocus(".frm-checkbox");
				mod_focus.initEliminarFocus(".mod_buttons input.but-green[type='submit']");	

				paso3Simulador();
			},
			error: function(xhr, textStatus, errorThrown){         
				$('#textoModalGenerico').removeClass('hidden');
				$('#textoModalEspecifico').addClass('hidden');
				$("#modalError").modal();
				setScrollModalIframe("#modalError");
			}

		});

	}
	return false;
}

function sendSolicitarPrestamo(simulador, espacio, finalidad, cantidad, plazo, producto, familia, subfamilia) {
	var entorno = $("#entornoOiPM").val();
	var cpp = $("#cpp").val();
	/*var valorFinalidad = finalidad;
  	if(finalidad == 'c'){
  		valorfinalidad = 'Coche nuevo';
  	}else if(finalidad == 'r'){
  		valorfinalidad = 'Reforma vivienda';
  	}else if(finalidad == 'o'){
  		valorfinalidad = 'Otros fines';
  	}*/

	var provider = new ChannelProvider();
	provider.addTrustedOrigins(entorno);
	var channel = provider.$get(window);
	var SCOPE =  'simuladores';
	var message = { 
			action:'SOLICITAR',
			data:{
				'simulador':simulador,'espacio':espacio,'finalidad':finalidad,'cantidad':cantidad,'cantidad':cantidad, 'plazo':plazo, 'producto':producto, 'cpp':cpp, 'familia':familia, 'subfamilia':subfamilia
			}
	};  
	channel.transmit(window.parent, SCOPE, message);
}

function solicitarPensiones(tituloPension, prioridad){

	var valorIdTeAyudamosPensiones = $("#idTeAyudamos").val();
	var valorTipoPension = $("#tipoEnvioAjax").val();
	var valorSegmentoPensionCont = $("#segmentoPensiones").val();
	var valorFamiliaPensionCont = $("#familiaPensiones").val();
	var valorColectivoPensionCont = $("#colectivoPensiones").val();
	var valorAhorrarMesPensionCont = $("#vivienda").val();
	var valorAhorradoPensionCont = $("#viviendaAhorro").val();
	var valorJubilacionAMPensionCont = $("#hipoteca").val();
	var valorJubilacionCAPensionCont = $("#hipotecaAhorro").val();
	var valorIngresosPensionCont = $("#ingresosBrutosAjax").val();
	var valorOtrosAhorrosPensionCont = $("#otrosAhorrosAjax").val();
	var titulo = tituloPension;
	var prioridad = prioridad;

	//nuevaContactabilidad


	var nuevaContactabilidadCerrar = $("#nuevaContactabilidadCerrar").val();
	var nuevaContactabilidadTeAyudamos = $("#nuevaContactabilidadTeAyudamos").val();
	var nuevaContactabilidadNumeroTelefonoPrestamo = $("#nuevaContactabilidadNumeroTelefonoPrestamo").val();
	var nuevaContactabilidadNumeroTelefonoPension = $("#nuevaContactabilidadNumeroTelefonoPension").val();
	var nuevaContactabilidadNumeroTelefonoHipoteca = $("#nuevaContactabilidadNumeroTelefonoHipoteca").val();
	var nuevaContactabilidadAtencionTelefonica = $("#nuevaContactabilidadAtencionTelefonica").val();
	var nuevaContactabilidadTeLlamamos = $("#nuevaContactabilidadTeLlamamos").val();
	var nuevaContactabilidadErrorFormulario = $("#nuevaContactabilidadErrorFormulario").val();
	var nuevaContactabilidadAcceso = $("#nuevaContactabilidadAcceso").val();
	var nuevaContactabilidadNombre = $("#nuevaContactabilidadNombre").val();


	var nuevaContactabilidadTelefono = $("#nuevaContactabilidadTelefono").val();
	var nuevaContactabilidadFormatoTelefono = $("#nuevaContactabilidadFormatoTelefono").val();
	var nuevaContactabilidadTelefonoIncorrecto = $("#nuevaContactabilidadTelefonoIncorrecto").val();
	var nuevaContactabilidadSoyCliente = $("#nuevaContactabilidadSoyCliente").val();
	var nuevaContactabilidadHeLeido = $("#nuevaContactabilidadHeLeido").val();
	var nuevaContactabilidadErrorCondiciones = $("#nuevaContactabilidadErrorCondiciones").val();
	var captchaMover = $(".captchaMover").val();
	var captchaValidado = $(".captchaValidado").val();
	var nuevaContactabilidadSolicitarLlamada = $("#nuevaContactabilidadSolicitarLlamada").val();
	var nuevaContactabilidadEscribirMensaje = $("#nuevaContactabilidadEscribirMensaje").val();

	var nuevaContactabilidadCorreo = $("#nuevaContactabilidadCorreo").val();
	var nuevaContactabilidadFormatoCorreo = $("#nuevaContactabilidadFormatoCorreo").val();
	var nuevaContactabilidadErrorCorreo = $("#nuevaContactabilidadErrorCorreo").val();
	var nuevaContactabilidadMensaje = $("#nuevaContactabilidadMensaje").val();
	var nuevaContactabilidadEnviarMensaje = $("#nuevaContactabilidadEnviarMensaje").val();
	var nuevaContactabilidadRecibidaPeticion = $("#nuevaContactabilidadRecibidaPeticion").val();
	var nuevaContactabilidadNosPondremosEnContacto = $("#nuevaContactabilidadNosPondremosEnContacto").val();

	var contactabilidadNombreErrorVacio = $(".contactabilidadNombreErrorVacio").val();
	var contactabilidadConsultaErrorVacio = $(".contactabilidadConsultaErrorVacio").val();

	var hreflang = $(".hreflang").val();
	var URLFormatear = "/portalunico/nuevaContactabilidad.jsp" + "?tipoContactabilidad=" + "pp" + "&idTeAyudamos=" + valorIdTeAyudamosPensiones + "&tipoPension=" + valorTipoPension + "&segmentoPension=" + valorSegmentoPensionCont  + "&familiaPension=" + valorFamiliaPensionCont + "&colectivoPension=" + valorColectivoPensionCont + "&ahorroMes=" + valorAhorrarMesPensionCont + "&ahorrado=" + valorAhorradoPensionCont + "&jubilacionAM=" + valorJubilacionAMPensionCont + "&jubilacionCA=" + valorJubilacionCAPensionCont + "&ingresosBrutos=" + valorIngresosPensionCont  + "&otrosAhorros=" + valorOtrosAhorrosPensionCont + "&titulo=" + titulo;
	jQuery.ajax({
		url: encodeURI(URLFormatear),
		context: document.body,
		data: {'nuevaContactabilidadCerrar':nuevaContactabilidadCerrar, 'nuevaContactabilidadTeAyudamos':nuevaContactabilidadTeAyudamos, 'nuevaContactabilidadNumeroTelefonoPrestamo':nuevaContactabilidadNumeroTelefonoPrestamo, 'nuevaContactabilidadNumeroTelefonoPension':nuevaContactabilidadNumeroTelefonoPension, 'nuevaContactabilidadNumeroTelefonoHipoteca':nuevaContactabilidadNumeroTelefonoHipoteca, 'nuevaContactabilidadAtencionTelefonica':nuevaContactabilidadAtencionTelefonica, 'nuevaContactabilidadTeLlamamos':nuevaContactabilidadTeLlamamos, 'nuevaContactabilidadErrorFormulario':nuevaContactabilidadErrorFormulario, 'nuevaContactabilidadAcceso':nuevaContactabilidadAcceso, 'nuevaContactabilidadNombre':nuevaContactabilidadNombre,
			'nuevaContactabilidadTelefono':nuevaContactabilidadTelefono, 'nuevaContactabilidadFormatoTelefono':nuevaContactabilidadFormatoTelefono, 'nuevaContactabilidadTelefonoIncorrecto':nuevaContactabilidadTelefonoIncorrecto, 'nuevaContactabilidadSoyCliente':nuevaContactabilidadSoyCliente, 'nuevaContactabilidadHeLeido':nuevaContactabilidadHeLeido, 'nuevaContactabilidadErrorCondiciones':nuevaContactabilidadErrorCondiciones, 'captchaMover':captchaMover, 'captchaValidado':captchaValidado, 'nuevaContactabilidadSolicitarLlamada':nuevaContactabilidadSolicitarLlamada, 'nuevaContactabilidadEscribirMensaje':nuevaContactabilidadEscribirMensaje,
			'nuevaContactabilidadCorreo':nuevaContactabilidadCorreo, 'nuevaContactabilidadFormatoCorreo':nuevaContactabilidadFormatoCorreo, 'nuevaContactabilidadErrorCorreo':nuevaContactabilidadErrorCorreo, 'nuevaContactabilidadMensaje':nuevaContactabilidadMensaje, 'nuevaContactabilidadEnviarMensaje':nuevaContactabilidadEnviarMensaje, 'nuevaContactabilidadRecibidaPeticion':nuevaContactabilidadRecibidaPeticion, 'nuevaContactabilidadNosPondremosEnContacto':nuevaContactabilidadNosPondremosEnContacto,'hreflang': hreflang,
			'contactabilidadNombreErrorVacio':contactabilidadNombreErrorVacio,'contactabilidadConsultaErrorVacio':contactabilidadConsultaErrorVacio,'prioridad':prioridad
		},
		success: function(data, textStatus )     
		{        
			jQuery('#nuevaContactabilidad').html(data);
			modCaptcha.initCaptcha("[data-function='fc-captcha']");
			mod_focus.initEliminarFocus("a");
			mod_focus.initEliminarFocus(".ui-accordion-header");
			mod_focus.initEliminarFocus(".frm-checkbox");
			mod_focus.initEliminarFocus(".mod_buttons input.but-green[type='submit']");

			paso3Simulador();
		},
		error: function(xhr, textStatus, errorThrown){         

		}

	});


	return false;
}



function solicitarHipoteca(tituloHipoteca, prioridadHipoteca, cpp){

	var valorIdTeAyudamosHipotecas = $("#idTeAyudamos").val();
	var valorTipoHipoteca = $("#privivienda").val();
	var valorViviendaHipoteca = "";
	if($("#inputValorVivienda").val() == undefined){
		valorViviendaHipoteca = $("#valorvivienda").val();
	}else{
		valorViviendaHipoteca = $("#inputValorVivienda").val();
	}
	var valorIngresosHipoteca = $("#ingresos").val();
	var valorGastosHipoteca = $("#gastos").val();
	var valorTipoInmuebleHipoteca = $("#tipoInmueble").val();
	var valorUbicacionHipoteca = $("#ubicacion").val();
	var valorCantidadHipoteca = "";
	var valorPlazoHipoteca = "";
	if($("#importe-hipotecaNecesitasPV").val() != undefined){
		valorCantidadHipoteca = $("#importe-hipotecaNecesitasPV").val();
	}else if($("#importe-hipotecaNecesitas").val() != undefined){
		valorCantidadHipoteca = $("#importe-hipotecaNecesitas").val();
	}else{
		valorCantidadHipoteca = $("#vivienda").val();
	}

	if($("#anios-hipotecaPV").val() != undefined){
		valorPlazoHipoteca = $("#anios-hipotecaPV").val();
	}else if($("#anios-hipoteca").val() != undefined){
		valorPlazoHipoteca = $("#anios-hipoteca").val();
	}else{
		valorPlazoHipoteca = $("#hipoteca").val();
	}
	var valorTituloHipoteca = tituloHipoteca;
	var valorPrioridadHipoteca = prioridadHipoteca;
	var segmentoHipoteca = $("#segmento").val();
	var familiaHipoteca = $("#familia").val();
	var colectivoHipoteca = $("#colectivo").val();
	var webPrivada = $("#webPrivada").val();
	var conocimientoPrecio = $("#conocimientoPrecio").val();
	if(webPrivada=='true'){
		sendSolicitarHipoteca('simulador hipoteca', 'Simulador', valorTipoHipoteca, valorViviendaHipoteca, valorIngresosHipoteca, valorGastosHipoteca, valorTipoInmuebleHipoteca, valorUbicacionHipoteca, valorCantidadHipoteca, valorPlazoHipoteca, valorTituloHipoteca, cpp, familiaHipoteca, colectivoHipoteca, conocimientoPrecio);
	}else{
		//nuevaContactabilidad


		var nuevaContactabilidadCerrar = $("#nuevaContactabilidadCerrar").val();
		var nuevaContactabilidadTeAyudamos = $("#nuevaContactabilidadTeAyudamos").val();
		var nuevaContactabilidadNumeroTelefonoPrestamo = $("#nuevaContactabilidadNumeroTelefonoPrestamo").val();
		var nuevaContactabilidadNumeroTelefonoPension = $("#nuevaContactabilidadNumeroTelefonoPension").val();
		var nuevaContactabilidadNumeroTelefonoHipoteca = $("#nuevaContactabilidadNumeroTelefonoHipoteca").val();
		var nuevaContactabilidadAtencionTelefonica = $("#nuevaContactabilidadAtencionTelefonica").val();
		var nuevaContactabilidadTeLlamamos = $("#nuevaContactabilidadTeLlamamos").val();
		var nuevaContactabilidadErrorFormulario = $("#nuevaContactabilidadErrorFormulario").val();
		var nuevaContactabilidadAcceso = $("#nuevaContactabilidadAcceso").val();
		var nuevaContactabilidadNombre = $("#nuevaContactabilidadNombre").val();


		var nuevaContactabilidadTelefono = $("#nuevaContactabilidadTelefono").val();
		var nuevaContactabilidadFormatoTelefono = $("#nuevaContactabilidadFormatoTelefono").val();
		var nuevaContactabilidadTelefonoIncorrecto = $("#nuevaContactabilidadTelefonoIncorrecto").val();
		var nuevaContactabilidadSoyCliente = $("#nuevaContactabilidadSoyCliente").val();
		var nuevaContactabilidadHeLeido = $("#nuevaContactabilidadHeLeido").val();
		var nuevaContactabilidadErrorCondiciones = $("#nuevaContactabilidadErrorCondiciones").val();
		var captchaMover = $(".captchaMover").val();
		var captchaValidado = $(".captchaValidado").val();
		var nuevaContactabilidadSolicitarLlamada = $("#nuevaContactabilidadSolicitarLlamada").val();
		var nuevaContactabilidadEscribirMensaje = $("#nuevaContactabilidadEscribirMensaje").val();

		var nuevaContactabilidadCorreo = $("#nuevaContactabilidadCorreo").val();
		var nuevaContactabilidadFormatoCorreo = $("#nuevaContactabilidadFormatoCorreo").val();
		var nuevaContactabilidadErrorCorreo = $("#nuevaContactabilidadErrorCorreo").val();
		var nuevaContactabilidadMensaje = $("#nuevaContactabilidadMensaje").val();
		var nuevaContactabilidadEnviarMensaje = $("#nuevaContactabilidadEnviarMensaje").val();
		var nuevaContactabilidadRecibidaPeticion = $("#nuevaContactabilidadRecibidaPeticion").val();
		var nuevaContactabilidadNosPondremosEnContacto = $("#nuevaContactabilidadNosPondremosEnContacto").val();

		var contactabilidadNombreErrorVacio = $(".contactabilidadNombreErrorVacio").val();
		var contactabilidadConsultaErrorVacio = $(".contactabilidadConsultaErrorVacio").val();

		var hreflang = $(".hreflang").val();
		var URLFormatear = "/portalunico/nuevaContactabilidad.jsp" + "?tipoContactabilidad=" + "h" + "&idTeAyudamos=" + valorIdTeAyudamosHipotecas + "&tipoHipoteca=" + valorTipoHipoteca + "&valorVivienda=" + valorViviendaHipoteca + "&ingresosHipoteca=" + valorIngresosHipoteca + "&gastosHipoteca=" + valorGastosHipoteca + "&tipoInmuebleHipoteca=" + valorTipoInmuebleHipoteca + "&ubicacionHipoteca=" + valorUbicacionHipoteca + "&cantidadHipoteca=" + valorCantidadHipoteca + "&plazoHipoteca=" + valorPlazoHipoteca + "&tituloHipoteca=" + valorTituloHipoteca + "&segmentoHipoteca=" + segmentoHipoteca + "&familiaHipoteca=" + familiaHipoteca + "&colectivoHipoteca=" + colectivoHipoteca + "&prioridadHipoteca=" + valorPrioridadHipoteca;
		jQuery.ajax({
			url: encodeURI(URLFormatear),
			context: document.body,
			data: {'nuevaContactabilidadCerrar':nuevaContactabilidadCerrar, 'nuevaContactabilidadTeAyudamos':nuevaContactabilidadTeAyudamos, 'nuevaContactabilidadNumeroTelefonoPrestamo':nuevaContactabilidadNumeroTelefonoPrestamo, 'nuevaContactabilidadNumeroTelefonoPension':nuevaContactabilidadNumeroTelefonoPension, 'nuevaContactabilidadNumeroTelefonoHipoteca':nuevaContactabilidadNumeroTelefonoHipoteca, 'nuevaContactabilidadAtencionTelefonica':nuevaContactabilidadAtencionTelefonica, 'nuevaContactabilidadTeLlamamos':nuevaContactabilidadTeLlamamos, 'nuevaContactabilidadErrorFormulario':nuevaContactabilidadErrorFormulario, 'nuevaContactabilidadAcceso':nuevaContactabilidadAcceso, 'nuevaContactabilidadNombre':nuevaContactabilidadNombre,
				'nuevaContactabilidadTelefono':nuevaContactabilidadTelefono, 'nuevaContactabilidadFormatoTelefono':nuevaContactabilidadFormatoTelefono, 'nuevaContactabilidadTelefonoIncorrecto':nuevaContactabilidadTelefonoIncorrecto, 'nuevaContactabilidadSoyCliente':nuevaContactabilidadSoyCliente, 'nuevaContactabilidadHeLeido':nuevaContactabilidadHeLeido, 'nuevaContactabilidadErrorCondiciones':nuevaContactabilidadErrorCondiciones, 'captchaMover':captchaMover, 'captchaValidado':captchaValidado, 'nuevaContactabilidadSolicitarLlamada':nuevaContactabilidadSolicitarLlamada, 'nuevaContactabilidadEscribirMensaje':nuevaContactabilidadEscribirMensaje,
				'nuevaContactabilidadCorreo':nuevaContactabilidadCorreo, 'nuevaContactabilidadFormatoCorreo':nuevaContactabilidadFormatoCorreo, 'nuevaContactabilidadErrorCorreo':nuevaContactabilidadErrorCorreo, 'nuevaContactabilidadMensaje':nuevaContactabilidadMensaje, 'nuevaContactabilidadEnviarMensaje':nuevaContactabilidadEnviarMensaje, 'nuevaContactabilidadRecibidaPeticion':nuevaContactabilidadRecibidaPeticion, 'nuevaContactabilidadNosPondremosEnContacto':nuevaContactabilidadNosPondremosEnContacto,'hreflang': hreflang,
				'contactabilidadNombreErrorVacio':contactabilidadNombreErrorVacio,'contactabilidadConsultaErrorVacio':contactabilidadConsultaErrorVacio
			},
			success: function(data, textStatus )     
			{        
				jQuery('#nuevaContactabilidad').html(data);
				modCaptcha.initCaptcha("[data-function='fc-captcha']");
				mod_focus.initEliminarFocus("a");
				mod_focus.initEliminarFocus(".ui-accordion-header");
				mod_focus.initEliminarFocus(".frm-checkbox");
				mod_focus.initEliminarFocus(".mod_buttons input.but-green[type='submit']");

				paso3Simulador();
			},
			error: function(xhr, textStatus, errorThrown){         

			}

		});

	}
	return false;
}

function sendSolicitarHipoteca(simulador, espacio, finalidad, valor, ingresos, gastos, tipoInmueble, ubicacion, cantidad, plazo, producto, cpp, familia, subfamilia, conocimientoPrecio) {
	var entorno = $("#entornoOiPM").val();
	/*if(finalidad=='1'){
		valorFinalidad='Primera vivienda';
	}else if(finalidad=='2'){
		valorFinalidad='Segunda vivienda';
	}
	if(tipoInmueble=='1'){
		valorTipoInmueble='Nuevo';
	}else if(tipoInmueble=='2'){
		valorTipoInmueble='Usado';
	}*/
	if(ubicacion=='1'){
		valorUbicacion='Álava';
	}else if(ubicacion=='2'){
		valorUbicacion='Albacete';
	}else if(ubicacion=='3'){
		valorUbicacion='Alicante';
	}else if(ubicacion=='4'){
		valorUbicacion='Almería';
	}else if(ubicacion=='33'){
		valorUbicacion='Asturias';
	}else if(ubicacion=='5'){
		valorUbicacion='Ávila';
	}else if(ubicacion=='6'){
		valorUbicacion='Badajoz';
	}else if(ubicacion=='7'){
		valorUbicacion='Baleares';
	}else if(ubicacion=='8'){
		valorUbicacion='Barcelona';
	}else if(ubicacion=='9'){
		valorUbicacion='Burgos';
	}else if(ubicacion=='10'){
		valorUbicacion='Cáceres';
	}else if(ubicacion=='11'){
		valorUbicacion='Cádiz';
	}else if(ubicacion=='39'){
		valorUbicacion='Cantabria';
	}else if(ubicacion=='12'){
		valorUbicacion='Castellón';
	}else if(ubicacion=='51'){
		valorUbicacion='Ceuta';
	}else if(ubicacion=='13'){
		valorUbicacion='Ciudad Real';
	}else if(ubicacion=='14'){
		valorUbicacion='Córdoba';
	}else if(ubicacion=='16'){
		valorUbicacion='Cuenca';
	}else if(ubicacion=='17'){
		valorUbicacion='Gerona';
	}else if(ubicacion=='18'){
		valorUbicacion='Granada';
	}else if(ubicacion=='19'){
		valorUbicacion='Guadalajara';
	}else if(ubicacion=='20'){
		valorUbicacion='Guipúzcoa';
	}else if(ubicacion=='21'){
		valorUbicacion='Huelva';
	}else if(ubicacion=='22'){
		valorUbicacion='Huesca';
	}else if(ubicacion=='23'){
		valorUbicacion='Jaén';
	}else if(ubicacion=='15'){
		valorUbicacion='La Coruña';
	}else if(ubicacion=='26'){
		valorUbicacion='La Rioja';
	}else if(ubicacion=='35'){
		valorUbicacion='Las Palmas';
	}else if(ubicacion=='24'){
		valorUbicacion='León';
	}else if(ubicacion=='25'){
		valorUbicacion='Lérida';
	}else if(ubicacion=='26'){
		valorUbicacion='Lugo';
	}else if(ubicacion=='28'){
		valorUbicacion='Madrid';
	}else if(ubicacion=='29'){
		valorUbicacion='Málaga';
	}else if(ubicacion=='52'){
		valorUbicacion='Melilla';
	}else if(ubicacion=='30'){
		valorUbicacion='Murcia';
	}else if(ubicacion=='31'){
		valorUbicacion='Navarra';
	}else if(ubicacion=='32'){
		valorUbicacion='Orense';
	}else if(ubicacion=='34'){
		valorUbicacion='Palencia';
	}else if(ubicacion=='36'){
		valorUbicacion='Pontevedra';
	}else if(ubicacion=='37'){
		valorUbicacion='Salamanca';
	}else if(ubicacion=='38'){
		valorUbicacion='S.C.Tenerife';
	}else if(ubicacion=='40'){
		valorUbicacion='Segovia';
	}else if(ubicacion=='41'){
		valorUbicacion='Sevilla';
	}else if(ubicacion=='42'){
		valorUbicacion='Soria';
	}else if(ubicacion=='43'){
		valorUbicacion='Tarragona';
	}else if(ubicacion=='44'){
		valorUbicacion='Teruel';
	}else if(ubicacion=='45'){
		valorUbicacion='Toledo';
	}else if(ubicacion=='46'){
		valorUbicacion='Valencia';
	}else if(ubicacion=='47'){
		valorUbicacion='Valladolid';
	}else if(ubicacion=='48'){
		valorUbicacion='Vizcaya';
	}else if(ubicacion=='49'){
		valorUbicacion='Zamora';
	}else if(ubicacion=='50'){
		valorUbicacion='Zaragoza';
	}

	var provider = new ChannelProvider();
	provider.addTrustedOrigins(entorno);
	var channel = provider.$get(window);
	var SCOPE =  'simuladores';
	var message = { 
			action:'SOLICITAR',
			data:{
				'simulador': simulador, 'espacio': espacio, 'finalidad': finalidad,'conocimientoValorVivienda': conocimientoPrecio, 'valor': valor, 'ingresos': ingresos, 'gastos': gastos, 'tipoInmueble': tipoInmueble, 'ubicacion': valorUbicacion, 'cantidad': cantidad, 'plazo': plazo, 'producto': producto, 'cpp': cpp, 'familia': familia, 'subfamilia': subfamilia
			}
	};  
	channel.transmit(window.parent, SCOPE, message);
}

function abrirModalValoraTuVivienda(){
	var modalValoradorInmueble = $("#modalValoradorInmueble").val();
	var widgetNoEncontramosViviendas = $("#widgetNoEncontramosViviendas").val();
	var modalValorInmueble = $("#modalValorInmueble").val();
	var widgetAceptar = $("#widgetAceptar").val();
	var poweredBy = $("#poweredBy").val();
	var TerceroB = $("#TerceroB").val();
	var URLFormatear = "/portalunico/widgetConoceValorModal.jsp";
	jQuery.ajax({
		url: encodeURI(URLFormatear),
		context: document.body,
		data: {'modalValoradorInmueble':modalValoradorInmueble, 'widgetNoEncontramosViviendas':widgetNoEncontramosViviendas, 
			'modalValorInmueble':modalValorInmueble, 'widgetAceptar':widgetAceptar, 'poweredBy':poweredBy, 'TerceroB':TerceroB},
			success: function(data, textStatus )     
			{        
				jQuery('#conocesModal').html(data);
			},
			error: function(xhr, textStatus, errorThrown){         

			}

	});


	return false;
}


function solicitarTraeteTuHipoteca(tituloHipoteca, prioridadHipoteca){

	var valorIdTeAyudamosHipotecas = $("#idTeAyudamos").val();

	var valorViviendaHipoteca = $("#valorActualVivienda").val();
	var valorCantidadHipoteca = $("#pendientePago").val();
	var valorPlazoAnyosHipoteca = $("#plazoAnyos").val();
	var valorPlazoMesesHipoteca = $("#plazoMeses").val();
	if(undefined == valorPlazoMesesHipoteca || 0 == valorPlazoMesesHipoteca || ""== valorPlazoMesesHipoteca){
		valorPlazoMesesHipoteca = 0;
	}
	var valorPlazoHipoteca = valorPlazoAnyosHipoteca + " aÃ±os y " + valorPlazoMesesHipoteca + " meses";

	var valorTituloHipoteca = tituloHipoteca;
	var valorPrioridadHipoteca = prioridadHipoteca;
	var segmentoHipoteca = $("#segmento").val();
	var familiaHipoteca = $("#familia").val();
	var colectivoHipoteca = $("#colectivo").val();


	//nuevaContactabilidad


	var nuevaContactabilidadCerrar = $("#nuevaContactabilidadCerrar").val();
	var nuevaContactabilidadTeAyudamos = $("#nuevaContactabilidadTeAyudamos").val();
	var nuevaContactabilidadNumeroTelefonoPrestamo = $("#nuevaContactabilidadNumeroTelefonoPrestamo").val();
	var nuevaContactabilidadNumeroTelefonoPension = $("#nuevaContactabilidadNumeroTelefonoPension").val();
	var nuevaContactabilidadNumeroTelefonoHipoteca = $("#nuevaContactabilidadNumeroTelefonoHipoteca").val();
	var nuevaContactabilidadAtencionTelefonica = $("#nuevaContactabilidadAtencionTelefonica").val();
	var nuevaContactabilidadTeLlamamos = $("#nuevaContactabilidadTeLlamamos").val();
	var nuevaContactabilidadErrorFormulario = $("#nuevaContactabilidadErrorFormulario").val();
	var nuevaContactabilidadAcceso = $("#nuevaContactabilidadAcceso").val();
	var nuevaContactabilidadNombre = $("#nuevaContactabilidadNombre").val();


	var nuevaContactabilidadTelefono = $("#nuevaContactabilidadTelefono").val();
	var nuevaContactabilidadFormatoTelefono = $("#nuevaContactabilidadFormatoTelefono").val();
	var nuevaContactabilidadTelefonoIncorrecto = $("#nuevaContactabilidadTelefonoIncorrecto").val();
	var nuevaContactabilidadSoyCliente = $("#nuevaContactabilidadSoyCliente").val();
	var nuevaContactabilidadHeLeido = $("#nuevaContactabilidadHeLeido").val();
	var nuevaContactabilidadErrorCondiciones = $("#nuevaContactabilidadErrorCondiciones").val();
	var captchaMover = $(".captchaMover").val();
	var captchaValidado = $(".captchaValidado").val();
	var nuevaContactabilidadSolicitarLlamada = $("#nuevaContactabilidadSolicitarLlamada").val();
	var nuevaContactabilidadEscribirMensaje = $("#nuevaContactabilidadEscribirMensaje").val();

	var nuevaContactabilidadCorreo = $("#nuevaContactabilidadCorreo").val();
	var nuevaContactabilidadFormatoCorreo = $("#nuevaContactabilidadFormatoCorreo").val();
	var nuevaContactabilidadErrorCorreo = $("#nuevaContactabilidadErrorCorreo").val();
	var nuevaContactabilidadMensaje = $("#nuevaContactabilidadMensaje").val();
	var nuevaContactabilidadEnviarMensaje = $("#nuevaContactabilidadEnviarMensaje").val();
	var nuevaContactabilidadRecibidaPeticion = $("#nuevaContactabilidadRecibidaPeticion").val();
	var nuevaContactabilidadNosPondremosEnContacto = $("#nuevaContactabilidadNosPondremosEnContacto").val();

	var contactabilidadNombreErrorVacio = $(".contactabilidadNombreErrorVacio").val();
	var contactabilidadConsultaErrorVacio = $(".contactabilidadConsultaErrorVacio").val();

	var hreflang = $(".hreflang").val();
	var URLFormatear = "/portalunico/nuevaContactabilidad.jsp" + "?tipoContactabilidad=" + "h" + "&idTeAyudamos=" + valorIdTeAyudamosHipotecas + "&tituloHipoteca=" + valorTituloHipoteca + "&segmentoHipoteca=" + segmentoHipoteca + "&familiaHipoteca=" + familiaHipoteca + "&colectivoHipoteca=" + colectivoHipoteca + "&prioridadHipoteca=" + valorPrioridadHipoteca + "&tipoHipoteca=" + "" + "&tipoInmuebleHipoteca=" + "" + "&cantidadHipoteca=" + valorCantidadHipoteca + "&plazoHipoteca=" + valorPlazoHipoteca + "&valorVivienda=" + valorViviendaHipoteca;
	jQuery.ajax({
		url: encodeURI(URLFormatear),
		context: document.body,
		data: {'nuevaContactabilidadCerrar':nuevaContactabilidadCerrar, 'nuevaContactabilidadTeAyudamos':nuevaContactabilidadTeAyudamos, 'nuevaContactabilidadNumeroTelefonoPrestamo':nuevaContactabilidadNumeroTelefonoPrestamo, 'nuevaContactabilidadNumeroTelefonoPension':nuevaContactabilidadNumeroTelefonoPension, 'nuevaContactabilidadNumeroTelefonoHipoteca':nuevaContactabilidadNumeroTelefonoHipoteca, 'nuevaContactabilidadAtencionTelefonica':nuevaContactabilidadAtencionTelefonica, 'nuevaContactabilidadTeLlamamos':nuevaContactabilidadTeLlamamos, 'nuevaContactabilidadErrorFormulario':nuevaContactabilidadErrorFormulario, 'nuevaContactabilidadAcceso':nuevaContactabilidadAcceso, 'nuevaContactabilidadNombre':nuevaContactabilidadNombre,
			'nuevaContactabilidadTelefono':nuevaContactabilidadTelefono, 'nuevaContactabilidadFormatoTelefono':nuevaContactabilidadFormatoTelefono, 'nuevaContactabilidadTelefonoIncorrecto':nuevaContactabilidadTelefonoIncorrecto, 'nuevaContactabilidadSoyCliente':nuevaContactabilidadSoyCliente, 'nuevaContactabilidadHeLeido':nuevaContactabilidadHeLeido, 'nuevaContactabilidadErrorCondiciones':nuevaContactabilidadErrorCondiciones, 'captchaMover':captchaMover, 'captchaValidado':captchaValidado, 'nuevaContactabilidadSolicitarLlamada':nuevaContactabilidadSolicitarLlamada, 'nuevaContactabilidadEscribirMensaje':nuevaContactabilidadEscribirMensaje,
			'nuevaContactabilidadCorreo':nuevaContactabilidadCorreo, 'nuevaContactabilidadFormatoCorreo':nuevaContactabilidadFormatoCorreo, 'nuevaContactabilidadErrorCorreo':nuevaContactabilidadErrorCorreo, 'nuevaContactabilidadMensaje':nuevaContactabilidadMensaje, 'nuevaContactabilidadEnviarMensaje':nuevaContactabilidadEnviarMensaje, 'nuevaContactabilidadRecibidaPeticion':nuevaContactabilidadRecibidaPeticion, 'nuevaContactabilidadNosPondremosEnContacto':nuevaContactabilidadNosPondremosEnContacto,'hreflang': hreflang,
			'contactabilidadNombreErrorVacio':contactabilidadNombreErrorVacio,'contactabilidadConsultaErrorVacio':contactabilidadConsultaErrorVacio
		},
		success: function(data, textStatus )     
		{        
			jQuery('#nuevaContactabilidadTraete').html(data);
			modCaptcha.initCaptcha("[data-function='fc-captcha']");
			mod_focus.initEliminarFocus("a");
			mod_focus.initEliminarFocus(".ui-accordion-header");
			mod_focus.initEliminarFocus(".frm-checkbox");
			mod_focus.initEliminarFocus(".mod_buttons input.but-green[type='submit']");

			paso3Simulador();
		},
		error: function(xhr, textStatus, errorThrown){ 
		}

	});


	return false;
}


function accionSolicitar(producto, prioridad){

	var valorSegmentoSolicitar = $(".segmentoSolicitar").val();
	var valorFamiliaSolicitar = $(".familiaSolicitar").val();
	var valorColectivoSolicitar = $(".colectivoSolicitar").val();
	var valorPaginaSolicitar = $(".paginaSolicitar").val();
	var valorEspacioSolicitar = $(".espacioSolicitar").val();
	var esFichaProducto = typeof($("#hddFichaProducto").val());

	var contactabilidadCamposErroneosPrivada = $(".contactabilidadCamposErroneosPrivada").val(); 
	var accionSolicitarErrorFormulario = $(".accionSolicitarErrorFormulario").val();
	var accionSolicitarCerrar = $(".accionSolicitarCerrar").val();
	var contactabilidadTituloCorreoPrivada = $(".contactabilidadTituloCorreoPrivada").val();
	var accionSolicitarEscribenos = $(".accionSolicitarEscribenos").val();
	var accionSolicitarAcceso = $(".accionSolicitarAcceso").val();
	var accionSolicitarNombre = $(".accionSolicitarNombre").val();
	var contactabilidadNombreEmpresa = $(".contactabilidadNombreEmpresa").val();
	var contactabilidadCif = $(".contactabilidadCif").val();
	var contactabilidadNombrePersona = $(".contactabilidadNombrePersona").val();
	var accionSolicitarCorreo = $(".accionSolicitarCorreo").val();
	var accionSolicitarCorreoFormato = $(".accionSolicitarCorreoFormato").val();
	var accionSolicitarErrorCorreo = $(".accionSolicitarErrorCorreo").val();
	var contactabilidadValCor = $(".contactabilidadValCor").val();
	var contactabilidadConsultaPrivada = $(".contactabilidadConsultaPrivada").val();
	var accionSolicitarEscribeConsulta = $(".accionSolicitarEscribeConsulta").val();
	var contactabilidadProvincia = $(".contactabilidadProvincia").val();
	var accionSolicitarOficina = $(".accionSolicitarOficina").val();
	var accionSolicitarBuscarOficina = $(".accionSolicitarBuscarOficina").val();
	var accionSolicitarSoyCliente = $(".accionSolicitarSoyCliente").val();
	var accionSolicitarHeLeido = $(".accionSolicitarHeLeido").val();
	var accionSolicitarUrlCondicionesServicio = $(".accionSolicitarUrlCondicionesServicio").val();
	var accionSolicitarCondicionesServicio = $(".accionSolicitarCondicionesServicio").val();
	var accionSolicitarErrorCondiciones = $(".accionSolicitarErrorCondiciones").val();
	var contactabilidadValCondiciones = $(".contactabilidadValCondiciones").val();
	var accionSolicitarEnviarMensaje = $(".accionSolicitarEnviarMensaje").val();
	var accionSolicitarHemosRecibido = $(".accionSolicitarHemosRecibido").val();
	var accionSolicitarEnBreve = $(".accionSolicitarEnBreve").val();

	var contactabilidadNombreErrorVacio = $(".contactabilidadNombreErrorVacio").val();
	var contactabilidadNombreEmpresaErrorVacio = $(".contactabilidadNombreEmpresaErrorVacio").val();
	var contactabilidadCifErrorVacio = $(".contactabilidadCifErrorVacio").val();
	var contactabilidadPersonaContactoErrorVacio = $(".contactabilidadPersonaContactoErrorVacio").val();
	var contactabilidadConsultaErrorVacio = $(".contactabilidadConsultaErrorVacio").val();


	var captchaMover = $(".captchaMover").val();
	var captchaValidado = $(".captchaValidado").val();

	var prioridadSolicitar = prioridad;

	var hreflang = $(".hreflang").val();

	if(esFichaProducto == "undefined"){
		esFichaProducto = "false";
	}else{
		esFichaProducto = $("#hddFichaProducto").val();
	}
	var URLFormatear = "/portalunico/accionSolicitar.jsp" + "?segmento=" + valorSegmentoSolicitar + "&familia=" + valorFamiliaSolicitar + "&colectivo=" + valorColectivoSolicitar + "&pagina=" + valorPaginaSolicitar + "&espacio=" + valorEspacioSolicitar + "&producto=" + encodeURI(producto) + "&esFP=" + esFichaProducto;
	jQuery.ajax({
		url: encodeURI(URLFormatear),
		context: document.body,
		contentType: 'text/html; charset=utf-8',
		data: {'paramsSeguir':'1',
			'contactabilidadCamposErroneosPrivada':contactabilidadCamposErroneosPrivada,
			'accionSolicitarErrorFormulario':accionSolicitarErrorFormulario,
			'accionSolicitarCerrar':accionSolicitarCerrar,
			'contactabilidadTituloCorreoPrivada':contactabilidadTituloCorreoPrivada,
			'accionSolicitarEscribenos':accionSolicitarEscribenos,
			'accionSolicitarAcceso':accionSolicitarAcceso,
			'accionSolicitarNombre':accionSolicitarNombre,
			'contactabilidadNombreEmpresa':contactabilidadNombreEmpresa,
			'contactabilidadCif':contactabilidadCif,
			'contactabilidadNombrePersona':contactabilidadNombrePersona,
			'accionSolicitarCorreo':accionSolicitarCorreo,
			'accionSolicitarCorreoFormato':accionSolicitarCorreoFormato,
			'accionSolicitarErrorCorreo':accionSolicitarErrorCorreo,
			'contactabilidadValCor':contactabilidadValCor,
			'contactabilidadConsultaPrivada':contactabilidadConsultaPrivada,
			'accionSolicitarEscribeConsulta':accionSolicitarEscribeConsulta,
			'contactabilidadProvincia':contactabilidadProvincia,
			'accionSolicitarOficina':accionSolicitarOficina,
			'accionSolicitarBuscarOficina':accionSolicitarBuscarOficina,
			'accionSolicitarSoyCliente':accionSolicitarSoyCliente,
			'accionSolicitarHeLeido':accionSolicitarHeLeido,
			'accionSolicitarUrlCondicionesServicio':accionSolicitarUrlCondicionesServicio,
			'accionSolicitarCondicionesServicio':accionSolicitarCondicionesServicio,
			'accionSolicitarErrorCondiciones':accionSolicitarErrorCondiciones,
			'contactabilidadValCondiciones':contactabilidadValCondiciones,
			'accionSolicitarEnviarMensaje':accionSolicitarEnviarMensaje,
			'accionSolicitarHemosRecibido':accionSolicitarHemosRecibido,
			'accionSolicitarEnBreve':accionSolicitarEnBreve,
			'contactabilidadNombreErrorVacio':contactabilidadNombreErrorVacio,
			'contactabilidadNombreEmpresaErrorVacio':contactabilidadNombreEmpresaErrorVacio,
			'contactabilidadCifErrorVacio':contactabilidadCifErrorVacio,
			'contactabilidadPersonaContactoErrorVacio':contactabilidadPersonaContactoErrorVacio,
			'contactabilidadConsultaErrorVacio':contactabilidadConsultaErrorVacio,
			'captchaMover':captchaMover, 
			'captchaValidado':captchaValidado,
			'prioridad':prioridadSolicitar,
			'hreflang': hreflang
		},
		success: function(data, textStatus )
		{        
			jQuery('.accionSolicitar').html(data);


			digitalData.funnel = "paso1:contactabilidad solicitar";
			digitalData.tipoContactabilidad = "email";
			digitalData.tipoPagina = "modal";
			digitalData.estado = "inicio";
//			if (digitalData.puntoAcceso == null || digitalData.puntoAcceso.length == 0){
//			digitalData.puntoAcceso = (digitalData.subseccion2 != null && digitalData.subseccion2.length > 0)? digitalData.subseccion2 : digitalData.subseccion1;
//			}
			sessionStorage.setItem('puntoAcceso', digitalData.puntoAcceso);
			sessionStorage.setItem("oldTematicaContenido", digitalData.tematicaContenido);
			sessionStorage.setItem("oldNombrePagina", digitalData.nombrePagina);
			digitalData.tematicaContenido = "contactabilidad";
			digitalData.proceso = "contactabilidad";
			digitalData.nombrePagina = "contactabilidad solicitar";

			if (typeof(sessionStorage.viewEnviado) === "undefined" || sessionStorage.viewEnviado == null){
				sessionStorage.setItem('viewEnviado', "1");
				_satellite.track('view');
			}
//			_satellite.track('view');

			$("#lightboxCEmailYouSol").ready(function(){
				$("#lightboxCEmailYouSol").on("hide.bs.modal",function(){

					modalHideCustomization();

					digitalData.funnel = "";
					digitalData.estado = "";
					digitalData.tipoPagina = "normal";
					digitalData.tematicaContenido = (sessionStorage.oldTematicaContenido !== undefined && sessionStorage.oldTematicaContenido != "")? sessionStorage.oldTematicaContenido : digitalData.tematicaContenido;
					digitalData.tipoContactabilidad = "";
					digitalData.proceso = "";
					digitalData.puntoAcceso = "";
					var lNombrePagina = digitalData.paginaBajoModal;
					var oldNombrePagina = "";
					if (lNombrePagina !== undefined && lNombrePagina != ""){
						var splitONP = lNombrePagina.split(":");
						oldNombrePagina = splitONP[splitONP.length-1];
					}
					digitalData.nombrePagina = oldNombrePagina;
					digitalData.paginaBajoModal = "";
					_satellite.track('view');
				});

			});



		},
		error: function(xhr, textStatus, errorThrown){         

		}
	});


	return false;
}



function validacionCalculadora(){
	valorMoney = document.getElementById("input_money").value;
	descrErrorVacioMoney = document.getElementById("id_desc_err_input_money_vacio");
	descrPintar = document.getElementById("pintar_money");
	banComentarioCantidad = 0;
	CampoObligatorioCantidad = 0;
	CampoObligatorioPlazo = 0;
	banComentarioPlazo = 0;
	correcto=0;
	colorMoney=0
	colorMonth=0

	if(valorMoney===""){
		descrPintar.className = "frm-label frm-message-error";
		descrErrorVacioMoney.className = "frm-txt-message";
		correcto = 1;
		colorMoney=1  
		CampoObligatorioCantidad = 1
	}else{
		descrErrorVacioMoney.className = "frm-txt-message hide";



	}
	valorMoney1 = document.getElementById("input_money").value;
	descrError = document.getElementById("id_desc_err_input_money");


	if(!(/^-?[0-9]+([0-9]*)?$/.test(valorMoney1))){
		descrPintar.className = "frm-label frm-message-error";
		descrError.className = "frm-txt-message";
		correcto = 1;
		colorMoney=1
		banComentarioCantidad=1
	}else{
		descrError.className = "frm-txt-message hide";

	}

	valorCantMaxStr = document.getElementById("id_cant_max").value;
	valorCantMaxStr = valorCantMaxStr.replace(",", ".");
	valorCantMax=parseFloat(valorCantMaxStr);

	valorCantMinStr = document.getElementById("id_cant_min").value;
	valorCantMinStr = valorCantMinStr.replace(",", ".");
	valorCantMin=parseFloat(valorCantMinStr);
	valorMoneyStr = document.getElementById("input_money").value;
	valorMoneyStr= valorMoneyStr.replace(",", ".");
	valorMoney2 = parseFloat(valorMoneyStr);

	descrErrorMinMax=document.getElementById("id_desc_err_input_money_maxmin");

	if((valorMoney2<valorCantMin || valorMoney2>valorCantMax)){
		descrPintar.className = "frm-label frm-message-error";
		descrErrorMinMax.className = "frm-txt-message";
		correcto = 1
		colorMoney=1

	}else{

		descrErrorMinMax.className = "frm-txt-message hide";

	}
	valorMonth = document.getElementById("input_month").value;
	descrErrorVacioMonth = document.getElementById("id_desc_err_input_month_vacio");
	descrPintarMonth = document.getElementById("pintar_month");
	if(valorMonth===""){
		descrPintarMonth.className = "frm-label frm-message-error";
		descrErrorVacioMonth.className = "frm-txt-message";
		correcto = 1;
		colorMonth = 1  
		CampoObligatorioPlazo = 1
	}else{

		descrErrorVacioMonth.className = "frm-txt-message hide";

	}
	valorMonth = document.getElementById("input_month").value;
	descrErrorMonth = document.getElementById("id_desc_err_input_month");



	if (!(/^-?[0-9]+([0-9]*)?$/.test(valorMonth))){
		descrPintarMonth.className = "frm-label frm-message-error";
		descrErrorMonth.className = "frm-txt-message";
		correcto = 1;
		colorMonth = 1
		banComentarioPlazo = 1
	}else{
		descrErrorMonth.className = "frm-txt-message hide";

	}
	valorPlazoMaxStr = document.getElementById("id_plaz_max").value;
	valorPlazoMaxStr = valorPlazoMaxStr.replace(",", ".");
	valorPlazoMax = parseFloat(valorPlazoMaxStr);

	valorPlazoMinStr = document.getElementById("id_plaz_min").value;
	valorPlazoMinStr = valorPlazoMinStr.replace(",", ".");
	valorPlazoMin = parseFloat(valorPlazoMinStr);

	valorMonthStr = document.getElementById("input_month").value;
	valorMonthStr = valorMonthStr.replace(",", ".");
	valorMonth = parseFloat(valorMonthStr);

	descrErrorMinMax=document.getElementById("id_desc_err_input_month_maxmin");

	if(valorMonth<valorPlazoMin || valorMonth>valorPlazoMax){
		descrPintarMonth.className = "frm-label frm-message-error";
		descrErrorMinMax.className = "frm-txt-message";
		correcto = 1
		colorMonth = 1

	}else{

		descrErrorMinMax.className = "frm-txt-message hide";


	}
	idMoney = document.getElementById("input_money");
	if(colorMoney == 1){

		idMoney.style.border="1px solid #D63F3F";
	}else{

		idMoney.style.border="1px solid #B9C800";
	}
	idMonth = document.getElementById("input_month");
	if(colorMonth == 1){

		idMonth.style.border="1px solid #D63F3F";
	}else{

		idMonth.style.border="1px solid #B9C800";
	}

	descrError = document.getElementById("id_desc_err_input_money");
	if(CampoObligatorioCantidad == 1){
		descrError.className = "frm-txt-message hide";

	}
	descrErrorMonth = document.getElementById("id_desc_err_input_month");
	if(CampoObligatorioPlazo == 1){
		descrErrorMonth.className = "frm-txt-message hide";
	}


	descrErrorMinMax=document.getElementById("id_desc_err_input_money_maxmin");
	if(banComentarioCantidad==1){
		descrErrorMinMax.className = "frm-txt-message hide";
	}
	descrErrorMinMax=document.getElementById("id_desc_err_input_month_maxmin");
	if(banComentarioPlazo==1){
		descrErrorMinMax.className = "frm-txt-message hide";
	}


	enviadoCal = document.getElementById("enviadoCal");
	descrPintar = document.getElementById("pintar_money");
	descrPintarMonth = document.getElementById("pintar_month");

	if (correcto == 0)
	{	
		enviadoCal.value="true";
		descrPintar.className="frm-label";
		descrPintarMonth.className="frm-label";


		//llamada ajax

		var valorDestacado = $("#idDestacado").val();
		var valorCantidad = $("#input_money").val();
		var valorplazo = $("#input_month").val();
		var valorinter = $("#id_interes").val();
		var valorEuriborSuelo = $("#id_euriborSuelo").val();
		var valorEuriborNormal = $("#id_euribor").val();

		var calculadoraLeyenda = $("#calculadoraLeyenda").val();
		var calculadoraLeyendaPrestamo = $("#calculadoraLeyendaPrestamo").val();
		var calculadoraMensajeCuotaPrestamo = $("#calculadoraMensajeCuotaPrestamo").val();
		var calculadoraMensajeCuota = $("#calculadoraMensajeCuota").val();
		var calculadoraCuotaMensual = $("#calculadoraCuotaMensual").val();
		var calculadoraPlazo1 = $("#calculadoraPlazo1").val();
		var calculadoraPlazoEnMeses = $("#calculadoraPlazoEnMeses").val();
		var calculadoraPlazo2 = $("#calculadoraPlazo2").val();
		var calculadoraTAE = $("#calculadoraTAE").val();
		var calculadoraMeinteresa = $("#calculadoraMeinteresa").val();
		var calculadoraTextoSegTramo1 = $("#calculadoraTextoSegTramo1").val();
		var calculadoraTextoSegTramo2 = $("#calculadoraTextoSegTramo2").val();
		var calculadoraTextoSegTramo3 = $("#calculadoraTextoSegTramo3").val();
		var calculadoraCondiciones = $("#calculadoraCondiciones").val();
		var hreflang = $(".hreflang").val();
		var URLFormatear = "/portalunico/nuevaSimCalculadora.jsp" + "?destacado=" + valorDestacado + "&cantidad=" + valorCantidad + "&plazo=" + valorplazo + "&inter=" + valorinter + "&euriborSuelo=" + valorEuriborSuelo + "&euriborNormal=" + valorEuriborNormal;
		jQuery.ajax({
			url: encodeURI(URLFormatear),
			context: document.body,
			data: {'paramsSeguir':'1',
				'calculadoraLeyenda':calculadoraLeyenda,
				'calculadoraLeyendaPrestamo':calculadoraLeyendaPrestamo,
				'calculadoraMensajeCuotaPrestamo':calculadoraMensajeCuotaPrestamo,
				'calculadoraMensajeCuota':calculadoraMensajeCuota,
				'calculadoraCuotaMensual':calculadoraCuotaMensual,
				'calculadoraPlazo1':calculadoraPlazo1,
				'calculadoraPlazoEnMeses':calculadoraPlazoEnMeses,
				'calculadoraPlazo2':calculadoraPlazo2,
				'calculadoraTAE':calculadoraTAE,
				'calculadoraMeinteresa':calculadoraMeinteresa,
				'calculadoraTextoSegTramo1':calculadoraTextoSegTramo1,
				'calculadoraTextoSegTramo2':calculadoraTextoSegTramo2,
				'calculadoraTextoSegTramo3':calculadoraTextoSegTramo3,
				'calculadoraCondiciones':calculadoraCondiciones,
				'hreflang': hreflang
			},
			success: function(data, textStatus )     
			{    
				if (!jQuery('.ajaxCalculadora').hasClass('hide'))
				{
					jQuery('.ajaxCalculadora').css('display','none');
					jQuery('.ajaxCalculadora').toggleClass('hide');
				}
				jQuery('#nuevaSimulacionCalculadora').html(data);

			},
			error: function(xhr, textStatus, errorThrown){         

			}

		});



		return false;
	}
	else
	{





		return false;

	}

}


var mod_chart = (function() {
	var initChart = (function(selector) {
		var idChart = "";
		var item = "";
		$(selector)
		.each(
				function(index) {
					if ($(this).attr("data-chart") == "rentabilidad" && rentabilidadAnual!='') {
						var data = rentabilidadAnual;
						d3.select(this).datum(data).call(
								columnChart().x(function(d, i) {
									return d[0];
								}).y(function(d, i) {
									return d[1];
								}));
					} else if ($(this).attr("data-chart") == "rentabilidadMensual" && rentabilidadMensual!='') {
						var data = rentabilidadMensual;
						d3.select(this).datum(data).call(
								columnChart().x(function(d, i) {
									return d[0];
								}).y(function(d, i) {
									return d[1];
								}));
					} else if ($(this).attr("data-chart") == "valoresDetalle" && vlpGrafica != '') {
						var margin = {
								top : 20,
								right : 50,
								bottom : 30,
								left : 50
						}, width = 960 - margin.left - margin.right, height = 500
						- margin.top - margin.bottom;
						var parseDate = d3.time.format("%d-%b-%y").parse, bisectDate = d3
						.bisector(function(d) {
							return d.date;
						}).left, formatValue = d3
						.format(",.2f"), formatCurrency = function(
								d) {
							return "" + formatValue(d);
						};
						var x = d3.time.scale().range([ 0, width ]);
						var y = d3.scale.linear().range([ height, 0 ]);
						var xAxis = d3.svg.axis().scale(x).orient(
						"bottom");
						var yAxis = d3.svg.axis().scale(y).orient(
						"left");
						var line = d3.svg.line().x(function(d) {
							return x(d.date);
						}).y(function(d) {
							return y(d.close);
						});

						var svg;
						var ua = window.navigator.userAgent;
						var msie = ua.indexOf('MSIE');
						var trident = ua.indexOf('Trident');
						var rv11 = ua.indexOf('rv:11');
						if(msie > 0 || (trident > 0 && rv11 > 0)){
							svg = d3.select(this).append("svg:svg")
							.attr("preserveAspectRatio",
							"xMinYMin meet").attr(
									"viewBox", "0 0 960 500").attr("class", "graficasIE")
									.append("g").attr(
											"transform",
											"translate(" + margin.left
											+ "," + margin.top
											+ ")");
						}else{
							svg = d3.select(this).append("svg:svg")
							.attr("preserveAspectRatio",
							"xMinYMin meet").attr(
									"viewBox", "0 0 960 500")
									.append("g").attr(
											"transform",
											"translate(" + margin.left
											+ "," + margin.top
											+ ")");
						}

						var data = vlpGrafica;

						data.forEach(function(d) {
							d.date = parseDate(d.date);
							d.close = +d.close;
						});
						data.sort(function(a, b) {
							return a.date - b.date;
						});
						x.domain([ data[0].date,
						           data[data.length - 1].date ]);
						y.domain(d3.extent(data, function(d) {
							return d.close;
						}));
						svg.append("g").attr("class", "x axis").attr(
								"transform",
								"translate(0," + height + ")").call(
										xAxis);
						svg.append("g").attr("class", "y axis").call(
								yAxis).append("text").attr("transform",
								"rotate(-90)").attr("y", 6).attr("dy",
								".71em").style("text-anchor", "end")
								.text("");
						svg.append("path").datum(data).attr("class",
						"line").attr("d", line);
						var focus = svg.append("g").attr("class",
						"focus").style("display", "none");
						focus.append("circle").attr("r", 4.5);
						focus.append("text").attr("x", 9).attr("dy",
						".35em");
						svg.append("rect").attr("class", "overlay")
						.attr("width", width).attr("height",
								height).on(
										"mouseover",
										function() {
											focus
											.style("display",
													null);
										}).on("mouseout", function() {
											focus.style("display", "none");
										}).on("mousemove", mousemove);
						function mousemove() {
							var x0 = x.invert(d3.mouse(this)[0]), i = bisectDate(
									data, x0, 1), d0 = data[i - 1], d1 = data[i], d = x0
									- d0.date > d1.date - x0 ? d1 : d0;
									focus.attr("transform", "translate("
											+ x(d.date) + "," + y(d.close)
											+ ")");
									focus.select("text").text(
											formatCurrency(d.close));
						}
					}else if ($(this).attr("data-chart") == "cartera" && (typeof datasetTotal !== "undefined") && datasetTotal != '') {
						var svg = d3.select(this).append("svg:svg").attr("preserveAspectRatio","xMinYMin meet").attr("viewBox", "0 0 650 400").append("g");
						svg.append("g").attr("class", "slices");
						svg.append("g").attr("class", "labelName");
						svg.append("g").attr("class", "labelValue");
						svg.append("g").attr("class", "lines");
						var width = 650, height = 400, radius = Math.min(width, height) / 2;
						var pie = d3.layout.pie().sort(null).value(
								function(d) {
									return d.value;
								});
						var arc = d3.svg.arc().outerRadius(radius * 0.7).innerRadius(radius * 0.5);
						var outerArc = d3.svg.arc().innerRadius(radius * 0.9).outerRadius(radius * 0.9);
						var legendRectSize = (radius * 0.1);
						var legendSpacing = radius * 0.02;
						var div = d3.select("body").append("div").attr("class", "chart-tooltip");
						svg.attr("transform", "translate(" + width / 2 + "," + height / 2 + ")")
						var colorRange = (d3.scale.category20());
						var color = d3.scale.ordinal().range(colorRange.range());
						change(datasetTotal);
						d3.selectAll("[data-function='fc-inputChart'], [data-function='fc-inputChart']+ui-selectmenu-button").on("change", selectDataset);
						function selectDataset() {
							var value = this.value;
							if (value == "total") {
								change(datasetTotal);
							} else if (value == "option1") {
								change(datasetOption1);
							} else if (value == "option2") {
								change(datasetOption2);
							} else if (value == "option3") {
								change(datasetOption3);
							} else if (value == "option4") {
								change(datasetOption4);
							} else if (value == "option5") {
								change(datasetOption5);
							}
						}
						function change(data) {
							var slice = svg.select(".slices")
							.selectAll("path.slice").data(
									pie(data), function(d) {
										return d.data.label
									});
							slice.enter().insert("path").style("fill",
									function(d) {
								return color(d.data.label);
							}).attr("class", "slice");
							slice
							.transition()
							.duration(1000)
							.attrTween(
									"d",
									function(d) {
										this._current = this._current
										|| d;
										var interpolate = d3
										.interpolate(
												this._current,
												d);
										this._current = interpolate(0);
										return function(t) {
											return arc(interpolate(t));
										};
									})
									slice.on("mousemove", function(d) {
										div.style("left", d3.event.pageX + 10
												+ "px");
										div.style("top", d3.event.pageY - 25
												+ "px");
										div.style("display", "block");
										div.html((d.data.label) + "<br>"
												+ (d.data.value) + "%");
									});
							slice.on("mouseout", function(d) {
								div.style("display", "none");
							});
							slice.exit().remove();
							//Eliminamos los legend
							$(".containerLegend").remove();

							var leyenda = "<div class='containerLegend'>";
							var leyColor = "";
							for (var i = 0; i < data.length; i++) {
								leyColor = $(".slice")[i].style.cssText
								leyColor = leyColor.split(":");
								leyenda = leyenda + "<span class='legendDonutGraph' style='border-left: 1rem solid " +leyColor[1]+"'>"+data[i].label+"</span>"

							}
							$(".mod_charts.chs-cartera").append(leyenda+"</div>")
							$(".slice");
//							var legend = svg
//							.selectAll('.legend')
//							.data(color.domain())
//							.enter()
//							.append('g')
//							.attr('class', 'legend')
//							.attr(
//							'transform',
//							function(d, i) {
//							var height = legendRectSize
//							+ legendSpacing;
//							var offset = height
//							* color
//							.domain().length
//							/ 2;
//							var horz = -13
//							* legendRectSize
//							+ 180 * i;
//							var vert = 300;
//							return 'translate('
//							+ horz + ','
//							+ vert + ')';
//							});
//							legend.append('rect').attr('width',
//							legendRectSize).attr('height',
//							legendRectSize)
//							.style('fill', color).style(
//							'stroke', color);
//							legend.append('text').attr('x',
//							legendRectSize + legendSpacing)
//							.attr(
//							'y',
//							legendRectSize
//							- legendSpacing)
//							.text(function(d) {
//							return d;
//							});
							var text = svg.select(".labelName")
							.selectAll("text").data(pie(data),
									function(d) {
								return d.data.label
							});
							text.enter().append("text").attr("dy",
							".35em").text(function(d) {
								return (d.value + "%");
							});
							function midAngle(d) {
								return d.startAngle
								+ (d.endAngle - d.startAngle)
								/ 2;
							}


							var minDiff = 15;
							var minDiff2 = 60;
							var alturaPrevia = 0;
							text.transition().duration(1000).attrTween("transform", function(d) {
								this._current = this._current || d;
								var interpolate = d3.interpolate(this._current, d);
								this._current = interpolate(0);
								return function(t) {
									var d2 = interpolate(t);
									var pos = outerArc.centroid(d2);
									pos[0] = radius * (midAngle(d2) < Math.PI ? 1 : -1);
									if (alturaPrevia) {
										if (Math.abs(alturaPrevia - pos[1]) < minDiff2 && pos[1] < 0) {
											pos[1] = alturaPrevia + minDiff;
										} else if (Math.abs(alturaPrevia - pos[1]) < minDiff2 && pos[1] > 0) {
											pos[1] = alturaPrevia - minDiff;
										}
									}
									alturaPrevia = pos[1];
									return "translate(" + pos + ")";
								};
							})
							.styleTween("text-anchor", function(d) {
								this._current = this._current || d;
								var interpolate = d3.interpolate(this._current, d);
								this._current = interpolate(0);
								return function(t) {
									var d2 = interpolate(t);
									return midAngle(d2) < Math.PI ? "start" : "end";
								};
							})
							.text(function(d) {
								return (d.value + "%");
							});


							text.exit()
							.remove();

							/* ------- SLICE TO TEXT POLYLINES -------*/

							var polyline = svg.select(".lines").selectAll("polyline")
							.data(pie(data), function(d) {
								return d.data.label
							});

							polyline.enter()
							.append("polyline");

							var alturaPrevia;
							polyline.transition().duration(1000).attrTween("points", function(d) {
								this._current = this._current || d;
								var interpolate = d3.interpolate(this._current, d);
								this._current = interpolate(0);
								return function(t) {
									var d2 = interpolate(t);
									var pos = outerArc.centroid(d2);
									pos[0] = radius * 0.95 * (midAngle(d2) < Math.PI ? 1 : -1);

									outer = outerArc.centroid(d2);

									if (alturaPrevia) {
										if (Math.abs(alturaPrevia - pos[1]) < minDiff2 && pos[1] < 0) {
											pos[1] = alturaPrevia + minDiff;
											outer[1] = alturaPrevia + minDiff;
										} else if (Math.abs(alturaPrevia - pos[1]) < minDiff2 && pos[1] > 0) {
											pos[1] = alturaPrevia - minDiff;
											outer[1] = alturaPrevia - minDiff;
										}
									}
									alturaPrevia = pos[1];

									return [arc.centroid(d2), outer, pos];
								};
							});
							polyline.exit().remove();
						}
						;
					} else if ($(this).attr("data-chart") == "valoresCalc" && vlpGraficaCalc!= '') {
						var margin = {
								top : 20,
								right : 50,
								bottom : 30,
								left : 50
						}, width = 960 - margin.left - margin.right, height = 500
						- margin.top - margin.bottom;
						var parseDate = d3.time.format("%d-%b-%y").parse, bisectDate = d3
						.bisector(function(d) {
							return d.date;
						}).left, formatValue = d3
						.format(",.2f"), formatCurrency = function(
								d) {
							return "" + formatValue(d);
						};
						var x = d3.time.scale().range([ 0, width ]);
						var y = d3.scale.linear().range([ height, 0 ]);
						var xAxis = d3.svg.axis().scale(x).orient(
						"bottom");
						var yAxis = d3.svg.axis().scale(y).orient(
						"left");
						var line = d3.svg.line().x(function(d) {
							return x(d.date);
						}).y(function(d) {
							return y(d.close);
						});
						var svg = d3.select(this).append("svg:svg")
						.attr("preserveAspectRatio",
						"xMinYMin meet").attr(
								"viewBox", "0 0 960 500")
								.append("g").attr(
										"transform",
										"translate(" + margin.left
										+ "," + margin.top
										+ ")");
						var data = vlpGraficaCalc;
						data.forEach(function(d) {
							d.date = parseDate(d.date);
							d.close = +d.close;
						});
						data.sort(function(a, b) {
							return a.date - b.date;
						});
						x.domain([ data[0].date,
						           data[data.length - 1].date ]);
						y.domain(d3.extent(data, function(d) {
							return d.close;
						}));
						svg.append("g").attr("class", "x axis").attr(
								"transform",
								"translate(0," + height + ")").call(
										xAxis);
						svg.append("g").attr("class", "y axis").call(
								yAxis).append("text").attr("transform",
								"rotate(-90)").attr("y", 6).attr("dy",
								".71em").style("text-anchor", "end")
								.text("");
						svg.append("path").datum(data).attr("class",
						"line").attr("d", line);
						var focus = svg.append("g").attr("class",
						"focus").style("display", "none");
						focus.append("circle").attr("r", 4.5);
						focus.append("text").attr("x", 9).attr("dy",
						".35em");
						svg.append("rect").attr("class", "overlay")
						.attr("width", width).attr("height",
								height).on(
										"mouseover",
										function() {
											focus
											.style("display",
													null);
										}).on("mouseout", function() {
											focus.style("display", "none");
										}).on("mousemove", mousemove);
						function mousemove() {
							var x0 = x.invert(d3.mouse(this)[0]), i = bisectDate(
									data, x0, 1), d0 = data[i - 1], d1 = data[i], d = x0
									- d0.date > d1.date - x0 ? d1 : d0;
									focus.attr("transform", "translate("
											+ x(d.date) + "," + y(d.close)
											+ ")");
									focus.select("text").text(
											formatCurrency(d.close));
						}
					} else {
						console
						.log("Este tipo de grafica no esta definida.")
					}
				});
		/*
	function columnChart() {
	    var margin = {
		top : 50,
		right : 10,
		bottom : 50,
		left : 50
	    }, width = 960, height = 500, xRoundBands = 0.2, xValue = function(
		    d) {
		return d[0];
	    }, yValue = function(d) {
		return d[1];
	    }, xScale = d3.scale.ordinal(), yScale = d3.scale.linear(), yAxis = d3.svg
		    .axis().scale(yScale).orient("left"), xAxis = d3.svg.axis()
		    .scale(xScale);
	    function chart(selection) {
		selection.each(function(data) {
		    data = data.map(function(d, i) {
			return [ xValue.call(data, d, i),
				yValue.call(data, d, i) ];
		    });
		    xScale.domain(data.map(function(d) {
			return d[0];
		    })).rangeRoundBands(
			    [ 0, width - margin.left - margin.right ],
			    xRoundBands);
		    yScale.domain(d3.extent(data.map(function(d) {
			return d[1];
		    }))).range([ height - margin.top - margin.bottom, 0 ])
			    .nice();
		    var svg = d3.select(this).selectAll("svg").data([ data ]);
		    var gEnter = svg.enter().append("svg:svg").append("g");
		    gEnter.append("g").attr("class", "bars");
		    gEnter.append("g").attr("class", "y axis");
		    gEnter.append("g").attr("class", "x axis");
		    gEnter.append("g").attr("class", "x axis zero");
		    svg.attr("preserveAspectRatio", "xMinYMin meet").attr(
			    "viewBox", "0 0 960 500")
		    var g = svg.select("g")
			    .attr(
				    "transform",
				    "translate(" + margin.left + ","
					    + margin.top + ")");
		    var bar = svg.select(".bars").selectAll(".bar").data(data);
		    bar.enter().append("rect");
		    bar.exit().remove();
		    bar.attr("class", function(d, i) {
			return d[1] < 0 ? "bar negative" : "bar positive";
		    }).attr("x", function(d) {
			return X(d);
		    }).attr("y", function(d, i) {
			return d[1] < 0 ? Y0() : Y(d);
		    }).attr("width", xScale.rangeBand()).attr("height",
			    function(d, i) {
				return Math.abs(Y(d) - Y0());
			    });
		    g.select(".x.axis").attr(
			    "transform",
			    "translate(0,"
				    + (height - margin.top - margin.bottom)
				    + ")").call(xAxis.orient("bottom")).attr(
			    "cx", "-25").attr("cy", "2")
		    g.select(".x.axis.zero").attr("transform",
			    "translate(0," + Y0() + ")").call(
			    xAxis.tickFormat("").tickSize(0));
		    g.select(".y.axis").call(yAxis);
		});
	    }
	    function X(d) {
		return xScale(d[0]);
	    }
	    function Y0() {
		return yScale(0);
	    }
	    function Y(d) {
		return yScale(d[1]);
	    }
	    chart.margin = function(_) {
		if (!arguments.length)
		    return margin;
		margin = _;
		return chart;
	    };
	    chart.width = function(_) {
		if (!arguments.length)
		    return width;
		width = _;
		return chart;
	    };
	    chart.height = function(_) {
		if (!arguments.length)
		    return height;
		height = _;
		return chart;
	    };
	    chart.x = function(_) {
		if (!arguments.length)
		    return xValue;
		xValue = _;
		return chart;
	    };
	    chart.y = function(_) {
		if (!arguments.length)
		    return yValue;
		yValue = _;
		return chart;
	    };
	    return chart;
	}
		 */
		function columnChart() {
			var margin = { top: 50, right: 10, bottom: 50, left: 50 },
			width = 960,
			height = 500,
			xRoundBands = 0.2,
			xValue = function(d) {
				return d[0];
			},
			yValue = function(d) {
				return d[1];
			},
			xScale = d3.scale.ordinal(),
			yScale = d3.scale.linear(),
			yAxis = d3.svg.axis().scale(yScale).orient("left"),
			xAxis = d3.svg.axis().scale(xScale);
			var allPositive = null;
			var numValues = [];

			function chart(selection) {
				selection.each(function(data) {
					// Convert data to standard representation greedily;
					// this is needed for nondeterministic accessors.

					data = data.map(function(d, i) {
						return [xValue.call(data, d, i), yValue.call(data, d, i)];
					});

					//Creamos array con solo valores numericos
					for (var i = 0; i < data.length; i++) {
						numValues.push(data[i][1]);
					}
					var min = Math.min.apply(Math,numValues);
					var max = Math.max.apply(Math,numValues);

					//ordenamos el array
					numValues.sort(function(a, b) {
						return a - b;
					});

					if (numValues[0] < 0 && numValues[numValues.length - 1] < 0) {
						allPositive = false;
						max = 0;
					} else if (numValues[0] > 0 && numValues[numValues.length - 1] > 0) {
						min = 0;
						allPositive = true;
					}


					// Update the x-scale.
					xScale
					.domain(data.map(function(d) {
						return d[0];
					}))
					.rangeRoundBands([0, width - margin.left - margin.right], xRoundBands);

					if (allPositive === null) {
						yScale
						.domain(d3.extent(data.map(function(d) {
							return d[1];
						})))
						.range([height - margin.top - margin.bottom, 0])
						.nice();
					} else {
						yScale
						.domain([min, max])
						.range([height - margin.top - margin.bottom, 0])
						.nice();
					}
					// Update the y-scale.



					// Select the svg element, if it exists.
					var svg = d3.select(this).selectAll("svg").data([data]);

					// Otherwise, create the skeletal chart.
					var gEnter = svg.enter().append("svg:svg").append("g");
					gEnter.append("g").attr("class", "bars");
					gEnter.append("g").attr("class", "y axis");
					gEnter.append("g").attr("class", "x axis");
					gEnter.append("g").attr("class", "x axis zero");

					// Update the outer dimensions.
					svg.attr("preserveAspectRatio", "xMinYMin meet");
					svg.attr("viewBox", "0 0 960 500");

					var ua = window.navigator.userAgent;
					var msie = ua.indexOf('MSIE');
					var trident = ua.indexOf('Trident');
					var rv11 = ua.indexOf('rv:11');
					if(msie > 0 || (trident > 0 && rv11 > 0)){
						svg.attr("class", "graficasIE");
					}

					// Update the inner dimensions.
					var g = svg.select("g")
					.attr("transform", "translate(" + margin.left + "," + margin.top + ")");

					// Update the bars.
					var bar = svg.select(".bars").selectAll(".bar").data(data);
					bar.enter().append("rect");
					bar.exit().remove();
					bar.attr("class", function(d, i) {
						return d[1] < 0 ? "bar negative" : "bar positive";
					})
					.attr("x", function(d) {
						return X(d);
					})
					.attr("y", function(d, i) {
						return d[1] < 0 ? Y0() : Y(d);
					})
					.attr("width", xScale.rangeBand())
					.attr("height", function(d, i) {
						return Math.abs(Y(d) - Y0());
					});

					// x axis at the bottom of the chart
					g.select(".x.axis")
					.attr("transform", "translate(0," + (height - margin.top - margin.bottom) + ")")
					//.style("fill", "red").style("font-size", "20")
					//.attr("transform", "translate(0," + (height - margin.top - margin.bottom) + ") rotate(310)")
					.call(xAxis.orient("bottom"))
					.attr("cx", "-25")
					.attr("cy", "2");

					// zero line
					g.select(".x.axis.zero")
					.attr("transform", "translate(0," + Y0() + ")")
					.call(xAxis.tickFormat("").tickSize(0));


					// Update the y-axis.
					g.select(".y.axis")
					.call(yAxis);

				});
			}


			// The x-accessor for the path generator; xScale ÃƒÂ¢Ã‹â€ Ã‹Å“ xValue.
			function X(d) {
				return xScale(d[0]);
			}

			function Y0() {
				return yScale(0);
			}

			// The x-accessor for the path generator; yScale ÃƒÂ¢Ã‹â€ Ã‹Å“ yValue.
			function Y(d) {
				return yScale(d[1]);
			}

			chart.margin = function(_) {
				if (!arguments.length) return margin;
				margin = _;
				return chart;
			};

			chart.width = function(_) {
				if (!arguments.length) return width;
				width = _;
				return chart;
			};

			chart.height = function(_) {
				if (!arguments.length) return height;
				height = _;
				return chart;
			};

			chart.x = function(_) {
				if (!arguments.length) return xValue;
				xValue = _;
				return chart;
			};

			chart.y = function(_) {
				if (!arguments.length) return yValue;
				yValue = _;
				return chart;
			};

			return chart;
		}
		return {
			columnChart : columnChart
		}
	});
	return {
		initChart : initChart
	}
})();

var mod_chart1 = (function() {
	var initChart1 = (function(selector) {
		var idChart = "";
		var item = "";
		$(selector)
		.each(
				function(index) {
					if ($(this).attr("data-chart") == "rentabilidad1" && rentabilidadAnual1!='') {
						var data = rentabilidadAnual1;
						d3.select(this).datum(data).call(
								columnChart1().x(function(d, i) {
									return d[0];
								}).y(function(d, i) {
									return d[1];
								}));
					} else if ($(this).attr("data-chart") == "rentabilidadMensual" && rentabilidadMensual!='') {
						var data = rentabilidadMensual;
						d3.select(this).datum(data).call(
								columnChart1().x(function(d, i) {
									return d[0];
								}).y(function(d, i) {
									return d[1];
								}));
					} else if ($(this).attr("data-chart") == "valoresDetalle" && vlpGrafica != '') {
						var margin = {
								top : 20,
								right : 50,
								bottom : 30,
								left : 50
						}, width = 960 - margin.left - margin.right, height = 500
						- margin.top - margin.bottom;
						var parseDate = d3.time.format("%d-%b-%y").parse, bisectDate = d3
						.bisector(function(d) {
							return d.date;
						}).left, formatValue = d3
						.format(",.2f"), formatCurrency = function(
								d) {
							return "" + formatValue(d);
						};
						var x = d3.time.scale().range([ 0, width ]);
						var y = d3.scale.linear().range([ height, 0 ]);
						var xAxis = d3.svg.axis().scale(x).orient(
						"bottom");
						var yAxis = d3.svg.axis().scale(y).orient(
						"left");
						var line = d3.svg.line().x(function(d) {
							return x(d.date);
						}).y(function(d) {
							return y(d.close);
						});
						var svg = d3.select(this).append("svg:svg")
						.attr("preserveAspectRatio",
						"xMinYMin meet").attr(
								"viewBox", "0 0 960 500")
								.append("g").attr(
										"transform",
										"translate(" + margin.left
										+ "," + margin.top
										+ ")");
						var data = vlpGrafica;

						data.forEach(function(d) {
							d.date = parseDate(d.date);
							d.close = +d.close;
						});
						data.sort(function(a, b) {
							return a.date - b.date;
						});
						x.domain([ data[0].date,
						           data[data.length - 1].date ]);
						y.domain(d3.extent(data, function(d) {
							return d.close;
						}));
						svg.append("g").attr("class", "x axis").attr(
								"transform",
								"translate(0," + height + ")").call(
										xAxis);
						svg.append("g").attr("class", "y axis").call(
								yAxis).append("text").attr("transform",
								"rotate(-90)").attr("y", 6).attr("dy",
								".71em").style("text-anchor", "end")
								.text("");
						svg.append("path").datum(data).attr("class",
						"line").attr("d", line);
						var focus = svg.append("g").attr("class",
						"focus").style("display", "none");
						focus.append("circle").attr("r", 4.5);
						focus.append("text").attr("x", 9).attr("dy",
						".35em");
						svg.append("rect").attr("class", "overlay")
						.attr("width", width).attr("height",
								height).on(
										"mouseover",
										function() {
											focus
											.style("display",
													null);
										}).on("mouseout", function() {
											focus.style("display", "none");
										}).on("mousemove", mousemove);
						function mousemove() {
							var x0 = x.invert(d3.mouse(this)[0]), i = bisectDate(
									data, x0, 1), d0 = data[i - 1], d1 = data[i], d = x0
									- d0.date > d1.date - x0 ? d1 : d0;
									focus.attr("transform", "translate("
											+ x(d.date) + "," + y(d.close)
											+ ")");
									focus.select("text").text(
											formatCurrency(d.close));
						}
					} else if ($(this).attr("data-chart") == "cartera1" && (typeof datasetTotal1 !== "undefined") && datasetTotal1 != '') {
						var svg = d3.select(this).append("svg:svg")
						.attr("preserveAspectRatio",
						"xMinYMin meet").attr(
								"viewBox", "0 0 650 400")
								.append("g")
								svg.append("g").attr("class", "slices");
						//svg.append("g").attr("class", "labelName");
						//svg.append("g").attr("class", "labelValue");
						//svg.append("g").attr("class", "lines");
						var width = 650, height = 400, radius = Math
						.min(width, height) / 2;
						var pie = d3.layout.pie().sort(null).value(
								function(d) {
									return d.value;
								});
						var arc = d3.svg.arc()
						.outerRadius(radius * 0.7).innerRadius(
								radius * 0.5);
						var outerArc = d3.svg.arc().innerRadius(
								radius * 0.9).outerRadius(radius * 0.9);
						var legendRectSize = (radius * 0.1);
						var legendSpacing = radius * 0.02;
						var div = d3.select("body").append("div").attr(
								"class", "chart-tooltip");
						svg.attr("transform", "translate(" + width / 2
								+ "," + height / 2 + ")")
								var colorRange = (d3.scale.category20());
						var color = d3.scale.ordinal().range(
								colorRange.range());
						change(datasetTotal1);
						d3
						.selectAll(
						"[data-function='fc-inputChart'], [data-function='fc-inputChart']+ui-selectmenu-button")
						.on("change", selectDataset);
						function selectDataset() {
							var value = this.value;
							if (value == "total") {
								change(datasetTotal1);
							} else if (value == "option1") {
								change(datasetOption1);
							} else if (value == "option2") {
								change(datasetOption2);
							} else if (value == "option3") {
								change(datasetOption3);
							} else if (value == "option4") {
								change(datasetOption4);
							} else if (value == "option5") {
								change(datasetOption5);
							}
						}
						function change(data) {
							var slice = svg.select(".slices")
							.selectAll("path.slice").data(
									pie(data), function(d) {
										return d.data.label
									});
							slice.enter().insert("path").style("fill",
									function(d) {
								return color(d.data.label);
							}).attr("class", "slice");
							slice
							.transition()
							.duration(1000)
							.attrTween(
									"d",
									function(d) {
										this._current = this._current
										|| d;
										var interpolate = d3
										.interpolate(
												this._current,
												d);
										this._current = interpolate(0);
										return function(t) {
											return arc(interpolate(t));
										};
									})
									slice.on("mousemove", function(d) {
										div.style("left", d3.event.pageX + 10
												+ "px");
										div.style("top", d3.event.pageY - 25
												+ "px");
										div.style("display", "block");
										div.html((d.data.label) + "<br>"
												+ (d.data.value) + "%");
									});
							slice.on("mouseout", function(d) {
								div.style("display", "none");
							});
							slice.exit().remove();
							//Eliminamos los legend
							//$(".containerLegend2").remove();

//							var leyenda = "<div class='containerLegend2'>";
//							var leyColor = "";
//							for (var i = 0; i < data.length; i++) {
//							leyColor = $(".slice")[i].style.cssText
//							leyColor = leyColor.split(":");
//							leyenda = leyenda + "<span class='legendDonutGraph' style='border-left: 1rem solid " +leyColor[1]+"'>"+data[i].label+"</span>"

//							}
//							$(".mod_charts2.chs-cartera2").append(leyenda+"</div>")
//							$(".slice");
//							var legend = svg
//							.selectAll('.legend')
//							.data(color.domain())
//							.enter()
//							.append('g')
//							.attr('class', 'legend')
//							.attr(
//							'transform',
//							function(d, i) {
//							var height = legendRectSize
//							+ legendSpacing;
//							var offset = height
//							* color
//							.domain().length
//							/ 2;
//							var horz = -13
//							* legendRectSize
//							+ 180 * i;
//							var vert = 300;
//							return 'translate('
//							+ horz + ','
//							+ vert + ')';
//							});
//							legend.append('rect').attr('width',
//							legendRectSize).attr('height',
//							legendRectSize)
//							.style('fill', color).style(
//							'stroke', color);
//							legend.append('text').attr('x',
//							legendRectSize + legendSpacing)
//							.attr(
//							'y',
//							legendRectSize
//							- legendSpacing)
//							.text(function(d) {
//							return d;
//							});
//							var text = svg.select(".labelName")
//							.selectAll("text").data(pie(data),
//							function(d) {
//							return d.data.label
//							});
//							text.enter().append("text").attr("dy",
//							".35em").text(function(d) {
//							return (d.value + "%");
//							});
							function midAngle(d) {
								return d.startAngle
								+ (d.endAngle - d.startAngle)
								/ 2;
							}
//							text
//							.transition()
//							.duration(1000)
//							.attrTween(
//							"transform",
//							function(d) {
//							this._current = this._current
//							|| d;
//							var interpolate = d3
//							.interpolate(
//							this._current,
//							d);
//							this._current = interpolate(0);
//							return function(t) {
//							var d2 = interpolate(t);
//							var pos = outerArc
//							.centroid(d2);
//							pos[0] = radius
//							* (midAngle(d2) < Math.PI ? 1
//							: -1);
//							return "translate("
//							+ pos + ")";
//							};
//							})
//							.styleTween(
//							"text-anchor",
//							function(d) {
//							this._current = this._current
//							|| d;
//							var interpolate = d3
//							.interpolate(
//							this._current,
//							d);
//							this._current = interpolate(0);
//							return function(t) {
//							var d2 = interpolate(t);
//							return midAngle(d2) < Math.PI ? "start"
//							: "end";
//							};
//							}).text(function(d) {
//							return (d.value + "%");
//							});
//							text.exit().remove();
//							var polyline = svg.select(".lines")
//							.selectAll("polyline").data(
//							pie(data), function(d) {
//							return d.data.label
//							});
//							polyline.enter().append("polyline");
//							polyline
//							.transition()
//							.duration(1000)
//							.attrTween(
//							"points",
//							function(d) {
//							this._current = this._current
//							|| d;
//							var interpolate = d3
//							.interpolate(
//							this._current,
//							d);
//							this._current = interpolate(0);
//							return function(t) {
//							var d2 = interpolate(t);
//							var pos = outerArc
//							.centroid(d2);
//							pos[0] = radius
//							* 0.95
//							* (midAngle(d2) < Math.PI ? 1
//							: -1);
//							return [
//							arc
//							.centroid(d2),
//							outerArc
//							.centroid(d2),
//							pos ];
//							};
//							});
//							polyline.exit().remove();
						}
						;
					} else if ($(this).attr("data-chart") == "valoresCalc" && vlpGraficaCalc!= '') {
						var margin = {
								top : 20,
								right : 50,
								bottom : 30,
								left : 50
						}, width = 960 - margin.left - margin.right, height = 500
						- margin.top - margin.bottom;
						var parseDate = d3.time.format("%d-%b-%y").parse, bisectDate = d3
						.bisector(function(d) {
							return d.date;
						}).left, formatValue = d3
						.format(",.2f"), formatCurrency = function(
								d) {
							return "" + formatValue(d);
						};
						var x = d3.time.scale().range([ 0, width ]);
						var y = d3.scale.linear().range([ height, 0 ]);
						var xAxis = d3.svg.axis().scale(x).orient(
						"bottom");
						var yAxis = d3.svg.axis().scale(y).orient(
						"left");
						var line = d3.svg.line().x(function(d) {
							return x(d.date);
						}).y(function(d) {
							return y(d.close);
						});
						var svg = d3.select(this).append("svg:svg")
						.attr("preserveAspectRatio",
						"xMinYMin meet").attr(
								"viewBox", "0 0 960 500")
								.append("g").attr(
										"transform",
										"translate(" + margin.left
										+ "," + margin.top
										+ ")");
						var data = vlpGraficaCalc;
						data.forEach(function(d) {
							d.date = parseDate(d.date);
							d.close = +d.close;
						});
						data.sort(function(a, b) {
							return a.date - b.date;
						});
						x.domain([ data[0].date,
						           data[data.length - 1].date ]);
						y.domain(d3.extent(data, function(d) {
							return d.close;
						}));
						svg.append("g").attr("class", "x axis").attr(
								"transform",
								"translate(0," + height + ")").call(
										xAxis);
						svg.append("g").attr("class", "y axis").call(
								yAxis).append("text").attr("transform",
								"rotate(-90)").attr("y", 6).attr("dy",
								".71em").style("text-anchor", "end")
								.text("");
						svg.append("path").datum(data).attr("class",
						"line").attr("d", line);
						var focus = svg.append("g").attr("class",
						"focus").style("display", "none");
						focus.append("circle").attr("r", 4.5);
						focus.append("text").attr("x", 9).attr("dy",
						".35em");
						svg.append("rect").attr("class", "overlay")
						.attr("width", width).attr("height",
								height).on(
										"mouseover",
										function() {
											focus
											.style("display",
													null);
										}).on("mouseout", function() {
											focus.style("display", "none");
										}).on("mousemove", mousemove);
						function mousemove() {
							var x0 = x.invert(d3.mouse(this)[0]), i = bisectDate(
									data, x0, 1), d0 = data[i - 1], d1 = data[i], d = x0
									- d0.date > d1.date - x0 ? d1 : d0;
									focus.attr("transform", "translate("
											+ x(d.date) + "," + y(d.close)
											+ ")");
									focus.select("text").text(
											formatCurrency(d.close));
						}
					} else {
						console
						.log("Este tipo de grafica no esta definida.")
					}
				});
		function columnChart1() {
			var margin = {
					top : 50,
					right : 10,
					bottom : 50,
					left : 50
			}, width = 960, height = 500, xRoundBands = 0.2, xValue = function(
					d) {
				return d[0];
			}, yValue = function(d) {
				return d[1];
			}, xScale = d3.scale.ordinal(), yScale = d3.scale.linear(), yAxis = d3.svg
			.axis().scale(yScale).orient("left"), xAxis = d3.svg.axis()
			.scale(xScale);
			function chart(selection) {
				selection.each(function(data) {
					data = data.map(function(d, i) {
						return [ xValue.call(data, d, i),
						         yValue.call(data, d, i) ];
					});
					xScale.domain(data.map(function(d) {
						return d[0];
					})).rangeRoundBands(
							[ 0, width - margin.left - margin.right ],
							xRoundBands);
					yScale.domain(d3.extent(data.map(function(d) {
						return d[1]-1;
					}))).range([ height - margin.top - margin.bottom, 0 ])
					.nice();
					var svg = d3.select(this).selectAll("svg").data([ data ]);
					var gEnter = svg.enter().append("svg:svg").append("g");
					gEnter.append("g").attr("class", "bars");
					gEnter.append("g").attr("class", "y axis");
					gEnter.append("g").attr("class", "x axis");
					gEnter.append("g").attr("class", "x axis zero");
					svg.attr("preserveAspectRatio", "xMinYMin meet").attr(
							"viewBox", "0 0 960 500")
							var g = svg.select("g")
							.attr(
									"transform",
									"translate(" + margin.left + ","
									+ margin.top + ")");
					var bar = svg.select(".bars").selectAll(".bar").data(data);
					bar.enter().append("rect");
					bar.exit().remove();
					bar.attr("class", function(d, i) {
						return d[1] < 0 ? "bar negative" : "bar positive";
					}).attr("x", function(d) {
						return X(d);
					}).attr("y", function(d, i) {
						return d[1] < 0 ? Y0() : Y(d);
					}).attr("width", xScale.rangeBand()).attr("height",
							function(d, i) {
						return Math.abs(Y(d) - Y0());
					});
					g.select(".x.axis").attr(
							"transform",
							"translate(0,"
							+ (height - margin.top - margin.bottom)
							+ ")").call(xAxis.orient("bottom")).attr(
									"cx", "-25").attr("cy", "2")
									g.select(".x.axis.zero").attr("transform",
											"translate(0," + Y0() + ")").call(
													xAxis.tickFormat("").tickSize(0));
					g.select(".y.axis").call(yAxis);
				});
			}
			function X(d) {
				return xScale(d[0]);
			}
			function Y0() {
				return yScale(0);
			}
			function Y(d) {
				return yScale(d[1]);
			}
			chart.margin = function(_) {
				if (!arguments.length)
					return margin;
				margin = _;
				return chart;
			};
			chart.width = function(_) {
				if (!arguments.length)
					return width;
				width = _;
				return chart;
			};
			chart.height = function(_) {
				if (!arguments.length)
					return height;
				height = _;
				return chart;
			};
			chart.x = function(_) {
				if (!arguments.length)
					return xValue;
				xValue = _;
				return chart;
			};
			chart.y = function(_) {
				if (!arguments.length)
					return yValue;
				yValue = _;
				return chart;
			};
			return chart;
		}
		return {
			columnChart1 : columnChart1
		}
	});
	return {
		initChart1 : initChart1
	}
})();

var mod_chart2 = (function() {
	var initChart2 = (function(selector) {
		var idChart = "";
		var item = "";
		$(selector)
		.each(
				function(index) {
					if ($(this).attr("data-chart") == "rentabilidad2" && rentabilidadAnual2!='') {
						var data = rentabilidadAnual2;
						d3.select(this).datum(data).call(
								columnChart2().x(function(d, i) {
									return d[0];
								}).y(function(d, i) {
									return d[1];
								}));
					} else if ($(this).attr("data-chart") == "rentabilidadMensual" && rentabilidadMensual!='') {
						var data = rentabilidadMensual;
						d3.select(this).datum(data).call(
								columnChart2().x(function(d, i) {
									return d[0];
								}).y(function(d, i) {
									return d[1];
								}));
					} else if ($(this).attr("data-chart") == "valoresDetalle" && vlpGrafica != '') {
						var margin = {
								top : 20,
								right : 50,
								bottom : 30,
								left : 50
						}, width = 960 - margin.left - margin.right, height = 500
						- margin.top - margin.bottom;
						var parseDate = d3.time.format("%d-%b-%y").parse, bisectDate = d3
						.bisector(function(d) {
							return d.date;
						}).left, formatValue = d3
						.format(",.2f"), formatCurrency = function(
								d) {
							return "" + formatValue(d);
						};
						var x = d3.time.scale().range([ 0, width ]);
						var y = d3.scale.linear().range([ height, 0 ]);
						var xAxis = d3.svg.axis().scale(x).orient(
						"bottom");
						var yAxis = d3.svg.axis().scale(y).orient(
						"left");
						var line = d3.svg.line().x(function(d) {
							return x(d.date);
						}).y(function(d) {
							return y(d.close);
						});
						var svg = d3.select(this).append("svg:svg")
						.attr("preserveAspectRatio",
						"xMinYMin meet").attr(
								"viewBox", "0 0 960 500")
								.append("g").attr(
										"transform",
										"translate(" + margin.left
										+ "," + margin.top
										+ ")");
						var data = vlpGrafica;

						data.forEach(function(d) {
							d.date = parseDate(d.date);
							d.close = +d.close;
						});
						data.sort(function(a, b) {
							return a.date - b.date;
						});
						x.domain([ data[0].date,
						           data[data.length - 1].date ]);
						y.domain(d3.extent(data, function(d) {
							return d.close;
						}));
						svg.append("g").attr("class", "x axis").attr(
								"transform",
								"translate(0," + height + ")").call(
										xAxis);
						svg.append("g").attr("class", "y axis").call(
								yAxis).append("text").attr("transform",
								"rotate(-90)").attr("y", 6).attr("dy",
								".71em").style("text-anchor", "end")
								.text("");
						svg.append("path").datum(data).attr("class",
						"line").attr("d", line);
						var focus = svg.append("g").attr("class",
						"focus").style("display", "none");
						focus.append("circle").attr("r", 4.5);
						focus.append("text").attr("x", 9).attr("dy",
						".35em");
						svg.append("rect").attr("class", "overlay")
						.attr("width", width).attr("height",
								height).on(
										"mouseover",
										function() {
											focus
											.style("display",
													null);
										}).on("mouseout", function() {
											focus.style("display", "none");
										}).on("mousemove", mousemove);
						function mousemove() {
							var x0 = x.invert(d3.mouse(this)[0]), i = bisectDate(
									data, x0, 1), d0 = data[i - 1], d1 = data[i], d = x0
									- d0.date > d1.date - x0 ? d1 : d0;
									focus.attr("transform", "translate("
											+ x(d.date) + "," + y(d.close)
											+ ")");
									focus.select("text").text(
											formatCurrency(d.close));
						}
					} else if ($(this).attr("data-chart") == "cartera2"  && (typeof datasetTotal2 !== "undefined") && datasetTotal2 != '') {
						var svg = d3.select(this).append("svg:svg")
						.attr("preserveAspectRatio",
						"xMinYMin meet").attr(
								"viewBox", "0 0 650 400")
								.append("g")
								svg.append("g").attr("class", "slices");
						//svg.append("g").attr("class", "labelName");
						//svg.append("g").attr("class", "labelValue");
						//svg.append("g").attr("class", "lines");
						var width = 650, height = 400, radius = Math
						.min(width, height) / 2;
						var pie = d3.layout.pie().sort(null).value(
								function(d) {
									return d.value;
								});
						var arc = d3.svg.arc()
						.outerRadius(radius * 0.7).innerRadius(
								radius * 0.5);
						var outerArc = d3.svg.arc().innerRadius(
								radius * 0.9).outerRadius(radius * 0.9);
						var legendRectSize = (radius * 0.1);
						var legendSpacing = radius * 0.02;
						var div = d3.select("body").append("div").attr(
								"class", "chart-tooltip");
						svg.attr("transform", "translate(" + width / 2
								+ "," + height / 2 + ")")
								var colorRange = (d3.scale.category20());
						var color = d3.scale.ordinal().range(
								colorRange.range());
						change(datasetTotal2);
						d3
						.selectAll(
						"[data-function='fc-inputChart'], [data-function='fc-inputChart']+ui-selectmenu-button")
						.on("change", selectDataset);
						function selectDataset() {
							var value = this.value;
							if (value == "total") {
								change(datasetTotal2);
							} else if (value == "option1") {
								change(datasetOption1);
							} else if (value == "option2") {
								change(datasetOption2);
							} else if (value == "option3") {
								change(datasetOption3);
							} else if (value == "option4") {
								change(datasetOption4);
							} else if (value == "option5") {
								change(datasetOption5);
							}
						}
						function change(data) {
							var slice = svg.select(".slices")
							.selectAll("path.slice").data(
									pie(data), function(d) {
										return d.data.label
									});
							slice.enter().insert("path").style("fill",
									function(d) {
								return color(d.data.label);
							}).attr("class", "slice");
							slice
							.transition()
							.duration(1000)
							.attrTween(
									"d",
									function(d) {
										this._current = this._current
										|| d;
										var interpolate = d3
										.interpolate(
												this._current,
												d);
										this._current = interpolate(0);
										return function(t) {
											return arc(interpolate(t));
										};
									})
									slice.on("mousemove", function(d) {
										div.style("left", d3.event.pageX + 10
												+ "px");
										div.style("top", d3.event.pageY - 25
												+ "px");
										div.style("display", "block");
										div.html((d.data.label) + "<br>"
												+ (d.data.value) + "%");
									});
							slice.on("mouseout", function(d) {
								div.style("display", "none");
							});
							slice.exit().remove();
							//Eliminamos los legend
							//$(".containerLegend2").remove();

//							var leyenda = "<div class='containerLegend2'>";
//							var leyColor = "";
//							for (var i = 0; i < data.length; i++) {
//							leyColor = $(".slice")[i].style.cssText
//							leyColor = leyColor.split(":");
//							leyenda = leyenda + "<span class='legendDonutGraph' style='border-left: 1rem solid " +leyColor[1]+"'>"+data[i].label+"</span>"

//							}
//							$(".mod_charts2.chs-cartera2").append(leyenda+"</div>")
//							$(".slice");
//							var legend = svg
//							.selectAll('.legend')
//							.data(color.domain())
//							.enter()
//							.append('g')
//							.attr('class', 'legend')
//							.attr(
//							'transform',
//							function(d, i) {
//							var height = legendRectSize
//							+ legendSpacing;
//							var offset = height
//							* color
//							.domain().length
//							/ 2;
//							var horz = -13
//							* legendRectSize
//							+ 180 * i;
//							var vert = 300;
//							return 'translate('
//							+ horz + ','
//							+ vert + ')';
//							});
//							legend.append('rect').attr('width',
//							legendRectSize).attr('height',
//							legendRectSize)
//							.style('fill', color).style(
//							'stroke', color);
//							legend.append('text').attr('x',
//							legendRectSize + legendSpacing)
//							.attr(
//							'y',
//							legendRectSize
//							- legendSpacing)
//							.text(function(d) {
//							return d;
//							});
//							var text = svg.select(".labelName")
//							.selectAll("text").data(pie(data),
//							function(d) {
//							return d.data.label
//							});
//							text.enter().append("text").attr("dy",
//							".35em").text(function(d) {
//							return (d.value + "%");
//							});
							function midAngle(d) {
								return d.startAngle
								+ (d.endAngle - d.startAngle)
								/ 2;
							}
//							text
//							.transition()
//							.duration(1000)
//							.attrTween(
//							"transform",
//							function(d) {
//							this._current = this._current
//							|| d;
//							var interpolate = d3
//							.interpolate(
//							this._current,
//							d);
//							this._current = interpolate(0);
//							return function(t) {
//							var d2 = interpolate(t);
//							var pos = outerArc
//							.centroid(d2);
//							pos[0] = radius
//							* (midAngle(d2) < Math.PI ? 1
//							: -1);
//							return "translate("
//							+ pos + ")";
//							};
//							})
//							.styleTween(
//							"text-anchor",
//							function(d) {
//							this._current = this._current
//							|| d;
//							var interpolate = d3
//							.interpolate(
//							this._current,
//							d);
//							this._current = interpolate(0);
//							return function(t) {
//							var d2 = interpolate(t);
//							return midAngle(d2) < Math.PI ? "start"
//							: "end";
//							};
//							}).text(function(d) {
//							return (d.value + "%");
//							});
//							text.exit().remove();
//							var polyline = svg.select(".lines")
//							.selectAll("polyline").data(
//							pie(data), function(d) {
//							return d.data.label
//							});
//							polyline.enter().append("polyline");
//							polyline
//							.transition()
//							.duration(1000)
//							.attrTween(
//							"points",
//							function(d) {
//							this._current = this._current
//							|| d;
//							var interpolate = d3
//							.interpolate(
//							this._current,
//							d);
//							this._current = interpolate(0);
//							return function(t) {
//							var d2 = interpolate(t);
//							var pos = outerArc
//							.centroid(d2);
//							pos[0] = radius
//							* 0.95
//							* (midAngle(d2) < Math.PI ? 1
//							: -1);
//							return [
//							arc
//							.centroid(d2),
//							outerArc
//							.centroid(d2),
//							pos ];
//							};
//							});
//							polyline.exit().remove();
						}
						;
					} else if ($(this).attr("data-chart") == "valoresCalc" && vlpGraficaCalc!= '') {
						var margin = {
								top : 20,
								right : 50,
								bottom : 30,
								left : 50
						}, width = 960 - margin.left - margin.right, height = 500
						- margin.top - margin.bottom;
						var parseDate = d3.time.format("%d-%b-%y").parse, bisectDate = d3
						.bisector(function(d) {
							return d.date;
						}).left, formatValue = d3
						.format(",.2f"), formatCurrency = function(
								d) {
							return "" + formatValue(d);
						};
						var x = d3.time.scale().range([ 0, width ]);
						var y = d3.scale.linear().range([ height, 0 ]);
						var xAxis = d3.svg.axis().scale(x).orient(
						"bottom");
						var yAxis = d3.svg.axis().scale(y).orient(
						"left");
						var line = d3.svg.line().x(function(d) {
							return x(d.date);
						}).y(function(d) {
							return y(d.close);
						});
						var svg = d3.select(this).append("svg:svg")
						.attr("preserveAspectRatio",
						"xMinYMin meet").attr(
								"viewBox", "0 0 960 500")
								.append("g").attr(
										"transform",
										"translate(" + margin.left
										+ "," + margin.top
										+ ")");
						var data = vlpGraficaCalc;
						data.forEach(function(d) {
							d.date = parseDate(d.date);
							d.close = +d.close;
						});
						data.sort(function(a, b) {
							return a.date - b.date;
						});
						x.domain([ data[0].date,
						           data[data.length - 1].date ]);
						y.domain(d3.extent(data, function(d) {
							return d.close;
						}));
						svg.append("g").attr("class", "x axis").attr(
								"transform",
								"translate(0," + height + ")").call(
										xAxis);
						svg.append("g").attr("class", "y axis").call(
								yAxis).append("text").attr("transform",
								"rotate(-90)").attr("y", 6).attr("dy",
								".71em").style("text-anchor", "end")
								.text("");
						svg.append("path").datum(data).attr("class",
						"line").attr("d", line);
						var focus = svg.append("g").attr("class",
						"focus").style("display", "none");
						focus.append("circle").attr("r", 4.5);
						focus.append("text").attr("x", 9).attr("dy",
						".35em");
						svg.append("rect").attr("class", "overlay")
						.attr("width", width).attr("height",
								height).on(
										"mouseover",
										function() {
											focus
											.style("display",
													null);
										}).on("mouseout", function() {
											focus.style("display", "none");
										}).on("mousemove", mousemove);
						function mousemove() {
							var x0 = x.invert(d3.mouse(this)[0]), i = bisectDate(
									data, x0, 1), d0 = data[i - 1], d1 = data[i], d = x0
									- d0.date > d1.date - x0 ? d1 : d0;
									focus.attr("transform", "translate("
											+ x(d.date) + "," + y(d.close)
											+ ")");
									focus.select("text").text(
											formatCurrency(d.close));
						}
					} else {
						console
						.log("Este tipo de gráfica no esta definida.")
					}
				});
		function columnChart2() {
			var margin = {
					top : 50,
					right : 10,
					bottom : 50,
					left : 50
			}, width = 960, height = 500, xRoundBands = 0.2, xValue = function(
					d) {
				return d[0];
			}, yValue = function(d) {
				return d[1];
			}, xScale = d3.scale.ordinal(), yScale = d3.scale.linear(), yAxis = d3.svg
			.axis().scale(yScale).orient("left"), xAxis = d3.svg.axis()
			.scale(xScale);
			function chart(selection) {
				selection.each(function(data) {
					data = data.map(function(d, i) {
						return [ xValue.call(data, d, i),
						         yValue.call(data, d, i) ];
					});
					xScale.domain(data.map(function(d) {
						return d[0];
					})).rangeRoundBands(
							[ 0, width - margin.left - margin.right ],
							xRoundBands);
					yScale.domain(d3.extent(data.map(function(d) {
						return d[1];
					}))).range([ height - margin.top - margin.bottom, 0 ])
					.nice();
					var svg = d3.select(this).selectAll("svg").data([ data ]);
					var gEnter = svg.enter().append("svg:svg").append("g");
					gEnter.append("g").attr("class", "bars");
					gEnter.append("g").attr("class", "y axis");
					gEnter.append("g").attr("class", "x axis");
					gEnter.append("g").attr("class", "x axis zero");
					svg.attr("preserveAspectRatio", "xMinYMin meet").attr(
							"viewBox", "0 0 960 500")
							var g = svg.select("g")
							.attr(
									"transform",
									"translate(" + margin.left + ","
									+ margin.top + ")");
					var bar = svg.select(".bars").selectAll(".bar").data(data);
					bar.enter().append("rect");
					bar.exit().remove();
					bar.attr("class", function(d, i) {
						return d[1] < 0 ? "bar negative" : "bar positive";
					}).attr("x", function(d) {
						return X(d);
					}).attr("y", function(d, i) {
						return d[1] < 0 ? Y0() : Y(d);
					}).attr("width", xScale.rangeBand()).attr("height",
							function(d, i) {
						return Math.abs(Y(d) - Y0());
					});
					g.select(".x.axis").attr(
							"transform",
							"translate(0,"
							+ (height - margin.top - margin.bottom)
							+ ")").call(xAxis.orient("bottom")).attr(
									"cx", "-25").attr("cy", "2")
									g.select(".x.axis.zero").attr("transform",
											"translate(0," + Y0() + ")").call(
													xAxis.tickFormat("").tickSize(0));
					g.select(".y.axis").call(yAxis);
				});
			}
			function X(d) {
				return xScale(d[0]);
			}
			function Y0() {
				return yScale(0);
			}
			function Y(d) {
				return yScale(d[1]);
			}
			chart.margin = function(_) {
				if (!arguments.length)
					return margin;
				margin = _;
				return chart;
			};
			chart.width = function(_) {
				if (!arguments.length)
					return width;
				width = _;
				return chart;
			};
			chart.height = function(_) {
				if (!arguments.length)
					return height;
				height = _;
				return chart;
			};
			chart.x = function(_) {
				if (!arguments.length)
					return xValue;
				xValue = _;
				return chart;
			};
			chart.y = function(_) {
				if (!arguments.length)
					return yValue;
				yValue = _;
				return chart;
			};
			return chart;
		}
		return {
			columnChart2 : columnChart2
		}
	});
	return {
		initChart2 : initChart2
	}
})();

var mod_chart3 = (function() {
	var initChart3 = (function(selector) {
		var idChart = "";
		var item = "";
		$(selector)
		.each(
				function(index) {
					if ($(this).attr("data-chart") == "rentabilidad3" && rentabilidadAnual3!='') {
						var data = rentabilidadAnual3;
						d3.select(this).datum(data).call(
								columnChart3().x(function(d, i) {
									return d[0];
								}).y(function(d, i) {
									return d[1];
								}));
					} else if ($(this).attr("data-chart") == "rentabilidadMensual" && rentabilidadMensual!='') {
						var data = rentabilidadMensual;
						d3.select(this).datum(data).call(
								columnChart3().x(function(d, i) {
									return d[0];
								}).y(function(d, i) {
									return d[1];
								}));
					} else if ($(this).attr("data-chart") == "valoresDetalle" && vlpGrafica != '') {
						var margin = {
								top : 20,
								right : 50,
								bottom : 30,
								left : 50
						}, width = 960 - margin.left - margin.right, height = 500
						- margin.top - margin.bottom;
						var parseDate = d3.time.format("%d-%b-%y").parse, bisectDate = d3
						.bisector(function(d) {
							return d.date;
						}).left, formatValue = d3
						.format(",.2f"), formatCurrency = function(
								d) {
							return "" + formatValue(d);
						};
						var x = d3.time.scale().range([ 0, width ]);
						var y = d3.scale.linear().range([ height, 0 ]);
						var xAxis = d3.svg.axis().scale(x).orient(
						"bottom");
						var yAxis = d3.svg.axis().scale(y).orient(
						"left");
						var line = d3.svg.line().x(function(d) {
							return x(d.date);
						}).y(function(d) {
							return y(d.close);
						});
						var svg = d3.select(this).append("svg:svg")
						.attr("preserveAspectRatio",
						"xMinYMin meet").attr(
								"viewBox", "0 0 960 500")
								.append("g").attr(
										"transform",
										"translate(" + margin.left
										+ "," + margin.top
										+ ")");
						var data = vlpGrafica;

						data.forEach(function(d) {
							d.date = parseDate(d.date);
							d.close = +d.close;
						});
						data.sort(function(a, b) {
							return a.date - b.date;
						});
						x.domain([ data[0].date,
						           data[data.length - 1].date ]);
						y.domain(d3.extent(data, function(d) {
							return d.close;
						}));
						svg.append("g").attr("class", "x axis").attr(
								"transform",
								"translate(0," + height + ")").call(
										xAxis);
						svg.append("g").attr("class", "y axis").call(
								yAxis).append("text").attr("transform",
								"rotate(-90)").attr("y", 6).attr("dy",
								".71em").style("text-anchor", "end")
								.text("");
						svg.append("path").datum(data).attr("class",
						"line").attr("d", line);
						var focus = svg.append("g").attr("class",
						"focus").style("display", "none");
						focus.append("circle").attr("r", 4.5);
						focus.append("text").attr("x", 9).attr("dy",
						".35em");
						svg.append("rect").attr("class", "overlay")
						.attr("width", width).attr("height",
								height).on(
										"mouseover",
										function() {
											focus
											.style("display",
													null);
										}).on("mouseout", function() {
											focus.style("display", "none");
										}).on("mousemove", mousemove);
						function mousemove() {
							var x0 = x.invert(d3.mouse(this)[0]), i = bisectDate(
									data, x0, 1), d0 = data[i - 1], d1 = data[i], d = x0
									- d0.date > d1.date - x0 ? d1 : d0;
									focus.attr("transform", "translate("
											+ x(d.date) + "," + y(d.close)
											+ ")");
									focus.select("text").text(
											formatCurrency(d.close));
						}
					} else if ($(this).attr("data-chart") == "cartera3"  && (typeof datasetTotal3 !== "undefined") && datasetTotal3 != '') {
						var svg = d3.select(this).append("svg:svg")
						.attr("preserveAspectRatio",
						"xMinYMin meet").attr(
								"viewBox", "0 0 650 400")
								.append("g")
								svg.append("g").attr("class", "slices");
						//svg.append("g").attr("class", "labelName");
						//svg.append("g").attr("class", "labelValue");
						//svg.append("g").attr("class", "lines");
						var width = 650, height = 400, radius = Math
						.min(width, height) / 2;
						var pie = d3.layout.pie().sort(null).value(
								function(d) {
									return d.value;
								});
						var arc = d3.svg.arc()
						.outerRadius(radius * 0.7).innerRadius(
								radius * 0.5);
						var outerArc = d3.svg.arc().innerRadius(
								radius * 0.9).outerRadius(radius * 0.9);
						var legendRectSize = (radius * 0.1);
						var legendSpacing = radius * 0.02;
						var div = d3.select("body").append("div").attr(
								"class", "chart-tooltip");
						svg.attr("transform", "translate(" + width / 2
								+ "," + height / 2 + ")")
								var colorRange = (d3.scale.category20());
						var color = d3.scale.ordinal().range(
								colorRange.range());
						change(datasetTotal3);
						d3
						.selectAll(
						"[data-function='fc-inputChart'], [data-function='fc-inputChart']+ui-selectmenu-button")
						.on("change", selectDataset);
						function selectDataset() {
							var value = this.value;
							if (value == "total") {
								change(datasetTotal3);
							} else if (value == "option1") {
								change(datasetOption1);
							} else if (value == "option2") {
								change(datasetOption2);
							} else if (value == "option3") {
								change(datasetOption3);
							} else if (value == "option4") {
								change(datasetOption4);
							} else if (value == "option5") {
								change(datasetOption5);
							}
						}
						function change(data) {
							var slice = svg.select(".slices")
							.selectAll("path.slice").data(
									pie(data), function(d) {
										return d.data.label
									});
							slice.enter().insert("path").style("fill",
									function(d) {
								return color(d.data.label);
							}).attr("class", "slice");
							slice
							.transition()
							.duration(1000)
							.attrTween(
									"d",
									function(d) {
										this._current = this._current
										|| d;
										var interpolate = d3
										.interpolate(
												this._current,
												d);
										this._current = interpolate(0);
										return function(t) {
											return arc(interpolate(t));
										};
									})
									slice.on("mousemove", function(d) {
										div.style("left", d3.event.pageX + 10
												+ "px");
										div.style("top", d3.event.pageY - 25
												+ "px");
										div.style("display", "block");
										div.html((d.data.label) + "<br>"
												+ (d.data.value) + "%");
									});
							slice.on("mouseout", function(d) {
								div.style("display", "none");
							});
							slice.exit().remove();
							//Eliminamos los legend
							//$(".containerLegend2").remove();

//							var leyenda = "<div class='containerLegend2'>";
//							var leyColor = "";
//							for (var i = 0; i < data.length; i++) {
//							leyColor = $(".slice")[i].style.cssText
//							leyColor = leyColor.split(":");
//							leyenda = leyenda + "<span class='legendDonutGraph' style='border-left: 1rem solid " +leyColor[1]+"'>"+data[i].label+"</span>"

//							}
//							$(".mod_charts2.chs-cartera2").append(leyenda+"</div>")
//							$(".slice");
//							var legend = svg
//							.selectAll('.legend')
//							.data(color.domain())
//							.enter()
//							.append('g')
//							.attr('class', 'legend')
//							.attr(
//							'transform',
//							function(d, i) {
//							var height = legendRectSize
//							+ legendSpacing;
//							var offset = height
//							* color
//							.domain().length
//							/ 2;
//							var horz = -13
//							* legendRectSize
//							+ 180 * i;
//							var vert = 300;
//							return 'translate('
//							+ horz + ','
//							+ vert + ')';
//							});
//							legend.append('rect').attr('width',
//							legendRectSize).attr('height',
//							legendRectSize)
//							.style('fill', color).style(
//							'stroke', color);
//							legend.append('text').attr('x',
//							legendRectSize + legendSpacing)
//							.attr(
//							'y',
//							legendRectSize
//							- legendSpacing)
//							.text(function(d) {
//							return d;
//							});
//							var text = svg.select(".labelName")
//							.selectAll("text").data(pie(data),
//							function(d) {
//							return d.data.label
//							});
//							text.enter().append("text").attr("dy",
//							".35em").text(function(d) {
//							return (d.value + "%");
//							});
							function midAngle(d) {
								return d.startAngle
								+ (d.endAngle - d.startAngle)
								/ 2;
							}
//							text
//							.transition()
//							.duration(1000)
//							.attrTween(
//							"transform",
//							function(d) {
//							this._current = this._current
//							|| d;
//							var interpolate = d3
//							.interpolate(
//							this._current,
//							d);
//							this._current = interpolate(0);
//							return function(t) {
//							var d2 = interpolate(t);
//							var pos = outerArc
//							.centroid(d2);
//							pos[0] = radius
//							* (midAngle(d2) < Math.PI ? 1
//							: -1);
//							return "translate("
//							+ pos + ")";
//							};
//							})
//							.styleTween(
//							"text-anchor",
//							function(d) {
//							this._current = this._current
//							|| d;
//							var interpolate = d3
//							.interpolate(
//							this._current,
//							d);
//							this._current = interpolate(0);
//							return function(t) {
//							var d2 = interpolate(t);
//							return midAngle(d2) < Math.PI ? "start"
//							: "end";
//							};
//							}).text(function(d) {
//							return (d.value + "%");
//							});
//							text.exit().remove();
//							var polyline = svg.select(".lines")
//							.selectAll("polyline").data(
//							pie(data), function(d) {
//							return d.data.label
//							});
//							polyline.enter().append("polyline");
//							polyline
//							.transition()
//							.duration(1000)
//							.attrTween(
//							"points",
//							function(d) {
//							this._current = this._current
//							|| d;
//							var interpolate = d3
//							.interpolate(
//							this._current,
//							d);
//							this._current = interpolate(0);
//							return function(t) {
//							var d2 = interpolate(t);
//							var pos = outerArc
//							.centroid(d2);
//							pos[0] = radius
//							* 0.95
//							* (midAngle(d2) < Math.PI ? 1
//							: -1);
//							return [
//							arc
//							.centroid(d2),
//							outerArc
//							.centroid(d2),
//							pos ];
//							};
//							});
//							polyline.exit().remove();
						}
						;
					} else if ($(this).attr("data-chart") == "valoresCalc" && vlpGraficaCalc!= '') {
						var margin = {
								top : 20,
								right : 50,
								bottom : 30,
								left : 50
						}, width = 960 - margin.left - margin.right, height = 500
						- margin.top - margin.bottom;
						var parseDate = d3.time.format("%d-%b-%y").parse, bisectDate = d3
						.bisector(function(d) {
							return d.date;
						}).left, formatValue = d3
						.format(",.2f"), formatCurrency = function(
								d) {
							return "" + formatValue(d);
						};
						var x = d3.time.scale().range([ 0, width ]);
						var y = d3.scale.linear().range([ height, 0 ]);
						var xAxis = d3.svg.axis().scale(x).orient(
						"bottom");
						var yAxis = d3.svg.axis().scale(y).orient(
						"left");
						var line = d3.svg.line().x(function(d) {
							return x(d.date);
						}).y(function(d) {
							return y(d.close);
						});
						var svg = d3.select(this).append("svg:svg")
						.attr("preserveAspectRatio",
						"xMinYMin meet").attr(
								"viewBox", "0 0 960 500")
								.append("g").attr(
										"transform",
										"translate(" + margin.left
										+ "," + margin.top
										+ ")");
						var data = vlpGraficaCalc;
						data.forEach(function(d) {
							d.date = parseDate(d.date);
							d.close = +d.close;
						});
						data.sort(function(a, b) {
							return a.date - b.date;
						});
						x.domain([ data[0].date,
						           data[data.length - 1].date ]);
						y.domain(d3.extent(data, function(d) {
							return d.close;
						}));
						svg.append("g").attr("class", "x axis").attr(
								"transform",
								"translate(0," + height + ")").call(
										xAxis);
						svg.append("g").attr("class", "y axis").call(
								yAxis).append("text").attr("transform",
								"rotate(-90)").attr("y", 6).attr("dy",
								".71em").style("text-anchor", "end")
								.text("");
						svg.append("path").datum(data).attr("class",
						"line").attr("d", line);
						var focus = svg.append("g").attr("class",
						"focus").style("display", "none");
						focus.append("circle").attr("r", 4.5);
						focus.append("text").attr("x", 9).attr("dy",
						".35em");
						svg.append("rect").attr("class", "overlay")
						.attr("width", width).attr("height",
								height).on(
										"mouseover",
										function() {
											focus
											.style("display",
													null);
										}).on("mouseout", function() {
											focus.style("display", "none");
										}).on("mousemove", mousemove);
						function mousemove() {
							var x0 = x.invert(d3.mouse(this)[0]), i = bisectDate(
									data, x0, 1), d0 = data[i - 1], d1 = data[i], d = x0
									- d0.date > d1.date - x0 ? d1 : d0;
									focus.attr("transform", "translate("
											+ x(d.date) + "," + y(d.close)
											+ ")");
									focus.select("text").text(
											formatCurrency(d.close));
						}
					} else {
						console
						.log("Este tipo de grafica no esta definida.")
					}
				});
		function columnChart3() {
			var margin = {
					top : 50,
					right : 10,
					bottom : 50,
					left : 50
			}, width = 960, height = 500, xRoundBands = 0.2, xValue = function(
					d) {
				return d[0];
			}, yValue = function(d) {
				return d[1];
			}, xScale = d3.scale.ordinal(), yScale = d3.scale.linear(), yAxis = d3.svg
			.axis().scale(yScale).orient("left"), xAxis = d3.svg.axis()
			.scale(xScale);
			function chart(selection) {
				selection.each(function(data) {
					data = data.map(function(d, i) {
						return [ xValue.call(data, d, i),
						         yValue.call(data, d, i) ];
					});
					xScale.domain(data.map(function(d) {
						return d[0];
					})).rangeRoundBands(
							[ 0, width - margin.left - margin.right ],
							xRoundBands);
					yScale.domain(d3.extent(data.map(function(d) {
						return d[1];
					}))).range([ height - margin.top - margin.bottom, 0 ])
					.nice();
					var svg = d3.select(this).selectAll("svg").data([ data ]);
					var gEnter = svg.enter().append("svg:svg").append("g");
					gEnter.append("g").attr("class", "bars");
					gEnter.append("g").attr("class", "y axis");
					gEnter.append("g").attr("class", "x axis");
					gEnter.append("g").attr("class", "x axis zero");
					svg.attr("preserveAspectRatio", "xMinYMin meet").attr(
							"viewBox", "0 0 960 500")
							var g = svg.select("g")
							.attr(
									"transform",
									"translate(" + margin.left + ","
									+ margin.top + ")");
					var bar = svg.select(".bars").selectAll(".bar").data(data);
					bar.enter().append("rect");
					bar.exit().remove();
					bar.attr("class", function(d, i) {
						return d[1] < 0 ? "bar negative" : "bar positive";
					}).attr("x", function(d) {
						return X(d);
					}).attr("y", function(d, i) {
						return d[1] < 0 ? Y0() : Y(d);
					}).attr("width", xScale.rangeBand()).attr("height",
							function(d, i) {
						return Math.abs(Y(d) - Y0());
					});
					g.select(".x.axis").attr(
							"transform",
							"translate(0,"
							+ (height - margin.top - margin.bottom)
							+ ")").call(xAxis.orient("bottom")).attr(
									"cx", "-25").attr("cy", "2")
									g.select(".x.axis.zero").attr("transform",
											"translate(0," + Y0() + ")").call(
													xAxis.tickFormat("").tickSize(0));
					g.select(".y.axis").call(yAxis);
				});
			}
			function X(d) {
				return xScale(d[0]);
			}
			function Y0() {
				return yScale(0);
			}
			function Y(d) {
				return yScale(d[1]);
			}
			chart.margin = function(_) {
				if (!arguments.length)
					return margin;
				margin = _;
				return chart;
			};
			chart.width = function(_) {
				if (!arguments.length)
					return width;
				width = _;
				return chart;
			};
			chart.height = function(_) {
				if (!arguments.length)
					return height;
				height = _;
				return chart;
			};
			chart.x = function(_) {
				if (!arguments.length)
					return xValue;
				xValue = _;
				return chart;
			};
			chart.y = function(_) {
				if (!arguments.length)
					return yValue;
				yValue = _;
				return chart;
			};
			return chart;
		}
		return {
			columnChart3 : columnChart3
		}
	});
	return {
		initChart3 : initChart3
	}
})();

(function($) {
	$.fn.tableToD3Chart = function(options) {
		var defaults = {
				wrapper : this,
				chartTitleWrapper : "caption",
				chartType : "donut",
				useDom : true,
				data : [],
				chartLabel : "Chart Label"
		}
		var options = $.extend(defaults, options);
		var o = options;
		var getChartData = {
				title : function(target) {
					if (o.useDom) {
						var $this = $(target), caption = $this.find(
								o.chartTitleWrapper).text();
						return caption;
					} else {
						var caption = o.chartLabel;
						return caption;
					}
				},
				tableData : function(target) {
					if (o.useDom) {
						var $this = $(target), $rows = $this.find("tr").not(
						":first"), rowData = [];
						$rows.each(function() {
							var $dataCells = $(this).children(), tmpData = [];
							$dataCells.each(function() {
								tmpData.push($(this).text());
							});
							rowData.push(tmpData)
						});
						return rowData;
					} else {
						var rowData = o.data;
						return rowData;
					}
				}
		}
		var chart = c3.generate({
			bindto : o.wrapper.selector,
			data : {
				columns : getChartData.tableData(o.chartDataTable),
				type : o.chartType
			},
			donut : {
				title : getChartData.title(o.chartDataTable)
			}
		});
	};
}(jQuery));


var initLoadingLogin = (function() {

	var initLoginButton = (function(selector, params) {
		// http://lab.hakim.se/ladda/
		// Create a new instance of ladda for the specified button
		var l = $(selector).ladda();

		$(selector).click(
				function(i) {
					if (validarCampos("cabecera")) {
						ocultarError("cabecera");
						thisItem = $(this);
						var btnTextSelector = thisItem.parents(".mod_form").find('.ladda-label');
						var j_gid_cod_app = $('#j_gid_cod_app').val();
						var j_gid_cod_ds = $('#j_gid_cod_ds').val();
						var j_gid_num_usuario = $('#txtlogin').val();
						var j_gid_password = $('#password').val();

						$.ajax(
								{
									global : false,
									type : "POST",
									url : "/libreriaLogin/InitLoginServlet",
									data : {
										j_gid_cod_app : j_gid_cod_app,
										j_gid_cod_ds : j_gid_cod_ds
									},
									dataType : "html",
									beforeSend : function(xhr) {
										thisItem.ladda('start');
										mostrarCargando(document.getElementById("hddValidando").value);
										btnTextSelector.text(saveMessage);
										thisItem.parents(".mod_form").find("input").prop("disabled","disabled");
										thisItem.parents(".mod_form").find("input").prop("disabled","disabled");
										thisItem.parents(".fc-tabs").tabs("disable");
									}
								})
								.done(
										function(data) {

											if (data != "") {
												var jsEncrypt = new JSEncrypt();
												jsEncrypt.setKey(data);

												var pCifrar = jsEncrypt.encrypt(j_gid_password);

												$.ajax(
														{
															global : false,
															type : "POST",
															url : "/libreriaLogin/LoginServlet",
															data : {
																j_gid_cod_app : j_gid_cod_app,
																j_gid_cod_ds : j_gid_cod_ds,
																j_gid_num_usuario : j_gid_num_usuario,
																j_gid_password : pCifrar
															},
															dataType : "html",
															headers : {
																"j_gid_cod_app" : j_gid_cod_app,
																"j_gid_cod_ds" : j_gid_cod_ds,
																"x-j_gid_cod_app" : j_gid_cod_app
															}
														})
														.done(
																function(responseText) {

																	btnTextSelector.text(ocultarCargando());
																	thisItem.ladda('stop');
																	thisItem.parents(".mod_form").find("input").removeAttr("disabled");
																	thisItem.parents(".mod_form").find("input").removeAttr("disabled");
																	thisItem.parents(".fc-tabs").tabs("enable");
																	// alert(responseText);
																	if (responseText != "") {
																		setCookie("SSO_TGT_OIP", responseText, false, ".bankia.es");									
																		location.href = "https://bankia.es/oficina/particulares/#/posicion-global";
																	} else {
																		showErrorMessajeValidando("cabecera");
																	}

																})
																.fail(
																		function() {
																			/*console.error("Error autenticando");*/
																			btnTextSelector.text(ocultarCargando());
																			thisItem.ladda('stop');
																			thisItem.parents(".mod_form").find("input").removeAttr("disabled");
																			thisItem.parents(".mod_form").find("input").removeAttr("disabled");
																			thisItem.parents(".fc-tabs").tabs("enable");

																		});

											}

										})
										.fail(
												function() {
													/*console.error("Error obteniendo clabe RSA");*/
													btnTextSelector.text(ocultarCargando());
													thisItem.ladda('stop');
													thisItem.parents(".mod_form").find("input").removeAttr("disabled");
													thisItem.parents(".mod_form").find("input").removeAttr("disabled");
													thisItem.parents(".fc-tabs").tabs("enable");

												});

					} else {
						i.preventDefault();
					}
				});

	});


	return {
		initLoginButton : initLoginButton
	}

})();

var initLoadingLoginG = (function() {

	var initLoginButtonG = (function(selector, params) {
		// http://lab.hakim.se/ladda/
		// Create a new instance of ladda for the specified button
		var l = $(selector).ladda();

		$(selector).click(
				function(i) {
					if (validarCampos("login")) {
						ocultarError("login");
						thisItem = $(this);
						var btnTextSelector = thisItem.parents(".mod_form").find('.ladda-label');
						var j_gid_cod_app = $('#j_gid_cod_appG').val();
						var j_gid_cod_ds = $('#j_gid_cod_dsG').val();
						var j_gid_num_usuario = $('#txtloginG').val();
						var j_gid_password = $('#passwordG').val();

						$.ajax(
								{
									global : false,
									type : "POST",
									url : "/libreriaLogin/InitLoginServlet",
									data : {
										j_gid_cod_app : j_gid_cod_app,
										j_gid_cod_ds : j_gid_cod_ds
									},
									dataType : "html",
									beforeSend : function(xhr) {
										thisItem.ladda('start');
										mostrarCargando(document.getElementById("hddValidando").value);
										btnTextSelector.text(saveMessage);
										thisItem.parents(".mod_form").find("input").prop("disabled","disabled");
										thisItem.parents(".mod_form").find("input").prop("disabled","disabled");
										thisItem.parents(".fc-tabs").tabs("disable");
									}
								})
								.done(
										function(data) {

											if (data != "") {
												var jsEncrypt = new JSEncrypt();
												jsEncrypt.setKey(data);

												var pCifrar = jsEncrypt.encrypt(j_gid_password);

												$.ajax(
														{
															global : false,
															type : "POST",
															url : "/libreriaLogin/LoginServlet",
															data : {
																j_gid_cod_app : j_gid_cod_app,
																j_gid_cod_ds : j_gid_cod_ds,
																j_gid_num_usuario : j_gid_num_usuario,
																j_gid_password : pCifrar
															},
															dataType : "html",
															headers : {
																"j_gid_cod_app" : j_gid_cod_app,
																"j_gid_cod_ds" : j_gid_cod_ds,
																"x-j_gid_cod_app" : j_gid_cod_app
															}
														})
														.done(
																function(responseText) {

																	btnTextSelector.text(ocultarCargando());
																	thisItem.ladda('stop');
																	thisItem.parents(".mod_form").find("input").removeAttr("disabled");
																	thisItem.parents(".mod_form").find("input").removeAttr("disabled");
																	thisItem.parents(".fc-tabs").tabs("enable");
																	// alert(responseText);
																	if (responseText != "") {
																		setCookie("SSO_TGT_OIP", responseText, false, ".bankia.es");									
																		location.href = "https://bankia.es/oficina/particulares/#/posicion-global";
																	} else {
																		showErrorMessajeValidando("login");
																	}

																})
																.fail(
																		function() {
																			/*console.error("Error autenticando");*/
																			btnTextSelector.text(ocultarCargando());
																			thisItem.ladda('stop');
																			thisItem.parents(".mod_form").find("input").removeAttr("disabled");
																			thisItem.parents(".mod_form").find("input").removeAttr("disabled");
																			thisItem.parents(".fc-tabs").tabs("enable");

																		});

											}

										})
										.fail(
												function() {
													/*console.error("Error obteniendo clabe RSA");*/
													btnTextSelector.text(ocultarCargando());
													thisItem.ladda('stop');
													thisItem.parents(".mod_form").find("input").removeAttr("disabled");
													thisItem.parents(".mod_form").find("input").removeAttr("disabled");
													thisItem.parents(".fc-tabs").tabs("enable");

												});

					} else {
						i.preventDefault();
					}
				});

	});


	return {
		initLoginButtonG : initLoginButtonG
	}

})();

/*Se unifican todos los document.ready*/
$(document).ready(function() {

	/* LOGIN BUTTON */
	if ($("[data-function='fc-buttonLogin']").length > 0) {
		initLoadingLogin.initLoginButton("[data-function='fc-buttonLogin']")
	}

	/* LOGIN BUTTON */
	if ($("[data-function='fc-buttonLoginG']").length > 0) {
		initLoadingLoginG.initLoginButtonG("[data-function='fc-buttonLoginG']")
	}

	$("#productosservicios").change(function(){
		var str = "";
		$( "#productosservicios option:selected" ).each(function() {
			str += "."+$(this).val()+",";
		});
		$(".prodServFilter").hide();

		if(str.length==0)
		{
			$(".prodServFilter").show();
		}
		else
		{
			$(str.substring(0,str.length-1)).show();
		}
	});

	$(".productosserviciosOrden").change(function(){
		var str = "";
		var tab = $(this).closest(".tab-content").attr('id');
		$("option:selected", this).each(function() {
			str += "."+$(this).val()+",";
		});

		$(".prodServFilter").each(function() {
			var tab2 = $(this).closest(".tab-content").attr('id');
			if(tab == tab2){
				if(str.length==0){
					$(this).show();
				}else{
					$(this).hide();
				}
			}
		});

		if(str.length!=0){
			$(str.substring(0,str.length-1)).each(function() {
				var tab4 = $(this).closest(".tab-content").attr('id');
				if(tab == tab4)
					$(this).show();
			});
		}
	});

	if ($("[data-function='fc-chart_init']").length > 0) {
		mod_chart.initChart("[data-function='fc-chart_init']");
	}

	if ($("[data-function='fc-chart_init_1']").length > 0) {
		mod_chart1.initChart1("[data-function='fc-chart_init_1']");
	}

	if ($("[data-function='fc-chart_init_2']").length > 0) {
		mod_chart2.initChart2("[data-function='fc-chart_init_2']");
	}

	if ($("[data-function='fc-chart_init_3']").length > 0) {
		mod_chart3.initChart3("[data-function='fc-chart_init_3']");
	}

	/*Se controla que no se envÃƒÆ’Ã‚Â­e el formulario si el texto estÃƒÆ’Ã‚Â¡ vacÃƒÆ’Ã‚Â­o*/
	$(".hdr-search-btn").click(function(){
		var typeInput = $(this).attr("type");
		if(typeInput != "submit"){
			if ($(".hdr-search-input").val().length > 0){
				console.log("Envio el FORMULARIO");
				$(".frm-search").submit();	
			}else{
				console.log("texto vacio")
			}
		}
	});
	
	if(digitalData != undefined){
		
		if (digitalData.segmento == "banca privada"){
			$(".contentCompany").css("display","none");
			$(".contentFreelance").css("display","block");
			$(".section-freelance ").addClass("active");
			$(".section-company ").removeClass("active");
		} 
		
		if (digitalData.segmento == "pymes y autonomos"){
			$(".contentCompany").css("display","block");
			$(".contentFreelance").css("display","none");
			$(".section-freelance ").removeClass("active");
			$(".section-company ").addClass("active");
		} 
		
		if (digitalData.segmento == "acceso clientes"){
					
			$(".contentCompany").css("display","none");
			$(".contentFreelance").css("display","block");
			$(".section-freelance ").addClass("active");
			$(".section-company ").removeClass("active");
			$("#EmpresasPymes-imagen").css("display","none");
			$("#ParticularesAutonomos-imagen").css("display","block");
			
			var tipo = getParameterByName('tipo');
			if (tipo == "empresas"){
				$(".contentCompany").css("display","block");
				$(".contentFreelance").css("display","none");
				$(".section-freelance ").removeClass("active");
				$(".section-company ").addClass("active");
				$(".section-company p").css("color","#35261a");
				$("#EmpresasPymes-imagen").css("display","block");
				$("#ParticularesAutonomos-imagen").css("display","none");
				var href = $('a[title="Oficinas y cajeros"]').attr('href').replace('/particulares/','/empresas/');
				$('a[title="Oficinas y cajeros"]').attr('href',href);
				SelectObject = document.getElementById('ui-id-1');
				for(index = 0;  index < SelectObject.length;  index++) {
					var href1 = SelectObject[index].value.replace('/particulares/','/empresas/');
					SelectObject[index].value = href1;
				}
			}

		} 
	}

});

if (window.location.href.match(/.bankia.int/)){
	document.domain = "bankia.int";
}

if (window.location.href.match(/.bankia.es/)){
	document.domain = "bankia.es";
}


function descargaCSV()
{
	var lang = navigator.language || navigator.userLanguage;

	var csv = vlpGraficaCalc.map(function(d){
		return JSON.stringify(Object.values(d));
	})
	.join('\n') 
	.replace(/(^\[)|(\]$)/mg, '')
	.split(',').join(';');


	if(lang!='en')
	{
		csv = "Fecha;VLP\n"+csv.split('.').join(',');
	}
	else
	{
		csv = "Fecha;VLP\n"+csv;
	}
	download(csv, 'bankia.csv','text/csv;charset=utf-8;')
}

var download = function(content, fileName, mimeType) {
	var a = document.createElement('a');
	mimeType = mimeType || 'application/octet-stream';

	if (navigator.msSaveBlob) { // IE10
		return navigator.msSaveBlob(new Blob([content], { type: mimeType }),     fileName);
	} else if ('download' in a) { //html5 A[download]
		a.href = 'data:' + mimeType + ',' + encodeURIComponent(content);
		a.setAttribute('download', fileName);
		document.body.appendChild(a);
		setTimeout(function() {
			a.click();
			document.body.removeChild(a);
		}, 66);
		return true;
	} else { //do iframe dataURL download (old ch+FF):
		var f = document.createElement('iframe');
		document.body.appendChild(f);
		f.src = 'data:' + mimeType + ',' + encodeURIComponent(content);

		setTimeout(function() {
			document.body.removeChild(f);
		}, 333);
		return true;
	}
}

Object.values = function (obj) {
	var vals = [];

	for( var key in obj ) {
		if ( obj.hasOwnProperty(key) ) {
			if(key=='date'){
				vals.push(obj[key].getDate()+'/'+(obj[key].getMonth()+1)+'/'+obj[key].getFullYear());
			}
			else if(key=='close')
			{
				vals.push(obj[key]);
			}
			else
			{
				vals.push(obj[key]);
			}            
		}
	}
	return vals;
}

function paso3Simulador(){

	modalShowCustomization();

	$(".mod_lightbox").on('hide.bs.modal', function(e) {
		modalHideCustomization();
	});
	var tipoSimulador = normalizeString($("#simuladorId").attr("value"));

	sessionStorage.setItem('oldTematicaContenido', digitalData.tematicaContenido);
	digitalData.estado = "inicio";
	digitalData.tipoPagina = "modal";
	digitalData.tipoContactabilidad = "mixta";
	digitalData.tematicaContenido = "contactabilidad";
	digitalData.proceso = "contactabilidad";
	digitalData.paginaBajoModal = localStorage.paginaBajoModal;
	if(tipoSimulador == "simulador vida nexo"){
		digitalData.paginaBajoModal = bajoModal() + "resultados prima";
	}
	if(tipoSimulador == "simulador seguro salud"){	
		if($("#botonCambiarSel").is(":visible")){
			digitalData.nombrePagina="contactabilidad solicitar seguro salud"
				digitalData.paginaBajoModal = bajoModal() + "ver comparativa seguro salud";
		}
	}
	digitalData.funnel = "paso1:contactabilidad " + sessionStorage.tipoSimulador;
	digitalData.puntoAcceso = sessionStorage.tipoSimulador;
	sessionStorage.setItem('puntoAcceso', digitalData.puntoAcceso);


	s.t();

}

function initModalWindowBuscador(){
	$(".mod_layout .busqueda a[target='_modal'], .mod_header .busqueda a[target='_modal']")
	.click(function(e) {

		e.preventDefault();

		var loadingOverlay = '<div style="display: none;" class="loading-overlay"></div>'
			var loading = '<div style="display: none;" class="loading"><img alt="Loading..." src="'
				+ frontPathPrefix
				+ '/images/modules/header/350.gif"></div>'
				$('body').append(loadingOverlay);
		$('body').append(loading);

		var href = $(this).attr("data-href");

		var pContratacion = $(this).attr("data-contratacion");

		var titleModal = "";

		if($(this).attr("data-titleModal") != undefined){

			titleModal = $(this).attr("data-titleModal");
		}


		$(this).attr("href", "#ni");

		var titulo = ".mod_title.tit-encabezado div";

		$
		.ajax(
				{
					global : false,
					type : "GET",
					url : href,
					data : {
						dataC : encodeURI(pContratacion)
					},
					dataType : "html",
					beforeSend : function(
							xhr) {
						$(".loading")
						.show();
						$(
						".loading-overlay")
						.show();
					}
				})
				.done(
						function(data) {

							if(titleModal != ""){
								$(".title-lightbox").text(titleModal);
							}
							$(".modal-lightbox")
							.html(
									$(data));

							var anchoDoc = window.innerWidth;
							var anchoMaxT = 1200;
							var anchoMaxM = 767;

							// Es escritorio
							if(anchoDoc > anchoMaxT){

								if($(".fc-tabsMobile").length > 0){
									if($(".fc-tabsMobile .ui-tabs-panel").length > 0){
										initTabs.initDestroy(".fc-tabsMobile");
									}
								}

								// Es tablet
							}else if((anchoDoc > anchoMaxM) && (anchoDoc < (anchoMaxT+1))){

								if($(".fc-tabsMobile").length > 0){
									if($(".fc-tabsMobile .ui-tabs-panel").length > 0){
										initTabs.initDestroy(".fc-tabsMobile");
									}
								}

								// Es movil
							}else if(anchoDoc < (anchoMaxM+1)){
								if($(".fc-tabsMobile").length > 0){
									if($(".fc-tabsMobile .ui-tabs-panel").length < 1){
										initTabs.init(".fc-tabsMobile","",0);
									}
								}
							}

							$(".loading-overlay").remove();
							$(".loading").remove();

							if($(".mod_lightbox.in .mod_encabezadoPagina").length > 0){
								if(titleModal != ""){
									$(".mod_lightbox.in .mod_encabezadoPagina").parents(".lyt-box").remove();
								}
							}

							return false;

						})
						.fail(
								function() {
									$
									.ajax(
											{
												global : false,
												type : "GET",
												url : "/portalunico/modal/es_ES/error%20login",
												dataType : "html"
											})
											.done(
													function(data) {

														$(".modal-lightbox")
														.html(
																$(data));

														$(
														".loading-overlay")
														.remove();
														$(".loading")
														.remove();

														$(
														".mod_lightbox.in .mod_encabezadoPagina")
														.parents(
														".lyt-box")
														.remove();

														return false;

													})
													.fail(
															function() {
																$(
																".loading-overlay")
																.remove();
																$(".loading")
																.remove();
																/*console
								    .error("Error");*/
															});

								});

	})
}

function initModalWindow(){
	$(".mod_layout a[target='_modal'], .mod_header a[target='_modal']")
	.click(function(e) {

		e.preventDefault();

		var loadingOverlay = '<div style="display: none;" class="loading-overlay"></div>'
			var loading = '<div style="display: none;" class="loading"><img alt="Loading..." src="'
				+ frontPathPrefix
				+ '/images/modules/header/350.gif"></div>'
				$('body').append(loadingOverlay);
		$('body').append(loading);

		var href = $(this).attr("data-href");

		var pContratacion = $(this).attr("data-contratacion");

		var titleModal = "";

		if($(this).attr("data-titleModal") != undefined){

			titleModal = $(this).attr("data-titleModal");
		}


		$(this).attr("href", "#ni");

		var titulo = ".mod_title.tit-encabezado div";

		$
		.ajax(
				{
					global : false,
					type : "GET",
					url : href,
					data : {
						dataC : encodeURI(pContratacion)
					},
					dataType : "html",
					beforeSend : function(
							xhr) {
						$(".loading")
						.show();
						$(
						".loading-overlay")
						.show();
					}
				})
				.done(
						function(data) {

							if(titleModal != ""){
								$(".title-lightbox").text(titleModal);
							}
							$(".modal-lightbox")
							.html(
									$(data));

							var anchoDoc = window.innerWidth;
							var anchoMaxT = 1200;
							var anchoMaxM = 767;

							// Es escritorio
							if(anchoDoc > anchoMaxT){

								if($(".fc-tabsMobile").length > 0){
									if($(".fc-tabsMobile .ui-tabs-panel").length > 0){
										initTabs.initDestroy(".fc-tabsMobile");
									}
								}

								// Es tablet
							}else if((anchoDoc > anchoMaxM) && (anchoDoc < (anchoMaxT+1))){

								if($(".fc-tabsMobile").length > 0){
									if($(".fc-tabsMobile .ui-tabs-panel").length > 0){
										initTabs.initDestroy(".fc-tabsMobile");
									}
								}

								// Es movil
							}else if(anchoDoc < (anchoMaxM+1)){
								if($(".fc-tabsMobile").length > 0){
									if($(".fc-tabsMobile .ui-tabs-panel").length < 1){
										initTabs.init(".fc-tabsMobile","",0);
									}
									if($(".fc-tabsMobile .ui-tabs-panel").length == 1){
										$("#tab-32").attr('class',$("#tab-32").attr('class')+' tab-content')
									}
								}
							}

							$(".loading-overlay").remove();
							$(".loading").remove();

							if($(".mod_lightbox.in .mod_encabezadoPagina").length > 0){
								if(titleModal != ""){
									$(".mod_lightbox.in .mod_encabezadoPagina").parents(".lyt-box").remove();
								}
							}

							return false;

						})
						.fail(
								function() {
									$
									.ajax(
											{
												global : false,
												type : "GET",
												url : "/portalunico/modal/es_ES/error%20login",
												dataType : "html"
											})
											.done(
													function(data) {

														$(".modal-lightbox")
														.html(
																$(data));

														$(
														".loading-overlay")
														.remove();
														$(".loading")
														.remove();

														$(
														".mod_lightbox.in .mod_encabezadoPagina")
														.parents(
														".lyt-box")
														.remove();

														return false;

													})
													.fail(
															function() {
																$(
																".loading-overlay")
																.remove();
																$(".loading")
																.remove();
																/*console
								    .error("Error");*/
															});

								});

	})
}

function abandonaHipoteca(tpHipoteca1, tpHipoteca2, cuotaResultante1, cuotaResultante2){

	var indicadorConoceValorVivienda = 'S';
	if($("#conocimientoPrecio").val() == '2'){
		var indicadorConoceValorVivienda = 'N';
	}
	var ingresosMensuales = $("#ingresos").val();
	var importeVivienda = "";
	if($("#importe-hipotecaNecesitasPV").val() != undefined){
		importeVivienda = $("#importe-hipotecaNecesitasPV").val();
	}else if($("#importe-hipotecaNecesitas").val() != undefined){
		importeVivienda = $("#importe-hipotecaNecesitas").val();
	}else{
		importeVivienda = $("#vivienda").val();
	}
	var Plazo = "";
	if($("#anios-hipotecaPV").val() != undefined){
		Plazo = $("#anios-hipotecaPV").val();
	}else if($("#anios-hipoteca").val() != undefined){
		Plazo = $("#anios-hipoteca").val();
	}else{
		Plazo = $("#hipoteca").val();
	}
	var tipoInmueble = 'Nuevo';
	if($("#tipoInmueble").val() == '2'){
		var tipoInmueble = 'Usado';
	}
	var finalidadCompra = 'V. habitual';
	if($("#privivienda").val() == '2'){
		var finalidadCompra = 'Seg. Residencia';
	}
	var codProvUbicacion = $("#ubicacion").val();
	if(codProvUbicacion<2){
		codProvUbicacion = "0" + codProvUbicacion;
	}

	var valorIdTeAyudamosHipotecas = $("#idTeAyudamos").val();
	var valorTipoHipoteca = $("#privivienda").val();
	var valorViviendaHipoteca = "";
	if($("#inputValorVivienda").val() == undefined){
		valorViviendaHipoteca = $("#valorvivienda").val();
	}else{
		valorViviendaHipoteca = $("#inputValorVivienda").val();
	}
	var valorGastosHipoteca = $("#gastos").val();

	var maximoFinanciado = $("#bankiaFinanciaPDF").text();
	var cuotaResultante1 = $(".cuotaPEH1PDF").text() + $(".cuotaPDH1PDF").text();
	var cuotaResultante2 = $(".cuotaPEH2PDF").text() + $(".cuotaPDH2PDF").text();

	var taeAplicado1 = $(".taeh1PDF").text().replace('%','');
	if(taeAplicado1.includes(",")){
		tae1Array = taeAplicado1.split(",");
		taeAplicado1 = tae1Array[0]+tae1Array[1]+tae1Array[1].length;
	}
	while (taeAplicado1.length < 6) {
		taeAplicado1 = '0' + taeAplicado1;
	}

	var taeAplicado2 = $(".taeh2PDF").text().replace('%','');
	if(taeAplicado2.includes(",")){
		tae2Array = taeAplicado2.split(",");
		taeAplicado2 = tae2Array[0]+tae2Array[1]+tae2Array[1].length;
	}
	while (taeAplicado2.length < 6) {
		taeAplicado2 = '0' + taeAplicado2;
	}

	if(tpHipoteca1 == 'Tipo Variable'){
		diferencial1 = $('.impuestoh1PDF').text().replace('%','').replace('+','').replace('-','');
		tin1 = '0';
	}else{
		diferencial1 = '0';
		tin1 = $('.impuestoh1PDF').text().replace('%','').replace('+','').replace('-','');
	}
	if(diferencial1.includes(",")){
		diferencial1Array = diferencial1.split(",");
		diferencial1 = diferencial1Array[0]+diferencial1Array[1]+diferencial1Array[1].length;
	}else{
		diferencial1=diferencial1+"0";
	}
	if(diferencial1 != '0'){
		while (diferencial1.length < 6) {
			diferencial1 = '0' + diferencial1;
		}
	}
	if(diferencial1=="000000" || diferencial1=="0"){
		diferencial1="000002";
	}
	if(tin1.includes(",")){
		tin1Array = tin1.split(",");
		tin1 = tin1Array[0]+tin1Array[1]+tin1Array[1].length;
	}else{
		tin1=tin1+"0";
	}
	if(tin1 != '0'){
		while (tin1.length < 6) {
			tin1 = '0' + tin1;
		}
	}
	if(tin1=="000000" || tin1=="0"){
		tin1="000002";
	}
	if(tpHipoteca2 == 'Tipo Variable'){
		diferencial2 = $('.impuestoh2PDF').text().replace('%','').replace('+','').replace('-','');
		tin2 = '0';
	}else{
		diferencial2 = '0';
		tin2 = $('.impuestoh2PDF').text().replace('%','').replace('+','').replace('-','');
	}
	if(diferencial2.includes(",")){
		diferencial2Array = diferencial2.split(",");
		diferencial2 = diferencial2Array[0]+diferencial2Array[1]+diferencial2Array[1].length;
	}else{
		diferencial2=diferencial2+"0";
	}
	if(diferencial2 != '0'){
		while (diferencial2.length < 6) {
			diferencial2 = '0' + diferencial2;
		}
	}
	if(diferencial2=="000000" || diferencial2=="0"){
		diferencial2="000002";
	}
	if(tin2.includes(",")){
		tin2Array = tin2.split(",");
		tin2 = tin2Array[0]+tin2Array[1]+tin2Array[1].length;
	}else{
		tin2=tin2+"0";
	}
	if(tin2 != '0'){
		while (tin2.length < 6) {
			tin2 = '0' + tin2;
		}
	}
	if(tin2=="000000" || tin2=="0"){
		tin2="000002";
	}

	var tipoHipoteca1 = 'F';
	if(tpHipoteca1 == 'Tipo Variable'){
		tipoHipoteca1 = 'V';
	}
	var tipoHipoteca2 = 'F';
	if(tpHipoteca2 == 'Tipo Variable'){
		tipoHipoteca2 = 'V';
	}
	var entorno = $('#entornoOiPM').val();
	var identificadorCliente = $('#identificadorCliente').val();
	var provider = new ChannelProvider();
	provider.addTrustedOrigins(entorno);
	var channel = provider.$get(window);
	var SCOPE =  'simuladores';
	var message = { 
			action:'AbandonoHipotecas',
			data:{
				'codigoCliente':identificadorCliente,
				'indicadorConoceValorVivienda':indicadorConoceValorVivienda,
				'ingresosMensuales':ingresosMensuales,
				'importeVivienda':importeVivienda,
				'Plazo':Plazo, 
				'tipoInmueble':tipoInmueble, 
				'finalidadCompra':finalidadCompra, 
				'codProvUbicacion':codProvUbicacion, 
				'tpHipoteca1':tipoHipoteca1, 
				'tpHipoteca2':tipoHipoteca2, 
				'cuotaResultante1':cuotaResultante1, 
				'cuotaResultante2':cuotaResultante2, 
				'taeAplicado1':taeAplicado1, 
				'taeAplicado2':taeAplicado2, 
				'diferencial1':diferencial1, 
				'diferencial2':diferencial2, 
				'tin1':tin1, 
				'tin2':tin2, 
				'maximoFinanciado':maximoFinanciado
			}
	};  
	channel.transmit(window.parent, SCOPE, message);
}

function abandonaPrestamo(){
	var cuantiaEntrada = $("#cantidad").val();
	var plazoEntrada = $("#plazo").val();
	var finalidadElegida = $(".finalidadSeleccionada").html();
	var finalidad = $("#tipoPrestamo").val();
	if(finalidad == 'c'){
		valorfinalidad = 'Coche';
	}else if(finalidad == 'r'){
		valorfinalidad = 'Reforma';
	}else if(finalidad == 'o'){
		valorfinalidad = 'Otros';
	}
	var cuota = $("#cuotaMensualPEPdf").html() + $("#cuotaMensualPDPdf").html();
	var identificadorCliente = $("#identificadorCliente").val();
	var tin =  $("#tinPdf").html();
	if(tin.includes(",")){
		tinArray = tin.split(",");
		tin = tinArray[0]+tinArray[1]+tinArray[1].length;
	}else{
		tin = tin+"0";
	}
	while (tin.length < 6) {
		tin = '0' + tin;
	}

	if(tin=="000000" || tin=="0"){
		tin="000002";
	}

	var tae =  $("#taePdf").html();
	if(tae.includes(",")){
		taeArray = tae.split(",");
		tae = taeArray[0]+taeArray[1]+taeArray[1].length;
	}else{
		tae=tae+"0";
	}
	while (tae.length < 6) {
		tae = '0' + tae;
	}
	var entorno = $('#entornoOiPM').val();
	var provider = new ChannelProvider();
	provider.addTrustedOrigins(entorno);
	var channel = provider.$get(window);
	var SCOPE =  'simuladores';
	var message = { 
			action:'AbandonoPrestamos',
			data:{
				'codigoCliente':identificadorCliente,
				'importeSolicitado':cuantiaEntrada,
				'plazoSolicitado':plazoEntrada,
				'finalidad':valorfinalidad,
				'cuotaResultante':cuota, 
				'taeAplicado':tae, 
				'tinAplicado':tin
			}
	};  
	channel.transmit(window.parent, SCOPE, message);
}

function esCocheEcologico(){
	var esCocheEcologico = false;
	var impMaximoCoche;
	var plazoMaxCoche;
	var interesFijoCoche;
	var comisionAperturaCoche;
	var comisionAperturaMinCoche;
	var uri = window.location.href;
	var formato = $("#formato").val();
	if(document.getElementById("id_cocheEcologico").checked){
		esCocheEcologico = true;
		//Cambio de valores en sliders
		$("#sliderPrestamoCocheSostenible").removeClass('hidden');
		$("#sliderPrestamoCoche").addClass('hidden');
		
		//Prestamos
		var simPrestamosCuotaMensual = $("#simPrestamosCuotaMensual").val();
		var simPrestamosEuros = $("#simPrestamosEuros").val();
		var simPrestamosPlazo = $("#simPrestamosPlazo").val();
		var simPrestamosMeses = $("#simPrestamosMeses").val();
		var simPrestamosSolicitar = $("#simPrestamosSolicitar").val();
		var simPrestamosVerDetalles = $("#simPrestamosVerDetalles").val();
		var simPrestamosVerCondiciones = $("#simPrestamosVerCondiciones").val();
		var simPrestamosImporte = $("#simPrestamosImporte").val();
		var simPrestamosTipoInteres = $("#simPrestamosTipoInteres").val();
		var simPrestamosPorCiento = $("#simPrestamosPorCiento").val();
		var simPrestamosComisionApertura = $("#simPrestamosComisionApertura").val();
		var calculadoraInfoLegal = $("#calculadoraInfoLegal").val();
		var simPrestamosNoEncontradoPrestamo = $("#simPrestamosNoEncontradoPrestamo").val();

		var sitiositeLog = $("#sitiositeLog").val();
		//Simuladores
		var valorSegmentoSolicitar = $(".segmentoSolicitar").val();
		var valorFamiliaSolicitar = $(".familiaSolicitar").val();
		var valorColectivoSolicitar = $(".colectivoSolicitar").val();
		var valorPaginaSolicitar = $(".paginaSolicitar").val();
		var valorEspacioSolicitar = $(".espacioSolicitar").val();
		var hreflang = $(".hreflang").val(); 
		var webPrivada = $("#webPrivada").val();
		var edadPrivada = $("#edadPrivada").val();


		var valorCantidadPrestamos = 0;
		if($("#cantidad").val() != undefined){
			valorCantidadPrestamos = dFrontJs.parseoNumber($("#cantidad").val().toString());
		}
		var valorPlazoPrestamos = 0;
		if($("#plazo").val() != undefined){
			valorPlazoPrestamos = dFrontJs.parseoNumber($("#plazo").val().toString());
		}
		var valorIDLista = $("#IDListaPrestamos").val();  
		var valorIDListaCoche = $("#iDListaPrestamosCoche").val();  
		var valorTipoPrestamo = $("#tipoPrestamo").val();
		
		//Valores para la llamada ajax
		impMaximoCoche = $("#maxSliCantCS").val();
		plazoMaxCoche = $("#maxSliPlaCS").val();
		interesFijoCoche = $("#TINCS").val();
		comisionAperturaCoche = $("#comAperturaCS").val();
		comisionAperturaMinCoche = $("#comAperturaImporteCS").val();
		var canalActual = $("#canalActual").val();
		var URLFormatear = "/portalunico/nuevaSimulacionPrestamos.jsp" + "?cantidad=" + valorCantidadPrestamos + "&plazo=" + valorPlazoPrestamos + "&IDLista=" + valorIDLista + "&tipoPrestamo=" + valorTipoPrestamo + "&segmento=" + valorSegmentoSolicitar + "&familia=" + valorFamiliaSolicitar + "&colectivo=" + valorColectivoSolicitar + "&pagina=" + valorPaginaSolicitar + "&espacio=" + valorEspacioSolicitar + "&formato=" +formato + "&IDListaCoche=" + valorIDListaCoche + "&esCocheEcologico=" +esCocheEcologico + "&impMaximoCoche=" +impMaximoCoche + "&plazoMaxCoche=" + plazoMaxCoche + "&interesFijoCoche=" + interesFijoCoche + "&comisionAperturaCoche=" + comisionAperturaCoche + "&comisionAperturaMinCoche=" + comisionAperturaMinCoche;
		jQuery.ajax({
			url: encodeURI(URLFormatear),
			context: document.body,
			data: {'simPrestamosCuotaMensual': simPrestamosCuotaMensual,'simPrestamosEuros': simPrestamosEuros,'simPrestamosPlazo': simPrestamosPlazo,'simPrestamosMeses': simPrestamosMeses,'simPrestamosSolicitar': simPrestamosSolicitar	,'simPrestamosVerDetalles': simPrestamosVerDetalles,'simPrestamosVerCondiciones': simPrestamosVerCondiciones,'simPrestamosImporte': simPrestamosImporte,'simPrestamosTipoInteres': simPrestamosTipoInteres ,'simPrestamosPorCiento': simPrestamosPorCiento,'simPrestamosComisionApertura': simPrestamosComisionApertura	,'calculadoraInfoLegal': calculadoraInfoLegal,'simPrestamosNoEncontradoPrestamo': simPrestamosNoEncontradoPrestamo, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog, 'webPrivada': webPrivada, 'edadPrivada': edadPrivada, 'canalActual': canalActual
			},
			success: function(data, textStatus )     
			{
				if (!jQuery('#div_ajaxSimPrestamo').hasClass('hide'))
				{
					jQuery('#div_ajaxSimPrestamo').css('display','none');
					jQuery('#div_ajaxSimPrestamo').toggleClass('hide');
				}
				if (!jQuery('.mod_TextoLegal').hasClass('hide'))
				{
					jQuery('.mod_TextoLegal').css('display','none');
					jQuery('.mod_TextoLegal').toggleClass('hide');
				}
				jQuery('#nuevaSimulacion').html(data);
				pintarDonut();
				/** INIT ANITICA NO BORRAR*/
				digitalData.importe = valorCantidadPrestamos;
				digitalData.plazo = valorPlazoPrestamos;
				/** END ANALITICA NO BORRAR*/
			},
			complete: function(){
				if(uri.indexOf("Mobile") > 0){
					$(".but-oranje.but-wAuto.solicitarDonut").addClass("mobile");
				}
			},
			error: function(xhr, textStatus, errorThrown){
			}
		});
		$('#cantidadPrestamoMovilCS').text($('#cantidad').val());
		$('#plazoPrestamoMovilCS').text($('#plazo').val());
		$('#cantidadCS').val($('#cantidad').val());
		$('#plazoCS').val($('#plazo').val());
		$("#sliderCantidadCS").slider({ value: $('#cantidadCS').val().replace('.','')});
		$("#sliderPlazoCS").slider({ value: $('#plazoCS').val()});
	}else{
		esCocheEcologico = false;
		//Cambio de valores en sliders
		$("#sliderPrestamoCoche").removeClass('hidden');
		$("#sliderPrestamoCocheSostenible").addClass('hidden');
		//Prestamos
		var simPrestamosCuotaMensual = $("#simPrestamosCuotaMensual").val();
		var simPrestamosEuros = $("#simPrestamosEuros").val();
		var simPrestamosPlazo = $("#simPrestamosPlazo").val();
		var simPrestamosMeses = $("#simPrestamosMeses").val();
		var simPrestamosSolicitar = $("#simPrestamosSolicitar").val();
		var simPrestamosVerDetalles = $("#simPrestamosVerDetalles").val();
		var simPrestamosVerCondiciones = $("#simPrestamosVerCondiciones").val();
		var simPrestamosImporte = $("#simPrestamosImporte").val();
		var simPrestamosTipoInteres = $("#simPrestamosTipoInteres").val();
		var simPrestamosPorCiento = $("#simPrestamosPorCiento").val();
		var simPrestamosComisionApertura = $("#simPrestamosComisionApertura").val();
		var calculadoraInfoLegal = $("#calculadoraInfoLegal").val();
		var simPrestamosNoEncontradoPrestamo = $("#simPrestamosNoEncontradoPrestamo").val();

		var sitiositeLog = $("#sitiositeLog").val();
		//Simuladores
		var valorSegmentoSolicitar = $(".segmentoSolicitar").val();
		var valorFamiliaSolicitar = $(".familiaSolicitar").val();
		var valorColectivoSolicitar = $(".colectivoSolicitar").val();
		var valorPaginaSolicitar = $(".paginaSolicitar").val();
		var valorEspacioSolicitar = $(".espacioSolicitar").val();
		var hreflang = $(".hreflang").val(); 
		var webPrivada = $("#webPrivada").val();
		var edadPrivada = $("#edadPrivada").val();


		var valorCantidadPrestamos = 0;
		if($("#cantidadCS").val() != undefined){
			valorCantidadPrestamos = dFrontJs.parseoNumber($("#cantidadCS").val().toString());
		}
		var valorPlazoPrestamos = 0;
		if($("#plazoCS").val() != undefined){
			valorPlazoPrestamos = dFrontJs.parseoNumber($("#plazoCS").val().toString());
		}
		var valorIDLista = $("#IDListaPrestamos").val();  
		var valorIDListaCoche = $("#iDListaPrestamosCoche").val();  
		var valorTipoPrestamo = $("#tipoPrestamo").val();
		
		//Valores para la llamada ajax
		impMaximoCoche = $("#maxSliCant").val();
		plazoMaxCoche = $("#maxSliPla").val();
		interesFijoCoche = $("#TIN").val();
		comisionAperturaCoche = $("#comApertura").val();
		comisionAperturaMinCoche = $("#comAperturaImporte").val();
		var canalActual = $("#canalActual").val();
		var URLFormatear = "/portalunico/nuevaSimulacionPrestamos.jsp" + "?cantidad=" + valorCantidadPrestamos + "&plazo=" + valorPlazoPrestamos + "&IDLista=" + valorIDLista + "&tipoPrestamo=" + valorTipoPrestamo + "&segmento=" + valorSegmentoSolicitar + "&familia=" + valorFamiliaSolicitar + "&colectivo=" + valorColectivoSolicitar + "&pagina=" + valorPaginaSolicitar + "&espacio=" + valorEspacioSolicitar + "&formato=" +formato + "&IDListaCoche=" + valorIDListaCoche + "&esCocheEcologico=" +esCocheEcologico + "&impMaximoCoche=" +impMaximoCoche + "&plazoMaxCoche=" + plazoMaxCoche + "&interesFijoCoche=" + interesFijoCoche + "&comisionAperturaCoche=" + comisionAperturaCoche + "&comisionAperturaMinCoche=" + comisionAperturaMinCoche;
		jQuery.ajax({
			url: encodeURI(URLFormatear),
			context: document.body,
			data: {'simPrestamosCuotaMensual': simPrestamosCuotaMensual,'simPrestamosEuros': simPrestamosEuros,'simPrestamosPlazo': simPrestamosPlazo,'simPrestamosMeses': simPrestamosMeses,'simPrestamosSolicitar': simPrestamosSolicitar	,'simPrestamosVerDetalles': simPrestamosVerDetalles,'simPrestamosVerCondiciones': simPrestamosVerCondiciones,'simPrestamosImporte': simPrestamosImporte,'simPrestamosTipoInteres': simPrestamosTipoInteres ,'simPrestamosPorCiento': simPrestamosPorCiento,'simPrestamosComisionApertura': simPrestamosComisionApertura	,'calculadoraInfoLegal': calculadoraInfoLegal,'simPrestamosNoEncontradoPrestamo': simPrestamosNoEncontradoPrestamo, 'hreflang': hreflang, 'sitiositeLog': sitiositeLog, 'webPrivada': webPrivada, 'edadPrivada': edadPrivada, 'canalActual': canalActual
			},
			success: function(data, textStatus )     
			{
				if (!jQuery('#div_ajaxSimPrestamo').hasClass('hide'))
				{
					jQuery('#div_ajaxSimPrestamo').css('display','none');
					jQuery('#div_ajaxSimPrestamo').toggleClass('hide');
				}
				if (!jQuery('.mod_TextoLegal').hasClass('hide'))
				{
					jQuery('.mod_TextoLegal').css('display','none');
					jQuery('.mod_TextoLegal').toggleClass('hide');
				}
				jQuery('#nuevaSimulacion').html(data);
				pintarDonut();
				/** INIT ANITICA NO BORRAR*/
				digitalData.importe = valorCantidadPrestamos;
				digitalData.plazo = valorPlazoPrestamos;
				/** END ANALITICA NO BORRAR*/
			},
			complete: function(){
				if(uri.indexOf("Mobile") > 0){
					$(".but-oranje.but-wAuto.solicitarDonut").addClass("mobile");
				}
			},
			error: function(xhr, textStatus, errorThrown){
			}
		});
		$('#cantidadPrestamoMovil').text($('#cantidadCS').val());
		$('#plazoPrestamoMovil').text($('#plazoCS').val());
		$('#cantidad').val($('#cantidadCS').val());
		$('#plazo').val($('#plazoCS').val());
		$("#sliderCantidad").slider({ value: $('#cantidad').val().replace('.','')});
		$("#sliderPlazo").slider({ value: $('#plazo').val()});
	}
}

function cambiarClienteParticular(){
    $(".contentCompany").css("display","none");
    $(".contentFreelance").css("display","block");
    $(".section-freelance ").addClass("active");
    $(".section-company ").removeClass("active");
    if (digitalData.segmento == "acceso clientes"){
    	$("#EmpresasPymes-imagen").css("display","none");
	    $("#ParticularesAutonomos-imagen").css("display","block");
	    var href = $('a[title="Oficinas y cajeros"]').attr('href').replace('/empresas/','/particulares/');
	    $('a[title="Oficinas y cajeros"]').attr('href',href);
	    SelectObject = document.getElementById('ui-id-1');
        for(index = 0;  index < SelectObject.length;  index++) {
        	var href1 = SelectObject[index].value.replace('/empresas/','/particulares/');
        	SelectObject[index].value = href1;
        }
    }
}

function cambiarClienteEmpresa(){
    $(".contentCompany").css("display","block");
    $(".contentFreelance").css("display","none");
    $(".section-freelance ").removeClass("active");
    $(".section-company ").addClass("active");
    $(".section-company p").css("color","#35261a");
    if (digitalData.segmento == "acceso clientes"){
    	$("#EmpresasPymes-imagen").css("display","block");
	    $("#ParticularesAutonomos-imagen").css("display","none");
	    var href = $('a[title="Oficinas y cajeros"]').attr('href').replace('/particulares/','/empresas/');
	    $('a[title="Oficinas y cajeros"]').attr('href',href);
	    SelectObject = document.getElementById('ui-id-1');
        for(index = 0;  index < SelectObject.length;  index++) {
        	var href1 = SelectObject[index].value.replace('/particulares/','/empresas/');
        	SelectObject[index].value = href1;
        }
    }
    
}

function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
    results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

function abrirModalLogin(url)  {
	var host = window.location.origin;
	
	if (digitalData.idioma == "en"){
		url = url.replace("_es.","_en.")
	}
	
	if (digitalData.idioma == "ca"){
		url = url.replace("_es.","_ca.")
	}

	if (digitalData.idioma == "va"){
		url = url.replace("_es.","_va.")
	}
	url = host + url;
    $('.modal-container').load(url,function(result){
    	$('#lightboxCondiciones').modal({show:true});
    });
}

function cargaDatosPDF() {
	var datos = "";
	var imagenFinalidadCoche = $("#imagenFinalidadCoche").val();
	var imagenFinalidadReforma = $("#imagenFinalidadReforma").val();
	var imagenFinalidadOtros = $("#imagenFinalidadOtros").val();
	var cuantiaEntrada = $("#cantidad").val();
	var plazoEntrada = $("#plazo").val();
	var finalidadElegida = $(".finalidadSeleccionada").html();
	var cuotaMensualParteEntera =  $("#cuotaMensualPEPdf").html();
	var cuotaMensualParteDecimal =  $("#cuotaMensualPDPdf").html();
	var cuotaMensual =  cuotaMensualParteEntera + cuotaMensualParteDecimal;
	var tin =  $("#tinPdf").html();
	var tae =  $("#taePdf").html();
	var comisionApertura =  $("#comAperturaPdf").html();
	var comisionAperturaImporte =  $("#comAperturaImportePdf").html();
	var interesesImporte =  $("#interesesImportePdf").html();
	var capitalImporte =  $("#capitalImportePdf").html();
	
	if($("#prioridadPrestamoAjax").length > 0){
		cuotaMensualParteEntera =  $("#cuotaMensualPEAjaxPdf").html();
		cuotaMensualParteDecimal =  $("#cuotaMensualPDAjaxPdf").html();
		cuotaMensual =  cuotaMensualParteEntera + cuotaMensualParteDecimal;
		tin =  $("#tinAjaxPdf").html();
		tae =  $("#taeAjaxPdf").html();
		comisionApertura =  $("#comAperturaAjaxPdf").html();
		comisionAperturaImporte =  $("#comAperturaImporteAjaxPdf").html();
		interesesImporte =  $("#interesesImportePdfAjax").html();
		capitalImporte =  $("#capitalImportePdfAjax").html();
	}
	if(undefined != $("#textoMinimoPDF").html()){
		textoMinimo =  $("#textoMinimoPDF").html();
	}
	if(undefined != $("#textoMinimoPDFAjax").html()){
		textoMinimo =  $("#textoMinimoPDFAjax").html();
	}
	var idPrestamo =  $("#idPrestamo").val();
	if(undefined != $("#idPrestamoAjax").val()){
		idPrestamo =  $("#idPrestamoAjax").val();
	}
	datos = ";imagenFinalidadCoche:"+imagenFinalidadCoche+";imagenFinalidadReforma:"+imagenFinalidadReforma+";imagenFinalidadOtros:"+imagenFinalidadOtros+
	";cuantiaEntrada:"+cuantiaEntrada+";plazoEntrada:"+plazoEntrada+";finalidadEntrada:"+finalidadElegida+";cuotaMensual:"+cuotaMensual+
	";tin:"+tin+";tae:"+tae+";comisionApertura:"+comisionApertura+";comisionAperturaImporte:"+comisionAperturaImporte+";textoMinimo:"+textoMinimo.replace('€', '')+";idPrestamo:"+idPrestamo+";interesesImporte:"+interesesImporte+";capitalImporte:"+capitalImporte
	return datos;
}

function downloadPdf (codigo,subtipo,nombre){
	$('.giro').show();
	$('.mod_seguros').addClass('opacity_container');
	$('#errorAjax').hide();
	$('#errorDoc').hide();
	var host = window.location.hostname;
	$.ajax({
		type: "POST",
		url: "/portalunico/services/downloadpdf/pdf?codigo=" + codigo + "&subtipo=" + subtipo,
		contentType: "application/json",
		success: function (respuesta){
			if ((respuesta != null) || (respuesta != 0)){
				var ua = window.navigator.userAgent;
				var msie = ua.indexOf("MSIE ");
				const linkSource = "data:application/pdf;base64," + respuesta['entity'];
				const downloadLink = document.createElement("a");
				const filename = nombre + ".pdf";
				
				setTimeout (function (){
					// If Internet Explorer
					if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)){
						var byteCharacters = atob(respuesta['entity']);
						var byteNumbers = new Array(byteCharacters.length);
						for (var i = 0; i < byteCharacters.length; i++) {
							byteNumbers[i] = byteCharacters.charCodeAt(i);
						}
						var byteArray = new Uint8Array(byteNumbers);
						var blob = new Blob([byteArray], {type: "application/pdf"});
						
						if (respuesta['entity'] !== null){
							window.navigator.msSaveOrOpenBlob(blob, filename);
							$('.giro').hide();
							$('.mod_seguros').removeClass('opacity_container');
						}else{
							$('.giro').hide();
							$('.mod_seguros').removeClass('opacity_container');
							$('#errorDoc').show();
							window.scroll(0,0);
						}
					    
					}else{
						downloadLink.href = linkSource;
						downloadLink.download = filename;
						if (respuesta['entity'] !== null){
							downloadLink.click();
							$('.giro').hide();
							$('.mod_seguros').removeClass('opacity_container');
						}else{
							$('.giro').hide();
							$('.mod_seguros').removeClass('opacity_container');
							$('#errorDoc').show();
							window.scroll(0,0);
						}
					}
						
				},1500)
				
			}else {
				$('.giro').hide();
				$('.mod_seguros').removeClass('opacity_container');
			}

		},
		
		error: function () {
			$('#errorAjax').show();
			window.scroll(0,0);
		}
	});
}
