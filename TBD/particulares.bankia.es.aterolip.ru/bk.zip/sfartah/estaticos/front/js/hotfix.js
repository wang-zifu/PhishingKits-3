$(document).ready(function(){
	
	if(digitalData != null && digitalData!=undefined){
    
		// oficinas-y-cajeros - 2017-07-14 - ancho IE
		if(digitalData.seccion == "oficinas y cajeros"){
			$('.container-fluid').addClass('col-xs-12');
		}
		
		// SISMKD-795 - 2017-11-20
		if(digitalData.seccion == "productos especificos"){
			$('.row.cps-list.fc-accordion_init').removeClass('ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all');
		}
		
			// SISMKD-937 - 2018-05-23
		if (digitalData.segmento == "empresas"){
			if ((screen.width >= 768)&&(screen.width < 1200)){
				$('.hdr-logo').attr('style','top: -2.1875rem');
			}
		}
	}
	
	$(".contentCompany").find("a").first().attr("href","https://oficinaempresas.bankia.es/bole/es/emision-clave-bloqueada.html");
});

$( window ).load(function() {
	
	// 'createDocumentFragment' of undefined
	if($('[name="vcmForm"]').length>0){
	
		if (typeof digitalData.formulario != 'undefined'){
			console.log(digitalData.formulario);
		}
		
		// reload data
		form.ajaxForm(options);
		
		// prevent multiple click events 
		$('[name="vcmForm"]').on('submit', function() {
			console.log("vcmForm submit");
			var input = $( '[name="vcmForm"]' ).find(':input[type=submit]');
			input.prop('disabled', true);
			setTimeout(function(){ 
				input.prop('disabled', false);
			}, 5000);
		});		
		
	}
	
});