$(document).ready(function(){
	
	/*
	setTimeout(function(){
		try{
			if($(window).width() <= 460){
				if ($(".mod_carousel .crl-carouselSpace figure.crl-img img").length) {
				    console.log('Carousel home active');    
				    $(".mod_carousel .crl-carouselSpace figure.crl-img img").each( function( index, value ) {
				    	 if(value != null && value.alt != null && value.alt != undefined){
				        	var textSrc = value.alt;
				        	if(textSrc.indexOf('Hipotecas') >= 0){
				        		// value.src='/estaticos/Portal-unico/imagenes/20190328/Carrusel_hipoteca_mobile_768x288.jpg';
								value.src='/estaticos/Portal-unico/imagenes/20190328/Home-Bankia.es-APP-768x288.jpg';
				        	}
				        }
				    });
				}
			}
		}catch(error){
			console.log('failed fix');
		}
	},500);
	*/
	
	setTimeout(function(){
		try{
			if($(window).width() <= 390){
				if ($(".lyt-box .mod_bannerHeaderSection figure.bhs-img img").length) {
				    $(".lyt-box .mod_bannerHeaderSection figure.bhs-img img").each( function( index, value ) {
				    	 if(value != null && value.alt != null && value.alt != undefined){
				        	var textSrc = value.src;
				        	if(textSrc.indexOf('1920x390pxv2_letras.jpg') >= 0){
				        		value.src='/estaticos/Portal-unico/imagenes/20190328/375x200.BANKIA.ES-verde.jpg';
				        	}
				        }
				    });
				}
			}
		}catch(error){
			console.log('failed fix');
		}
	},100);
	
	setTimeout(function(){
		try{
			 	var imgsCarrousel = new Map();
			 
				if ($(".crl-carouselSpace .crl-list .crl-item picture source").length > 0) {
				    if ($(".crl-carouselSpace .crl-list .crl-item img").length > 0) {
					    $(".crl-carouselSpace .crl-list .crl-item img").each( function( index, value ) {
					    	if(value.src != null && value.src != undefined){
					    		imgsCarrousel.set(index,value.src);
					    	}
					    });
					}
				    $(".crl-carouselSpace .crl-list .crl-item picture source").each( function( index, value ) {
				    	if(value.srcset != null && value.srcset != undefined){
				    		imgsCarrousel.set(index,value.srcset);
				    	}
				    });
				}
				if(imgsCarrousel.size > 0){
					if ($(".crl-carouselSpace .crl-list .crl-item").length > 0) {
					    $(".crl-carouselSpace .crl-list .crl-item").each( function( index, value ) {
					    	var new_figure = document.createElement('figure');
					    	new_figure.classList.add("crl-img");
					    	var new_img = document.createElement('img');
					    	new_img.src = imgsCarrousel.get(index);
					    	new_figure.appendChild(new_img);
					    	value.appendChild(new_figure);
					    });
					}
					if ($(".crl-carouselSpace .crl-list .crl-item picture").length > 0) {
					    $(".crl-carouselSpace .crl-list .crl-item picture").each( function( index, value ) {   	
					    	value.parentNode.removeChild(value);
					    });
					}
				}
		}catch(error){
			console.log('failed fix');
		}
	},100);
	
	
	
});


