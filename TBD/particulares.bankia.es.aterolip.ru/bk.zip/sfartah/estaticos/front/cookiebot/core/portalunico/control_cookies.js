/******************************************************************************
**
** Version
** =======
**
** Version del plugin de cookie (Se mantiene por compatibilidad descendente)
*******************************************************************************/

var version = '3.8';

	function leerCookie(clave)
	{ 
		var valCookie= ""; 
		var buscar= clave + "="; 
		if(document.cookie.length > 0) { 
			pos=document.cookie.indexOf(buscar); 
			if (pos != -1) { 
				pos += buscar.length; 
				fin= document.cookie.indexOf(";", pos); 
			if (fin == -1) 
				fin= document.cookie.length; 
				valCookie= unescape(document.cookie.substring(pos,fin)) 
			} 
		} 
		return valCookie; 
	} 
	
	function escrCookie(clave,valor, dias) { 
		var expirar = ""; 
		
		if(dias == null) { 
			dias = 30;
		}
	  
		var splitHostname = location.hostname.split('.');
		var domainCookie = '.'+splitHostname[splitHostname.length-2]+'.'+splitHostname[splitHostname.length-1];
	  
		var c=new Date;c.setDate(c.getDate()+dias);    
		expirar = "; expires="+ c.toUTCString()+";domain="+domainCookie+"; path=/";  	
			
		escribir = clave+"="+escape(valor)+ expirar; 	
		document.cookie = escribir 
	} 

	function borraCookie(clave) {
		var splitHostname = location.hostname.split('.');
		var domainCookie = '.'+splitHostname[splitHostname.length-2]+'.'+splitHostname[splitHostname.length-1];	
		document.cookie = clave+'=; expires=Thu, 01 Jan 1970 00:00:01 GMT; domain='+domainCookie+'; path=/'; 
		document.cookie = clave+'=; expires=Thu, 01 Jan 1970 00:00:01 GMT; path=/';
	}

$( document ).ready(function() {

    // Asociando consentimiento implícito a elementos de la página distintos de 'a' y que no tienen 'onclick'
	//// Buscador Fondos de inversión
    $("form.mod_form ul.bll-list li label.bll-label").addClass("cookieconsent-implied-trigger");
    $("form.mod_form select#id-nombreFondo").addClass("cookieconsent-implied-trigger");
    $("form.mod_form select#id-categoria").addClass("cookieconsent-implied-trigger");
    // Bankia > Simulador Hipotecas
    $("input#living_place-price-ammount").addClass("cookieconsent-implied-trigger");
    $("div.mod_switch ul.sth_list li.sth_item label.sth_label").addClass("cookieconsent-implied-trigger");
    $("div.suo-groupSlider div#sliderPrecioVivienda").addClass("cookieconsent-implied-trigger");
    $("div.content-infoBlock select#id_acc_provincias").addClass("cookieconsent-implied-trigger");
    $("input#financial_income").addClass("cookieconsent-implied-trigger");
    // Fondos de inversión/Bankia pensiones: Encuentra el fondo/plan que mejor se adapta a ti
    $("div.mod_barLevel ul.bll-list li.bll-item label.bll-label").addClass("cookieconsent-implied-trigger");
    $("div.mod_barLevel button[type='button']").addClass("cookieconsent-implied-trigger");
    $("div.mod_buttons input[type='button']").addClass("cookieconsent-implied-trigger");
    // Simulador de Plan de Pensiones
    $("div.mod_buttons input[type='submit']").addClass("cookieconsent-implied-trigger");
    // Botones "Contratar"
    $("a span").addClass("cookieconsent-implied-trigger");

    // Se activa cuando el banner de consentimiento de cookies se muestra al usuario final.
	 if(((window.location.pathname.indexOf("/Mobile/") !==-1) || (navigator.userAgent.indexOf('oipApp')!==-1)) && !CookieConsent.hasResponse) {
		//Existe un iframe o  la URL=oficina-internet o URL = Mobile, no queremos que se muestre la capa de coockies
		setTimeout(function() {
			Cookiebot.hide();
	    	CookieConsent.submitConsent(!0, window.location.href, !1);
		}, 500);
    	escrCookie('sat_track', 'true', 30);
    	_satellite.track("cookieDTM");
	}

    // El callback asíncrono se activa cuando algún usuario hace
	// clic en el botón de aceptar del diálogo de consentimiento de
	// cookies (o consentimiento implícito) y cada vez que algún 
    // usuario que haya dado su consentimiento carga una página.
    window.addEventListener('CookiebotOnAccept', function (e) {
	        if (Cookiebot.consent.statistics){
	        	if (leerCookie('cc_analytics')!='yes')
	        		escrCookie('cc_analytics','yes',30);
	        	if (leerCookie('sat_track')!='true') {
	        		escrCookie('sat_track', 'true', 30);
	    			_satellite.track("cookieDTM");
	        	}
	        } else {
	        	if (leerCookie('sat_track')!='false')
	        		escrCookie('sat_track', 'false', 30);
	        	borraCookie('cc_analytics');
	        	borraCookie('_ga');
	        	borraCookie('_gid');
	        	borraCookie('_gat');
	        }
	        if (!Cookiebot.consent.preferences){
	        	borraCookie('language');
	        }
	        if (Cookiebot.consent.necessary){
	        	if (leerCookie('bankia_versionCookie')!=version)
	        		escrCookie('bankia_versionCookie',version, 1825);
	        	if (leerCookie('cc_necessary')!='yes')
	        		escrCookie('cc_necessary','yes',30);                           
	        }
        }, false);

    // El evento se activa si el usuario rechaza el uso de cookies
	// haciendo clic en el botón rechazar del diálogo de
	// consentimiento de cookies. El evento también se activa si el
	// usuario ya había rechazado el uso de cookies en una visita
	// anterior al sitio web.
    window.addEventListener('CookiebotOnDecline', function (e) {
    	if (leerCookie('sat_track')!='false')
    		escrCookie('sat_track', 'false', 30);
    	borraCookie('cc_analytics');
    	borraCookie('_ga');
    	borraCookie('_gid');
    	borraCookie('_gat');
    	borraCookie('language');
    }, false);
    
});