$( document ).ready(function() {

var maxSizeButton=0;
	var sizeButton=0;
	$('.mod_relatedSegment').each(function(){
        $(this).find('li').each(function(){
			$(this).find('.rsg-description').each(function(){	
						sizeButton = $(this).height();
				if(sizeButton>maxSizeButton){
					maxSizeButton=sizeButton;	
				}
			});
		 });
    });
	
	
$('.mod_relatedSegment').each(function(){
        $(this).find('li').each(function(){
			$(this).find('.rsg-description').each(function(){	
						if(sizeButton>maxSizeButton){
						$(this).height(maxSizeButton);			
					}
					else{
						$(this).height(maxSizeButton);
					}
			});
		 });
    });

});