$( document ).ready(function() {
	console.log( "ready!" );

	$('.mod_relatedProductsNew').each(function(){
		var maxSizeButton=0;
		var sizeButton=0;
	
        $(this).find('li').each(function(){
			$(this).find('.rps-descriptionBox').each(function(){	
				sizeButton = $(this).height();
				if(sizeButton > maxSizeButton){
					maxSizeButton=sizeButton;	
				}
			});
		 });
		 
		 
        $(this).find('li').each(function(){
			$(this).find('.rps-descriptionBox').each(function(){
				if (sizeButton>0){			
					if(sizeButton>maxSizeButton){
						$(this).height(maxSizeButton);			
					}
					else{
						$(this).height(maxSizeButton);
					}
				}
			});
		 });		 
		 
    });
	
});