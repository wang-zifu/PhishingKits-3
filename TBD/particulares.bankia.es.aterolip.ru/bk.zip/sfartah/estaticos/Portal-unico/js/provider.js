'use strict';

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

{
  var messageEventListener = function messageEventListener(event) {
    var data = event.data;
    if (isTrustedOrigin(event.origin)) listeners.forEach(function (scopeListeners, scope) {
      return scope === data.scope && scopeListeners.forEach(function (listener) {
        return listener(data.message);
      });
    });
  };

  var isTrustedOrigin = function isTrustedOrigin(origin) {
    return trustedOrigins.indexOf(origin) > -1;
  };

  var listeners = new Map();

  var Channel = function () {
    function Channel($window) {
      _classCallCheck(this, Channel);

      this.$window = $window;
    }
    /**
     * Adds the listener to the provided scope
     *
     * @param {string} scope The namespace of the listener
     * @param {function} listener The listener function
     * @returns The listener
     *
     * @memberOf Channel
     */


    Channel.prototype.listen = function listen(scope, listener) {
      if (!listeners.size) this.open();
      if (!listeners.has(scope)) listeners.set(scope, []);
      var scopeListeners = listeners.get(scope);
      if (scopeListeners.indexOf(listener) < 0) scopeListeners.push(listener);
      return listener;
    };
    /**
     * Removes the listener from the provided scope
     *
     * @param {string} scope The namespace of the listener
     * @param {function} listener The reference to the listener function
     * @returns The listener
     *
     * @memberOf Channel
     */


    Channel.prototype.unlisten = function unlisten(scope, listener) {
      var scopeListeners = listeners.get(scope);
      if (scopeListeners) {
        var index = scopeListeners.indexOf(listener);
        if (index > -1) scopeListeners.splice(index, 1);
        if (!scopeListeners.length) listeners.delete(scope);
        if (!listeners.size) this.close();
      }
      return listener;
    };
    /**
     * This method transmit a message to the target window.
     *
     * @param {window} target The target window instance
     * @param {string} scope The namespace of the message
     * @param {any} message The message
     *
     * @memberOf Channel
     */


    Channel.prototype.transmit = function transmit(target, scope, message) {
      trustedOrigins.forEach(function (trustedOrigin) {
        try {
          target.postMessage({
            scope: scope,
            message: message
          }, trustedOrigin);
        } catch (ignore) {
          // Ignore any error
        }
      });
    };
    /**
     * This method opens the channel.
     * It opens the channel to listen incomming messages
     *
     * @memberOf Channel
     */


    Channel.prototype.open = function open() {
      this.$window.addEventListener('message', messageEventListener, false);
    };
    /**
     * This method closes the channel.
     * It stops the channel from listenning any message
     *
     * @memberOf Channel
     */


    Channel.prototype.close = function close() {
      this.$window.removeEventListener('message', messageEventListener, false);
    };

    return Channel;
  }();

  var trustedOrigins = [];

  var ChannelProvider = function () {
    function ChannelProvider() {
      _classCallCheck(this, ChannelProvider);
    }
    /**
     * Method to trust in the provided document origins.
     * Any message transmitted from this service will be sent only if the target window origin is added through this method
     * This service will only listen to window origins added through this method
     *
     * @param {string} params A list of origin URLs
     *
     * @memberOf ChannelProvider
     */


    ChannelProvider.prototype.addTrustedOrigins = function addTrustedOrigins() {
      for (var _len = arguments.length, params = Array(_len), _key = 0; _key < _len; _key++) {
        params[_key] = arguments[_key];
      }

      trustedOrigins.push.apply(trustedOrigins, params);
    };
    /* @ngInject */


    ChannelProvider.prototype.$get = function $get($window) {
      return new Channel($window);
    };

    return ChannelProvider;
  }();

  window.ChannelProvider = ChannelProvider;
}