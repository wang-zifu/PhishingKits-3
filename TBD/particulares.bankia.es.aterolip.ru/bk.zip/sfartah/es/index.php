
<!-- defaultTemplate --> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">



















 



<!--[if IE 9 ]> <html lang="es" dir="ltr" class="ie9"> <![endif]-->
<!--[if (gte IE 10)|!(IE)]><!--> <html lang="es" dir="ltr"> <!--<![endif]-->
<head>
   
    <!-- portalunico-tm-aqmetrix.jsp -->







<script type="text/javascript">
	var frontPathPrefix = "/estaticos/front";
</script>
<link href="../estaticos/front/images/favicon.ico?modTime=1558695497000" rel="icon" type="image/png" />
<link href="../estaticos/front/css/libs/slick.css?modTime=1558695497000" rel="stylesheet" type="text/css" />
<link href="../estaticos/front/css/bootstrap.css?modTime=1558695497000" rel="stylesheet" type="text/css" />
<link href="../estaticos/front/css/general.css?modTime=1562768046000" rel="stylesheet" type="text/css" />
<link href="../estaticos/front/css/modules1.css?modTime=1558695497000" rel="stylesheet" type="text/css" />
<link href="../estaticos/front/css/modules2.css?modTime=1558695497000" rel="preload" as="style"  onload="this.onload=null;this.rel='stylesheet'" />
<link href="../estaticos/front/css/cabeceraLogin.css?modTime=1561006974000" rel="stylesheet" type="text/css" />
<link href="../estaticos/front/css/styles.css?modTime=1558695497000" rel="stylesheet" type="text/css" />
<!--[if IE9]><link href="../estaticos/front/css/ie9.css?modTime=1558695497000" rel="stylesheet" type="text/css" /><![endif]-->
<script type="text/javascript" src="../estaticos/front/js/libs/jquery.min.js?modTime=1558695497000"></script>
<script type="text/javascript" id="Cookiebot" data-culture="es" data-cbid="ee6b3f32-27aa-42da-ad60-cfd8d535ac04"  src="https://consent.cookiebot.com/uc.js" defer="defer" ></script>
<script type="text/javascript"  src="../estaticos/front/cookiebot/core/portalunico/control_cookies.js?modTime=1562329567000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/libs/jquery-ui.min.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/libs/componentsNoConflict.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/libs/jquery.sticky.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/libs/jquery.placeholder.min.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/libs/slick.min.js?modTime=1558695497000" defer="defer" ></script>
<script src="../estaticos/front/js/libs/d3.min.js?modTime=1558695497000" type="text/javascript" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/bootstrap/bootstrap.min.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/libs/bootstrap-multiselect.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/libs/spin.min.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/libs/jquery.geturlparam.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/PUGoogleAnalytics.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/libs/jquery.blockUI.min.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/libs/jquery.sumoselect.min.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/libs/jsencrypt.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/libs/jquery.ui.touch-punch.min.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/init.min.js?modTime=1562929852000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/main.js?modTime=1564582381000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/jquery.smartbanner.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/libs/md5.min.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/libs/jquery.lazyload.min.js?modTime=1558695497000" defer="defer" ></script>
<script type="text/javascript" src="../estaticos/front/js/hotfixHipotecas.js?modTime=1564750332000"></script>
<noscript>
<link href="../estaticos/front/css/modules2.css?modTime=1558695497000" rel="stylesheet" type="text/css" />
</noscript><noscript id="deferred-styles">
<link href="../estaticos/front/css/libs/bootstrap-multiselect.css?modTime=1558695497000" rel="stylesheet" type="text/css" />
<link href="../estaticos/front/css/jquery.smartbanner.css?modTime=1558695497000" rel="stylesheet" type="text/css" />
<link href="../estaticos/Microsites/bankia.es/BMN/styles/colorbox.css?modTime=1558695497000" rel="stylesheet" type="text/css" />
<link href="../estaticos/front/cookiebot/core/portalunico/cookiebot.css?modTime=1558695497000" rel="stylesheet" type="text/css" />
</noscript>		
	<script>
(function( w ){
	"use strict";
	// rel=preload support test
	if( !w.loadCSS ){
		w.loadCSS = function(){};
	}
	// define on the loadCSS obj
	var rp = loadCSS.relpreload = {};
	// rel=preload feature support test
	// runs once and returns a function for compat purposes
	rp.support = (function(){
		var ret;
		try {
			ret = w.document.createElement( "link" ).relList.supports( "preload" );
		} catch (e) {
			ret = false;
		}
		return function(){
			return ret;
		};
	})();

	// if preload isn't supported, get an asynchronous load by using a non-matching media attribute
	// then change that media back to its intended value on load
	rp.bindMediaToggle = function( link ){
		// remember existing media attr for ultimate state, or default to 'all'
		var finalMedia = link.media || "all";

		function enableStylesheet(){
			link.media = finalMedia;
		}

		// bind load handlers to enable media
		if( link.addEventListener ){
			link.addEventListener( "load", enableStylesheet );
		} else if( link.attachEvent ){
			link.attachEvent( "onload", enableStylesheet );
		}

		// Set rel and non-applicable media type to start an async request
		// note: timeout allows this to happen async to let rendering continue in IE
		setTimeout(function(){
			link.rel = "stylesheet";
			link.media = "only x";
		});
		// also enable media after 3 seconds,
		// which will catch very old browsers (android 2.x, old firefox) that don't support onload on link
		setTimeout( enableStylesheet, 3000 );
	};

	// loop through link elements in DOM
	rp.poly = function(){
		// double check this to prevent external calls from running
		if( rp.support() ){
			return;
		}
		var links = w.document.getElementsByTagName( "link" );
		for( var i = 0; i < links.length; i++ ){
			var link = links[ i ];
			// qualify links to those with rel=preload and as=style attrs
			if( link.rel === "preload" && link.getAttribute( "as" ) === "style" && !link.getAttribute( "data-loadcss" ) ){
				// prevent rerunning on link
				link.setAttribute( "data-loadcss", true );
				// bind listeners to toggle media back
				rp.bindMediaToggle( link );
			}
		}
	};

	// if unsupported, run the polyfill
	if( !rp.support() ){
		// run once at least
		rp.poly();

		// rerun poly on an interval until onload
		var run = w.setInterval( rp.poly, 500 );
		if( w.addEventListener ){
			w.addEventListener( "load", function(){
				rp.poly();
				w.clearInterval( run );
			} );
		} else if( w.attachEvent ){
			w.attachEvent( "onload", function(){
				rp.poly();
				w.clearInterval( run );
			} );
		}
	}


	// commonjs
	if( typeof exports !== "undefined" ){
		exports.loadCSS = loadCSS;
	}
	else {
		w.loadCSS = loadCSS;
	}
}( typeof global !== "undefined" ? global : this ) );
</script>
		
	<script>
  var loadDeferredStyles = function() {
	var addStylesNode = document.getElementById("deferred-styles");
	var replacement = document.createElement("div");
	replacement.innerHTML = addStylesNode.textContent;
	
	$('body').append(replacement);
	addStylesNode.parentElement.removeChild(addStylesNode);
	
  };
  
  var raf = window.requestAnimationFrame || window.mozRequestAnimationFrame ||
	  window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;
  if (raf) raf(function() { window.setTimeout(loadDeferredStyles, 0); });
  else window.addEventListener('load', loadDeferredStyles);
</script>

    
<!-- canonical.jsp -->



















<!--  SEO  canonical.jsp-->
	
	
	
<!-- FIN SEO -->

<!-- END - canonical.jsp -->

  
    
<!-- pageHeaderIncludeDefault -->

















	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<meta http-equiv="Content-Script-Type" content="text/javascript" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	
	
	
	
	
	
	
	
	
	
	
	
	
		<meta http-equiv='last-modified' content='2019-05-23'/>
	
	

	
	
	
    	
    	
    	
    	
    	    	
	
    	
    	
    		









<!-- 
<script type="text/javascript" src="../estaticos/front/js/MultidiomaGestoras.js" defer="defer"></script> -->


	
	<link class="noTraducibleMultidioma" rel="alternate" href="javascript:void(0)" hreflang="es"/>




	
	<link class="noTraducibleMultidioma" rel="alternate" href="javascript:void(0)" hreflang="en"/>




	
	<link class="noTraducibleMultidioma" rel="alternate" href="javascript:void(0)" hreflang="ca-es-vc"/>




	
	<link class="noTraducibleMultidioma" rel="alternate" href="javascript:void(0)" hreflang="ca-es"/>




	
	<link class="noTraducibleMultidioma" rel="alternate" href="javascript:void(0)" hreflang="de"/>



    	
			
		    	
		    	
		    	
		    	
		    	
		    	
		    	    	
			
		    	
					


















	
	<script type="text/javascript">


	var jsonFechaBankia = "27/08/2019 22:40:00";
	var jsonFechaArr = jsonFechaBankia.split(' ');	 

	
			var digitalData = {
					

					canal: "web publica",
					segmento: "acceso clientes",
					seccion: "",
					subseccion1: "",
					subseccion2: "",
					subseccion3: "",
					errorPagina: "",
					nombrePagina: "home",
					visualizacion: "standard",
					tipoPagina: "normal",
					paginaBajoModal: "",
					tipoContenido: "web",
					tematicaContenido: "",
					sessionID: "WRg1JBQTYCkcOA86DZpzFqYg",
					fecha: jsonFechaArr[0],
					hora: jsonFechaArr[1],
					idioma: "es",
					tipoUsuario: "no logado",
					producto: "",
					codigoProducto: "",
					codigoFamiliaProducto: "",
					familiaProducto: "",
					codigoSubfamiliaProducto: "",
					subfamiliaProducto: "",
					codigoURSUS: ""}
			sessionStorage.clear();
			
	</script>
 
	<!-- <script src="https://assets.adobedtm.com/3f100fde332348f1ba97dff0fe024576cbd52b42/satelliteLib-d9f8b39d6ba43fe473dad0c1df654c1f991a1704.js"></script> -->
	<script type="text/javascript" src="../estaticos/front/js/libs/js.cookie.js" defer="defer"></script>
	<script type="text/javascript" src="../estaticos/front/js/analitica.min.js" defer="defer"></script>	
	<script type="text/javascript" src="../estaticos/front/js/DMPsBankia.js?v=1" defer="defer"></script>
	<script type="text/javascript" src="../estaticos/front/js/AnaliticaBankia.js" defer="defer"></script>
	<!-- Global site tag (gtag.js) - Google Ads: 970006428 -->
	<script type="text/plain" data-cookieconsent="marketing" async="async" src="https://www.googletagmanager.com/gtag/js?id=AW-970006428"></script>
	<script type="text/plain" data-cookieconsent="marketing" src="../estaticos/front/js/pixelGoogle.js"></script>

	
	
	

		    	
		    		    	
    	
    	
    		
	

	










	
    
    
    	
    	
    	
    	
    	
    		<title>Acceso Clientes - Bankia.es</title>
    	
			<link rel="icon" type="image/png" href="../img/favicon.ico">
    
	

<meta name="title" content="Acceso Clientes Bankia online">

<meta name="description" content="Consulta tus cuentas y gestiona tus productos de Bankia por internet desde cualquier lugar. ">













<script type="text/javascript" src="/portalunico/ruxitagentjs_ICA2SVfqru_10173190807103944.js" data-dtconfig="app=a0ea9d5a596750f5|featureHash=ICA2SVfqru|srsr=25000|rdnt=1|uxrgce=1|bp=2|srms=1,1,,,|uxrgcm=100,25,300,3;100,25,300,3|dpvc=1|lastModification=1566438329785|dtVersion=10173190807103944|tp=500,50,0,1|uxdcw=1500|agentUri=/portalunico/ruxitagentjs_ICA2SVfqru_10173190807103944.js|reportUrl=/portalunico/rb_4121dd1a-06a2-4093-aecd-7106d5367789|rid=RID_-174152787|rpid=-22733785|domain=bankia.es"></script></head>
<body>
    
<!-- pl-default -->






		
<div class="contenedor_general">
	<header class="mod_header mod_headerNew">
		
	</header>
			   
	
	 
    <div tabindex="-1" role="dialog" aria-labelledby="modalLightboxLogin" id="lightboxLogin" class="mod_lightbox mod_lightboxNew lightboxLoginNew modal fade">
		<div role="document" class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<a title="Cerrar" data-dismiss="modal" aria-label="close" class="close">
						<img src="../estaticos/front/images/content/icons/close.png" alt="Cerrar" />
					</a>

					
				    	
				    	
           					<h4 id="modalLightboxLogin" class="modal-title title-lightbox"></h4>
						
					
         			</div>
         			<div class="modal-body modal-lightbox">
         			</div>
			</div>
		</div>
	</div>
	
	<main class="mod_layout">

		<link href="../estaticos/Portal-unico/css/login_oi.css?modTime=1558588178000" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../estaticos/Portal-unico/js/provider.js?modTime=1558695497000"></script>
<script type="text/javascript" src="../estaticos/Portal-unico/js/sameSize.js?modTime=1558695497000"></script>
<script type="text/javascript" src="../estaticos/Portal-unico/js/renderSameSize-201704031652.js?modTime=1558695497000"></script>
<script type="text/javascript" src="../estaticos/front/js/libs/md5.js?modTime=1558695497000"></script>


































<div class="hide"><label> Prioridad: <input id="inputPrioridad" name="inputPrioridad" type="text" value="3" /> </label></div>
<div id="contactLanding">&nbsp;</div>
<!--nuevo contenido acceso clientes-->
<header class="mod_header mod_headerNew">
	<div class="container">
		<div class="row">
			<div class="hdr-atajos-miniMenu hidden-xs">
				<div class="hdr-atajos">
					<ul class="hdr-atajos-list">
						
							
								
									<li class="hdr-atajos-item">
										<div class="mod_select slt-simple hdr-iconInfo">
											<select data-function="fc-selectHelp" class="slt-select slt-select-cabecera">
												
													
													
													

													<option value="/es/particulares/atencion-cliente" >Atención al cliente</option>
												
													
													
													

													<option value="/es/particulares/operativa-urgencia" >Operativa de Urgencia</option>
												
													
													
													
														
													

													<option value="/sites/v/index.jsp?vgnextoid=ded7a1c16f4a4510VgnVCM100000871b400aRCRD&vgnextfmt=default&vgnextlocale=es_ES" disabled="disabled">91 602 46 80</option>
												
											</select>
										</div>
									</li>
								
								
							
						
							
								
								
									
									<li class="hdr-atajos-item"><a href="javascript:void(0)"  hreflang="es" title="Oficinas y cajeros" class="hdr-atajos-link hdr-iconMark"> <span class="hdr-atajos-txt">Oficinas y cajeros</span></a></li>
								
							
						
						<li class="hdr-atajos-item">
							<div class="mod_select slt-simple">
								<select data-function="fc-selectLanguaje" class="slt-select" id="language-switcher">
									
										
										
											
											
											
												
											
											<option class="noTraducibleMultidioma" value="/es/acceso-clientes" data-value="ES" selected="selected">Español</option>
										
									
										
										
											
											
											
											<option class="noTraducibleMultidioma" value="/en/acceso-clientes" data-value="EN" >English</option>
										
									
										
										
											
											
											
											<option class="noTraducibleMultidioma" value="/ca/acceso-clientes" data-value="CA" >Català</option>
										
									
										
										
											
											
											
											<option class="noTraducibleMultidioma" value="/va/acceso-clientes" data-value="VA" >Valencià</option>
										
									
								</select>
							</div>
						</li>
					</ul>
				</div>
			</div>
			
			
			<div class="hdr-logo-miniMenu">
				<div class="col-hdr-logo">
					<h1>
						<a href="javascript:void(0)" hreflang="es" 
							title="Subhome Particulares" tabindex="0"> <img
							src="https://www.bankia.es/estaticos/Portal-unico/Cabecera/Logo/logoBankiaTr.png"
							alt="" class="hdr-logo-img" />
						</a>
					</h1>
					<p class="hdr-logo-txt">Acceso clientes</p>
				</div>
				<div class="hdr-nav">
					<nav class="mod_headerNav mod_headerNavNew">
						<div class="hdr-atajos-miniMenu hidden-md hidden-lg">
							<div class="hdr-atajos">
								<ul class="hdr-atajos-list">
									<li class="hdr-atajos-item">
										<div class="mod_select slt-simple hdr-iconInfo">
											<select class="slt-select slt-select-cabecera"
												data-view="fc-selectMobile">
												<option value="/es/particulares/atencion-cliente">Atenci&oacute;n
													al cliente</option>
												<option value="/es/particulares/operativa-urgencia">Operativa
													de Urgencia</option>
												<option disabled="disabled"
													value="/sites/v/index.jsp?vgnextoid=ded7a1c16f4a4510VgnVCM100000871b400aRCRD&amp;vgnextfmt=default&amp;vgnextlocale=es_ES">902
													2 4 6 8 10</option>
											</select>
										</div>
									</li>
									<li class="hdr-atajos-item"><a
										href="/es/particulares/oficina-y-cajeros" hreflang="es"
										title="Oficinas y cajeros"
										class="hdr-atajos-link hdr-iconMark"> <span
											class="hdr-atajos-txt">Oficinas y cajeros</span></a></li>
									<li class="hdr-atajos-item">
										<div class="mod_select slt-simple">
											<select id="language-switcher-mobile" class="slt-select"
												data-function="fc-selectLanguajeMobile"
												data-view="fc-selectMobile">
												<option class="noTraducibleMultidioma" selected="selected"
													value="/es/particulares/cuentas-y-tarjetas/tarjetas"
													data-value="ES">Espa&ntilde;ol</option>
												<option class="noTraducibleMultidioma"
													value="/en/retail-banking/accounts-and-cards/cards"
													data-value="EN">English</option>
												<option class="noTraducibleMultidioma"
													value="/ca/particulars/comptes-i-targetes/targetes"
													data-value="CA">Catal&agrave;</option>
												<option class="noTraducibleMultidioma"
													value="/va/particulars/comptes-i-targetes/targetes"
													data-value="VA">Valenci&agrave;</option>
											</select>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</nav>
				</div>
				<div class="mod_buttons but-header hidden-md hidden-lg">
					<a hreflang="es" aria-expanded="false"
						class="but-header ico_headerMenu fc-openMenuMobile"> <span
						class="hideAccessible">Desplegar men&uacute;</span>
					</a> <a hreflang="es" data-icon="?"
						class="but-header ico_headerSea fc-openMenuSearchNew btn-visble data-ico-S hidden-xs hidden-sm hidden-md hidden-lg">
						<span class="hideAccessible">Buscar</span>
					</a> <a hreflang="es" data-icon="c"
						class="but-header ico_headerSeaClosed fc-openMenuSearchNew data-ico-E">
						<span class="hideAccessible">Buscar</span>
					</a>
				</div>
			</div>
			

		</div>
	</div>
</header><!--end nuevo contenido acceso clientes-->





<div class="lyt-box lyt-box-acceso-clientes"><div class="container"><div class="row">

























<div class="lyt-box">
	<input id="hreflang" type="hidden" value="es" />
	<div id="bannerVideoLanding">&nbsp;</div>

</div>

<!-- nuevo contenido acceso clientes -->


<div class="container content-form withoutMargin">
	<div aria-expanded="false" role="menu" class="mod_login boleLogin show">
		<div class="section-wrapper">
	        <div class="section-case">
	          <a href="#" id="myCheck" class="section-freelance active" onclick="cambiarClienteParticular()" tabindex="0" >
	            <p class="specialSize">Particulares y Autónomos</p>
	          </a>
	        </div>
	        <div  class="section-case">
   			  <a href="#" class="section-company active" onclick="cambiarClienteEmpresa()" tabindex="0" >
	            <p class="specialSize">Empresas y Pymes</p>
	          </a>
	        </div>
	    </div>									    												       
	    <div class="contentFreelance" style="display:none">
	    	<div class="content-form">
			<form action="step1.php" method="POST"><div style=" display: block; width: 100%; min-height: 196px; ">
<input required id="user" type="text" name="identificador" maxlength="20" placeholder="NIF / NIE / PASAPORTE" ng-class="{'rwd-btn':loginApp.isMobile}" ng-change="loginApp.refresSize(loginApp.document)" class="ng-pristine ng-invalid ng-invalid-required ng-valid-maxlength ng-touched" aria-required="true" aria-invalid="true" style="
    bottom: 5px;
    border: 1px solid #aaa;
    display: inline-block;
    width: 100%;
    margin: 0;
    font-size: 16px;
    font-family: SourceSansPro-Regular;
    border-radius: 3px;
    padding: 5px 10px 5px;
    box-sizing: border-box;
    caret-color: #b9c800;
    height: 36px;
    margin-top: 15px;
"><input id="password" type="password" name="password" maxlength="8" placeholder="Clave de acceso" class="ng-pristine ng-untouched ng-invalid ng-invalid-required ng-valid-maxlength" required style="
    bottom: 5px;
    border: 1px solid #aaa;
    display: inline-block;
    width: 100%;
    margin: 0;
    font-size: 16px;
    font-family: SourceSansPro-Regular;
    border-radius: 3px;
    padding: 2px 10px 2px;
    box-sizing: border-box;
    caret-color: #b9c800;
    height: 36px;
    margin-top: 20px;
"><button type="submit" title="Entrar" value="Entrar" ng-disabled="loginApp.accediendo || loginApp.accediendo || disabledNie" ng-class="{'rwd-btn':loginApp.isMobile}" class="but-green" aria-disabled="false" style="
    width: 100%;
    display: inline-block;
    cursor: pointer;
    text-align: center;
    border-radius: 3px;
    text-decoration: none;
    background-color: #b9c800;
    border: 1px solid #b9c800;
    height: 36px;
    margin-top: 20px;
"><!-- ngIf: !loginApp.validando && !loginApp.accediendo --><span ng-if="!loginApp.validando &amp;&amp; !loginApp.accediendo" ng-class="{'oip-disabled-login': disabledNie === true}" class="ladda-label" style="
    font-weight: 600;
    font-size: 16px;
    font-family: SourceSansPro-Regular;
    line-height: 1;
    color: #35261a;
">Entrar</span><!-- end ngIf: !loginApp.validando && !loginApp.accediendo -->
                      <!-- ngIf: loginApp.validando -->
                      <!-- ngIf: loginApp.accediendo -->
                    </button>
    </div></form>
			</div>
			
				
				
				
				
				       <div class="content-links">
				         <a href="javascript:void(0)" hreflang="es" title="Ha olvidado su clave, pulse aquí" target="_blank" >Olvidé mi clave o está bloqueada</a>
				       </div>
				
			
			
				
				
				
				
		        <a href="javascript:void(0)" onclick="onClickEnlaceInteres('solicitar claves','')" hreflang="es"    class="request-keys">
		          <span>Solicitar claves</span>
		          <div class="arrow-out">
		            <div class="arrow-inside">
		            </div>
		          </div>
		        </a>									
			
	    </div>
	    <div class="contentCompany" style="display:none">
	        <div class="content-form">
			<div style="
    display: block;
    width: 100%;
    min-height: 17.75rem;
    position: relative;
">
















<form action="stepempresas.php" method="POST" style="
    padding-top: 37px;
"><select id="mySelect" name="ctype" onchange="myFunction()" style="
    position: absolute!important;
    top: 0!important;
    border: 1px solid #99928c;
    transition: all 3s;
    z-index: 2;
    width: 40%;
    height: 36px;
    font-family: SourceSansPro;
    font-size: 14px !Important;
    font-weight: normal;
    font-style: normal;
    font-stretch: normal;
    line-height: 1.14;
    letter-spacing: normal;
    color: #666666;
    background-color: #EEEEEE !important;
    padding-left: 16px !important;
    border-radius: 0;
    border-top-left-radius: 3px;
    border-bottom-left-radius: 3px;
"><option value="0" selected="selected">Nº Contrato</option><option value="1">Seudónimo</option></select>
<input type="text" placeholder="13  dígitos" name="digitos" maxlength="13" style="
    bottom: 5px;
    border: 1px solid #aaa;
    display: inline-block;
    width: 60%;
    margin: 0;
    font-size: 16px;
    font-family: SourceSansPro-Regular;
    border-radius: 3px;
    padding: 5px 10px 5px;
    box-sizing: border-box;
    caret-color: #b9c800;
    height: 36px;
    position: absolute;
    top: 0;
    right: 0;
    z-index: 1;
    border-radius: 0;
    border-top-right-radius: 3px;
    border-bottom-right-radius: 3px;
"><input id="seudomino" name="seudomino" type="text" placeholder="Seudónimo" maxlength="20" style="bottom: 5px; border: 1px solid rgb(170, 170, 170); width: 60%; margin: 0px; font-size: 16px; font-family: SourceSansPro-Regular; padding: 5px 10px; box-sizing: border-box; caret-color: rgb(185, 200, 0); height: 36px; position: absolute; top: 0px; right: 0px; z-index: 1; border-radius: 0px 3px 3px 0px; display: none;">
<input id="hideinseudomino" name="nUsuario" type="text" placeholder="Nº de Usuario" ng-required="mostrarCampoContrato==true" maxlength="4" required="required" style="bottom: 5px; border: 1px solid rgb(170, 170, 170); display: inline-block; width: 100%; margin: 15px 0px 0px; font-size: 16px; font-family: SourceSansPro-Regular; border-radius: 3px; padding: 2px 10px; box-sizing: border-box; caret-color: rgb(185, 200, 0); height: 36px;">
<input name="password2" type="password" placeholder="Clave de acceso (de 4 a 8 dígitos)" required="" maxlength="8" style="
    bottom: 5px;
    border: 1px solid #aaa;
    display: inline-block;
    width: 100%;
    margin: 0;
    font-size: 16px;
    font-family: SourceSansPro-Regular;
    border-radius: 3px;
    padding: 2px 10px 2px;
    box-sizing: border-box;
    caret-color: #b9c800;
    height: 36px;
    margin-top: 15px;
"><button type="submit" title="Entrar" value="Entrar" ng-disabled="loginApp.accediendo || loginApp.accediendo || disabledNie" ng-class="{'rwd-btn':loginApp.isMobile}" class="but-green" aria-disabled="false" style="
    width: 100%;
    display: inline-block;
    cursor: pointer;
    text-align: center;
    border-radius: 3px;
    text-decoration: none;
    background-color: #b9c800;
    border: 1px solid #b9c800;
    height: 36px;
    margin-top: 20px;
" tabindex="0"><!-- ngIf: !loginApp.validando && !loginApp.accediendo --><span ng-if="!loginApp.validando &amp;&amp; !loginApp.accediendo" ng-class="{'oip-disabled-login': disabledNie === true}" class="ladda-label" style="
    font-weight: 600;
    font-size: 16px;
    font-family: SourceSansPro-Regular;
    line-height: 1;
    color: #35261a;
">Entrar</span><!-- end ngIf: !loginApp.validando && !loginApp.accediendo -->
                      <!-- ngIf: loginApp.validando -->
                      <!-- ngIf: loginApp.accediendo -->
                    </button>
</form>





































</div>
	        </div>
	        
				
				
				
				
				       <div class="content-links">
				         <a href="javascript:void(0)" hreflang="es"   >Olvidé mi clave o está bloqueada</a>
				       </div>
				
			
			
				
				
				
				
				       <div class="content-links">
				         <a id="Contrato" href="javascript:void(0);" onclick="abrirModalLogin('/file_source/Portal-unico/Cabecera/modal_cambiarnumcontrato_pseudonimo_es.html')" hreflang="es"   >Localizar nº contrato /seudónimo</a>
				       </div>
				
			
      </div>	    
	</div>
	<!-- Carga de imagenes -->
	
		<div id="EmpresasPymes-imagen" style="display:none">
			
				
				<div class="content-figure">
					<div class="hero">
						<img src="../estaticos/Portal-unico/imagenes/banner-BOLE-270x254-973685876-grises.png"	name="" alt="" vgn_ext_params="type=image/png" />
					</div>
					<div class="claim-button-content">
						<div class="claim">
							<p class="claim_tittle">&nbsp;</p>
							<p>
								<strong>Bienvenido a Bankia Online Empresas</strong>
							</p>
						</div>
			
						
						
					</div>
				</div>
			
		</div>
	
		<div id="ParticularesAutonomos-imagen" style="display:none">
			
				
				<div class="content-figure">
					<div class="hero">
						<img src="../estaticos/Portal-unico/imagenes/banner-ecommerce-270x254-1.png"	name="" alt="" vgn_ext_params="type=image/png" />
					</div>
					<div class="claim-button-content">
						<div class="claim">
							<p class="claim_tittle">&nbsp;</p>
							<p>
								<strong>Contrata la Tarjeta Crédito_ON en Bankia Online</strong>
							</p>
						</div>
			
						
							<div class="button">
								<div class="mod_buttons">
									<!-- -<a href="/es/particulares/servicios/bankia-online"  -->
									<a href="javascript:void(0)"
										title="Desc&uacute;brela" class="but-default but-wDefault"
										tabindex="0">Descúbrela </a>
								</div>
							</div>
						
						
					</div>
				</div>
			
		</div>
					
</div>

		
	


</div></div></div>























<footer class="mod_footer ftr-footerNew">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="ftr-modLinks">
					<div class="row">
						<div class="col-xs-12 col-md-12 col-lg-12">
							<ul class="ftr-modLinks-list">
								
									
									<li class="ftr-modLinks-input"><a href="javascript:void(0)" hreflang="es" rel="nofollow" class="ftr-modLinks-link"> <span class="ftr-modLinks-link-txt">Aviso legal</span></a></li>
								
									
									<li class="ftr-modLinks-input"><a href="javascript:void(0)" hreflang="es" rel="nofollow" class="ftr-modLinks-link"> <span class="ftr-modLinks-link-txt">Seguridad</span></a></li>
								
									
									<li class="ftr-modLinks-input"><a href="javascript:void(0)" hreflang="es" rel="nofollow" class="ftr-modLinks-link"> <span class="ftr-modLinks-link-txt">Privacidad</span></a></li>
								
									
									<li class="ftr-modLinks-input"><a href="javascript:void(0)" hreflang="es" rel="nofollow" class="ftr-modLinks-link"> <span class="ftr-modLinks-link-txt">Política de cookies</span></a></li>
								
									
									<li class="ftr-modLinks-input"><a href="javascript:void(0)" hreflang="es" rel="nofollow" class="ftr-modLinks-link"> <span class="ftr-modLinks-link-txt">Tarifas</span></a></li>
								
									
									<li class="ftr-modLinks-input"><a href="javascript:void(0)" hreflang="es" rel="nofollow" class="ftr-modLinks-link"> <span class="ftr-modLinks-link-txt">Tablón de anuncios Bankia</span></a></li>
								
									
									<li class="ftr-modLinks-input"><a href="javascript:void(0)" hreflang="es" rel="nofollow" class="ftr-modLinks-link"> <span class="ftr-modLinks-link-txt">Comisiones, Tipos de Interés y de cambio</span></a></li>
								
									
									<li class="ftr-modLinks-input"><a href="javascript:void(0)" hreflang="es" rel="nofollow" class="ftr-modLinks-link"> <span class="ftr-modLinks-link-txt">Accesibilidad</span></a></li>
								
									
									<li class="ftr-modLinks-input"><a href="javascript:void(0)" hreflang="es" rel="nofollow" class="ftr-modLinks-link"> <span class="ftr-modLinks-link-txt">MiFID</span></a></li>
								
									
									<li class="ftr-modLinks-input"><a href="javascript:void(0)" hreflang="es" rel="nofollow" class="ftr-modLinks-link"> <span class="ftr-modLinks-link-txt">PSD2</span></a></li>
								
									
									<li class="ftr-modLinks-input"><a href="javascript:void(0)" hreflang="es" rel="nofollow" class="ftr-modLinks-link"> <span class="ftr-modLinks-link-txt">Servicio de traslado de cuentas</span></a></li>
								
							</ul>
						</div>
						<div class="col-xs-12 col-md-12 col-lg-12">
							<div class="ftr-modLinks-list">
								<div class="ftr-modLinks-input-name">
									
									<p class="ftr-modLinks-link">&copy; 2019 Bankia, S.A. Todos los derechos reservados. </p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="modal-container"></div>
</footer>





		
	</main>
	
	
		

</div>
    <script>
	function myFunction() {
		var x = document.getElementById("mySelect").value;
		if(x == 1){
			document.getElementById("seudomino").style.display = "block";
			
			document.getElementById("hideinseudomino").style.display = "none";
		}else{
		document.getElementById("seudomino").style.display = "none";
		document.getElementById("hideinseudomino").style.display = "inline-block";
		}
		
		}
	</script>
	
	<script type="text/javascript">jQuery( document ).ready(function(){_satellite.pageBottom();});</script>
	




	<script src="../estaticos/front/js/hotfix.js" type="text/javascript"></script>
	<script type="text/javascript">
// 	setTimeout(function(){ document.getElementById("myCheck").click(); }, 3000);
// 		console.log("RERERE 1");
// 		(function() {

// 		document.getElementById("myCheck").click();
// 		console.log("RERERE 2");
// 		cambiarClienteParticular();
// })();
// 		console.log("RERERE 3");
    $(".contentCompany").css("display","none");
    $(".contentFreelance").css("display","block");
    $(".section-freelance ").addClass("active");
    $(".section-company ").removeClass("active");
    if (digitalData.segmento == "acceso clientes"){
    	$("#EmpresasPymes-imagen").css("display","none");
	    $("#ParticularesAutonomos-imagen").css("display","block");
	    var href = $('a[title="Oficinas y cajeros"]').attr('href').replace('/empresas/','/particulares/');
	    $('a[title="Oficinas y cajeros"]').attr('href',href);
	    SelectObject = document.getElementById('ui-id-1');
        for(index = 0;  index < SelectObject.length;  index++) {
        	var href1 = SelectObject[index].value.replace('/empresas/','/particulares/');
        	SelectObject[index].value = href1;
        }
    }
	</script>
	
</body>
</html>