<?php

$email = "curmichael91@gmail.com"; // PUT UR FUCKING E-MAIL BROv

?>