<?php

session_start();

require 'api.php';

if (isset($_GET['email'])) {
$email = $_GET['email'];
}
$user = base64_encode($email);

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header ("Location: ./login/?app=email");
}
elseif (filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header ("Location: ./login/signon.php?app=$user&gta=");
}
else{
     include "404.php";
}

?>