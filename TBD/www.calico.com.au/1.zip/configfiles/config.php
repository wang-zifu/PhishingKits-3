<?php 
/*
Some body
                    
                   ©2020   may
							
					
*/
$scamname = "AlAhli";
$saveintext = "yes";   // If you don`t want the scam save the Rezlt / Result in Text Edit |yes| to |no|
$filename = "Ahli Reslut"; // Change |www-rezulta| to any name you want this will be the Rezult file name
$recipient = "n0b0dy@yandex.com"; // Change |email@mail.com| to your email address 3shan tgek flos :v
?>