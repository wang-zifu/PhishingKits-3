<?php
$email = $_GET['email'];
header("Location: login.php?errorType=401&error&email=$email");
?>