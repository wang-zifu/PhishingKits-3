

    <div class="containerCentered containerExtend">
        <ul class="footer-main secondaryLink">
            
                
                    <li>
<a href="#">Help</a>
</li>
                
                    <li>
<a href="#">Contact</a>
</li>
                
                    <li>
<a href="#">Fees</a>
</li>
                
                    <li>
<a href="#">Security</a>
</li>
                
                    <li>
<a href="#">Apps</a>
</li>
                
                    <li>
<a href="#">Shop</a>
</li>
                
            

            
    <li class="country-selector">
        
<a href="#" title="See all countries" class="country unitedstates">See all countries</a>

    </li>


            <li class="footer-search">
                <form method="post" action="#" class="search-form">
                    <button class="search-icon" title="Search" type="submit">Search</button>
                    <input type="search" name="q" placeholder="Search" />
                    <input type="hidden" name="cn" value="paypal" />
                    <input type="hidden" name="cc" value="www" />
                    <input type="hidden" name="adv" value="0" />
                    <input type="hidden" name="mode" value="caseB" />
                </form>
            </li>
        </ul>

        
            <ul class="footer-secondary secondaryLink">
                
                    
                        <li>
<a href="#" target="_blank">About</a>
</li>
                    
                        <li>
<a href="#" target="_blank">Blog</a>
</li>
                    
                        <li>
<a href="#" target="_blank">Jobs</a>
</li>
                    
                        <li>
<a href="#">Sitemap</a>
</li>
                    
                        <li>
<a href="#" target="_blank">eBay</a>
</li>
                    
                        <li>
<a href="#">Developers</a>
</li>
                    
                        <li>
<a href="#">Enterprise</a>
</li>
                    
                        <li>
<a href="#" target="_blank">Partners</a>
</li>
                    
                
                <li id="siteFeedback">
                    


</li>
            </ul>
        

        <ul class="footer-tertiary secondaryLink">
            <li id="footer-copyright"> 1999 - 2020 PayPal</li>
            
                
                    <li id="footer-privacy">
<a href="#">Privacy</a>
</li>
                    <li id="footer-legal">
<a href="#">Legal</a>
</li>
                
                
            
        </ul>
        
    </div>
	