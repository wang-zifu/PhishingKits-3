<div class="section" id="custModule" style="height:10px">
                            <div class="sectionHeader">
                                <a name="cust_body">
                                    <h2>Enabled By</h2>
                                </a>
                            </div>
                            <div class="custContent">
                                <div><img src="./img/logo2.gif"><img src="./img/sc.png"><img src="./img/enabled_by_symc_vip.png"></div>
                                <div class="custCountryNames"></div>
                            </div>
                            <ul class="horizontalList bottomLinks">
                               
                            </ul>
                        </div>