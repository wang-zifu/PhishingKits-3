<div class="section" id="toolsModule">
                            <div class="sectionHeader">
                                <a name="tools_body">
                                    <h2>Tools</h2> 
                                </a>
                            </div>
                            <div class="sectionContent">
                                <ul class="toolsTile">
                                    <li class="invoicing"><a href="#">Billing</a>
                                    </li>
                                    <li class="requestMoney"><a href="#">Request for payment</a>
                                    </li>
                                    <li class="sendMoney"><a href="#">Sending money</a>
                                    </li>
                                    <li class="businessSetup"><a href="#">Configuration of my activity</a>
                                    </li>
                                    <li class="welcome"><a href="#">Presentation</a>
                                    </li>
                                    <li class="resolutionCenter"><a href="#">Resolution Center</a>
                                    </li>
                                </ul>
                            </div>
                        </div>