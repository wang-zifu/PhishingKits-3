<?php
// Theme Name
$name = 'Venus';

// Theme Author
$author = 'phpSound';

// Theme URL
$url = 'https://phpsound.com';

// Theme Version
$version = '1.3.0';
?>