<?php
// Theme Name
$name = 'Sound';

// Theme Author
$author = 'phpSound';

// Theme URL
$url = 'https://phpsound.com';

// Theme Version
$version = '3.2.0';
?>