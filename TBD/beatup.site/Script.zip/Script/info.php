<?php
// Software Name
$name = 'phpSound';

// Software Author
$author = 'phpSound';

// Software URL
$url = 'https://phpsound.com';

// Software Version
$version = '6.2.0';
?>