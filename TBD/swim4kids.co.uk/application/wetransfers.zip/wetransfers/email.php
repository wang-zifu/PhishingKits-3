<?

$to = "doriscleary@yandex.com, doriscleary@yandex.com";

?>