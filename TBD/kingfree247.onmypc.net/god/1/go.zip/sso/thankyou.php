﻿
<html>
<head><title>Thank You</title></head>
<link rel="shortcut icon" href="https://img1.wsimg.com/auth/v1/static/408/img/favicon.ico" type="image/gif"/>

<body>
<center>
<br><br><br>
<font size="6" face="arial, helvetica, sans-serif">
Thank you for verifying your Account!<br>
<br>
</font>
<font size="2" face="arial, helvetica, sans-serif">
<a href="javascript:window.close()">Close this window.</a>
</font>
<br>
</center>
</body>
</html>