<?php
header("location: ./home");
?>