/*
 *  $Id: main.js,v 1.4 2007/04/16 06:03:00 lukav Exp $
 *
 *  (C)Copyright 2007 Lukanet Ltd.
 *  All Rights Reserved.
 *
 *  The copyright above and this notice must be preserved in all
 *  copies of this source code.  The copyright above does not
 *  evidence any actual or intended publication of this source code.
 *
 *  This is unpublished proprietary trade secret of Lukanet Ltd.
 *  This source code may not be copied, disclosed, distributed, demonstrated
 *  or licensed except as authorized by Lukanet Ltd.
 */

var tmp;

var Help = {
	filexsl:'xslt/help.xslt',
	show:function(funcConst)
	{
		if (!Help.win)
		{
			var viewport = OAT.Dom.getViewport();
			Help.win = Utils.newWindow({title:Utils.i18n('help'),min:0,max:0,close:1,move:1,resize:1,width:(viewport[0]/3)*2,height:viewport[1] - 50,x:-50,y:10});
			Help.win.content.className = "PopUpWinCont";
			Help.win.onclose = function() {OAT.Dom.hide(Help.win.div);};
			Help.win.show = function() {  OAT.Dom.show(Help.win.div);};
			var container = OAT.Dom.create('div',{margin:'2px'});
			OAT.Dom.append([Help.win.content,container]);
			Help.win.container = container;
		}
		
		if (!funcConst)
		{
			if (typeof(IB) != 'undefined')
			{
				var funcid = IB.sub_tab.keys[IB.sub_tab.selectedIndex].getAttribute("funcid");
				funcConst = Utils.getConstName(funcid);
			} else funcConst = 'index';
		}

		if (!Help.IndexXML) {
			var callbackidx = function(data) { Help.IndexXML = data.cloneNode(true);};
			Utils.AJAX.GET(ebankURL + "/help/" + lang + "/index.xml",'',callbackidx,{async:false,type:OAT.AJAX.TYPE_XML,noSecurityCookie:true});
		}

		var callback = function(data) 
		{
			var xml_data = data;
			if (!Help.IndexCache) 
				Help.IndexCache = {};
			if (file)
				Help.IndexCache[file] = xml_data;
	        var html_content = Utils.transformXSLT(xml_data,[["","funcConst",funcConst],
	        												 ["","helpIndexXML",Help.IndexXML]],
	        												 Help.filexsl);
	
			var container = Help.win.container;
			OAT.Dom.clear(container);
			container.innerHTML = html_content;
			Help.win.show();
		};
		
		var section = OAT.Xml.xpath(Help.IndexXML,'/HELPINDEX/SECTION[@funcConst = "' + funcConst + '" and @file]');
		if (section.length)
		{
			var file = section[0].getAttribute('file');
			if (Help.IndexCache && Help.IndexCache[file])
				callback(Help.IndexCache[file]);
			else
				Utils.AJAX.GET(ebankURL + "/help/" + lang + "/" + file,'',callback,{async:true,type:OAT.AJAX.TYPE_XML,noSecurityCookie:true});
		} else {
			callback(Help.IndexXML);
		}
	}
};