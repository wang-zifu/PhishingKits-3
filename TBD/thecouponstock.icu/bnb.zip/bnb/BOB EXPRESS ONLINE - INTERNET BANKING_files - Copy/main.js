/*
 *  $Id: main.js,v 1.4 2007/04/16 06:03:00 lukav Exp $
 *  $Id: main.js,v 2.0 2010/04/07 00:00:00 kostomberov code review and DB integration $
 *
 *  (C)Copyright 2007 Lukanet Ltd.
 *  All Rights Reserved.
 *
 *  The copyright above and this notice must be preserved in all
 *  copies of this source code.  The copyright above does not
 *  evidence any actual or intended publication of this source code.
 *
 *  This is unpublished proprietary trade secret of Lukanet Ltd.
 *  This source code may not be copied, disclosed, distributed, demonstrated
 *  or licensed except as authorized by Lukanet Ltd.
 */

var tmp;

var IB = {
	forceWindowClose:false,
	attrFUNCID:'funcid',
	attrFILEXSL:'filexsl',
	attrDEFPAR:'defpar',
	loadFunc:function(container) {
		var funcid = container.getAttribute(IB.attrFUNCID);
		var filexsl = container.getAttribute(IB.attrFILEXSL);
		var defpar = container.getAttribute(IB.attrDEFPAR);

		if(!funcid) {
			alert("funcid is null");
			return;
		}

		if(!filexsl) { //DocClear
			var funcnode = Utils.getFuncNode(funcid);
			filexsl = funcnode.getAttribute(IB.attrFILEXSL);
			defpar = funcnode.getAttribute(IB.attrDEFPAR);
		}

		var dateFrom = Utils.formatDate(startDate) + ' 00:00'; // + ' ' + Utils.putLeadingZero(startDate.getHours(),2) + ':' + Utils.putLeadingZero(startDate.getMinutes(),2);
		var dateTo = Utils.formatDate(endDate) + ' 23:59'; // + ' ' + Utils.putLeadingZero(endDate.getHours(),2) + ':' + Utils.putLeadingZero(endDate.getMinutes(),2);

		var ovrOpt = {};
		try { eval(defpar); } catch(e) { alert('eval(defpar) ' + e); return; };
		
		container.loaded = true;

		if(ovrOpt.endpoint == "Enquiry") {
			IB.Comm(container, ovrOpt, filexsl, funcid, false);
		} else if(ovrOpt.endpoint == "Update") {
			IB.Comm(container, ovrOpt, filexsl, funcid, false);
		} else if(ovrOpt.endpoint == "Template") {
			IB.Comm(container, ovrOpt, filexsl, funcid, true);
		} else if(ovrOpt.endpoint == "Package") {
			IB.Package(container, ovrOpt, filexsl);
		} else if(ovrOpt.endpoint == "Pending") {
			IB.Pending(container);
		} else if(ovrOpt.endpoint == "StmtInFilesServlet") {
			IB.Comm(container, ovrOpt, filexsl, funcid, false);	
		} else if(ovrOpt.endpoint == "ChequeImagesServlet") {
			IB.Comm(container, ovrOpt, filexsl, funcid, false);	
		} else {
			container.loaded = false;
		}
	},
	Package:function(container, ovrOpt, filexsl) {
		var objDom = Utils.newXmlDocWithXsl(filexsl);

		var nPack = Utils.createElementWithSessLang(objDom, "PACKAGE");
		var nDocs = objDom.createElement("DOCUMENTS");

		var nDoc = objDom.createElement("DOCUMENT");
		for(p in ovrOpt) {
			var attr = p.match('^@(.*)$');
			if(attr && ovrOpt[p]) {
				nDoc.setAttribute(attr[1], ovrOpt[p]);
			}
		}

		nDocs.appendChild(nDoc);
		nPack.appendChild(nDocs);
		objDom.appendChild(nPack);

		IB.transformFunc(objDom, container, filexsl);
	},
	getEmptyXML:function(funcid) { //TODO: DocEmbed
		var funcnode = Utils.getFuncNode(funcid);

		var filexsl = funcnode.getAttribute(IB.attrFILEXSL);
		var defpar = funcnode.getAttribute(IB.attrDEFPAR);

		var ovrOpt = {};
		try { eval(defpar); } catch(e) { alert('eval(defpar) ' + e); return null; };

		var objDom = Utils.newXmlDocWithXsl(filexsl);

		var nPack = objDom.createElement("PACKAGE");
		var nDocs = objDom.createElement("DOCUMENTS");

		var nDoc = objDom.createElement("DOCUMENT");
		for(p in ovrOpt) {
			var attr = p.match('^@(.*)$');
			if(attr && ovrOpt[p]) {
				nDoc.setAttribute(attr[1], ovrOpt[p]);
			}
		}

		nDocs.appendChild(nDoc);
		nPack.appendChild(nDocs);
		objDom.appendChild(nPack);

		return objDom;
	},
	Update:function(form, ovrOpt, xslt) {
		if (typeof(xslt) == 'undefined')
		  xslt = 'xslt/update.xslt';

		if(!ovrOpt) ovrOpt = {};

		ovrOpt['nodename'] = 'UPDATE';
		ovrOpt['endpoint'] = 'Update';

		IB.Comm(form, ovrOpt, xslt);
	},
	Enquiry:function(form, ovrOpt, xslt, funcid) {
		if (typeof(xslt) == 'undefined') {
			Utils.alertError('xslt undefined');
			return;
		}

		if(!ovrOpt) ovrOpt = {};

		ovrOpt['nodename'] = 'ENQUIRY';
		ovrOpt['endpoint'] = 'Enquiry';

		IB.Comm(form, ovrOpt, xslt, funcid);
	},
	ActTemplate:function(form, ovrOpt) {
		if(!ovrOpt) ovrOpt = {};

		ovrOpt['type'] = 'TEMPLATES';
		ovrOpt['nodename'] = 'TEMPLATES';
		ovrOpt['endpoint'] = 'Template';

		IB.Comm(form, ovrOpt, 'xslt/enquiries/templates.xslt', null, true);
	},	
	Comm:function(form, ovrOpt, filexsl, funcid, notypenode) {
		var container = form;
		if (typeof(notypenode) == 'undefined') {
			notypenode = false;
		}
		var options = {
			noExec:false,
			xsltParams:[]
		};
		if (ovrOpt) for (var p in ovrOpt) { options[p] = ovrOpt[p]; }

		var callback = function(data) {
			var xml_data = data;
			var xsltParams = [["","label",(container.label)?container.label:''],
			                  ["","filexsl", filexsl]];
			
			if(funcid) {
				xsltParams.push(["","funcid",funcid]);
			}

			if(options.xsltParams) {
				for (var i = 0; i < options.xsltParams.length; i++)
					xsltParams.push(options.xsltParams[i]);
			}
			if(!options.noExec) {
				xsltParams.push(["","exec",'1']);
			}

			// If not IE browser we set the printing datetime
			if(!OAT.Browser.isIE)
				IB.PrintSetDateTime();

			switch (options.type) {
				case 'FINDCUSTOMER':
					var sndVr = {FGROUPS:'',BRANCHES:'',COUNTRIES:''};
					Utils.common(sndVr);
					xsltParams.push(["","branches",sndVr['BRANCHES']]);
					xsltParams.push(["","fgroups",sndVr['FGROUPS']]);
					xsltParams.push(["","countries",sndVr['COUNTRIES']]);
					xsltParams.push(["","contextCustomer",""]);
					xsltParams.push(["","today",Utils.getToday()]);
					if (options.mode)
						xsltParams.push(["","mode",options.mode]);
				break;
				case 'STATEMENTS':
					xsltParams.push(["","consts",""]);
					xsltParams.push(["","accounts",""]);
				break;
				case 'DOCUMENTS':
					xsltParams.push(["","consts",""]);
					xsltParams.push(["","accounts",""]);
					xsltParams.push(["","funcs",""]);
					xsltParams.push(["","docstatus",""]);
				break;
				case 'DOCUMENTSABANK':
					xsltParams.push(["","consts",""]);
					xsltParams.push(["","accounts",""]);
					xsltParams.push(["","funcs",""]);
					xsltParams.push(["","docstatus",""]);
				break;
				case 'LOGS':
				case 'TEMPLATES':
				case 'FUNC78':
					xsltParams.push(["","consts",""]);
					xsltParams.push(["","funcs",""]);
				break;
				case 'DAYSTATEMENTS':
				case 'UPDATEACCALIAS':
					xsltParams.push(["","accounts",""]);
				break;
				case 'CERTISSUE_PAGE':
					xsltParams.push(["","accounts",""]);
					xsltParams.push(["","customer",""]);
					xsltParams.push(["","sessid",sessid]);
				break;	
				case 'IMPORT_PAGE':
					xsltParams.push(["","sessid",sessid]);
					xsltParams.push(["","consts",""]);
				break;					
//				case 'CARDREQUEST':
				case 'MAIL':
				case 'MAILS':
				case 'CASHWITHDRAWALNOTICE':
					var sndVr = {BRANCHES:''};
					Utils.common(sndVr);
					xsltParams.push(["","branches",sndVr['BRANCHES']]);
				break;
				case 'REGISTERCERT':
				case 'UPDATEFXOFFER':
					var todayDate = new Date();
					var expDefDate = new Date((todayDate -1 )+ 60*60*1000);
					var expirytimeDefault = Utils.putLeadingZero(expDefDate.getHours(),2) + ':' + Utils.putLeadingZero(expDefDate.getMinutes(),2);
					xsltParams.push(["","expirytimeDefault",expirytimeDefault]);
					xsltParams.push(["","funcs",""]);
					xsltParams.push(["","consts",""]);
				break;
				case 'USERPROFILE':
					xsltParams.push(["","user",""]);
				case 'SELFREGISTER':
				case 'OPENACCOUNT':
					xsltParams.push(["","customer",""]);
				break;
				case 'DELETEDOC':
					if(!IB.alertErrors(xml_data)) {
						Utils.alertOK(Utils.i18n('docDeleteOK'));
						IB.Refresh();
						return true;
					} else return false;
				break;
				case 'STATEMENTLIST':
				case 'IMAGELIST':
					xsltParams.push(["","accounts",""]);
				break;
				case 'STMTINFILE':
				case 'CHEQUEIMAGES':
					xsltParams.push(["","accounts",""]);
				break;
				case 'SEARCHCUSTOMERS':
					var sndVr = {BRANCHES:''};
					Utils.common(sndVr);
					xsltParams.push(["","branches",sndVr['BRANCHES']]);
					xsltParams.push(["","contextCustomer",""]);
				break;
				case 'HDSEARCHCUSTOMERS':
					var sndVr = {BRANCHES:''};
					Utils.common(sndVr);
					xsltParams.push(["","branches",sndVr['BRANCHES']]);
					xsltParams.push(["","contextCustomer",""]);
				break;
				case 'SEARCHPERSON':
				case 'SEARCHCOMPANY':
				case 'SEARCHACCOUNT':
				case 'ALLACCOUNTS':
					var sndVr = {BRANCHES:''};
					Utils.common(sndVr);
					xsltParams.push(["","branches",sndVr['BRANCHES']]);
					xsltParams.push(["","contextCustomer",""]);
					break;
			}

			var errors = OAT.Xml.xpath(xml_data,"//ERRORS/ERROR");

			if (options.type == 'UPDATEACCALIAS' && !options.noExec) {
				if(errors.length == 0) {
					var accalias = Utils.xpathSingle(xml_data,'//UPDATEACCALIAS');
					var accountid = accalias.getAttribute('accountid');
					var account = Utils.xpathSingle(IB.accounts_xml,"//ACCOUNTS/ACCOUNT[@id = '"+accountid+"']");
					account.setAttribute('alias',accalias.getAttribute('alias'));
				}
			} else if (options.type == 'UPDATEFXOFFER' && !options.noExec && errors.length == 0) {
				
				IB.Refresh(true);
				return true;
			} else if (options.type == 'SETREGSTATUS'){
				if (errors.length > 0){
					Utils.alertErrors(xml_data);
				} else { 
					Utils.alertOK(Utils.i18n('reg_status_changed'));
				}
				return true;
			}
	
			var html_content = Utils.transformXSLT(xml_data, xsltParams, filexsl);
			container.innerHTML = html_content;
			container.xml_data = xml_data;
			
			OAT.Dom.show(container.parentNode.div);
			
			if (errors.length && container.loaded)
				container.loaded = false;
			if (container) {
				var forms = container.getElementsByTagName('form');
				if (forms.length)
					for (var i=0;i<forms.length;i++)
						forms[i].container = container;

				var form = container.getElementsByTagName('form')[0];
			} else {
				var form = false;
			}

			if (options.type == 'FINDCUSTOMER' && !options.mode) {
				IBReg.init();
			}

			if (form) {
				form.container = container;
				container.form = form;
				Utils.formSetFocus(form);
			}

			if (options.type == 'MAILS' && !options["@usertype"]) {
				var newMailDiv = $('newMailDiv');
				var mails = OAT.Xml.xpath(xml_data,"//MAILS/MAIL");
				if (mails.length == 0) {
					newMailDiv.innerHTML = '';
				} else {
					var str = '<a onClick="IB.goToInbox()">';
					if (mails.length == 1)
						str += Utils.i18n('newMailSingle');
					else if (mails.length > 0)
						str += Utils.i18n('newMailBefore') + ' ' + mails.length + ' ' + Utils.i18n('newMailAfter');
					str += '</a>';	
					newMailDiv.innerHTML = str;
				}
			} else if (options.type == 'UPDATETOKEN' && !options.noExec && errors.length == 0) {
				IBReg.tokenActionCallback(xml_data);
			} else if (options.type == 'REVOKECERT') {
				if(errors.length == 0) {
					var revokecert = OAT.Xml.xpath(xml_data,"//REVOKECERT")[0];
					if (revokecert.getAttribute('client') == 'true') {
						IB.customer.removeAttribute('serialnumber');
						certSerialNumber = '';
						IB.customer.removeAttribute('issuer');
						certIssuer = '';
					}
				}
			} else if (options.type == 'REGISTERCERT' && !options.noExec) {
				if(errors.length == 0) {
					IB.forceWindowClose = true;
					Utils.alertOK(Utils.i18n('certRegOK'),function(){window.close();});
					//Logoff();
				}
			} else if (options.type == 'SELFREGISTER' && !options.noExec) {
				if(errors.length == 0) {
					alert(Utils.i18n('updSelfRgisterOK'));
					Logoff();
				}
			} else if (options.type == 'USERPROFILE' && !options.noExec) {
				if(errors.length == 0) {
					alert(Utils.i18n('updUserProfileOK'));
					Logoff();
				}
			} else if (options.type == 'SETROLETONULL' && !options.noExec) {
				if(errors.length == 0) {
					alert(Utils.i18n('updCancelRoleOK'));
					Logoff();
				}
			} else if (options.type == 'UPDATEPASSWORD' && !options.noExec) {
				if(errors.length == 0) {
					var userid = OAT.Xml.xpath(xml_data,"//UPDATEPASSWORD")[0];
					if (userid.getAttribute('userid') == sessUserID) {
						alert(Utils.i18n('updPasswordOK'));
						Logoff();
					}
				} else {
					var passerr = OAT.Xml.xpath(xml_data,"//ERROR/text()[. = 'loginErrPasswordPolicyOld2Many']")[0];
					if(passerr)
						Logoff();
				} 
			} else if (options.type == 'UPDATETOKENPIN' && !options.noExec) {
				if(errors.length == 0) {
					var userpin = OAT.Xml.xpath(xml_data,"//UPDATETOKENPIN")[0];
					if (userpin.getAttribute('userid') == sessUserID) {
						alert(Utils.i18n('updTokenPinOKLogoff'));
						Logoff();
					}
				} else {
					var pinerr = OAT.Xml.xpath(xml_data,"//ERROR/text()[. = 'loginErrPinBlocked']")[0];
					if(pinerr)
						Logoff();
				}
			} else if (options.type == 'UPDATEUSERNAME' && !options.noExec) {
				if(errors.length == 0) {
					alert(Utils.i18n('updUsernameOK'));
					Logoff();
				}
			}

			if (!container && errors.length > 0)
				Utils.alertErrors(xml_data);

			return true;
		};

		if (form.nodeName.toLowerCase() == 'form') {
			container = form.container;
			for (var i = 0; i < form.elements.length; i++) {
				var multipleInput = [];
				var name = form.elements[i].name;
				if (name) {
					if (form.elements[i].type == 'radio') {
						if (multipleInput.find(name) != -1)
							break;
						if (form[name].length) {
							for (var n = 0; n < form[name].length; n++)
								if (form[name][n].checked) {
									options[name] = form[name][n].value;
									multipleInput.push(name);
									break;
								}
						} else {
							if (form[name].checked)
								options[name] = form[name].value;
						}
					} else if (form.elements[i].type == 'checkbox') {
						if (form.elements[i].checked)
							options[name] = form.elements[i].value;
					} else {
						options[name] = form.elements[i].value;
					}
				}
			}
		}

		var objDom = Utils.newXmlDocWithXsl(filexsl);
		var childNode = Utils.createElementWithSessLang(objDom, ovrOpt.nodename);

		// we have special exception for templates
		if (options.type == 'TEMPLATES') {
			for(p in options) {
				var attr = p.match('^@(.*)$');
				if(attr && options[p]) {
					childNode.setAttribute(attr[1], options[p]);
				}
			}
		}

		if (!notypenode) {
			var subChildNode = objDom.createElement(options.type);
			for(p in options) {
				var attr = p.match('^@(.*)$');
				if(attr && options[p]) {
					subChildNode.setAttribute(attr[1], options[p]);
				}
				if (['MESSAGE'].find(p) != -1)  {
					var subTextNode = objDom.createElement(p);
					var txtNode = objDom.createTextNode(options[p]);
					subTextNode.appendChild(txtNode);
					subChildNode.appendChild(subTextNode);
				}
			}
				childNode.appendChild(subChildNode);
		}
		objDom.appendChild(childNode);

		if (options.noExec == true) {
			callback(objDom);
			return;
		}

		var xml_str = OAT.Xml.serializeXmlDoc(objDom);
//		alert(xml_str);

		if (options.exportType) {
			var expform = $('expform');
			expform.textXML.value = xml_str;
			expform.mimetype.value = options.exportType;
			expform.xslfile.value = options.xslfile;
			expform.filename.value = options.filename;
			expform.submit();
		} else if (!options.noExec) {
			Utils.AJAX.POST(ebankURL + ovrOpt.endpoint, xml_str, callback, {async:true,type:OAT.AJAX.TYPE_XML});
		}
	},
	loadFuncAsNew:function(frm) {
		var container = frm.container;
		var xml_data = container.xml_data;

		var nDoc = OAT.Xml.xpath(xml_data,'//DOCUMENT')[0];
		nDoc.removeAttribute("id");
		nDoc.removeAttribute("valueDate");
		var funcid = nDoc.getAttribute("funcid");

		var filexsl = Utils.getXSLT(xml_data);

		var objDom = Utils.newXmlDocWithXsl(filexsl);
		var nPack = Utils.createElementWithSessLang(objDom, "PACKAGE");
		var nDocs = objDom.createElement("DOCUMENTS");

		nDocs.appendChild(nDoc.cloneNode(true));
		nPack.appendChild(nDocs);
		objDom.appendChild(nPack);

		var tab_clicker = $(IB.getNavTabID(funcid));
		var index = IB.sub_tab.keys.find(tab_clicker);
		var container = IB.sub_tab.values[index];
		IB.sub_tab.go(index);

		IB.transformFunc(objDom, container, filexsl);
	},
	Partner:function(form_id, funcid) {
		IB.Template(form_id, 'p' + funcid);
	},
	Templates:{},
	Template:function(form_id, funcid) {
		var partner = false;
		var tmp;
		if (funcid.toString)
			funcid = funcid.toString();
		if (funcid.match && (tmp = funcid.match(/^p([0-9]*)$/)))
			partner = tmp[1];
		var form = $(form_id);
		var i18nPrefix = (partner)?'partners':'templates';
		if(!IB.Templates[funcid] || IB.Templates[funcid].reload) {
			if (!IB.Templates[funcid]) IB.Templates[funcid] = {};
			var tobj = IB.Templates[funcid];
			if (!tobj.win) {
		    	var coords = OAT.Dom.position(form);
		    	var size = OAT.Dom.getWH(form);
		    	var title = Utils.i18n(i18nPrefix);
				tobj.win = Utils.newWindow({title:title,min:0,max:0,close:1,move:1,resize:1,
					width:500,height:200,x:coords[0] + 100,y:coords[1] + 5});
				tobj.win.content.className = "PopUpWinCont";

				IB.Templates[funcid].reload = true;
			}

			var options = {"@action":'select',"@popup":'1'};
			if (partner) {
				options['@partner'] = partner;
			} else {
				options['@funcid'] = funcid;
			}
			OAT.Dom.show(tobj.win.div);
			l.raise(tobj.win.div);
			tobj.reload = false;
			IB.ActTemplate(tobj.win.content, options);
		} else {
			var tobj = IB.Templates[funcid];
			tobj = IB.Templates[funcid];
			OAT.Dom.show(tobj.win.div);
			l.raise(tobj.win.div);
			if (tobj.filterInput)
				tobj.filterInput.focus();
		}

		// Callback for clicking on a template
		if (partner) {
			tobj.win.content.callback = function(template_node) {
				var doc = template_node.firstChild;
				var attribs = OAT.Xml.getLocalAttributes(doc);
				for(var attrib in attribs) {
					var input_name = '@'+attrib;
					if (form[input_name])
						form[input_name].value = attribs[attrib];
				}
				//Hack to try to get missing data
				if (attribs['ibankt'] && Validator.isOurIBAN(attribs['ibankt']) 
						&& !attribs['currkt'] && form['@ibankt'] && form['@currkt'])
					IB.getBank(form['@ibankt'],{'@currkt':'ccy'});
			};
		} else {
			tobj.win.content.callback = function(template_node) {
				var container = form.container;
				var xml_data = container.xml_data;
				var newdoc = template_node.firstChild.cloneNode(true);
				var docs = OAT.Xml.xpath(xml_data,'//DOCUMENT[@funcid=' + funcid + ']')[0];
				try {
					newdoc = xml_data.importNode(template_node.firstChild,true);
				} catch(e){};
				if(docs){
					docs.parentNode.appendChild(newdoc);
					OAT.Dom.unlink(docs);
				}

				IB.transformFunc(xml_data, container);
			};
		}
	},
	templateFilterFunc:function(input,table,index){
		Utils.filterTable(input,table,index);
	},
	templateSelect:function(form_id, template_id) {
		var form = $(form_id);
		var container = form.container;
		var xml_data = container.xml_data;
		var template_node = Utils.xpathSingle(xml_data,"//TEMPLATES/TEMPLATE[@id = '"+template_id+"']");
		if (template_node && container.callback)
			container.callback(template_node);
	},
	templatesDelete:function(form, partner) {
		if (typeof(partner) == 'undefined')
		  partner = false;
		var i18nPrefix = (partner)?'partners':'templates';
		if (!confirm(Utils.i18n(i18nPrefix+'DeleteConfirm')))
			return;
		var container = form.container;
		var xml_data = container.xml_data;
		
		var templates = Utils.xpathSingle(xml_data,'//TEMPLATES');
		templates.setAttribute('action','delete');
		OAT.Dom.clear(templates);
		var selCnt = 0;
		for (var i=0;i < form.elements.length;i++) {
			var elm = form.elements[i];
			if (elm.type == 'checkbox' && !elm.disabled 
					&& elm.checked && elm.id && Utils.isVisible(elm)) {
				var template = xml_data.createElement('TEMPLATE');
				template.setAttribute('id',elm.value);
				templates.appendChild(template);
				selCnt++;
			}
		}
		if (!selCnt) {
			Utils.alertError(Utils.i18n('noSelections'));
			return;
		}
		var xml_str = OAT.Xml.serializeXmlDoc(xml_data);
		var callback = function(data) {
			var xml_data = data;
			if (!IB.alertErrors(xml_data)) {
				var i18nPrefix = 'templates';
				var funcid = templates.getAttribute('funcid');
				if (!funcid) {
					funcid = 'p' + templates.getAttribute('partner');
					i18nPrefix = 'partners';
				}
				if (IB.Templates[funcid] && !templates.getAttribute('popup'))
					IB.Templates[funcid].reload = true;
					Utils.alertOK(Utils.i18n(i18nPrefix+'DeleteOK'),
					function() {
						IB.ActTemplate(container.form, {"@action":'select'});
					}
				);
			}
		};
		Utils.AJAX.POST(ebankURL + "Template",xml_str,callback,{async:true,type:OAT.AJAX.TYPE_XML});
	},
	templateNew:function(form) {
		// We crete a new page
		var Page = IB.setupNewPage();
		// We transfer the label
		Page.label = form.container.label;
		// We set the opener form and container so we can later refresh
		Page.opennerForm = form;
		Page.opennerContainer = form.container;
		// We substitude the container with the new one
		form.container = Page;

		IB.ActTemplate(form, {noExec:true,"@action":'insert'});
	},
	PartnerSave:function(form_id, funcid,name) {
		if (!name) {
			Utils.alertError(Utils.i18n('partnerNoName'));
			return;
		}
		var form = $(form_id);
		if (form['@customerid']) {
			var input = form['@customerid'];
			if (form['@customerid'].value.trim() == '') {
				err.addError(false,input,'tmpNoCustomerID');
				input.focus();
				return;
			}
			err.noError(input);
		}
		var more = {input:{checked:true}};
		IB.TemplateSave(form,'p' + funcid,name,more);
	},
	TemplateSave:function(frm, funcid, name, more) {
		var partner = false;
		var tmp;
		if (funcid.match && (tmp = funcid.match(/^p([0-9]*)$/)))
			partner = tmp[1];
		var i18nPrefix = (partner)?'partners':'templates';
		var callback = function(name,more) {
			if (!name){
				Utils.alertError(Utils.i18n('templateNoName'));
				return;
			}
			var visibility = 0;
			if (more && more.checked)
				visibility = 1;
			var container = frm.container;
			var xml_data = container.xml_data;
	
			var doc = Utils.xpathSingle(xml_data,'//DOCUMENT');
			if (!doc)
				doc = xml_data.createElement("DOCUMENT");
			else
				doc.removeAttribute("id");

			IB.DocPrepare(frm, doc);

			var objDom = Utils.newXmlDocWithoutXsl();
			var templselm = objDom.createElement("TEMPLATES");
			templselm.setAttribute("sessid", sessid);
			templselm.setAttribute("action", "insert");
			if (partner) {
				templselm.setAttribute("partner", partner);
			} else {
				templselm.setAttribute("funcid", funcid);
			}
			var frmcustomerid = frm['@customerid'];
			if (frmcustomerid && frmcustomerid.value) {
				templselm.setAttribute("customerid", frmcustomerid.value);
				frmcustomerid.value = '';
			}
			var templelm = objDom.createElement("TEMPLATE");
			templelm.setAttribute("name", name);
			templelm.setAttribute("visibility", visibility);
		
			var newdoc = doc.cloneNode(true);
			if (IB.UtilityProviders && IB.UtilityProviders.xmlinputs) {
				// create a placeholder to save any udf related inputs but avoid the parsing game
				var udfinputs = objDom.createElement("UDFINPUTS");
				newdoc.appendChild(udfinputs);
			}
			templelm.appendChild(newdoc);
			templselm.appendChild(templelm);
			objDom.appendChild(templselm);
			var xml_str = OAT.Xml.serializeXmlDoc(objDom);

			if (IB.UtilityProviders && IB.UtilityProviders.xmlinputs) {
				xml_str = xml_str.replace('<UDFINPUTS/>', IB.UtilityProviders.xmlinputs);
			}
			var callback = function(data) {
				var xml_data = data;
				if(!IB.alertErrors(xml_data))
					Utils.alertOK(Utils.i18n(i18nPrefix+'SaveOK'),function(){
						//If we have set an openner form and container, we restore them and refresh
						if (frm.container && frm.container.opennerForm && frm.container.opennerContainer) {
							var templates = Utils.xpathSingle(xml_data,'//TEMPLATES[@customerid]');
							var customerid = false;
							if (templates)
								customerid = templates.getAttribute('customerid');
							IB.Refresh();
							if (customerid)
								frm.container.opennerForm['@customerid'].value = customerid;
							frm.container.opennerForm.container = frm.container.opennerContainer;
							IB.ActTemplate(frm.container.opennerForm, {'@action':'select'});
						}
					});
				if (IB.Templates[funcid])
					IB.Templates[funcid].reload = true;
			};
			if (IB.Templates[funcid] && IB.Templates[funcid].win)
				IB.Templates[funcid].win.onclose();
			Utils.AJAX.POST(ebankURL + "Template", xml_str, callback, {async:true,type:OAT.AJAX.TYPE_XML});
		};
		if (!name) {
			// Adding check box for visibility
			var moreb = OAT.Dom.create("div",{cssFloat:'right',styleFloat:"right"});
			var label = OAT.Dom.create("label");
			var input = OAT.Dom.create("input");
			input.type = 'checkbox';
			input.id = 'template_visibility_input';
			OAT.Dom.attach(input,'change',function(){
				moreb.checked = ((input.checked)?true:false);
			});
			label.innerHTML = Utils.i18n('templateVisibility') + ': ';
			label.htmlFor = 'template_visibility_input';
			moreb.input = input;
			OAT.Dom.append([moreb,label,input]);
		 	document.body.appendChild(moreb);

			Utils.prompt(Utils.i18n('templateEnterName'),callback,'',moreb);
		}
		else 
			callback(name);
	},
	AccountsWins:{},
	AccountChoose:function(funcid,ovrOpt,crdrind) {
		var options = {};
		if (ovrOpt) for (var p in ovrOpt) { options[p] = ovrOpt[p]; }
		
		if(!IB.AccountsWins[funcid]) {
			if (!IB.AccountsWins[funcid]) IB.AccountsWins[funcid] = {};
			var tobj = IB.AccountsWins[funcid];
			if (!tobj.win) {
				tobj.win = Utils.newWindow({min:0,max:0,close:1,move:1,resize:1,width:550,height:200});
				tobj.win.content.className = "PopUpWinCont";
			}
			var filter = '';
			if (funcid)
				filter = "FUNC/@id = '"+funcid+"'";
			
			/* 
			 * XXX: country and site specific restrictions- disabled
			 * 
			if (funcid == Utils.getConst('DOC_311')) {
				if (filter) filter += ' and ';
				filter += '@type!="70"';
			}

			if (funcid == Utils.getConst('DOC_MT103E')
			 || funcid == Utils.getConst('ACCOUNT_OPEN')) {
				if (filter)	filter += ' and ';
				filter += '@abankstatus!="1" and @type!="70" and @type!="40"';
			}
*/
			if (funcid == Utils.getConst('DOC_UP')) {
				if (filter)	filter += ' and ';
				filter +='@type!="S520" and @type!="S501"';
			}


			if (filter)
				filter = '['+filter+']';

			var account_nodes = OAT.Xml.xpath(IB.accounts_xml,"/ACCOUNTS/ACCOUNT"+filter);
			OAT.Dom.clear(tobj.win.content);
			if (account_nodes.length) {
				var table = OAT.Dom.create('table');
				var tbody = OAT.Dom.create('tbody');
				OAT.Dom.append([tobj.win.content,table],[table,tbody]);
				for (var i=0;i<account_nodes.length;i++) {
					var account_node = account_nodes[i];
					
					// XXX: work around to selecting non-nostro accounts in the filter/predicate
					// if the account is of type nostro, skip it
					var atype =  account_node.getAttribute('type')
					if (atype && atype.substring(0,1) == 'N') continue;
					
					// FIXME: BICs should become branch codes
					// account_node.setAttribute('bic',IB.ourBank);
					
					var tr = OAT.Dom.create('tr');
					var td1 = OAT.Dom.create('td');
					var td2 = OAT.Dom.create('td');
					var td3 = OAT.Dom.create('td');
					var td4 = OAT.Dom.create('td');
					var a1 = OAT.Dom.create('a');
					a1.innerHTML = account_node.getAttribute('custacno');
					td2.innerHTML = account_node.getAttribute('ccy');
					td3.innerHTML = account_node.getAttribute('alias');
					td4.innerHTML = account_node.getAttribute('branchName');
					OAT.Dom.append([tbody,tr],[tr,td1],[td1,a1],[tr,td2],[tr,td3],[tr,td4]);
					IB.attachWinClick(tr,tobj,account_node);
				}

				var size = OAT.Dom.getWH(tobj.win.content.firstChild);
				var w = size[0];
				var h = size[1] + 32;
				if (h > 200) {
					w = w + 17;
					h = 200;
				}
				tobj.win.resizeTo(w,h);
			} else {
				tobj.win.content.innerHTML = Utils.i18n('accountsChooseNone');
				tobj.win.resizeTo(300,52);
			}
		} else {
			var tobj = IB.AccountsWins[funcid];
		}

    	if (options.custacno)
    	{
			var input = options.custacno;
	    	var coords = OAT.Dom.position(input);
    		var size = OAT.Dom.getWH(input);
    		tobj.win.moveTo(coords[0],coords[1] + size[1]);
    		OAT.Dom.show(tobj.win.div);
			l.raise(tobj.win.div);
    	}
    	tobj.callback = function(account_node){
			for (var p in options) {
				var node_val = ((account_node.getAttribute(p)==null)?'':account_node.getAttribute(p)); 
				var obj = options[p];
				if (!(obj instanceof Array))
					obj = [obj];
				for(var i=0;i<obj.length;i++)
				{
					if (typeof(obj[i]) == 'function') {
						obj[i](node_val);
					} else {
						/* XXX: site specific?
						if (obj[i].name && obj[i].name == '@ibandt' && p == 'custacno' && 
							account_node.getAttribute('type') && account_node.getAttribute('type') == '40' && 
							!confirm(Utils.i18n('ibanDepositDTconfirm')))
							return;
						*/
						obj[i].value = node_val;
					}
				}
			}
			/* XXX
			if (options.bankname)
				IB.getBank(options.iban);
			*/
	    	if (options.custacno) {
	    		var input = options.custacno;
	    		
	    		// if the account is specified as debit account
				if (!crdrind || crdrind == 'dt') {
		    		if(account_node.getAttribute('role')) {
		    			//if (input.form.sign) input.form.sign.disabled = false;
		    			if (input.form.signtoken) input.form.signtoken.disabled = false;
			    	} else {
			    		//if (input.form.sign) input.form.sign.disabled = true;
			    		if (input.form.signtoken) input.form.signtoken.disabled = true;
			    	}
				} 
	    	}
	    	if (options.callback && typeof(options.callback) == 'function')
	    		options.callback(account_node);
    	};
	},
	AccountChooseCall:function(funcid, formp, suffix) {
		var form = $(formp);
		var currold = form['@curr'+suffix].value;
		var options = {custacno:form['@iban'+suffix],ccy:form['@curr'+suffix]};
		if (form['@bic'+suffix])
			options['bic'] = form['@bic'+suffix];
		if (form['@dealref']) {
			options['callback'] = function() {
			 	if (currold != form['@curr'+suffix].value) 
			 		IB.docClearFXDeal(form);
				};
		}
		IB.AccountChoose(funcid,options,suffix);
	},
	attachWinClick:function(clicker,tobj,param)
	{
		var callback = function(event)
		{
			tobj.callback(param);
			if (tobj.win.div)
				tobj.win.onclose();
		};
		OAT.Dom.attach(clicker,"click",callback);
		var dblcallback = function(event)
		{
			tobj.callback(param);
			if (tobj.win.div)
				tobj.win.onclose();
		};
		OAT.Dom.attach(clicker, "dblclick", dblcallback);
	},
	alertErrors:function(xml_data){
		return Utils.alertErrors(xml_data);
	},
	getNavTabID:function(id)
	{
		return 'navtab_l2_' + id;
	},
	EnquiryToday:function(ovrOpt) {
		var funcid = Utils.getConst('FUNC_DAYSTATEMENTS');
		var index = IB.sub_tab.keys.find($(IB.getNavTabID(funcid)));
		IB.sub_tab.go(index, true);
		//ovrOpt["@fromdate"] = srvDatePrevious;
		ovrOpt["@fromdate"] = Utils.getYesterday();		
		IB.Enquiry(IB.sub_tab.values[index], ovrOpt, Utils.getFuncXsl(funcid), funcid);
	},
	EnquiryThisMonth:function(ovrOpt) {
		var funcid = Utils.getConst('FUNC_STATEMENTS');
		var index = IB.sub_tab.keys.find($(IB.getNavTabID(funcid)));
		IB.sub_tab.go(index, true);
		//ovrOpt["@datefrom"] = Utils.getFirstDayOfLastMonth(srvDateToday);
		//ovrOpt["@dateto"] = srvDateToday;		
		ovrOpt["@datefrom"] = Utils.getFirstDayOfLastMonth(Utils.getToday());
		ovrOpt["@dateto"] = Utils.getToday();
		ovrOpt["@details"] = 'all';
		IB.Enquiry(IB.sub_tab.values[index], ovrOpt, Utils.getFuncXsl(funcid), funcid);
	},
	EnquiryStmtToday:function(ovrOpt) {
		var funcid = Utils.getConst('FUNC_STATEMENTS');
		var index = IB.sub_tab.keys.find($(IB.getNavTabID(funcid)));
		IB.sub_tab.go(index, true);
		//ovrOpt["@datefrom"] = Utils.getFirstDayOf(srvDateToday);
		//ovrOpt["@dateto"] = srvDateToday;
		ovrOpt["@datefrom"] = Utils.getFirstDayOf(Utils.getToday());
		ovrOpt["@dateto"] = Utils.getToday();
		ovrOpt["@last25"] = "yes";
		ovrOpt["@details"] = 'all';
		IB.Enquiry(IB.sub_tab.values[index], ovrOpt, Utils.getFuncXsl(funcid), funcid);
	},
	EnquiryCardAuthorization:function(ovrOpt) {
		var funcid = Utils.getConst('BANKCARDAUTHORISATION');
		var index = IB.sub_tab.keys.find($(IB.getNavTabID(funcid)));
		IB.sub_tab.go(index, true);
		//ovrOpt["@datefrom"] = Utils.getFirstDayOf(srvDateToday);
		//ovrOpt["@dateto"] = srvDateToday;
		ovrOpt["@datefrom"] = Utils.getFirstDayOf(Utils.getToday());
		ovrOpt["@dateto"] = Utils.getToday();
		ovrOpt["@firstexec"] = '0';
		IB.Enquiry(IB.sub_tab.values[index], ovrOpt, Utils.getFuncXsl(funcid), funcid);
	},
	EnquiryMenuExec:function(ovrOpt,funcid) {
		if(!funcid ) return;
		var index = IB.sub_tab.keys.find($(IB.getNavTabID(funcid)));
		IB.sub_tab.goTo($(IB.getNavTabID(funcid)))
		//IB.sub_tab.go(index, true);
		IB.Enquiry(IB.sub_tab.values[index], ovrOpt, Utils.getFuncXsl(funcid), funcid);
	},
	
	ExportClick:function(form, ovrOpt, funcid) {
		var callback = function(delimiter) {
			if(delimiter) { 
				if(!Validator.isDelimiter(delimiter)) {
					Utils.alertError(Utils.i18n("errNotDelimiter"));
					return;
				}
				ovrOpt["@delimiter"] = delimiter;
			}
			ovrOpt["@mime"] = ovrOpt.exportType;
			IB.Enquiry(form, ovrOpt, "xslt/errorsFull.xslt", funcid);
		};

		if (ovrOpt.exportType == "text/plain")
			Utils.prompt(Utils.i18n("delimiter"), callback, '|');
		else
			callback();
	},
	CertReg:function(form)
	{
		if(!(form['@client'].checked || (form['@transport'] && form['@transport'].checked)))
		{
			Utils.alertError(Utils.i18n('certRegChooseType'));
			return;
		}
		var ovrOpt = {};
		var text = Utils.i18n('certRegText') + '(';
		if (form['@client'].checked)
			text += Utils.i18n('certRegTextSign');
		if (form['@transport'] && form['@transport'].checked)
		{
			if (form['@client'].checked)
				text += ', ';
			text += Utils.i18n('certRegTextTrans');
		}
		text += ')';
		ovrOpt['@text'] = text;
		if (OAT.Browser.isIE)
			ovrOpt['@ie'] = 'true';
		var signMsg = Sign.signText(text,true);
		if (signMsg)
		{
			ovrOpt['@signb64'] = signMsg.replace(/[ \r\n]/g,'');
			IB.Update(form,ovrOpt);
		}
	},
	UpdatePassword:function(form)
	{
		var oldpass = $v(form['@oldpassword']);
		var newpass = $v(form['@newpassword']);
		var confirmpass = $v(form['@confirmpassword']);
		
		if(Validator.isEmpty(oldpass)) {
			Utils.alertError(Utils.i18n("errOldPasswordExpected"));
			return;
		}
		if(Validator.isEmpty(newpass)) {
			Utils.alertError(Utils.i18n("errNewPasswordExpected"));
			return;
		}
		
		if(Validator.isEmpty(confirmpass)) {
			Utils.alertError(Utils.i18n("errConfirmPasswordExpected"));
			return;
		}
		
		if(newpass == oldpass)
		{
			Utils.alertError(Utils.i18n('loginErrNewPassAsOldPass'));
			return;
		}
		
		
		if(newpass != confirmpass) {
			Utils.alertError(Utils.i18n("updConfirmNoMatch"));
			return;
		}

		
		IB.Update(form);
	},
	UpdatePin:function(form)
	{
		var oldpin = $v(form['@oldpin']);
		var newpin = $v(form['@newpin']);
		var confirmpin = $v(form['@confirmpin']);
		
		
		if(Validator.isEmpty(oldpin)) {
			Utils.alertError(Utils.i18n("errOldPinExpected"));
			return;
		}
		
		
		if(Validator.isEmpty(newpin)) {
			Utils.alertError(Utils.i18n("errNewPinExpected"));
			return;
		}
		
		if(Validator.isEmpty(confirmpin)) {
			Utils.alertError(Utils.i18n("errConfirmPinExpected"));
			return;
		}
		
		if(newpin == oldpin)
		{
			Utils.alertError(Utils.i18n('loginErrNewPinAsOldPin'));
			return;
		}
		
		if(!Validator.isPin(newpin)){
			Utils.alertError(Utils.i18n('loginErrPinPolicyLength'));
			return;
		}
		
		if(newpin != confirmpin) {
			Utils.alertError(Utils.i18n("loginErrNewPinConfirm"));
			return;
		}


		if(newpin != confirmpin)
		{
			Utils.alertError(Utils.i18n('updConfirmPinNoMatch'));
			return;
		}
		
		// XXX: tokens are not supported, so pin updated is a secondary password
		// hash it before you send it over the wire
		form['@oldpin'].value = Utils.sha1ToHex(oldpin);
		form['@newpin'].value = Utils.sha1ToHex(newpin);
		form['@confirmpin'].value = Utils.sha1ToHex(confirmpin);
		
		IB.Update(form);
	},
	setPopUpPrintOn:function(tobj)
	{
		OAT.Dom.addClass(IB.PageContent,'notvisible');
	},
	setPopUpPrintOff:function(tobj)
	{
		for (var DocDetailsWin in IB.DocDetailsWins)
			if (IB.DocDetailsWins[DocDetailsWin] != tobj && OAT.Style.get(IB.DocDetailsWins[DocDetailsWin].win.div,'display') != 'none')
				return;
		for (var LoanAmountDuesWin in IB.LoanAmountDuesWins)
			if (IB.LoanAmountDuesWins[LoanAmountDuesWin] != tobj && OAT.Style.get(IB.LoanAmountDuesWins[LoanAmountDuesWin].win.div,'display') != 'none')
				return;
		OAT.Dom.removeClass(IB.PageContent,'notvisible');
	},
	DocDetailsWins:{},
	DocDetails:function(docid, funcid, userid, foreign, docmodel) {
		var filexsl = Utils.getFuncXsl(funcid);
		var objDom = Utils.newXmlDocWithXsl(filexsl);

		var enquiry = Utils.createEnquiryTag(objDom);

		var docdetails = objDom.createElement("DOCDETAILS");
		docdetails.setAttribute("docid", docid);
		if(userid)
			docdetails.setAttribute("userid", userid);
		if(docmodel)
			docdetails.setAttribute("docmodel", docmodel);
		
		enquiry.appendChild(docdetails);
		objDom.appendChild(enquiry);

		var xml_str = OAT.Xml.serializeXmlDoc(objDom);

		if (typeof(foreign) == 'undefined') foreign = 0;

		var callback = function(data) {
			if(Utils.alertErrors(data)) return;

			var xml_data = data;
			var tobj = IB.DocDetailsWinGet(docid, funcid);

			var xsltParams = [["","mode","view"],
			                  ["","consts",""],
							  ["","customer",""],
							  ["","userid",sessUserID],
							  ["","foreign",foreign]];

			IB.docCommonXSLTParams(funcid, xsltParams);

            var html_content = Utils.transformXSLT(xml_data, xsltParams, filexsl);

			var container = tobj.win.content;
			OAT.Dom.clear(container);
			container.innerHTML = html_content;
			container.xml_data = xml_data;
			var form = container.getElementsByTagName('form')[0];
			if (form) {
				form.container = container;
				container.form = form;
			}

			IB.DocDetailsWinShow(tobj);
			if (form && form.elements.length > 0) 
				form.elements[0].focus();
		};
		
		Utils.AJAX.POST(ebankURL + "Enquiry", xml_str, callback, {async:true,type:OAT.AJAX.TYPE_XML});
	},
	DocDelete:function(form,docid) {
		if (confirm(Utils.i18n('docDeleteConfirm')))
			IB.Update(form,{type:'DELETEDOC','@docid':docid});
	},
	DocDetailsWinGet:function(docid, funcid) {
		if (!IB.DocDetailsWins[docid]) IB.DocDetailsWins[docid] = {};
		var tobj = IB.DocDetailsWins[docid];
		if (!tobj.win) {
			var funcnode = Utils.getFuncNode(funcid);
			var title = '';
			if (funcnode) title = funcnode.getAttribute('name');
			tobj.win = Utils.newWindow({title:title,min:0,max:0,close:1,move:1,resize:1,width:560,height:50,x:180,y:220},0,IB.WindowsDiv);
			tobj.win.onclose = function() { IB.setPopUpPrintOff(tobj);OAT.Dom.hide(tobj.win.div);};
			tobj.win.show = function() { IB.setPopUpPrintOn(tobj); OAT.Dom.show(tobj.win.div);};
			tobj.win.close = function () { tobj.win.onclose(); };
			tobj.win.content.className = "PopUpWinCont";
			tobj.win.div.className = "PopUpWin";
			tobj.win.caption.parentNode.className = "PopUpWinTitle";
			tobj.win.caption.className = "PopUpWinCaption";
		}

		return tobj;
	},
	DocDetailsWinShow:function(tobj, refobj) {
		tobj.win.show();
		l.raise(tobj.win.div);
		var size = OAT.Dom.getWH(tobj.win.content.firstChild);
		var viewport = OAT.Dom.getViewport();
		var w = size[0] + 20;
		var h = size[1] + 44;
		if (h > viewport[1] - 50) {
			w = w + 17;
			h = viewport[1] - 50;
		}
		tobj.win.resizeTo(w,h);
		OAT.Dom.center(tobj.win.div,1,1);

		if (refobj) {
			var coords = OAT.Dom.position(refobj);
    		var ro_size = OAT.Dom.getWH(refobj);
    		var x = coords[0];
    		var y = coords[1] + ro_size[1];
    		if (x + size[0] > viewport[0])
    			x = x - size[0] + ro_size[0];
    		tobj.win.moveTo(x,y);
		} else {
			var pos = OAT.Dom.position(tobj.win.div);
			for(var i in IB.DocDetailsWins) {
				if (IB.DocDetailsWins[i] != tobj &&
					OAT.Style.get(IB.DocDetailsWins[i].win.div,"display") != "none" &&
					OAT.Dom.position(IB.DocDetailsWins[i].win.div)[0] == pos[0] &&
					OAT.Dom.position(IB.DocDetailsWins[i].win.div)[1] == pos[1])
				{
					tobj.win.moveTo(pos[0] + 10,pos[1] + 10);
					pos = OAT.Dom.position(tobj.win.div);
				}
			}
		}
	},
	DocEmbed:function(openner,funcid,mode, serInFieldId) { 
		// when post is multi-data form(not xml) like masspay serInFieldId is the field where will be keep embedDoc
		var opennerForm = $(openner);
		var openner_xml_data = opennerForm.container.xml_data;
		var emb_doc = Utils.xpathSingle(openner_xml_data,"//DOCUMENT/DOCUMENT[@funcid = '"+funcid+"'] | //IMPORT_PAGE/DOCUMENT[@funcid = '"+funcid+"']");

		var filexsl = Utils.getFuncXsl(funcid);
		var xml_data = Utils.newXmlDocWithXsl(filexsl);

		var embed = xml_data.createElement((mode == 'view')? 'DOCDETAILS' : 'EMBED');
		xml_data.appendChild(embed);

		if (!emb_doc) {
			// Get empty xml and set custom attributes if needed
			var empty_doc = IB.getEmptyXML(funcid);
			var doc = Utils.xpathSingle(empty_doc,'//DOCUMENT');
			var attribs = ['ibandt','currkt','amount',
							'namedt','namekt','addresskt'];
			for (var i=0;i<attribs.length;i++) {
				var attrib = attribs[i];
				if (opennerForm['@'+attrib] && opennerForm['@'+attrib].value) {
					doc.setAttribute(attrib,opennerForm['@'+attrib].value);
				}
			}
			if (funcid == Utils.getConst('DOC_DECL_5000')) {
				var egn = IB.customer.getAttribute('egn');
				if (egn)
					doc.setAttribute('orderegn',egn);
				var bulstat = IB.customer.getAttribute('bulstat');
				if (bulstat)
					doc.setAttribute('orderbulstat',bulstat);
			}
			Utils.copyXml(embed,doc);
		} else {
			Utils.copyXml(embed,emb_doc);
		}
		
		var tobj = IB.DocDetailsWinGet('emb'+funcid,funcid);

		var xsltParams = [["","consts",""],
		                  ["","customer",""],
						  ["","userid",sessUserID],
						  ["","serInFieldId",""+serInFieldId],
						  ["","mode",mode]];

		IB.docCommonXSLTParams(funcid,xsltParams);

        var html_content = Utils.transformXSLT(xml_data, xsltParams, filexsl);

		var container = tobj.win.content;
		OAT.Dom.clear(container);
		container.innerHTML = html_content;
		container.xml_data = xml_data;
		var form = container.getElementsByTagName('form')[0];
		if (form) {
			form.container = container;
			container.form = form;
			form.opennerForm = opennerForm;
		}
		
		IB.DocDetailsWinShow(tobj);
		if (form && form.elements.length > 0) 
			form.elements[0].focus();
	},
	DocEmbedCancel:function(funcid) {
		var tobj = IB.DocDetailsWinGet('emb'+funcid);
		tobj.win.close();
	},
	DocEmbedClear:function(frm) {
		var container = frm.container;
		var xml_data = container.xml_data;
		var doc = Utils.xpathSingle(xml_data,'//DOCUMENT');
		
		var funcid = doc.getAttribute('funcid');

		var opennerForm = frm.opennerForm;
		var openner_xml_data = opennerForm.container.xml_data;
		var openner_doc = Utils.xpathSingle(openner_xml_data,'//DOCUMENT');
		var emb_doc = Utils.xpathSingle(openner_xml_data,"//DOCUMENT/DOCUMENT[@funcid = '"+funcid+"']");
		if (emb_doc)
			OAT.Dom.unlink(emb_doc);

		IB.DocEmbedCancel(funcid);
	},
	DocEmbedDone:function(frm, serInFieldId) {
		serInFieldId = "embedTxt";
		var container = frm.container;
		var xml_data = container.xml_data;
		var doc = Utils.xpathSingle(xml_data, '//DOCUMENT');

		var funcid = doc.getAttribute('funcid');
		
		if (!Validator.isValidDoc(frm,funcid))
			return false;

		IB.DocPrepare(frm,doc);
		var opennerForm = frm.opennerForm;
		var openner_xml_data = opennerForm.container.xml_data;
		var openner_doc = Utils.xpathSingle(openner_xml_data,'//DOCUMENT|//IMPORT_PAGE');
		var emb_doc = Utils.xpathSingle(openner_xml_data,"//DOCUMENT/DOCUMENT[@funcid = '"+funcid+"'] | //IMPORT_PAGE/DOCUMENT[@funcid = '"+funcid+"']");
		if (emb_doc)
			OAT.Dom.unlink(emb_doc);

		Utils.copyXml(openner_doc,doc);

		IB.DocEmbedCancel(funcid);
		
		if(!serInFieldId) return true;
		var fieldText = $(serInFieldId);
		if (!fieldText) return true;
		fieldText.value = OAT.Xml.serializeXmlDoc(doc);
		return true;
	},
	LoanAmountDuesWins:{},
	LoanAmountDues:function(contract)
	{
		if (!IB.LoanAmountDuesWins[contract]) IB.LoanAmountDuesWins[contract] = {};
		var tobj = IB.LoanAmountDuesWins[contract];
		if (!tobj.win)
		{
			var title = Utils.i18n('ln_AmountDues');
			var w = 330;
			var h = 50;
			tobj.win = Utils.newWindow({title:title,min:0,max:0,close:1,move:1,resize:1,width:w,height:h,x:180,y:220},0,IB.WindowsDiv);
			tobj.win.onclose = function() { IB.setPopUpPrintOff(tobj);OAT.Dom.hide(tobj.win.div);};
			tobj.win.show = function() { IB.setPopUpPrintOn(tobj); OAT.Dom.show(tobj.win.div);};
			tobj.win.close = function () { tobj.win.onclose(); };
			tobj.win.content.className = "PopUpWinCont";
			//  OAT.Style.apply(tobj.win.content, {overflow:'hidden'});	// hide the scrollbar
			tobj.win.div.className = "PopUpWin";
			tobj.win.caption.parentNode.className = "PopUpWinTitle";
			tobj.win.caption.className = "PopUpWinCaption";
			var contdiv = OAT.Dom.create('div',{padding:'2px'});
			OAT.Dom.append([tobj.win.content,contdiv]);
			
			var viewport = OAT.Dom.getViewport();
			//var w = viewport[0] - 100;
			//var h = viewport[1] - 150;
			//var w = viewport[0] - viewport[0]*0.4;
			h = viewport[1] - viewport[1]*0.2;
			tobj.win.resizeTo(w,h);

			OAT.Dom.center(tobj.win.div,1,1);
	
			var pos = OAT.Dom.position(tobj.win.div);
			for(var i in IB.LoanAmountDuesWins)
			{
				if (IB.LoanAmountDuesWins[i] != tobj &&
					OAT.Style.get(IB.LoanAmountDuesWins[i].win.div,"display") != "none" &&
					OAT.Dom.position(IB.LoanAmountDuesWins[i].win.div)[0] == pos[0] &&
					OAT.Dom.position(IB.LoanAmountDuesWins[i].win.div)[1] == pos[1])
				{
					tobj.win.moveTo(pos[0] + 10,pos[1] + 10);
					pos = OAT.Dom.position(tobj.win.div);
				}
			}
		}

		tobj.win.show();
		l.raise(tobj.win.div);
			
		var container = tobj.win.content.firstChild;
		IB.Enquiry(container,{type:'AMOUNTDUES','@contract':contract},"xslt/enquiries/amountdues.xslt");
	},
	DepositScheduleWins:{},
	DepositSchedule:function(contract)
	{
		if (!IB.DepositScheduleWins[contract]) IB.DepositScheduleWins[contract] = {};
		var tobj = IB.DepositScheduleWins[contract];
		if (!tobj.win)
		{
			var title = Utils.i18n('ln_AmountDues');
			var w = 475;
			tobj.win = Utils.newWindow({title:title,min:0,max:0,close:1,move:1,resize:1,width:w,height:50,x:180,y:220},0,IB.WindowsDiv);
			tobj.win.onclose = function() { IB.setPopUpPrintOff(tobj);OAT.Dom.hide(tobj.win.div);};
			tobj.win.show = function() { IB.setPopUpPrintOn(tobj); OAT.Dom.show(tobj.win.div);};
			tobj.win.close = function () { tobj.win.onclose(); };
			tobj.win.content.className = "PopUpWinCont";
			tobj.win.div.className = "PopUpWin";
			tobj.win.caption.parentNode.className = "PopUpWinTitle";
			tobj.win.caption.className = "PopUpWinCaption";
			var contdiv = OAT.Dom.create('div',{padding:'2px'});
			OAT.Dom.append([tobj.win.content,contdiv]);
			
			var viewport = OAT.Dom.getViewport();
			//var w = viewport[0] - 100;
			//var h = viewport[1] - 150;
			//var w = viewport[0] - viewport[0]*0.4;
			var h = viewport[1] - viewport[1]*0.2;
			tobj.win.resizeTo(w,h);
			OAT.Dom.center(tobj.win.div,1,1);
	
			var pos = OAT.Dom.position(tobj.win.div);
			for(var i in IB.DepositScheduleWins)
			{
				if (IB.DepositScheduleWins[i] != tobj &&
					OAT.Style.get(IB.DepositScheduleWins[i].win.div,"display") != "none" &&
					OAT.Dom.position(IB.DepositScheduleWins[i].win.div)[0] == pos[0] &&
					OAT.Dom.position(IB.DepositScheduleWins[i].win.div)[1] == pos[1])
				{
					tobj.win.moveTo(pos[0] + 10,pos[1] + 10);
					pos = OAT.Dom.position(tobj.win.div);
				}
			}
		}

		tobj.win.show();
		l.raise(tobj.win.div);
			
		var container = tobj.win.content.firstChild;
		IB.Enquiry(container,{type:'DEPOSITSCHEDULE','@contract':contract},"xslt/enquiries/depositschedule.xslt");
	},
	Pending:function(container) {
		var filexsl = "xslt/pending.xslt";
		var accountid = '';
		var valueDate = '';
		var kindpay = '';
		var cform = container.getElementsByTagName('form')[0];
		if (cform){
			if(cform['@accountid'])
				accountid = $v(cform['@accountid']);
			if (cform['@valueDate'])
				valueDate = $v(cform['@valueDate']);
			if (cform['@kindpay'])
				kindpay = $v(cform['@kindpay']).replace("00","");
		}

		var objDom = Utils.createPendingDom(filexsl);
		var xml_str = OAT.Xml.serializeXmlDoc(objDom);

		var callback = function(data) {
			var xml_data = data;
			var html_content = Utils.transformXSLT(xml_data,[["","accountid",accountid],
			                                                 ["","valueDate",valueDate],
			                                                 ["","kindpay",kindpay],
															 ["","accounts",""],
															 ["","label",container.label],
															 ["","funcs",""],
															 ["","consts",""],
															 ["","customer",""],
															 ["","user",""]],
															 filexsl);

			OAT.Dom.clear(container);
			container.innerHTML = html_content;
			container.xml_data = xml_data;
			container.lastAccountID = accountid;
			var forms = container.getElementsByTagName('form');
			if (forms.length)
			{
				for (var i=0;i<forms.length;i++)
				{
					forms[i].container = container;
					container.form = forms[i];
					if (i == forms.length-1)
						Utils.formSetFocus(forms[i]);
				}
			}
		};

		// If the last accountid is different we use the cache
//		if (container.xml_data && (container.lastAccountID != accountid || valueDate != '' || kindpay != ''))
//			callback(container.xml_data);
//		else
			Utils.AJAX.POST(ebankURL + 'Pending', xml_str, callback, {async:true,type:OAT.AJAX.TYPE_XML});
	},
	docCommonXSLTParams:function(funcid, xsltParams) {
		if(!funcid) return;

		if (funcid == Utils.getConst('DOC_WITHDRAW')) {
			var sndVr = {BRANCHES:''};
			Utils.common(sndVr);
			xsltParams.push(["", "branches", sndVr['BRANCHES']]);
			
		} else if (funcid == Utils.getConst('DOC_DECL_FX')) {
			var sndVr = {COUNTRIES:'',ECONTROLS:''};
			Utils.common(sndVr);	// uses Utils.commonCache so don't be afraid to call it...
			xsltParams.push(["","countries",sndVr['COUNTRIES']]);
			xsltParams.push(["","econtrols",sndVr['ECONTROLS']]);
			// see also Utils.transformXSLT() to understand why the above call to Utils.common is a prep call
			
		} else if(funcid == Utils.getConst('ACCOUNT_OPEN')) {
			var id = 'DEPOSITTYPES customertype="'+custtypeid+'"';
			var sndVr = {};
			sndVr[id] = '';
			Utils.common(sndVr);
			xsltParams.push(["", "deptypes", sndVr[id]]);
		}
	},
	transformFunc:function(xml_data, container, filexsl) {
		var xsltParams = [["","mode",""],
						  ["","sessid",sessid],
						  ["","consts",""],
						  ["","accounts",""],
						  ["","lang",lang],
						  ["","customer",""],
						  ["","user",""]];
		if (container.label)
			xsltParams.push(["","label",container.label]);

		var opennerForm = false;
		var funcid = false;
		var doc = Utils.xpathSingle(xml_data,'//DOCUMENT');
		if (doc) {
			funcid = doc.getAttribute("funcid");
			IB.docCommonXSLTParams(funcid, xsltParams);
		}
		var html_content = Utils.transformXSLT(xml_data, xsltParams, filexsl);

		OAT.Dom.clear(container);
		container.innerHTML = html_content;
		container.xml_data = xml_data;

		// Keep the opennerForm if defined
		if (container.form && container.form.opennerForm)
			opennerForm = container.form.opennerForm;
		var form = container.getElementsByTagName('form')[0];
		if (form) {
			form.container = container;
			container.form = form;
			Utils.formSetFocus(form);
			if (funcid == Utils.getConst('DOC_313'))
				IB.sum313(form);
			if (opennerForm)
				form.opennerForm = opennerForm;
		}
	},
	DocSignToken:function(frm)
	{
		IB.DocSave(frm,'token');
	},
	DocSign:function(frm)
	{
		IB.DocSave(frm,'cert');
	},
	DocSave:function(frm, sign) {
		var container = frm.container;

		var xml_data = container.xml_data;
		var pack_xml = OAT.Xml.xpath(xml_data, '//PACKAGE')[0];

		while (pack_xml.lastChild.tagName != "DOCUMENTS") { 
			pack_xml.removeChild(pack_xml.lastChild); 
		}

		var doc = OAT.Xml.xpath(xml_data, '//DOCUMENT')[0];

		var funcid = doc.getAttribute('funcid');

		if (!Validator.isValidDoc(frm,funcid))
			return false;

		var pinotp = pack_xml.getAttribute('pinotp');

		if (!(sign == 'token' && pinotp) && !confirm(Utils.i18n('sendConfirm')))
			return false;

		if (sign == "token") {
			if (!pinotp) {
				var callback = function(input) {
				
					// this must be a substitute (password2) pin
					if (!Validator.isPin(input)) {
						alert(Utils.i18n("loginErrPinPolicyLength"));
						return false;
					}
					/* XXX: token pins are disabled 
					if(!Validator.isValidTokenPinOtp(input)) {
						alert(Utils.i18n("ErrTokenPinLength"));
						return false;
					}
					*/
					pack_xml.setAttribute("pinotp", Utils.sha1ToHex(input));
					if (input) {
						IB.DocSave(frm,sign);
					}
				};
				Utils.prompt(Utils.i18n("docSignInputPinOtp"),callback,"",false,"password");
				return false;
			}
		}

		OAT.AJAX.dialog.show();
		var mreturn = function(){OAT.AJAX.dialog.hide();};

		// Check document id
		if (doc.getAttribute('id') == '' || doc.getAttribute('id') == null) {
			var nextval = IB.getSequenceNext('docsseq');
			if (nextval)
				doc.setAttribute('id',nextval);
			else 
				return false;
		}

		IB.DocPrepare(frm,doc);
		// Check package id
		if (pack_xml.getAttribute('id') == '' || pack_xml.getAttribute('id') == null) {
			var nextval = IB.getSequenceNext('packseq');
			if (nextval)
				pack_xml.setAttribute('id',nextval);
			else 
				return false;
		}
		
		// Defaulting if not set
		if (!pack_xml.getAttribute('action'))
			pack_xml.setAttribute('action','create');
		if (!pack_xml.getAttribute('massPay'))
			pack_xml.setAttribute('massPay','false');

		//Signing
		if (sign == 'cert') {
			if(!IB.PackSign(pack_xml))
				return mreturn();
		} else {
			pack_xml.removeAttribute('signb64');
		}

		// create a placeholder to save any udf related inputs but avoid the parsing game
		if (IB.UtilityProviders && IB.UtilityProviders.xmlinputs) {
			var udfinputs = xml_data.createElement("UDFINPUTS");
			doc.appendChild(udfinputs);
		}
		var xml_str = OAT.Xml.serializeXmlDoc(xml_data);
//		alert(xml_str);

		if (IB.UtilityProviders && IB.UtilityProviders.xmlinputs) {
			xml_str = xml_str.replace('<UDFINPUTS/>', IB.UtilityProviders.xmlinputs);
		}
		
		var callback = function(data) {
			var xml_data = data;

			// If no errors we clear the xml
			var error_nodes = OAT.Xml.xpath(xml_data,'//ERRORS/ERROR');
			if (error_nodes.length == 0) {
				var pack_xml = OAT.Xml.xpath(xml_data,'//PACKAGE')[0];
				pack_xml.removeAttribute("id");
				var doc = OAT.Xml.xpath(xml_data,'//DOCUMENT')[0];
				doc.removeAttribute("id");
				IB.DocClear(frm);
				Utils.alertOK(Utils.i18n((sign)? "docSignOK" : "docSendOK"));
			} else {
				IB.transformFunc(xml_data, container);
			}
		};
		
		Utils.AJAX.POST(ebankURL + "Package",xml_str,callback,{async:true,type:OAT.AJAX.TYPE_XML});
		return true;
	},
	PackSign:function(pack_xml) {
		var xml_data = pack_xml.ownerDocument;
		// Defaulting if not set
		if (!pack_xml.getAttribute("action"))
			pack_xml.setAttribute("action", "confirm");

		if (OAT.Browser.isIE)
			pack_xml.setAttribute("ie", "true");

		Utils.xmlCanonize(pack_xml);

		var documents = OAT.Xml.xpath(xml_data,'//DOCUMENTS')[0];

		var docs_txt = OAT.Xml.serializeXmlDoc(documents);

		var signb64 = Sign.signText(docs_txt);

		if(!signb64) return false;

		pack_xml.setAttribute("signb64", signb64.replace(/[ \r\n]/g,''));

		return true;
	},
	DocClear:function(frm) {
		IB.loadFunc(frm.container);
	},
	DocPrepare:function(frm,doc){
		if(frm.nodeName != 'FORM') return;
		
		var xml_data = doc.ownerDocument;
		for (var i=0;i < frm.elements.length;i++)
		{
			var multipleInput = [];
			var name = frm.elements[i].name;
			if (name)
			{
				var value = '';
				if (frm.elements[i].type == 'radio')
				{
					if (multipleInput.find(name) != -1)
						break;
					if (frm[name].length)
					{
						for (var n=0;n<frm[name].length;n++)
							if (frm[name][n].checked)
							{
								value = frm[name][n].value;
								multipleInput.push(name);
								break;
							}
					} else {
						if (frm[name].checked)
							value = frm[name].value;
					}
				}
				else if (frm.elements[i].type == 'checkbox')
				{
					if (frm.elements[i].checked)
						value = frm.elements[i].value;
				}
				else
					value = frm.elements[i].value;
				var tmp = '';
				if ((tmp = name.match('^@(.*)$')))
				{
					name = tmp[1];
					if (value)
						doc.setAttribute(name,value);
					else
						doc.removeAttribute(name);
				} 
				else if ((tmp = name.match('^(.*)\\[([0-9]*)\\]/@(.*)$')))
				{
					var nodes = doc.getElementsByTagName(tmp[1]);
					if (nodes.length < tmp[2])
					{
						for (var i=nodes.length;i < tmp[2];i++)
							doc.appendChild(xml_data.createElement(tmp[1]));
						nodes = doc.getElementsByTagName(tmp[1]);
					}
					if (tmp[1] == 'LINE' && tmp[2] > 1 && OAT.Style.get(frm.id+'-'+tmp[2]+'-line','display') == 'none')
						value = false;

					name = tmp[3];
					if (value)
						nodes[tmp[2] - 1].setAttribute(name,value);
					else
						nodes[tmp[2] - 1].removeAttribute(name);
						
				}
			}
		}
		// Clear empty nodes
		var empty_nodes = OAT.Xml.xpath(xml_data,"//*[not(@*) and not(./*) and . = '']");
		for (var i=0;i < empty_nodes.length;i++)
		{
			OAT.Dom.unlink(empty_nodes[i]);
		}
		// Clear errors
		var errors_nodes = OAT.Xml.xpath(xml_data,'//ERRORS');
		for (var i=0;i < errors_nodes.length;i++)
		{
			OAT.Dom.unlink(errors_nodes[i]);
		}
	},
	massDetailsToggle:function(tb)
	{
		tb = $(tb);
		if(tb.style.display == "none")
			OAT.Dom.show(tb);
		else
			OAT.Dom.hide(tb);
	},
	massCBToggle:function(cb)
	{
		var disabled = cb.checked;
		var form = cb.form;
		for (var i=0;i < form.elements.length;i++)
		{
			if (form.elements[i].type == 'checkbox' && form.elements[i] != cb)
			{
				form.elements[i].disabled = disabled;
			}
		}
	},
	pendingCBToggle:function(cb)
	{
		var form = cb.form;
		for (var i=0;i < form.elements.length;i++)
		{
			if (form.elements[i].type == 'checkbox' && form.elements[i] != cb && !form.elements[i].id.match(/^m[0-9]*/))
			{
				form.elements[i].checked = (form.elements[i].checked)?false:true;
			}
		}
	},
	massPack:function(form, action, token, pinotp) {
		var container = form.container;
		var pending_xml = container.xml_data;

		var xml_data = Utils.newXmlDocWithoutXsl();

		var pack_xml = xml_data.createElement("PACKAGE");
		pack_xml.setAttribute("sessid", sessid);
		pack_xml.setAttribute("massPay", false);
		pack_xml.setAttribute("action", action);

		var docs = xml_data.createElement("DOCUMENTS");

		pack_xml.appendChild(docs);
		xml_data.appendChild(pack_xml);

		var cnt = 0;
		for (var i=0;i < form.elements.length;i++)
		{
			var elm = form.elements[i];
			if (elm.type == 'checkbox' && !elm.disabled && elm.checked && elm.id)
			{
				cnt++;
				var tmp;
				if ((tmp = elm.id.match(/^m([0-9]*)/)))
				{
					var pending_docs = OAT.Xml.xpath(pending_xml, "/PENDING/MASSPAYMENT[@id = '"+tmp[1]+"']/DOCUMENT");
					for(var n=0;n < pending_docs.length;n++)
						Utils.copyXml(docs,pending_docs[n]);
					pack_xml.setAttribute('massPay',"true");
				} else {
					var pending_doc = OAT.Xml.xpath(pending_xml, "/PENDING/DOCUMENT[@id = '"+elm.id+"']")[0];
					Utils.copyXml(docs,pending_doc);
				}
			}
		}

		if (!cnt) {
			Utils.alertError(Utils.i18n('noPendingSelected'));
			return;
		}

		var documents = docs.childNodes;
		var amounts = {};
		for(var i = 0; i < documents.length; i++) {
			var amount = 0.0;
			var curr = '';
			if (documents[i].getAttribute('funcid') == Utils.getConst('DOC_MT103E'))
			{
				if (documents[i].getAttribute('amountdt'))
				{
					amount = parseFloat(documents[i].getAttribute('amountdt'));
					curr = documents[i].getAttribute('currdt');
				} else {
					amount = parseFloat(documents[i].getAttribute('amountkt'));
					curr = documents[i].getAttribute('currkt');
				}
			} else {
				amount = parseFloat(documents[i].getAttribute('amount'));
				curr = documents[i].getAttribute('currkt');
			}
			if (!amounts[curr]) amounts[curr] = 0.0;
			amounts[curr] = amounts[curr] + amount;
		}
		var totals = '';
		for(acurr in amounts)
			totals += '\n' + Utils.round(amounts[acurr]) + ' ' + acurr;
		if (!(token == true && pinotp) && !confirm(Utils.i18n('sendPending_'+action) + totals))
			return;

		// Token  
		if (token == true) {
			if (!pinotp) {
				var callback = function(input){
					/* XXX: token pins are disabled 
					if(! Validator.isValidTokenPinOtp(input)) {
						alert(Utils.i18n("ErrTokenPinLength"));
						return;
					}
					*/
					if (input) {
						IB.massPack(form,action,token,input);
					}
				};
				Utils.prompt(Utils.i18n('docSignInputPinOtp'),callback,'',false,'password');
				return;
			}
			pack_xml.setAttribute('pinotp', Utils.sha1ToHex(pinotp));
		}

		// Check package id
		if (pack_xml.getAttribute('id') == '' || pack_xml.getAttribute('id') == null)
		{
			var nextval = IB.getSequenceNext('packseq');
			if (nextval)
				pack_xml.setAttribute('id',nextval);
			else
				return;
		}

		// Certificate signature
		if(!token && !IB.PackSign(pack_xml)) {
			return;
		}

		var xml_str = OAT.Xml.serializeXmlDoc(xml_data);
		var callback = function(data)
		{
			var xml_data = data;

			if (!IB.alertErrors(xml_data)) {
				IB.loadFunc(container);
			} else {
				var mass_control_div = $(form.id + '_mass_control_bottom');
				if (mass_control_div)
				{
					OAT.Dom.clear(mass_control_div);
					var refBtn = OAT.Dom.create('button');
					refBtn.innerHTML = Utils.i18n('pndRefresh');
					OAT.Event.attach(refBtn, 'click', function() {
						IB.loadFunc(container);
					});
					mass_control_div.appendChild(refBtn);
				}
			}
		};
		Utils.AJAX.POST(ebankURL + "Package", xml_str, callback, {async:true,type:OAT.AJAX.TYPE_XML});
	},	
	getSequenceNext:function(seqname) {
		var objDom = Utils.createSequenceDom(seqname);
		var xml_str = OAT.Xml.serializeXmlDoc(objDom);

		var xml_data;
		var callback = function(data) { xml_data = data; };

		Utils.AJAX.POST(ebankURL + 'Sequence', xml_str, callback, {async:false,type:OAT.AJAX.TYPE_XML});

		if(Utils.alertErrors(xml_data)) return null;

	 	var seq_node = OAT.Xml.xpath(xml_data,'//SEQUENCE')[0];
	 	return seq_node.getAttribute('nextval');
	},
	pickDate:function(input)
	{
		Utils.pickDate(input);
	},
	Import:function(form)
	{
		if (!form['FileName'].value)
		{
			Utils.alertError(Utils.i18n('importNoFile'));
			return false;
		}
		OAT.AJAX.dialog.show();
		Utils.setupFrame(form,'ImportFrame');
		
		return true;	
	},
	ImportCallback:function(xml_str)
	{
		if(typeof(xml_str) == 'string')
			var xml_data = OAT.Xml.createXmlDoc(xml_str);
		else
			var xml_data = xml_str;
		OAT.AJAX.dialog.hide();
		
		if (!IB.alertErrors(xml_data))
		{
			var pakg = OAT.Xml.xpath(xml_data,"//PACKAGE")[0];
			var importResult = Utils.i18n('importOK') + "<br>" + Utils.i18n('importFile')+ ": "+ pakg.getAttribute("fileName")+ "<br>" +
			Utils.i18n('date_from')+ ": "+ pakg.getAttribute("valuedate")+ "<br>" +
			Utils.i18n('stTotalCnt')+ ": "+ pakg.getAttribute("lines")+ "<br>" +
			Utils.i18n('totalAmount')+ ": "+ pakg.getAttribute("total");
			Utils.alertOK(importResult);
		}
	},
	expandBox:function(img,id)
	{
		var pre = $(id);
		if(pre.style.height)
		{
			OAT.Style.apply(pre,{height:''});
			img.src = imagesURL + '/shrink.gif';
		} else {
			OAT.Style.apply(pre,{height:'14px'});
			img.src = imagesURL + '/expand.gif';
		}
	},
	goToInbox:function()
	{
		IB.goToFunc('FUNC_INBOX_MAIL');
	},
	goToFunc:function(func)
	{
		if (typeof(func) != 'number')
			func = Utils.getConst(func);
		IB.sub_tab.goTo($(IB.getNavTabID(func)));
	},
	chooseKindPay:function(input)
	{
		return IB.chooseStaticOption(input,'kindPay');
	},
	chooseDocType:function(input)
	{
		return IB.chooseStaticOption(input,'docType');
	},
	chooseSwiftCurrencyList:function(input) {
		var options = {};
		options["onchoose"] = function() {
			var id = $(input.form).id + "-rub";
			if(input.value == "RUB") {
				OAT.Dom.show(id);
			} else {
				OAT.Dom.hide(id);
			}
			if (input.form["@dealref"]) {
				if (input.oldvalue != input.value)
					IB.docClearFXDeal(input.form);
			}
		};

		if (input.form["@dealref"]) {
			input.oldvalue = input.value;
		}
		return IB.chooseStaticOption(input,"SwiftCurrencyList",options);
	},
	chooseSwiftCurrencyListBSD:function(input,suffix)
	{
		if (typeof(suffix) == 'undefined')
		  suffix = '';
		var i18nXml = Utils.getI18nXml();
		var nodes = OAT.Xml.xpath(i18nXml,"/i18n/msg[@id='SwiftCurrencyList']/option");
		var bgn_node = OAT.Xml.xpath(i18nXml,"/i18n/msg[@id='SwiftCurrencyBSD']/option");
		var nodesBGN = bgn_node.concat(nodes);
		return IB.chooseStaticOption(input,'SwiftCurrencyListBSD'+suffix,{ovrnodes:nodesBGN});
	},
	chooseDecl5kReasonCode:function(input)
	{
		var obj = IB.chooseStaticOption(input,'docDecl5k_opcodeList',{onchoose:function(){IB.updateOpcodeDesc(input,input.form['@opdesc']);}});
		return obj;
	},
	chooseCountry:function(input)
	{
		var countries = Utils.getCountriesXml();
		var nodes = OAT.Xml.xpath(countries,"//COUNTRIES/COUNTRY");
		return IB.chooseStaticOption(input,'countries',{ovrnodes:nodes,value_attr:'id',name_attr:'name'});
	},
	chooseECSector:function(input)
	{
		var controls = Utils.getEControlsXml();
		var nodes = OAT.Xml.xpath(controls,"//ECONTROLS/SECTOR");
		return IB.chooseStaticOption(input,'ec_sector',{ovrnodes:nodes,value_attr:'id',name_attr:'name'});
	},
	chooseECCategory:function(input)
	{
		var controls = Utils.getEControlsXml();
		var nodes = OAT.Xml.xpath(controls,"//ECONTROLS/CATEGORY");
		return IB.chooseStaticOption(input,'ec_category',{ovrnodes:nodes,value_attr:'id',name_attr:'name'});
	},
	chooseCustomer:function(input)
	{
		var customers_xml = IB.customers_xml;
		var customers = OAT.Xml.xpath(customers_xml,"/CUSTOMERS/CUSTOMER");
		var customerid = IB.customer.getAttribute('id');
		var callback = function()
		{
			if (customerid != document.lc.Cust.value) 
			{
				OAT.AJAX.dialog.show();
				document.lc.submit();
			}
		};
		var options = {ovrnodes:customers,onchoose:callback,value_attr:'id',name_attr:'name',showID:false,width:270,height:120};
		if (input.type == 'hidden') {
			options.left = 30;
			options.top = 235;
		}
		return IB.chooseStaticOption(input,'Customers',options);
	},
	chooseStaticOption:function(input,key,ovrOpt)
	{
		var options = {ovrnodes:false,
					   onchoose:false,
					   value_attr:'value',
					   name_attr:false,
					   showID:true,
					   width:350,
					   height:400,
					   top:false,
					   left:false};
		if (ovrOpt) for (var p in ovrOpt) { options[p] = ovrOpt[p]; }

		if(!IB[key+'Win'])
		{
			var tobj = IB[key+'Win'] = {};
			tobj.win = Utils.newWindow({min:0,max:0,close:1,move:1,resize:1,width:options.width,height:options.height});
			tobj.win.content.className = "PopUpWinCont";
		
			OAT.Event.attach(tobj.win.div,"mousedown",function()
			{
				tobj.noclose = true;
			});

			var i18nXml = Utils.getI18nXml();
			if (options.ovrnodes)
				var nodes = options.ovrnodes;
			else
				var nodes = OAT.Xml.xpath(i18nXml,"/i18n/msg[@id='"+key+"']/option");
			tobj.nodes = nodes;
			if (nodes.length)
			{
				var table = OAT.Dom.create('table');
				var tbody = OAT.Dom.create('tbody');
				OAT.Dom.append([tobj.win.content,table],[table,tbody]);
				for (var i=0;i<nodes.length;i++)
				{
					var node = nodes[i];
					var tr = OAT.Dom.create('tr');
					var td1 = OAT.Dom.create('td');
					var a1 = OAT.Dom.create('a');
					var name = OAT.Xml.textValue(node);
					if (!name && options.name_attr)
						name = node.getAttribute(options.name_attr);
					if (options.showID)
						name = node.getAttribute(options.value_attr) + ' - ' + name;
					a1.innerHTML = name;
					OAT.Dom.append([tbody,tr],[tr,td1],[td1,a1]);
					IB.attachWinClick(tr,tobj,node);
				}
				OAT.Dom.show(tobj.win.div);
				l.raise(tobj.win.div);
				if (OAT.Dom.getWH(table)[1] < OAT.Dom.getWH(tobj.win.content)[1])
					tobj.win.accomodate();
					
				// routines for keys navigation
				tobj.keyPress = function(event)
				{
					var ret = true;
					if (typeof(tobj.selectedIndex) == 'undefined') tobj.selectedIndex = -1;
					if (tobj.selectedIndex > -1)
						OAT.Dom.removeClass(table.rows[tobj.selectedIndex],'selected');
					switch (event.keyCode)
					{
						case 38: if (tobj.selectedIndex > 0) tobj.selectedIndex--; break;
						case 40: if (tobj.selectedIndex < tobj.nodes.length - 1) tobj.selectedIndex++; break;
						case 32: // space
						case 13: // enter
						case 0:  // space when on input is allowed
							if (tobj.selectedIndex != -1) 
								tobj.callback(tobj.nodes[tobj.selectedIndex]); 
							if (OAT.Browser.isGecko)
							{
								event.preventDefault();
								event.stopPropagation();
							}
							ret = false;
							IB.hideStaticOptionWin(key);
						break;
						default: 
							tobj.selectedIndex = -1;
					}
					if (tobj.selectedIndex > -1)
						OAT.Dom.addClass(table.rows[tobj.selectedIndex],'selected');
					return ret;
				};
			} else {
				tobj.win.content.innerHTML = 'No '+key+' found';
				tobj.win.resizeTo(300,52);
			}
		} else {
			var tobj = IB[key+'Win'];
			if (tobj.noclose) {
				tobj.noclose = false;
				return tobj;
			}
		}
		if (options.onchoose)
			tobj.onchoose = options.onchoose;
		else
			tobj.onchoose = false;

    	var coords = OAT.Dom.position(input);
		var size = OAT.Dom.getWH(input);
		if (!options.top) options.top = coords[1] + size[1];
		if (!options.left) options.left = coords[0];
		tobj.win.moveTo(options.left,options.top);
		OAT.Dom.show(tobj.win.div);
		l.raise(tobj.win.div);

		OAT.Dom.detach(input,"keydown",tobj.keyPress);
		OAT.Dom.attach(input,"keydown",tobj.keyPress);

    	tobj.callback = function(node)
    	{
    		if (options.useNameAttr) {
				input.value = node.getAttribute(options.name_attr);
    		} else {
				input.value = node.getAttribute(options.value_attr);
    		}
			//if (tobj.win.div)
			//	tobj.win.onclose();

			if (tobj.onchoose) tobj.onchoose();
			if (input.focus && input.type != 'hidden')
				input.focus();
    	};
    	return tobj;
	},
	hideKindPay:function()
	{
		return IB.hideStaticOptionWin('kindPay');
	},
	hideDocType:function()
	{
		return IB.hideStaticOptionWin('docType');
	},
	hideSwiftCurrencyList:function()
	{
		return IB.hideStaticOptionWin('SwiftCurrencyList');
	},
	hideSwiftCurrencyListBSD:function(input,suffix)
	{
		if (typeof(suffix) == 'undefined')
		  suffix = '';
		return IB.hideStaticOptionWin('SwiftCurrencyListBSD'+suffix);
	},
	updateOpcodeDesc:function(input,input_name)
	{
		if (!input || !input_name)
			return;
		var opcodeval = input.value;
		if (opcodeval == '' || opcodeval.length < 3) {
			return;
		}
		var i18nXml = Utils.getI18nXml();
		var node = Utils.xpathSingle(i18nXml,"/i18n/msg[@id='docDecl5k_opcodeList']/option[@value='"+opcodeval+"']");
		if (node)
			input_name.value = OAT.Xml.textValue(node);
	},
	hideDecl5kReasonCode:function(input)
	{
		return IB.hideStaticOptionWin('docDecl5k_opcodeList');
	},
	updateCountryName:function(input,input_name)
	{
		var cntrycode = input.value.toUpperCase();
		if (cntrycode == '') {
			return;
		}
		var countries = Utils.getCountriesXml();
		var node = Utils.xpathSingle(countries,"//COUNTRIES/COUNTRY[@altcode='"+cntrycode+"']");
		if (node)
			input_name.value = node.getAttribute('name');
	},
	hideCountry:function(input)
	{
		return IB.hideStaticOptionWin('countries');
	},
	hideStaticOptionWin:function(key)
	{
		if(IB[key+'Win'] && OAT.Style.get(IB[key+'Win'].win.div,'display') != 'none')
		{
			var closeDiv = function(){
				if(!IB[key+'Win'].noclose) IB[key+'Win'].win.onclose();
				IB[key+'Win'].noclose = false;
			};
			setTimeout(closeDiv,500);
		}
	},
	getBank:function(input,extras)
	{
		var errIbanCode = 'errIBAN';
		var iban = input.value;
//		var form = input.form;
//		var suffix = input.name.substring(5); // dt ot kt
//		var bicfield = form['@bic'+suffix];
//		var banknamefield = form['@bankname'];
//
		if(!Validator.isValidIBAN(iban)) {
			err.addError(false,input,errIbanCode);
			input.focus();
			return;
		}
		err.noError(input);
//		var id = 'BANK iban="'+iban+'"';
//		var sndVr = {};
//		sndVr[id] = '';
//		Utils.common(sndVr);
//
//		var bic = sndVr[id].getAttribute('bic');
//		if(sndVr[id] && bic)
//		{
//			var node = sndVr[id];
//
//			// if ccy is null then account does not exists
//			var ccy = node.getAttribute('ccy');
//			if(ccy == null) {
//				err.addError(false,input,'errIBANNotExists');
//				input.focus();
//				return;
//			}
//
//			if (bicfield) bicfield.value = bic;
//			if (banknamefield) banknamefield.value = node.getAttribute('name');
//			if (extras)
//			{
//				for (extra in extras)
//					if (form[extra] && node.getAttribute(extras[extra]))
//						form[extra].value = node.getAttribute(extras[extra]);
//			}
//		} else {
//			Utils.alertError(Utils.i18n(errIbanCode));
//			return;
//		}
	},
	getBic:function(input)
	{
		var errBic = 'errBICKT';
		var form = input.form;
		var bic = input.value;

		var system = form['@system'].value;
		var bankname = form['@bankname'];

		if (bic == '' || system == '') return;

		if(!Validator.isBICSEPA(bic)) {
			err.addError(false,input,errBic);
			input.focus();
			return;
		}

		err.noError(input);

		var id = 'BIC bic="'+bic+'" system="'+system+'"';
		var sndVr = {};
		sndVr[id] = '';
		Utils.common(sndVr);

		var name = sndVr[id].getAttribute('name');
		if(name == null) {
			bankname.value = ""; 
			err.addError(false,input,errBic);
			input.focus();
			return;
		}

		if (bankname) bankname.value = name;
	},
	PaymentTypeWins:{},
	choosePaymentType:function(iban_input,paytype_input)
	{
		var iban = iban_input.value;
		if (!iban)
		{
			Utils.alertError(Utils.i18n('chooseIBANFirst'));
			return;
		}
		var catType = iban.substring(12,14);
		if (catType.length != 2) 
		{
			Utils.alertError(Utils.i18n('errIBAN'));
			return;
		}

		if(!IB.PaymentTypeWins[catType])
		{
			var id = 'PAYMENTTYPES categorytype="'+catType+'"';
			var sndVr = {};
			sndVr[id] = '';
			Utils.common(sndVr);
			if(!sndVr[id]) return;

			var ptypes_node = sndVr[id];
			
			if (!ptypes_node.childNodes.length)
			{
				Utils.alertError(Utils.i18n('noPayTypeForIBAN'));
				return;
			}

			if (!IB.PaymentTypeWins[catType]) IB.PaymentTypeWins[catType] = {};
			var tobj = IB.PaymentTypeWins[catType];
			if (!tobj.win)
			{
				tobj.win = Utils.newWindow({min:0,max:0,close:1,move:1,resize:1,width:400,height:200});
				tobj.win.content.className = "PopUpWinCont";
			}

			OAT.Dom.clear(tobj.win.content);
			var table = OAT.Dom.create('table');
			var thead = OAT.Dom.create('thead');
			var tr = OAT.Dom.create('tr');
			var th = OAT.Dom.create('th');
			th.colSpan = 2;
			th.innerHTML = ptypes_node.getAttribute('categoryname');
			var tbody = OAT.Dom.create('tbody');
			OAT.Dom.append([tobj.win.content,table],[table,thead,tbody],[thead,tr],[tr,th]);
			for (var i=0;i<ptypes_node.childNodes.length;i++)
			{
				var ptype_node = ptypes_node.childNodes[i];
				var tr = OAT.Dom.create('tr');
				var td1 = OAT.Dom.create('td');
				td1.innerHTML = ptype_node.getAttribute('type');
				var td2 = OAT.Dom.create('td');
				var a1 = OAT.Dom.create('a');
				a1.innerHTML = ptype_node.getAttribute('name');
				OAT.Dom.append([tbody,tr],[tr,td1,td2],[td2,a1]);
				IB.attachWinClick(tr,tobj,ptype_node);
			}

			var size = OAT.Dom.getWH(tobj.win.content.firstChild);
			var w = size[0];
			var h = size[1] + 32;
			if (h > 200)
			{
				w = w + 17;
				h = 200;
			}
			tobj.win.resizeTo(w,h);
		} else {
			var tobj = IB.PaymentTypeWins[catType];
		}

    	var coords = OAT.Dom.position(paytype_input);
		var size = OAT.Dom.getWH(paytype_input);
		tobj.win.moveTo(coords[0],coords[1] + size[1]);
		OAT.Dom.show(tobj.win.div);
		l.raise(tobj.win.div);

    	tobj.callback = function(ptype_node){
    		paytype_input.value = ptype_node.getAttribute('type');
    	};
	},
	chooseUtilProvider1:function(provider_name, provider_code, provider_no)
	{
		if(!IB.UtilityProviders)
		{
			var id = 'UTILPROVIDERS';
			var sndVr = {};
			sndVr[id] = '';
			Utils.common(sndVr);
			if(!sndVr[id]) return;

			var result = sndVr[id];
			
			if (!result.childNodes.length)
			{
				Utils.alertError(Utils.i18n('errNoUtilProviders'));
				return;
			}
			IB.UtilityProviders = {};
			var tobj = IB.UtilityProviders;
			if (!tobj.win)
			{
				tobj.win = Utils.newWindow({min:0,max:0,close:1,move:1,resize:1,width:400,height:200});
				tobj.win.content.className = "PopUpWinCont";
			}

			OAT.Dom.clear(tobj.win.content);
			var table = OAT.Dom.create('table');
			var thead = OAT.Dom.create('thead');
			var tr = OAT.Dom.create('tr');
			var th = OAT.Dom.create('th');
			th.colSpan = 2;
			th.innerHTML = 'Utility Providers';
			var tbody = OAT.Dom.create('tbody');
			OAT.Dom.append([tobj.win.content,table],[table,thead,tbody],[thead,tr],[tr,th]);
			for (var i=0; i < result.childNodes.length;i++)
			{
				var node = result.childNodes[i];
				var tr = OAT.Dom.create('tr');
				var td1 = OAT.Dom.create('td');
				td1.innerHTML = node.getAttribute('id');
				var td2 = OAT.Dom.create('td');
				var a1 = OAT.Dom.create('a');
				a1.innerHTML = node.getAttribute('name');
				OAT.Dom.append([tbody,tr],[tr,td1,td2],[td2,a1]);
				IB.attachWinClick(tr,tobj,node);
			}

			var size = OAT.Dom.getWH(tobj.win.content.firstChild);
			var w = size[0];
			var h = size[1] + 32;
			if (h > 200)
			{
				w = w + 17;
				h = 200;
			}
			tobj.win.resizeTo(w,h);
		} else {
			var tobj = IB.UtilityProviders;
		}

    	var coords = OAT.Dom.position(provider_name);
		var size = OAT.Dom.getWH(provider_name);
		tobj.win.moveTo(coords[0],coords[1] + size[1]);
		OAT.Dom.show(tobj.win.div);
		l.raise(tobj.win.div);

    	tobj.callback = function(node){
    		provider_name.value = node.getAttribute('name');
    		provider_code.value = node.getAttribute('id');
    		provider_no.value = node.getAttribute('custno');
    	
    		if (provider_code.value == 'AMEX') {
    			var input = document.getElementById('@subscriberno');
    			if (input) {
    				input.onblur = function () {
    					if (! Validator.isValidAMEX(input.value)) {
    						Utils.alertError(Utils.i18n('ErrInvalidAMEX'));
    						// indicate an error
    						input.style.border = '1px solid red';
    					} else {
    						input.style.border = '';
    					}
    				}
    			}
    		}
    		// process UDFs, generating the HTML, and preserving the input elements as xml
    		var xmlstr = '';
    		var xmlinputs = '<UDFINPUTS>';
    		var product = node.getAttribute('product');
    		var transpath = "/i18n/msg[@id='utility_providers']/provider[@product_code = 'default']";
    		var specTranspath = "/i18n/msg[@id='utility_providers']/provider[@product_code = '" + product + "']";
    		if(OAT.Xml.xpath(Utils.getI18nXml(),specTranspath).length > 0){
    			transpath = specTranspath;// thear are specific fields and labels.
    			
    		}
    		for (var i=0; i < node.childNodes.length; i++)
			{
				var udf = node.childNodes[i];
				var vtype = udf.getAttribute('vtype');
    			var uname = udf.getAttribute('name');
    			var fname = '@udf_' + uname;
    			var label = OAT.Xml.xpath(Utils.getI18nXml(), transpath + "/msg[@id='udf_"+ uname +"']");
				if(label.length == 0){
					var inputxml = '<input value="" type="hidden"  name="' + fname + '" id="' + fname + '"></input>';
					xmlinputs += inputxml;
					xmlstr += inputxml;
					continue;
				}
				
    			var ulen = udf.getAttribute('length');
				var min = udf.getAttribute('min');
				var max = udf.getAttribute('max');
				
    			if (!ulen) {
    				if (max > 35) ulen = 35;
    				else ulen = max;
    			}
    			 
		    	xmlstr += '<div class="left box" style="margin-left: 2px">';
		    	xmlstr += '<label for="' + fname + '">' + OAT.Xml.textValue(label[0]) + ':</label><br/>';
		    	if (vtype && vtype == 'V') {
		    		var selectxml = '<select name="' + fname + '" id="' + fname + '">';
		    		for (var c=0; c < udf.childNodes.length; c++) {
		    			var optval = udf.childNodes[c].getAttribute('value');
		    			var optdesc = udf.childNodes[c].getAttribute('desc');
		    			selectxml += '<option value="' + optval + '">' + optdesc + '</option>';
		    		}
					selectxml += '</select>';
					xmlinputs += selectxml;
					xmlstr += selectxml;
		    	} else {
					var inputxml = '<input value="" type="text" minlength="' + min + '" maxlength="' + max + '" name="' + 
						fname + '" id="' + fname + '" style="width:' + ulen * 14 + 'px"></input>';
					xmlinputs += inputxml;
					xmlstr += inputxml;
		    	}
		    	xmlstr += '</div>';
				//alert(xmlstr);
    		}
    		xmlinputs += '</UDFINPUTS>';
    		IB.UtilityProviders.xmlinputs = xmlinputs; 
			document.getElementById('udfdiv').innerHTML = '<input value="' + product + '" type="hidden" name="@product" id="@product" />' + xmlstr;
    	};
	},
chooseUtilProvider:function(form ,provider_name, provider_code, provider_no)
{
	if(!IB.UtilityProviders)
	{
		var id = 'UTILPROVIDERS';
		var sndVr = {};
		sndVr[id] = '';
		Utils.common(sndVr);
		if(!sndVr[id]) return;
		
		var result = sndVr[id];
		
		if (!result.childNodes.length)
		{
			Utils.alertError(Utils.i18n('errNoUtilProviders'));
			return;
		}
		IB.UtilityProviders = {};
		var tobj = IB.UtilityProviders;
		if (!tobj.win)
		{
			tobj.win = Utils.newWindow({min:0,max:0,close:1,move:1,resize:1,width:400,height:200});
			tobj.win.content.className = "PopUpWinCont";
		}
		
		OAT.Dom.clear(tobj.win.content);
		var table = OAT.Dom.create('table');
		var thead = OAT.Dom.create('thead');
		var tr = OAT.Dom.create('tr');
		var th = OAT.Dom.create('th');
		th.colSpan = 2;
		th.innerHTML = 'Utility Providers';
		var tbody = OAT.Dom.create('tbody');
		OAT.Dom.append([tobj.win.content,table],[table,thead,tbody],[thead,tr],[tr,th]);
		for (var i=0; i < result.childNodes.length;i++)
		{
			var node = result.childNodes[i];
			var tr = OAT.Dom.create('tr');
			var td1 = OAT.Dom.create('td');
			td1.innerHTML = node.getAttribute('id');
			var td2 = OAT.Dom.create('td');
			var a1 = OAT.Dom.create('a');
			a1.innerHTML = node.getAttribute('name');
			OAT.Dom.append([tbody,tr],[tr,td1,td2],[td2,a1]);
			IB.attachWinClick(tr,tobj,node);
		}
		
		var size = OAT.Dom.getWH(tobj.win.content.firstChild);
		var w = size[0];
		var h = size[1] + 32;
		if (h > 200)
		{
			w = w + 17;
			h = 200;
		}
		tobj.win.resizeTo(w,h);
	} else {
		var tobj = IB.UtilityProviders;
	}
	
	var coords = OAT.Dom.position(provider_name);
	var size = OAT.Dom.getWH(provider_name);
	tobj.win.moveTo(coords[0],coords[1] + size[1]);
	OAT.Dom.show(tobj.win.div);
	l.raise(tobj.win.div);
	
	tobj.callback = function(node){
		var container = form.container
		var xml_data = container.xml_data;
		var filexsl = container.getAttribute(IB.attrFILEXSL);
		var defpar = container.getAttribute(IB.attrDEFPAR);
		var funcid = container.getAttribute(IB.attrFUNCID);
		var ovrOpt = {};
		try { eval(defpar); } catch(e) { alert('eval(defpar) ' + e); return; };
	
		var UTIL_CUST_PHONENO = (IB.customer.getAttribute("compid"))?IB.customer.getAttribute("phoneno"):IB.user.getAttribute("cellphone");	
		var UTIL_CUST_EMAIL = (IB.customer.getAttribute("compid"))?"":IB.user.getAttribute("email");

		ovrOpt["@udf_UTIL_CUST_PHONENO"] = UTIL_CUST_PHONENO; 
		ovrOpt["@udf_UTIL_CUST_EMAIL"] = UTIL_CUST_EMAIL; 
		
		ovrOpt[provider_name] = node.getAttribute('name');
		ovrOpt[provider_code] = node.getAttribute('id');
		ovrOpt[provider_no] = node.getAttribute('custno');
		
		var objDom = Utils.newXmlDocWithXsl(filexsl);

		var nPack = Utils.createElementWithSessLang(objDom, "PACKAGE");
		var nDocs = objDom.createElement("DOCUMENTS");

		var nDoc = objDom.createElement("DOCUMENT");
		
		
		for(p in ovrOpt) {
			var attr = p.match('^@(.*)$');
			if(attr && ovrOpt[p]) {
				nDoc.setAttribute(attr[1], ovrOpt[p]);
			}
		}
		nDoc.appendChild(node.cloneNode(true));
		nDocs.appendChild(nDoc);
		nPack.appendChild(nDocs);
		objDom.appendChild(nPack);

		IB.transformFunc(objDom, container, filexsl);
	};
},
	ReqCardSend:function(form)
	{
		if (!form['@nameoncard'].value)
		{
			Utils.alertError(Utils.i18n('req_crErrNameOnCard'));
			return;
		}	
		var productId = form['@productId'].value;
		var i18nXml = Utils.getI18nXml();
		var node = OAT.Xml.xpath(i18nXml,"/i18n/msg[@id='req_crProductEnum']/option[@value='"+productId+"']");
		var productName = OAT.Xml.textValue(node[0]);
		IB.Update(form,{'@productName':productName});
	},
	showDeclFX:function(input)
	{
		return;
		var amount = input.value;
		var div_id = input.form.id + '_declFX_cont';
		if (Validator.isDecl30kNeeded(amount))
			OAT.Dom.show(div_id);
		else
			OAT.Dom.hide(div_id);
	},
	docExchChangeType:function(form)
	{
		var val = form['@amountdt'].value;
		if (!val)
			val = form['@amountkt'].value;
		if (form['type_sell'].checked)
		{
			OAT.Dom.show(form.id+'-row-dt');
			OAT.Dom.hide(form.id+'-row-kt');
			form['@amountdt'].value = val;
			form['@amountkt'].value = '';
		} else {
			OAT.Dom.show(form.id+'-row-kt');
			OAT.Dom.hide(form.id+'-row-dt');
			form['@amountdt'].value = '';
			form['@amountkt'].value = val;
		}
		IB.docExchClearFXDeal(form);
	},
	docExchChooseFXDeal:function(formp) {
		form = $(formp);
		var options = {'@buyccy':form['@currkt'].value,
					   '@sellccy':form['@currdt'].value,
					   '@fromdate':Utils.getYesterda(),
					   '@todate':Utils.getToday()};
		if (form['type_sell'].checked) {
			options['@dealtype'] = 'S';
			options['@amount'] = form['@amountdt'].value;
		} else {
			options['@dealtype'] = 'B';
			options['@amount'] = form['@amountkt'].value;
		}
		
		if (!options['@dealtype'] || !options['@buyccy'] || !options['@sellccy'] || !options['@amount'] || !parseFloat(options['@amount']) > 0.0)
			return Utils.alertError(Utils.i18n('docExch_FXDealFillAll'));
		
		IB.FXDealChoose(form['@dealref'],options);
		return true;
	},
	docChooseFXDeal:function(formp) {
		form = $(formp);
		var options = {'@buyccy':form['@currkt'].value,
					   '@sellccy':form['@currdt'].value,
					   '@fromdate':Utils.getYesterday(),
					   '@todate':Utils.getToday(),
					   '@dealtype':'B', 
					   '@amount':form['@amount'].value};
		
		if (!options['@buyccy'] || !options['@sellccy'] || !options['@amount'] || !parseFloat(options['@amount']) > 0.0)
			return Utils.alertError(Utils.i18n('docExch_FXDealFillAll'));
		
		IB.FXDealChoose(form['@dealref'],options);
		return true;
	},
	docClearFXDeal:function(formp) {
		form = $(formp);
		if (form['@dealref'] && form['@dealref'].value) {
			Utils.alertError(Utils.i18n('docExch_FXDealRefInvalid'));
			form['@dealref'].value = '';
		}
	},
	docExchClearFXDeal:function(form) {
		IB.docClearFXDeal(form);
	},
	docDeclIncomeChangeType:function(form) {
		var elms = form['@nationalitytype'];
		for (var i=0;i<elms.length;i++)  {
			if (elms[i].checked)
				OAT.Dom.show(form.id+'-'+elms[i].value);
			else
				OAT.Dom.hide(form.id+'-'+elms[i].value);
		}
	},
	docExchChangeRateType:function(form) {
		if (form['standardrate'].checked)
		{
			OAT.Dom.hide(form.id+'-offer-id');
		} else {
			OAT.Dom.show(form.id+'-offer-id');
		}
		form['@dealref'].value = '';
	},
	Print:function() {
		IB.PrintSetDateTime();
		window.print();
	},
	PrintSetDateTime:function() {
		var today = new Date();
		$('printDate').innerHTML = Utils.formatDate(today);
		$('printTime').innerHTML = Utils.putLeadingZero(today.getHours(),2)+':'+Utils.putLeadingZero(today.getMinutes(),2)+':'+Utils.putLeadingZero(today.getSeconds(),2);
	},
	Help:function(funcConst)
	{
		Help.show(funcConst);
	},
	Refresh:function(forceReload)
	{
		if (forceReload && IB.sub_tab.values[IB.sub_tab.selectedIndex])
			IB.sub_tab.values[IB.sub_tab.selectedIndex].loaded = false;
		IB.sub_tab.goTo(IB.sub_tab.keys[IB.sub_tab.selectedIndex]);
	},
	UpdateAccAlias_AccountChange:function(input)
	{
		var form = input.form;
		var accountid = $v(input);
		if (accountid)
		{
			var account = Utils.xpathSingle(IB.accounts_xml,"//ACCOUNTS/ACCOUNT[@id = '"+accountid+"']");
			form['@alias'].value = account.getAttribute('alias');
		} else 
			form['@alias'].value = '';
	},
	forceCertReg:function() {
		if (!IB.forceCertRegWin) {
			var div = OAT.Dom.create('div',{textAlign:'center'});
			var Box = OAT.Dom.create('div',{textAlign:'left',marginBottom:'10px'},'errorBox');

			var width = OAT.Dom.getViewport()[0]/2;
			IB.forceCertRegWin = new OAT.Dialog('&#160;',div,{modal:1, buttons:0, close:0, resize:0, width:width, height:200});

			var tokenreg = OAT.Dom.create('button',{marginLeft:'10px',marginRight:'10px'});
		 	tokenreg.innerHTML = Utils.i18n('forceCertReg_PIN');

		 	OAT.Dom.append([div,Box,tokenreg]);

			OAT.Dom.attach(tokenreg,"click",function(){
				IB.goToFunc('UPDATE_TOKENPIN');
				IB.forceCertRegWin.hide();
			});
			IB.forceCertRegWin.issueBtn = tokenreg;

			IB.forceCertRegWin.Box = Box;
//			IB.forceCertRegWin.regBtn = reg;
		}

		IB.forceCertRegWin.Box.innerHTML = Utils.i18n('errRessetPin');
		IB.forceCertRegWin.show();
		IB.forceCertRegWin.issueBtn.focus();
		IB.forceCertRegWin.accomodate();
	},
	setupNewPage:function(){
		// We crete a new page
		OAT.Dom.clear(IB.PageContent);
		var Page = OAT.Dom.create('div');
		IB.PageContent.appendChild(Page);
		IB.ActivePage = Page;
		return Page;
	},
/*	showFXRates:function()
	{
		var funcid = Utils.getConst('FUNC_EXCHANGERATES');
		var tobj = IB.DocDetailsWinGet('popup'+funcid,funcid);
		var container = tobj.win.content;
		if (!container.firstChild)
		{
			var div = OAT.Dom.create('div',{padding:'2px',width:'500px',height:'350px'});
			OAT.Dom.append([container,div]);
			IB.Enquiry(div,{type:'EXCHANGERATES'});
		}
		IB.DocDetailsWinShow(tobj);
	},*/
	exchangeCalc:function(amount,amtccy,buyccy,sellccy,formid)
	{
		if (typeof(formid) == 'undefined')
		  formid = '';
		var funcid = Utils.getConst('FUNC_EXCHANGECALC');
		var tobj = IB.DocDetailsWinGet('popup'+funcid,funcid);
		var container = tobj.win.content;
		if (!container.firstChild)
		{
			var div = OAT.Dom.create('div',{padding:'2px',width:'350px',height:'85px'});
			OAT.Dom.append([container,div]);
			container.div = div;
		}
		OAT.Dom.clear(container.div);
		var xsltParams = [["","formid",formid]];
		IB.Enquiry(container.div,
				{type:'EXCHANGECALC',xsltParams:xsltParams,'@amount':amount,'@amtccy':amtccy,'@buyccy':buyccy,'@sellccy':sellccy},
				'xslt/enquiries/exchangecalc.xslt',
				funcid);
		IB.DocDetailsWinShow(tobj);
	},
	FXDealChoose:function(input, ovrOpt) {
		var options = {'@buyccy':'','@sellccy':'','@status':'0','@dealtype':'S','@fromdate':srvDatePrevious,'@todate':Utils.getToday(),'@amount':''};
		if (ovrOpt) for (var p in ovrOpt) { options[p] = ovrOpt[p]; }

		var funcid = Utils.getConst('FUNC_SEARCHFX');
		var tobj = IB.DocDetailsWinGet('popup'+funcid,funcid);
		var container = tobj.win.content;
		if (!container.firstChild) {
			var div = OAT.Dom.create('div',{padding:'2px',width:'550px',height:'185px'});
			OAT.Dom.append([container,div]);
			container.div = div;
		}
		OAT.Dom.clear(container.div);

		container.div.callback = function(dealref) {
			input.value = dealref;
			tobj.win.close();
		};

		options.type = 'SEARCHFX';
		IB.Enquiry(container.div, options, 'xslt/enquiries/searchfxpopup.xslt', funcid);
		IB.DocDetailsWinShow(tobj, input);
	},
	FXDealSelect:function(form_id, dealref) {
		var form = $(form_id);
		var container = form.container;
		if (container.callback)
			container.callback(dealref);
	}, 
	changePic:function(id, status){
		var picture = $(id);
		var alt = Utils.i18n("reg_status"+status);
		picture.setAttribute("alt", alt);
		picture.setAttribute("title", alt);
		picture.setAttribute("src", imagesURL+((status=="0")?"/tick.png":"/cross.png"));
	},
	setInactive:function(){
		if(IB.inactive) clearTimeout(IB.inactive);
		IB.inactive = setTimeout(function(){Utils.SessExp(Utils.i18n('ErrSessId'),function(){Logoff();});}, inactivWebSessTimeout);
	}
};

var l = {};
function init() 
{
	setTimeout(function(){Utils.SessExp(Utils.i18n('ErrSessId'),function(){Logoff();});}, webSessTimeout);
	OAT.Preferences.imagePath = "lib/oat/images/";
	OAT.AJAX.imagePath = "lib/oat/images";
	OAT.Preferences.showAjax = 1;
	OAT.AJAX.httpError = 0;
	//OAT.Preferences.windowTypeOverride = OAT.WindowData.TYPE_WIN;
	OAT.WindowData.TYPE_MAC = OAT.WindowData.TYPE_WIN;
	l = new OAT.Layers(100);
	
	OAT.MSG.attach(OAT.AJAX,OAT.MSG.AJAX_ERROR,function(sender,msg,xhr) {
		if (xhr.options.onerror) return;
		var errmsg = xhr.getResponseText();
		if (!errmsg) errmsg = Utils.i18n('ErrComm');
		Utils.alertError(errmsg);
	});
	
	IB.accounts_xml = OAT.Xml.createXmlDoc('<ACCOUNTS>' + accounts_xmlstr + '</ACCOUNTS>');
	IB.funcs_xml = OAT.Xml.createXmlDoc('<FUNCS>' + funcs_xmlstr + '</FUNCS>');
	IB.docstatus_xml = OAT.Xml.createXmlDoc(docstatus_xmlstr);
	IB.customer_xml = OAT.Xml.createXmlDoc(customer_xmlstr);
	IB.customers_xml = OAT.Xml.createXmlDoc('<CUSTOMERS>' + customers_xmlstr + '</CUSTOMERS>');
	IB.user_xml = OAT.Xml.createXmlDoc(user_xmlstr);
	IB.customer = OAT.Xml.xpath(IB.customer_xml,'//CUSTOMER')[0];
	IB.user = OAT.Xml.xpath(IB.user_xml,'//USER')[0];

	IB.PageContent = $('page_content');
	IB.WindowsDiv = $('windows');

	// Main navigation - changes content in div navtab_l2
	IB.nav_tab = new OAT.Tab("navtab_l2");
	// Left navigation - changes content in div page_content
	IB.sub_tab = new OAT.Tab(IB.PageContent);
  
	// Get all the "li"s from main navigation and loop on them
	var topnavi_ul = $("topnavi_ul");
	var list = topnavi_ul.childNodes;

	// should be length-1, the last menu item is EXIT
	for (var i=0;i<list.length-1;i++) 
	{
		if (list[i].tagName && list[i].tagName.toLowerCase() == "li") 
		{
			// for each li add to tab and assign content to load
			var li_id = list[i].getAttribute("id");
      		IB.nav_tab.add(li_id,li_id + "_page");
      		
			// get all the "li"s from the sub tab and loop over them
      		var li_l2_ul = $(li_id + "_list");
			var list_l2 = li_l2_ul.childNodes;
			for (var n=0;n<list_l2.length;n++) {
				if (list_l2[n].tagName && list_l2[n].tagName.toLowerCase() == "li" && 
						(!OAT.Dom.isClass(list_l2[n],"disabled") || (typeof(debugLevel) != 'undefined' && debugLevel > 1))) 
				{
					// for each li add to tab and assign content to load
					var li_l2_id = list_l2[n].getAttribute("id");
					IB.sub_tab.add(li_l2_id,li_l2_id + "_page");
					// we store the main tab in the sub tab
					IB.sub_tab.keys[IB.sub_tab.selectedIndex].nav_tab_index = parseInt(i);
		      		if (n == 0) {
						// we store the first sub tab in the main tab
		      			IB.nav_tab.keys[i].first_tab_id = li_l2_id;
		      		}
				}
			}
		}
	}

	OAT.AJAX.dialog = {
		show:function(){
			var dimmer_win = $('pleaseWait_win');
			OAT.Dimmer.show(dimmer_win);
			OAT.Dom.center(dimmer_win,1,1);
		},
		hide:function(){
			OAT.Dimmer.hide();
		}
	};

	// this is called after click on the main tab
	IB.nav_tab.goCallback = function(oldindex,newindex)
	{
		// If the tab is change we default to the first sub tab
		if (oldindex != newindex)
			if (IB.nav_tab.keys[newindex].first_tab_id)
				IB.sub_tab.goTo($(IB.nav_tab.keys[newindex].first_tab_id));
	};

	//We use this iframe for browser back fix
	IB.HistIFrame = OAT.Dom.create('iframe',{display:'block',position:'absolute',top:0,left:'0px',zIndex:'-1',filter:'mask()',border:'none',width:'1px',height:'1px'});
	IB.HistIFrame.src = OAT.Loader.toolkitPath + 'blank.html';
	OAT.Dom.append([document.body,IB.HistIFrame]);
	
	// this is called after click on the sub tab
	IB.sub_tab.goCallback = function(oldindex,newindex)
	{
		// check for forceWindowClose
		if (IB.forceWindowClose)
		{
			Utils.alertOK(Utils.i18n('certIssueOK'),function(){window.close();});
			return false;
		}
		
		// If not IE browser we set the printing datetime
		if (!OAT.Browser.isIE)
			IB.PrintSetDateTime();
		// If we have an active page we get rid of it.
		if(IB.ActivePage)
			OAT.Dom.unlink(IB.ActivePage);
		
		//We try to fix back/forward here
		//We need to distinguish between normal click and back/forward
		if (!IB.HistNavClick) {
			IB.HistNormClick = true;
			IB.HistIFrame.src = dataURL + '/backfix.html' + '?' + newindex;
		}
		var mreturn = function(container) {
			IB.HistNavClick = false;
			if (container && container.form)
				Utils.formSetFocus(container.form);
		};

		var keyindex = IB.sub_tab.keys[newindex];

		//We check if we need to change the main tab - when called from a function
		if (IB.nav_tab.selectedIndex != keyindex.nav_tab_index)
			IB.nav_tab.go(keyindex.nav_tab_index,1);

		for(var i in IB.Templates)
			if (IB.Templates[i].win) IB.Templates[i].win.onclose();
		for(var i in IB.AccountsWins)
			if (IB.AccountsWins[i].win) IB.AccountsWins[i].win.onclose();
		for(var i in IB.DocDetailsWins)
			if (IB.DocDetailsWins[i].win) IB.DocDetailsWins[i].win.onclose();
		for(var i in IB.PaymentTypeWins)
			if (IB.PaymentTypeWins[i].win) IB.PaymentTypeWins[i].win.onclose();

		// Get func form if not loaded.
		var funcid = keyindex.getAttribute("funcid");
		if(funcid) {
			
			/*
			 * XXX: feature disabled by default
			 */
			// Check for UEP or TOKEN registration
			if (IB.user.getAttribute("resetpin") && IB.user.getAttribute("resetpin") == 1
			&& !(funcid == Utils.getConst('UPDATE_TOKENPIN'))) {
				IB.forceCertReg();
				return mreturn(false);
			}
			/**/
			
			//If we loaded before we don't load now ? Can change later on
			var container = IB.sub_tab.values[newindex];
			// Func in this array always loads
			var alwaysLoad = [Utils.getConst('FUNC_INBOX_MAIL'),
							  Utils.getConst('FUNC_BANK_MAIL'),
							  Utils.getConst('FUNC_CERTISSUE'),
							  Utils.getConst('FUNC_CERTREGISTER'),
							  Utils.getConst('OPENACCOUNT')];

			if(alwaysLoad.find(funcid) == -1 && container.loaded && container.loaded == true) 
				return mreturn(container);

			if(IB.HistNavClick) return mreturn(container);

			container.label = Utils.getCellValue(keyindex);
			container.setAttribute(IB.attrFILEXSL, keyindex.getAttribute(IB.attrFILEXSL));
			container.setAttribute(IB.attrDEFPAR,  keyindex.getAttribute(IB.attrDEFPAR));

			IB.loadFunc(container);
		}
		return mreturn(false);
	};

	// We make the first tab active on load
	IB.nav_tab.go(0);
	if ((typeof(debugLevel) != 'undefined' && debugLevel > 1))
	{
//		IB.sub_tab.go(23);
	}

	// We try to fix printing styles because IE is has problems
	if (OAT.Browser.isIE)
	{
		OAT.Event.attach(window,"beforeprint",function()
		{
			IB.PrintSetDateTime();
			var elm = IB.PageContent.getElementsByTagName('div');
			for (var i=0;i<elm.length;i++)
			{
				if (OAT.Dom.isClass(elm[i],'right') || OAT.Dom.isClass(elm[i],'left'))
				{
					var width = OAT.Dom.getWH(elm[i])[0];
					if (width) 
					{
						if (OAT.Dom.isClass(elm[i],'box') && !elm[i].style.width)
							width = width - 4;
						elm[i].style.width = width + 'px';
					}
				}
			}
		});
	}
	IB.PrintSetDateTime();
}