/*
 *  $Id: main.js,v 1.4 2007/04/16 06:03:00 lukav Exp $
 *
 *  (C)Copyright 2007 Lukanet Ltd.
 *  All Rights Reserved.
 *
 *  The copyright above and this notice must be preserved in all
 *  copies of this source code.  The copyright above does not
 *  evidence any actual or intended publication of this source code.
 *
 *  This is unpublished proprietary trade secret of Lukanet Ltd.
 *  This source code may not be copied, disclosed, distributed, demonstrated
 *  or licensed except as authorized by Lukanet Ltd.
 */


// Level 2 - do not pages and xslt
// Level 3 - do not pages, xslt and i18n files
var debugLevel = 0;
