var l = {};
function init() {
	l = new OAT.Layers(100);
	OAT.Preferences.imagePath = "lib/oat/images/";
	OAT.AJAX.imagePath = "lib/oat/images";
	OAT.Preferences.showAjax = 1;
	OAT.AJAX.httpError = 0;
	//OAT.Preferences.windowTypeOverride = OAT.WindowData.TYPE_WIN;
	OAT.WindowData.TYPE_MAC = OAT.WindowData.TYPE_WIN;
	l = new OAT.Layers(100);
	
	OAT.MSG.attach(OAT.AJAX,OAT.MSG.AJAX_ERROR,function(sender,msg,xhr) {
		Utils.alertError(xhr.getResponseText());
	});
}
var frmlogin = document.getElementById("loginform");
var frmlc = document.getElementById("lc");

function excapeXMLValue(val) {
	return val.replace('&amp;','&amp;amp;').replace('&lt;','&amp;lt;').replace('&gt;','&amp;gt;');
}
function Validate() {
	with (document.loginform) {
		var newpassword = '';
		var isagree = '';
		if (typeof(s_newpassword) != 'undefined') {
			if (s_newpassword.value == "" || s_confirmpassword.value == "") {
				alert(loginFillAll);
				return false;
			}
			if (s_newpassword.value != s_confirmpassword.value) {
				alert(lgConfirmNoMatch);
				return false;
			}
			newpassword = ' newpassword="'+s_newpassword.value.replace('"','&quot;')+'"';
			
			if (typeof(agreement) != 'undefined' && agreement.checked ) {
				isagree = ' agreement="1"';
			}
			if (typeof(obagreement) != 'undefined' && obagreement.checked ) {
				isagree = isagree + ' obagreement="1"';
			}
		}

		/*
		 * XXX: disabled
		 *
		 var vpinotp = (pinotp.value != "")? ' pinotp="'+pinotp.value+'"' : "";
		 */

		if (S_USERID.value == "") {
			alert(loginFillAll);
			S_USERID.focus();
			return false;
		} else if (password.value == "") {
			alert(loginFillAll);
			password.focus();
			return false;
		} else {
			/*
			 * XXX: see above
			 *
			textXML.value = '<?xml version="1.0"?><LOGIN'+newpassword+vpinotp+'><USER_NAME>'+S_USERID.value+'</USER_NAME><USER_PASS>'+excapeXMLValue(password.value)+'</USER_PASS><USER_LANG>'+S_LANG.value+'</USER_LANG><CUSTOMER_TYPE>'+custType+'</CUSTOMER_TYPE></LOGIN>';
			*/
			textXML.value = '<?xml version="1.0"?><LOGIN'+newpassword+isagree+'><USER_NAME>'+S_USERID.value+'</USER_NAME><USER_PASS>'+excapeXMLValue(password.value)+'</USER_PASS><USER_LANG>'+S_LANG.value+'</USER_LANG><CUSTOMER_TYPE>'+custType+'</CUSTOMER_TYPE></LOGIN>';
			return true;
		}
	}
}
function ChangeLang(langid, typeid) {
	var date = new Date();
	date.setTime(date.getTime()+(60*1000*24*365));
	var expires = "; expires="+date.toGMTString();
	document.cookie = "lang="+langid+expires+";";
	document.cookie = "typeid="+typeid+expires+";";
	frmlc.textXML.value = "<LOGIN><USER_LANG>"+langid+"</USER_LANG><CUSTOMER_TYPE>"+typeid+"</CUSTOMER_TYPE></LOGIN>";
	frmlc.submit();
}


function demoSubmit() {
	frmlogin.USER_NAME.value = 'demo';
	frmlogin.password.value = 'demo123';
	if(Validate()) {
		frmlogin.submit();
	}
}

function Logoff(sessid) {
	frmlc.value = "<LOGIN><USER_SESS>"+sessid+"</USER_SESS></LOGIN>"; 							
	frmlc.submit();
}