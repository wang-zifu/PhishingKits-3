/*
 *  $Id: utils.js,v 1.2 2007/04/02 12:20:58 darco Exp $
 *  $Id: utils.js,v 2.0 2010/04/07 00:00:00 kostomberov code review and DB integration $
 *
 *  (C)Copyright 2007 Lukanet Ltd.
 *  All Rights Reserved.
 *
 *  The copyright above and this notice must be preserved in all
 *  copies of this source code.  The copyright above does not
 *  evidence any actual or intended publication of this source code.
 *
 *  This is unpublished proprietary trade secret of Lukanet Ltd.
 *  This source code may not be copied, disclosed, distributed, demonstrated
 *  or licensed except as authorized by Lukanet Ltd.
 */

/*
CryptoJS v3.0.2
code.google.com/p/crypto-js
(c) 2009-2012 by Jeff Mott. All rights reserved.
code.google.com/p/crypto-js/wiki/License
*/
var CryptoJS=CryptoJS||function(i,m){var p={},h=p.lib={},n=h.Base=function(){function a(){}return{extend:function(b){a.prototype=this;var c=new a;b&&c.mixIn(b);c.$super=this;return c},create:function(){var a=this.extend();a.init.apply(a,arguments);return a},init:function(){},mixIn:function(a){for(var c in a)a.hasOwnProperty(c)&&(this[c]=a[c]);a.hasOwnProperty("toString")&&(this.toString=a.toString)},clone:function(){return this.$super.extend(this)}}}(),o=h.WordArray=n.extend({init:function(a,b){a=
this.words=a||[];this.sigBytes=b!=m?b:4*a.length},toString:function(a){return(a||e).stringify(this)},concat:function(a){var b=this.words,c=a.words,d=this.sigBytes,a=a.sigBytes;this.clamp();if(d%4)for(var f=0;f<a;f++)b[d+f>>>2]|=(c[f>>>2]>>>24-8*(f%4)&255)<<24-8*((d+f)%4);else if(65535<c.length)for(f=0;f<a;f+=4)b[d+f>>>2]=c[f>>>2];else b.push.apply(b,c);this.sigBytes+=a;return this},clamp:function(){var a=this.words,b=this.sigBytes;a[b>>>2]&=4294967295<<32-8*(b%4);a.length=i.ceil(b/4)},clone:function(){var a=
n.clone.call(this);a.words=this.words.slice(0);return a},random:function(a){for(var b=[],c=0;c<a;c+=4)b.push(4294967296*i.random()|0);return o.create(b,a)}}),q=p.enc={},e=q.Hex={stringify:function(a){for(var b=a.words,a=a.sigBytes,c=[],d=0;d<a;d++){var f=b[d>>>2]>>>24-8*(d%4)&255;c.push((f>>>4).toString(16));c.push((f&15).toString(16))}return c.join("")},parse:function(a){for(var b=a.length,c=[],d=0;d<b;d+=2)c[d>>>3]|=parseInt(a.substr(d,2),16)<<24-4*(d%8);return o.create(c,b/2)}},g=q.Latin1={stringify:function(a){for(var b=
a.words,a=a.sigBytes,c=[],d=0;d<a;d++)c.push(String.fromCharCode(b[d>>>2]>>>24-8*(d%4)&255));return c.join("")},parse:function(a){for(var b=a.length,c=[],d=0;d<b;d++)c[d>>>2]|=(a.charCodeAt(d)&255)<<24-8*(d%4);return o.create(c,b)}},j=q.Utf8={stringify:function(a){try{return decodeURIComponent(escape(g.stringify(a)))}catch(b){throw Error("Malformed UTF-8 data");}},parse:function(a){return g.parse(unescape(encodeURIComponent(a)))}},k=h.BufferedBlockAlgorithm=n.extend({reset:function(){this._data=o.create();
this._nDataBytes=0},_append:function(a){"string"==typeof a&&(a=j.parse(a));this._data.concat(a);this._nDataBytes+=a.sigBytes},_process:function(a){var b=this._data,c=b.words,d=b.sigBytes,f=this.blockSize,e=d/(4*f),e=a?i.ceil(e):i.max((e|0)-this._minBufferSize,0),a=e*f,d=i.min(4*a,d);if(a){for(var g=0;g<a;g+=f)this._doProcessBlock(c,g);g=c.splice(0,a);b.sigBytes-=d}return o.create(g,d)},clone:function(){var a=n.clone.call(this);a._data=this._data.clone();return a},_minBufferSize:0});h.Hasher=k.extend({init:function(){this.reset()},
reset:function(){k.reset.call(this);this._doReset()},update:function(a){this._append(a);this._process();return this},finalize:function(a){a&&this._append(a);this._doFinalize();return this._hash},clone:function(){var a=k.clone.call(this);a._hash=this._hash.clone();return a},blockSize:16,_createHelper:function(a){return function(b,c){return a.create(c).finalize(b)}},_createHmacHelper:function(a){return function(b,c){return l.HMAC.create(a,c).finalize(b)}}});var l=p.algo={};return p}(Math);
(function(){var i=CryptoJS,m=i.lib,p=m.WordArray,m=m.Hasher,h=[],n=i.algo.SHA1=m.extend({_doReset:function(){this._hash=p.create([1732584193,4023233417,2562383102,271733878,3285377520])},_doProcessBlock:function(o,i){for(var e=this._hash.words,g=e[0],j=e[1],k=e[2],l=e[3],a=e[4],b=0;80>b;b++){if(16>b)h[b]=o[i+b]|0;else{var c=h[b-3]^h[b-8]^h[b-14]^h[b-16];h[b]=c<<1|c>>>31}c=(g<<5|g>>>27)+a+h[b];c=20>b?c+((j&k|~j&l)+1518500249):40>b?c+((j^k^l)+1859775393):60>b?c+((j&k|j&l|k&l)-1894007588):c+((j^k^l)-
899497514);a=l;l=k;k=j<<30|j>>>2;j=g;g=c}e[0]=e[0]+g|0;e[1]=e[1]+j|0;e[2]=e[2]+k|0;e[3]=e[3]+l|0;e[4]=e[4]+a|0},_doFinalize:function(){var i=this._data,h=i.words,e=8*this._nDataBytes,g=8*i.sigBytes;h[g>>>5]|=128<<24-g%32;h[(g+64>>>9<<4)+15]=e;i.sigBytes=4*h.length;this._process()}});i.SHA1=m._createHelper(n);i.HmacSHA1=m._createHmacHelper(n)})();

var Utils = {
	xmlEscAttr:function(str){
		// Ima nujda da se napishe funkciq koqto obrusha & samo ako ne e chast ot drug escape
		return str.replace(/"/g,'&quot;').replace(/</,'&lt;');
		//return str.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</,'&lt;');
	},
	putLeadingZero:function(val,prec)
	{
	  if (!prec) prec = 2;
	  if(String(val).length < prec)
	    return '0'.repeat(prec - String(val).length) + String(val);
	  else 
	    return val;
	},
	getDate:function(inpt,full)
	{
		var tmp;
		if (full && (tmp = String(inpt).match(/([0-9]{1,2})\W?([0-9]{1,2})\W?([0-9]{4,4})\W?([0-9]{1,2})\W?([0-9]{1,2})\W?([0-9]{1,2})\W?/)))
			return new Date(tmp[3] + '/' + tmp[2] + '/' + tmp[1] + ' ' + tmp[4] + ':' + tmp[5] + ':' + tmp[6]);
		if ((tmp = String(inpt).match(/([0-9]{1,2})\W?([0-9]{1,2})\W?([0-9]{4,4})/)))
			return new Date(tmp[3] + '/' + tmp[2] + '/' + tmp[1]);
		if (!isNaN(Date.parse(String(inpt).replace(/-/g,'/'))))
    	 	return new Date(String(inpt).replace(/-/g,'/'));
    	return false;
    },
	formatDate:function(indt) {
		var dindt = String(indt);
		if (isNaN(Date.parse(dindt))) {
			dindt = dindt.replace(/-/g, '/');
			if (isNaN(Date.parse(dindt))) {
				return indt;
			}
		}
		var tmp = new Date(dindt);
		return Utils.putLeadingZero(tmp.getDate(), 2) + '/'
				+ Utils.putLeadingZero(tmp.getMonth() + 1, 2) + '/'
				+ tmp.getFullYear();
	},	
	getToday:function()
	{
		return Utils.formatDate(Date());
	},
	getYesterday:function()
	{
		var today = new Date();
		var Yesterday = new Date(today - 86400000);
		return Utils.formatDate(Yesterday);
	},
	getTomorrow:function()
	{
		var today = new Date();
		var Tomorrow = new Date(today.getTime() + 86400000);
		return Utils.formatDate(Tomorrow);
	},
	getFirstDay:function(){
	    var today = new Date();
	    return Utils.formatDate(today.getFullYear() + '/' + (today.getMonth() + 1) + '/' + '01');
	},
	getBeginYear:function(){
	    var today = new Date();
	    return Utils.formatDate(today.getFullYear() + '/' + '01' + '/' + '01');
	},
	getFirstDayOf:function(dt){
	    var date = Utils.getDate(dt, true);
	    return Utils.formatDate(date.getFullYear() + '/' + (date.getMonth() + 1) + '/' + '01');
	},
    getFirstDayOfLastMonth:function(dt) {
	    var date = Utils.getDate(dt, true);
	    return Utils.formatDate(date.getFullYear() + '/' + date.getMonth() + '/' + '01');    	
    },
    XSLT:{index:[],obj:[]},
	getXSLT:function(xml_data)
	{
		for (var i=0;i<xml_data.childNodes.length;i++){
			// Get xslt
			if (xml_data.childNodes[i].nodeName == 'xml-stylesheet')
			{
				var tmp = '';
				if ((tmp = xml_data.childNodes[i].nodeValue.match('href *= *"([^"]*)"')))
				  return tmp[1];
			}
		}
		return false;
	},
	transformXSLT:function(xml_data, params, xslt_uri) {
		if(!xml_data.documentElement) {
			Utils.alertError(Utils.i18n('ErrComm'));
			return '';
		}
		// many funcs comes here without xslt_uri
		if (!xslt_uri)
			xslt_uri = Utils.getXSLT(xml_data);

		var xslt_content = Utils.load_xslt(xslt_uri);

		var bCONSTS = false, bI18n = false, bACC = false, 
		bFUNCS = false, bCST = false, bFGROUPS = false, 
		bBRANCHES = false, bDEPOSITTYPES = false, bHELPINDEX = false;

		var children = xml_data.documentElement.childNodes;
		for(var j = 0; j < children.length; j++) {
			var chname = children[j].tagName;
			if(chname == "CONSTS") bCONSTS = true;
			else if(chname == "i18n") bI18n = true;
			else if(chname == "ACCOUNTS") bACC = true;
			else if(chname == "FUNCS") bFUNCS = true;
			else if(chname == "CUSTOMER") bCST = true;
			else if(chname == "FGROUPS") bFGROUPS = true;
			else if(chname == "BRANCHES") bBRANCHES = true;
			else if(chname == "DEPOSITTYPES") bDEPOSITTYPES = true;
			else if(chname == "HELPINDEX") bHELPINDEX = true;
		}

		var xsltParams = [	["","today",Utils.getToday()],
		                  	["","lang",lang],
						 	["","ebankURL",ebankURL],
						 	["","dataURL",dataURL],
						 	["","id",new Date().getTime()],
						 	["","imagesURL",imagesURL]];

		if(!bI18n) {
			var i18node = OAT.Xml.xpath(Utils.getI18nXml(),"/i18n");
			xml_data.documentElement.appendChild(i18node[0].cloneNode(true));
		}

		if(params && params.length) {
			for (var i = 0; i < params.length; i++) {
				var paramname = params[i][1];
				if(paramname == "consts" && !bCONSTS) {
					var nodes = OAT.Xml.xpath(Utils.getConstsXml(),"/CONSTS");
					xml_data.documentElement.appendChild(nodes[0].cloneNode(true));					
				} else if(paramname == "accounts" && !bACC) {
					var nodes = OAT.Xml.xpath(IB.accounts_xml, "/ACCOUNTS");
					xml_data.documentElement.appendChild(nodes[0].cloneNode(true));
				} else if(paramname == "funcs" && !bFUNCS) {
					var nodes = OAT.Xml.xpath(IB.funcs_xml, "/FUNCS");
					xml_data.documentElement.appendChild(nodes[0].cloneNode(true));
				} else if(paramname == "docstatus") {
					var nodes = OAT.Xml.xpath(IB.docstatus_xml, "/DOCSTATUS");
					xml_data.documentElement.appendChild(nodes[0].cloneNode(true));
				} else if((paramname == "contextCustomer" || paramname == "customer") && !bCST) {
					xml_data.documentElement.appendChild(IB.customer.cloneNode(true));
				} else if(paramname == "branches" && !bBRANCHES) {
					xml_data.documentElement.appendChild(params[i][2].cloneNode(true));
				} else if(paramname == "fgroups" && !bFGROUPS) {
					xml_data.documentElement.appendChild(params[i][2].cloneNode(true));
				} else if(paramname == "user") {
					xml_data.documentElement.appendChild(IB.user.cloneNode(true));
				} else if(paramname == "helpIndexXML" && !bHELPINDEX) {
					var nodes = OAT.Xml.xpath(params[i][2], "/HELPINDEX");
					xml_data.documentElement.appendChild(nodes[0].cloneNode(true));
				} else if(paramname == "countries") {
					var nodes = OAT.Xml.xpath(Utils.getCountriesXml(),"/COUNTRIES");
					xml_data.documentElement.appendChild(nodes[0].cloneNode(true));
				} else if(paramname == "econtrols") {
					var nodes = OAT.Xml.xpath(Utils.getEControlsXml(),"/ECONTROLS");
					xml_data.documentElement.appendChild(nodes[0].cloneNode(true));
				} else if(paramname == "deptypes" && !bDEPOSITTYPES) {
					xml_data.documentElement.appendChild(params[i][2].cloneNode(true));
				} else {
					xsltParams.push(params[i]);
				}
			}
		}

		var html_xml = OAT.Xml.transformXSLT(xml_data, xslt_content, xsltParams);
		var html_content = OAT.Xml.serializeXmlDoc(html_xml.documentElement);
		IB.setInactive();
		return html_content;
	},
	load_xslt:function(xslt_uri,onerror){
		if (typeof(onerror) == 'undefined')	onerror = false;

		if (debugLevel == 0 && Utils.XSLT.index.find(xslt_uri) != -1)
			return Utils.XSLT.obj[Utils.XSLT.index.find(xslt_uri)];
		
		var xslt_content = '';
		var callback = function(data) {
			xslt_content = OAT.Xml.createXmlDoc(data);

			if (!xslt_content) return false;

			var nsObj = {xsl:"http://www.w3.org/1999/XSL/Transform"};

			var includes = OAT.Xml.xpath(xslt_content, "/xsl:stylesheet/xsl:include", nsObj);

			for(var i = 0; i < includes.length; i++) {
				var inc_file = includes[i].getAttribute("href");
				var path = xslt_uri.substring(0,xslt_uri.lastIndexOf("/")) + "/" + inc_file;
				// Normalize path 
				while (path.match(/\/\.\./))
					path = path.replace(/\/[^\/]*\/\.\./g,'');
				var inc_xml = Utils.load_xslt(path);
				var childs = OAT.Xml.xpath(inc_xml,"/xsl:stylesheet/*",nsObj);
				for(var n = 0; n < childs.length; n++) {
					var node = childs[n].cloneNode(true);
					includes[i].parentNode.insertBefore(node,includes[i]);
				}
				OAT.Dom.unlink(includes[i]);
			}

			// dynamic load of js file
			var scripts = OAT.Xml.xpath(xslt_content,"//script");
			for(var i = 0; i < scripts.length; i++) {
				var oHead = document.getElementsByTagName('head')[0];
				var oScript = document.createElement('script');
				oScript.type = 'text/javascript';
				oScript.src = jsURL + '/' + scripts[i].getAttribute("src");
				oHead.appendChild(oScript);
			}

			Utils.XSLT.index.push(xslt_uri);
			Utils.XSLT.obj.push(xslt_content);
			
			return xslt_content;
		};

		Utils.AJAX.GET(ebankURL + xslt_uri,'',callback,{async:false,type:OAT.AJAX.TYPE_TEXT,noSecurityCookie:true,onerror:onerror});
		
		return xslt_content;
	},
	alertErrors:function(xml_data){
		var error_nodes = OAT.Xml.xpath(xml_data,'//ERRORS/ERROR');
		if (error_nodes.length)
		{
			if (!Utils.errorDialog)
			{
				var contentDiv = OAT.Dom.create("div");
				var width = OAT.Dom.getViewport()[0]/3;
				var container = OAT.Dom.create("div");
				OAT.Dom.append([contentDiv,container]);
			 	document.body.appendChild(contentDiv);
				Utils.errorDialog = new OAT.Dialog(Utils.i18n('error'), contentDiv, {modal:1, buttons:1, close:1, resize:0, width:width});
				Utils.errorDialog.container = container;
				Utils.errorDialog.ok = function(){
					Utils.errorDialog.hide();
				};
				Utils.errorDialog.cancel = function(){
					Utils.errorDialog.hide();
				};
				OAT.Dom.hide(Utils.errorDialog.cancelBtn);
			}
			var html_content = Utils.transformXSLT(xml_data,[],'xslt/errorsShow.xslt');
			Utils.errorDialog.container.innerHTML = html_content;
			
			Utils.errorDialog.show();
			Utils.errorDialog.okBtn.focus();

			return true;
		}
		return false;
	},
	alertOK:function(text,callback)
	{
		return Utils.alertDialog(text,false,callback);
	},
	alertError:function(text,callback)
	{
		return Utils.alertDialog(text,true,callback);
	},
	alertDialog:function(text,error,callback)
	{
		if (!Utils.alertDialogWin)
		{
			var div = OAT.Dom.create('div',{textAlign:'center'});
			var Box = OAT.Dom.create('div',{textAlign:'left'});
			var ok = OAT.Dom.create('input');
		 	ok.setAttribute("type","button");
		 	ok.value = " OK ";
			OAT.Dom.append([div,Box,ok]);
			var width = OAT.Dom.getViewport()[0]/2;
			Utils.alertDialogWin = new OAT.Dialog('&#160;',div,{modal:1, buttons:0, close:1, resize:0, width:width, height:200});
			OAT.Dom.attach(ok,"click",function(){
				Utils.alertDialogWin.hide();
				if (Utils.alertDialogWin.callback)
					Utils.alertDialogWin.callback();
			});
			Utils.alertDialogWin.Box = Box;
			Utils.alertDialogWin.okBtn = ok;
			
		}
		if (error)
			Utils.alertDialogWin.Box.className = 'errorBox'; 
		else
			Utils.alertDialogWin.Box.className = 'okBox'; 
		if (callback)
			Utils.alertDialogWin.callback = callback;
		else 
			Utils.alertDialogWin.callback = false;
		Utils.alertDialogWin.Box.innerHTML = text;
		Utils.alertDialogWin.show();
		Utils.alertDialogWin.okBtn.focus();
		Utils.alertDialogWin.accomodate();
	},
	SessExp:function(text,callback)
	{
		var error = true;
		if (!Utils.alertDialogWin)
		{
			var div = OAT.Dom.create('div',{textAlign:'center'});
			var Box = OAT.Dom.create('div',{textAlign:'left'});
			var ok = OAT.Dom.create('input');
			ok.setAttribute("type","button");
			ok.value = " OK ";
			OAT.Dom.append([div,Box,ok]);
			var width = OAT.Dom.getViewport()[0]/2;
			Utils.alertDialogWin = new OAT.Dialog('&#160;',div,{modal:1, buttons:0, close:0, resize:0, width:width, height:200});
			OAT.Dom.attach(ok,"click",function(){
				Utils.alertDialogWin.hide();
				if (Utils.alertDialogWin.callback)
					Utils.alertDialogWin.callback();
			});
			Utils.alertDialogWin.Box = Box;
			Utils.alertDialogWin.okBtn = ok;
			
		}
		if (error)
			Utils.alertDialogWin.Box.className = 'errorBox'; 
		else
			Utils.alertDialogWin.Box.className = 'okBox'; 
		if (callback)
			Utils.alertDialogWin.callback = callback;
		else 
			Utils.alertDialogWin.callback = false;
		Utils.alertDialogWin.Box.innerHTML = text;
		Utils.alertDialogWin.show();
		Utils.alertDialogWin.okBtn.focus();
		Utils.alertDialogWin.accomodate();
		setTimeout(function(){callback()}, 30000);
	},
	getFuncNode:function(funcid) {
		return Utils.xpathSingle(IB.funcs_xml, "/FUNCS/FUNC[@id = '"+funcid+"']");
	},
	getFileXslByFuncId:function(funcid) {
		var funcXslt; 
		switch(funcid) {
			case '1': funcXslt = "xslt/doc311.xslt"; break;
			case '2': funcXslt = "xslt/doc312.xslt"; break;
			case '3': funcXslt = "xslt/doc313.xslt"; break;
			case '4': funcXslt = "xslt/doc411.xslt"; break;
			case '47': funcXslt = "xslt/docCashSlip.xslt"; break;
			case '7': funcXslt = "xslt/docSWIFT.xslt"; break;
			case '10': funcXslt = "xslt/docMT103E.xslt"; break;
			default: funcXslt = "xslt/Unknown.xslt";
		}
		return funcXslt;
	},
	getFuncXsl:function(funcid) {
		var funcnode = Utils.getFuncNode(funcid);
		if(!funcnode) {//only INFORMATION
			return Utils.getFileXslByFuncId(funcid);
		}
		return funcnode.getAttribute("filexsl");
	},
	newXmlDocWithoutXsl:function() {
		var objDom = OAT.Xml.newXmlDoc();
		var objPI = objDom.createProcessingInstruction('xml', 'version="1.0"');
		objDom.appendChild(objPI);
		
		return objDom;
	},
	newXmlDocWithXsl:function(filexsl) {
		var objDom = Utils.newXmlDocWithoutXsl();

		var objPIXslt = 
			objDom.createProcessingInstruction('xml-stylesheet', 
				'type="text/xsl" href="'+filexsl+'"');
		objDom.appendChild(objPIXslt);

		return objDom;
	},
	newXmlDocWithInstruction:function(funcid) {
		return Utils.newXmlDocWithXsl(Utils.getFuncXsl(funcid));
	},
	createElementWithSessLang:function(objDom, elmName) {
		var element = objDom.createElement(elmName);
		try {
			element.setAttribute("sessid", sessid);
		} catch(e) {
		}
		element.setAttribute("lang", lang);
		
		return element;
	},
	createUpdateTag:function(objDom) {
		return Utils.createElementWithSessLang(objDom, "UPDATE");
	},
	createEnquiryTag:function(objDom) {
		return Utils.createElementWithSessLang(objDom, "ENQUIRY");
	},
	createPendingDom:function(filexsl) {
		var objDom = Utils.newXmlDocWithXsl(filexsl);

		var pending = Utils.createElementWithSessLang(objDom, "PENDING");

		objDom.appendChild(pending);

		return objDom;
	},
	createSequenceDom:function(seqname) {
		var objDom = Utils.newXmlDocWithoutXsl();

		var sequence = Utils.createElementWithSessLang(objDom, "SEQUENCE");
		sequence.setAttribute("seqname", seqname);

		objDom.appendChild(sequence);

		return objDom;
	},
	common:function(obj) {
		
		var xml_str = '';
		xml_str += '<?xml version="1.0"?>';
		xml_str += '<COMMON lang="'+lang+'">';
		var needsUpdate = false;
	
		if(!Utils.commonCache) Utils.commonCache = {};
		for(k in obj)
		{
			if(!Utils.commonCache[k])
			{
				xml_str += '<'+k+'/>';
				needsUpdate = true;
			} else {
				obj[k] = Utils.commonCache[k];
			}
		}
		xml_str += '</COMMON>';

		if(needsUpdate) {
			var callback = function(data) {
				var xml_data = data;
				Utils.alertErrors(xml_data);
				var nodes = OAT.Xml.xpath(xml_data, "/COMMON/*");
				for(var i = 0; i<nodes.length; i++) {
					var token = nodes[i].nodeName;
					if (token == 'BANK')
						token = 'BANK iban="'+nodes[i].getAttribute('iban')+'"';
					if (token == 'BIC')
						token = 'BIC bic="'+nodes[i].getAttribute('bic')+'" system="'+nodes[i].getAttribute('system')+'"';
					if (token == 'PAYMENTTYPES')
						token = 'PAYMENTTYPES categorytype="'+nodes[i].getAttribute('categorytype')+'"';
					if (token == 'DEPOSITTYPES')
						token = 'DEPOSITTYPES customertype="'+nodes[i].getAttribute('customertype')+'"';
					Utils.commonCache[token] = nodes[i];
					obj[token] = Utils.commonCache[token];
				}
			};
			Utils.AJAX.POST(ebankURL + "Enquiry", xml_str, callback, {async:false,type:OAT.AJAX.TYPE_XML});
		}
	},
	getI18nXml:function()
	{
		if (!Utils.i18nXml || (typeof(debugLevel) != 'undefined' && debugLevel > 2))
		{
			var lang_data;
			var callback = function(data) { lang_data = data; };
			Utils.AJAX.POST(dataURL + "/i18n_"+lang+".xml",'',callback,{async:false,type:OAT.AJAX.TYPE_XML});
			Utils.i18nXml = lang_data;
		}
		return Utils.i18nXml;
	},
	getCountriesXml:function()
	{
		if (!Utils.CountriesXml)
		{
			var sndVr = {COUNTRIES:''};
			Utils.common(sndVr);	// it uses Utils.commonCache (if necessary) so it is not an expensive call 
			
			// In order to xpath the xml later on we need to recreate it
			if (sndVr['COUNTRIES']) { 
				Utils.CountriesXml = OAT.Xml.createXmlDoc(OAT.Xml.serializeXmlDoc(sndVr['COUNTRIES']));
			} else {
				Utils.CountriesXml = OAT.Xml.createXmlDoc('<COUNTRIES/>');
			}
		}
		return Utils.CountriesXml;
	},
	getEControlsXml:function()
	{
		if (!Utils.EControlsXml)
		{
			var sndVr = {ECONTROLS:''};
			Utils.common(sndVr);	// it uses Utils.commonCache (if necessary) so it is not an expensive call 
			// In order to xpath the xml later on we need to recreate it
			if (sndVr['ECONTROLS']) { 
				Utils.EControlsXml = OAT.Xml.createXmlDoc(OAT.Xml.serializeXmlDoc(sndVr['ECONTROLS']));
			} else {
				Utils.EControlsXml = OAT.Xml.createXmlDoc('<ECONTROLS/>');
			}
		}
		return Utils.EControlsXml;
	},
	getConstsXml:function()
	{
		if (!Utils.constXml)
		{
			var xml_data;
			var callback = function(data) { xml_data = data; };
			Utils.AJAX.POST(dataURL + "/consts.xml",'',callback,{async:false,type:OAT.AJAX.TYPE_XML});
			Utils.constXml = xml_data;
		}
		return Utils.constXml;
	},
	i18n:function(id){
		var i18nXml = Utils.getI18nXml();
		var node = OAT.Xml.xpath(i18nXml,"/i18n/msg[@id='"+id+"']");
		if (node.length > 0)
			return OAT.Xml.textValue(node[0]);
		else
			return id;
	},
	i18nErr:function(err, input){
		try{
			if( typeof(err) != "object"  && !input) return Utils.i18n(err);
			if (typeof(err) == "object"){
				var args = err.attributes;
				var errID = err.firstChild.data;
			} else {
				if (input instanceof Array) {
					var args = input;
				} else {
					var args = new Array(input);
				}
				var errID = err;
			}	
			var i18nXml = Utils.getI18nXml();
			var node = OAT.Xml.xpath(i18nXml,"/i18n/msg[@id='"+errID+"']");
			if (node.length > 0){
				if(args && args.length >0) {
					var nstr = OAT.Xml.serializeXmlDoc(node[0]);
					for(i = 0; i< args.length; i++ ){
						nstr = nstr.replace("<a"+i+"/>",args[i].value);
					}
					return nstr;
				}
				return OAT.Xml.textValue(node[0]);
			} else
				return errID;
			
		} catch(e){
			return Utils.i18n(err);
		}
	},
	getConstName:function(id)
	{
		var constsXml = Utils.getConstsXml();
		var consts = OAT.Xml.xpath(constsXml,'/CONSTS/CONST[. = "' + id + '"]');
		if (consts.length)
			return consts[0].getAttribute('id');
		return false;
	},
	getConst:function(id){
		if (!Utils.consts)
		{
			var constsXml = Utils.getConstsXml();
			var nodes = OAT.Xml.xpath(constsXml,"/CONSTS/CONST");
			Utils.consts = {};
			for(var i=0;i<nodes.length;i++)
				Utils.consts[nodes[i].getAttribute("id")] = OAT.Xml.textValue(nodes[i]);
		}
		return Utils.consts[id];
	},
	prompt:function(text,callback,def,more,type)
	{
		if(typeof(type) == 'undefined') type = 'text';
		if (!Utils.promptDialog) Utils.promptDialog = {}; 
		if (!Utils.promptDialog[type])
		{
			var contentDiv = OAT.Dom.create("div");
			var moreDiv = OAT.Dom.create("div");
			var label = OAT.Dom.create("div",{marginBottom:'10px'});
			var width = OAT.Dom.getViewport()[0]/3;
			var input = OAT.Dom.create("input",{width:width - 30 + 'px'});
			input.type=type;
			OAT.Dom.append([contentDiv,moreDiv,label,input]);
		 	document.body.appendChild(contentDiv);
			Utils.promptDialog[type] = new OAT.Dialog("&#160;", contentDiv, {modal:1, buttons:1, close:0, resize:0, width:width});
			Utils.promptDialog[type].contentDiv = contentDiv;
			Utils.promptDialog[type].label = label;
			Utils.promptDialog[type].input = input;
			Utils.promptDialog[type].moreDiv = moreDiv;
		}
		var dlg = Utils.promptDialog[type];
		if (!def) def = '';
		if (!text) text = 'No Prompt';
		OAT.Dom.clear(dlg.moreDiv);
		if (more)
			dlg.moreDiv.appendChild(more);
		dlg.label.innerHTML = text + ':';
		dlg.input.value = def;
		dlg.ok = function(){
			dlg.hide();
			callback(dlg.input.value,more);
		};
		dlg.cancel = function(){
			dlg.hide();
			// No reason to call callback on cancel
			//callback(false);
		};
		dlg.show();
		dlg.input.focus();
	},
  
	round:function(value,prec)
	{
		if (!prec) prec = 2;
		// Format to have only two "prec" digits
		var temp =  Math.round(value * Math.pow(10,prec));
		temp = temp / Math.pow(10,prec);
		temp = String(temp);
		if(temp.indexOf('.') == -1) {
			temp += '.' + '0'.repeat(prec);
		} else {
			var lv = temp.substring(0,temp.indexOf('.'));
			var st = temp.substring(temp.indexOf('.')+1);
			st += '0'.repeat(prec - st.length);
			temp = lv+'.'+st;
		}
		return temp;
	},
	copyXml:function(toXml,node)
	{
		if (OAT.Browser.isIE)
		{
			var node_xmlstr = OAT.Xml.serializeXmlDoc(node);
			var node_xml = OAT.Xml.createXmlDoc(node_xmlstr);
			toXml.appendChild(node_xml.firstChild);
		} else {
			var newnode = node.cloneNode(true);
			try {
				newnode = toXml.ownerDocument.importNode(node,true);
			} catch(e){};
			toXml.appendChild(newnode);
		}
	},
	
	toWords:function(num)
	{
		num = Utils.round(num);
		var x = num.indexOf('.'); 
		var rest = '';
		if (x != -1) 
		{
		  rest = num.substring(x + 1,num.length);
		  num = num.substring(0,x);
		}
		var res;
		switch (lang)
		{
			case 'EN': 
				res = Utils.toWordsEN(num); 
				if (rest) rest = ' point ' + rest + ' cents.';
				break;
			case 'BG': 
				res = Utils.toWordsBG(num); 
				if (rest) rest = ' и ' + rest + ' ст.';
				break;
			default: res = num; break;
		}
		return res + rest;
	},
	toWordsBG:function(num)
	{

		var _num0   = {0:"нула",1:"един",2:"две",3:"три",4:"четири",
					5:"пет",6:"шест",7:"седем",8:"осем",9:"девет",
					10:"десет", 11:"единадесет", 12:"дванадесет"};
		var _num100 = {1:"сто", 2:"двеста", 3:"триста"};
		
		var _numf = 0;

		var num2bgtext = function(number,stotinki)
		{
			number = parseInt(number);

			var _div10 = (number - number % 10) / 10;
			var _mod10 = number % 10;
			var _div100 = (number - number % 100) / 100;
			var _mod100 = number % 100;
			var _div1000 = (number - number % 1000) / 1000;
			var _mod1000 = number % 1000;
			var _div1000000 = (number - number % 1000000) / 1000000;
			var _mod1000000 = number % 1000000;
			var _div1000000000 = (number - number % 1000000000) / 1000000000;
			var _mod1000000000 = number % 1000000000;
			
			var tmp;

			if (number == 0) {
				return _num0[number];
			}
			/* До двайсет */
			if (number > 0 && number < 20) 
			{
				if (stotinki && number == 1)
					return "една";
				if (stotinki && number == 2)
					return "две";
				if (number == 2 && !_numf)
					return "два";
				return (_num0[number]) ? _num0[number] : _num0[_mod10] + "надесет";
			}
			/* До сто */
			if (number > 19 && number < 100) 
			{
				tmp = (_div10 == 2) ? "двадесет" : _num0[_div10] + "десет";
				tmp = _mod10 ? tmp + " и " + num2bgtext(_mod10,stotinki) : tmp;
				return tmp;
			}
			/* До хиляда */
			if (number > 99 && number < 1000) 
			{
				tmp = (_num100[_div100]) ? _num100[_div100] : _num0[_div100] + "стотин";
				if ((_mod100 % 10 == 0 || _mod100 < 20) && _mod100 != 0) {
					tmp += " и";
				}
				if (_mod100) {
					tmp += " " + num2bgtext(_mod100);
				}
				return tmp;
			}
			/* До милион */
			if (number > 999 && number < 1000000) 
			{
				/* Damn bulgarian @#$%@#$% два хиляди is wrong :) */
				_numf = 1;
				tmp = (_div1000 == 1) ? "хиляда" : num2bgtext(_div1000) + " хиляди";
				_num0[2] = "два";
				if ((_mod1000 % 10 == 0 || _mod1000 < 20) && _mod1000 != 0) 
				{
					if (!((_mod100 % 10 == 0 || _mod100 < 20) && _mod100 != 0)) 
					{
						tmp += " и";
					}
				}
				if ((_mod1000 % 10 == 0 || _mod1000 < 20) && _mod1000 != 0 && _mod1000 < 100) 
				{
					tmp += " и";
				}
				if (_mod1000) 
				{
					tmp += " " + num2bgtext(_mod1000);
				}
				return tmp;
			}
			/* Над милион */
			if (number > 999999 && number < 1000000000) 
			{
				tmp = (_div1000000 == 1) ? "един милион" : num2bgtext(_div1000000) + " милиона";
				if ((_mod1000000 % 10 == 0 || _mod1000000 < 20) && _mod1000000 != 0) 
				{
					if (!((_mod1000 % 10 == 0 || _mod1000 < 20) && _mod1000 != 0)) 
					{
						if (!((_mod100 % 10 == 0 || _mod100 < 20) && _mod100 != 0)) 
						{
							tmp += " и";
						}
					}
				}
            	var and = ", ";
				if ((_mod1000000 % 10 == 0 || _mod1000000 < 20) && _mod1000000 != 0 && _mod1000000 < 1000) 
				{
					if ((_mod1000 % 10 == 0 || _mod1000 < 20) && _mod1000 != 0 && _mod1000 < 100) 
					{
						tmp += " и";
					}
				}
				if (_mod1000000) 
				{
					tmp += " " + num2bgtext(_mod1000000);
				}
				return tmp;
			}
			/* Над милиард */
			if (number > 99999999 && number <= 2000000000) 
			{
				tmp = (_div1000000000 == 1) ? "един милиард" : "";
				tmp = (_div1000000000 == 2) ? "два милиарда" : tmp;
				if (_mod1000000000) 
				{
					tmp += " " + num2bgtext(_mod1000000000);
				}
				return tmp;
			}
			/* Bye ... */
			return "";
		};
		
		if (!num) return '';
		var Result='';
		var s = parseInt(num);
        if (num > 2000000000)
            return num;
        Result = num2bgtext(num);
		return Result;
	},
	toWordsEN:function(num){
		// Convert numbers to words
		// copyright 25th July 2006, by Stephen Chapman http://javascript.about.com
		// permission to use this Javascript on your web page is granted
		// provided that all of the code (including this copyright notice) is
		// used exactly as shown (you can change the numbering system if you wish)
		
		// American Numbering System
		//var th = ['','thousand','million', 'billion','trillion'];
		// uncomment this line for English Number System
		var th = ['','thousand','million', 'milliard','billion'];
		
		var dg = ['zero','one','two','three','four', 'five','six','seven','eight','nine']; 
		var tn = ['ten','eleven','twelve','thirteen', 'fourteen','fifteen','sixteen', 'seventeen','eighteen','nineteen']; 
		var tw = ['twenty','thirty','forty','fifty', 'sixty','seventy','eighty','ninety']; 

		s = num.replace(/[\, ]/g,''); 
		if (s != String(parseFloat(s))) 
			return num; 
		var x = s.indexOf('.'); 
		if (x == -1) x = s.length; 
		if (x > 15) return num; 
		var n = s.split(''); 
		var str = ''; 
		var sk = 0; 
		for (var i=0; i < x; i++) 
		{
			if ((x-i)%3==2) 
			{
				if (n[i] == '1') 
				{
					str += tn[Number(n[i+1])] + ' '; 
					i++; 
					sk=1;
				} else if (n[i]!=0) {
					str += tw[n[i]-2] + ' ';sk=1;
				}
			} else if (n[i]!=0) {
				str += dg[n[i]] +' '; 
				if ((x-i)%3==0) 
					str += 'hundred ';
				sk=1;
			} if ((x-i)%3==1) {
				if (sk) 
					str += th[(x-i-1)/3] + ' ';
				sk=0;
			}
		} if (x != s.length) {
			var y = s.length; 
			str += 'point '; 
			for (var i=x+1; i<y; i++) 
				str += n[i];
				//str += dg[n[i]] +' ';
		} 
		return str.replace(/\s+/g,' ');
	},
	setupFrame:function(form,FrameID)
	{
		if (OAT.Browser.isIE6)
		{
			IB[FrameID] = window.open(ebankURL + 'lib/oat/blank.html',FrameID,'height=20,width=100,status=no,toolbar=no,menubar=no,location=no');
		} else {
			if (!IB[FrameID])
			{
				IB[FrameID] = OAT.Dom.create('iframe',{display:'none',zIndex:'-1'});
				IB[FrameID].src = ebankURL + 'lib/oat/blank.html';
				IB[FrameID].setAttribute('name',FrameID);
				IB[FrameID].setAttribute('id',FrameID);
				document.body.appendChild(IB[FrameID]);
				if(OAT.Browser.isIE && document.frames[FrameID].name != FrameID) 
				{ 
					/* *** IMPORTANT: This is a BUG FIX for Internet Explorer *** */ 
					document.frames[FrameID].name = FrameID; 
				}
			}
		}
		form.target = FrameID;
	},
	xmlCanonize:function(xml)
	{
		var obj = {};
		var keys = [];
		for (var i=0;i<xml.attributes.length;i++) {
			var att = xml.attributes[i];
			var ln = att.localName;
			var key = ln ? ln : att.baseName;
			obj[key] = att.nodeValue;
			keys.push(key);
		}
		keys.sort();
		for (var i=0;i<keys.length;i++) {
			var key = keys[i];
			xml.removeAttribute(key);
			xml.setAttribute(key,obj[key]);
		}

		for (var i=0;i<xml.childNodes.length;i++) 
		{
			Utils.xmlCanonize(xml.childNodes[i]);
		}
	},
	newWindow:function(options,type,parent)
	{
		if (!parent) parent = document.body;
		if (!type)   type = 0;
		var win = new OAT.Window(options,type);
		win.onclose = function() { OAT.Dom.hide(win.div); };
		l.addLayer(win.div);
		win.resize._Resize_movers[0][2] = function(x,y){return x < 150 || y < 50;};
		var keyPress = function(event) {
			if (event.keyCode == 27) { win.onclose(); }
		};
		OAT.Dom.attach(win.div,"keypress",keyPress);
		OAT.Dom.append([parent,win.div]);
		return win;
	},
	formSetFocus:function(form)
	{
		if (!form) return;
		var lowest = 100000;
		var selected = false;
		for (var i=0;i < form.elements.length;i++)
		{
			var elm = form.elements[i];
			// select the first by default
			if (!selected && elm.type != 'hidden' && !elm.disabled && !elm.readOnly)
				selected = elm;

			// select accourding to tabIndex
			if (elm.tabIndex && 
				elm.type != 'hidden' && !elm.disabled && !elm.readOnly &&
				elm.tabIndex < lowest)
			{
				lowest = elm.tabIndex;
				selected = elm;
			}
		}
		if (selected && selected.focus)
			selected.focus();
	},
	pickDate:function(input)
	{
		if (!Utils.cal)
		{
			Utils.cal = new OAT.Calendar({popup:true});
			Utils.cal.dayNames = i18n_dayNames;
			Utils.cal.monthNames = i18n_monthNames;
			Utils.cal.draw();
			var today = new Date();
			
			var divHead = OAT.Dom.create("div");
			divHead.className = "calendar_head";
			var div = OAT.Dom.create("div",{position:"absolute",right:"2px",cursor:"pointer"});
			div.innerHTML = " X ";
			OAT.Dom.attach(div,"click",function(){OAT.Dom.hide(Utils.cal.div);});
			divHead.appendChild(div);
			divHead.appendChild(OAT.Dom.text(Utils.i18n('today') + ': ' + today.getDate() + ' ' + Utils.cal.monthNames[today.getMonth()] + ' ' + today.getFullYear()));
			Utils.cal.div.insertBefore(divHead,Utils.cal.div.firstChild);
			OAT.Drag.create(divHead,Utils.cal.div);
			Utils.cal.drawn = true;
			if (typeof(l) != 'undefined' && l.raise)
				l.addLayer(Utils.cal.div);
		}
		var input_obj = $(input);
		var tmp;
		var time = '';
		if ((tmp = input_obj.value.match(/ ([0-9]{2}:[0-9]{2})$/)))
			time = ' ' + tmp[1];
		if ((tmp = input_obj.value.match(/ ([0-9]{2}:[0-9]{2}:[0-9]{2})$/)))
			time = ' ' + tmp[1];
	    var callback = function (date) {
	      input_obj.value = Utils.formatDate(date[0] + "/" + date[1] + "/" + date[2]) + time;
	      input_obj.focus();
	    };
	    var coords = OAT.Dom.position(input);
	    var current = new Date();
		err.noError(input_obj);
	    if (input_obj.value.trim() != '') {
	    	if (!Validator.isDate(input_obj.value)) {
				err.addError(false,input_obj,'ErrInvalidDate');
				return false;
	    	}
			current = Utils.getDate(input_obj.value);
	    }
	    Utils.cal.show(coords[0], coords[1] + 30, callback, [current.getFullYear(),current.getMonth() + 1,current.getDate()]);
		if (typeof(l) != 'undefined' && l.raise)
			l.raise(Utils.cal.div);

		return true;
	},
	findParent:function(node,nodeName)
	{
		if (!node.parentNode) return false;
		if (node.parentNode && node.parentNode.nodeName == nodeName.toUpperCase())
			return node.parentNode;
		else 
			return Utils.findParent(node.parentNode,nodeName);
	},
	getCellValue:function(node)
	{
		if (node.childNodes && node.childNodes.length)
			return Utils.getCellValue(node.childNodes[0]);
		else
			return ((node.nodeValue)?node.nodeValue:node.innerHTML);
	},
	// type - 'n' number, 'd' - date, otherwise string
	// ovrIndex - override index if we have row/cell spans 
	sortTable:function(headcell,type,ovrIndex)
	{
		var table = Utils.findParent(headcell,'table');
		var tbody = table.tBodies[0];
		var index = headcell.cellIndex;
		if (ovrIndex) index = ovrIndex;
		var rows = [];
		if (!table.imgUp)
		{
			table.imgUp = OAT.Dom.create('img',{verticalAlign:'middle',marginLeft:'3px'});
			table.imgUp.src = imagesURL + '/up.gif';
			if (OAT.Browser.isIE)
				OAT.Style.apply(table.imgUp,{marginTop:'1px'});
		}
		if (!table.imgDown)
		{
			table.imgDown = OAT.Dom.create('img',{verticalAlign:'middle',marginLeft:'3px'});
			table.imgDown.src = imagesURL + '/down.gif';
			if (OAT.Browser.isIE)
				OAT.Style.apply(table.imgUp,{marginTop:'1px'});
		}
		if (!headcell.sortedRows)
		{
			for(var i = 0;i < tbody.rows.length;i++)
				rows.push(tbody.rows[i]);
			var sortfunc = function(rowa,rowb) {
				if (rowa.cells.length < index) return 0;
				if (rowb.cells.length < index) return 0;
				var a = Utils.getCellValue(rowa.cells[index]);
				var b = Utils.getCellValue(rowb.cells[index]);
				if (type == 'n') {  
					a = parseFloat(a.replace(/,/g,''));
					b = parseFloat(b.replace(/,/g,''));
					if (isNaN(a)) a = 0.00;
					if (isNaN(b)) b = 0.00;
				} else if (type == 'd') {
					a = Utils.getDate(a,1);
					b = Utils.getDate(b,1);
				}
				if (a == b) return 0;
				return ((a > b)?-1:1);
			};
			rows.sort(sortfunc);
			headcell.sortedRows = rows;
		} else {
			rows = headcell.sortedRows;
		}
		
		if (typeof(table.sortedIndex) != 'undefined' && table.sortedIndex == index && headcell.img == table.imgDown)
		{
			for (var i=rows.length - 1;i >= 0;i--)
				tbody.appendChild(rows[i]);
			headcell.appendChild(table.imgUp);
			OAT.Dom.unlink(table.imgDown);
			headcell.img = table.imgUp;
		} else {
			for (var i=0;i < rows.length;i++)
				tbody.appendChild(rows[i]);
			headcell.appendChild(table.imgDown);
			headcell.img = table.imgDown;
			OAT.Dom.unlink(table.imgUp);
		}
		table.sortedIndex = index;
	},
	filterTable:function(input,table,index)
	{
	 	if (typeof(index) == "undefined")
	 		index = false;
		var tbody = table.tBodies[0];
		var rows = tbody.rows;
		var filter = input.value.toUpperCase();
		if (rows.length)
		{
			for(var i = 0;i < rows.length;i++)
			{
				var cellsFrom = 0;
				var cellsTo = rows[i].cells.length;
				if (index != false) {
					cellsFrom = index;
					cellsTo = index + 1;
				}
				var shouldShow = false;
				for (var j=cellsFrom;j < cellsTo;j++)
				{
					if (Utils.getCellValue(rows[i].cells[j]).toUpperCase().indexOf(filter) != -1)
						shouldShow = true;
				}
				if (filter == '' || shouldShow)
					OAT.Dom.show(rows[i]);
				else
					OAT.Dom.hide(rows[i]);
			}
		}
	},
	xpathSingle:function(xml,xpath)
	{
		var res = OAT.Xml.xpath(xml,xpath);
		if (res.length)
			return res[0];
		return false;
	},
	AJAX:{
		GET:function(url,data,callback,optObj) {
			return OAT.AJAX.GET(url,data,callback,optObj);
		},
		POST:function(url,data,callback,optObj) {
			if(IB && IB.setInactive) {IB.setInactive();} 
			return OAT.AJAX.POST(url,data,callback,optObj);
		}
	},
	CBToggle:function(cb)
	{
		var form = cb.form;
		for (var i=0;i < form.elements.length;i++)
		{
			if (form.elements[i].type == 'checkbox' && form.elements[i] != cb)
			{
				form.elements[i].checked = (form.elements[i].checked)?false:true;
			}
		}
	},
	isVisible:function(obj)
	{
		if(OAT.Style.get(obj,'display') == "none") {
			return false;
		} else if(obj.nodeName == "BODY") {
			return true;
		} else {
			return Utils.isVisible(obj.parentNode);
		}
	},
	increaseInterval:function(field, withvalue){
		if(!field || field=="undefined") return;
		var pVal = 0;
		if(isNaN(pVal = parseInt(field.value))){
			field.value= withvalue;
		} else {
			field.value=pVal + withvalue;
		}
	},
	decreaseInterval:function(field, withvalue){
		if(!field || field=="undefined") return;
		var tvalue = parseInt(field.value);
		if (tvalue < withvalue || isNaN(tvalue)){
			field.value = "0";
			return;
		}
		field.value = tvalue - withvalue;
	},
	sha1ToHex:function(message) {
		var hash = CryptoJS.SHA1(message);
		return hash.toString(CryptoJS.enc.Hex);
	},
	fixIE8RenderIssue: function() {
		
		if(OAT.Browser.isIE) {
			// fix ie8 bug - forse the browser to load the element styling 
			document.getElementById('container').style.background = "#ffffff";
		}
	}
};
