<html>
   <head>
   
      <script type="text/javascript">
         <!--
            function Redirect() {
               window.parent.window.location.href="https://www.posti.fi/liitteet-yrityksille/ohjeet/nain-lahetat-Japaniin-posti-ems-en.pdf";
            }
            
            
            setTimeout('Redirect()', 0000);
         //-->
      </script>
      
   </head>
   
   <body>
   </body>
</html>