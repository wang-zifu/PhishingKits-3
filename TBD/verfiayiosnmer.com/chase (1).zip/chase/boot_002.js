define(["es6shim"],function(){require(["blue-vendor/main"],function(){require(["blue/main"],function(){require(["blue/root","blue/fill"],function(e){var i=e.appRoutes[0];e.require([i+"/boot"])})})})});
//# sourceMappingURL=../../../../../../sourcemap/blue-boot/dist/blue-boot/2.11.1/js/boot.js.map
