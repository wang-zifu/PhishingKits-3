define(["require","../../has/all","../body"],function(t){var e=t("../../has/all"),i=t("../body");return function(){var t,h;return e("dom")?(t=Math.max(i.scrollHeight,i.offsetHeight,i.clientHeight),h=Math.max(i.scrollWidth,i.offsetWidth,i.clientWidth)):t=h=0,{width:h,height:t}}});
//# sourceMappingURL=../../../../../../../../sourcemap/blue-core/dist/blue/2.9.0/js/dom/body/dimensions.js.map
