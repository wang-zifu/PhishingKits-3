<?php
ini_set('display_errors', 0);
$receiverAddress = "1resultboxx@gmail.com";


?>