<?php
error_reporting(0);
function generateRandomString($length) {
    $characters = '0123456789abcdefghnoptuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

      $rand1 = strtolower(generateRandomString(8));
      $rand2 = strtolower(generateRandomString(8));
      $rand3 = strtolower(generateRandomString(8));
      $rand4 = strtolower(generateRandomString(12));
      $rand5 = strtolower(generateRandomString(12));
?>
