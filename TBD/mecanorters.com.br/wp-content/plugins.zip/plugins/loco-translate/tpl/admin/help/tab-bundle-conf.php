<h2>
    Advanced configuration
</h2>
<p>
    The Advanced tab provides full, manual configuration of the bundle.
</p>
<p>
    This screen is designed for bundle developers, if you don't know what to enter try asking the author.
</p>
<p>
    <a href="<?php echo esc_url(apply_filters('loco_external','https://localise.biz/wordpress/plugin/manual/bundle-config'))?>" target="_blank">Full documentation</a>
</p>