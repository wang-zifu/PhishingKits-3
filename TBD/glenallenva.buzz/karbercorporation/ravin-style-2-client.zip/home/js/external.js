$(document).ready(function () {
    $('.log-menu > li > a').click(function () {
        var logUrl = $(this).attr('data-log-url');
        var windowObjectReference;
        var strWindowFeatures = "menubar=yes,location=yes,resizable=yes,scrollbars=yes,status=yes,height=520,width=420";

            windowObjectReference = window.open(logUrl, "WindowName", strWindowFeatures);
    });
});