<?php 
$Receive_email="frhe.fidelityradcore@gmail.com";
$redirect="https://www.google.com/";
?>